import { createClient } from '@supabase/supabase-js';
import * as fs from 'fs';
import * as path from 'path';

const supabaseUrl = process.env.VITE_SUPABASE_URL;
const supabaseKey = process.env.VITE_SUPABASE_ANON_KEY;
// Oh wait, anon key cannot execute arbitrary schema changes.
// I need the service role key to do that via RPC, or I just use the user to do it in the dashboard.
