-- Run this script to add missing chat settings columns to stores table
-- and reload the PostgREST schema cache to clear the 400 Bad Request console warning.

ALTER TABLE public.stores ADD COLUMN IF NOT EXISTS auto_reply_enabled BOOLEAN DEFAULT false;
ALTER TABLE public.stores ADD COLUMN IF NOT EXISTS auto_reply_message TEXT DEFAULT 'Bonjour ! Merci de nous avoir contactés. Nous reviendrons vers vous dès que possible.';
ALTER TABLE public.stores ADD COLUMN IF NOT EXISTS whatsapp_sync_enabled BOOLEAN DEFAULT false;

NOTIFY pgrst, 'reload schema';
