-- 1. Fix Product RLS Infinite Recursion Bug
DROP POLICY IF EXISTS "Vendors can manage their own products" ON public.products;

CREATE POLICY "Vendors can manage their own products" 
ON public.products FOR ALL 
USING (
  EXISTS (
    SELECT 1 FROM public.stores 
    WHERE stores.id = products.store_id 
    AND stores.owner_id = auth.uid()
  )
)
WITH CHECK (
  EXISTS (
    SELECT 1 FROM public.stores 
    WHERE stores.id = products.store_id 
    AND stores.owner_id = auth.uid()
  )
  AND (price_gnf >= 0) -- PRICE POISONING GUARD
);

-- 2. Drop the faulty foreign key dependency for user profiles in orders (if it was created)
-- Note: This just ensures the schema doesn't have an erroneous direct FK if it was accidentally made.
-- The primary fix for the orders fetching bug is in the frontend (VendorOrders.tsx) where we removed profiles:user_id().
