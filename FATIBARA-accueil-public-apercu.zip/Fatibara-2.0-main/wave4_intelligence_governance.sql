-- WAVE 4: OPERATIONAL INTELLIGENCE & GOVERNANCE
-- This script adds communication channels and hardens financial settings.

-- 1. ANNOUNCEMENTS TABLE (For Platform-wide Intelligence)
CREATE TABLE IF NOT EXISTS public.announcements (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    created_at TIMESTAMPTZ DEFAULT now(),
    title TEXT NOT NULL,
    content TEXT NOT NULL,
    target_type TEXT DEFAULT 'all', -- 'all', 'vendors', 'couriers', 'clients'
    is_active BOOLEAN DEFAULT true,
    created_by UUID REFERENCES auth.users(id)
);

-- 2. ENABLE RLS ON ANNOUNCEMENTS
ALTER TABLE public.announcements ENABLE ROW LEVEL SECURITY;

-- 3. ANNOUNCEMENTS POLICIES
CREATE POLICY "Public announcements are viewable by everyone" 
ON public.announcements FOR SELECT USING (is_active = true);

CREATE POLICY "Admins have full control over announcements" 
ON public.announcements FOR ALL USING (
    EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND is_admin = true)
);

-- 4. ENSURE WAVE 4 SETTINGS ARE INITIALIZED
INSERT INTO public.platform_settings (id, value, description)
VALUES 
('maintenance_mode', 'false', 'Global toggle to disable platform operations'),
('max_withdraw_daily', '5000000', 'Maximum GNF a vendor/courier can withdraw in 24h'),
('support_contact', 'support@fatibara.gn', 'Official support email shown in apps')
ON CONFLICT (id) DO NOTHING;
