#!/usr/bin/env bash

set -e

echo "🧹 1. Normalizing migration filenames (14-digit timestamps)..."
for file in supabase/migrations/[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]_*.sql; do
    if [ -f "$file" ]; then
        base=$(basename "$file")
        date_part=$(echo "$base" | cut -d'_' -f1)
        rest_part=$(echo "$base" | cut -d'_' -f2-)
        
        if [ ${#date_part} -eq 8 ]; then
            new_name="supabase/migrations/${date_part}000000_${rest_part}"
            echo "   -> Renaming $file -> $new_name"
            mv "$file" "$new_name"
        fi
    fi
done

echo "🚀 2. Booting Supabase local services..."
npx supabase@latest start || true

echo "🔄 3. Applying clean migration reset..."
npx supabase@latest db reset

echo "=================================================="
echo "🎉 SUCCESS! Fatibara local database is fully up and synced!"
echo "=================================================="
