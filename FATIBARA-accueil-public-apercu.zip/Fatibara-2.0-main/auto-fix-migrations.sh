#!/usr/bin/env bash

MAX_RETRIES=20
COUNT=0

echo "🤖 Starting dynamic migration auto-repair..."

while [ $COUNT -lt $MAX_RETRIES ]; do
    echo "--------------------------------------------------"
    echo "🚀 Attempting Supabase start (Attempt $((COUNT+1)))..."
    
    OUTPUT=$(npx supabase@latest start 2>&1)
    
    if echo "$OUTPUT" | grep -q "Started supabase local development setup"; then
        echo "=================================================="
        echo "🎉 SUCCESS! Supabase local setup completed!"
        echo "=================================================="
        exit 0
    fi

    # Extract target file name correctly
    FAILING_RAW=$(echo "$OUTPUT" | grep -o "Applying migration [^...]*" | tail -n 1 | awk '{print $3}' | tr -d '.')
    if [ -n "$FAILING_RAW" ]; then
        FAILING_FILE="${FAILING_RAW}.sql"
    fi
    
    ERROR_MSG=$(echo "$OUTPUT" | grep -A 10 "ERROR:")

    echo "❌ Migration failed on file: ${FAILING_FILE:-'Unknown'}"
    echo "$ERROR_MSG"
    echo "🧠 Requesting fix from Qwen2.5-Coder..."

    PROMPT="You are a database engineer fixing Supabase local migration errors.
Error details:
$ERROR_MSG

Fix missing relation (SQLSTATE 42P01) or missing column (SQLSTATE 42703) on user schema tables (public/auth). Do NOT alter internal supabase_migrations.

RULES:
- Return ONLY 1 single valid executable SQL line (e.g. CREATE TABLE IF NOT EXISTS public.tablename (id uuid PRIMARY KEY DEFAULT gen_random_uuid()); or ALTER TABLE public.tablename ADD COLUMN IF NOT EXISTS colname type;).
- No code fences. No markdown. No text explanations."

    SQL_FIX=$(ollama run qwen2.5-coder "$PROMPT" | tr -d '\r' | sed 's/```sql//g; s/```//g; s/^[[:space:]]*//; s/[[:space:]]*$//')

    # Ignore fixes targeting internal Supabase tables
    if echo "$SQL_FIX" | grep -qi "supabase_migrations"; then
        echo "⚠️ Fix target invalid (internal schema). Skipping injection."
        COUNT=$((COUNT+1))
        continue
    fi

    if [ -n "$FAILING_FILE" ] && [ -n "$SQL_FIX" ]; then
        TARGET_FILE="supabase/migrations/$FAILING_FILE"
        
        # Avoid prepending if the line is already present at top
        if grep -Fq "$SQL_FIX" "$TARGET_FILE"; then
            echo "⚠️ Fix already present in $TARGET_FILE, skipping re-injection."
        else
            echo "🔧 Injecting fix into $TARGET_FILE:"
            echo "   -> $SQL_FIX"
            
            tmp_file=$(mktemp)
            echo "$SQL_FIX" > "$tmp_file"
            echo "" >> "$tmp_file"
            cat "$TARGET_FILE" >> "$tmp_file"
            mv "$tmp_file" "$TARGET_FILE"
        fi
    else
        echo "⚠️ Could not parse fix command."
    fi

    COUNT=$((COUNT+1))
    sleep 1
done

echo "❌ Reached max retries ($MAX_RETRIES). Check remaining errors manually."
