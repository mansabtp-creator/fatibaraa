-- OPTIMIZE VENDOR DASHBOARD PERFORMANCE
-- This script creates a powerful backend RPC to aggregate all vendor metrics, eliminating massive frontend data fetching.

CREATE OR REPLACE FUNCTION public.get_vendor_dashboard_metrics(target_vendor_id UUID)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_store_id UUID;
    v_total_sales NUMERIC := 0;
    v_total_orders INT := 0;
    v_delivered_orders INT := 0;
    v_last_30_days_revenue NUMERIC := 0;
    v_total_products INT := 0;
    v_low_stock_count INT := 0;
    v_total_views INT := 0;
    v_avg_rating NUMERIC := 0;
    v_commission_str TEXT;
    v_commission_rate NUMERIC := 0.05;
    v_result JSONB;
BEGIN
    -- Authorization Check
    IF target_vendor_id != auth.uid() THEN
        RAISE EXCEPTION 'Unauthorized';
    END IF;

    -- Get Store ID
    SELECT id INTO v_store_id FROM public.stores WHERE owner_id = target_vendor_id;

    -- Fetch dynamic commission rate
    SELECT value INTO v_commission_str FROM public.platform_settings WHERE id = 'commission_rate';
    v_commission_rate := COALESCE(NULLIF(v_commission_str, '')::NUMERIC, 5) / 100.0;

    -- 1. Order Metrics
    SELECT 
        COALESCE(SUM(total_amount), 0),
        COUNT(*),
        COUNT(*) FILTER (WHERE status = 'delivered'),
        COALESCE(SUM(total_amount) FILTER (WHERE created_at >= NOW() - INTERVAL '30 days'), 0)
    INTO v_total_sales, v_total_orders, v_delivered_orders, v_last_30_days_revenue
    FROM public.orders
    WHERE vendor_id = target_vendor_id;

    -- 2. Product Metrics
    IF v_store_id IS NOT NULL THEN
        SELECT 
            COUNT(*),
            COUNT(*) FILTER (WHERE stock_quantity <= COALESCE(low_stock_threshold, 5))
        INTO v_total_products, v_low_stock_count
        FROM public.products
        WHERE store_id = v_store_id;

        -- Total Views
        SELECT COUNT(*)
        INTO v_total_views
        FROM public.product_views pv
        JOIN public.products p ON p.id = pv.product_id
        WHERE p.store_id = v_store_id;

        -- Average Rating
        SELECT COALESCE(AVG(rating), 0)
        INTO v_avg_rating
        FROM public.reviews r
        JOIN public.products p ON p.id = r.product_id
        WHERE p.store_id = v_store_id;
    END IF;

    -- Build Fast JSON Payload
    SELECT jsonb_build_object(
        'totalSales', v_total_sales,
        'totalOrders', v_total_orders,
        'totalProducts', v_total_products,
        'totalViews', v_total_views,
        'lowStockCount', v_low_stock_count,
        'score', CASE WHEN v_total_orders > 0 THEN ROUND((v_delivered_orders::NUMERIC / v_total_orders) * 10, 1) ELSE 0 END,
        'projectedRevenue', v_last_30_days_revenue * 1.15,
        'rating', ROUND(v_avg_rating, 1),
        'commissionRate', v_commission_rate,
        'last7Days', (
            SELECT COALESCE(jsonb_agg(
                jsonb_build_object(
                    'date', d::date::text,
                    'sales', COALESCE(daily.sales, 0),
                    'orders', COALESCE(daily.orders, 0)
                ) ORDER BY d ASC
            ), '[]'::jsonb)
            FROM generate_series(CURRENT_DATE - INTERVAL '6 days', CURRENT_DATE, '1 day') d
            LEFT JOIN (
                SELECT date_trunc('day', created_at) as dt, SUM(total_amount) as sales, COUNT(*) as orders
                FROM public.orders
                WHERE vendor_id = target_vendor_id AND created_at >= CURRENT_DATE - INTERVAL '6 days'
                GROUP BY 1
            ) daily ON date_trunc('day', d) = daily.dt
        ),
        'peakHours', (
            SELECT COALESCE(jsonb_agg(
                jsonb_build_object(
                    'hour', lpad(h::text, 2, '0') || ':00',
                    'value', COALESCE(ph.cnt, 0)
                ) ORDER BY h ASC
            ), '[]'::jsonb)
            FROM generate_series(0, 22, 2) h
            LEFT JOIN (
                SELECT (EXTRACT(hour FROM created_at)::int / 2) * 2 as bucket, COUNT(*) as cnt
                FROM public.orders
                WHERE vendor_id = target_vendor_id
                GROUP BY 1
            ) ph ON h = ph.bucket
        ),
        'topProducts', (
            SELECT COALESCE(jsonb_agg(
                jsonb_build_object(
                    'id', p.id,
                    'title', p.title,
                    'views', pv.views
                )
            ), '[]'::jsonb)
            FROM public.products p
            JOIN (
                SELECT product_id, COUNT(*) as views
                FROM public.product_views
                GROUP BY product_id
            ) pv ON pv.product_id = p.id
            WHERE p.store_id = v_store_id
            ORDER BY pv.views DESC
            LIMIT 3
        )
    ) INTO v_result;

    RETURN v_result;
END;
$$;
