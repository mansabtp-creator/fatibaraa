# Core Directives

- **Language**: Always communicate with the user in English. Even if the application UI is in French (to match the target market in Guinea), all agent responses and reasoning should be in English.
