-- Fix for the 'profiles.role does not exist' error.
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS role TEXT;
-- We align role with profile_type just in case legacy queries need it
UPDATE public.profiles SET role = profile_type WHERE role IS NULL;

-- 1. Drop existing problematic policies on profiles
DROP POLICY IF EXISTS "Public profiles are viewable by everyone." ON public.profiles;
DROP POLICY IF EXISTS "Profiles are viewable by self or admin" ON public.profiles;
DROP POLICY IF EXISTS "Users can insert their own profile." ON public.profiles;
DROP POLICY IF EXISTS "Users can insert their own profile" ON public.profiles;
DROP POLICY IF EXISTS "Users can update own profile." ON public.profiles;
DROP POLICY IF EXISTS "Users can update own profile" ON public.profiles;
DROP POLICY IF EXISTS "Admins can view all profiles" ON public.profiles;
DROP POLICY IF EXISTS "Admins can see all profiles" ON public.profiles;
DROP POLICY IF EXISTS "Admins have full profile access" ON public.profiles;

-- 2. Anyone can view profiles (required for storefronts, public vendor pages, etc)
CREATE POLICY "Public profiles are viewable by everyone." 
ON public.profiles FOR SELECT 
USING (true);

-- 3. Users can insert their own profile
CREATE POLICY "Users can insert their own profile." 
ON public.profiles FOR INSERT 
WITH CHECK (auth.uid() = id);

-- 4. Users can update their own profile
CREATE POLICY "Users can update own profile." 
ON public.profiles FOR UPDATE 
USING (auth.uid() = id) 
WITH CHECK (auth.uid() = id);

-- 5. Admins can update all profiles (for promotions, role assignments, etc)
CREATE POLICY "Admins can update all profiles"
ON public.profiles FOR UPDATE
USING (
  -- Check if current user is an admin
  EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND is_admin = true)
);

-- 6. Admins can delete profiles (if needed)
CREATE POLICY "Admins can delete profiles"
ON public.profiles FOR DELETE
USING (
  -- Check if current user is an admin
  EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND is_admin = true)
);
