
-- STORAGE SETUP: Verification Documents (Private & Secure)

-- 1. Create the bucket (Public: false for privacy)
INSERT INTO storage.buckets (id, name, public) 
VALUES ('verification-documents', 'verification-documents', false)
ON CONFLICT (id) DO NOTHING;

-- 2. Clear old policies if any
DROP POLICY IF EXISTS "Admins can view verification documents" ON storage.objects;
DROP POLICY IF EXISTS "Users can view own verification documents" ON storage.objects;
DROP POLICY IF EXISTS "Authenticated users can upload verification documents" ON storage.objects;

-- 3. Create Secure Policies

-- Policy: Authenticated users can upload to the verification folder 
-- We restrict it so they can only see/manage their own files later
CREATE POLICY "Authenticated users can upload verification documents"
ON storage.objects FOR INSERT
TO authenticated
WITH CHECK ( bucket_id = 'verification-documents' );

-- Policy: Users can view their own documents (via owner field)
CREATE POLICY "Users can view own verification documents"
ON storage.objects FOR SELECT
TO authenticated
USING ( bucket_id = 'verification-documents' AND (auth.uid() = owner) );

-- Policy: Admins can view ALL verification documents
-- Assuming profiles.is_admin exists
CREATE POLICY "Admins can view verification documents"
ON storage.objects FOR SELECT
TO authenticated
USING ( 
  bucket_id = 'verification-documents' 
  AND EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND is_admin = true)
);

-- 4. Update stores table to have 'status' column if missing (User mentioned it in Phase 1)
ALTER TABLE public.stores ADD COLUMN IF NOT EXISTS status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'active', 'rejected', 'suspended'));
