/**
 * GET /api/payment/status?tx_id=<uuid>  |  ?order_id=ORD-xxx  |  ?pay_id=<pay_id>
 *
 * For wallet top-up flows (tx_id):
 *   1. Check our DB — if already completed/failed, return immediately.
 *   2. If still 'pending', query LengoPay's /api/v1/transactions to get
 *      the real status. If LengoPay says SUCCESS, call credit_user_wallet
 *      and return 'completed' so the Vérifier button self-heals the balance.
 *
 * For order flows (order_id / pay_id): read-only DB check as before.
 */

import type { VercelRequest, VercelResponse } from '@vercel/node';
import { createClient } from '@supabase/supabase-js';

function getSupabase() {
  const url = process.env.VITE_SUPABASE_URL;
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY;
  if (!url || !key) throw new Error('[payment/status] Missing env vars.');
  return createClient(url, key, { auth: { persistSession: false, autoRefreshToken: false } });
}

// ── Query LengoPay for all Cash-In transactions and find one by pay_id ────────
async function fetchLengoPayStatus(targetPayId: string): Promise<string | null> {
  const licenseKey = (process.env.LENGOPAY_SECRET_KEY ?? process.env.LENGOPAY_API_KEY ?? '').trim();
  const websiteId  = (process.env.LENGOPAY_WEBSITE_ID ?? process.env.LENGOPAY_MERCHANT_ID ?? '').trim();

  if (!licenseKey || !websiteId) {
    console.warn('[payment/status] LengoPay credentials not configured — skipping live check.');
    return null;
  }

  try {
    const res = await fetch('https://portal.lengopay.com/api/v1/transactions', {
      method:  'POST',
      headers: {
        'Authorization': `Basic ${licenseKey}`,
        'Accept':        'application/json',
        'Content-Type':  'application/json',
      },
      body: JSON.stringify({ websiteid: websiteId }),
      signal: AbortSignal.timeout(15_000),
    });

    if (!res.ok) {
      console.warn('[payment/status] LengoPay transactions API returned', res.status);
      return null;
    }

    const list: Array<{ pay_id: string; status: string | number }> = await res.json();
    const match = list.find(t => t.pay_id === targetPayId);
    if (!match) return null;

    // Normalise: LengoPay returns strings in production, numeric in docs examples
    const raw = String(match.status).toUpperCase();
    if (raw === 'SUCCESS'   || raw === '1') return 'SUCCESS';
    if (raw === 'FAILED'    || raw === '2') return 'FAILED';
    if (raw === 'CANCELLED')               return 'CANCELLED';
    return raw; // PENDING, etc.
  } catch (e: any) {
    console.warn('[payment/status] LengoPay fetch error:', e.message);
    return null;
  }
}

export default async function handler(req: VercelRequest, res: VercelResponse) {
  if (req.method !== 'GET' && req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  const orderId = String(req.query.order_id ?? (req.body as any)?.order_id ?? '').trim();
  const txId    = String(req.query.tx_id    ?? (req.body as any)?.tx_id    ?? '').trim();
  const payId   = String(req.query.pay_id   ?? (req.body as any)?.pay_id   ?? '').trim();

  if (!orderId && !txId && !payId) {
    return res.status(400).json({ success: false, error: 'Paramètre requis : order_id, tx_id ou pay_id.' });
  }

  let supabase: ReturnType<typeof getSupabase>;
  try { supabase = getSupabase(); }
  catch { return res.status(503).json({ success: false, error: 'Configuration serveur incomplète.' }); }

  try {
    // ── Wallet top-up flow ───────────────────────────────────────────────────
    if (txId) {
      const { data: tx, error: txErr } = await supabase
        .from('wallet_transactions')
        .select('id, status, amount, type, pay_id, profile_id, store_id, description, updated_at')
        .eq('id', txId)
        .maybeSingle();

      if (txErr) return res.status(500).json({ success: false, error: 'Erreur de base de données.' });
      if (!tx)   return res.status(404).json({ success: false, found: false, status: 'not_found' });

      // ── Self-healing guard for Vendor store deposits ─────────────────────────────
      // If a vendor deposit was previously marked 'completed' (e.g. by credit_user_wallet)
      // but store balance was never credited, self-heal it now.
      if (tx.status === 'completed') {
        if (tx.store_id && tx.type === 'deposit' && !tx.description?.includes('(Crédité)')) {
          console.log(`[payment/status] Self-healing vendor store credit for completed tx ${tx.id}...`);
          const { error: storeErr } = await supabase.rpc('increment_store_balance', {
            p_store_id: tx.store_id,
            p_amount:   Number(tx.amount),
          });

          if (!storeErr) {
            const newDesc = (tx.description || 'Recharge Mobile Money') + ' (Crédité)';
            await supabase
              .from('wallet_transactions')
              .update({ description: newDesc, updated_at: new Date().toISOString() })
              .eq('id', tx.id);
            console.log(`[payment/status] ✓ Successfully self-healed store ${tx.store_id} with +${tx.amount} GNF.`);
          } else {
            console.error(`[payment/status] Failed to self-heal store ${tx.store_id}:`, storeErr.message);
          }
        }

        return res.status(200).json({
          success: true, found: true, type: 'topup', status: 'completed',
          amount: tx.amount, updated_at: tx.updated_at,
          message: 'Recharge confirmée. Votre portefeuille a été crédité.',
        });
      }

      if (tx.status === 'failed' || tx.status === 'cancelled') {
        return res.status(200).json({
          success: true, found: true, type: 'topup', status: 'failed',
          amount: tx.amount, updated_at: tx.updated_at,
          message: 'Recharge échouée ou annulée.',
        });
      }

      // ── Still pending → ask LengoPay for the truth ───────────────────────
      const storedPayId  = String(tx.pay_id ?? '').trim();
      const lengoStatus  = storedPayId ? await fetchLengoPayStatus(storedPayId) : null;

      if (lengoStatus === 'SUCCESS') {
        if (tx.store_id) {
          // Vendor store top-up: credit stores.balance directly
          const newDesc = (tx.description || 'Recharge Mobile Money — Boutique') + ' (Crédité)';
          const { error: casErr } = await supabase
            .from('wallet_transactions')
            .update({
              status: 'completed',
              pay_id: storedPayId || null,
              description: newDesc,
              updated_at: new Date().toISOString()
            })
            .eq('id', tx.id)
            .eq('status', 'pending');

          if (casErr) {
            console.error('[payment/status] CAS update failed for vendor store tx:', casErr.message);
            return res.status(200).json({
              success: false, found: true, type: 'topup', status: 'pending',
              message: 'Paiement détecté mais mise à jour échouée — contactez le support.',
            });
          }

          const { error: storeErr } = await supabase.rpc('increment_store_balance', {
            p_store_id: tx.store_id,
            p_amount:   Number(tx.amount),
          });

          if (storeErr) {
            console.error('[payment/status] increment_store_balance RPC failed:', storeErr.message);
            // Revert status to pending so retry can fix it
            await supabase.from('wallet_transactions').update({ status: 'pending' }).eq('id', tx.id);
            return res.status(200).json({
              success: false, found: true, type: 'topup', status: 'pending',
              message: 'Paiement détecté mais crédit boutique échoué — contactez le support.',
            });
          }

          console.log(`[payment/status] Self-healed vendor store topup ${tx.id} — +${tx.amount} GNF credited to store ${tx.store_id}.`);
        } else {
          // Personal user wallet top-up
          const { error: creditErr } = await supabase.rpc('credit_user_wallet', {
            p_tx_id:   tx.id,
            p_amount:  tx.amount,
            p_pay_id:  storedPayId,
            p_user_id: tx.profile_id,
          });

          if (creditErr) {
            console.error('[payment/status] credit_user_wallet failed:', creditErr.message);
            return res.status(200).json({
              success: false, found: true, type: 'topup', status: 'pending',
              message: 'Paiement détecté mais crédit échoué — contactez le support.',
            });
          }

          console.log(`[payment/status] Self-healed user topup ${tx.id} — +${tx.amount} GNF credited.`);
        }

        return res.status(200).json({
          success: true, found: true, type: 'topup', status: 'completed',
          amount: tx.amount,
          message: 'Recharge confirmée. Votre portefeuille a été crédité.',
        });
      }

      if (lengoStatus === 'FAILED' || lengoStatus === 'CANCELLED') {
        // Mark as failed in DB for ledger hygiene
        await supabase.from('wallet_transactions')
          .update({ status: 'failed', description: `Recharge échouée (LengoPay: ${lengoStatus})` })
          .eq('id', tx.id)
          .eq('status', 'pending');

        return res.status(200).json({
          success: true, found: true, type: 'topup', status: 'failed',
          amount: tx.amount,
          message: 'Recharge échouée ou annulée par LengoPay.',
        });
      }

      // LengoPay not reachable or tx not found there yet — still pending
      return res.status(200).json({
        success: true, found: true, type: 'topup', status: 'pending',
        amount: tx.amount, updated_at: tx.updated_at,
        message: 'Recharge en attente de confirmation USSD. Validez sur votre téléphone.',
      });
    }

    // ── Order payment flow (read-only DB check) ──────────────────────────────
    let orderQuery = supabase
      .from('orders')
      .select('id, status, financial_status, tracking_number, total_amount, updated_at');

    if      (orderId.startsWith('ORD-')) orderQuery = orderQuery.eq('tracking_number', orderId);
    else if (orderId)                    orderQuery = (orderQuery as any).eq('id', orderId);
    else if (payId)                      orderQuery = orderQuery.eq('tracking_number', payId);

    const { data: orders, error: ordErr } = await orderQuery;
    if (ordErr) return res.status(500).json({ success: false, error: 'Erreur de base de données.' });

    const order = Array.isArray(orders) ? orders[0] : null;
    if (!order) return res.status(404).json({ success: false, found: false, status: 'not_found' });

    const clientStatus =
      order.financial_status === 'paid'      ||
      order.financial_status === 'processed' ||
      order.status           === 'accepted'  ||
      order.status           === 'confirmed' ||
      order.status           === 'delivered'  ? 'success'
    : order.status           === 'cancelled' ||
      order.financial_status === 'failed'    ||
      order.financial_status === 'refunded'   ? 'failure'
    : 'pending';

    return res.status(200).json({
      success: true, found: true, type: 'order',
      status: clientStatus, db_status: order.status,
      financial_status: order.financial_status,
      order_id: order.id, tracking_number: order.tracking_number,
      amount: order.total_amount, updated_at: order.updated_at,
      message:
        clientStatus === 'success' ? 'Paiement confirmé. Votre commande est en cours de préparation.'
      : clientStatus === 'failure' ? 'Paiement échoué ou annulé. Veuillez réessayer.'
      : 'Paiement en attente de confirmation USSD. Validez sur votre téléphone.',
    });

  } catch (err: any) {
    console.error('[payment/status] Unhandled exception:', err.message);
    return res.status(500).json({ success: false, error: 'Erreur interne. Veuillez réessayer.' });
  }
}
