import type { VercelRequest, VercelResponse } from '@vercel/node';
import { createClient } from '@supabase/supabase-js';
import { paymentMobileLimiter } from '../_lib/rateLimit';

// P-8 fix: lazy fail-fast factory instead of module-level createClient('', '').
// Module-level createClient with empty strings silently fails on all DB calls.
function getSupabase() {
  const url = process.env.VITE_SUPABASE_URL;
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY;
  if (!url || !key) {
    throw new Error('[mobile] VITE_SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY must be set.');
  }
  return createClient(url, key);
}

export default async function handler(req: VercelRequest, res: VercelResponse) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  // ── Rate limit: 10 mobile payment attempts per IP per 60 s ─────────────────
  const rl = paymentMobileLimiter.check(req);
  if (!rl.allowed) {
    res.setHeader('Retry-After', String(rl.retryAfterSeconds));
    res.setHeader('X-RateLimit-Limit', '10');
    res.setHeader('X-RateLimit-Remaining', '0');
    return res.status(429).json({ success: false, error: rl.message });
  }
  res.setHeader('X-RateLimit-Limit', '10');
  res.setHeader('X-RateLimit-Remaining', String(rl.remaining));
  // ─────────────────────────────────────────────────────────────────────────

  const { amount, orderId, phone, provider } = req.body;

  // --- INPUT VALIDATION ---
  // 1. Check for missing required fields
  if (!amount || !phone || !orderId || !provider) {
    return res.status(400).json({ 
      success: false, 
      error: "Paramètres manquants (amount, phone, orderId, provider)" 
    });
  }

  // 2. Validate Amount
  const numericAmount = Number(amount);
  if (isNaN(numericAmount) || numericAmount <= 0) {
    return res.status(400).json({ 
      success: false, 
      error: "Montant invalide (doit être un nombre positif)" 
    });
  }

  // 3. Validate Provider (Network)
  const allowedProviders = ['ORANGE', 'MTN', 'CELLCOM'];
  const network = String(provider).toUpperCase();
  if (!allowedProviders.includes(network)) {
    return res.status(400).json({ 
      success: false, 
      error: `Réseau non supporté (${provider}). Réseaux autorisés: ${allowedProviders.join(', ')}` 
    });
  }

  // 4. Validate and Sanitize Phone
  const sanitizedPhone = String(phone).replace(/\s/g, '').replace(/^\+224/, '').replace(/^224/, '');
  if (!/^\d{9}$/.test(sanitizedPhone)) {
    return res.status(400).json({ 
      success: false, 
      error: "Numéro de téléphone invalide (format attendu: 9 chiffres, ex: 620123456)" 
    });
  }

  const apiKey = process.env.LENGOPAY_API_KEY;
  const websiteId = process.env.LENGOPAY_MERCHANT_ID;
  let apiUrl = process.env.LENGOPAY_API_URL;
  if (!apiUrl || apiUrl.trim() === "" || apiUrl.includes("your-lengopay-api-url")) {
    apiUrl = "https://portal.lengopay.com/api/v1/payments";
  }
  apiUrl = apiUrl.trim();
  if (!apiUrl.startsWith("http://") && !apiUrl.startsWith("https://")) {
    apiUrl = "https://" + apiUrl;
  }

  // Normalize endpoint
  if (apiUrl.endsWith("/v1") || apiUrl.endsWith("/v1/")) {
     apiUrl = apiUrl.replace(/\/$/, "") + "/payments";
  }

  if (!apiKey || !websiteId || apiKey === "your-lengopay-secret-key" || apiKey === "your-lengopay-license-key") {
    console.error("[LengoPay Vercel] Configuration incomplete. Aborting.");
    return res.status(500).json({ 
      success: false, 
      error: "Configuration LengoPay incomplète (Vercel).",
      details: "LENGOPAY_API_KEY or LENGOPAY_MERCHANT_ID is missing or set to placeholder values."
    });
  }

  try {
    const trimmedKey = apiKey.trim();
    const trimmedWebsiteId = websiteId.trim();
    
    // Fallback logic for appUrl
    let host = req.headers.host;
    if (req.headers['x-forwarded-host']) {
      host = Array.isArray(req.headers['x-forwarded-host']) 
        ? req.headers['x-forwarded-host'][0] 
        : req.headers['x-forwarded-host'];
    }
    const protocol = req.headers['x-forwarded-proto'] || 'https';
    const appUrl = process.env.APP_URL || `${protocol}://${host}`;
    
    let authoritativeAmount = Math.round(Number(amount));
    if (orderId && String(orderId).startsWith('ORD-')) {
      try {
        const { data: ordersData, error: ordersError } = await getSupabase()
          .from('orders')
          .select('total_amount')
          .eq('tracking_number', String(orderId));
          
        if (ordersError) throw ordersError;
        if (!ordersData || ordersData.length === 0) {
          return res.status(404).json({ success: false, error: "Commande introuvable dans le système." });
        }
        const dbTotal = ordersData.reduce((sum, o) => sum + Number(o.total_amount || 0), 0);
        authoritativeAmount = Math.round(dbTotal);
      } catch (err) {
        console.error("Error fetching order amount:", err);
        return res.status(500).json({ success: false, error: "Erreur lors de la vérification de la commande." });
      }
    }

    const body = {
      websiteid: trimmedWebsiteId,
      amount: authoritativeAmount,
      currency: "GNF",
      country: "GN",
      phone: sanitizedPhone,
      network: network,
      order_id: String(orderId), 
      return_url: `${appUrl}/payment-result?orderId=${orderId}&status=success`,
      failure_url: `${appUrl}/payment-result?orderId=${orderId}&status=failure`,
      callback_url: `${appUrl}/api/webhook/gateway?order_id=${orderId}`,
      description: `Paiement #${orderId}`
    };

    let vpsProxyUrl = (process.env.VPS_PROXY_URL || '').trim();
    const vpsProxySecret = (process.env.VPS_PROXY_SECRET || '').trim();

    let fetchUrl = apiUrl;
    const fetchHeaders: any = {
      'Content-Type': 'application/json',
      'Accept': 'application/json',
      'Authorization': `Basic ${trimmedKey}`
    };

    const isUsingProxy = !!(vpsProxyUrl && vpsProxySecret && vpsProxyUrl !== "" && vpsProxySecret !== "");

    if (isUsingProxy) {
      if (!vpsProxyUrl.startsWith("http://") && !vpsProxyUrl.startsWith("https://")) {
         vpsProxyUrl = "http://" + vpsProxyUrl;
      }
      console.log(`[LengoPay Vercel] Routing request through VPS Proxy: ${vpsProxyUrl}`);
      fetchUrl = vpsProxyUrl;
      fetchHeaders['x-target-url'] = apiUrl;
      fetchHeaders['x-proxy-secret'] = vpsProxySecret;
    }

    // Ensure URL is valid before fetching
    try {
      new URL(fetchUrl);
    } catch(e) {
      console.error(`[LengoPay] Invalid API/Proxy URL: ${fetchUrl}`);
      return res.status(500).json({
        success: false,
        error: "Configuration URL invalide",
        details: `L'URL cible n'est pas valide: ${fetchUrl}`
      });
    }

    let response;
    try {
      response = await fetch(fetchUrl, {
        method: 'POST',
        headers: fetchHeaders,
        body: JSON.stringify(body)
      });
    } catch (fetchError: any) {
      if (isUsingProxy) {
        console.warn(`[LengoPay Vercel] Proxy request failed: ${fetchError.message}. Retrying directly to LengoPay...`);
        const directHeaders = {
          'Content-Type': 'application/json',
          'Accept': 'application/json',
          'Authorization': `Basic ${trimmedKey}`
        };
        response = await fetch(apiUrl, {
          method: 'POST',
          headers: directHeaders,
          body: JSON.stringify(body)
        });
      } else {
        throw fetchError;
      }
    }

    const contentType = response.headers.get('content-type');
    const text = await response.text();
    
    let result: any;
    if (contentType && contentType.includes('application/json')) {
      try {
        result = JSON.parse(text);
      } catch(e) {
        return res.status(502).json({
          success: false,
          error: "LengoPay returned malformed JSON",
          details: text.slice(0, 500)
        });
      }
    } else {
      let friendlyError = "LengoPay returned non-JSON response";
      if (response.status === 401 || text.includes("Unauthorized")) {
         friendlyError = "Invalid LengoPay Credentials or IP not whitelisted";
      }
      return res.status(response.status >= 400 ? response.status : 502).json({
        success: false,
        error: friendlyError,
        details: text.slice(0, 500)
      });
    }
    
    if (!response.ok) {
      console.error("LengoPay Error Response:", result);
      let friendlyError = result.message || result.error || "Gateway error";
      if (response.status === 401) {
         friendlyError = "Vérifiez vos clés LengoPay (ID Site et License Key) et la whitelist IP.";
      }
      
      return res.status(response.status).json({ 
        success: false, 
        error: friendlyError, 
        details: result 
      });
    }

    if (result.status === "Success" || result.payment_url) {
      res.status(200).json({
        success: true,
        payment_url: result.payment_url,
        pay_id: result.pay_id
      });
    } else {
      res.status(400).json({
        success: false,
        error: "Erreur LengoPay inattendue",
        details: result
      });
    }
  } catch (error: any) {
    console.error("[LengoPay] Exception:", error.message);
    if (error.cause) {
      console.error("[LengoPay] Exception Cause:", error.cause.message || error.cause);
    }
    res.status(500).json({ 
      success: false, 
      error: error.message,
      details: error.cause ? error.cause.message : undefined
    });
  }
}
