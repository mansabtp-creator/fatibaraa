import type { VercelRequest, VercelResponse } from '@vercel/node';
import { createClient } from '@supabase/supabase-js';

const supabase = createClient(
  process.env.VITE_SUPABASE_URL || '',
  process.env.SUPABASE_SERVICE_ROLE_KEY || ''
);

export default async function handler(req: VercelRequest, res: VercelResponse) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  const rawAction = req.query.action || req.url?.split('/').pop()?.split('?')[0];
  const action = Array.isArray(rawAction) ? rawAction[0] : rawAction;

  try {
    if (action === 'system-log') {
      const { component, status, details } = req.body || {};
      const { error } = await supabase.from('system_health_logs').insert({ 
        component, 
        status, 
        details 
      });

      if (error) {
        console.error("Failed to insert health log:", error);
        return res.status(500).json({ success: false, error: error.message });
      }
      return res.status(200).json({ success: true });
    }

    if (action === 'housekeeping-task') {
      const { task_name, status } = req.body || {};
      const { error } = await supabase.from('housekeeping_tasks').upsert({ 
        task_name, 
        status, 
        last_run: new Date().toISOString() 
      });

      if (error) {
        console.error("Failed to update housekeeping task:", error);
        return res.status(500).json({ success: false, error: error.message });
      }
      return res.status(200).json({ success: true });
    }

    return res.status(404).json({ error: `Unknown admin action: ${action}` });
  } catch (error: any) {
    console.error(`Admin action ${action} exception:`, error);
    return res.status(500).json({ success: false, error: error.message });
  }
}
