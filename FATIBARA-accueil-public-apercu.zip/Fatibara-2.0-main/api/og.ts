/**
 * api/og.ts — Vercel Edge Function: Social Media OG Tag Gateway
 *
 * Intercepts requests for /product/:id and /boutique/:slug.
 * - Real users → pass through to static index.html (SPA)
 * - Social crawlers (WhatsApp, Telegram, FB, etc.) → return minimal HTML with OG meta tags
 *   generated from live Supabase data.
 */

export const config = {
  runtime: 'edge',
};

// ─── Bot User-Agent signatures ────────────────────────────────────────────────
const BOT_USER_AGENTS = [
  'whatsapp',
  'facebookexternalhit',
  'facebot',
  'twitterbot',
  'telegrambot',
  'linkedinbot',
  'slackbot',
  'discordbot',
  'applebot',
  'googlebot',
  'bingbot',
  'ia_archiver',
  'pinterest',
];

// ─── Helpers ──────────────────────────────────────────────────────────────────

/** Escape HTML entities to prevent XSS in meta tag attributes */
function escapeHtml(str: string): string {
  return str
    .replace(/&/g, '&amp;')
    .replace(/"/g, '&quot;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');
}

/** Format a number as Guinean Franc currency string */
function formatGNF(amount: number): string {
  return new Intl.NumberFormat('fr-GN').format(amount) + ' GNF';
}

/** Build the minimal OG HTML response for a crawler */
function buildOGHtml(params: {
  title: string;
  description: string;
  imageUrl: string;
  pageUrl: string;
  type?: string;
  siteName?: string;
}): string {
  const {
    title,
    description,
    imageUrl,
    pageUrl,
    type = 'website',
    siteName = 'Fatibara',
  } = params;

  const t = escapeHtml(title);
  const d = escapeHtml(description);
  const img = escapeHtml(imageUrl);
  const url = escapeHtml(pageUrl);

  return `<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>${t}</title>
  <meta name="description" content="${d}" />

  <!-- Open Graph / Facebook / WhatsApp / Telegram -->
  <meta property="og:type" content="${type}" />
  <meta property="og:site_name" content="${siteName}" />
  <meta property="og:title" content="${t}" />
  <meta property="og:description" content="${d}" />
  <meta property="og:image" content="${img}" />
  <meta property="og:image:secure_url" content="${img}" />
  <meta property="og:image:width" content="1200" />
  <meta property="og:image:height" content="630" />
  <meta property="og:image:alt" content="${t}" />
  <meta property="og:url" content="${url}" />

  <!-- Twitter Card -->
  <meta name="twitter:card" content="summary_large_image" />
  <meta name="twitter:site" content="@fatibara" />
  <meta name="twitter:title" content="${t}" />
  <meta name="twitter:description" content="${d}" />
  <meta name="twitter:image" content="${img}" />

  <!-- Redirect real visitors who land here (e.g. via cached bot response) -->
  <noscript><meta http-equiv="refresh" content="0;url=${url}" /></noscript>
</head>
<body>
  <p><a href="${url}">${t}</a></p>
</body>
</html>`;
}

// ─── Edge Handler ─────────────────────────────────────────────────────────────
export default async function handler(req: Request): Promise<Response> {
  const userAgent = (req.headers.get('user-agent') || '').toLowerCase();
  const isBot = BOT_USER_AGENTS.some((bot) => userAgent.includes(bot));
  const url = new URL(req.url);
  const pathname = url.pathname;

  // ── Real user: pass straight through to the SPA ──────────────────────────
  if (!isBot) {
    // Vercel serves index.html for all SPA routes via the catch-all rewrite.
    // We just fetch it directly from the origin.
    return fetch(new URL('/index.html', req.url));
  }

  // ── Default OG values (fallback) ─────────────────────────────────────────
  const DEFAULT_IMAGE = 'https://fatibara.com/og-default.jpg';
  let title = 'Fatibara | Le Marché Local de Guinée';
  let description = 'Achetez et vendez facilement en Guinée sur Fatibara. Livraison rapide à Conakry et dans toutes les grandes villes.';
  let imageUrl = DEFAULT_IMAGE;
  let ogType: 'product' | 'website' = 'website';

  // ── Resolve Supabase credentials ─────────────────────────────────────────
  const supabaseUrl =
    (typeof process !== 'undefined' && process.env?.VITE_SUPABASE_URL) ||
    (typeof process !== 'undefined' && process.env?.NEXT_PUBLIC_SUPABASE_URL) || '';
  const supabaseKey =
    (typeof process !== 'undefined' && process.env?.VITE_SUPABASE_ANON_KEY) ||
    (typeof process !== 'undefined' && process.env?.NEXT_PUBLIC_SUPABASE_ANON_KEY) || '';

  try {
    // ── /product/:id ────────────────────────────────────────────────────────
    if (pathname.startsWith('/product/')) {
      const productId = pathname.split('/product/')[1]?.split(/[/?#]/)[0];

      if (productId && supabaseUrl && supabaseKey) {
        const res = await fetch(
          `${supabaseUrl}/rest/v1/products?id=eq.${encodeURIComponent(productId)}&select=title,price_gnf,image_urls,description,category`,
          {
            headers: {
              apikey: supabaseKey,
              Authorization: `Bearer ${supabaseKey}`,
              'Content-Type': 'application/json',
            },
          }
        );

        if (res.ok) {
          const data: any[] = await res.json();
          const product = data?.[0];
          if (product) {
            const formattedPrice = formatGNF(product.price_gnf || 0);
            title = `${product.title} — ${formattedPrice} | Fatibara`;
            description =
              product.description ||
              `Disponible sur Fatibara à ${formattedPrice}. Achetez ${product.title} en ligne en Guinée — livraison rapide à domicile.`;
            // image_urls is a JSON array; pick the first
            const rawImages = product.image_urls;
            const firstImage = Array.isArray(rawImages)
              ? rawImages[0]
              : typeof rawImages === 'string'
              ? JSON.parse(rawImages)[0]
              : null;
            if (firstImage) imageUrl = firstImage;
            ogType = 'product';
          }
        }
      }
    }

    // ── /boutique/:slug (store profile) ─────────────────────────────────────
    else if (pathname.startsWith('/boutique/')) {
      const rawSlug = pathname.split('/boutique/')[1]?.split(/[/?#]/)[0];
      const storeSlug = rawSlug ? decodeURIComponent(rawSlug) : null;

      if (storeSlug && supabaseUrl && supabaseKey) {
        const res = await fetch(
          `${supabaseUrl}/rest/v1/stores?store_name=ilike.${encodeURIComponent(storeSlug)}&select=store_name,description,avatar_url,is_verified_store,location_commune&limit=1`,
          {
            headers: {
              apikey: supabaseKey,
              Authorization: `Bearer ${supabaseKey}`,
              'Content-Type': 'application/json',
            },
          }
        );

        if (res.ok) {
          const data: any[] = await res.json();
          const store = data?.[0];
          if (store) {
            const verified = store.is_verified_store ? ' ✓ Boutique Vérifiée' : '';
            title = `${store.store_name}${verified} | Fatibara`;
            description =
              store.description ||
              `Découvrez la boutique ${store.store_name} sur Fatibara — la marketplace locale de Guinée. Produits de qualité, livraison à Conakry.`;
            if (store.avatar_url) imageUrl = store.avatar_url;
          }
        }
      }
    }
  } catch (err) {
    // Non-blocking: fall through to defaults
    console.error('[api/og] Metadata fetch error:', err);
  }

  const html = buildOGHtml({
    title,
    description,
    imageUrl,
    pageUrl: url.href,
    type: ogType,
  });

  return new Response(html, {
    status: 200,
    headers: {
      'Content-Type': 'text/html; charset=utf-8',
      // Cache for 1 hour on the edge (CDN), 24h in shared caches, 5 min in browsers.
      // This keeps OG data fresh without hammering Supabase.
      'Cache-Control': 'public, max-age=300, s-maxage=3600, stale-while-revalidate=86400',
      'X-OG-Handler': 'fatibara-edge',
    },
  });
}
