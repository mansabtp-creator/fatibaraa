import type { VercelRequest, VercelResponse } from '@vercel/node';
import { GoogleGenAI } from "@google/genai";

let aiClient: GoogleGenAI | null = null;
function getAiClient() {
  if (!aiClient) {
    aiClient = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });
  }
  return aiClient;
}

export default async function handler(req: VercelRequest, res: VercelResponse) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  const rawAction = req.query.action || req.url?.split('/').pop()?.split('?')[0];
  const action = Array.isArray(rawAction) ? rawAction[0] : rawAction;

  try {
    if (action === 'shoppingAdvice') {
      const { userPrompt, history = [], systemInstruction } = req.body || {};
      const response = await getAiClient().models.generateContent({
        model: "gemini-3.8-flash",
        contents: [
          ...(history.length > 0 ? history.map((h: any) => ({ role: h.role, parts: [{ text: h.text }] })) : []),
          { role: "user", parts: [{ text: userPrompt }] }
        ],
        config: { systemInstruction, temperature: 0.7 }
      });
      return res.status(200).json({ text: response.text });
    }

    // Default: generateContent
    const { contents, config, model } = req.body || {};
    const validModel = (!model || model.includes("gemini-2.") || model.includes("gemini-1.")) ? "gemini-3.8-flash" : model;
    const response = await getAiClient().models.generateContent({
      model: validModel,
      contents,
      config
    });
    return res.status(200).json({ text: response.text });
  } catch (e: any) {
    console.error(`AI ${action} Error:`, e);
    if (e.message && (e.message.toLowerCase().includes("suspended") || e.message.toLowerCase().includes("permission denied") || e.message.toLowerCase().includes("denied access") || e.message.includes("PERMISSION_DENIED"))) {
       return res.status(200).json({ text: "[System]: Your Gemini API Key has been suspended or denied access. Please check your environment variables to update it." });
    }
    return res.status(500).json({ error: e.message });
  }
}
