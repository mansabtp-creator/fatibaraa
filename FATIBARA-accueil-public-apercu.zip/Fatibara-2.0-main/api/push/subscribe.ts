/**
 * api/push/subscribe.ts
 *
 * Vercel serverless function: stores a Web Push subscription object in
 * the `push_subscriptions` table.
 *
 * Called by the frontend hook `usePushNotifications` after the browser
 * grants notification permission and returns a PushSubscription.
 *
 * POST /api/push/subscribe
 * Body: { endpoint, keys: { p256dh, auth }, userAgent? }
 * Auth: Bearer token in Authorization header (Supabase JWT)
 *
 * Required env vars:
 *   VITE_SUPABASE_URL
 *   SUPABASE_SERVICE_ROLE_KEY
 */

import type { VercelRequest, VercelResponse } from '@vercel/node';
import { createClient } from '@supabase/supabase-js';

function getSupabase() {
  const url = process.env.VITE_SUPABASE_URL!;
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY!;
  return createClient(url, key, { auth: { persistSession: false } });
}

export default async function handler(req: VercelRequest, res: VercelResponse) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  // ── Authenticate via Supabase JWT ─────────────────────────────────────────
  const authHeader = req.headers.authorization ?? '';
  const token = authHeader.startsWith('Bearer ') ? authHeader.slice(7) : null;
  if (!token) {
    return res.status(401).json({ error: 'Missing Authorization token' });
  }

  const supabase = getSupabase();
  const { data: { user }, error: authErr } = await supabase.auth.getUser(token);
  if (authErr || !user) {
    return res.status(401).json({ error: 'Invalid or expired token' });
  }

  // ── Parse body ────────────────────────────────────────────────────────────
  const body = typeof req.body === 'string' ? JSON.parse(req.body) : req.body;
  const { endpoint, keys, userAgent } = body ?? {};

  if (!endpoint || !keys?.p256dh || !keys?.auth) {
    return res.status(400).json({ error: 'endpoint, keys.p256dh and keys.auth are required' });
  }

  // ── Upsert subscription (handle re-subscribe on same device) ─────────────
  const { error } = await supabase
    .from('push_subscriptions')
    .upsert(
      {
        user_id:     user.id,
        endpoint,
        p256dh:      keys.p256dh,
        auth:        keys.auth,
        user_agent:  userAgent ?? null,
        is_active:   true,
        last_used_at: new Date().toISOString(),
      },
      { onConflict: 'user_id,endpoint' }
    );

  if (error) {
    console.error('[Push/Subscribe] DB error:', error.message);
    return res.status(500).json({ error: 'Failed to save subscription' });
  }

  console.log(`[Push/Subscribe] Subscription saved for user ${user.id.substring(0, 8)}`);
  return res.status(200).json({ ok: true });
}
