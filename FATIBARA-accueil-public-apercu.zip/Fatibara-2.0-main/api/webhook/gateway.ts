import type { VercelRequest, VercelResponse } from '@vercel/node';
import { createClient } from '@supabase/supabase-js';

// ─── Admin client (service role — bypasses RLS) ───────────────────────────────
function getAdminClient() {
  const url = process.env.VITE_SUPABASE_URL ?? process.env.SUPABASE_URL ?? '';
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY ?? '';
  if (!url || !key) {
    throw new Error(
      '[webhook/gateway] Missing env: VITE_SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY must both be set.'
    );
  }
  return createClient(url, key, {
    auth: { persistSession: false, autoRefreshToken: false },
  });
}

// ─── Handler ─────────────────────────────────────────────────────────────────
export default async function handler(req: VercelRequest, res: VercelResponse) {
  if (req.method !== 'POST') {
    return res.status(405).send('Method Not Allowed');
  }

  // ── Auth guard ──────────────────────────────────────────────────────────────
  // LengoPay does NOT send a signature header — their callback is a plain POST.
  // We validate authenticity by:
  //   1. Requiring pay_id to be present in the body (unauthenticated callers
  //      can't forge a valid pay_id that matches one of our wallet_transactions).
  //   2. Optionally matching LENGOPAY_WEBSITE_ID if set.
  //
  // The old x-lengopay-signature check was silently rejecting every real callback
  // because LengoPay never sends that header. This caused all top-ups to stay
  // permanently stuck at 'pending'.
  const rawBodyForAuth: Record<string, any> =
    typeof req.body === 'string' ? JSON.parse(req.body) : (req.body ?? {});
  const incomingPayId = String(rawBodyForAuth?.pay_id ?? '').trim();

  if (!incomingPayId) {
    console.warn('[webhook/gateway] Missing pay_id — rejecting request.');
    return res.status(200).json({ message: 'Missing pay_id' });
  }

  // Optional: if LENGOPAY_WEBSITE_ID is configured, reject payloads that carry
  // a different website id (defence against cross-merchant replay).
  const configuredSiteId = process.env.LENGOPAY_WEBSITE_ID?.trim();
  const incomingSiteId   = String(rawBodyForAuth?.websiteid ?? '').trim();
  if (configuredSiteId && incomingSiteId && incomingSiteId !== configuredSiteId) {
    console.warn('[webhook/gateway] websiteid mismatch — rejecting.', { incomingSiteId });
    return res.status(200).json({ message: 'Invalid websiteid' });
  }

  let supabaseAdmin: ReturnType<typeof getAdminClient>;
  try {
    supabaseAdmin = getAdminClient();
  } catch (configErr: any) {
    console.error('[webhook/gateway] Config error:', configErr.message);
    return res.status(500).json({ error: 'Server configuration error' });
  }

  try {
    // ── Parse payload ─────────────────────────────────────────────────────────
    const event: Record<string, any> =
      typeof req.body === 'string' ? JSON.parse(req.body) : (req.body ?? {});

    // ── Status normalisation ──────────────────────────────────────────────────
    const rawStatus = String(event?.status ?? '').toLowerCase();
    const isSuccess =
      rawStatus === 'success' ||
      rawStatus === 'paid'    ||
      String(event?.code ?? '') === '200';

    const isFailed =
      rawStatus === 'failed'    ||
      rawStatus === 'expired'   ||
      rawStatus === 'cancelled';

    const payId  = String(event?.pay_id ?? event?.payId ?? '').trim();
    const txIdFromQuery = String(req.query.tx_id ?? '').trim();

    // ── Reference ID resolution ───────────────────────────────────────────────
    const referenceId: string = (
      String(event?.reference_id             ?? '').trim() ||
      String(event?.order_id                 ?? '').trim() ||
      String(event?.custom_data?.reference_id ?? '').trim() ||
      String(req.query.order_id              ?? '').trim() ||
      payId
    );

    console.log(
      `[webhook/gateway] Received | status=${rawStatus} | isSuccess=${isSuccess} | referenceId=${referenceId || '(none)'} | tx_id=${txIdFromQuery || '(none)'} | pay_id=${payId}`
    );

    if (!referenceId && !txIdFromQuery) {
      console.warn('[webhook/gateway] No reference ID or tx_id — acknowledged.');
      return res.status(200).json({ message: 'No reference_id — acknowledged' });
    }

    // ── Wallet top-up path (TOPUP- prefix OR direct tx_id lookup) ────────────
    if (referenceId.startsWith('TOPUP-') || (!referenceId && txIdFromQuery)) {

      type TxRow = { id: string; status: string; amount: number; profile_id: string; store_id: string | null };
      let tx: TxRow | null = null;
      let fetchErr: any    = null;

      // Primary: reference_text (migration-patched rows)
      const { data: txByText, error: errByText } = await supabaseAdmin
        .from('wallet_transactions')
        .select('id, status, amount, profile_id, store_id')
        .eq('reference_text', referenceId)
        .maybeSingle();

      if (errByText) fetchErr = errByText;
      else tx = txByText as TxRow | null;

      // Fallback 1: reference_id TEXT cast (legacy rows)
      if (!tx && !fetchErr) {
        const { data: txByRef, error: errByRef } = await supabaseAdmin
          .from('wallet_transactions')
          .select('id, status, amount, profile_id, store_id')
          .eq('reference_id', referenceId)
          .maybeSingle();
        if (errByRef) fetchErr = errByRef;
        else tx = txByRef as TxRow | null;
      }

      // Fallback 2: direct UUID lookup via tx_id query param
      if (!tx && !fetchErr && txIdFromQuery) {
        const { data: txById, error: errById } = await supabaseAdmin
          .from('wallet_transactions')
          .select('id, status, amount, profile_id, store_id')
          .eq('id', txIdFromQuery)
          .maybeSingle();
        if (errById) fetchErr = errById;
        else tx = txById as TxRow | null;
      }

      if (fetchErr) {
        console.error('[webhook/gateway] DB fetch error:', fetchErr.message);
        return res.status(500).json({ error: 'Database error' });
      }

      if (!tx) {
        console.warn(`[webhook/gateway] No wallet_transaction found for reference=${referenceId}`);
        return res.status(200).json({ message: 'Transaction not found — acknowledged' });
      }

      // ── Idempotency guard: already processed → skip ───────────────────────
      if (tx.status === 'completed' || tx.status === 'failed') {
        console.info(`[webhook/gateway] Transaction ${tx.id} already ${tx.status} — skipping.`);
        return res.status(200).json({ message: `Transaction already ${tx.status}` });
      }

      // ── Handle failed / expired top-ups ──────────────────────────────────
      if (isFailed) {
        await supabaseAdmin
          .from('wallet_transactions')
          .update({ status: 'failed', updated_at: new Date().toISOString() })
          .eq('id', tx.id)
          .eq('status', 'pending');

        console.info(`[webhook/gateway] Topup marked failed | tx=${tx.id}`);
        return res.status(200).json({ message: `Event ${rawStatus} acknowledged` });
      }

      if (!isSuccess) {
        console.log(`[webhook/gateway] Unhandled status "${rawStatus}" — acknowledged.`);
        return res.status(200).json({ message: `Event ${rawStatus} acknowledged` });
      }

      // ── Route credit to the correct bucket ───────────────────────────────────────
      if (tx.store_id) {
        // ── Vendor store top-up: credit stores.balance directly ─────────────────
        // 1. Mark tx completed (CAS guard against double-credit on webhook retry)
        const { error: casErr } = await supabaseAdmin
          .from('wallet_transactions')
          .update({
            status: 'completed',
            pay_id: payId || null,
            description: 'Recharge Mobile Money via LengoPay — Boutique (Crédité)',
            updated_at: new Date().toISOString()
          })
          .eq('id', tx.id)
          .eq('status', 'pending');

        if (casErr) {
          console.error(`[webhook/gateway] CAS update failed for tx ${tx.id}:`, casErr.message);
          return res.status(500).json({ error: 'Credit failed — will retry' });
        }

        // 2. Credit the store balance
        const { error: storeErr } = await supabaseAdmin.rpc('increment_store_balance', {
          p_store_id: tx.store_id,
          p_amount:   tx.amount,
        });

        if (storeErr) {
          // Rollback CAS — revert to pending so next retry can try again
          await supabaseAdmin
            .from('wallet_transactions')
            .update({ status: 'pending' })
            .eq('id', tx.id);
          console.error(`[webhook/gateway] increment_store_balance failed for store ${tx.store_id}:`, storeErr.message);
          return res.status(500).json({ error: 'Store credit failed — will retry' });
        }

        console.info(`[webhook/gateway] ✓ Store wallet credited | store=${tx.store_id} | user=${tx.profile_id} | amount=${tx.amount} | tx=${tx.id}`);
      } else {
        // ── Personal wallet top-up (courier/customer) ───────────────────────
        // Atomic credit via credit_user_wallet SECURITY DEFINER RPC:
        //   1. CAS wallet_transactions pending→completed  ← double-credit guard
        //   2. Increments profiles.wallet_balance
        //   3. Syncs courier_profiles.balance (now also covered by DB trigger)
        const { error: rpcErr } = await supabaseAdmin.rpc('credit_user_wallet', {
          p_user_id: tx.profile_id,
          p_amount:  tx.amount,
          p_tx_id:   tx.id,
          p_pay_id:  payId || null,
        });

        if (rpcErr) {
          console.error(`[webhook/gateway] credit_user_wallet RPC failed for tx ${tx.id}:`, rpcErr.message);
          return res.status(500).json({ error: 'Credit failed — will retry' });
        }
        console.info(`[webhook/gateway] ✓ Wallet credited | user=${tx.profile_id} | amount=${tx.amount} | tx=${tx.id}`);
      }

      // Non-blocking in-app notification
      void supabaseAdmin.from('notifications').insert({
        user_id: tx.profile_id,
        type:    'payment',
        title:   'Recharge confirmée ✅',
        message: `Votre portefeuille a été crédité de ${Number(tx.amount).toLocaleString('fr-GN')} GNF.`,
        is_read: false,
      }).then(({ error: notifErr }) => {
        if (notifErr) console.warn('[webhook/gateway] Notification failed:', notifErr.message);
      });

      return res.status(200).json({ message: 'Wallet top-up processed' });
    }

    // ── Order payment path ────────────────────────────────────────────────────
    // P-3 fix: Call secure_process_order_financials after marking paid.
    // P-4 fix: Guard against duplicate webhooks with financial_status check.
    if (referenceId) {
      const { data: ords, error: ordErr } = await supabaseAdmin
        .from('orders')
        .select('id, status, financial_status')
        .eq('tracking_number', referenceId);

      if (ordErr) {
        console.error('[webhook/gateway] Order lookup error:', ordErr.message);
        return res.status(500).json({ error: 'Database error' });
      }

      if (ords && ords.length > 0) {
        for (const ord of ords) {
          if (isSuccess) {
            // Idempotency: skip already-paid or fully processed orders
            if (ord.financial_status === 'paid' || ord.financial_status === 'processed') {
              console.info(`[webhook/gateway] Order ${ord.id} already ${ord.financial_status} — skipping.`);
              continue;
            }

            // NOTE: financial_status='processing' does NOT exist in the DB CHECK constraint.
            // Valid values: pending → paid → processed | failed | refunded.
            // This was silently dropping all mobile payment webhooks with a 400.
            const { error: updateErr } = await supabaseAdmin
              .from('orders')
              .update({
                status:           'accepted',   // vendor can now see and prepare
                financial_status: 'paid',       // correct post-payment state
                updated_at:       new Date().toISOString(),
              })
              .eq('id', ord.id)
              .neq('financial_status', 'paid'); // atomic guard against double-write

            if (updateErr) {
              console.error(`[webhook/gateway] Order update failed for ${ord.id}:`, updateErr.message);
              continue;
            }

            // P-3: Trigger vendor/courier financial settlement atomically
            const { error: finErr } = await supabaseAdmin.rpc('secure_process_order_financials', {
              p_order_id: ord.id,
            });

            if (finErr) {
              console.error(`[webhook/gateway] Financial RPC failed for order ${ord.id}:`, finErr.message);
              // Order is paid; financials can be manually reconciled if needed
            } else {
              console.info(`[webhook/gateway] ✓ Order ${ord.id} paid + financials settled.`);
            }

          } else if (isFailed) {
            const { error: cancelErr } = await supabaseAdmin.rpc('cancel_unpaid_mobile_order', {
              p_order_id: ord.id,
              p_reason: `Paiement ${rawStatus.toLowerCase()}`,
            });
            if (cancelErr) {
              console.error(`[webhook/gateway] Failed to cancel unpaid order ${ord.id}:`, cancelErr.message);
              continue;
            }
            console.info(`[webhook/gateway] Order ${ord.id} → ${rawStatus}`);
          }
        }
      } else {
        console.warn(`[webhook/gateway] No orders found for tracking_number=${referenceId}`);
      }
    }

    return res.status(200).json({ message: 'Webhook processed' });

  } catch (err: any) {
    console.error('[webhook/gateway] Unhandled exception:', {
      name:    err.name    ?? 'Error',
      message: err.message ?? String(err),
      stack:   process.env.NODE_ENV !== 'production' ? err.stack : undefined,
    });
    return res.status(500).json({ error: 'Internal server error' });
  }
}
