/**
 * api/courier/complete-delivery.ts
 *
 * Vercel serverless function: atomically finalizes courier delivery.
 * 1. Verifies caller JWT and ensures caller is the assigned courier (or admin)
 * 2. Compares OTP with order's delivery_otp server-side
 * 3. Calculates 80% courier delivery earnings and settles COD/cash collections
 * 4. Credits courier wallet and updates active_capacity
 * 5. Updates order status to 'delivered' and completed_at
 * 6. Triggers vendor financial settlement if not already processed
 *
 * POST /api/courier/complete-delivery
 * Body: { orderId: string, otp?: string }
 * Auth: Bearer token (Supabase JWT)
 */

import type { VercelRequest, VercelResponse } from '@vercel/node';
import { createClient } from '@supabase/supabase-js';

function getSupabase() {
  const url = process.env.VITE_SUPABASE_URL!;
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY!;
  return createClient(url, key, { auth: { persistSession: false } });
}

export default async function handler(req: VercelRequest, res: VercelResponse) {
  if (req.method !== 'POST') {
    return res.status(405).json({ success: false, error: 'Méthode non autorisée' });
  }

  // 1. Authenticate courier
  const authHeader = req.headers.authorization ?? '';
  const token = authHeader.startsWith('Bearer ') ? authHeader.slice(7) : null;
  if (!token) {
    return res.status(401).json({ success: false, error: 'Token d\'authentification requis.' });
  }

  const supabase = getSupabase();
  const { data: { user }, error: authErr } = await supabase.auth.getUser(token);
  if (authErr || !user) {
    return res.status(401).json({ success: false, error: 'Session expirée ou invalide.' });
  }

  const { orderId, otp } = req.body ?? {};
  if (!orderId) {
    return res.status(400).json({ success: false, error: 'Identifiant de commande manquant.' });
  }

  try {
    // 2. Fetch order
    const { data: order, error: orderErr } = await supabase
      .from('orders')
      .select('*')
      .eq('id', orderId)
      .single();

    if (orderErr || !order) {
      return res.status(404).json({ success: false, error: 'Commande introuvable.' });
    }

    // 3. Authorization check
    const { data: callerProfile } = await supabase
      .from('profiles')
      .select('id, profile_type, is_admin')
      .eq('id', user.id)
      .single();

    const isAdmin = callerProfile?.is_admin === true || callerProfile?.profile_type === 'admin';
    if (order.courier_id !== user.id && !isAdmin) {
      return res.status(403).json({
        success: false,
        error: "Non autorisé : vous n'êtes pas le livreur assigné à cette commande.",
      });
    }

    // 4. Terminal state check
    if (order.status === 'delivered') {
      return res.status(400).json({ success: false, error: 'Cette commande a déjà été livrée.' });
    }
    if (order.status === 'cancelled') {
      return res.status(400).json({ success: false, error: 'Cette commande a été annulée.' });
    }

    // 5. OTP verification
    if (order.delivery_otp && String(order.delivery_otp).trim() !== '') {
      const cleanExpected = String(order.delivery_otp).trim();
      const cleanProvided = String(otp || '').trim();
      if (cleanExpected !== cleanProvided) {
        return res.status(400).json({
          success: false,
          error: 'Code OTP incorrect. Veuillez vérifier avec le client et réessayer.',
        });
      }
    }

    // 6. Courier Payout Math
    const deliveryFee = Number(order.delivery_fee || order.vendor_delivery_fee || 0);
    let courierPayout = Math.round(deliveryFee * 0.8);

    const paymentMethod =
      order.shipping_address?.payment_method ||
      (order.financial_status === 'paid' || order.financial_status === 'processed' ? 'wallet' : 'cash');
    const isCash = paymentMethod === 'cash';

    if (isCash) {
      courierPayout = courierPayout - Number(order.total_amount || 0);
    }

    // 7. Courier Credit & Ledger
    const courierUserId = order.courier_id || user.id;
    if (courierPayout > 0) {
      const { error: incErr } = await supabase.rpc('increment_wallet_balance', {
        user_id: courierUserId,
        amount: courierPayout,
      });

      if (incErr) {
        const { data: p } = await supabase
          .from('profiles')
          .select('wallet_balance')
          .eq('id', courierUserId)
          .single();
        await supabase
          .from('profiles')
          .update({
            wallet_balance: (Number(p?.wallet_balance) || 0) + courierPayout,
            updated_at: new Date().toISOString(),
          })
          .eq('id', courierUserId);
      }

      const { data: cProf } = await supabase
        .from('courier_profiles')
        .select('balance')
        .eq('user_id', courierUserId)
        .maybeSingle();

      if (cProf) {
        await supabase
          .from('courier_profiles')
          .update({
            balance: (Number(cProf.balance) || 0) + courierPayout,
            updated_at: new Date().toISOString(),
          })
          .eq('user_id', courierUserId);
      }

      await supabase.from('wallet_transactions').insert({
        profile_id: courierUserId,
        amount: courierPayout,
        type: 'delivery_fee',
        reference_id: order.id,
        description: `Course livrée #${order.id.slice(0, 8).toUpperCase()}`,
        status: 'completed',
      });
    }

    // 8. Decrement courier active capacity
    const { data: cProfCap } = await supabase
      .from('courier_profiles')
      .select('active_capacity')
      .eq('user_id', courierUserId)
      .maybeSingle();

    if (cProfCap && (cProfCap.active_capacity || 0) > 0) {
      await supabase
        .from('courier_profiles')
        .update({
          active_capacity: Math.max(0, cProfCap.active_capacity - 1),
          updated_at: new Date().toISOString(),
        })
        .eq('user_id', courierUserId);
    }

    // 9. Update order to delivered
    const { error: updateOrderErr } = await supabase
      .from('orders')
      .update({
        status: 'delivered',
        financial_status: 'processed',
        completed_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      })
      .eq('id', order.id);

    if (updateOrderErr) {
      return res.status(500).json({ success: false, error: updateOrderErr.message });
    }

    // 10. Vendor Settlement
    const { data: existingSales } = await supabase
      .from('wallet_transactions')
      .select('id')
      .eq('reference_id', order.id)
      .eq('type', 'sale')
      .limit(1);

    if (!existingSales || existingSales.length === 0) {
      try {
        await supabase.rpc('secure_process_order_financials', { p_order_id: order.id });
      } catch (e: any) {
        console.warn('[CompleteDelivery Serverless] Vendor settlement warning:', e.message);
      }
    }

    // 11. Notifications
    try {
      if (order.user_id) {
        await supabase
          .from('notifications')
          .insert({
            user_id: order.user_id,
            type: 'order',
            title: 'Commande livrée 🎉',
            message: `Votre commande #${order.id.slice(0, 8).toUpperCase()} a été livrée avec succès !`,
            is_read: false,
          });
      }

      if (order.vendor_id) {
        await supabase
          .from('notifications')
          .insert({
            user_id: order.vendor_id,
            type: 'order',
            title: 'Livraison effectuée ✅',
            message: `La commande #${order.id.slice(0, 8).toUpperCase()} a été livrée par le coursier.`,
            is_read: false,
          });
      }
    } catch (notifErr: any) {
      console.warn('[CompleteDelivery Serverless] Notification error (non-fatal):', notifErr.message);
    }

    return res.status(200).json({
      success: true,
      courier_payout: courierPayout,
      message: 'Livraison finalisée avec succès.',
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message || 'Erreur interne de livraison.' });
  }
}
