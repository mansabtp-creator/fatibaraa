/**
 * api/health.ts
 *
 * Comprehensive health check endpoint for Vercel deployment validation.
 *
 * GET /api/health
 *
 * Returns:
 *   200 { status: "ok", checks: { ... } }      — all checks pass
 *   503 { status: "degraded", checks: { ... } } — one or more checks fail
 *
 * Checks performed:
 *   - env: Required environment variables are set
 *   - db:  Supabase DB reachable (SELECT 1 query)
 *   - vapid: VAPID keys configured for Web Push
 *   - resend: Resend API key configured for emails
 *
 * Used by:
 *   - Vercel deployment health check (Phase 4 launch checklist)
 *   - Uptime monitoring (e.g. UptimeRobot pointing at /api/health)
 */

import type { VercelRequest, VercelResponse } from '@vercel/node';
import { createClient } from '@supabase/supabase-js';

interface CheckResult {
  ok:      boolean;
  message: string;
  latency?: number;
}

interface HealthReport {
  status:    'ok' | 'degraded';
  timestamp: string;
  version:   string;
  checks: {
    env:    CheckResult;
    db:     CheckResult;
    vapid:  CheckResult;
    resend: CheckResult;
  };
}

// ─── Individual checks ────────────────────────────────────────────────────────

function checkEnv(): CheckResult {
  // Always-required vars
  const always = [
    'VITE_SUPABASE_URL',
    'VITE_SUPABASE_ANON_KEY',
    'SUPABASE_SERVICE_ROLE_KEY',
  ];
  const missingAlways = always.filter(k => !process.env[k]);

  // LengoPay accepts EITHER naming convention:
  //   Canonical  (server.ts)  : LENGOPAY_SECRET_KEY  + LENGOPAY_WEBSITE_ID
  //   Vercel api/ aliases     : LENGOPAY_API_KEY     + LENGOPAY_MERCHANT_ID
  const hasCanonical = !!(process.env.LENGOPAY_SECRET_KEY && process.env.LENGOPAY_WEBSITE_ID);
  const hasAliases   = !!(process.env.LENGOPAY_API_KEY    && process.env.LENGOPAY_MERCHANT_ID);
  const lengoOk      = hasCanonical || hasAliases;

  if (missingAlways.length > 0 || !lengoOk) {
    const missing = [
      ...missingAlways,
      ...(!lengoOk ? ['LENGOPAY_SECRET_KEY+LENGOPAY_WEBSITE_ID (or LENGOPAY_API_KEY+LENGOPAY_MERCHANT_ID)'] : []),
    ];
    return { ok: false, message: `Missing required env vars: ${missing.join(', ')}` };
  }

  const lengoScheme = hasCanonical ? 'canonical (server.ts)' : 'Vercel api/ aliases';
  return { ok: true, message: `All required env vars set — LengoPay using ${lengoScheme} naming` };
}

async function checkDb(): Promise<CheckResult> {
  const url = process.env.VITE_SUPABASE_URL;
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY;
  if (!url || !key) {
    return { ok: false, message: 'Supabase credentials not configured' };
  }
  const t0 = Date.now();
  try {
    const supabase = createClient(url, key, { auth: { persistSession: false } });
    // Lightweight probe — just fetch a single profile row
    const { error } = await supabase
      .from('platform_settings')
      .select('id')
      .limit(1)
      .maybeSingle();
    const latency = Date.now() - t0;
    if (error) {
      return { ok: false, message: `DB error: ${error.message}`, latency };
    }
    return { ok: true, message: 'Supabase DB reachable', latency };
  } catch (err: any) {
    return { ok: false, message: `DB unreachable: ${err.message}`, latency: Date.now() - t0 };
  }
}

function checkVapid(): CheckResult {
  const pub  = process.env.VAPID_PUBLIC_KEY;
  const priv = process.env.VAPID_PRIVATE_KEY;
  if (!pub || !priv) {
    return {
      ok:      false,
      message: 'VAPID keys not set — Web Push notifications will not work. Run: npx web-push generate-vapid-keys',
    };
  }
  // Basic length sanity check for base64url keys
  if (pub.length < 80 || priv.length < 40) {
    return { ok: false, message: 'VAPID keys appear malformed (wrong length)' };
  }
  return { ok: true, message: 'VAPID keys configured' };
}

function checkResend(): CheckResult {
  const key = process.env.RESEND_API_KEY;
  if (!key) {
    return {
      ok:      false,
      message: 'RESEND_API_KEY not set — order confirmation emails will be skipped',
    };
  }
  if (!key.startsWith('re_')) {
    return { ok: false, message: 'RESEND_API_KEY looks invalid (should start with re_)' };
  }
  return { ok: true, message: 'Resend API key configured' };
}

// ─── Handler ─────────────────────────────────────────────────────────────────

export default async function handler(_req: VercelRequest, res: VercelResponse) {
  const [dbResult] = await Promise.all([checkDb()]);

  const checks = {
    env:    checkEnv(),
    db:     dbResult,
    vapid:  checkVapid(),
    resend: checkResend(),
  };

  // Overall status: degraded if any CRITICAL check fails (env or db)
  const criticalOk = checks.env.ok && checks.db.ok;
  const status: 'ok' | 'degraded' = criticalOk ? 'ok' : 'degraded';

  const report: HealthReport = {
    status,
    timestamp: new Date().toISOString(),
    version:   process.env.VERCEL_GIT_COMMIT_SHA?.substring(0, 7) ?? 'local',
    checks,
  };

  return res.status(criticalOk ? 200 : 503).json(report);
}
