import type { VercelRequest, VercelResponse } from '@vercel/node';
import { createClient } from '@supabase/supabase-js';

// ─── Supabase service-role client (bypasses RLS) ────────────────────────────
function getSupabase() {
  const url = process.env.VITE_SUPABASE_URL;
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY;
  if (!url || !key) {
    throw new Error('[Config] VITE_SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY must be set.');
  }
  return createClient(url, key);
}

// ─── Guinean mobile prefix detection ─────────────────────────────────────────
function detectNetwork(phone: string): 'ORANGE' | 'MTN' | null {
  const local = phone.replace(/\D/g, '').replace(/^224/, '');
  if (!/^\d{9}$/.test(local)) return null;
  const p3 = parseInt(local.slice(0, 3), 10);
  if (p3 >= 610 && p3 <= 619) return 'ORANGE';
  if (p3 >= 620 && p3 <= 629) return 'ORANGE';
  if (p3 >= 650 && p3 <= 659) return 'MTN';
  if (p3 >= 660 && p3 <= 669) return 'MTN';
  return null;
}

// ─── Handler ─────────────────────────────────────────────────────────────────
export default async function handler(req: VercelRequest, res: VercelResponse) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  // ── Config guard ────────────────────────────────────────────────────────────
  // ── Env var names match .env.example: LENGOPAY_SECRET_KEY / LENGOPAY_WEBSITE_ID
  const secretKey = (process.env.LENGOPAY_SECRET_KEY ?? process.env.LENGOPAY_API_KEY ?? '').trim();
  const websiteId = (process.env.LENGOPAY_WEBSITE_ID ?? process.env.LENGOPAY_MERCHANT_ID ?? '').trim();
  const apiUrl = (
    process.env.LENGOPAY_API_URL?.trim() || 'https://portal.lengopay.com/api/v1/payments'
  );

  if (!secretKey || !websiteId) {
    console.error('[payin] LengoPay credentials not configured. Set LENGOPAY_SECRET_KEY and LENGOPAY_WEBSITE_ID in Vercel env vars.');
    return res.status(503).json({
      success: false,
      error: 'Configuration LengoPay incomplète. Contactez le support.',
      details: 'LENGOPAY_SECRET_KEY or LENGOPAY_WEBSITE_ID is missing.',
    });
  }

  // ── Input validation ────────────────────────────────────────────────────────
  if (!req.body || typeof req.body !== 'object') {
    return res.status(400).json({ success: false, error: 'Corps de requête invalide.' });
  }

  const { amount, phone_number, provider, user_id, entity_type, entity_id } = req.body as {
    amount: unknown;
    phone_number: unknown;
    provider: unknown;
    user_id: unknown;
    entity_type?: string;  // 'vendor' | 'courier' | 'user'
    entity_id?: string;    // store_id when vendor, profile_id otherwise
  };

  if (!amount || !phone_number || !provider || !user_id) {
    return res.status(400).json({
      success: false,
      error: 'Paramètres manquants : amount, phone_number, provider et user_id sont requis.',
    });
  }

  const numericAmount = Number(amount);
  if (isNaN(numericAmount) || numericAmount < 1000) {
    return res.status(400).json({
      success: false,
      error: 'Le montant minimum de recharge est de 1 000 GNF.',
    });
  }

  const ALLOWED_PROVIDERS = ['ORANGE', 'MTN'] as const;
  const network = String(provider).toUpperCase() as 'ORANGE' | 'MTN';
  if (!ALLOWED_PROVIDERS.includes(network)) {
    return res.status(400).json({
      success: false,
      error: `Réseau non supporté: ${provider}. Réseaux autorisés: ORANGE, MTN.`,
    });
  }

  // Sanitize phone: strip spaces, +224 or 224 prefix → 9-digit local number
  const sanitizedPhone = String(phone_number)
    .replace(/\s/g, '')
    .replace(/^\+224/, '')
    .replace(/^224/, '');

  if (!/^\d{9}$/.test(sanitizedPhone)) {
    return res.status(400).json({
      success: false,
      error: 'Numéro de téléphone invalide (9 chiffres requis, ex: 620123456).',
    });
  }

  // Cross-check: detected network must match the stated provider
  const detectedNetwork = detectNetwork(sanitizedPhone);
  if (detectedNetwork && detectedNetwork !== network) {
    return res.status(400).json({
      success: false,
      error: `Le numéro ${sanitizedPhone} appartient au réseau ${detectedNetwork}, pas ${network}.`,
    });
  }

  const userId     = String(user_id);
  // Determine if this is a vendor store top-up (credits stores.balance)
  // or a personal wallet top-up (credits profiles.wallet_balance).
  const isVendor   = String(entity_type ?? '').toLowerCase() === 'vendor';
  const entityId   = entity_id ? String(entity_id) : userId;

  // ── Single outer try/catch covers ALL I/O: Supabase init, profile lookup,
  // tx insert, and LengoPay fetch. Any unhandled throw (including network-level
  // Supabase failures that don't surface as { error } objects) is caught here
  // and returned as a structured JSON response — never a blank Vercel 500.
  let transactionId: string | null = null;
  let supabase: ReturnType<typeof getSupabase> | null = null;

  try {
    // ── Supabase init ────────────────────────────────────────────────────────────
    try {
      supabase = getSupabase();
    } catch (configErr: any) {
      console.error('[payin] Supabase config error:', configErr.message);
      return res.status(503).json({
        success: false,
        error: 'Configuration base de données incomplète.',
        details: configErr.message,
      });
    }

    // ── Verify user exists (with graceful fallback if store_id was passed as user_id) ──
    let actualUserId = userId;
    let storeId: string | null = null;
    let profile: any = null;

    const { data: directProfile, error: profileErr } = await supabase
      .from('profiles')
      .select('id, wallet_balance')
      .eq('id', userId)
      .maybeSingle();

    if (profileErr) {
      console.error('[payin] Profile lookup error:', profileErr.message);
      return res.status(500).json({ success: false, error: 'Erreur serveur lors de la vérification du compte.', details: profileErr.message });
    }

    if (directProfile) {
      profile = directProfile;
    } else {
      // Fallback: Check if userId was sent as a store_id
      const { data: storeFallback } = await supabase
        .from('stores')
        .select('id, owner_id')
        .eq('id', userId)
        .maybeSingle();

      if (storeFallback && storeFallback.owner_id) {
        actualUserId = storeFallback.owner_id;
        storeId = storeFallback.id;
        const { data: ownerProfile } = await supabase
          .from('profiles')
          .select('id, wallet_balance')
          .eq('id', actualUserId)
          .maybeSingle();
        if (ownerProfile) {
          profile = ownerProfile;
        }
      }
    }

    if (!profile) {
      return res.status(404).json({ success: false, error: 'Compte utilisateur introuvable.' });
    }

    // ── For vendor top-ups: validate the store exists and belongs to this user ──
    if (isVendor && !storeId && entityId) {
      const targetStoreId = entityId !== actualUserId ? entityId : null;
      if (targetStoreId) {
        const { data: store, error: storeErr } = await supabase
          .from('stores')
          .select('id')
          .eq('id', targetStoreId)
          .eq('owner_id', actualUserId)
          .maybeSingle();
        if (storeErr || !store) {
          return res.status(403).json({
            success: false,
            error: 'Boutique introuvable ou non autorisée.',
          });
        }
        storeId = store.id;
      }
    }

    // ── Create pending wallet_transaction ──────────────────────────────────────────
    // Format: TOPUP-<userId>_<entityType>_<amount>_<timestamp>
    // The gateway detects the TOPUP- prefix to route this as a wallet top-up.
    // The _VENDOR_ / _USER_ tag tells the gateway which bucket to credit.
    const entityTag = isVendor && storeId ? `VENDOR_${storeId}` : 'USER';
    const orderId = `TOPUP-${actualUserId}_${entityTag}_${Math.round(numericAmount)}_${Date.now()}`;

    const { data: txRow, error: txErr } = await supabase
      .from('wallet_transactions')
      .insert({
        profile_id:     actualUserId,
        // Store store_id when it's a vendor top-up so the ledger is queryable by store.
        store_id:       storeId ?? null,
        amount:         Math.round(numericAmount),
        type:           'deposit',
        status:         'pending',
        description:    `Recharge Mobile Money (${network}) via LengoPay${
          isVendor ? ' — Boutique' : ''
        }`,
        // reference_text is the canonical TEXT lookup key used by the webhook
        // gateway (api/webhook/gateway.ts). reference_id is typed UUID and
        // cannot store the TOPUP- prefixed string.
        reference_text: orderId,
      })
      .select('id')
      .single();

    if (txErr || !txRow) {
      console.error('[payin] wallet_transactions insert failed:', txErr?.message);
      return res.status(500).json({
        success: false,
        error: 'Impossible de créer la transaction en attente. Veuillez réessayer.',
        details: txErr?.message,
      });
    }

    transactionId = txRow.id;

    // ── Build LengoPay payload ────────────────────────────────────────────────
    let host = req.headers['x-forwarded-host'] ?? req.headers.host ?? '';
    if (Array.isArray(host)) host = host[0];
    const protocol = req.headers['x-forwarded-proto'] ?? 'https';
    const appUrl = (process.env.APP_URL ?? `${protocol}://${host}`).replace(/\/$/, '');

    const lengoPayload = {
      websiteid: websiteId,
      amount: Math.round(numericAmount),
      currency: 'GNF',
      country: 'GN',
      phone: sanitizedPhone,
      network,
      order_id: orderId,
      return_url: `${appUrl}/dashboard?tab=wallet&status=success`,
      failure_url: `${appUrl}/dashboard?tab=wallet&status=failure`,
      callback_url: `${appUrl}/api/webhook/gateway?tx_id=${transactionId}`,
      description: `Recharge portefeuille Fatibara — ${network}`,
    };

    console.log(
      `[payin] → LengoPay | user: ${userId.slice(0, 8)} | amount: ${numericAmount} GNF | network: ${network} | orderId: ${orderId}`
    );

    // ── Fire LengoPay USSD Flash Push ─────────────────────────────────────────
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 30_000);

    let lengoRes: Response;
    try {
      lengoRes = await fetch(apiUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Accept: 'application/json',
          Authorization: `Basic ${secretKey}`,
        },
        body: JSON.stringify(lengoPayload),
        signal: controller.signal,
      });
    } finally {
      clearTimeout(timeoutId);
    }

    const responseText = await lengoRes.text();
    console.log(`[payin] LengoPay responded ${lengoRes.status} | ${responseText.slice(0, 300)}`);

    if (!lengoRes.ok) {
      await supabase.from('wallet_transactions').update({ status: 'failed' }).eq('id', transactionId);
      let friendlyError = 'Erreur de la plateforme LengoPay.';
      if (lengoRes.status === 401) {
        friendlyError = 'Clé LengoPay invalide ou IP non autorisée.';
      } else if (responseText.includes('<!DOCTYPE')) {
        friendlyError = "LengoPay a retourné une page HTML — l'URL de l'API est peut-être incorrecte.";
      }
      return res.status(lengoRes.status >= 400 && lengoRes.status < 600 ? lengoRes.status : 502).json({
        success: false,
        error: friendlyError,
        details: responseText.slice(0, 200),
      });
    }

    let result: any;
    try {
      result = JSON.parse(responseText);
    } catch {
      await supabase.from('wallet_transactions').update({ status: 'failed' }).eq('id', transactionId);
      return res.status(502).json({
        success: false,
        error: 'Réponse non-JSON reçue de LengoPay.',
        details: responseText.slice(0, 200),
      });
    }

    if (result.status === 'Success' || result.pay_id || result.payment_url || result.redirect_url || result.url) {
      // Store LengoPay's pay_id in its own column.
      // IMPORTANT: Do NOT overwrite reference_id — the webhook gateway uses
      // reference_id (the TOPUP- orderId) as its canonical idempotency key.
      // Overwriting it would break duplicate-webhook detection entirely.
      if (result.pay_id) {
        await supabase
          .from('wallet_transactions')
          .update({ pay_id: result.pay_id })
          .eq('id', transactionId);
      }

      // Forward any hosted-checkout redirect URL that LengoPay may return.
      // LengoPay USSD push → no URL (null); hosted portal → URL present.
      const paymentUrl: string | null =
        result.payment_url ?? result.redirect_url ?? result.url ?? null;

      return res.status(200).json({
        success: true,
        pay_id: result.pay_id ?? null,
        transaction_id: transactionId,
        payment_url: paymentUrl,
        message: paymentUrl
          ? 'Redirection vers le portail de paiement LengoPay.'
          : 'USSD envoyé. Le client doit valider sur son téléphone.',
      });
    }

    // Unexpected response shape
    await supabase.from('wallet_transactions').update({ status: 'failed' }).eq('id', transactionId);
    return res.status(400).json({
      success: false,
      error: 'Réponse inattendue de LengoPay.',
      details: result,
    });

  } catch (err: any) {
    // Global catch — handles any unhandled throw from Supabase I/O or fetch
    const isAbort = err.name === 'AbortError';

    // ── Structured exception log ─────────────────────────────────────────────
    // Emit every field so the Vercel function log shows the exact root cause.
    console.error(
      '[payin] Unhandled exception:',
      JSON.stringify({
        name:     err.name       ?? 'UnknownError',
        message:  err.message    ?? String(err),
        cause:    err.cause?.message ?? err.cause ?? null,
        code:     err.code       ?? null,
        // Include stack only in non-production to avoid leaking internals
        ...(process.env.NODE_ENV !== 'production' && { stack: err.stack }),
      })
    );

    // Best-effort: mark any created transaction as failed
    if (transactionId && supabase) {
      try {
        await supabase
          .from('wallet_transactions')
          .update({ status: 'failed' })
          .eq('id', transactionId);
      } catch { /* ignore secondary failure */ }
    }

    if (isAbort) {
      return res.status(504).json({
        success: false,
        error: 'La requête vers LengoPay a expiré (30s).',
        details: 'AbortError: fetch timed out after 30 000 ms.',
      });
    }

    // Build a details string that chains name → message → cause
    const causeMsg = err.cause?.message ?? (typeof err.cause === 'string' ? err.cause : null);
    const details = [
      `${err.name ?? 'Error'}: ${err.message ?? String(err)}`,
      causeMsg ? `Caused by: ${causeMsg}` : null,
      // Expose stack only outside production for easier staging diagnosis
      process.env.NODE_ENV !== 'production' && err.stack ? err.stack.split('\n').slice(0, 6).join(' | ') : null,
    ]
      .filter(Boolean)
      .join(' — ');

    return res.status(500).json({
      success: false,
      error: 'Erreur lors du traitement de la recharge.',
      details,
    });
  }
}

