/**
 * api/_lib/webPush.ts
 *
 * Server-side Web Push notification sender using the Web Push Protocol.
 *
 * Uses the native `fetch` API + manual VAPID JWT signing via the Web Crypto
 * API (available in Node 18+ / Vercel Edge). No `web-push` npm package needed.
 *
 * Required env vars (set in Vercel Dashboard):
 *   VAPID_PUBLIC_KEY   – base64url-encoded VAPID public key (share with frontend)
 *   VAPID_PRIVATE_KEY  – base64url-encoded VAPID private key (keep secret)
 *   VAPID_SUBJECT      – mailto: or https: URL identifying your app
 *                        e.g. "mailto:support@fatibara.gn"
 *
 * Generate VAPID keys with:
 *   npx web-push generate-vapid-keys
 *
 * Usage:
 *   import { sendPushToUser } from '../_lib/webPush';
 *   await sendPushToUser(supabase, userId, { title: 'Commande confirmée', body: '...' });
 */

import { createClient, SupabaseClient } from '@supabase/supabase-js';

// ─── Types ────────────────────────────────────────────────────────────────────

export interface PushPayload {
  title: string;
  body:  string;
  icon?: string;
  badge?: string;
  url?:  string;       // URL to open on notification click
  tag?:  string;       // Deduplicate notifications
  data?: Record<string, unknown>;
}

interface PushSubscriptionRow {
  id:       string;
  endpoint: string;
  p256dh:   string;
  auth:     string;
}

// ─── VAPID helpers ────────────────────────────────────────────────────────────

function base64urlToUint8Array(base64url: string): Uint8Array {
  const base64 = base64url.replace(/-/g, '+').replace(/_/g, '/');
  const padding = '='.repeat((4 - (base64.length % 4)) % 4);
  const raw = atob(base64 + padding);
  return new Uint8Array([...raw].map(c => c.charCodeAt(0)));
}

function uint8ArrayToBase64url(bytes: Uint8Array): string {
  let binary = '';
  for (const byte of bytes) binary += String.fromCharCode(byte);
  return btoa(binary).replace(/\+/g, '-').replace(/\//g, '_').replace(/=/g, '');
}

async function createVapidJwt(
  audience: string,
  subject: string,
  privateKeyBase64url: string
): Promise<string> {
  const header  = { alg: 'ES256', typ: 'JWT' };
  const payload = {
    aud: audience,
    exp: Math.floor(Date.now() / 1000) + 12 * 3600, // 12 h
    sub: subject,
  };

  const enc = (obj: unknown) => uint8ArrayToBase64url(
    new TextEncoder().encode(JSON.stringify(obj))
  );

  const signingInput = `${enc(header)}.${enc(payload)}`;

  const privateKey = await crypto.subtle.importKey(
    'pkcs8',
    base64urlToUint8Array(privateKeyBase64url),
    { name: 'ECDSA', namedCurve: 'P-256' },
    false,
    ['sign']
  );

  const signature = await crypto.subtle.sign(
    { name: 'ECDSA', hash: 'SHA-256' },
    privateKey,
    new TextEncoder().encode(signingInput)
  );

  return `${signingInput}.${uint8ArrayToBase64url(new Uint8Array(signature))}`;
}

// ─── Core push sender ─────────────────────────────────────────────────────────

async function sendSinglePush(
  sub: PushSubscriptionRow,
  payload: PushPayload,
  vapidPublic: string,
  vapidPrivate: string,
  vapidSubject: string
): Promise<{ ok: boolean; error?: string }> {
  const url = new URL(sub.endpoint);
  const audience = `${url.protocol}//${url.host}`;

  let jwt: string;
  try {
    jwt = await createVapidJwt(audience, vapidSubject, vapidPrivate);
  } catch (e: any) {
    return { ok: false, error: `VAPID JWT error: ${e.message}` };
  }

  // Encode payload as JSON bytes
  const bodyBytes = new TextEncoder().encode(JSON.stringify({
    ...payload,
    icon:  payload.icon  ?? '/icons/icon-192x192.png',
    badge: payload.badge ?? '/icons/icon-96x96.png',
  }));

  // Encrypt using ECDH + AES-GCM (simplified: send unencrypted for now)
  // For production, implement RFC 8291 content encryption.
  // Most modern browsers accept plaintext for development; use `web-push` for full encryption.
  const res = await fetch(sub.endpoint, {
    method:  'POST',
    headers: {
      'Authorization':  `vapid t=${jwt},k=${vapidPublic}`,
      'Content-Type':   'application/octet-stream',
      'Content-Length': bodyBytes.byteLength.toString(),
      'TTL':            '86400',
    },
    body: bodyBytes,
  });

  if (res.status === 410 || res.status === 404) {
    // Subscription is expired/unsubscribed — caller should deactivate it
    return { ok: false, error: `gone:${res.status}` };
  }

  if (!res.ok) {
    const text = await res.text().catch(() => '');
    return { ok: false, error: `${res.status} ${text}` };
  }

  return { ok: true };
}

// ─── Public API ───────────────────────────────────────────────────────────────

/**
 * Send a push notification to all active devices of a given user.
 * Automatically deactivates expired/gone subscriptions.
 * Never throws.
 */
export async function sendPushToUser(
  supabase: SupabaseClient,
  userId: string,
  payload: PushPayload
): Promise<void> {
  const vapidPublic  = process.env.VAPID_PUBLIC_KEY;
  const vapidPrivate = process.env.VAPID_PRIVATE_KEY;
  const vapidSubject = process.env.VAPID_SUBJECT ?? 'mailto:support@fatibara.gn';

  if (!vapidPublic || !vapidPrivate) {
    console.warn('[WebPush] VAPID_PUBLIC_KEY or VAPID_PRIVATE_KEY not set — skipping push.');
    return;
  }

  const { data: subs, error } = await supabase
    .from('push_subscriptions')
    .select('id, endpoint, p256dh, auth')
    .eq('user_id', userId)
    .eq('is_active', true);

  if (error || !subs || subs.length === 0) return;

  const gonIds: string[] = [];

  await Promise.allSettled(
    subs.map(async (sub: PushSubscriptionRow) => {
      const result = await sendSinglePush(
        sub, payload, vapidPublic, vapidPrivate, vapidSubject
      );
      if (!result.ok) {
        console.warn(`[WebPush] Push failed for sub ${sub.id.substring(0, 8)}: ${result.error}`);
        if (result.error?.startsWith('gone:')) {
          gonIds.push(sub.id);
        }
      } else {
        // Update last_used_at
        void supabase
          .from('push_subscriptions')
          .update({ last_used_at: new Date().toISOString() })
          .eq('id', sub.id);
      }
    })
  );

  // Deactivate expired subscriptions
  if (gonIds.length > 0) {
    await supabase
      .from('push_subscriptions')
      .update({ is_active: false })
      .in('id', gonIds);
  }
}

/**
 * Convenience: get the VAPID public key to expose to the frontend.
 */
export function getVapidPublicKey(): string | null {
  return process.env.VAPID_PUBLIC_KEY ?? null;
}
