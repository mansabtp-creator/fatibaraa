/**
 * api/_lib/whatsapp.ts
 *
 * WhatsApp order notification helper using Africa's Talking WhatsApp API.
 * Africa's Talking has strong coverage in Guinea (Conakry) and offers
 * a sandbox for free testing.
 *
 * Alternative: Replace the sendViaAfricasTalking() implementation with
 * the Twilio WhatsApp API if you prefer that provider.
 *
 * Required env vars (set in Vercel Dashboard):
 *   AFRICASTALKING_API_KEY   – Africa's Talking API key
 *   AFRICASTALKING_USERNAME  – Your AT username (use 'sandbox' for testing)
 *   AFRICASTALKING_FROM      – WhatsApp sender number (e.g. "+2250700000000")
 *                              Must be a registered AT WhatsApp Business number
 *
 * Docs: https://developers.africastalking.com/docs/whatsapp
 *
 * Usage:
 *   import { sendOrderWhatsApp } from '../_lib/whatsapp';
 *   await sendOrderWhatsApp({ phone: '+224622...', orderId: '...', amount: 450000, storeName: '...' });
 *
 * NOTE: If AFRICASTALKING_API_KEY is not set, the function logs a warning
 * and returns false gracefully — never throws.
 */

const AT_WHATSAPP_API = 'https://chat.africastalking.com/whatsapp/message';

export interface WhatsAppOrderPayload {
  phone:     string;    // Buyer's phone in E.164 format, e.g. "+224622123456"
  orderId:   string;    // Full UUID — will be truncated to 8 chars
  amount:    number;    // GNF amount
  storeName: string;    // Vendor store name
  buyerName?: string;   // Optional — used for personalised greeting
}

/**
 * Build a concise WhatsApp message (≤1024 chars for template compliance).
 * Keep it short — WhatsApp Business templates must be pre-approved for
 * outbound messages to non-contacts. This draft follows template guidelines.
 */
function buildMessage(p: WhatsAppOrderPayload): string {
  const shortId   = p.orderId.substring(0, 8).toUpperCase();
  const amount    = p.amount.toLocaleString('fr-GN') + ' GNF';
  const greeting  = p.buyerName ? `Bonjour ${p.buyerName},` : 'Bonjour,';

  return [
    `✅ *FATIBARA* — Commande confirmée`,
    '',
    greeting,
    `Votre paiement de *${amount}* a été confirmé ! 🎉`,
    '',
    `🛍️ Boutique : *${p.storeName}*`,
    `🔖 Référence : *#${shortId}*`,
    '',
    `📦 Votre commande est en cours de préparation. Vous recevrez une alerte à chaque mise à jour.`,
    '',
    `Suivez votre commande sur : https://www.fatibara.com/dashboard`,
    '',
    `Des questions ? Répondez à ce message ou appelez : *+224 660 34 58 58*`,
  ].join('\n');
}

/**
 * Send via Africa's Talking WhatsApp API.
 */
async function sendViaAfricasTalking(
  to:      string,
  message: string
): Promise<{ ok: boolean; error?: string }> {
  const apiKey   = process.env.AFRICASTALKING_API_KEY!;
  const username = process.env.AFRICASTALKING_USERNAME!;
  const from     = process.env.AFRICASTALKING_FROM!;

  const body = new URLSearchParams({
    username,
    to,
    from,
    message,
  });

  try {
    const res = await fetch(AT_WHATSAPP_API, {
      method:  'POST',
      headers: {
        'apiKey':       apiKey,
        'Content-Type': 'application/x-www-form-urlencoded',
        'Accept':       'application/json',
      },
      body: body.toString(),
    });

    if (!res.ok) {
      const text = await res.text().catch(() => '');
      return { ok: false, error: `AT error ${res.status}: ${text}` };
    }

    const json = await res.json().catch(() => ({}));
    const status = json?.SMSMessageData?.Recipients?.[0]?.status ?? 'Unknown';
    if (status !== 'Success') {
      return { ok: false, error: `AT delivery status: ${status}` };
    }

    return { ok: true };
  } catch (err: any) {
    return { ok: false, error: err.message ?? String(err) };
  }
}

/**
 * Send an order confirmation WhatsApp message.
 * Never throws — skips gracefully if env vars are not set.
 */
export async function sendOrderWhatsApp(
  payload: WhatsAppOrderPayload
): Promise<boolean> {
  const apiKey   = process.env.AFRICASTALKING_API_KEY;
  const username = process.env.AFRICASTALKING_USERNAME;
  const from     = process.env.AFRICASTALKING_FROM;

  if (!apiKey || !username || !from) {
    console.warn('[WhatsApp] AFRICASTALKING_* env vars not set — skipping WhatsApp notification.');
    return false;
  }

  // Normalise phone: ensure E.164 with Guinea +224 prefix
  let phone = payload.phone.replace(/\s/g, '');
  if (phone.startsWith('00')) phone = '+' + phone.slice(2);
  if (phone.startsWith('6') && phone.length === 9) phone = '+224' + phone;
  if (!phone.startsWith('+')) {
    console.warn(`[WhatsApp] Invalid phone format: ${payload.phone} — skipping.`);
    return false;
  }

  const message = buildMessage(payload);
  const result  = await sendViaAfricasTalking(phone, message);

  if (!result.ok) {
    console.warn(`[WhatsApp] Send failed for order ${payload.orderId.substring(0, 8)}: ${result.error}`);
    return false;
  }

  console.log(`[WhatsApp] Order confirmation sent → ${phone} | order #${payload.orderId.substring(0, 8)}`);
  return true;
}
