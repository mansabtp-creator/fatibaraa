/**
 * api/_lib/email.ts
 *
 * Transactional email helper using the Resend REST API (no npm package needed).
 * Set RESEND_API_KEY in Vercel env vars. If the key is absent the function
 * logs a warning and returns gracefully — never hard-fails a payment callback.
 *
 * Docs: https://resend.com/docs/api-reference/emails/send-email
 *
 * Required env vars:
 *   RESEND_API_KEY         – Resend API key  (re_xxxx…)
 *   EMAIL_FROM             – Verified sender address (e.g. "FATIBARA <no-reply@fatibara.com>")
 *                            Falls back to "FATIBARA <no-reply@fatibara.gn>"
 */

const RESEND_API = 'https://api.resend.com/emails';

// ─── Types ────────────────────────────────────────────────────────────────────

export interface OrderEmailPayload {
  to:          string;           // Buyer's email address
  buyerName:   string;           // Full name for greeting
  orderId:     string;           // UUID (shown truncated)
  totalAmount: number;           // GNF amount
  storeName:   string;           // Vendor's store name
  items?:      OrderItem[];      // Optional line items
}

interface OrderItem {
  title: string;
  quantity: number;
  price_gnf: number;
}

// ─── Helpers ─────────────────────────────────────────────────────────────────

function gnf(amount: number) {
  return amount.toLocaleString('fr-GN') + ' GNF';
}

// ─── HTML Template ───────────────────────────────────────────────────────────

function buildOrderConfirmationHtml(p: OrderEmailPayload): string {
  const shortId = p.orderId.substring(0, 8).toUpperCase();
  const itemsHtml = (p.items ?? []).map(item => `
    <tr>
      <td style="padding:8px 0;border-bottom:1px solid #f0f0f0;font-size:13px;color:#1a1a1a">${item.title}</td>
      <td style="padding:8px 0;border-bottom:1px solid #f0f0f0;font-size:13px;color:#666;text-align:center">${item.quantity}</td>
      <td style="padding:8px 0;border-bottom:1px solid #f0f0f0;font-size:13px;color:#ff6600;text-align:right;font-weight:bold">${gnf(item.price_gnf * item.quantity)}</td>
    </tr>
  `).join('');

  return `<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Confirmation de commande — FATIBARA</title>
</head>
<body style="margin:0;padding:0;background:#f8f8f8;font-family:'Helvetica Neue',Helvetica,Arial,sans-serif">
  <table width="100%" cellpadding="0" cellspacing="0" style="background:#f8f8f8;padding:32px 16px">
    <tr>
      <td align="center">
        <table width="100%" cellpadding="0" cellspacing="0" style="max-width:560px;background:#ffffff;border-radius:16px;overflow:hidden;box-shadow:0 2px 16px rgba(0,0,0,.06)">

          <!-- Header -->
          <tr>
            <td style="background:linear-gradient(135deg,#ff6600 0%,#e65c00 100%);padding:32px 40px;text-align:center">
              <h1 style="margin:0;font-size:28px;font-weight:900;color:#ffffff;letter-spacing:-1px;text-transform:uppercase">FATIBARA</h1>
              <p style="margin:4px 0 0;font-size:11px;color:rgba(255,255,255,.8);letter-spacing:2px;text-transform:uppercase">La place de marché #1 en Guinée</p>
            </td>
          </tr>

          <!-- Status banner -->
          <tr>
            <td style="background:#fff8f5;border-bottom:3px solid #ff6600;padding:20px 40px;text-align:center">
              <span style="font-size:32px">✅</span>
              <h2 style="margin:8px 0 4px;font-size:20px;font-weight:800;color:#1a1a1a">Paiement confirmé !</h2>
              <p style="margin:0;font-size:13px;color:#666">Commande <strong style="color:#ff6600">#${shortId}</strong></p>
            </td>
          </tr>

          <!-- Body -->
          <tr>
            <td style="padding:32px 40px">
              <p style="margin:0 0 20px;font-size:15px;color:#1a1a1a">Bonjour <strong>${p.buyerName}</strong>,</p>
              <p style="margin:0 0 24px;font-size:14px;color:#444;line-height:1.6">
                Votre paiement a été reçu et confirmé avec succès. La boutique <strong>${p.storeName}</strong> prépare votre commande — vous recevrez une notification dès qu'elle est expédiée.
              </p>

              <!-- Order summary -->
              <div style="background:#f9f9f9;border-radius:12px;padding:20px 24px;margin-bottom:24px">
                <h3 style="margin:0 0 16px;font-size:12px;font-weight:800;color:#999;text-transform:uppercase;letter-spacing:1px">Récapitulatif</h3>
                ${p.items && p.items.length > 0 ? `
                <table width="100%" cellpadding="0" cellspacing="0">
                  <thead>
                    <tr>
                      <th style="font-size:10px;font-weight:700;color:#999;text-transform:uppercase;text-align:left;padding-bottom:8px">Article</th>
                      <th style="font-size:10px;font-weight:700;color:#999;text-transform:uppercase;text-align:center;padding-bottom:8px">Qté</th>
                      <th style="font-size:10px;font-weight:700;color:#999;text-transform:uppercase;text-align:right;padding-bottom:8px">Prix</th>
                    </tr>
                  </thead>
                  <tbody>${itemsHtml}</tbody>
                </table>
                ` : ''}
                <div style="margin-top:16px;padding-top:16px;border-top:2px solid #e8e8e8;display:flex;justify-content:space-between">
                  <span style="font-size:14px;font-weight:800;color:#1a1a1a">Total payé</span>
                  <span style="font-size:18px;font-weight:900;color:#ff6600">${gnf(p.totalAmount)}</span>
                </div>
              </div>

              <!-- CTA -->
              <div style="text-align:center;margin-bottom:24px">
                <a href="https://www.fatibara.com/dashboard" style="display:inline-block;background:#ff6600;color:#ffffff;text-decoration:none;padding:14px 32px;border-radius:10px;font-size:13px;font-weight:800;text-transform:uppercase;letter-spacing:1px">
                  Suivre ma commande →
                </a>
              </div>

              <p style="margin:0;font-size:12px;color:#aaa;line-height:1.6;text-align:center">
                Besoin d'aide ? Contactez-nous à <a href="mailto:support@fatibara.gn" style="color:#ff6600">support@fatibara.gn</a><br>ou via WhatsApp au <strong>+224 660 34 58 58</strong>
              </p>
            </td>
          </tr>

          <!-- Footer -->
          <tr>
            <td style="background:#1a1a1a;padding:20px 40px;text-align:center">
              <p style="margin:0;font-size:10px;color:#666;letter-spacing:1px;text-transform:uppercase">
                © ${new Date().getFullYear()} FATIBARA — FATIGLOBAL Group &nbsp;·&nbsp;
                <a href="https://www.fatibara.com/privacy" style="color:#ff6600;text-decoration:none">Confidentialité</a> &nbsp;·&nbsp;
                <a href="https://www.fatibara.com/terms" style="color:#ff6600;text-decoration:none">CGU</a>
              </p>
            </td>
          </tr>

        </table>
      </td>
    </tr>
  </table>
</body>
</html>`;
}

// ─── Plain-text fallback ──────────────────────────────────────────────────────

function buildOrderConfirmationText(p: OrderEmailPayload): string {
  const shortId = p.orderId.substring(0, 8).toUpperCase();
  return [
    `FATIBARA — Confirmation de commande #${shortId}`,
    '',
    `Bonjour ${p.buyerName},`,
    '',
    `Votre paiement de ${gnf(p.totalAmount)} a été confirmé !`,
    `Boutique : ${p.storeName}`,
    '',
    'Suivez votre commande sur : https://www.fatibara.com/dashboard',
    '',
    'Support : support@fatibara.gn | +224 660 34 58 58',
  ].join('\n');
}

// ─── Main export ─────────────────────────────────────────────────────────────

/**
 * Send an order confirmation email via Resend.
 * Never throws — logs errors and returns false on failure so the webhook
 * can always respond 200 to LengoPay.
 */
export async function sendOrderConfirmationEmail(
  payload: OrderEmailPayload
): Promise<boolean> {
  const apiKey = process.env.RESEND_API_KEY;
  const from   = process.env.EMAIL_FROM ?? 'FATIBARA <no-reply@fatibara.gn>';

  if (!apiKey) {
    console.warn('[Email] RESEND_API_KEY not set — skipping order confirmation email.');
    return false;
  }

  if (!payload.to || !payload.to.includes('@')) {
    console.warn('[Email] Invalid recipient address — skipping.');
    return false;
  }

  try {
    const shortId = payload.orderId.substring(0, 8).toUpperCase();
    const response = await fetch(RESEND_API, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${apiKey}`,
        'Content-Type':  'application/json',
      },
      body: JSON.stringify({
        from,
        to:      [payload.to],
        subject: `✅ Commande #${shortId} confirmée — FATIBARA`,
        html:    buildOrderConfirmationHtml(payload),
        text:    buildOrderConfirmationText(payload),
        tags: [
          { name: 'category', value: 'order_confirmation' },
          { name: 'order_id', value: payload.orderId },
        ],
      }),
    });

    if (!response.ok) {
      const body = await response.text().catch(() => '(no body)');
      console.error(`[Email] Resend error ${response.status}: ${body}`);
      return false;
    }

    console.log(`[Email] Order confirmation sent → ${payload.to} | order #${shortId}`);
    return true;
  } catch (err: any) {
    console.error('[Email] Unexpected error sending confirmation:', err?.message ?? err);
    return false;
  }
}
