/**
 * api/_lib/rateLimit.ts
 *
 * Sliding-window rate limiter for Vercel Serverless Functions.
 *
 * STRATEGY:
 *   Vercel reuses warm lambda instances across requests. An in-process Map
 *   acts as a fast, zero-latency store for the sliding window. Cold starts
 *   reset the window — acceptable for the protection this provides.
 *
 *   For production at scale, swap the `MemoryStore` for a Redis/Upstash
 *   store without changing the calling API.
 *
 * USAGE:
 *   import { rateLimit } from '../_lib/rateLimit';
 *
 *   const limiter = rateLimit({ limit: 5, windowMs: 60_000 });
 *
 *   export default async function handler(req, res) {
 *     const result = limiter.check(req);
 *     if (!result.allowed) {
 *       res.setHeader('Retry-After', String(result.retryAfterSeconds));
 *       return res.status(429).json({ success: false, error: result.message });
 *     }
 *     // ... rest of handler
 *   }
 */

import type { VercelRequest } from '@vercel/node';

// ─── Types ────────────────────────────────────────────────────────────────────

export interface RateLimitOptions {
  /** Maximum number of requests allowed within windowMs. Default: 5 */
  limit?: number;
  /** Time window in milliseconds. Default: 60_000 (1 minute) */
  windowMs?: number;
  /** Optional key prefix to namespace different limiters. Default: 'rl' */
  prefix?: string;
}

export interface RateLimitResult {
  /** Whether the request is within the rate limit */
  allowed: boolean;
  /** Remaining requests in the current window */
  remaining: number;
  /** Seconds until the window resets (only meaningful when allowed = false) */
  retryAfterSeconds: number;
  /** Human-readable French error message for 429 responses */
  message: string;
}

// ─── In-process sliding window store ─────────────────────────────────────────

interface WindowEntry {
  /** Timestamps (ms) of each request within the current window */
  timestamps: number[];
}

// Module-level Map — survives across requests on warm lambda instances.
// Each RateLimiter instance gets its own Map to avoid key collisions.
// eslint-disable-next-line @typescript-eslint/no-explicit-any
const globalStores = new Map<string, Map<string, WindowEntry>>();

function getStore(prefix: string): Map<string, WindowEntry> {
  let store = globalStores.get(prefix);
  if (!store) {
    store = new Map<string, WindowEntry>();
    globalStores.set(prefix, store);
  }
  return store;
}

// ─── IP extraction ────────────────────────────────────────────────────────────

/**
 * Extracts the real client IP from Vercel request headers.
 * Order: x-real-ip → x-forwarded-for (first hop) → fallback '0.0.0.0'
 */
function getClientIp(req: VercelRequest): string {
  const realIp = req.headers['x-real-ip'];
  if (typeof realIp === 'string' && realIp.trim()) {
    return realIp.trim();
  }

  const forwarded = req.headers['x-forwarded-for'];
  if (typeof forwarded === 'string' && forwarded.trim()) {
    // x-forwarded-for can be a comma-separated list; first entry is the client
    return forwarded.split(',')[0].trim();
  }
  if (Array.isArray(forwarded) && forwarded.length > 0) {
    return forwarded[0].split(',')[0].trim();
  }

  return '0.0.0.0';
}

// ─── RateLimiter class ────────────────────────────────────────────────────────

export class RateLimiter {
  private readonly limit: number;
  private readonly windowMs: number;
  private readonly store: Map<string, WindowEntry>;

  constructor(options: RateLimitOptions = {}) {
    this.limit     = options.limit     ?? 5;
    this.windowMs  = options.windowMs  ?? 60_000;
    this.store     = getStore(options.prefix ?? 'rl');
  }

  /**
   * Check whether the incoming request is within the rate limit.
   * Call this at the very top of a Vercel handler, before any business logic.
   */
  check(req: VercelRequest): RateLimitResult {
    const ip  = getClientIp(req);
    const now = Date.now();
    const windowStart = now - this.windowMs;

    // Retrieve or initialise the window entry for this IP
    let entry = this.store.get(ip);
    if (!entry) {
      entry = { timestamps: [] };
      this.store.set(ip, entry);
    }

    // Prune timestamps outside the current window (sliding window algorithm)
    entry.timestamps = entry.timestamps.filter(ts => ts > windowStart);

    const count = entry.timestamps.length;

    if (count >= this.limit) {
      // Find when the oldest in-window request expires
      const oldestInWindow   = entry.timestamps[0]; // already sorted asc
      const resetAt          = oldestInWindow + this.windowMs;
      const retryAfterMs     = Math.max(0, resetAt - now);
      const retryAfterSeconds = Math.ceil(retryAfterMs / 1000);

      return {
        allowed: false,
        remaining: 0,
        retryAfterSeconds,
        message: `Trop de tentatives de paiement. Veuillez patienter ${retryAfterSeconds} seconde(s) avant de réessayer.`,
      };
    }

    // Record this request
    entry.timestamps.push(now);

    return {
      allowed: true,
      remaining: this.limit - entry.timestamps.length,
      retryAfterSeconds: 0,
      message: '',
    };
  }

  /**
   * Manually reset the window for a given IP (e.g. after a successful payment
   * to allow the next legitimate attempt immediately).
   */
  reset(req: VercelRequest): void {
    const ip = getClientIp(req);
    this.store.delete(ip);
  }
}

// ─── Pre-built limiters for payment endpoints ─────────────────────────────────

/**
 * Strict limiter for payment initiation:
 *   - 5 attempts per IP per 60 seconds
 *   - Each failed attempt still counts (prevents rapid retry loops)
 */
export const paymentInitiateLimiter = new RateLimiter({
  limit: 5,
  windowMs: 60_000,
  prefix: 'pay_initiate',
});

/**
 * Slightly more lenient for the mobile/OTP endpoint
 * (user may need a couple of tries for OTP):
 *   - 10 attempts per IP per 60 seconds
 */
export const paymentMobileLimiter = new RateLimiter({
  limit: 10,
  windowMs: 60_000,
  prefix: 'pay_mobile',
});

/**
 * Generic factory — use this when creating limiters for other endpoints.
 */
export function rateLimit(options?: RateLimitOptions): RateLimiter {
  return new RateLimiter(options);
}
