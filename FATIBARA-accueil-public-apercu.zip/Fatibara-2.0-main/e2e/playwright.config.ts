/**
 * e2e/playwright.config.ts
 *
 * Playwright configuration for the Fatibara E2E & Financial test suite.
 * Target: https://www.fatibara.com (Vercel production)
 *
 * Safety contract:
 *  - ALL mutating tests use isolated accounts (e2e_*@fatibara.test)
 *  - fatiglobal data is NEVER touched by any write operation
 */

import { defineConfig, devices } from '@playwright/test';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

export default defineConfig({
  // ── Test directory ────────────────────────────────────────────────────────
  testDir: path.join(__dirname, 'tests'),

  // ── Parallelism ───────────────────────────────────────────────────────────
  // Run suites in parallel but keep individual tests serial within a file
  // to maintain order-of-operations for financial state machines.
  fullyParallel: false,
  workers: 1,  // Sequential — financial state tests are order-sensitive

  // ── Timeouts ─────────────────────────────────────────────────────────────
  timeout: 45_000,          // per-test
  expect: { timeout: 10_000 },

  // ── Retries ──────────────────────────────────────────────────────────────
  retries: 0,               // Financial tests must not retry — idempotency is tested explicitly

  // ── Reporters ────────────────────────────────────────────────────────────
  reporter: [
    ['list'],
    ['html', { outputFolder: path.join(__dirname, '..', 'playwright-report'), open: 'never' }],
    ['json', { outputFile: path.join(__dirname, '..', 'playwright-report', 'results.json') }],
  ],

  // ── Global setup / teardown ───────────────────────────────────────────────
  globalSetup:    path.join(__dirname, 'global-setup.ts'),
  globalTeardown: path.join(__dirname, 'global-teardown.ts'),

  // ── Shared env ────────────────────────────────────────────────────────────
  // All tests read SUPABASE_URL / SUPABASE_SERVICE_KEY from env (or .env)
  use: {
    baseURL: 'https://www.fatibara.com',

    // We test the live site via fetch/API — no browser UI needed for most suites
    headless: true,

    // Record traces on failure for debugging
    trace: 'on-first-retry',
    screenshot: 'only-on-failure',

    // Extra HTTP timeout for real network calls
    navigationTimeout: 30_000,
    actionTimeout:     15_000,
  },

  // ── Projects ─────────────────────────────────────────────────────────────
  projects: [
    {
      name: 'chromium',
      use: { ...devices['Desktop Chrome'] },
    },
  ],

  // ── Output ────────────────────────────────────────────────────────────────
  outputDir: path.join(__dirname, '..', 'playwright-results'),
});
