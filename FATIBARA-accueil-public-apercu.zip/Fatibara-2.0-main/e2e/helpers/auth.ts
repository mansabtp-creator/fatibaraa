/**
 * e2e/helpers/auth.ts
 *
 * Isolated test account lifecycle utilities.
 *
 * ALL test accounts use email pattern:  e2e_<role>_<timestamp>@fatibara.test
 * ALL test accounts are cleaned up in globalTeardown.
 *
 * SAFETY: This file NEVER references or modifies fatiglobal data.
 */

import { getServiceClient } from './supabase.js';

export interface TestAccount {
  id: string;
  email: string;
  password: string;
  role: 'buyer' | 'vendor' | 'courier';
}

export interface TestStore {
  id: string;
  owner_id: string;
  store_name: string;
  store_slug: string;
}

const TEST_DOMAIN = 'fatibara.test';
const TEST_PASSWORD = 'E2eTestPass!2026';

// ── Registry (populated during test run, consumed by teardown) ────────────────
const _createdAccountIds: string[] = [];
const _createdStoreIds: string[]   = [];
const _createdOrderIds: string[]   = [];

export function getCreatedAccountIds() { return [..._createdAccountIds]; }
export function getCreatedStoreIds()   { return [..._createdStoreIds]; }
export function getCreatedOrderIds()   { return [..._createdOrderIds]; }

/**
 * Create an isolated test user via the Supabase Admin API.
 * Returns the new account's id + credentials.
 */
export async function createTestAccount(role: 'buyer' | 'vendor' | 'courier'): Promise<TestAccount> {
  const ts    = Date.now();
  const email = `e2e_${role}_${ts}@${TEST_DOMAIN}`;
  const svc   = getServiceClient();

  const { data, error } = await svc.auth.admin.createUser({
    email,
    password: TEST_PASSWORD,
    email_confirm: true,   // skip email confirmation for test accounts
    user_metadata: { full_name: `E2E ${role} ${ts}` },
  });

  if (error || !data?.user) {
    throw new Error(`[auth] createTestAccount(${role}) failed: ${error?.message}`);
  }

  // Determine profile_type from role
  const profileType = role === 'vendor' ? 'vendor'
    : role === 'courier' ? 'courier'
    : 'client';

  // Ensure profile row exists (trigger should handle it, but be defensive)
  await svc.from('profiles').upsert({
    id: data.user.id,
    full_name: `E2E ${role} ${ts}`,
    profile_type: profileType,
    wallet_balance: 0,
  }, { onConflict: 'id', ignoreDuplicates: false });

  _createdAccountIds.push(data.user.id);

  return {
    id:       data.user.id,
    email,
    password: TEST_PASSWORD,
    role,
  };
}

/**
 * Create an isolated courier test account with security fields pre-populated.
 * This is the preferred helper for courier-specific test suites.
 */
export async function createCourierAccount(opts?: {
  licensePlate?: string;
  phoneNumber?: string;
  vehicleType?: 'motorcycle' | 'car' | 'bicycle' | 'foot' | 'moto' | 'voiture' | 'velo';
  walletBalance?: number;
}): Promise<TestAccount & {
  licensePlate: string;
  phoneNumber: string;
}> {
  const account = await createTestAccount('courier');
  const svc     = getServiceClient();

  const licensePlate = opts?.licensePlate ?? `E2E-${Date.now().toString().slice(-5)}-MC`;
  const phoneNumber  = opts?.phoneNumber  ?? `62${Math.floor(Math.random() * 9_000_000 + 1_000_000)}`;
  // Use 'moto' (French alias) — matches the live DB CHECK constraint set by courier_fleet_migration.sql.
  // After migration 20260807000001 runs, 'motorcycle' will also be accepted.
  const vehicleType  = opts?.vehicleType  ?? 'moto';

  const { error } = await svc.from('profiles').update({
    profile_type:         'courier',
    phone_number:         phoneNumber,
    license_plate_number: licensePlate,
    vehicle_type:         vehicleType,
    is_courier_online:    false,
    wallet_balance:       opts?.walletBalance ?? 0,
  }).eq('id', account.id);

  if (error) {
    throw new Error(`[auth] createCourierAccount security fields update failed: ${error.message}`);
  }

  return { ...account, licensePlate, phoneNumber };
}

/**
 * Create an isolated vendor store owned by the given vendor account.
 */
export async function createTestStore(vendorId: string, suffix?: string): Promise<TestStore> {
  const ts        = Date.now();
  const slug      = `e2e-store-${ts}${suffix ? '-' + suffix : ''}`;
  const storeName = `E2E Store ${ts}`;
  const svc       = getServiceClient();

  const { data, error } = await svc
    .from('stores')
    .insert({
      owner_id:          vendorId,
      store_name:        storeName,
      balance:           0,
      is_verified_store: false,
      store_status:      'active',
    })
    .select('id, store_name')
    .single();

  if (error || !data) {
    throw new Error(`[auth] createTestStore failed: ${error?.message}`);
  }

  _createdStoreIds.push(data.id);

  return {
    id:         data.id,
    owner_id:   vendorId,
    store_name: data.store_name,
    store_slug: slug,  // logical slug used for teardown matching only
  };
}

/**
 * Create an isolated test product inside a test store.
 */
export async function createTestProduct(
  storeId: string,
  _vendorId: string,   // kept for call-site compatibility; not used (ownership via store_id)
  priceGnf: number,
  title?: string
): Promise<{ id: string; price_gnf: number; title: string }> {
  const svc  = getServiceClient();
  const name = title ?? `E2E Product ${Date.now()}`;

  const { data, error } = await svc
    .from('products')
    .insert({
      store_id:          storeId,
      title:             name,
      price_gnf:         Math.round(priceGnf),
      stock_quantity:    100,
      is_active:         true,
      moderation_status: 'approved',
    })
    .select('id, price_gnf, title')
    .single();

  if (error || !data) {
    throw new Error(`[auth] createTestProduct failed: ${error?.message}`);
  }

  return data;
}

/**
 * Create an isolated test order (bypasses cart flow — uses service-role insert).
 */
export async function createTestOrder(opts: {
  buyerId:     string;
  storeId:     string;
  vendorId:    string;
  totalAmount: number;
  items:       Array<{ product_id: string; title: string; quantity: number; price_gnf: number }>;
  paymentMethod?: string;  // kept for API compatibility; not inserted (not a DB column)
}): Promise<string> {
  const svc = getServiceClient();
  const ts  = Date.now();
  const trackingNumber = `ORD-E2E-${ts}`;

  const { data: order, error: orderErr } = await svc
    .from('orders')
    .insert({
      user_id:          opts.buyerId,
      store_id:         opts.storeId,
      vendor_id:        opts.vendorId,
      tracking_number:  trackingNumber,
      total_amount:     Math.round(opts.totalAmount),
      status:           'pending',
      financial_status: 'pending',
      customer_name:    'E2E Test Buyer',  // Required by public_pulse_events trigger (user_name NOT NULL)
    })
    .select('id')
    .single();

  if (orderErr || !order) {
    throw new Error(`[auth] createTestOrder failed: ${orderErr?.message}`);
  }

  // Insert order items
  if (opts.items.length > 0) {
    const { error: itemsErr } = await svc.from('order_items').insert(
      opts.items.map(item => ({
        order_id:         order.id,
        product_id:       item.product_id,
        quantity:         item.quantity,
        // DB column is price_at_purchase, NOT price_gnf
        price_at_purchase: item.price_gnf,
      }))
    );
    if (itemsErr) {
      console.warn(`[auth] order items insert warning: ${itemsErr.message}`);
    }
  }

  _createdOrderIds.push(order.id);
  return order.id;
}

/**
 * Set a user's wallet balance directly (service-role, bypasses RLS).
 * Used for test setup in Suite 3.
 */
export async function setWalletBalance(userId: string, amount: number): Promise<void> {
  const svc = getServiceClient();
  const { error } = await svc
    .from('profiles')
    .update({ wallet_balance: Math.round(amount) })
    .eq('id', userId);
  if (error) throw new Error(`[auth] setWalletBalance failed: ${error.message}`);
}

/**
 * Read a user's current wallet balance.
 */
export async function getWalletBalance(userId: string): Promise<number> {
  const svc = getServiceClient();
  const { data, error } = await svc
    .from('profiles')
    .select('wallet_balance')
    .eq('id', userId)
    .single();
  if (error || !data) throw new Error(`[auth] getWalletBalance failed: ${error?.message}`);
  return Number(data.wallet_balance ?? 0);
}

/**
 * Read a store's current balance.
 */
export async function getStoreBalance(storeId: string): Promise<number> {
  const svc = getServiceClient();
  const { data, error } = await svc
    .from('stores')
    .select('balance')
    .eq('id', storeId)
    .single();
  if (error || !data) throw new Error(`[auth] getStoreBalance failed: ${error?.message}`);
  return Number(data.balance ?? 0);
}

/**
 * Cleanup — called from globalTeardown.
 * Deletes all accounts, stores, and orders created during the test run.
 */
export async function cleanupAllTestData(): Promise<void> {
  const svc = getServiceClient();

  // Orders first (FK constraints)
  if (_createdOrderIds.length > 0) {
    await svc.from('order_items').delete().in('order_id', _createdOrderIds);
    await svc.from('orders').delete().in('id', _createdOrderIds);
  }

  // Stores + their products / transactions
  if (_createdStoreIds.length > 0) {
    await svc.from('products').delete().in('store_id', _createdStoreIds);
    await svc.from('wallet_transactions').delete().in('store_id', _createdStoreIds);
    await svc.from('withdrawals').delete().in('store_id', _createdStoreIds);
    await svc.from('stores').delete().in('id', _createdStoreIds);
  }

  // Users (auth.admin.deleteUser cascades profile rows)
  for (const userId of _createdAccountIds) {
    await svc.auth.admin.deleteUser(userId);
  }

  console.log(
    `[teardown] Cleaned up: ${_createdAccountIds.length} accounts, ` +
    `${_createdStoreIds.length} stores, ${_createdOrderIds.length} orders`
  );
}
