/**
 * e2e/helpers/supabase.ts
 *
 * Production Supabase client factory.
 * Uses SUPABASE_SERVICE_ROLE_KEY (server-side only — never exposed to browser).
 *
 * Reads from environment variables set in .env (VITE_ prefix stripped for server).
 */

import { createClient, SupabaseClient } from '@supabase/supabase-js';
import * as dotenv from 'dotenv';
import * as path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

// Load .env from project root
dotenv.config({ path: path.resolve(__dirname, '../../.env') });

function requireEnv(key: string): string {
  const val = process.env[key];
  if (!val) throw new Error(`[e2e/supabase] Missing env var: ${key}`);
  return val;
}

// ── Prod Supabase URL (from VITE_ prefix in .env) ────────────────────────────
export const SUPABASE_URL   = requireEnv('VITE_SUPABASE_URL');
export const SUPABASE_ANON  = requireEnv('VITE_SUPABASE_ANON_KEY');
export const SUPABASE_SVC   = requireEnv('SUPABASE_SERVICE_ROLE_KEY');

// ── The webhook secret used to authenticate LengoPay callbacks ───────────────
export const LENGOPAY_WEBHOOK_SECRET = process.env.LENGOPAY_WEBHOOK_SECRET ?? '';

// ── App base URL ─────────────────────────────────────────────────────────────
export const BASE_URL = 'https://www.fatibara.com';

let _serviceClient: SupabaseClient | null = null;
let _anonClient: SupabaseClient | null = null;

/**
 * Returns a service-role Supabase client.
 * Bypasses RLS — use only for test setup / teardown and financial RPC calls.
 */
export function getServiceClient(): SupabaseClient {
  if (!_serviceClient) {
    _serviceClient = createClient(SUPABASE_URL, SUPABASE_SVC, {
      auth: { persistSession: false, autoRefreshToken: false },
    });
  }
  return _serviceClient;
}

/**
 * Returns an anon Supabase client.
 * Simulates an unauthenticated browser visitor — used for RLS boundary tests.
 */
export function getAnonClient(): SupabaseClient {
  if (!_anonClient) {
    _anonClient = createClient(SUPABASE_URL, SUPABASE_ANON, {
      auth: { persistSession: false, autoRefreshToken: false },
    });
  }
  return _anonClient;
}

/**
 * Returns an authenticated Supabase client for a given test user.
 * Signs in using email/password (the test account must already exist).
 */
export async function getAuthenticatedClient(
  email: string,
  password: string
): Promise<SupabaseClient> {
  const client = createClient(SUPABASE_URL, SUPABASE_ANON, {
    auth: { persistSession: false, autoRefreshToken: false },
  });
  const { error } = await client.auth.signInWithPassword({ email, password });
  if (error) throw new Error(`[e2e/supabase] Sign-in failed for ${email}: ${error.message}`);
  return client;
}
