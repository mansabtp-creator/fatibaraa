/**
 * e2e/helpers/gnf.ts
 *
 * GNF (Guinean Franc) integer precision helpers & assertion utilities.
 *
 * GNF is always an integer — no centimes, no decimal places.
 * Any floating-point value is a bug (e.g., JS 10000 * 0.95 = 9500.000000001).
 *
 * All arithmetic in this module uses integer-safe operations.
 */

/**
 * Assert that a value is a safe integer (no fractional component).
 * Throws an AssertionError with a descriptive message if not.
 */
export function assertGnfInteger(value: number, label: string): void {
  if (!Number.isFinite(value)) {
    throw new Error(`[GNF] ${label} is not finite: ${value}`);
  }
  if (!Number.isInteger(value)) {
    throw new Error(
      `[GNF] ${label} has decimal component — GNF must be an integer. ` +
      `Got: ${value} (fractional: ${value - Math.floor(value)})`
    );
  }
  if (value < 0) {
    throw new Error(`[GNF] ${label} is negative: ${value}`);
  }
}

/**
 * Calculate subtotal for a list of line items.
 * Uses integer arithmetic throughout.
 *
 * @param items  Array of { unit_price_gnf, quantity }
 * @returns      Integer subtotal in GNF
 */
export function calcSubtotal(items: Array<{ unit_price_gnf: number; quantity: number }>): number {
  const subtotal = items.reduce((acc, item) => {
    const lineTotal = Math.round(item.unit_price_gnf) * Math.round(item.quantity);
    return acc + lineTotal;
  }, 0);
  assertGnfInteger(subtotal, 'calcSubtotal result');
  return subtotal;
}

/**
 * Calculate order total = subtotal + delivery_fee.
 * Both inputs must be integers.
 */
export function calcOrderTotal(subtotalGnf: number, deliveryFeeGnf: number): number {
  assertGnfInteger(subtotalGnf,    'subtotal');
  assertGnfInteger(deliveryFeeGnf, 'delivery_fee');
  return subtotalGnf + deliveryFeeGnf;
}

/**
 * Apply a percentage discount to a subtotal.
 * Uses floor() — never round up discounts in the customer's favour.
 *
 * @param subtotalGnf  Integer subtotal
 * @param pct          Integer percentage (e.g., 10 for 10%)
 * @returns            Integer discount amount
 */
export function calcPercentageDiscount(subtotalGnf: number, pct: number): number {
  assertGnfInteger(subtotalGnf, 'subtotal for discount');
  if (pct < 0 || pct > 100) throw new Error(`[GNF] pct must be 0-100, got ${pct}`);
  return Math.floor(subtotalGnf * pct / 100);
}

/**
 * Vendor payout calculation (mirrors secure_process_order_financials).
 *
 * Formula:
 *   item_subtotal     = (order_total - delivery_fee) / (1 + commission_rate)
 *   platform_commission = ROUND(item_subtotal × commission_rate)
 *   vendor_payout     = ROUND(item_subtotal) - vendor_delivery_fee
 *
 * @param orderTotalGnf    Total paid by buyer
 * @param deliveryFeeGnf   Delivery fee component
 * @param commissionPct    Platform commission % (default 5)
 * @param vendorDeliveryFee Delivery fee owed by vendor (default 0)
 */
export function calcVendorPayout(
  orderTotalGnf: number,
  deliveryFeeGnf: number,
  commissionPct: number = 5,
  vendorDeliveryFee: number = 0,
): { itemSubtotal: number; platformCommission: number; vendorPayout: number } {
  const commissionRate = commissionPct / 100;
  const itemsRealValue = orderTotalGnf - deliveryFeeGnf;
  const itemSubtotal   = Math.round(itemsRealValue / (1 + commissionRate));
  const platformCommission = Math.round(itemSubtotal * commissionRate);
  const vendorPayout   = itemSubtotal - Math.round(vendorDeliveryFee);

  return { itemSubtotal, platformCommission, vendorPayout };
}

/**
 * Verify that a GNF value matches an expected integer exactly.
 * Provides a detailed diff message on failure.
 */
export function expectGnfEqual(actual: number, expected: number, label: string): void {
  assertGnfInteger(actual,   `actual ${label}`);
  assertGnfInteger(expected, `expected ${label}`);
  if (actual !== expected) {
    throw new Error(
      `[GNF] ${label} mismatch:\n` +
      `  Expected: ${expected.toLocaleString('fr-GN')} GNF\n` +
      `  Actual:   ${actual.toLocaleString('fr-GN')} GNF\n` +
      `  Diff:     ${(actual - expected).toLocaleString('fr-GN')} GNF`
    );
  }
}

/**
 * Verify multi-vendor cart split correctness.
 * The sum of all sub-order totals must equal the grand total.
 */
export function assertMultiVendorSplit(
  subOrders: Array<{ store_id: string; subtotal: number }>,
  grandTotal: number,
  label = 'multi-vendor split'
): void {
  const sum = subOrders.reduce((acc, s) => acc + s.subtotal, 0);
  if (sum !== grandTotal) {
    const breakdown = subOrders.map(s => `  store ${s.store_id}: ${s.subtotal}`).join('\n');
    throw new Error(
      `[GNF] ${label}: sub-order sum (${sum}) !== grand total (${grandTotal})\n${breakdown}`
    );
  }
}
