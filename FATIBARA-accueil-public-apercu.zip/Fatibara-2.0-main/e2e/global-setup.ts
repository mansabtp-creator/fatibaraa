/**
 * e2e/global-setup.ts
 *
 * Runs ONCE before all test suites.
 *
 * Responsibilities:
 *  1. Validate all required environment variables are present.
 *  2. Capture a "before" snapshot of fatiglobal store + products (Suite 6 baseline).
 *  3. Verify production Supabase is reachable.
 *  4. Write the snapshot to a temp file for globalTeardown to diff.
 *  5. Auto-bootstrap sweep-state.json if missing or stale (> 24h old),
 *     so phase1–phase4 tests run without requiring a manual setup-sweep.ts invocation.
 *
 * SAFETY: Snapshot steps are read-only. Sweep bootstrap creates isolated test
 * accounts that bypass the globalTeardown registry intentionally (persistent
 * across suite runs for phase continuity).
 */

import { getServiceClient } from './helpers/supabase.js';
import * as fs   from 'fs';
import * as path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const SNAPSHOT_PATH  = path.join(__dirname, '..', 'playwright-results', 'fatiglobal-snapshot.json');
const STATE_FILE     = path.join(__dirname, '..', 'sweep-state.json');
const SWEEP_MAX_AGE_MS = 24 * 60 * 60 * 1000; // 24 hours

// ── Sweep bootstrap constants (mirrors setup-sweep.ts) ───────────────────────
const TEST_DOMAIN   = 'e2e.fatibara-test.internal';
const TEST_PASS     = 'E2eTest!2026$Fatibara';
const PRODUCT_PRICE = 5_000;
const DELIVERY_FEE  = 10_000;
const ORDER_TOTAL   = PRODUCT_PRICE + DELIVERY_FEE;
const BUYER_WALLET  = 200_000;

// ── Check if sweep-state.json is fresh enough ─────────────────────────────────
function isSweepStateFresh(): boolean {
  if (!fs.existsSync(STATE_FILE)) return false;
  try {
    const state = JSON.parse(fs.readFileSync(STATE_FILE, 'utf-8'));
    if (!state.createdAt) return false;
    const age = Date.now() - new Date(state.createdAt).getTime();
    return age < SWEEP_MAX_AGE_MS;
  } catch {
    return false;
  }
}

// ── Bootstrap sweep accounts ──────────────────────────────────────────────────
async function bootstrapSweepAccounts(): Promise<void> {
  const svc = getServiceClient();
  const ts  = Date.now();
  const tag = `sweep_${ts}`;

  console.log(`  [globalSetup] Bootstrapping sweep accounts (tag: ${tag})...`);

  async function createSweepUser(role: string, extraProfile: Record<string, unknown> = {}) {
    const email = `${tag}_${role}@${TEST_DOMAIN}`;
    const { data, error } = await svc.auth.admin.createUser({
      email,
      password:      TEST_PASS,
      email_confirm: true,
      user_metadata: { full_name: `Sweep ${role} ${ts}` },
    });
    if (error || !data?.user) throw new Error(`[sweep] createUser(${role}) failed: ${error?.message}`);
    const id = data.user.id;

    await svc.from('profiles').upsert({
      id,
      full_name:      `Sweep ${role} ${ts}`,
      wallet_balance: role === 'buyer' ? BUYER_WALLET : 0,
      ...extraProfile,
    }, { onConflict: 'id', ignoreDuplicates: false });

    console.log(`  [sweep] ✅ ${role.padEnd(8)} | ${id.slice(0, 8)} | ${email}`);
    return { id, email, password: TEST_PASS };
  }

  // Buyer
  const buyer = await createSweepUser('buyer', {
    profile_type:   'client',
    wallet_balance: BUYER_WALLET,
  });

  // Vendor
  const vendor = await createSweepUser('vendor', { profile_type: 'vendor' });

  // Store
  const { data: storeData, error: storeErr } = await svc.from('stores').insert({
    owner_id:          vendor.id,
    store_name:        `Sweep Store ${ts}`,
    balance:           100_000,
    is_verified_store: false,
    store_status:      'active',
  }).select('id').single();
  if (storeErr) throw new Error(`[sweep] Store creation failed: ${storeErr.message}`);
  const storeId = storeData.id;

  // Product
  const { data: productData, error: prodErr } = await svc.from('products').insert({
    store_id:          storeId,
    title:             `Sweep Test Product ${ts}`,
    price_gnf:         PRODUCT_PRICE,
    stock_quantity:    100,
    is_active:         true,
    moderation_status: 'approved',
  }).select('id').single();
  if (prodErr) throw new Error(`[sweep] Product creation failed: ${prodErr.message}`);
  const productId = productData.id;

  // Courier
  const plate   = `SWP-${ts.toString().slice(-5)}-MC`;
  const phone   = `62${Math.floor(Math.random() * 9_000_000 + 1_000_000)}`;
  const courier = await createSweepUser('courier', {
    profile_type:         'courier',
    phone_number:         phone,
    license_plate_number: plate,
    vehicle_type:         'moto',
    is_courier_online:    false,
    wallet_balance:       0,
  });

  // Write state file
  const state = {
    tag,
    createdAt: new Date().toISOString(),
    ids: { buyerId: buyer.id, vendorId: vendor.id, courierId: courier.id, storeId, productId },
    credentials: {
      buyer:   { email: buyer.email,   password: TEST_PASS },
      vendor:  { email: vendor.email,  password: TEST_PASS },
      courier: { email: courier.email, password: TEST_PASS },
    },
    order: {
      id:          null as string | null,
      status:      null as string | null,
      deliveryOtp: null as string | null,
      total:       ORDER_TOTAL,
      deliveryFee: DELIVERY_FEE,
      productPrice: PRODUCT_PRICE,
    },
    phases: {
      phase1: { complete: false, timestamp: null as string | null, orderId: null as string | null },
      phase2: { complete: false, timestamp: null as string | null },
      phase3: { complete: false, timestamp: null as string | null },
      phase4: { complete: false, timestamp: null as string | null },
    },
  };

  fs.writeFileSync(STATE_FILE, JSON.stringify(state, null, 2), 'utf-8');
  console.log(`  [globalSetup] ✅ sweep-state.json written | tag=${tag}`);
}

// ── Main globalSetup ──────────────────────────────────────────────────────────
async function globalSetup() {
  console.log('\n╔══════════════════════════════════════════════════════╗');
  console.log('║  Fatibara E2E Suite — Global Setup                  ║');
  console.log('║  Target: https://www.fatibara.com                   ║');
  console.log('╚══════════════════════════════════════════════════════╝\n');

  // 1. Validate environment
  const required = [
    'VITE_SUPABASE_URL',
    'VITE_SUPABASE_ANON_KEY',
    'SUPABASE_SERVICE_ROLE_KEY',
  ];
  const missing = required.filter(k => !process.env[k]);
  if (missing.length > 0) {
    throw new Error(`[globalSetup] Missing required env vars: ${missing.join(', ')}`);
  }
  console.log('  ✅ Environment variables validated');

  // 2. Verify Supabase connectivity
  const svc = getServiceClient();
  const { error: pingErr } = await svc
    .from('platform_settings')
    .select('id')
    .limit(1);
  if (pingErr) {
    throw new Error(`[globalSetup] Supabase connectivity check failed: ${pingErr.message}`);
  }
  console.log('  ✅ Supabase connectivity verified');

  // 3. Auto-bootstrap sweep-state.json if missing or stale
  if (!isSweepStateFresh()) {
    console.log('  ⚡ sweep-state.json missing or stale — auto-bootstrapping...');
    // Remove stale file first so phase tests skip cleanly if bootstrap fails
    // rather than crashing with "Invalid login credentials" on deleted accounts.
    if (fs.existsSync(STATE_FILE)) {
      fs.unlinkSync(STATE_FILE);
      console.log('  ✗ Removed stale sweep-state.json');
    }
    try {
      await bootstrapSweepAccounts();
    } catch (err: any) {
      // Non-fatal: phase tests will still fail, but other suites can run
      console.warn(`  ⚠️  sweep bootstrap failed: ${err.message}`);
      console.warn('     → Run `npx tsx setup-sweep.ts` manually if phase tests need to run.');
    }
  } else {
    const state = JSON.parse(fs.readFileSync(STATE_FILE, 'utf-8'));
    console.log(`  ✅ sweep-state.json found (tag: ${state.tag}, age: ${
      Math.round((Date.now() - new Date(state.createdAt).getTime()) / 60_000)
    }m)`);
  }

  // 4. Capture fatiglobal snapshot (read-only)
  const { data: stores, error: storeErr } = await svc
    .from('stores')
    .select('id, store_name, balance, is_verified_store, store_status')
    .ilike('store_name', 'FATIGLOBAL');

  if (storeErr) {
    console.warn(`[globalSetup] Could not snapshot fatiglobal stores: ${storeErr.message}`);
  }

  let productSnapshot: any[] = [];
  if (stores && stores.length > 0) {
    const storeId = stores[0].id;
    const { data: products, error: prodErr } = await svc
      .from('products')
      .select('id, title, price_gnf, stock_quantity, is_active, moderation_status')
      .eq('store_id', storeId)
      .order('id');

    if (!prodErr) productSnapshot = products ?? [];
  }

  // Ensure output dir exists
  fs.mkdirSync(path.dirname(SNAPSHOT_PATH), { recursive: true });

  const snapshot = {
    capturedAt:   new Date().toISOString(),
    stores:       stores ?? [],
    products:     productSnapshot,
    productCount: productSnapshot.length,
  };

  fs.writeFileSync(SNAPSHOT_PATH, JSON.stringify(snapshot, null, 2), 'utf8');
  console.log(`  ✅ fatiglobal snapshot captured: ${productSnapshot.length} products, ${(stores ?? []).length} stores`);
  console.log(`     Written to: ${SNAPSHOT_PATH}`);

  console.log('\n  🚀 Global setup complete — running test suites...\n');
}

export default globalSetup;
