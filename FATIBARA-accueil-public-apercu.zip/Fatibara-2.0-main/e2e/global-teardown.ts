/**
 * e2e/global-teardown.ts
 *
 * Runs ONCE after all test suites complete.
 *
 * Responsibilities:
 *  1. Delete all isolated test accounts / stores / orders created during the run.
 *  2. Re-read the fatiglobal snapshot and diff against current state.
 *  3. Report any unexpected mutations to fatiglobal data (integrity assertion).
 *
 * SAFETY: Only deletes rows matching the e2e_ prefix pattern.
 *         fatiglobal data is NEVER touched.
 */

import { getServiceClient } from './helpers/supabase.js';
import * as fs   from 'fs';
import * as path from 'path';
import { fileURLToPath } from 'url';

const __dirname     = path.dirname(fileURLToPath(import.meta.url));
const SNAPSHOT_PATH = path.join(__dirname, '..', 'playwright-results', 'fatiglobal-snapshot.json');

async function globalTeardown() {
  console.log('\n╔══════════════════════════════════════════════════════╗');
  console.log('║  Fatibara E2E Suite — Global Teardown               ║');
  console.log('╚══════════════════════════════════════════════════════╝\n');

  const svc = getServiceClient();

  // ── 1. Delete all isolated test accounts (e2e_*@fatibara.test) ────────────
  try {
    const { data: users } = await svc.auth.admin.listUsers({ perPage: 500 });
    const testUsers = (users?.users ?? []).filter(u =>
      u.email?.endsWith('@fatibara.test') && u.email?.startsWith('e2e_')
    );

    console.log(`  🗑️  Cleaning up ${testUsers.length} test accounts...`);

    for (const user of testUsers) {
      // Cleanup associated test stores
      const { data: testStores } = await svc
        .from('stores')
        .select('id')
        .eq('owner_id', user.id);

      if (testStores && testStores.length > 0) {
        const storeIds = testStores.map((s: any) => s.id);

        // Cleanup in dependency order
        const { data: storeOrders } = await svc
          .from('orders')
          .select('id')
          .in('store_id', storeIds);

        if (storeOrders && storeOrders.length > 0) {
          const orderIds = storeOrders.map((o: any) => o.id);
          await svc.from('order_items').delete().in('order_id', orderIds);
          await svc.from('orders').delete().in('id', orderIds);
        }

        await svc.from('products').delete().in('store_id', storeIds);
        await svc.from('wallet_transactions').delete().in('store_id', storeIds);
        await svc.from('withdrawals').delete().in('store_id', storeIds);
        await svc.from('stores').delete().in('id', storeIds);
      }

      // Cleanup buyer orders
      const { data: buyerOrders } = await svc
        .from('orders')
        .select('id')
        .eq('user_id', user.id)
        .like('tracking_number', 'ORD-E2E-%');

      if (buyerOrders && buyerOrders.length > 0) {
        const orderIds = buyerOrders.map((o: any) => o.id);
        await svc.from('order_items').delete().in('order_id', orderIds);
        await svc.from('wallet_transactions').delete().in('profile_id', [user.id]);
        await svc.from('orders').delete().in('id', orderIds);
      }

      // Finally delete the auth user (cascades profile row)
      await svc.auth.admin.deleteUser(user.id);
    }

    console.log(`  ✅ ${testUsers.length} test accounts cleaned up`);
  } catch (err: any) {
    console.error(`  ⚠️  Teardown error (non-fatal): ${err.message}`);
  }

  // ── 2. fatiglobal integrity diff ──────────────────────────────────────────
  console.log('\n  🔍 Running fatiglobal integrity diff...');

  let integrityPassed = true;

  try {
    if (!fs.existsSync(SNAPSHOT_PATH)) {
      console.warn('  ⚠️  No fatiglobal snapshot found — integrity check skipped');
    } else {
      const before = JSON.parse(fs.readFileSync(SNAPSHOT_PATH, 'utf8'));

      // Re-read current state
      const { data: currentStores } = await svc
        .from('stores')
        .select('id, store_name, balance, is_verified_store, store_status')
        .ilike('store_name', 'FATIGLOBAL');

      let currentProducts: any[] = [];
      if (currentStores && currentStores.length > 0) {
        const { data: prods } = await svc
          .from('products')
          .select('id, title, price_gnf, stock_quantity, is_active, moderation_status')
          .eq('store_id', currentStores[0].id)
          .order('id');
        currentProducts = prods ?? [];
      }

      const issues: string[] = [];

      // Store count
      if ((currentStores?.length ?? 0) !== before.stores.length) {
        issues.push(
          `Store count changed: before=${before.stores.length}, after=${currentStores?.length ?? 0}`
        );
      }

      // Store balance unchanged
      for (const beforeStore of before.stores) {
        const afterStore = (currentStores ?? []).find((s: any) => s.id === beforeStore.id);
        if (!afterStore) {
          issues.push(`Store MISSING after tests: ${beforeStore.store_name} (${beforeStore.id})`);
        } else if (afterStore.balance !== beforeStore.balance) {
          issues.push(
            `Store balance changed for ${beforeStore.store_name}: ` +
            `before=${beforeStore.balance}, after=${afterStore.balance}`
          );
        } else if (!afterStore.is_verified_store && beforeStore.is_verified_store) {
          issues.push(`Store is_verified_store was REVOKED for ${beforeStore.store_name}`);
        }
      }

      // Product count
      if (currentProducts.length !== before.productCount) {
        issues.push(
          `Product count changed: before=${before.productCount}, after=${currentProducts.length}`
        );
      }

      // Product price integrity
      for (const beforeProd of before.products) {
        const afterProd = currentProducts.find((p: any) => p.id === beforeProd.id);
        if (!afterProd) {
          issues.push(`Product MISSING after tests: "${beforeProd.title}" (${beforeProd.id})`);
        } else if (afterProd.price_gnf !== beforeProd.price_gnf) {
          issues.push(
            `Product price_gnf changed: "${beforeProd.title}" ` +
            `before=${beforeProd.price_gnf}, after=${afterProd.price_gnf}`
          );
        }
      }

      if (issues.length === 0) {
        console.log('  ✅ fatiglobal integrity: PASSED — 0 mutations detected');
      } else {
        integrityPassed = false;
        console.error('  ❌ fatiglobal integrity: FAILED');
        issues.forEach(issue => console.error(`     • ${issue}`));
      }
    }
  } catch (err: any) {
    console.error(`  ⚠️  Integrity diff error: ${err.message}`);
  }

  console.log('\n  🏁 Global teardown complete.');

  if (!integrityPassed) {
    throw new Error(
      '[globalTeardown] fatiglobal data integrity check FAILED — check output above for mutations!'
    );
  }
}

export default globalTeardown;
