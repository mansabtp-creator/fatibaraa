/**
 * e2e/tests/02-cart-math.spec.ts
 *
 * Suite 2: Monetary Calculations & Cart Math Matrix
 *
 * Tests GNF integer precision throughout:
 *  - Subtotal = Σ(unit_price × qty)
 *  - Total    = subtotal + delivery_fee
 *  - Percentage & fixed discount math
 *  - Multi-vendor cart split integrity
 *  - No floating-point drift in any stored price_gnf
 *
 * Strategy: Query live product prices from production DB, then exercise
 * all math in-process. No UI cart interaction needed for math matrix.
 */

import { test, expect } from '@playwright/test';
import { getServiceClient, getAnonClient } from '../helpers/supabase.js';
import {
  calcSubtotal,
  calcOrderTotal,
  calcPercentageDiscount,
  calcVendorPayout,
  assertGnfInteger,
  expectGnfEqual,
  assertMultiVendorSplit,
} from '../helpers/gnf.js';

test.describe('Suite 2 — Monetary Calculations & Cart Math Matrix', () => {
  // ── 2.1 All product prices are integers ────────────────────────────────────
  test('All products have integer price_gnf (no floating-point drift)', async () => {
    const svc = getServiceClient();
    const { data, error } = await svc
      .from('products')
      .select('id, title, price_gnf')
      .eq('is_active', true)
      .limit(100);

    expect(error).toBeNull();
    expect(data).not.toBeNull();
    expect(data!.length).toBeGreaterThan(0);

    const violations: string[] = [];
    for (const product of data!) {
      const price = Number(product.price_gnf);
      if (!Number.isInteger(price) || price < 0) {
        violations.push(`"${product.title}" (${product.id}): price_gnf=${price}`);
      }
    }

    expect(
      violations,
      `Found non-integer price_gnf values:\n${violations.join('\n')}`
    ).toHaveLength(0);

    console.log(`  ✅ Validated ${data!.length} product prices — all integers`);
  });

  // ── 2.2 Subtotal calculation ────────────────────────────────────────────────
  test('Subtotal = Σ(unit_price × quantity) with integer precision', async () => {
    // Use a deterministic set of prices to test the math
    const lineItems = [
      { unit_price_gnf: 50_000, quantity: 2 },   // 100,000
      { unit_price_gnf: 120_000, quantity: 1 },  // 120,000
      { unit_price_gnf: 35_000, quantity: 3 },   // 105,000
    ];
    const expected = 100_000 + 120_000 + 105_000; // 325,000

    const actual = calcSubtotal(lineItems);
    expectGnfEqual(actual, expected, 'subtotal');
    console.log(`  ✅ Subtotal: ${actual.toLocaleString('fr-GN')} GNF (expected ${expected.toLocaleString('fr-GN')})`);
  });

  test('Subtotal with single-item quantity=1 equals unit price', async () => {
    const price = 75_000;
    const result = calcSubtotal([{ unit_price_gnf: price, quantity: 1 }]);
    expectGnfEqual(result, price, 'single-item subtotal');
  });

  test('Subtotal with zero items is 0', async () => {
    const result = calcSubtotal([]);
    expectGnfEqual(result, 0, 'empty cart subtotal');
  });

  // ── 2.3 Order total = subtotal + delivery ──────────────────────────────────
  test('Order total = subtotal + delivery_fee (integer math)', async () => {
    const subtotal     = 325_000;
    const deliveryFee  = 15_000;
    const expected     = 340_000;

    const actual = calcOrderTotal(subtotal, deliveryFee);
    expectGnfEqual(actual, expected, 'order total');
  });

  test('Order total with zero delivery fee equals subtotal', async () => {
    const subtotal = 200_000;
    const actual   = calcOrderTotal(subtotal, 0);
    expectGnfEqual(actual, subtotal, 'order total (no delivery)');
  });

  // ── 2.4 Percentage discount math ──────────────────────────────────────────
  test('10% discount on 100,000 GNF = exactly 10,000 GNF', async () => {
    const discount = calcPercentageDiscount(100_000, 10);
    expectGnfEqual(discount, 10_000, '10% discount');
  });

  test('5% discount on 325,000 GNF = floor(16,250) = 16,250 GNF', async () => {
    const discount = calcPercentageDiscount(325_000, 5);
    expectGnfEqual(discount, 16_250, '5% discount');
  });

  test('Percentage discount result is always an integer (floor)', async () => {
    // 13% of 100,001 = 13,000.13 → must floor to 13,000
    const discount = calcPercentageDiscount(100_001, 13);
    assertGnfInteger(discount, '13% discount result');
    expect(discount).toBe(13_000);
    console.log(`  ✅ 13% of 100,001 GNF → floor(13,000.13) = ${discount} GNF (no drift)`);
  });

  test('Percentage discount never rounds UP (protects platform margin)', async () => {
    // Test edge case: 33% of 100 = 33.0 exactly
    const d1 = calcPercentageDiscount(100, 33);
    expect(d1).toBe(33);

    // 33% of 101 = 33.33 → floor = 33
    const d2 = calcPercentageDiscount(101, 33);
    expect(d2).toBe(33);
    assertGnfInteger(d2, '33% of 101');
  });

  // ── 2.5 Fixed-amount promo ─────────────────────────────────────────────────
  test('Fixed-amount discount applied correctly', async () => {
    const subtotal    = 200_000;
    const fixedDisc   = 25_000;
    const discounted  = subtotal - fixedDisc;
    assertGnfInteger(discounted, 'fixed discount result');
    expectGnfEqual(discounted, 175_000, 'post-discount subtotal');
  });

  test('Fixed discount cannot exceed subtotal (zero floor)', async () => {
    const subtotal  = 10_000;
    const fixedDisc = 15_000;
    const result    = Math.max(0, subtotal - fixedDisc);
    assertGnfInteger(result, 'clamped fixed discount');
    expect(result).toBe(0);
  });

  // ── 2.6 Vendor payout formula (mirrors SQL ROUND()) ────────────────────────
  test('Vendor payout = item_subtotal − commission (5%) for no-delivery order', async () => {
    const orderTotal    = 100_000;
    const deliveryFee   = 0;
    const commissionPct = 5;

    const { itemSubtotal, platformCommission, vendorPayout } = calcVendorPayout(
      orderTotal, deliveryFee, commissionPct
    );

    // item_subtotal = ROUND(100000 / 1.05) = ROUND(95238.0952...) = 95238
    expect(itemSubtotal).toBe(95238);
    // commission = ROUND(95238 * 0.05) = ROUND(4761.9) = 4762
    expect(platformCommission).toBe(4762);
    // vendor_payout = 95238 - 0 = 95238
    expect(vendorPayout).toBe(95238);

    // Sanity: payout + commission ≈ order_total (rounding diff ≤ 1 GNF)
    const diff = Math.abs((vendorPayout + platformCommission) - orderTotal);
    expect(diff).toBeLessThanOrEqual(1);

    console.log(
      `  ✅ Payout math: total=${orderTotal} → vendor=${vendorPayout}, ` +
      `commission=${platformCommission}, diff=${diff} GNF`
    );
  });

  test('Platform commission is always rounded (ROUND, not floor/ceil)', async () => {
    // Test that our helper matches Postgres ROUND() semantics
    // 5% of 95238 = 4761.9 → ROUND = 4762
    const { platformCommission } = calcVendorPayout(100_000, 0, 5);
    assertGnfInteger(platformCommission, 'platform commission');
    expect(platformCommission).toBe(4762);
  });

  // ── 2.7 Multi-vendor cart split ────────────────────────────────────────────
  test('Multi-vendor cart: sub-orders sum to grand total', async () => {
    // Simulate a cart with items from 2 different stores
    const storeAItems = [
      { unit_price_gnf: 80_000, quantity: 1 },
      { unit_price_gnf: 20_000, quantity: 2 },
    ];
    const storeBItems = [
      { unit_price_gnf: 150_000, quantity: 1 },
    ];

    const subtotalA    = calcSubtotal(storeAItems);  // 120,000
    const subtotalB    = calcSubtotal(storeBItems);  // 150,000
    const grandTotal   = subtotalA + subtotalB;      // 270,000

    assertMultiVendorSplit(
      [
        { store_id: 'store-a', subtotal: subtotalA },
        { store_id: 'store-b', subtotal: subtotalB },
      ],
      grandTotal
    );

    expectGnfEqual(subtotalA, 120_000, 'Store A subtotal');
    expectGnfEqual(subtotalB, 150_000, 'Store B subtotal');
    expectGnfEqual(grandTotal, 270_000, 'Grand total');

    console.log(
      `  ✅ Multi-vendor split: A=${subtotalA.toLocaleString('fr-GN')} + ` +
      `B=${subtotalB.toLocaleString('fr-GN')} = ${grandTotal.toLocaleString('fr-GN')} GNF`
    );
  });

  test('Multi-vendor split: mismatched sum throws assertion error', async () => {
    expect(() => {
      assertMultiVendorSplit(
        [
          { store_id: 'store-a', subtotal: 100_000 },
          { store_id: 'store-b', subtotal: 200_000 },
        ],
        350_000  // Wrong total (should be 300,000)
      );
    }).toThrow('GNF');
  });

  // ── 2.8 Live DB: Sample product price sanity ──────────────────────────────
  test('Live products: fatiglobal prices are positive integers', async () => {
    const anon = getAnonClient();
    const { data: stores } = await anon
      .from('stores')
      .select('id')
      .ilike('store_name', 'FATIGLOBAL')
      .limit(1);

    if (!stores || stores.length === 0) {
      console.log('  ⚠️  fatiglobal store not found — skipping live price check');
      return;
    }

    const { data: products, error } = await anon
      .from('products')
      .select('id, title, price_gnf')
      .eq('store_id', stores[0].id)
      .eq('is_active', true)
      .limit(20);

    expect(error).toBeNull();
    console.log(`  Checking ${products?.length ?? 0} fatiglobal products...`);

    for (const product of products ?? []) {
      const price = Number(product.price_gnf);
      assertGnfInteger(price, `"${product.title}" price_gnf`);
      expect(price).toBeGreaterThan(0);
    }

    console.log(`  ✅ All ${products?.length ?? 0} fatiglobal prices are valid integers`);
  });

  // ── 2.9 Floating-point attack simulation ──────────────────────────────────
  test('Floating-point drift scenario: 1/3 price must be rounded', async () => {
    // Simulates a 1/3 discount applied to a weird price — must always be integer
    const subtotal = 100_001;
    const pct = 33;
    const discount = calcPercentageDiscount(subtotal, pct);
    assertGnfInteger(discount, `${pct}% discount on ${subtotal}`);
    // 100_001 * 33 / 100 = 33000.33 → floor = 33000
    expect(discount).toBe(33_000);
  });

  test('JS floating-point multiplication does not leak into GNF subtotals', async () => {
    // Known JS float trap: 0.1 + 0.2 !== 0.3
    // Our calcSubtotal must avoid this entirely by using Math.round on each line
    const items = [
      { unit_price_gnf: 33_333, quantity: 3 },  // 99999 — exact
    ];
    const result = calcSubtotal(items);
    assertGnfInteger(result, 'subtotal with × 3');
    expect(result).toBe(99_999);
  });
});
