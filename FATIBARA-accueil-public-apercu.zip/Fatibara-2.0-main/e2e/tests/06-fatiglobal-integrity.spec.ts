/**
 * e2e/tests/06-fatiglobal-integrity.spec.ts
 *
 * Suite 6: fatiglobal Vendor Data Integrity
 *
 * This suite verifies that the fatiglobal store and all its data
 * remain completely intact and unmodified throughout the E2E test run.
 *
 * ALL operations are READ-ONLY.
 * This suite runs in isolation — it never creates or modifies any data.
 *
 * Verifies:
 *  - fatiglobal store exists with correct slug
 *  - Store has is_verified_store = true
 *  - All products have positive integer price_gnf
 *  - Product count matches the pre-run snapshot (set in globalSetup)
 *  - No product prices were modified
 *  - Store balance unchanged
 */

import { test, expect } from '@playwright/test';
import { getServiceClient, getAnonClient } from '../helpers/supabase.js';
import { assertGnfInteger } from '../helpers/gnf.js';
import * as fs   from 'fs';
import * as path from 'path';
import { fileURLToPath } from 'url';

const __dirname     = path.dirname(fileURLToPath(import.meta.url));
const SNAPSHOT_PATH = path.join(__dirname, '../../playwright-results/fatiglobal-snapshot.json');

test.describe('Suite 6 — fatiglobal Vendor Data Integrity', () => {
  let storeId:   string | null = null;
  let storeData: any           = null;
  let products:  any[]         = [];
  let snapshot:  any           = null;

  test.beforeAll(async () => {
    const svc = getServiceClient();

    // Load pre-run snapshot
    if (fs.existsSync(SNAPSHOT_PATH)) {
      try {
        snapshot = JSON.parse(fs.readFileSync(SNAPSHOT_PATH, 'utf8'));
        console.log(
          `\n  [Suite 6] Loaded snapshot from ${snapshot.capturedAt}: ` +
          `${snapshot.productCount} products, ${snapshot.stores.length} stores`
        );
      } catch (e: any) {
        console.warn(`  [Suite 6] Could not parse snapshot: ${e.message}`);
      }
    } else {
      console.warn(`  [Suite 6] Snapshot not found at ${SNAPSHOT_PATH} — cross-run diff disabled`);
    }

    // Fetch current state
    const { data: stores, error: storeErr } = await svc
      .from('stores')
      .select('id, store_name, balance, is_verified_store, store_status')
      .ilike('store_name', 'FATIGLOBAL');

    if (storeErr) {
      console.warn(`  [Suite 6] Store query error: ${storeErr.message}`);
    } else if (stores && stores.length > 0) {
      storeData = stores[0];
      storeId   = stores[0].id;
    }

    if (storeId) {
      const { data: prods, error: prodErr } = await svc
        .from('products')
        .select('id, title, price_gnf, stock_quantity, is_active, moderation_status')
        .eq('store_id', storeId)
        .order('id');

      if (!prodErr) {
        products = prods ?? [];
      } else {
        console.warn(`  [Suite 6] Products query error: ${prodErr.message}`);
      }
    }
  });

  // ── 6.1 Store existence ────────────────────────────────────────────────────
  test('fatiglobal store exists in the database', async () => {
    expect(
      storeData,
      'fatiglobal store not found — no store with name FATIGLOBAL found in stores table'
    ).not.toBeNull();

    expect(storeData.store_name.toUpperCase()).toBe('FATIGLOBAL');
    console.log(`  ✅ fatiglobal store found: "${storeData.store_name}" (${storeData.id})`);
  });

  test('fatiglobal store is_verified_store = true', async () => {
    if (!storeData) {
      console.log('  ⚠️  fatiglobal not found — skipping');
      return;
    }
    expect(
      storeData.is_verified_store,
      `fatiglobal is_verified_store should be true, got: ${storeData.is_verified_store}`
    ).toBe(true);
    console.log('  ✅ fatiglobal is_verified_store = true');
  });

  test('fatiglobal store is_active = true', async () => {
    if (!storeData) { return; }
    // stores table uses store_status (text) not is_active (boolean)
    expect(storeData.store_status).toBe('active');
    console.log(`  ✅ fatiglobal store_status = '${storeData.store_status}'`);
  });

  // ── 6.2 Store visibility to anon ──────────────────────────────────────────
  test('fatiglobal store is publicly visible (anon can read)', async () => {
    const anon = getAnonClient();
    const { data, error } = await anon
      .from('stores')
      .select('id, store_name, is_verified_store')
      .ilike('store_name', 'FATIGLOBAL')
      .single();

    expect(error).toBeNull();
    expect(data).not.toBeNull();
    expect(data!.store_name.toUpperCase()).toBe('FATIGLOBAL');
    console.log(`  ✅ fatiglobal publicly visible to anon: "${data!.store_name}"`);
  });

  // ── 6.3 Product count ─────────────────────────────────────────────────────
  test('fatiglobal has at least 1 product', async () => {
    if (!storeId) {
      console.log('  ⚠️  fatiglobal not found — skipping');
      return;
    }
    expect(products.length).toBeGreaterThan(0);
    console.log(`  ✅ fatiglobal product count: ${products.length}`);
  });

  // ── 6.4 Product price integrity ───────────────────────────────────────────
  test('All fatiglobal products have positive integer price_gnf', async () => {
    if (!storeId || products.length === 0) {
      console.log('  ⚠️  No products to check — skipping');
      return;
    }

    const violations: string[] = [];
    for (const product of products) {
      const price = Number(product.price_gnf);
      try {
        assertGnfInteger(price, `"${product.title}"`);
        if (price <= 0) {
          violations.push(`"${product.title}" (${product.id}): price_gnf=${price} is not positive`);
        }
      } catch (e: any) {
        violations.push(e.message);
      }
    }

    expect(
      violations,
      `fatiglobal price integrity violations:\n${violations.join('\n')}`
    ).toHaveLength(0);

    console.log(`  ✅ All ${products.length} fatiglobal products have valid integer prices`);
  });

  test('All fatiglobal products have moderation_status approved or null', async () => {
    if (!storeId || products.length === 0) { return; }

    const rejectedProducts = products.filter(p =>
      p.moderation_status && p.moderation_status === 'rejected'
    );

    if (rejectedProducts.length > 0) {
      console.warn(
        `  ⚠️  ${rejectedProducts.length} fatiglobal products have rejected moderation status`
      );
    } else {
      console.log('  ✅ No fatiglobal products are rejected');
    }

    // This is a warning, not a hard failure — moderation is a platform concern
  });

  // ── 6.5 Snapshot diff ─────────────────────────────────────────────────────
  test('fatiglobal product count unchanged from pre-run snapshot', async () => {
    if (!snapshot) {
      console.log('  ⚠️  No snapshot available — skipping count diff');
      return;
    }
    if (!storeId) {
      console.log('  ⚠️  fatiglobal not found — skipping');
      return;
    }

    expect(
      products.length,
      `Product count changed: snapshot=${snapshot.productCount}, current=${products.length}`
    ).toBe(snapshot.productCount);

    console.log(
      `  ✅ Product count unchanged: ${snapshot.productCount} (snapshot) = ${products.length} (current)`
    );
  });

  test('No fatiglobal product price_gnf was modified during tests', async () => {
    if (!snapshot || !storeId || products.length === 0) {
      console.log('  ⚠️  Cannot diff prices — no snapshot or no products');
      return;
    }

    const snapshotProducts: any[] = snapshot.products ?? [];
    const priceChanges: string[]  = [];

    for (const snapProd of snapshotProducts) {
      const current = products.find(p => p.id === snapProd.id);
      if (!current) {
        priceChanges.push(`Product MISSING: "${snapProd.title}" (${snapProd.id})`);
      } else if (Number(current.price_gnf) !== Number(snapProd.price_gnf)) {
        priceChanges.push(
          `Price changed: "${snapProd.title}" ` +
          `snapshot=${snapProd.price_gnf} → current=${current.price_gnf}`
        );
      }
    }

    expect(
      priceChanges,
      `fatiglobal price mutations detected:\n${priceChanges.join('\n')}`
    ).toHaveLength(0);

    console.log(
      `  ✅ All ${snapshotProducts.length} fatiglobal product prices unchanged`
    );
  });

  test('fatiglobal store balance unchanged from pre-run snapshot', async () => {
    if (!snapshot || !storeData) {
      console.log('  ⚠️  No snapshot or store data — skipping balance diff');
      return;
    }

    const snapStore = snapshot.stores.find((s: any) => s.store_slug === 'fatiglobal');
    if (!snapStore) {
      console.log('  ⚠️  fatiglobal not in snapshot — skipping');
      return;
    }

    expect(
      Number(storeData.balance),
      `Store balance changed: snapshot=${snapStore.balance}, current=${storeData.balance}`
    ).toBe(Number(snapStore.balance));

    console.log(
      `  ✅ fatiglobal store balance unchanged: ${storeData.balance} GNF`
    );
  });

  // ── 6.6 Products publicly accessible ─────────────────────────────────────
  test('fatiglobal products are publicly readable by anon', async () => {
    if (!storeId) { return; }

    const anon = getAnonClient();
    const { data, error } = await anon
      .from('products')
      .select('id, title, price_gnf')
      .eq('store_id', storeId)
      .eq('is_active', true)
      .limit(10);

    expect(error).toBeNull();
    expect(data).not.toBeNull();
    expect((data ?? []).length).toBeGreaterThan(0);

    console.log(
      `  ✅ ${data!.length} fatiglobal products publicly readable by anon`
    );
  });

  // ── 6.7 No e2e_ contamination in fatiglobal ─────────────────────────────
  test('No e2e_ test data leaked into fatiglobal store', async () => {
    if (!storeId) { return; }

    const svc = getServiceClient();
    const { data: e2eProducts } = await svc
      .from('products')
      .select('id, title')
      .eq('store_id', storeId)
      .like('title', 'E2E%');

    const leaked = (e2eProducts ?? []).length;
    expect(leaked).toBe(0);
    console.log(
      `  ✅ No E2E test products found in fatiglobal store (${leaked} contaminations)`
    );
  });

  test('No e2e_ test orders reference fatiglobal store', async () => {
    if (!storeId) { return; }

    const svc = getServiceClient();
    const { data: e2eOrders } = await svc
      .from('orders')
      .select('id, tracking_number')
      .eq('store_id', storeId)
      .like('tracking_number', 'ORD-E2E-%');

    const leaked = (e2eOrders ?? []).length;
    expect(leaked).toBe(0);
    console.log(
      `  ✅ No E2E test orders reference fatiglobal store (${leaked} contaminations)`
    );
  });
});
