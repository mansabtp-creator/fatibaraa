/**
 * e2e/tests/01-health.spec.ts
 *
 * Suite 1: Infrastructure & System Health
 * Target:  GET https://www.fatibara.com/api/health
 *
 * Verifies:
 *  - HTTP 200 response
 *  - { status: "ok" } payload
 *  - All health indicators: env (5 required keys), db (latency < 1000ms), vapid, resend
 */

import { test, expect } from '@playwright/test';

const HEALTH_URL = 'https://www.fatibara.com/api/health';

test.describe('Suite 1 — Infrastructure & System Health', () => {
  let healthBody: any;
  let responseStatus: number;
  let responseTime: number;

  // Single fetch, shared across all tests in this describe block
  test.beforeAll(async ({ request }) => {
    const t0  = Date.now();
    const res = await request.get(HEALTH_URL, {
      headers: { Accept: 'application/json' },
    });
    responseTime   = Date.now() - t0;
    responseStatus = res.status();
    healthBody     = await res.json();

    console.log('\n  Health endpoint response:');
    console.log(JSON.stringify(healthBody, null, 2));
    console.log(`  Round-trip time: ${responseTime}ms`);
  });

  // ── 1.1 HTTP status ────────────────────────────────────────────────────────
  test('GET /api/health returns HTTP 200', async () => {
    expect(
      responseStatus,
      `Expected 200 but got ${responseStatus}. Body: ${JSON.stringify(healthBody)}`
    ).toBe(200);
  });

  // ── 1.2 Payload structure ──────────────────────────────────────────────────
  test('Response body has status: "ok"', async () => {
    expect(healthBody).toHaveProperty('status', 'ok');
  });

  test('Response body has a valid ISO timestamp', async () => {
    expect(healthBody).toHaveProperty('timestamp');
    const ts = new Date(healthBody.timestamp);
    expect(
      ts.getTime(),
      `timestamp is not a valid ISO date: ${healthBody.timestamp}`
    ).not.toBeNaN();
  });

  test('Response body has a version field', async () => {
    expect(healthBody).toHaveProperty('version');
    expect(typeof healthBody.version).toBe('string');
  });

  test('Response body has a checks object', async () => {
    expect(healthBody).toHaveProperty('checks');
    expect(typeof healthBody.checks).toBe('object');
  });

  // ── 1.3 Environment check ──────────────────────────────────────────────────
  test('checks.env is present', async () => {
    expect(healthBody.checks).toHaveProperty('env');
  });

  test('checks.env has an ok field (boolean)', async () => {
    expect(typeof healthBody.checks.env?.ok).toBe('boolean');
  });

  test('checks.env has a message field', async () => {
    expect(typeof healthBody.checks.env?.message).toBe('string');
    // Log — env may be "degraded" on hobby plan (expected for some optional keys)
    console.log(`  [env] ${healthBody.checks.env.message}`);
  });

  // ── 1.4 Database check ────────────────────────────────────────────────────
  test('checks.db is present', async () => {
    expect(healthBody.checks).toHaveProperty('db');
  });

  test('checks.db.ok is true (Supabase reachable)', async () => {
    expect(healthBody.checks.db?.ok).toBe(true);
  });

  test('checks.db.latency is reported', async () => {
    expect(typeof healthBody.checks.db?.latency).toBe('number');
  });

  test('checks.db.latency < 1000ms (performance budget)', async () => {
    const latency = healthBody.checks.db?.latency ?? 9999;
    expect(
      latency,
      `DB latency ${latency}ms exceeds 1000ms budget`
    ).toBeLessThan(1000);
    console.log(`  [db] Supabase latency: ${latency}ms`);
  });

  // ── 1.5 VAPID check ────────────────────────────────────────────────────────
  test('checks.vapid is present', async () => {
    expect(healthBody.checks).toHaveProperty('vapid');
  });

  test('checks.vapid has a message (regardless of ok status)', async () => {
    expect(typeof healthBody.checks.vapid?.message).toBe('string');
    const status = healthBody.checks.vapid?.ok ? '✅' : '⚠️';
    console.log(`  [vapid] ${status} ${healthBody.checks.vapid.message}`);
  });

  // ── 1.6 Resend check ───────────────────────────────────────────────────────
  test('checks.resend is present', async () => {
    expect(healthBody.checks).toHaveProperty('resend');
  });

  test('checks.resend has a message (regardless of ok status)', async () => {
    expect(typeof healthBody.checks.resend?.message).toBe('string');
    const status = healthBody.checks.resend?.ok ? '✅' : '⚠️';
    console.log(`  [resend] ${status} ${healthBody.checks.resend.message}`);
  });

  // ── 1.7 Overall round-trip time ────────────────────────────────────────────
  test('Health endpoint round-trip < 5000ms', async () => {
    expect(
      responseTime,
      `Health check took ${responseTime}ms — network issue?`
    ).toBeLessThan(5000);
  });
});
