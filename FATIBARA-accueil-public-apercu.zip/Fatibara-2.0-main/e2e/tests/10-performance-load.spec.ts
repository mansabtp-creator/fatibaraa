/**
 * e2e/tests/10-performance-load.spec.ts
 * SECTION 10 — Performance & Load
 *
 * 10.1  Home page loads in < 8 seconds (LCP proxy via domcontentloaded)
 * 10.2  Product listing page loads in < 8 seconds
 * 10.3  Supabase query returns < 2 seconds for a paginated product list
 * 10.4  10 concurrent product reads complete without errors
 * 10.5  Order history query with 20 rows completes in < 3 seconds
 * 10.6  Notification fetch for 50 rows completes in < 2 seconds
 * 10.7  Vendor dashboard page loads in < 10 seconds (authenticated)
 * 10.8  /checkout page loads in < 10 seconds (authenticated)
 * 10.9  Search query with full-text filter responds in < 3 seconds
 * 10.10 Stress: 20 sequential profile reads complete without timeouts
 */

import { test, expect } from '@playwright/test';
import { getServiceClient, getAuthenticatedClient } from '../helpers/supabase.js';

const BASE_URL  = process.env.E2E_BASE_URL ?? 'https://www.fatibara.com';
const TEST_PASS = process.env.E2E_TEST_PASS ?? 'TestPass123!';
const TS        = Date.now().toString(36);

let userId    = '';
let userEmail = '';

async function injectSession(page: any, email: string, password: string) {
  const origin = new URL(BASE_URL).origin;
  if (!page.url().startsWith(origin)) {
    await page.goto(BASE_URL, { waitUntil: 'domcontentloaded', timeout: 45_000 });
  }
  const projectRef = new URL(process.env.VITE_SUPABASE_URL!).hostname.split('.')[0];
  const storageKey = `sb-${projectRef}-auth-token`;
  const svc = getServiceClient();
  const { data: signIn, error } = await svc.auth.signInWithPassword({ email, password });
  if (error) throw new Error(`injectSession: ${error.message}`);
  await page.evaluate(
    ([key, session]: [string, any]) => localStorage.setItem(key, JSON.stringify(session)),
    [storageKey, signIn.session]
  );
}

test.describe('SECTION 10 — Performance & Load', () => {
  test.beforeAll(async () => {
    test.setTimeout(120_000);
    const svc   = getServiceClient();
    const sleep = (ms: number) => new Promise(r => setTimeout(r, ms));

    for (let attempt = 0; attempt < 3; attempt++) {
      try {
        const email = `e2e_perf_${TS}_${attempt}@fatibara.test`;
        const { data, error } = await svc.auth.admin.createUser({
          email, password: TEST_PASS, email_confirm: true,
        });
        if (error) throw error;
        userId = data.user!.id; userEmail = email;
        await svc.from('profiles').upsert({
          id: userId, full_name: 'E2E Perf User',
          profile_type: 'client', wallet_balance: 0,
        }, { onConflict: 'id' });
        console.log(`  [§10 Setup] user=${userId.slice(0,8)}`);
        break;
      } catch (err: any) {
        console.warn(`  [§10 Setup] attempt ${attempt + 1} failed: ${err.message}`);
        if (attempt < 2) await sleep(3000);
        else console.error('  [§10 Setup] All retries failed — some tests will skip');
      }
    }
  });

  test.afterAll(async () => {
    const svc = getServiceClient();
    try {
      await Promise.allSettled([
        userId ? svc.from('profiles').delete().eq('id', userId)           : Promise.resolve(),
        userId ? svc.auth.admin.deleteUser(userId).catch(() => {})        : Promise.resolve(),
      ]);
    } catch { /* ignore */ }
    console.log('  [§10 Cleanup] done');
  });

  // ── 10.1 Home page load time ─────────────────────────────────────────────────
  test('10.1 — Home page loads within 8 seconds', async ({ page }) => {
    test.setTimeout(30_000);
    const t0 = Date.now();
    await page.goto(BASE_URL, { waitUntil: 'domcontentloaded', timeout: 20_000 });
    const elapsed = Date.now() - t0;
    expect(elapsed).toBeLessThan(8_000);
    // SPA may still be hydrating — just confirm the page responded
    const title = await page.title();
    console.log(`  ✅ 10.1 Home loaded in ${elapsed}ms | title: "${title}"`);
  });

  // ── 10.2 Product listing page ────────────────────────────────────────────────
  test('10.2 — Product listing page loads within 8 seconds', async ({ page }) => {
    test.setTimeout(30_000);
    const t0 = Date.now();
    await page.goto(`${BASE_URL}/products`, { waitUntil: 'domcontentloaded', timeout: 20_000 });
    const elapsed = Date.now() - t0;
    expect(elapsed).toBeLessThan(8_000);
    console.log(`  ✅ 10.2 /products loaded in ${elapsed}ms | url: ${page.url()}`);
  });

  // ── 10.3 Paginated product query performance ──────────────────────────────────
  test('10.3 — Paginated product DB query completes in < 2 seconds', async () => {
    test.setTimeout(10_000);
    const svc = getServiceClient();
    const t0 = Date.now();
    const { data, error } = await svc
      .from('products').select('id, title, price_gnf').eq('is_active', true)
      .range(0, 19).order('created_at', { ascending: false });
    const elapsed = Date.now() - t0;
    expect(error).toBeNull();
    expect(elapsed).toBeLessThan(2_000);
    console.log(`  ✅ 10.3 Product paginated query: ${elapsed}ms | rows: ${data?.length ?? 0}`);
  });

  // ── 10.4 10 concurrent product reads ─────────────────────────────────────────
  test('10.4 — 10 concurrent product reads complete without errors', async () => {
    test.setTimeout(20_000);
    const svc = getServiceClient();
    const t0 = Date.now();
    const requests = Array.from({ length: 10 }, (_, i) =>
      svc.from('products').select('id, title').eq('is_active', true).range(i * 2, i * 2 + 1)
    );
    const results = await Promise.all(requests);
    const elapsed = Date.now() - t0;
    const errors = results.filter(r => r.error !== null);
    expect(errors.length).toBe(0);
    expect(elapsed).toBeLessThan(8_000);
    console.log(`  ✅ 10.4 10 concurrent reads in ${elapsed}ms | errors: ${errors.length}`);
  });

  // ── 10.5 Order history query ──────────────────────────────────────────────────
  test('10.5 — Order history query (20 rows) completes in < 3 seconds', async () => {
    test.setTimeout(10_000);
    if (!userId) test.skip(true, 'Seed unavailable');

    const svc = getServiceClient();
    const t0 = Date.now();
    const { data, error } = await svc
      .from('orders').select('id, status, total_amount, created_at')
      .eq('user_id', userId).order('created_at', { ascending: false }).limit(20);
    const elapsed = Date.now() - t0;
    expect(error).toBeNull();
    expect(elapsed).toBeLessThan(3_000);
    console.log(`  ✅ 10.5 Order history query: ${elapsed}ms | rows: ${data?.length ?? 0}`);
  });

  // ── 10.6 Notification fetch (50 rows) ────────────────────────────────────────
  test('10.6 — Notification fetch (50 rows) completes in < 2 seconds', async () => {
    test.setTimeout(10_000);
    if (!userId) test.skip(true, 'Seed unavailable');

    const svc = getServiceClient();
    const t0 = Date.now();
    const { data, error } = await svc
      .from('notifications').select('id, type, title, is_read, created_at')
      .eq('user_id', userId).order('created_at', { ascending: false }).limit(50);
    const elapsed = Date.now() - t0;
    expect(error).toBeNull();
    expect(elapsed).toBeLessThan(2_000);
    console.log(`  ✅ 10.6 Notification fetch: ${elapsed}ms | rows: ${data?.length ?? 0}`);
  });

  // ── 10.7 Vendor dashboard page (authenticated) ───────────────────────────────
  test('10.7 — Vendor dashboard loads within 10 seconds (authenticated)', async ({ page }) => {
    test.setTimeout(60_000);
    if (!userEmail) test.skip(true, 'Seed unavailable');

    await injectSession(page, userEmail, TEST_PASS);
    const t0 = Date.now();
    await page.goto(`${BASE_URL}/vendor/dashboard`, { waitUntil: 'domcontentloaded', timeout: 30_000 });
    await page.waitForFunction(() => document.body.innerText.length > 20, { timeout: 10_000 }).catch(() => {});
    const elapsed = Date.now() - t0;
    expect(elapsed).toBeLessThan(10_000);
    console.log(`  ✅ 10.7 Vendor dashboard: ${elapsed}ms | url: ${page.url()}`);
  });

  // ── 10.8 Checkout page (authenticated) ───────────────────────────────────────
  test('10.8 — /checkout loads within 10 seconds (authenticated)', async ({ page }) => {
    test.setTimeout(60_000);
    if (!userEmail) test.skip(true, 'Seed unavailable');

    await injectSession(page, userEmail, TEST_PASS);
    const t0 = Date.now();
    await page.goto(`${BASE_URL}/checkout`, { waitUntil: 'domcontentloaded', timeout: 30_000 });
    await page.waitForFunction(() => document.body.innerText.length > 20, { timeout: 10_000 }).catch(() => {});
    const elapsed = Date.now() - t0;
    expect(elapsed).toBeLessThan(10_000);
    console.log(`  ✅ 10.8 /checkout: ${elapsed}ms | url: ${page.url()}`);
  });

  // ── 10.9 Full-text search performance ────────────────────────────────────────
  test('10.9 — Full-text product search responds in < 3 seconds', async () => {
    test.setTimeout(10_000);
    const svc = getServiceClient();

    const terms = ['téléphone', 'chaussure', 'robe'];
    for (const term of terms) {
      const t0 = Date.now();
      const { data, error } = await svc
        .from('products').select('id, title').ilike('title', `%${term}%`)
        .eq('is_active', true).limit(10);
      const elapsed = Date.now() - t0;
      // Allow Cloudflare WAF to intercept (not a performance failure)
      if (!error) {
        expect(elapsed).toBeLessThan(3_000);
        console.log(`  ✅ 10.9 Search "${term}": ${elapsed}ms | rows: ${data?.length ?? 0}`);
      } else {
        console.log(`  ⚠️ 10.9 Search "${term}" blocked (WAF): ${error.message.slice(0, 40)}`);
      }
    }
  });

  // ── 10.10 Stress: 20 sequential profile reads ─────────────────────────────────
  test('10.10 — 20 sequential profile reads complete without timeouts', async () => {
    test.setTimeout(60_000);
    if (!userId) test.skip(true, 'Seed unavailable');

    const svc = getServiceClient();
    const times: number[] = [];

    for (let i = 0; i < 20; i++) {
      const t0 = Date.now();
      const { error } = await svc
        .from('profiles').select('id, wallet_balance').eq('id', userId).single();
      const elapsed = Date.now() - t0;
      times.push(elapsed);
      if (error) {
        console.warn(`  ⚠️ 10.10 Read ${i + 1}/20 error: ${error.message}`);
      }
      // Small delay to avoid rate-limiting
      await new Promise(r => setTimeout(r, 50));
    }

    const avg = Math.round(times.reduce((a, b) => a + b, 0) / times.length);
    const max = Math.max(...times);
    expect(max).toBeLessThan(5_000); // No single read should exceed 5s
    console.log(`  ✅ 10.10 20 profile reads | avg: ${avg}ms | max: ${max}ms`);
  });
});
