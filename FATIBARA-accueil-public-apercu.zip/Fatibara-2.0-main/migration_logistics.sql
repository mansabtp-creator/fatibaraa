-- Migration to support Courier Assignments, Wallet Transactions and improved Statuses

-- 1. Enhance Profiles with Wallet
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS wallet_balance NUMERIC DEFAULT 0;

-- 2. Enhance Orders Table
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS courier_id UUID REFERENCES public.profiles(id) ON DELETE SET NULL;
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS delivery_otp TEXT;
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS tracking_number TEXT;
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS delivery_notes TEXT;
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS financial_status TEXT DEFAULT 'pending';
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS completed_at TIMESTAMPTZ;

-- 3. Handle Status Constraint Robustly
ALTER TABLE public.orders DROP CONSTRAINT IF EXISTS orders_status_check;

-- Cleanup existing data to match new constraint
UPDATE public.orders SET status = 'pending' WHERE status IS NULL;
UPDATE public.orders SET status = 'delivered' WHERE status = 'completed';
UPDATE public.orders SET status = 'in_transit' WHERE status = 'shipped';
UPDATE public.orders SET status = 'accepted' WHERE status = 'confirmed';

ALTER TABLE public.orders ADD CONSTRAINT orders_status_check 
CHECK (status IN ('pending', 'paid', 'accepted', 'preparing', 'ready_for_pickup', 'picked_up', 'in_transit', 'shipped', 'confirmed', 'arriving_soon', 'delivered', 'cancelled'));

-- 4. Create Wallet Transactions Table
CREATE TABLE IF NOT EXISTS public.wallet_transactions (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  profile_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE,
  store_id UUID REFERENCES public.stores(id) ON DELETE CASCADE,
  amount NUMERIC NOT NULL,
  type TEXT NOT NULL CHECK (type IN ('sale', 'delivery_fee', 'referral', 'withdrawal', 'refund')),
  reference_id UUID, -- order_id or other ref
  description TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- RLS for Wallet Transactions
ALTER TABLE public.wallet_transactions ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Users can see their own transactions" ON public.wallet_transactions;
CREATE POLICY "Users can see their own transactions" 
ON public.wallet_transactions FOR SELECT 
USING (auth.uid() = profile_id OR EXISTS (SELECT 1 FROM public.stores WHERE id = store_id AND owner_id = auth.uid()));
