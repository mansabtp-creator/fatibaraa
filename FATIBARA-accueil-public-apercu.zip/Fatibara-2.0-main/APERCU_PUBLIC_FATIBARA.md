# FATIBARA — aperçu de la nouvelle page d'accueil publique

Cette copie contient une proposition de refonte limitée à la page d'accueil publique :
- écran d'introduction public avec bouton « Passer » et fermeture automatique ;
- bannière de présentation FATIBARA adaptée aux mobiles ;
- mise en avant des offres flash existantes lorsqu'une offre valide est disponible ;
- les sections et composants existants de catalogue, boutiques, recherche et navigation restent en place.

## Protection de la production
Cette archive est une copie de travail et n'a pas été déployée. Elle ne contient pas de migration SQL volontairement ajoutée et ne modifie pas la logique d'authentification, de commande ou de paiement. Ne déployez pas cette copie avant de la tester avec les variables d'environnement de votre environnement de préproduction.

## Lancement local (après installation des dépendances)
1. Copier `.env.example` vers `.env` et renseigner les clés nécessaires à un environnement de test, jamais des secrets de production partagés publiquement.
2. Installer les dépendances avec le gestionnaire utilisé par le projet.
3. Lancer `npm run dev`.
4. Tester la page d'accueil, recherche, catégories, connexion, panier et parcours de paiement en mode test.

Note : cette archive source n'est pas un lien public prêt à envoyer au client. Elle doit être exécutée dans un environnement de prévisualisation configuré.
