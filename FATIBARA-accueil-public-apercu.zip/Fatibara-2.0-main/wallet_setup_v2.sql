-- WALLET & WITHDRAWALS SYSTEM (Idempotent Version)
-- This script safely drops existing objects before recreating them to avoid "already exists" errors.

-- 1. Create Tables
ALTER TABLE public.stores ADD COLUMN IF NOT EXISTS balance BIGINT DEFAULT 0;

CREATE TABLE IF NOT EXISTS public.wallet_transactions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    store_id UUID REFERENCES public.stores(id) ON DELETE CASCADE,
    amount BIGINT NOT NULL,
    type TEXT NOT NULL, -- 'sale', 'withdrawal', 'refund', 'adjustment'
    reference_id UUID,
    description TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS public.withdrawals (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    store_id UUID REFERENCES public.stores(id) ON DELETE CASCADE,
    amount BIGINT NOT NULL,
    method TEXT NOT NULL, -- 'Orange Money', 'MTN MoMo'
    phone_number TEXT NOT NULL,
    status TEXT DEFAULT 'pending', -- 'pending', 'processed', 'rejected'
    processed_at TIMESTAMP WITH TIME ZONE,
    admin_notes TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 2. Setup RLS (Row Level Security)
ALTER TABLE public.wallet_transactions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.withdrawals ENABLE ROW LEVEL SECURITY;

-- Drop existing policies to avoid errors
DROP POLICY IF EXISTS "Vendors can view own transactions" ON public.wallet_transactions;
DROP POLICY IF EXISTS "Vendors can view own withdrawals" ON public.withdrawals;
DROP POLICY IF EXISTS "Vendors can create withdrawals" ON public.withdrawals;

-- Recreate policies
CREATE POLICY "Vendors can view own transactions" 
ON public.wallet_transactions FOR SELECT 
USING (store_id IN (SELECT id FROM public.stores WHERE owner_id = auth.uid()));

CREATE POLICY "Vendors can view own withdrawals" 
ON public.withdrawals FOR SELECT 
USING (store_id IN (SELECT id FROM public.stores WHERE owner_id = auth.uid()));

CREATE POLICY "Vendors can create withdrawals" 
ON public.withdrawals FOR INSERT 
WITH CHECK (store_id IN (SELECT id FROM public.stores WHERE owner_id = auth.uid()));

-- 3. Trigger for Automatic Sales Logging
CREATE OR REPLACE FUNCTION log_sale_transaction()
RETURNS TRIGGER AS $$
BEGIN
    -- Log transaction when order is delivered
    IF (TG_OP = 'UPDATE' AND OLD.status != 'delivered' AND NEW.status = 'delivered') THEN
        INSERT INTO wallet_transactions (store_id, amount, type, reference_id, description)
        VALUES (NEW.store_id, NEW.total_amount, 'sale', NEW.id, 'Vente finalisée: Commande ' || NEW.id);
        
        -- Update store balance
        UPDATE stores
        SET balance = COALESCE(balance, 0) + NEW.total_amount
        WHERE id = NEW.store_id;
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS tr_log_sale_transaction ON orders;
CREATE TRIGGER tr_log_sale_transaction
AFTER UPDATE ON orders
FOR EACH ROW
EXECUTE FUNCTION log_sale_transaction();
