-- WAVE 5: TACTICAL PERFORMANCE & FLEET OPTIMIZATION
-- This script adds metrics tracking and referral relationship logic.

-- 1. COURIER PERFORMANCE METRICS (Snapshot table)
CREATE TABLE IF NOT EXISTS public.courier_performance (
    courier_id UUID PRIMARY KEY REFERENCES public.profiles(id),
    total_deliveries INTEGER DEFAULT 0,
    successful_deliveries INTEGER DEFAULT 0,
    avg_delivery_time INTERVAL, -- Computed average
    rating_avg DECIMAL(3,2) DEFAULT 5.0,
    reliability_score INTEGER DEFAULT 100, -- 0-100 scale
    last_updated TIMESTAMPTZ DEFAULT now()
);

-- 2. REFERRAL TRACKING (Growth Engine)
CREATE TABLE IF NOT EXISTS public.referrals (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    referrer_id UUID REFERENCES public.profiles(id),
    referred_id UUID REFERENCES public.profiles(id) UNIQUE,
    status TEXT DEFAULT 'pending', -- 'pending', 'verified', 'paid'
    reward_amount DECIMAL DEFAULT 0,
    created_at TIMESTAMPTZ DEFAULT now()
);

-- 3. ENABLE RLS
ALTER TABLE public.courier_performance ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.referrals ENABLE ROW LEVEL SECURITY;

-- 4. POLICIES
CREATE POLICY "Performance viewable by owners and admins" 
ON public.courier_performance FOR SELECT 
USING (auth.uid() = courier_id OR EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND is_admin = true));

CREATE POLICY "Referrals viewable by referrer and admins" 
ON public.referrals FOR SELECT 
USING (auth.uid() = referrer_id OR EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND is_admin = true));

-- 5. FUNCTION TO UPDATE COURIER METRICS (Trigger logic)
CREATE OR REPLACE FUNCTION public.update_courier_stats()
RETURNS TRIGGER AS $$
BEGIN
    IF (NEW.status = 'delivered') THEN
        INSERT INTO public.courier_performance (courier_id, total_deliveries, successful_deliveries, last_updated)
        VALUES (NEW.courier_id, 1, 1, now())
        ON CONFLICT (courier_id) DO UPDATE SET 
            total_deliveries = public.courier_performance.total_deliveries + 1,
            successful_deliveries = public.courier_performance.successful_deliveries + 1,
            last_updated = now();
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- 6. INITIALIZE PERFORMANCE FOR EXISTING COURIERS
INSERT INTO public.courier_performance (courier_id)
SELECT id FROM public.profiles WHERE profile_type = 'courier'
ON CONFLICT (courier_id) DO NOTHING;
