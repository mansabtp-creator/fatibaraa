-- WAVE 6: FINANCIAL INTEGRITY & REVENUE ANALYTICS
-- This script adds daily revenue snapshots and support tracking.

-- 1. DAILY REVENUE SNAPSHOTS (Analytics)
CREATE TABLE IF NOT EXISTS public.daily_revenue (
    date DATE PRIMARY KEY,
    total_revenue DECIMAL(12,2) DEFAULT 0,
    total_orders INTEGER DEFAULT 0,
    platform_fee DECIMAL(12,2) DEFAULT 0,
    last_updated TIMESTAMPTZ DEFAULT now()
);

-- 2. SUPPORT TICKETS (Financial & General)
CREATE TABLE IF NOT EXISTS public.support_tickets (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES public.profiles(id),
    subject TEXT NOT NULL,
    description TEXT NOT NULL,
    status TEXT DEFAULT 'open', -- 'open', 'in-progress', 'resolved'
    priority TEXT DEFAULT 'normal', -- 'low', 'normal', 'high'
    created_at TIMESTAMPTZ DEFAULT now()
);

-- 3. ENABLE RLS
ALTER TABLE public.daily_revenue ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.support_tickets ENABLE ROW LEVEL SECURITY;

-- 4. POLICIES
CREATE POLICY "Revenue viewable by admins only" 
ON public.daily_revenue FOR SELECT 
USING (EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND is_admin = true));

CREATE POLICY "Users can view their own tickets" 
ON public.support_tickets FOR SELECT 
USING (auth.uid() = user_id OR EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND is_admin = true));

CREATE POLICY "Users can create their own tickets"
ON public.support_tickets FOR INSERT
WITH CHECK (auth.uid() = user_id);
