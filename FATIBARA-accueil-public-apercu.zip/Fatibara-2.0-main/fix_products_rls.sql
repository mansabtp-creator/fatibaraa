DROP POLICY IF EXISTS "Vendors can manage their own products" ON public.products;
DROP POLICY IF EXISTS "Store owners can update their own products." ON public.products;
DROP POLICY IF EXISTS "Store owners can delete their own products." ON public.products;
DROP POLICY IF EXISTS "Store owners can insert products into their stores." ON public.products;

CREATE POLICY "Vendors can manage their own products" 
ON public.products FOR ALL 
USING (
  EXISTS (
    SELECT 1 FROM public.stores 
    WHERE stores.id = products.store_id 
    AND stores.owner_id = auth.uid()
  )
)
WITH CHECK (
  EXISTS (
    SELECT 1 FROM public.stores 
    WHERE stores.id = products.store_id 
    AND (stores.owner_id = auth.uid())
  )
);
