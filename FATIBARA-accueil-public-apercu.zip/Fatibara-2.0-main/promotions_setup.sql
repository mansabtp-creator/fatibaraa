-- PROMOTION MANAGER (ADVANCED DEALS)
CREATE TABLE IF NOT EXISTS public.promotions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    title TEXT NOT NULL,
    description TEXT,
    promo_type TEXT NOT NULL CHECK (promo_type IN ('flash_deal', 'bogo', 'coupon', 'global_discount')),
    discount_type TEXT NOT NULL CHECK (discount_type IN ('percentage', 'fixed')),
    discount_value DECIMAL NOT NULL,
    min_purchase_amount DECIMAL DEFAULT 0,
    max_discount_amount DECIMAL,
    start_at TIMESTAMP WITH TIME ZONE NOT NULL,
    end_at TIMESTAMP WITH TIME ZONE NOT NULL,
    status TEXT DEFAULT 'active' CHECK (status IN ('active', 'inactive', 'scheduled', 'expired')),
    code TEXT UNIQUE, -- For coupons
    store_id UUID REFERENCES public.stores(id), -- NULL if global
    banner_url TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Link promotions to products (Many-to-Many)
CREATE TABLE IF NOT EXISTS public.promotion_products (
    promotion_id UUID REFERENCES public.promotions(id) ON DELETE CASCADE,
    product_id UUID REFERENCES public.products(id) ON DELETE CASCADE,
    PRIMARY KEY (promotion_id, product_id)
);
