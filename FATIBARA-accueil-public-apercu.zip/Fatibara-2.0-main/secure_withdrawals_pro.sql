-- ==============================================================================
-- SECURE WITHDRAWAL & PRO UPGRADE DEFINITIONS
-- ==============================================================================

-- 1. SECURE USER WITHDRAWAL RPC
CREATE OR REPLACE FUNCTION public.request_user_withdrawal(
    p_amount BIGINT,
    p_method TEXT,
    p_phone TEXT
) RETURNS JSONB AS $$
DECLARE
    v_profile RECORD;
    v_withdrawal_id UUID;
    p_user_id UUID;
BEGIN
    p_user_id := auth.uid();
    IF p_user_id IS NULL THEN
        RAISE EXCEPTION 'Not authenticated';
    END IF;

    -- Validate profile and lock for update to prevent concurrent race conditions
    SELECT * INTO v_profile FROM public.profiles WHERE id = p_user_id FOR UPDATE;
    
    IF v_profile IS NULL THEN
        RAISE EXCEPTION 'Profile not found';
    END IF;
    
    IF v_profile.wallet_balance < p_amount THEN
        RAISE EXCEPTION 'Insufficient balance';
    END IF;
    
    IF p_amount < 2000 THEN
        RAISE EXCEPTION 'Minimum withdrawal amount is 2000 GNF';
    END IF;
    
    -- 1. Create withdrawal record
    INSERT INTO public.withdrawals (profile_id, amount, method, phone_number, status)
    VALUES (p_user_id, p_amount, p_method, p_phone, 'pending')
    RETURNING id INTO v_withdrawal_id;
    
    -- 2. Deduct balance atomically
    UPDATE public.profiles
    SET wallet_balance = wallet_balance - p_amount
    WHERE id = p_user_id;
    
    -- 3. Log transaction
    INSERT INTO public.wallet_transactions (profile_id, amount, type, reference_id, description, status)
    VALUES (
        p_user_id, 
        -p_amount, 
        'withdrawal', 
        v_withdrawal_id, 
        'Retrait vers ' || p_method || ' (' || p_phone || ')', 
        'completed'
    );
    
    RETURN jsonb_build_object('success', true, 'withdrawal_id', v_withdrawal_id);
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- 2. SECURE VIP/PRO UPGRADE RPC
CREATE OR REPLACE FUNCTION public.upgrade_user_to_pro(p_user_id UUID, p_cost NUMERIC)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_current_balance NUMERIC;
BEGIN
  -- Validate that caller can only upgrade themselves unless they are admin (auth.uid() = p_user_id)
  IF auth.uid() != p_user_id THEN
    -- Check if caller is admin
    IF NOT EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND is_admin = true) THEN
      RAISE EXCEPTION 'Unauthorized';
    END IF;
  END IF;

  -- Lock user row
  SELECT wallet_balance INTO v_current_balance
  FROM public.profiles
  WHERE id = p_user_id
  FOR UPDATE;

  IF v_current_balance IS NULL THEN
    RAISE EXCEPTION 'User profile not found';
  END IF;

  IF v_current_balance < p_cost THEN
    RAISE EXCEPTION 'Insufficient wallet balance';
  END IF;

  -- Deduct balance
  UPDATE public.profiles
  SET wallet_balance = wallet_balance - p_cost,
      is_pro_member = true
  WHERE id = p_user_id;

  -- Log transaction
  INSERT INTO public.wallet_transactions (profile_id, amount, type, description, status)
  VALUES (
    p_user_id,
    -p_cost,
    'fee',
    'Abonnement VIP / Pro',
    'completed'
  );

  RETURN jsonb_build_object('success', true);
END;
$$;

-- 3. SECURE ADMIN WITHDRAWAL REJECTION RPC
CREATE OR REPLACE FUNCTION public.reject_withdrawal(
    p_withdrawal_id UUID,
    p_reason TEXT
) RETURNS JSONB AS $$
DECLARE
    v_withdrawal RECORD;
BEGIN
    -- Check if auth user is admin
    IF NOT EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND is_admin = true) THEN
        RAISE EXCEPTION 'Unauthorized: Only administrators can reject withdrawals';
    END IF;

    -- Lock withdrawal record
    SELECT * INTO v_withdrawal FROM public.withdrawals WHERE id = p_withdrawal_id FOR UPDATE;
    IF v_withdrawal IS NULL THEN
        RAISE EXCEPTION 'Withdrawal not found';
    END IF;

    IF v_withdrawal.status != 'pending' THEN
        RAISE EXCEPTION 'Withdrawal is not pending';
    END IF;

    -- Perform restoration
    IF v_withdrawal.store_id IS NOT NULL THEN
        UPDATE public.stores
        SET balance = balance + ROUND(v_withdrawal.amount)
        WHERE id = v_withdrawal.store_id;
    ELSIF v_withdrawal.profile_id IS NOT NULL THEN
        UPDATE public.profiles
        SET wallet_balance = wallet_balance + ROUND(v_withdrawal.amount)
        WHERE id = v_withdrawal.profile_id;
    END IF;

    -- Update withdrawal status
    UPDATE public.withdrawals
    SET status = 'rejected',
        rejection_reason = p_reason,
        processed_at = NOW()
    WHERE id = p_withdrawal_id;

    -- Log transaction
    INSERT INTO public.wallet_transactions (store_id, profile_id, amount, type, reference_id, description, status)
    VALUES (
        v_withdrawal.store_id,
        v_withdrawal.profile_id,
        v_withdrawal.amount,
        'adjustment',
        v_withdrawal.id,
        'Remboursement retrait rejeté: ' || p_reason,
        'completed'
    );

    RETURN jsonb_build_object('success', true);
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;
