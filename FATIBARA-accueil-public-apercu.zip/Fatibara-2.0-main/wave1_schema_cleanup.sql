
-- WAVE 1: CRITICAL SCHEMA REPAIR
-- This script fixes the missing columns reported by users and essential for dashboard functionality.

-- 1. STORES Table Enhancements
ALTER TABLE public.stores ADD COLUMN IF NOT EXISTS store_status TEXT DEFAULT 'active' CHECK (store_status IN ('active', 'suspended', 'holiday', 'pending'));
ALTER TABLE public.stores ADD COLUMN IF NOT EXISTS store_category TEXT;
ALTER TABLE public.stores ADD COLUMN IF NOT EXISTS logo_dark_url TEXT;
ALTER TABLE public.stores ADD COLUMN IF NOT EXISTS verification_document_url TEXT;
ALTER TABLE public.stores ADD COLUMN IF NOT EXISTS contact_phone TEXT;
ALTER TABLE public.stores ADD COLUMN IF NOT EXISTS status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'active', 'rejected', 'suspended'));
ALTER TABLE public.stores ADD COLUMN IF NOT EXISTS payout_orange_money TEXT;
ALTER TABLE public.stores ADD COLUMN IF NOT EXISTS payout_mtn_money TEXT;

-- 2. PRODUCTS Table Enhancements
ALTER TABLE public.products ADD COLUMN IF NOT EXISTS status TEXT DEFAULT 'published' CHECK (status IN ('published', 'draft', 'scheduled', 'archived'));
ALTER TABLE public.products ADD COLUMN IF NOT EXISTS low_stock_threshold INTEGER DEFAULT 5;
ALTER TABLE public.products ADD COLUMN IF NOT EXISTS is_digital BOOLEAN DEFAULT false;
ALTER TABLE public.products ADD COLUMN IF NOT EXISTS download_url TEXT;

-- 3. PROFILES Table Enhancements
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS courier_status TEXT DEFAULT NULL; -- 'active', 'inactive', 'pending'
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS city TEXT DEFAULT 'Conakry';

-- 4. AUDIT LOGS Table Alignment
-- The dashboard expects certain column names. We ensure they exist or alias them.
-- Based on AdminDashboardPage.tsx: logAction(action, entity_type, entity_id, new_data)
-- Existing admin_infrastructure.sql: target_type, target_id, details
ALTER TABLE public.audit_logs ADD COLUMN IF NOT EXISTS entity_type TEXT;
ALTER TABLE public.audit_logs ADD COLUMN IF NOT EXISTS entity_id TEXT;
ALTER TABLE public.audit_logs ADD COLUMN IF NOT EXISTS new_data JSONB;
ALTER TABLE public.audit_logs ADD COLUMN IF NOT EXISTS user_id UUID REFERENCES public.profiles(id);

-- 5. PLATFORM LOGS Table (Financial Analytics)
CREATE TABLE IF NOT EXISTS public.platform_logs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    amount NUMERIC DEFAULT 0,
    type TEXT, -- 'commission', 'withdrawal_fee', etc.
    description TEXT,
    created_at TIMESTAMPTZ DEFAULT now()
);

-- 6. RPC HELPERS (Atomic Increments)
CREATE OR REPLACE FUNCTION public.increment_store_balance(target_store_id UUID, amount NUMERIC)
RETURNS void AS $$
BEGIN
  UPDATE public.stores
  SET balance = balance + amount
  WHERE id = target_store_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE OR REPLACE FUNCTION public.increment_wallet_balance(user_id UUID, amount NUMERIC)
RETURNS void AS $$
BEGIN
  UPDATE public.profiles
  SET wallet_balance = wallet_balance + amount
  WHERE id = user_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- 7. RLS REFRESH (Ensure Admin visibility)
DROP POLICY IF EXISTS "Admins can view all profiles" ON public.profiles;
CREATE POLICY "Admins can view all profiles" 
ON public.profiles FOR SELECT 
USING (
  is_admin = true OR id = auth.uid()
);

-- Force cache refresh (Supabase side) by adding a comment or minor change
COMMENT ON TABLE public.products IS 'Product Inventory';
