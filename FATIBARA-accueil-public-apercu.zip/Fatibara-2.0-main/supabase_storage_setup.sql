-- STORAGE SETUP: Product Images (Optimized Version)

-- 1. Create the bucket
INSERT INTO storage.buckets (id, name, public) 
VALUES ('product-images', 'product-images', true)
ON CONFLICT (id) DO NOTHING;

-- 2. Enable RLS
ALTER TABLE storage.objects ENABLE ROW LEVEL SECURITY;

-- 3. Reset Policies
DROP POLICY IF EXISTS "Public View Access" ON storage.objects;
DROP POLICY IF EXISTS "Authenticated users can upload images" ON storage.objects;
DROP POLICY IF EXISTS "Users can manage their own images" ON storage.objects;

-- 4. Create Policies
CREATE POLICY "Public View Access"
ON storage.objects FOR SELECT
USING ( bucket_id = 'product-images' );

CREATE POLICY "Authenticated users can upload images"
ON storage.objects FOR INSERT
TO authenticated
WITH CHECK ( bucket_id = 'product-images' );

CREATE POLICY "Users can manage their own images"
ON storage.objects FOR ALL
TO authenticated
USING ( bucket_id = 'product-images' AND auth.uid() = owner );
