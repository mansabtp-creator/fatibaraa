-- ============================================================
-- COURIER FLEET MIGRATION
-- Run this in your Supabase SQL Editor (Project > SQL Editor)
-- Safe to re-run (all ADD COLUMN IF NOT EXISTS)
-- ============================================================

-- 1. New columns for fleet management
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS vehicle_type    TEXT    DEFAULT NULL;
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS courier_zone    TEXT    DEFAULT NULL;
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS cash_in_hand    NUMERIC DEFAULT 0;
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS courier_wallet  NUMERIC DEFAULT 0;
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS total_deliveries INTEGER DEFAULT 0;
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS courier_rating  NUMERIC DEFAULT 0;

-- 2. Extend courier_status CHECK to accept both legacy & new canonical values
--    Legacy:    inactive | active | on_delivery | suspended
--    Canonical: hors_ligne | disponible | en_course | suspendu
ALTER TABLE public.profiles DROP CONSTRAINT IF EXISTS profiles_courier_status_check;
ALTER TABLE public.profiles ADD CONSTRAINT profiles_courier_status_check
  CHECK (courier_status IN (
    'inactive', 'active', 'on_delivery', 'suspended',    -- legacy (kept for data compatibility)
    'hors_ligne', 'disponible', 'en_course', 'suspendu'  -- canonical
  ));

-- 3. vehicle_type CHECK
ALTER TABLE public.profiles DROP CONSTRAINT IF EXISTS profiles_vehicle_type_check;
ALTER TABLE public.profiles ADD CONSTRAINT profiles_vehicle_type_check
  CHECK (vehicle_type IN ('moto', 'voiture', 'velo') OR vehicle_type IS NULL);

-- 4. Ensure admins can update courier profiles (needed for status changes)
DROP POLICY IF EXISTS "Admins can update any profile" ON public.profiles;
CREATE POLICY "Admins can update any profile"
  ON public.profiles FOR UPDATE
  USING (
    auth.uid() = id       -- user can update own profile
    OR public.is_admin()  -- admin can update any profile
  );

-- 5. Verify
SELECT column_name, data_type, column_default
FROM information_schema.columns
WHERE table_name = 'profiles'
  AND column_name IN (
    'courier_status', 'vehicle_type', 'courier_zone',
    'cash_in_hand', 'courier_wallet', 'total_deliveries', 'courier_rating'
  )
ORDER BY column_name;
