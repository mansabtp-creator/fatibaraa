-- FIX VENDOR FULFILLMENT: SECURE RPC MIGRATION
-- This script migrates the financial calculations for order fulfillment from the client-side to the secure PostgreSQL backend.

-- 1. SECURE RPC FOR DELIVERING AN ORDER AND PROCESSING PAYOUTS
CREATE OR REPLACE FUNCTION public.complete_vendor_order(
    target_order_id UUID,
    provided_otp TEXT
)
RETURNS VOID
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_order public.orders%ROWTYPE;
    v_store_id UUID;
    v_commission_str TEXT;
    v_commission_rate NUMERIC;
    v_items_real_value NUMERIC := 0;
    v_item_subtotal NUMERIC;
    v_platform_commission NUMERIC;
    v_vendor_payout NUMERIC;
    v_courier_payout NUMERIC;
    v_is_cash_payment BOOLEAN;
    v_final_vendor_digital_change NUMERIC;
    v_final_courier_digital_change NUMERIC;
BEGIN
    SELECT * INTO v_order
    FROM public.orders
    WHERE id = target_order_id
    FOR UPDATE; -- Lock the row to prevent race conditions

    IF NOT FOUND THEN
        RAISE EXCEPTION 'Order not found';
    END IF;

    IF v_order.vendor_id != auth.uid() THEN
        RAISE EXCEPTION 'Unauthorized: You do not own this store';
    END IF;

    -- Get store_id from order items or fallback to vendor's store
    SELECT COALESCE(
        (SELECT p.store_id 
         FROM public.order_items oi
         JOIN public.products p ON oi.product_id = p.id
         WHERE oi.order_id = target_order_id
         LIMIT 1),
        (SELECT id 
         FROM public.stores 
         WHERE owner_id = v_order.vendor_id
         LIMIT 1)
    ) INTO v_store_id;

    -- 2. Enforce state transitions
    IF v_order.status NOT IN ('ready_for_pickup', 'in_transit') THEN
        RAISE EXCEPTION 'Order must be ready_for_pickup or in_transit to be delivered';
    END IF;

    -- 3. Validate OTP (Strict security check)
    IF v_order.delivery_otp IS NOT NULL AND v_order.delivery_otp != '' THEN
        IF provided_otp IS NULL OR provided_otp != v_order.delivery_otp THEN
            RAISE EXCEPTION 'Invalid delivery OTP';
        END IF;
    END IF;

    -- 4. Idempotency Check
    IF v_order.financial_status = 'processed' OR v_order.status = 'delivered' THEN
        RAISE EXCEPTION 'Order financials already processed';
    END IF;

    -- 5. Calculate Mathematics Securely
    SELECT value INTO v_commission_str FROM public.platform_settings WHERE id = 'commission_rate';
    v_commission_rate := COALESCE(NULLIF(v_commission_str, '')::NUMERIC, 5) / 100.0;

    -- Get sum of order items real value directly from DB
    SELECT COALESCE(SUM(price_at_purchase * quantity), 0) INTO v_items_real_value
    FROM public.order_items
    WHERE order_id = target_order_id;

    IF v_items_real_value = 0 THEN
        v_items_real_value := (COALESCE(v_order.total_amount, 0) - COALESCE(v_order.delivery_fee, 0)) / (1 + v_commission_rate);
    END IF;

    v_item_subtotal := v_items_real_value / (1 + v_commission_rate);
    v_platform_commission := v_item_subtotal * v_commission_rate;

    v_vendor_payout := v_item_subtotal - COALESCE(v_order.vendor_delivery_fee, 0);

    IF COALESCE(v_order.delivery_fee, 0) > 0 THEN
        v_courier_payout := COALESCE(v_order.delivery_fee, 0) * 0.8;
    ELSE
        v_courier_payout := COALESCE(v_order.vendor_delivery_fee, 0) * 0.8;
    END IF;

    IF v_order.courier_id IS NULL THEN
        v_vendor_payout := v_vendor_payout + v_courier_payout;
    END IF;

    v_is_cash_payment := v_order.payment_method = 'cash';

    -- 6. Update Vendor Store Balance
    v_final_vendor_digital_change := v_vendor_payout;
    IF v_is_cash_payment AND v_order.courier_id IS NULL THEN
        v_final_vendor_digital_change := v_vendor_payout - COALESCE(v_order.total_amount, 0);
    END IF;

    IF v_final_vendor_digital_change != 0 THEN
        -- Bypass increment_store_balance for direct, secure internal update
        UPDATE public.stores
        SET balance = balance + ROUND(v_final_vendor_digital_change)
        WHERE id = v_store_id;

        INSERT INTO public.wallet_transactions (store_id, profile_id, amount, type, reference_id, description)
        VALUES (
            v_store_id, 
            v_order.vendor_id, 
            v_final_vendor_digital_change, 
            CASE WHEN v_final_vendor_digital_change > 0 THEN 'sale' ELSE 'fee' END, 
            target_order_id, 
            CASE WHEN v_is_cash_payment AND v_order.courier_id IS NULL 
                 THEN 'Collecte Cash #' || left(target_order_id::text, 8) || ' (Retenue: ' || abs(ROUND(v_final_vendor_digital_change)) || ')'
                 ELSE 'Vente #' || left(target_order_id::text, 8) || ' (Logiciel Silencieux: Payout ' || ROUND(v_item_subtotal) || ')'
            END
        );
    END IF;

    -- 7. Update Courier Balance (if assigned)
    IF v_order.courier_id IS NOT NULL THEN
        v_final_courier_digital_change := v_courier_payout;
        IF v_is_cash_payment THEN
            v_final_courier_digital_change := v_courier_payout - COALESCE(v_order.total_amount, 0);
        END IF;

        IF v_final_courier_digital_change != 0 THEN
            UPDATE public.profiles
            SET wallet_balance = wallet_balance + ROUND(v_final_courier_digital_change)
            WHERE id = v_order.courier_id;

            INSERT INTO public.wallet_transactions (profile_id, amount, type, reference_id, description)
            VALUES (
                v_order.courier_id, 
                v_final_courier_digital_change, 
                CASE WHEN v_final_courier_digital_change > 0 THEN 'delivery_fee' ELSE 'fee' END, 
                target_order_id, 
                CASE WHEN v_is_cash_payment 
                     THEN 'Collecte Cash #' || left(target_order_id::text, 8) || ' (Retenue: ' || abs(ROUND(v_final_courier_digital_change)) || ')'
                     ELSE 'Course effectuée - Commande #' || left(target_order_id::text, 8)
                END
            );
        END IF;
    END IF;

    -- 8. Log Platform Commission
    INSERT INTO public.platform_logs (type, amount, reference_id, metadata)
    VALUES (
        'commission', 
        ROUND(v_platform_commission), 
        target_order_id, 
        jsonb_build_object('order_total', v_order.total_amount, 'vendor_id', v_order.vendor_id)
    );

    -- 9. Mark Order Delivered and Processed Atomically
    UPDATE public.orders
    SET status = 'delivered', financial_status = 'processed', updated_at = now()
    WHERE id = target_order_id;
END;
$$;


-- 2. SECURE RPC FOR CANCELLING AN ORDER AND ISSUING REFUNDS
CREATE OR REPLACE FUNCTION public.cancel_vendor_order(
    target_order_id UUID,
    cancel_reason TEXT
)
RETURNS VOID
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_order public.orders%ROWTYPE;
    v_is_digital_payment BOOLEAN;
BEGIN
    SELECT * INTO v_order
    FROM public.orders
    WHERE id = target_order_id
    FOR UPDATE;

    IF NOT FOUND THEN
        RAISE EXCEPTION 'Order not found';
    END IF;

    IF v_order.vendor_id != auth.uid() THEN
        RAISE EXCEPTION 'Unauthorized: You do not own this store';
    END IF;

    IF v_order.status IN ('delivered', 'cancelled') THEN
        RAISE EXCEPTION 'Order is already in a terminal state';
    END IF;

    IF v_order.financial_status = 'refunded' THEN
        RAISE EXCEPTION 'Order already refunded';
    END IF;

    v_is_digital_payment := v_order.payment_method IN ('wallet', 'orange', 'mtn');

    -- Refund digital payments natively if not already processed
    IF v_is_digital_payment AND v_order.status NOT IN ('pending', 'cancelled') THEN
        -- Refund to user wallet natively
        UPDATE public.profiles
        SET wallet_balance = wallet_balance + ROUND(v_order.total_amount)
        WHERE id = v_order.user_id;

        INSERT INTO public.wallet_transactions (profile_id, amount, type, reference_id, description)
        VALUES (
            v_order.user_id, 
            v_order.total_amount, 
            'refund', 
            target_order_id, 
            'Remboursement Commande #' || left(target_order_id::text, 8) || ' (' || cancel_reason || ')'
        );
    END IF;

    UPDATE public.orders
    SET status = 'cancelled', financial_status = 'refunded', updated_at = now()
    WHERE id = target_order_id;
END;
$$;
