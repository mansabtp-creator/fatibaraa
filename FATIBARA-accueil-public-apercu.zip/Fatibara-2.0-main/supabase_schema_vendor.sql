-- Phase 4: Vendor Admin & Pricing Analytics Fixes

-- 1. Migration: Ensure all required columns exist in 'orders' table
DO $$ 
BEGIN 
    -- Add vendor_id if missing
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='orders' AND column_name='vendor_id') THEN
        ALTER TABLE public.orders ADD COLUMN vendor_id uuid REFERENCES auth.users(id);
    END IF;

    -- Handle total_amount rename if total_gnf exists
    IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='orders' AND column_name='total_gnf') 
       AND NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='orders' AND column_name='total_amount') THEN
        ALTER TABLE public.orders RENAME COLUMN total_gnf TO total_amount;
    END IF;

    -- Create total_amount if neither exists (fallback)
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='orders' AND column_name='total_amount') THEN
        ALTER TABLE public.orders ADD COLUMN total_amount numeric DEFAULT 0;
    END IF;
END $$;

-- 2. Update RLS policies for vendors to see their orders
-- Drop existing first to avoid conflicts on re-run
DROP POLICY IF EXISTS "Vendors can view orders for their products" ON public.orders;
DROP POLICY IF EXISTS "Vendors can update status of their orders" ON public.orders;

CREATE POLICY "Vendors can view orders for their products" 
    ON public.orders FOR SELECT 
    USING (auth.uid() = vendor_id);

CREATE POLICY "Vendors can update status of their orders"
    ON public.orders FOR UPDATE
    USING (auth.uid() = vendor_id);

-- 3. Analytics View (Helper for stats)
CREATE OR REPLACE VIEW vendor_sales_stats AS
SELECT 
    vendor_id,
    COUNT(id) as total_orders,
    COALESCE(SUM(total_amount), 0) as gross_revenue,
    status
FROM public.orders
GROUP BY vendor_id, status;

