<div align="center">

<img src="https://miizhdzuxidilrzwdivk.supabase.co/storage/v1/object/public/assets/favicon_fatibara.png" width="96" height="96" alt="Fatibara Logo" />

# Fatibara — La Marketplace de Guinée 🇬🇳

**A high-performance, full-stack, AI-powered e-commerce marketplace built for the Guinean market.**  
*Mobile-First · Progressive Web App (PWA) · Real-Time · Gemini AI · LengoPay*

[![TypeScript](https://img.shields.io/badge/TypeScript-5.8-3178C6?logo=typescript&logoColor=white)](https://www.typescriptlang.org/)
[![React](https://img.shields.io/badge/React-19-61DAFB?logo=react&logoColor=black)](https://react.dev/)
[![Supabase](https://img.shields.io/badge/Supabase-Backend-3ECF8E?logo=supabase&logoColor=white)](https://supabase.com/)
[![Vite](https://img.shields.io/badge/Vite-6-646CFF?logo=vite&logoColor=white)](https://vitejs.dev/)
[![Deployed on Vercel](https://img.shields.io/badge/Deployed%20on-Vercel-000?logo=vercel&logoColor=white)](https://vercel.com/)
[![License](https://img.shields.io/badge/License-Apache_2.0-blue.svg)](LICENSE)

[🇬🇧 English Section](#-english-documentation) • [🇫🇷 Section Française](#-documentation-en-français)

</div>

---

# 🇬🇧 English Documentation

## 🌍 Overview

**Fatibara** is a localized e-commerce marketplace connecting buyers, local vendors, and logistics couriers across Guinea. It manages the complete commerce lifecycle — product discovery, multi-vendor cart & checkout, mobile-money settlement (LengoPay), order fulfillment, real-time courier dispatch, and AI-driven vendor tools — in a single installable Progressive Web App.

Built for low-bandwidth, mobile-first environments in Conakry and regional cities, the platform features a French UI tailored to Guinean market conventions:
* **Currency:** Guinean Franc (GNF)
* **Address System:** Commune and neighborhood pin-pointing
* **Payments:** Orange Money, Wave, and MTN Mobile Money via LengoPay

---

## ✨ Feature Matrix

### 🛒 Buyer Experience
* **Product Discovery:** Category browsing, full-text fuzzy search, trending feed, and flash deals.
* **AI Search & Visual Search:** Semantic search powered by Google Gemini with camera-based image lookup.
* **Autour de moi:** Geolocation-based nearby store discovery and delivery estimates.
* **Cart & Checkout:** Multi-vendor cart support, promo codes, and interactive map pin picker.
* **Mobile Money Payments:** Native LengoPay integration with OTP verification.
* **Order Tracking:** Real-time order progress, courier GPS tracking, and delivery OTP confirmation.
* **PWA & Offline Capability:** Installable on iOS/Android with offline caching via Service Workers.

### 🏪 Vendor Portal (`/vendor/*`)
* **Live KPI Dashboard:** Real-time sales analytics, revenue graphs, and activity streams.
* **Catalog Management:** Full product CRUD with AI description generator, image compression, variants, and bulk pricing.
* **Order Kanban:** Sequential order pipeline (`pending → paid → preparing → ready → delivered`).
* **AI Marketing Boosts:** Geo-targeted campaign creation across 6 duration tiers.
* **Finances & Wallet:** Ledger audit trails, instant payout requests, and automated commission tracking.
* **Real-time Messenger:** Direct buyer-to-vendor chat with active order context attached.

### 🚚 Courier Fleet Portal (`/courier-dashboard`)
* Fleet onboarding and verification workflow.
* Live delivery job board with acceptance timers and GPS route guidance.
* OTP-verified handoffs for secure delivery confirmation.
* Earnings ledger and customer rating metrics.

### 🛡️ Admin Control Panel (`/admin`)
* System-wide operational oversight across users, stores, products, and deliveries.
* RLS-secured financial audits and manual adjustment controls.
* Platform announcement engine and banner manager.

---

## 🏗️ Architecture

```
┌──────────────────────────────────────────────────────────┐
│                     Browser / PWA                        │
│  React 19 · React Router 7 · Zustand · Motion · Tailwind │
│  Recharts · Leaflet · Lucide                             │
└────────────────────┬─────────────────────────────────────┘
                     │ HTTPS / WSS
          ┌──────────▼──────────┐
          │  Express API Server │  ← server.ts (Node / Vercel)
          │  /api/payment/*     │
          │  /api/webhook/*     │
          └──┬──────────────┬───┘
             │              │
    ┌────────▼──┐    ┌──────▼──────────────┐
    │ LengoPay  │    │   Supabase (PaaS)   │
    │  Payment  │    │ PostgreSQL · RLS    │
    │  Gateway  │    │ Realtime · Storage  │
    └───────────┘    └─────────────────────┘
                            │
                    ┌───────▼─────────┐
                    │  Google Gemini  │
                    │     AI API      │
                    └─────────────────┘
```

---

## 🚀 Quick Start (English)

```bash
# 1. Clone repo
git clone https://github.com/kconde-dev/Fatibara-2.0.git
cd Fatibara-2.0

# 2. Install dependencies
npm install

# 3. Configure environment
cp .env.example .env.local

# 4. Start dev server
npm run dev
```

---

# 🇫🇷 Documentation en Français

## 🌍 Présentation Générale

**Fatibara** est une marketplace e-commerce locale connectant acheteurs, vendeurs locaux et livreurs à travers toute la Guinée. La plateforme gère l'intégralité du cycle commercial : découverte de produits, panier multi-vendeurs, paiements par Mobile Money (LengoPay), exécution des commandes, répartition en temps réel des livraisons et outils de croissance propulsés par l'IA.

Conçue pour un usage **mobile-first** et adaptée aux réseaux à faible bande passante à Conakry et en province, l'interface est entièrement en français et adaptée aux réalités guinéennes :
* **Devise :** Franc Guinéen (GNF) avec formatage monétaire local.
* **Système d'adresse :** Sélection par commune, quartier et géolocalisation GPS.
* **Paiements :** Orange Money, Wave et MTN Mobile Money via l'API LengoPay.

---

## ✨ Fonctionnalités Détaillées

### 🛒 Espace Acheteur
* **Découverte Produit :** Navigation par catégorie, recherche textuelle avancée, tendances et ventes flash.
* **Recherche IA & Visuelle :** Recherche sémantique propulsée par **Google Gemini** avec analyse d'image par caméra.
* **Autour de moi :** Détection géolocalisée des boutiques à proximité et calcul de livraison.
* **Panier & Commande :** Prise en charge des paniers multi-vendeurs, codes promos et sélection d'adresse sur carte interactive.
* **Paiement Mobile Money :** Intégration native LengoPay avec vérification sécurisée par OTP.
* **Suivi de Commande :** Statut en temps réel, suivi GPS du livreur et code de confirmation à la livraison.
* **PWA & Mode Hors Ligne :** Installable sur iOS/Android avec mise en cache hors ligne via Service Worker.

### 🏪 Espace Vendeur (`/vendor/*`)
* **Tableau de Bord KPI :** Graphiques de revenus en temps réel, volume des ventes et fil d'activité.
* **Gestion du Catalogue :** Création et modification de produits avec génération de descriptions par IA, compression d'images, déclinaisons (variantes) et prix dégressifs.
* **Kanban des Commandes :** Suivi visuel séquentiel (`en_attente → payé → en_préparation → prêt → livré`).
* **Boosts Marketing IA :** Campagnes de promotion ciblées selon 6 formules de durée.
* **Portefeuille & Finances :** Relevé de compte, demandes de retrait instantanées et suivi automatisé des commissions.
* **Messagerie Directe :** Chat en temps réel acheteur-vendeur avec contexte de la commande rattaché.

### 🚚 Espace Livreurs (`/courier-dashboard`)
* Inscription et vérification de la flotte de coursiers.
* Tableau des livraisons disponibles avec compte à rebours d'acceptation et guidage GPS.
* Validation sécurisée des remises de colis par code OTP.
* Historique des gains et statistiques de satisfaction client.

### 🛡️ Panneau d'Administration (`/admin`)
* Supervision globale des utilisateurs, boutiques, produits et livraisons.
* Audit financier sécurisé par **RLS (Row Level Security)** et ajustements manuels.
* Gestionnaire d'annonces de la plateforme et bannières promotionnelles.

---

## 🏗️ Architecture Technique

| Couche | Technologie Utilisée |
|---|---|
| **Interface Utilisateur** | React 19 + TypeScript 5.8 |
| **Routage** | React Router v7 |
| **Gestion d'État** | Zustand v5 |
| **Style & Animations** | TailwindCSS v4 + Motion (Framer Motion v12) |
| **Cartographie** | Leaflet + React-Leaflet |
| **Backend & Base de Données** | Supabase (PostgreSQL, RLS, Realtime, Storage) |
| **Moteur d'IA** | Google Gemini API (`@google/genai`) |
| **Passerelle de Paiement** | LengoPay API (Mobile Money Guinée) |
| **Serveur Backend** | Express.js + tsx (dev) / esbuild (prod) |
| **Outil de Build** | Vite 6 + esbuild |
| **Hébergement** | Vercel (Frontend & Fonctions Serverless API) |

---

## 📁 Structure du Projet

```
Fatibara-2.0/
├── api/                  # Endpoints Express Serverless (Paiements, Webhooks)
├── e2e/                  # Tests d'intégration Playwright
├── src/
│   ├── app/              # Page d'accueil principale
│   ├── components/       # Composants UI réutilisables (70+ composants)
│   ├── context/          # Contextes React (Notifications, État Global)
│   ├── hooks/            # Hooks React personnalisés
│   ├── lib/              # Clients Supabase, Sentry et utilitaires
│   ├── pages/            # Vues (Acheteur, Vendeur, Livreur, Admin)
│   ├── services/         # Abstractions API (Gemini IA, LengoPay)
│   ├── store/            # Stores Zustand
│   └── utils/            # Fonctions utilitaires et formatage
├── supabase/             # Migrations SQL et schémas de base de données
├── server.ts             # Point d'entrée du serveur Express
└── vite.config.ts        # Configuration du bundler Vite
```

---

## 🚀 Guide d'Installation Locale

### Prérequis
* **Node.js** `>= 20.0.0`
* Un projet **Supabase** actif — [supabase.com](https://supabase.com)
* Une clé d'API **Google Gemini** — [aistudio.google.com](https://aistudio.google.com/)

### 1. Clonage et Installation

```bash
git clone https://github.com/kconde-dev/Fatibara-2.0.git
cd Fatibara-2.0
npm install
```

### 2. Configuration des Variables d'Environnement

Créez le fichier `.env.local` à partir de l'exemple :

```bash
cp .env.example .env.local
```

Renseignez les variables nécessaires :

```env
# Configuration Application
APP_URL="http://localhost:3000"
NODE_ENV="development"

# Supabase
VITE_SUPABASE_URL="https://votre-projet.supabase.co"
VITE_SUPABASE_ANON_KEY="votre-cle-anon"
SUPABASE_SERVICE_ROLE_KEY="votre-cle-service-role"

# Moteur IA Google Gemini
GEMINI_API_KEY="votre-cle-gemini"

# Paiements LengoPay (Guinée)
LENGOPAY_SECRET_KEY="cle-secrete-lengopay"
LENGOPAY_WEBSITE_ID="id-site-lengopay"
LENGOPAY_WEBHOOK_SECRET="secret-webhook-lengopay"
```

### 3. Initialisation de la Base de Données

Exécutez les scripts de migration SQL dans l'**Éditeur SQL de Supabase** dans l'ordre suivant :

1. `supabase/migrations/20240101000000_foundation_schema.sql`
2. `supabase/migrations/20260917000000_comprehensive_fatibara_schema.sql`
3. `supabase_rls_policies.sql`
4. `fix_vendor_fulfillment.sql`

> *Note : Tous les scripts sont conçus pour être réexécutables en toute sécurité (`IF NOT EXISTS` / `OR REPLACE`).*

### 4. Lancement du Serveur de Développement

```bash
npm run dev
```

L'application sera accessible sur **http://localhost:3000** avec rechargement à chaud (HMR) et le serveur Express API combinés.

---

## 🗄️ Schéma de Base de Données & Machine d'État

### Tables Principales

| Nom de la Table | Rôle |
|---|---|
| `profiles` | Comptes utilisateurs et rôles actifs (`buyer`, `vendor`, `courier`, `admin`) |
| `stores` | Profils des boutiques vendeurs, zones géographiques et statuts |
| `products` | Produits, stocks, variantes et prix |
| `orders` | Suivi des commandes, montants et adresses de livraison |
| `deliveries` | Missions de livraison, coordonnées GPS et codes OTP |
| `wallets` | Solde des portefeuilles vendeurs et livreurs |
| `transactions` | Historique financier immuable de la plateforme |

### Machine d'État des Commandes

```
[ pending ] ──► [ paid ] ──► [ accepted ] ──► [ preparing ] ──► [ ready_for_pickup ] ──► [ in_transit ] ──► [ delivered ]
     │                                                                                                           │
     └───────────────────────────────────────► [ cancelled ] ◄───────────────────────────────────────────────────┘
```

---

## 🧪 Tests & Qualité du Code

```bash
# Vérification du typage TypeScript
npm run lint

# Exécution de la suite de tests E2E (Playwright)
npx playwright test
```

---

## ☁️ Déploiement sur Vercel

Le projet inclut une configuration `vercel.json` prête pour le déploiement serverless :

```bash
npm install -g vercel
vercel --prod
```

Assurez-vous d'ajouter toutes les variables du fichier `.env.example` dans **Vercel → Settings → Environment Variables**.

---

## 📄 Licence

Projet distribué sous la licence Apache 2.0. Voir le fichier [`LICENSE`](LICENSE) pour plus de détails.

---

<div align="center">
  <strong>Développé avec ❤️ pour la Guinée 🇬🇳</strong><br/>
  <sub>Fatibara — La marketplace locale de confiance</sub>
</div>