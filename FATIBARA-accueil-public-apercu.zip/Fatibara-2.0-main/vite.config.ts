import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import path from 'path';
import { defineConfig, loadEnv } from 'vite';
import { VitePWA } from 'vite-plugin-pwa';

function cleanEnvJwt(key?: string): string {
  if (!key) return '';
  const match = key.match(/^[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+/);
  return match ? match[0] : key.trim().replace(/^["']|["']$/g, '');
}

if (process.env.VITE_SUPABASE_ANON_KEY) {
  process.env.VITE_SUPABASE_ANON_KEY = cleanEnvJwt(process.env.VITE_SUPABASE_ANON_KEY);
}

export default defineConfig(({ mode }) => {
  const env = loadEnv(mode, process.cwd(), '');
  return {
    plugins: [
      react(),
      tailwindcss(),
      VitePWA({
        registerType: 'autoUpdate',
        includeAssets: ['cubes.png'],
        manifest: {
          name: 'Marketplace Fatibara',
          short_name: 'Fatibara',
          description: 'La marketplace locale de confiance en Guinée',
          theme_color: '#0f0f0f',
          background_color: '#0f0f0f',
          display: 'standalone',
          start_url: '.',
          scope: '/',
          icons: [
            {
              src: 'https://miizhdzuxidilrzwdivk.supabase.co/storage/v1/object/public/assets/favicon_fatibara.png',
              sizes: '192x192',
              type: 'image/png'
            },
            {
              src: 'https://miizhdzuxidilrzwdivk.supabase.co/storage/v1/object/public/assets/favicon_fatibara.png',
              sizes: '512x512',
              type: 'image/png',
              purpose: 'any maskable'
            }
          ]
        },
        // Recommendation 7: limit precache to ≤500 kB per file so large JS chunks
        // (recharts/d3, maps, motion) are not force-downloaded on first install.
        // Large chunks are served via runtime CacheFirst instead.
        workbox: {
          maximumFileSizeToCacheInBytes: 3_000_000,
          cleanupOutdatedCaches: true,
          skipWaiting: true,
          clientsClaim: true,
          // Explicitly exclude share-modal.js from the precache manifest so the
          // new SW never caches it. Old SWs that had it cached are evicted by
          // cleanupOutdatedCaches + the SW guard in index.html.
          globIgnores: ['**/share-modal.js'],
          navigateFallback: 'index.html',
          navigateFallbackAllowlist: [/^(?!\/api\/).*/],
          runtimeCaching: [

            {
              // Supabase REST API calls — NetworkFirst so the feed always reads
              // fresh data when online. Cache is used as offline fallback only.
              // networkTimeoutSeconds evicts requests that hang on slow 2G before
              // falling back to the cache (aligns with DEFAULT_QUERY_TIMEOUT_MS).
              urlPattern: /supabase\.co\/rest\//,
              handler: 'NetworkFirst',
              options: {
                cacheName: 'supabase-api-v1',
                networkTimeoutSeconds: 10,
                expiration: {
                  maxEntries: 50,
                  maxAgeSeconds: 60 * 5, // 5 min — offline fallback only
                },
              },
            },
            {
              // Charts (recharts + d3), maps (leaflet), animation (motion) vendor chunks
              urlPattern: /\/assets\/(vendor|chunk)-[^.]+\.js$/,
              handler: 'CacheFirst',
              options: {
                cacheName: 'large-vendor-chunks',
                expiration: { maxAgeSeconds: 60 * 60 * 24 * 30 }, // 30 days
              },
            },
          ],
        },
        devOptions: {
          enabled: false,
        }
      }),
    ],
    build: {
      target: 'esnext',
      minify: 'esbuild',
      cssMinify: true,
      modulePreload: false,
      rollupOptions: {
        output: {
          manualChunks(id) {
            if (id.includes('node_modules/recharts') || id.includes('node_modules/d3-') || id.includes('node_modules/victory')) {
              return 'vendor-charts';
            }
          },
        },
      },
    },
    resolve: {
      alias: {
        '@': path.resolve(__dirname, '.'),
      },
      dedupe: ['react', 'react-dom'],
    },
    server: {
      host: '0.0.0.0',
      port: 3000,
      hmr: false,
    },
  };
});
