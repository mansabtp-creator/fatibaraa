-- WAVE 7: SYSTEM SAFETY & AUTOMATED HOUSEKEEPING
-- This script adds system health monitoring and automated maintenance tasks.

-- 1. SYSTEM HEALTH LOGS (Diagnostics)
CREATE TABLE IF NOT EXISTS public.system_health_logs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    component TEXT NOT NULL,
    status TEXT NOT NULL, -- 'ok', 'warning', 'critical'
    details JSONB,
    created_at TIMESTAMPTZ DEFAULT now()
);

-- 2. AUTOMATED HOUSEKEEPING TASKS (e.g., archive old logs/tickets)
CREATE TABLE IF NOT EXISTS public.housekeeping_tasks (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    task_name TEXT NOT NULL,
    last_run TIMESTAMPTZ DEFAULT now(),
    status TEXT DEFAULT 'pending' -- 'pending', 'running', 'completed', 'failed'
);

-- 3. ENABLE RLS
ALTER TABLE public.system_health_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.housekeeping_tasks ENABLE ROW LEVEL SECURITY;

-- 4. POLICIES
CREATE POLICY "Health logs viewable by admins only" 
ON public.system_health_logs FOR SELECT 
USING (EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND is_admin = true));

CREATE POLICY "Housekeeping logs viewable by admins only" 
ON public.housekeeping_tasks FOR SELECT 
USING (EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND is_admin = true));
