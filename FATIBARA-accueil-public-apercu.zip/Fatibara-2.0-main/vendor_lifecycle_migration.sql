-- ============================================================
-- VENDOR LIFECYCLE MIGRATION
-- Run this in your Supabase SQL Editor (Project > SQL Editor)
-- ============================================================

-- 1. Ensure store_status column exists (safe to re-run)
ALTER TABLE public.stores 
  ADD COLUMN IF NOT EXISTS store_status TEXT DEFAULT 'active';

-- 2. Drop existing CHECK constraint (name may vary) and re-add with 'archived'
ALTER TABLE public.stores DROP CONSTRAINT IF EXISTS stores_store_status_check;
ALTER TABLE public.stores ADD CONSTRAINT stores_store_status_check 
  CHECK (store_status IN ('active', 'suspended', 'pending', 'holiday', 'archived'));

-- 3. Ensure balance column exists (safe to re-run)
ALTER TABLE public.stores 
  ADD COLUMN IF NOT EXISTS balance BIGINT DEFAULT 0;

-- 4. Create admin-bypass UPDATE policy for store lifecycle management
--    (requires the is_admin() helper from wave2_admin_infrastructure.sql)
DROP POLICY IF EXISTS "Admins can update any store status" ON public.stores;
CREATE POLICY "Admins can update any store status"
  ON public.stores FOR UPDATE
  USING (
    auth.uid() = owner_id      -- owner can still update their own store
    OR public.is_admin()       -- admin can update ANY store
  );

-- 5. Ensure admin can delete any store (for hard-delete feature)
DROP POLICY IF EXISTS "Admins can delete any store" ON public.stores;
CREATE POLICY "Admins can delete any store"
  ON public.stores FOR DELETE
  USING (
    auth.uid() = owner_id      -- owner can delete their own
    OR public.is_admin()       -- admin can delete any
  );

-- Verify
SELECT column_name, data_type, column_default 
FROM information_schema.columns 
WHERE table_name = 'stores' 
  AND column_name IN ('store_status', 'balance', 'is_verified_store');
