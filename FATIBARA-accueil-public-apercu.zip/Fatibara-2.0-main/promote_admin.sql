-- Promote the user to Admin status
UPDATE public.profiles 
SET is_admin = true 
WHERE id = 'c620a30d-5828-4066-9d59-8db34c28d20d';

-- Ensure the user exists in the profiles table if not already (safeguard)
INSERT INTO public.profiles (id, full_name, is_admin)
VALUES ('c620a30d-5828-4066-9d59-8db34c28d20d', 'Administrator', true)
ON CONFLICT (id) DO UPDATE 
SET is_admin = true;
