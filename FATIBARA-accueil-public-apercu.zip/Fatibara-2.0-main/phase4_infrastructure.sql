-- PHASE 4: FINANCIAL & CUSTOMIZATION INFRASTRUCTURE

-- 1. EXTEND STORES TABLE
ALTER TABLE public.stores 
ADD COLUMN IF NOT EXISTS bio TEXT,
ADD COLUMN IF NOT EXISTS banner_url TEXT,
ADD COLUMN IF NOT EXISTS balance DECIMAL(12,2) DEFAULT 0.00;

-- 2. WITHDRAWAL REQUESTS
CREATE TABLE IF NOT EXISTS public.withdrawals (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    store_id UUID REFERENCES public.stores(id) NOT NULL,
    amount DECIMAL(12,2) NOT NULL,
    method TEXT NOT NULL, -- 'Orange Money', 'MTN MoMo'
    phone_number TEXT NOT NULL,
    status TEXT DEFAULT 'pending', -- 'pending', 'processed', 'rejected'
    notes TEXT,
    created_at TIMESTAMPTZ DEFAULT now(),
    processed_at TIMESTAMPTZ
);

ALTER TABLE public.withdrawals ENABLE ROW LEVEL SECURITY;

-- 3. WALLET TRANSACTIONS (Audit for balance changes)
CREATE TABLE IF NOT EXISTS public.wallet_transactions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    store_id UUID REFERENCES public.stores(id) NOT NULL,
    amount DECIMAL(12,2) NOT NULL, -- Positive for sales, negative for withdrawals
    type TEXT NOT NULL, -- 'sale', 'withdrawal', 'adjustment'
    reference_id UUID, -- order_id or withdrawal_id
    description TEXT,
    created_at TIMESTAMPTZ DEFAULT now()
);

ALTER TABLE public.wallet_transactions ENABLE ROW LEVEL SECURITY;

-- 4. POLICIES
-- Withdrawals: Vendors can view/create their own, Admins can view/update all
CREATE POLICY "Vendors can view own withdrawals" ON public.withdrawals FOR SELECT USING (store_id IN (SELECT id FROM public.stores WHERE owner_id = auth.uid()));
CREATE POLICY "Vendors can request withdrawals" ON public.withdrawals FOR INSERT WITH CHECK (store_id IN (SELECT id FROM public.stores WHERE owner_id = auth.uid()));
CREATE POLICY "Admins full access to withdrawals" ON public.withdrawals FOR ALL USING ((SELECT is_admin FROM public.profiles WHERE id = auth.uid()) = true);

-- Wallet Transactions: Vendors see own, Admins see all
CREATE POLICY "Vendors can view own transactions" ON public.wallet_transactions FOR SELECT USING (store_id IN (SELECT id FROM public.stores WHERE owner_id = auth.uid()));
CREATE POLICY "Admins full access to transactions" ON public.wallet_transactions FOR ALL USING ((SELECT is_admin FROM public.profiles WHERE id = auth.uid()) = true);
