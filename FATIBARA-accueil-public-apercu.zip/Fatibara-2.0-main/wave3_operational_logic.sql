
-- WAVE 3: FINANCIAL & OPERATIONAL LOGIC REPAIR
-- This script adds missing columns and settings required for logic-heavy calculations.

-- 1. ADD COURIER STATUS TO PROFILES
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS courier_status TEXT DEFAULT 'inactive';
ALTER TABLE public.profiles DROP CONSTRAINT IF EXISTS profiles_courier_status_check;
ALTER TABLE public.profiles ADD CONSTRAINT profiles_courier_status_check CHECK (courier_status IN ('inactive', 'active', 'on_delivery', 'suspended'));

-- 2. UPDATE PROFILE TYPE CHECK
-- Some versions of the schema might limit types. Let's ensure 'courier' is included if the field exists.
ALTER TABLE public.profiles DROP CONSTRAINT IF EXISTS profiles_profile_type_check;
ALTER TABLE public.profiles ADD CONSTRAINT profiles_profile_type_check CHECK (profile_type IN ('client', 'pro', 'vendor', 'admin', 'courier'));

-- 3. ORDERS FINANCIAL TRACKING
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS financial_status TEXT DEFAULT 'pending';
ALTER TABLE public.orders DROP CONSTRAINT IF EXISTS orders_financial_status_check;
ALTER TABLE public.orders ADD CONSTRAINT orders_financial_status_check CHECK (financial_status IN ('pending', 'processed', 'refunded'));

ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS vendor_delivery_fee NUMERIC DEFAULT 0;

-- 4. ENSURE PLATFORM SETTINGS DEFAULTS
INSERT INTO public.platform_settings (id, value, description)
VALUES 
('commission_rate', '12', 'Standard Platform Fee (%)'),
('withdrawal_delay', '3', 'Days to hold funds before withdrawal availability'),
('referral_bonus', '5000', 'GNF earned per verified referral join'),
('min_withdrawal', '50000', 'Minimum GNF amount allowed for withdrawal')
ON CONFLICT (id) DO NOTHING;

-- 5. RLS UPDATES FOR NEW COLUMNS
-- Ensure admins can update everything
DROP POLICY IF EXISTS "Admins have full profile access" ON public.profiles;
CREATE POLICY "Admins have full profile access" ON public.profiles FOR ALL USING (
  EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND is_admin = true)
);

DROP POLICY IF EXISTS "Admins have full order access" ON public.orders;
CREATE POLICY "Admins have full order access" ON public.orders FOR ALL USING (
  EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND is_admin = true)
);
