import { supabase } from '../lib/supabase';

export async function getPlatformSettingsValue(id: string, defaultValue: string): Promise<string> {
  const { data, error } = await supabase
    .from('platform_settings')
    .select('value')
    .eq('id', id)
    .single();
  
  if (error) return defaultValue;
  return data.value;
}

export async function refundOrderFinancials(orderId: string, cancelReason: string = 'Annulation') {
  try {
    const { data, error } = await supabase.rpc('secure_refund_order_financials', {
      p_order_id: orderId,
      p_cancel_reason: cancelReason
    });

    if (error) throw error;
    return data;
  } catch (error) {
    console.error("Refund failed:", error);
    throw error;
  }
}

export async function processOrderFinancials(orderId: string) {
  try {
    const { data, error } = await supabase.rpc('secure_process_order_financials', {
      p_order_id: orderId
    });

    if (error) throw error;
    return data;
  } catch (error) {
    console.error("Financial processing failed:", error);
    throw error;
  }
}
