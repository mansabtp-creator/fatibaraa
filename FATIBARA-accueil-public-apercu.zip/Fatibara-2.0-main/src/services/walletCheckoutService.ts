import { supabase } from '../lib/supabase';
import { formatGNF } from '../utils/formatters';

export interface WalletCheckoutParams {
  userId: string;
  totalAmount: number;
  orders: any[];
  deliveries: any[];
  orderItems: any[][];
  couponCode?: string | null;
}

export interface WalletCheckoutResult {
  success: boolean;
  orderIds: string[];
  fallbackUsed?: boolean;
}

/**
 * Service to execute wallet payments with atomic RPC call
 * and safe client-side fallback if RPC fails or is unavailable.
 */
export const walletCheckoutService = {
  async processCheckout(params: WalletCheckoutParams): Promise<WalletCheckoutResult> {
    const { userId, totalAmount, orders, deliveries, orderItems, couponCode } = params;
    const roundedTotal = Math.round(totalAmount);

    if (!userId) {
      throw new Error('Utilisateur non identifié. Veuillez vous reconnecter.');
    }

    if (isNaN(roundedTotal) || roundedTotal <= 0) {
      throw new Error('Montant de la commande invalide.');
    }

    // Ensure order status is set to 'confirmed' for wallet payments
    const confirmedOrders = orders.map(ord => ({
      ...ord,
      status: 'confirmed',
      user_id: userId
    }));

    // ── 1. Attempt Primary RPC Execution ────────────────────────────────────
    try {
      const { data: rpcResult, error: rpcError } = await supabase.rpc('process_wallet_checkout', {
        p_user_id: userId,
        p_total_amount: roundedTotal,
        p_orders: confirmedOrders,
        p_deliveries: deliveries,
        p_order_items: orderItems
      });

      if (!rpcError) {
        const ids = Array.isArray(rpcResult) ? rpcResult.map((r: any) => r.id || r) : [];
        
        // If coupon was applied, increment usage count asynchronously
        if (couponCode) {
          supabase.rpc('increment_coupon_usage', { p_code: couponCode }).then(() => {});
        }

        return { success: true, orderIds: ids };
      }

      console.warn('[walletCheckoutService] RPC call failed, testing user-friendly exception:', rpcError.message);

      // Translate known RPC exception messages
      const msg = rpcError.message || '';
      if (msg.includes('Solde insuffisant') || msg.includes('Insufficient wallet')) {
        throw new Error('Solde insuffisant dans votre portefeuille — veuillez recharger votre compte.');
      }
      if (msg.includes('Profil introuvable')) {
        throw new Error('Profil utilisateur introuvable. Veuillez vous reconnecter.');
      }

    } catch (rpcCatchErr: any) {
      // Re-throw user balance insufficiency or auth error directly
      if (
        rpcCatchErr.message?.includes('Solde insuffisant') ||
        rpcCatchErr.message?.includes('recharger votre compte') ||
        rpcCatchErr.message?.includes('reconnecter')
      ) {
        throw rpcCatchErr;
      }
      console.warn('[walletCheckoutService] Falling back to direct database execution:', rpcCatchErr.message);
    }

    // ── 2. Safe Direct Fallback Execution ───────────────────────────────────
    // Fetch live user balance from DB
    const { data: profile, error: profErr } = await supabase
      .from('profiles')
      .select('wallet_balance')
      .eq('id', userId)
      .maybeSingle();

    if (profErr || !profile) {
      throw new Error('Impossible de vérifier le solde du portefeuille. Réessayez dans un instant.');
    }

    const currentBalance = Number(profile.wallet_balance || 0);

    if (currentBalance < roundedTotal) {
      throw new Error(
        `Solde insuffisant dans votre portefeuille. Solde disponible: ${formatGNF(currentBalance)}, Total requis: ${formatGNF(roundedTotal)}.`
      );
    }

    // A. Deduct balance from profile
    const newBalance = currentBalance - roundedTotal;
    const { error: deductErr } = await supabase
      .from('profiles')
      .update({ wallet_balance: newBalance })
      .eq('id', userId)
      .gte('wallet_balance', roundedTotal);

    if (deductErr) {
      console.error('[walletCheckoutService] Balance deduction failed:', deductErr.message);
      throw new Error('Échec du débit du portefeuille. Veuillez réessayer.');
    }

    // B. Create wallet_transaction record via backend proxy (prevents client RLS 403)
    await fetch('/api/wallet/record-transaction', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        profile_id: userId,
        amount: -roundedTotal,
        type: 'purchase',
        status: 'completed',
        description: 'Achat de commande via Portefeuille'
      }),
    }).catch((err) => {
      console.warn('[walletCheckoutService] Wallet transaction record note:', err);
    });

    // C. Insert orders
    const createdOrderIds: string[] = [];

    for (let i = 0; i < confirmedOrders.length; i++) {
      const ordPayload = confirmedOrders[i];
      const delPayload = deliveries[i] || { status: 'pending' };
      const itemsPayload = orderItems[i] || [];

      // Insert Order
      const { data: createdOrd, error: ordErr } = await supabase
        .from('orders')
        .insert(ordPayload)
        .select('id')
        .single();

      if (ordErr || !createdOrd) {
        console.error('[walletCheckoutService] Order insertion error:', ordErr?.message);
        continue;
      }

      const orderId = createdOrd.id;
      createdOrderIds.push(orderId);

      // Insert Delivery
      await supabase.from('deliveries').insert({
        ...delPayload,
        order_id: orderId
      });

      // Insert Order Items
      if (itemsPayload.length > 0) {
        const itemRows = itemsPayload.map((item: any) => ({
          ...item,
          order_id: orderId
        }));
        await supabase.from('order_items').insert(itemRows);
      }
    }

    if (createdOrderIds.length === 0) {
      // Revert balance if order creation completely failed
      await supabase.from('profiles').update({ wallet_balance: currentBalance }).eq('id', userId);
      throw new Error('Erreur lors de la création de la commande. Votre solde a été restauré.');
    }

    // Increment coupon usage if used
    if (couponCode) {
      supabase.rpc('increment_coupon_usage', { p_code: couponCode }).then(() => {});
    }

    return {
      success: true,
      orderIds: createdOrderIds,
      fallbackUsed: true
    };
  }
};
