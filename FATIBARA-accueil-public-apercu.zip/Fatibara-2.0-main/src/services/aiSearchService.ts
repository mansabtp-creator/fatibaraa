import { aiClient as ai } from "../lib/ai-client";
import { APP_NAME } from "../lib/constants";

export interface SmartSearchFilters {
  category?: string;
  minPrice?: number;
  maxPrice?: number;
  keywords?: string[];
  intent?: 'buy' | 'info' | 'compare';
  description?: string;
}

export async function interpretSearchQuery(query: string): Promise<SmartSearchFilters | null> {
  if (query.length < 3) return null;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3.8-flash",
      contents: [
        {
          role: "user",
          parts: [{
            text: `Analyze this user search query for an e-commerce marketplace in Guinea (${APP_NAME}): "${query}"
            Extract structured data in JSON format for search filters.
            Only return the JSON object.`
          }]
        }
      ],
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: "OBJECT",
          properties: {
            category: { type: "STRING", description: "One of: Phones, Laptops, Fashion, Local, Services, etc" },
            minPrice: { type: "NUMBER" },
            maxPrice: { type: "NUMBER" },
            keywords: { type: "ARRAY", items: { type: "STRING" } },
            intent: { type: "STRING", enum: ["buy", "info", "compare"] }
          }
        }
      }
    });

    return JSON.parse(response.text || '{}');
  } catch (error: any) {
    console.error("AI Search Interpretation Error:", error);
    if (error?.message?.includes('403') || error?.message?.includes('suspended')) {
      return { keywords: [query], intent: 'buy' }; // Fallback with original query
    }
    return null;
  }
}

export async function analyzeSearchImage(base64Image: string, mimeType: string = "image/jpeg"): Promise<SmartSearchFilters | null> {

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3.8-flash",
      contents: [
        {
          role: "user",
          parts: [
            { inlineData: { data: base64Image, mimeType } },
            { text: "Identify the product in this image. Extract search filters like category, estimated market price in GNF, and keywords." }
          ]
        }
      ],
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: "OBJECT",
          properties: {
            category: { type: "STRING" },
            maxPrice: { type: "NUMBER" },
            keywords: { type: "ARRAY", items: { type: "STRING" } },
            description: { type: "STRING", description: "A short 3-word description for the search box" }
          }
        }
      }
    });

    return JSON.parse(response.text || '{}');
  } catch (error) {
    console.error("AI Image Search Error:", error);
    return null;
  }
}
