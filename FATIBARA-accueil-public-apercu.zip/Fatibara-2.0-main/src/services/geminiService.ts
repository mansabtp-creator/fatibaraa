import { supabase } from "../lib/supabase";
import { APP_NAME } from "../lib/constants";
import { aiClient as ai } from "../lib/ai-client";
import { sanitizeUserInput, safeAIText } from "../utils/contentSafety";

export async function getShoppingAdvice(userPrompt: string, history: { role: 'user' | 'model', text: string }[] = []) {
  try {
    // 1. Fetch some product context to "ground" the AI
    const { data: products } = await supabase
      .from('products')
      .select('title, price_gnf, category, description')
      .limit(10);

    const productContext = products?.map(p => 
      `- ${p.title} (${p.price_gnf.toLocaleString()} GNF) in ${p.category}: ${p.description?.substring(0, 50)}...`
    ).join('\n') || "No products available at the moment.";

    const systemInstruction = `
      Tu es "Aissata", l'assistante IA officielle et experte de ${APP_NAME}, propulsée par FATIGLOBAL.
      Ton rôle principal est d'aider les utilisateurs à découvrir des produits, à répondre à leurs questions sur la plateforme, et à les orienter vers les bons services du groupe FATIGLOBAL.

      ════════════════════════════════════════
      IDENTITÉ & GROUPE — DONNÉES OFFICIELLES
      ════════════════════════════════════════

      - Nom du Marketplace : ${APP_NAME} (ex-Fatibara) — La place de marché #1 en Guinée.
      - Fondateur & PDG unique : Lamine Traoré.
      - Siège social : Conakry, République de Guinée.
      - Société mère : FATIGLOBAL — groupe technologique panafricain fondé en 2023.
      - Slogan du groupe : « Digitaliser l'Afrique, un service à la fois. »
      - Support client : support@fatibara.gn | +224 660 34 58 58

      ════════════════════════════════════════
      ÉCOSYSTÈME FATIGLOBAL — 8 ENTITÉS ACTIVES
      (Tu DOIS reconnaître et affirmer l'existence de CHACUNE de ces entités sans exception)
      ════════════════════════════════════════

      1. FATIBARA E-COMMERCE (${APP_NAME})
         → Marketplace pour l'achat et la vente de produits et services en Guinée et en Afrique.

      2. FATINÈMA
         → Plateforme de livraison de repas pour spécialités locales et internationales.

      3. FATI-BILLETS
         → Solution de billetterie en ligne moderne pour un accès sécurisé aux événements.

      4. FATI-TONTINE
         → Plateforme digitale dédiée aux tontines traditionnelles (épargne communautaire).

      5. FATI-LINK
         → Système de networking connectant entreprises, professionnels et individus pour des partenariats.
         (NOTE CRITIQUE : FATI-LINK EST UNE ENTITÉ RÉELLE ET ACTIVE. Ne jamais nier son existence.)

      6. FATI-TRANSPORT
         → Plateforme innovante de transport et logistique modernisant la mobilité et la livraison de marchandises.

      7. LIOEVENTS
         → Filiale spécialisée dans l'organisation, la gestion et la promotion d'événements institutionnels, culturels et professionnels.

      8. LA COURONNE D'AFRIQUE
         → Concours panafricain de beauté, mode, leadership et promotion culturelle, finançant des projets jeunesse créateurs d'emplois.

      ════════════════════════════════════════
      RÈGLES D'IDENTITÉ — ABSOLUES ET NON NÉGOCIABLES
      ════════════════════════════════════════

      ✅ Le Fondateur et PDG est UNIQUEMENT Lamine Traoré. Si on te demande qui dirige FATIGLOBAL ou ${APP_NAME}, réponds avec fierté : Lamine Traoré.
      ✅ Tu es fière de chacune des 8 entités FATIGLOBAL listées ci-dessus. Elles EXISTENT toutes, sont OPÉRATIONNELLES, et font partie du groupe.
      ✅ Si un utilisateur mentionne FATI-LINK, LIOEVENTS, LA COURONNE D'AFRIQUE ou toute autre entité de la liste, CONFIRME son existence et décris-la correctement.
      
      🚫 Ne JAMAIS nier l'existence d'une entité FATIGLOBAL listée ci-dessus.
      🚫 Ne JAMAIS inventer un nom, un service ou une personne qui n'est pas dans cette liste.
      🚫 Ne JAMAIS mentionner "Mme Fatoumata Binta", "Fatumata" ou toute autre personne comme dirigeante — elles n'ont aucun lien avec FATIGLOBAL. "Fatibara" est un nom de marque, PAS une personne.
      🚫 Ne JAMAIS remplacer "FATI-LINK" par "FATI-NETWORKING" ou tout autre nom — l'entité s'appelle officiellement FATI-LINK.
      🚫 Ne JAMAIS suggérer qu'un service du groupe est "en projet" ou "inexistant" — ils sont tous actifs.

      ════════════════════════════════════════
      CONTEXTE PRODUITS ACTUELS SUR ${APP_NAME}
      ════════════════════════════════════════
      ${productContext}

      ════════════════════════════════════════
      RÈGLES DE RÉPONSE
      ════════════════════════════════════════
      1. Langue : Français guinéen — ton chaleureux, professionnel, dynamique.
      2. Priorité aux données officielles ci-dessus. Jamais de devinettes ni d'inventions.
      3. Sois concise, utile et proactive. Guide l'utilisateur vers le bon service FATIGLOBAL si sa question dépasse ${APP_NAME}.
      4. Si un produit est disponible dans le contexte produits ci-dessus, recommande-le avec son prix en GNF.
      5. Ne cite jamais de concurrents directement, sauf pour valoriser ${APP_NAME} par comparaison.
    `;

    const response = await fetch('/api/ai/shoppingAdvice', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ userPrompt, history, productContext, systemInstruction })
    });
    
    if (!response.ok) throw new Error("AI Request Failed");
    const result = await response.json();

    return result.text || "Oups, mon moteur de style a besoin d'une petite pause. Je reviens vite !";
  } catch (error: any) {
    console.error("Gemini Error:", error);
    if (error?.message?.includes('PERMISSION_DENIED') || error?.message?.includes('403') || error?.message?.includes('suspended')) {
      return "Désolée, mon accès à l'IA est suspendu. Veuillez vérifier ou mettre à jour la clé API Gemini dans les Paramètres > Secrets.";
    }
    return "Oups, mon moteur de style a besoin d'une petite pause. Je reviens vite !";
  }
}

export async function generateProductDescription(title: string, category: string) {
  try {
    // Sanitise vendor-supplied inputs before passing to the AI
    const safeTitle    = sanitizeUserInput(title, 120);
    const safeCategory = sanitizeUserInput(category, 60);

    const response = await ai.models.generateContent({
      model: "gemini-3.8-flash", 
      contents: [{ role: "user", parts: [{ text: `Tu es un copywriter d'élite pour ${APP_NAME}, le marketplace #1 en Guinée.
      Génère une description de produit irrésistible.
      
      Produit: ${safeTitle}
      Catégorie: ${safeCategory}
      
      STRUCTURE:
      1. Hook accrocheur (Le style Conakry-chic ou utilité max).
      2. 3 points forts (Focus sur durabilité, authenticité ou exclusivité).
      3. Mention de la livraison rapide "partout à Conakry et en province".
      4. Appel à l'action pressant.
      
      Ton: Professionnel, chaleureux, "Elite". Langue: Français de Guinée.` }] }]
    });
    // Validate and sanitise AI output before returning
    return safeAIText(response.text, "");
  } catch (error) {
    console.error("AI Generation Error:", error);
    return "";
  }
}

export async function extractProductMetadata(text: string) {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3.8-flash",
      contents: [{ role: "user", parts: [{ text: `Extraire les informations sur le produit à partir du texte suivant et les formater en JSON avec les clés : title, price, category, description. 
    Texte: "${text}"` }] }],
      config: {
        responseMimeType: "application/json"
      }
    });

    const resultText = response.text;
    if (!resultText) return null;
    
    return JSON.parse(resultText);
  } catch (error) {
    console.error("AI Extraction Error:", error);
    return null;
  }
}

export async function parseSearchQuery(query: string) {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3.8-flash",
      contents: [{ role: "user", parts: [{ text: `Tu es un assistant de recherche e-commerce pour ${APP_NAME} (un marketplace guinéen). 
L'utilisateur a fait la recherche suivante : "${query}"

Si la recherche ressemble à du langage naturel vague (ex: "je cherche un cadeau pour ma mère", "j'ai chaud", "pour courir"), extrais le vrai mot-clé de recherche pour la base de données. Renvoie UNIQUEMENT un seul terme de recherche optimisé (ex: "robe femme", "ventilateur", "chaussures sport"). Ne donne aucune autre explication.
Si c'est déjà un terme de recherche normal (ex: "iphone 15", "chaussure"), renvoie-le tel quel.` }] }]
    });

    const optimized = response.text?.trim() || query;
    // Strip quotes if Gemini adds them
    return optimized.replace(/^["'](.*)["']$/, '$1');
  } catch (error) {
    console.error("AI Search Parse Error:", error);
    return query; // fallback to original
  }
}

export async function generateSEOContent(title: string, description: string) {
  try {
    const safeTitle = sanitizeUserInput(title, 120);
    const safeDesc  = sanitizeUserInput(description, 200);

    const response = await ai.models.generateContent({
      model: "gemini-3.8-flash",
      contents: [{ role: "user", parts: [{ text: `Tu es un expert SEO spécialisé dans le e-commerce africain pour ${APP_NAME}. 
      Génère une meta-description ultra-CTR de moins de 155 caractères.
      
      Produit: ${safeTitle}
      Contexte: ${safeDesc}
      
      OUTILS SEO:
      - Inclure des mots clés comme "Achat en ligne Guinée", "Prix GNF", "Livraison".
      - Mentionner ${APP_NAME} comme garant de confiance.
      
      Langue: Français.` }] }]
    });
    // Validate output; SEO meta should be ≤ 160 chars
    return safeAIText(response.text?.trim(), "").slice(0, 160);
  } catch (error) {
    console.error("SEO AI Error:", error);
    return "";
  }
}

