import { aiClient as ai } from "../lib/ai-client";
import { supabase } from "../lib/supabase";
import { APP_NAME } from "../lib/constants";

export interface PricingInsight {
  suggestedPrice: number;
  confidence: number;
  reasoning: string[];
  marketTrend: 'rising' | 'falling' | 'stable';
  competitorPriceRange?: { min: number; max: number };
}

export async function getAIDynamicPricing(
  productTitle: string, 
  category: string, 
  currentPrice: number,
  stockCount: number
): Promise<PricingInsight | null> {

  let minComp = 0;
  let maxComp = 0;

  try {
    // 1. Fetch some context from other products in same category
    const { data: competitors } = await supabase
      .from('products')
      .select('price_gnf')
      .eq('category', category)
      .limit(10);

    const competitorPrices = competitors?.map(c => c.price_gnf) || [];
    minComp = competitorPrices.length > 0 ? Math.min(...competitorPrices) : 0;
    maxComp = competitorPrices.length > 0 ? Math.max(...competitorPrices) : 0;

    const response = await ai.models.generateContent({
      model: "gemini-3.8-flash",
      contents: [
        {
          role: "user",
          parts: [{
            text: `Analyse de Tarification Elite pour le marketplace ${APP_NAME} (Guinée).
            
            DONNÉES DU PRODUIT:
            - Titre: ${productTitle}
            - Catégorie: ${category}
            - Prix Actuel: ${currentPrice} GNF
            - Stock restant: ${stockCount}
            - Fourchette Marché ${APP_NAME}: ${minComp} - ${maxComp} GNF
            
            MISSION: 
            Suggère un prix optimal en GNF pour maximiser le profit tout en restant compétitif. 
            Prends en compte la logistique à Conakry et le pouvoir d'achat local.
            Le raisonnement doit être en français et orienté "business d'élite".`
          }]
        }
      ],
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: "OBJECT",
          properties: {
            suggestedPrice: { type: "NUMBER" },
            confidence: { type: "NUMBER", description: "Indice de confiance 0-1" },
            reasoning: { type: "ARRAY", items: { type: "STRING" }, description: "3-4 points d'analyse du marché" },
            marketTrend: { type: "STRING", enum: ["rising", "falling", "stable"] }
          }
        }
      }
    });

    const result = JSON.parse(response.text || '{}');
    return {
      ...result,
      competitorPriceRange: { min: minComp, max: maxComp }
    };
  } catch (error: any) {
    console.error("AI Pricing Error:", error);
    if (error?.message?.includes('403') || error?.message?.includes('suspended')) {
      return {
        suggestedPrice: currentPrice,
        confidence: 0.5,
        reasoning: ["L'analyse IA est temporairement indisponible (Clé suspendue)."],
        marketTrend: 'stable',
        competitorPriceRange: { min: minComp, max: maxComp }
      };
    }
    return null;
  }
}
