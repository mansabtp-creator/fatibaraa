
export const adminService = {
  logSystemHealth: async (component: string, status: string, details: any) => {
    const response = await fetch('/api/admin/system-log', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ component, status, details }),
    });
    if (!response.ok) throw new Error('Failed to log system health');
    return response.json();
  },

  updateHousekeepingTask: async (task_name: string, status: string) => {
    const response = await fetch('/api/admin/housekeeping-task', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ task_name, status }),
    });
    if (!response.ok) throw new Error('Failed to update housekeeping task');
    return response.json();
  }
};
