import { supabase } from '../lib/supabase';

export interface Promotion {
  id: string;
  title: string;
  promo_type: 'flash_deal' | 'bogo' | 'coupon' | 'global_discount';
  discount_type: 'percentage' | 'fixed';
  discount_value: number;
  start_at: string;
  end_at: string;
  status: 'active' | 'inactive' | 'scheduled' | 'expired';
  code?: string;
  store_id?: string;
  product_ids?: string[];
}

export const promotionService = {
  async getActivePromotions() {
    const now = new Date().toISOString();
    const { data, error } = await supabase
      .from('promotions')
      .select('*, promotion_products(product_id)')
      .eq('status', 'active')
      .lte('start_at', now)
      .gte('end_at', now);
    
    if (error) throw error;
    
    return data.map(p => ({
      ...p,
      product_ids: p.promotion_products?.map((pp: any) => pp.product_id) || []
    }));
  },

  calculateDiscountedPrice(product: any, activePromos: Promotion[]) {
    let bestPrice = product.price_gnf;
    let appliedPromo = null;

    // Filter promos for this product or global promos
    const relevantPromos = activePromos.filter(promo => 
      (promo.promo_type === 'global_discount') ||
      (promo.store_id === product.store_id) ||
      (promo.product_ids?.includes(product.id))
    );

    for (const promo of relevantPromos) {
      let currentPrice = product.price_gnf;
      if (promo.discount_type === 'percentage') {
        currentPrice = product.price_gnf * (1 - promo.discount_value / 100);
      } else {
        currentPrice = Math.max(0, product.price_gnf - promo.discount_value);
      }

      if (currentPrice < bestPrice) {
        bestPrice = currentPrice;
        appliedPromo = promo;
      }
    }

    return {
      originalPrice: product.price_gnf,
      discountedPrice: bestPrice,
      hasDiscount: bestPrice < product.price_gnf,
      promo: appliedPromo
    };
  }
};
