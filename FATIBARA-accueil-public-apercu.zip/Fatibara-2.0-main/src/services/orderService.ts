import { supabase, safeSupabaseQuery } from '../lib/supabase';
import { Order, Delivery } from '../types';

export const orderService = {
  async getOrders(userId?: string) {
    let query = supabase.from('orders').select('*');
    if (userId) {
      query = query.or(`user_id.eq.${userId},vendor_id.eq.${userId}`);
    }
    return safeSupabaseQuery<Order[]>(query, 'list', 'orders');
  },

  async createOrder(order: Omit<Order, 'id' | 'created_at' | 'updated_at'>) {
    return safeSupabaseQuery<Order>(
      supabase.from('orders').insert(order).select().single(),
      'create',
      'orders'
    );
  },

  async updateOrderStatus(orderId: string, status: Order['status']) {
    return safeSupabaseQuery(
      supabase.from('orders').update({ status, updated_at: new Date().toISOString() }).eq('id', orderId),
      'update',
      'orders'
    );
  },

  async getDeliveryForOrder(orderId: string) {
    return safeSupabaseQuery<Delivery>(
      supabase.from('deliveries').select('*').eq('order_id', orderId).single(),
      'get',
      'deliveries'
    );
  },

  async updateDeliveryStatus(deliveryId: string, status: Delivery['status'], location?: { lat: number; lng: number }) {
    const updateData: any = { status, updated_at: new Date().toISOString() };
    if (location) updateData.current_location = location;
    return safeSupabaseQuery(
      supabase.from('deliveries').update(updateData).eq('id', deliveryId),
      'update',
      'deliveries'
    );
  }
};
