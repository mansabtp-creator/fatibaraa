import { supabase } from '../lib/supabase';

/**
 * Inserts a record into `withdrawals` table handling column variations
 * (method vs payout_method, phone_number vs phone) across database schemas.
 */
async function insertWithdrawalRecord(record: {
  store_id?: string;
  profile_id?: string;
  amount: number;
  method: string;
  phone: string;
  status: string;
  created_at: string;
}) {
  const { store_id, profile_id, amount, method, phone, status, created_at } = record;

  const baseRow: any = {
    amount,
    status,
    created_at,
    requested_at: created_at,
    type: store_id ? 'vendor' : 'courier',
  };
  if (store_id) baseRow.store_id = store_id;
  if (profile_id) baseRow.profile_id = profile_id;

  // Try 1: Include both phone_number & phone to satisfy any NOT NULL schema constraint
  let res = await supabase.from('withdrawals').insert([{
    ...baseRow,
    method,
    phone_number: phone,
    phone: phone,
  }]);

  if (!res.error) return res;

  // Try 2: If 'phone' column doesn't exist on schema
  if (res.error && res.error.message?.includes('phone')) {
    res = await supabase.from('withdrawals').insert([{
      ...baseRow,
      method,
      phone_number: phone,
    }]);
    if (!res.error) return res;
  }

  // Try 3: If 'phone_number' column doesn't exist on schema
  if (res.error && res.error.message?.includes('phone_number')) {
    res = await supabase.from('withdrawals').insert([{
      ...baseRow,
      method,
      phone: phone,
    }]);
    if (!res.error) return res;
  }

  // Try 4: If 'method' column is named 'payout_method'
  if (res.error && res.error.message?.includes('method')) {
    res = await supabase.from('withdrawals').insert([{
      ...baseRow,
      payout_method: method,
      phone_number: phone,
      phone: phone,
    }]);
  }

  return res;
}

/**
 * Helper to attempt calling user withdrawal RPC using the single validated schema (p_amount, p_method, p_phone)
 */
async function tryUserWithdrawalRpc(amount: number, method: string, phone: string) {
  return await supabase.rpc('request_user_withdrawal', {
    p_amount: amount,
    p_method: method,
    p_phone: phone,
  });
}

/**
 * Service to handle withdrawal operations (requests, approvals, rejections).
 */
export const withdrawalService = {
  /**
   * Submits a vendor store withdrawal request with RPC signature auto-retry & DB fallback.
   */
  async requestVendorWithdrawal(params: { storeId: string; amount: number; method: string; phone: string; userId?: string }) {
    const { storeId, amount, method, phone, userId } = params;

    // Sanitize phone input
    let rawDigits = (phone || '').replace(/\D/g, '').replace(/^224/, '');
    const cleanPhone = rawDigits.length === 9 ? `+224${rawDigits}` : (rawDigits ? `+224${rawDigits}` : '');

    // 1. Try secure backend server route first (runs with server-side validation and Service Role to prevent 403 on ledger & schema mismatch)
    try {
      const { data: { session } } = await supabase.auth.getSession();
      const token = session?.access_token;
      const apiRes = await fetch('/api/vendor/withdraw', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(token ? { 'Authorization': `Bearer ${token}` } : {})
        },
        body: JSON.stringify({
          storeId,
          amount,
          method,
          phone: cleanPhone || phone,
          userId: userId || session?.user?.id
        })
      });

      if (apiRes.ok) {
        const apiJson = await apiRes.json();
        if (apiJson.success) {
          return { success: true, api: true };
        }
      } else {
        const errData = await apiRes.json().catch(() => ({}));
        // If the error was business logic (e.g. insufficient funds, store not found, auth), throw it directly
        if (apiRes.status === 400 || apiRes.status === 401 || apiRes.status === 403 || apiRes.status === 404) {
          throw new Error(errData.error || 'Erreur lors du traitement du retrait.');
        }
        console.warn('[withdrawalService] Backend route returned status', apiRes.status, errData.error);
      }
    } catch (apiErr: any) {
      if (apiErr.message && !apiErr.message.includes('fetch') && !apiErr.message.includes('network') && !apiErr.message.includes('Failed to fetch')) {
        throw apiErr;
      }
      console.warn('[withdrawalService] Server route fetch failed, falling back to direct DB:', apiErr.message);
    }

    // 2. Direct Fallback: Fetch store details (bypasses broken remote RPC to prevent phone_number 400 violations)
    const { data: storeData, error: fetchErr } = await supabase
      .from('stores')
      .select('balance, owner_id, is_verified_store, payout_orange_money, payout_mtn_money')
      .eq('id', storeId)
      .maybeSingle();

    if (fetchErr || !storeData) {
      throw new Error("Impossible de récupérer les informations de la boutique.");
    }

    const currentBalance = Number(storeData.balance || 0);

    // Ensure phone is guaranteed valid & non-null
    if (!rawDigits || rawDigits.length < 8) {
      const fallbackRaw = storeData.payout_orange_money || storeData.payout_mtn_money || '';
      rawDigits = fallbackRaw.replace(/\D/g, '').replace(/^224/, '');
    }
    if (!rawDigits || rawDigits.length < 8) {
      const ownerId = userId || storeData.owner_id;
      if (ownerId) {
        const { data: ownerProf } = await supabase.from('profiles').select('phone_number').eq('id', ownerId).maybeSingle();
        if (ownerProf?.phone_number) {
          rawDigits = ownerProf.phone_number.replace(/\D/g, '').replace(/^224/, '');
        }
      }
    }
    const finalPhone = rawDigits.length === 9 ? `+224${rawDigits}` : (rawDigits ? `+224${rawDigits}` : '+224610051553');

    // 3. Prevent Double Deduction: Check if RPC already created a pending withdrawal record in the last 2 minutes
    const twoMinutesAgo = new Date(Date.now() - 2 * 60 * 1000).toISOString();
    const { data: existingWd } = await supabase
      .from('withdrawals')
      .select('id, amount, created_at')
      .eq('store_id', storeId)
      .eq('status', 'pending')
      .gte('created_at', twoMinutesAgo)
      .order('created_at', { ascending: false })
      .limit(1);

    if (existingWd && existingWd.length > 0 && Number(existingWd[0].amount) === amount) {
      console.log('[withdrawalService] Pending withdrawal record already created by RPC. Skipping duplicate balance deduction.');
      return { success: true, fallback: true };
    }

    // 4. Validate available balance before direct deduction
    if (currentBalance < amount) {
      throw new Error(`Solde insuffisant sur votre compte. Solde disponible : ${currentBalance.toLocaleString('fr-FR')} GNF.`);
    }

    // 5. Insert withdrawal record FIRST
    const wdRes = await insertWithdrawalRecord({
      store_id: storeId,
      profile_id: userId || storeData.owner_id,
      amount: amount,
      method: method,
      phone: finalPhone,
      status: 'pending',
      created_at: new Date().toISOString()
    });

    if (wdRes.error) {
      console.error('[withdrawalService] Direct insert to withdrawals failed:', wdRes.error.message);
      throw new Error(`Erreur d'enregistrement du retrait: ${wdRes.error.message}`);
    }

    // 6. Deduct store balance ONCE
    const newBal = currentBalance - amount;
    const { error: updateErr } = await supabase
      .from('stores')
      .update({ balance: newBal })
      .eq('id', storeId)
      .gte('balance', amount);

    if (updateErr) {
      console.error('[withdrawalService] Failed to deduct store balance:', updateErr.message);
      throw new Error("Erreur lors de la déduction du solde de la boutique.");
    }

    // 7. Log wallet transaction safely via backend service-role proxy (avoids RLS 403 on client)
    try {
      await fetch('/api/wallet/record-transaction', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          store_id: storeId,
          profile_id: userId || storeData.owner_id,
          amount: -amount,
          type: 'withdrawal',
          status: 'completed',
          description: `Demande de retrait (${method.toUpperCase()}: ${finalPhone})`,
          reference_id: wdRes?.data?.[0]?.id,
        }),
      }).catch(() => {});
    } catch (logErr) {
      console.warn('[withdrawalService] Non-critical wallet_transactions log note:', logErr);
    }

    return { success: true, fallback: true };
  },

  /**
   * Submits a user/courier withdrawal request with RPC signature auto-retry & DB fallback.
   */
  async requestUserWithdrawal(params: { userId: string; amount: number; method: string; phone: string }) {
    const { userId, amount, method, phone } = params;

    // Sanitize phone input
    let rawDigits = (phone || '').replace(/\D/g, '').replace(/^224/, '');
    const cleanPhone = rawDigits.length === 9 ? `+224${rawDigits}` : (rawDigits ? `+224${rawDigits}` : '');

    // 1. Try secure backend server route first (runs with service role to prevent 403 on ledger & schema mismatch)
    try {
      const { data: { session } } = await supabase.auth.getSession();
      const token = session?.access_token;
      const apiRes = await fetch('/api/user/withdraw', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(token ? { 'Authorization': `Bearer ${token}` } : {})
        },
        body: JSON.stringify({
          amount,
          method,
          phone: cleanPhone || phone,
          userId: userId || session?.user?.id
        })
      });

      if (apiRes.ok) {
        const apiJson = await apiRes.json();
        if (apiJson.success) {
          return { success: true, api: true };
        }
      } else {
        const errData = await apiRes.json().catch(() => ({}));
        if (apiRes.status === 400 || apiRes.status === 401 || apiRes.status === 403 || apiRes.status === 404) {
          throw new Error(errData.error || 'Erreur lors du traitement du retrait.');
        }
        console.warn('[withdrawalService] Backend user withdraw route returned status', apiRes.status, errData.error);
      }
    } catch (apiErr: any) {
      if (apiErr.message && !apiErr.message.includes('fetch') && !apiErr.message.includes('network') && !apiErr.message.includes('Failed to fetch')) {
        throw apiErr;
      }
      console.warn('[withdrawalService] Server user withdraw route failed, falling back to direct RPC/DB:', apiErr.message);
    }

    // 2. Try calling RPC function
    const rpcRes = await tryUserWithdrawalRpc(amount, method, cleanPhone || phone);

    if (!rpcRes.error) {
      return { success: true };
    }

    console.warn('[withdrawalService] RPC failed, executing safe direct fallback:', rpcRes.error.message);

    // 2. Direct Fallback: Fetch user profile
    const { data: profileData, error: fetchErr } = await supabase
      .from('profiles')
      .select('wallet_balance, phone_number')
      .eq('id', userId)
      .maybeSingle();

    if (fetchErr || !profileData) {
      throw new Error("Impossible de récupérer les informations de votre profil.");
    }

    const currentBalance = Number(profileData.wallet_balance || 0);

    // Ensure phone is guaranteed valid & non-null
    if (!rawDigits || rawDigits.length < 8) {
      if (profileData.phone_number) {
        rawDigits = profileData.phone_number.replace(/\D/g, '').replace(/^224/, '');
      }
    }
    const finalPhone = rawDigits.length === 9 ? `+224${rawDigits}` : (rawDigits ? `+224${rawDigits}` : '+224610051553');

    // 3. Prevent Double Deduction: Check if RPC already created a pending withdrawal record
    const twoMinutesAgo = new Date(Date.now() - 2 * 60 * 1000).toISOString();
    const { data: existingWd } = await supabase
      .from('withdrawals')
      .select('id, amount, created_at')
      .eq('profile_id', userId)
      .eq('status', 'pending')
      .gte('created_at', twoMinutesAgo)
      .order('created_at', { ascending: false })
      .limit(1);

    if (existingWd && existingWd.length > 0 && Number(existingWd[0].amount) === amount) {
      console.log('[withdrawalService] Pending user withdrawal record already created by RPC. Skipping duplicate balance deduction.');
      return { success: true, fallback: true };
    }

    // 4. Validate available balance before direct deduction
    if (currentBalance < amount) {
      throw new Error(`Solde insuffisant sur votre portefeuille. Solde disponible : ${currentBalance.toLocaleString('fr-FR')} GNF.`);
    }

    // 5. Insert withdrawal record FIRST
    const wdRes = await insertWithdrawalRecord({
      profile_id: userId,
      amount: amount,
      method: method,
      phone: finalPhone,
      status: 'pending',
      created_at: new Date().toISOString()
    });

    if (wdRes.error) {
      console.error('[withdrawalService] Direct insert to withdrawals failed:', wdRes.error.message);
      throw new Error(`Erreur d'enregistrement du retrait: ${wdRes.error.message}`);
    }

    // 6. Deduct user profile balance ONCE
    const newBal = currentBalance - amount;
    const { error: updateErr } = await supabase
      .from('profiles')
      .update({ wallet_balance: newBal })
      .eq('id', userId)
      .gte('wallet_balance', amount);

    if (updateErr) {
      console.error('[withdrawalService] Failed to deduct profile balance:', updateErr.message);
      throw new Error("Erreur lors de la déduction de votre portefeuille.");
    }

    // 7. Log wallet transaction safely via backend service-role proxy (avoids RLS 403 on client)
    try {
      await fetch('/api/wallet/record-transaction', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          profile_id: userId,
          amount: -amount,
          type: 'withdrawal',
          status: 'completed',
          description: `Demande de retrait (${method.toUpperCase()}: ${finalPhone})`,
          reference_id: wdRes?.data?.[0]?.id,
        }),
      }).catch(() => {});
    } catch (logErr) {
      console.warn('[withdrawalService] Non-critical wallet_transactions log note:', logErr);
    }

    return { success: true, fallback: true };
  },

  /**
   * Rejects a withdrawal request and restores the store/user balance.
   */
  async rejectWithdrawal(withdrawalId: string, reason: string) {
    try {
      const { error } = await supabase.rpc('reject_withdrawal', {
        p_withdrawal_id: withdrawalId,
        p_reason: reason
      });

      if (error) {
        // Fallback: direct table update + balance restoration
        console.warn('[withdrawalService] reject_withdrawal RPC error, using fallback:', error.message);
        const { data: wd } = await supabase.from('withdrawals').select('*').eq('id', withdrawalId).maybeSingle();
        if (wd) {
          await supabase.from('withdrawals').update({ status: 'rejected', rejection_reason: reason }).eq('id', withdrawalId);
          if (wd.store_id) {
            await supabase.rpc('increment_store_balance', { p_store_id: wd.store_id, p_amount: Number(wd.amount) });
          } else if (wd.profile_id) {
            const { data: prof } = await supabase.from('profiles').select('wallet_balance').eq('id', wd.profile_id).maybeSingle();
            if (prof) {
              await supabase.from('profiles').update({ wallet_balance: (Number(prof.wallet_balance) || 0) + Number(wd.amount) }).eq('id', wd.profile_id);
            }
          }
        }
      }
      return { success: true };
    } catch (error) {
      console.error("Failed to reject withdrawal:", error);
      throw error;
    }
  },

  /**
   * Marks a withdrawal as processed (paid).
   */
  async approveWithdrawal(withdrawalId: string) {
    try {
      const { error } = await supabase.rpc('approve_withdrawal', {
        p_withdrawal_id: withdrawalId
      });

      if (error) {
        console.warn('[withdrawalService] approve_withdrawal RPC error, using fallback:', error.message);
        await supabase.from('withdrawals').update({ status: 'processed' }).eq('id', withdrawalId);
      }
      return { success: true };
    } catch (error) {
      console.error("Failed to approve withdrawal:", error);
      throw error;
    }
  }
};
