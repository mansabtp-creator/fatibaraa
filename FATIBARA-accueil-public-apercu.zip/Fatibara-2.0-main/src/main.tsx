import React from 'react';
import { createRoot } from 'react-dom/client';
import { HelmetProvider } from 'react-helmet-async';
import App from './App';
import './index.css';
import './utils/walletAuditor';
import { AppProvider } from './context/AppContext';
import { ErrorBoundary } from './components/ErrorBoundary';
import DebugOverlay from './components/DebugOverlay';
import { registerSW } from 'virtual:pwa-register';
import { initSentry, captureException } from './lib/sentry';

// ── Sentry error monitoring ────────────────────────────────────────────────
// Must be called before createRoot so Sentry captures the earliest errors.
initSentry();

if (import.meta.env.PROD) {
  const updateSW = registerSW({
    onNeedRefresh() {
      console.info('Une nouvelle version est disponible. Mise à jour en cours…');
      updateSW(true);
    },
    onOfflineReady() {
      console.log('App prête pour fonctionner hors ligne');
    },
  });
}


// NOTE: SW unregistration, cache purging, and the share-modal onerror guard
// are all handled by the synchronous inline <script> in index.html, which runs
// before this ES module loads. See index.html lines 51–95.

const originalConsoleError = console.error;
console.error = (...args: any[]) => {
  if (typeof args[0] === 'string' && args[0].includes('Refresh Token')) return;
  if (typeof args[0] === 'string' && args[0].includes('share-modal')) return;
  originalConsoleError(...args);
};

// Suppress any unhandledrejections from the stale SW that slip through
window.addEventListener('unhandledrejection', (event) => {
  const msg = event.reason?.message || event.reason?.toString() || '';
  const stack = event.reason?.stack || '';
  if (stack.includes('share-modal') || msg.includes('share-modal')) {
    event.preventDefault();
    console.debug('[share-modal] Suppressed stale SW unhandled rejection.');
  }
});



const rootEl = document.getElementById('root');
if (!rootEl) {
  console.error('Root element not found');
} else {
  try {
    createRoot(rootEl).render(
      <React.StrictMode>
        <HelmetProvider>
          <AppProvider>
            <ErrorBoundary onError={(err, info) => captureException(err, { componentStack: info.componentStack })}>
              <App />
              <DebugOverlay />
            </ErrorBoundary>
          </AppProvider>
        </HelmetProvider>
      </React.StrictMode>
    );
      console.log("✅ React app mounted");
  } catch (e: any) {
    console.error("❌ RENDER ERROR:", e);
  }
}
