/**
 * Order — aligned with the live database schema.
 *
 * Base columns come from supabase_schema.sql (CREATE TABLE public.orders).
 * The logistics columns (tracking_number, delivery_otp, courier_id) were added
 * via ALTER TABLE … ADD COLUMN IF NOT EXISTS in migration_logistics.sql and
 * apply_this_sql_now.sql — they are nullable because existing rows predate them.
 *
 * Status values match the CHECK constraint in supabase_schema.sql plus the
 * 'ready_for_pickup' state introduced by the state-machine migration.
 */
export interface Order {
  id: string;
  vendor_id: string;
  user_id: string | null;

  // Financial
  total_amount: number;
  delivery_fee: number;

  // Customer info (used in VendorOrders / AdminDashboard display)
  customer_name: string;
  items_count: number;
  shipping_address: Record<string, unknown> | null;
  notes?: string | null;

  // Lifecycle
  status:
    | 'pending'
    | 'paid'
    | 'accepted'
    | 'preparing'
    | 'ready_for_pickup'
    | 'in_transit'
    | 'shipped'
    | 'arriving_soon'
    | 'delivered'
    | 'cancelled';

  // Logistics — added via ADD COLUMN IF NOT EXISTS (nullable on older rows)
  tracking_number: string | null;
  delivery_otp: string | null;
  courier_id: string | null;

  created_at: string;
  updated_at: string;
}

export type OrderStatus = Order['status'];

export interface Delivery {
  id: string;
  order_id: string;
  courier_id: string;
  status: 'assigned' | 'picked_up' | 'in_transit' | 'delivered';
  current_location: { lat: number; lng: number };
  updated_at: string;
}
