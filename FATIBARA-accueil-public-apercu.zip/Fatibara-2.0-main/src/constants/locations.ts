export const GUINEA_LOCATIONS = {
  'Conakry': [
    'Kaloum', 'Dixinn', 'Matam', 'Ratoma', 'Matoto', 'Kassa', 
    'Lambanyi', 'Sonfonia', 'Foula Madina', 'Gbessia', 'Tombolia', 'Sanoyah', 'Maneah', 'Kagbelen'
  ],
  'Kindia': ['Kindia', 'Coyah', 'Dubréka', 'Forécariah', 'Télimélé'],
  'Boké': ['Boké', 'Boffa', 'Fria', 'Gaoual', 'Koundara'],
  'Mamou': ['Mamou', 'Dalaba', 'Pita'],
  'Labé': ['Labé', 'Koubia', 'Lélouma', 'Mali', 'Tougué'],
  'Faranah': ['Faranah', 'Dabola', 'Dinguiraye', 'Kissidougou'],
  'Kankan': ['Kankan', 'Kérouané', 'Kouroussa', 'Mandiana', 'Siguiri'],
  'Nzérékoré': ['Nzérékoré', 'Beyla', 'Guéckédou', 'Lola', 'Macenta', 'Yomou']
};

export const ALL_REGIONS = Object.keys(GUINEA_LOCATIONS);

export const ALL_PREFECTURES = Object.values(GUINEA_LOCATIONS).flat();
