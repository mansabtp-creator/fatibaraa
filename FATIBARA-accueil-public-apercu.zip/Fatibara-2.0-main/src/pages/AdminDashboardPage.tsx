import React, { useState, useEffect, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import Header from '../components/Header';
import Footer from '../components/Footer';
import { useAppContext } from '../context/AppContext';
import { useToast } from '../context/ToastContext';
import { supabase } from '../lib/supabase';
import { 
  ShieldAlert, Users, Store, Activity, Coins, Banknote,
  Settings, CheckCircle, XCircle, Search, Filter,
  TrendingUp, ShoppingBag, AlertTriangle, ChevronRight,
  Monitor, BarChart3, Mail, Calendar, Trash2, FileText, ExternalLink,
  Menu, X, Megaphone, Send, Archive, Ban, Clock, Wallet, PlayCircle,
  Bike, Car, MapPin, Star, Package, PhoneCall, Wifi, WifiOff, Zap,
  Eye, EyeOff, ShieldOff, ShieldCheck, Phone, LayoutDashboard, Tag, Truck, LogOut,
  Hash, ToggleLeft, ToggleRight, MessageSquare, RefreshCw, UserCog, ArrowRight, Copy,
  Save, RotateCcw, Percent
} from 'lucide-react';
import { APP_NAME, PARENT_BRAND } from '../lib/constants';
import { withdrawalService } from '../services/withdrawalService';
import { 
  ResponsiveContainer, AreaChart, Area, XAxis, YAxis, 
  CartesianGrid, Tooltip, BarChart, Bar, Cell
} from 'recharts';
import { motion, AnimatePresence } from 'motion/react';
import { useStore } from '../store/useStore';
import VendorInvitationPanel from '../components/VendorInvitationPanel';
import AdminApplicationsQueue from '../components/AdminApplicationsQueue';
import { formatGNF } from '../utils/formatters';
import { logAuditEvent } from '../utils/auditLogger';

type AdminTab = 'overview' | 'users' | 'vendors' | 'orders' | 'products' | 'finance' | 'settings' | 'logs' | 'announcements' | 'couriers' | 'promotions' | 'system-health' | 'applications';

export default function AdminDashboardPage() {
  const { user, isAuthLoading } = useAppContext();
  const { showToast } = useToast();
  const navigate = useNavigate();
  const { isDarkMode } = useStore();
  const [isAdmin, setIsAdmin] = useState(false);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<AdminTab>('overview');
  const [financeSubTab, setFinanceSubTab] = useState<'withdrawals' | 'commissions' | 'couriers'>('withdrawals');
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(true);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const [promptConfig, setPromptConfig] = useState<{
    isOpen: boolean;
    title: string;
    description?: string;
    resolve: (value: string | null) => void;
  } | null>(null);

  const [confirmConfig, setConfirmConfig] = useState<{
    isOpen: boolean;
    title: string;
    description?: string;
    resolve: (value: boolean) => void;
  } | null>(null);

  const askPrompt = (title: string, description?: string): Promise<string | null> => {
    return new Promise((resolve) => {
      setPromptConfig({ isOpen: true, title, description, resolve });
    });
  };

  const askConfirm = (title: string, description?: string): Promise<boolean> => {
    return new Promise((resolve) => {
      setConfirmConfig({ isOpen: true, title, description, resolve });
    });
  };

  // Multi-tab Data
  const [stats, setStats] = useState({
    totalUsers: 0,
    totalVendors: 0,
    totalSales: 0,
    platformNet: 0,
    activeListings: 0,
    pendingVendors: 0,
    monthlyGrowth: 12.5,
    pendingCouriers: 0
  });

  // Keep this after `stats`: the applications badge reads its initial value
  // during render, so declaring it above the state hook triggers a TDZ error.
  const navGroups = [
    {
      label: 'PILOTAGE',
      items: [
        { id: 'overview' as AdminTab, label: 'Tableau de bord', icon: LayoutDashboard },
        { id: 'finance' as AdminTab, label: 'Argent & Ventes', icon: Wallet },
      ]
    },
    {
      label: 'FLUX COMMERCIAUX',
      items: [
        { id: 'orders' as AdminTab, label: 'Commandes', icon: ShoppingBag },
        { id: 'products' as AdminTab, label: 'Produits & Stocks', icon: Package },
        { id: 'promotions' as AdminTab, label: 'Promos & Offres', icon: Tag },
      ]
    },
    {
      label: 'ÉCOSYSTÈME',
      items: [
        { id: 'applications' as AdminTab, label: 'Candidatures', icon: CheckCircle, badge: (stats.pendingVendors + stats.pendingCouriers) || 0 },
        { id: 'vendors' as AdminTab, label: 'Les Vendeurs', icon: Store },
        { id: 'couriers' as AdminTab, label: 'Les Livreurs', icon: Truck },
        { id: 'users' as AdminTab, label: 'Utilisateurs', icon: Users },
      ]
    },
    {
      label: 'GESTION SYSTÈME',
      items: [
        { id: 'announcements' as AdminTab, label: 'Messages et Annonces', icon: Mail },
        { id: 'settings' as AdminTab, label: 'Réglages', icon: Settings },
        { id: 'logs' as AdminTab, label: 'Historique', icon: FileText },
        { id: 'system-health' as AdminTab, label: "État de l'App", icon: Monitor },
      ]
    }
  ];

  const [allUsers, setAllUsers] = useState<any[]>([]);
  const [allVendors, setAllVendors] = useState<any[]>([]);
  const [allCouriers, setAllCouriers] = useState<any[]>([]);
  const [promotions, setPromotions] = useState<any[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [userRoleFilter, setUserRoleFilter] = useState<'all' | 'client' | 'vendor' | 'courier' | 'admin'>('all');
  const [userStatusFilter, setUserStatusFilter] = useState<'all' | 'active' | 'suspended' | 'missing_phone'>('all');
  const [selectedUser, setSelectedUser] = useState<any | null>(null);
  const [chartData, setChartData] = useState<any[]>([]);
  const [topProductsData, setTopProductsData] = useState<any[]>([]);
  const [isRefreshingMV, setIsRefreshingMV] = useState(false);

  // Refreshes the trending_products_mv materialized view so the homepage
  // "Ventes Flash" section reflects the latest approved products.
  const refreshTrendingMV = async () => {
    if (isRefreshingMV) return;
    setIsRefreshingMV(true);
    try {
      const { error } = await supabase.rpc('refresh_trending_products_mv');
      if (error) throw error;
      showToast('Ventes Flash mis à jour avec succès !', 'success');
    } catch (err: any) {
      showToast(`Erreur : ${err.message}`, 'error');
    } finally {
      setIsRefreshingMV(false);
    }
  };

  // Verification
  useEffect(() => {
    async function verifyAdmin() {
      if (isAuthLoading) return;
      if (!user) {
        navigate('/');
        return;
      }
      
      try {
        const { data: profile } = await supabase
          .from('profiles')
          .select('id, is_admin')
          .eq('id', user.id)
          .single();
          
        const hasAdminAccess = profile?.is_admin === true;

        if (hasAdminAccess) {
          setIsAdmin(true); 
          await fetchData();
        } else {
          navigate('/');
        }
      } catch (err) {
        navigate('/');
      } finally {
        setLoading(false);
      }
    }

    verifyAdmin();
  }, [user, isAuthLoading, navigate]);

  const fetchData = async () => {
    setLoading(true);
    try {
      // 2. Fetch Detailed Data for Tabs using safer individual queries
      const fetchWithCatch = async (query: any, label: string) => {
        try {
          const result = await query;
          if (result.error) {
            console.warn(`Admin Fetch Warning [${label}]:`, result.error.message);
            // Return empty data instead of crashing
            return { data: [], error: result.error };
          }
          return result;
        } catch (err) {
          console.error(`Admin Fetch Critical [${label}]:`, err);
          return { data: [], error: err };
        }
      };

      const [
        usersRes,
        vendorsRes,
        productsRes,
        ordersRes,
        settingsRes,
        logsRes,
        announcementRes,
        withdrawalsRes,
        couriersRes,
        promotionsRes,
        platformLogsRes,
        healthLogsRes,
        housekeepingTasksRes
      ] = await Promise.all([
        (async () => {
          // Try the enriched RPC (email + last_sign_in_at). If PostgREST cache is
          // stale after a schema change, fall back to the plain profiles table so
          // the dashboard always loads.
          const rpcRes = await supabase.rpc('admin_get_users_v3');
          if (!rpcRes.error) return { data: rpcRes.data, error: null };
          console.warn('Admin RPC fallback to profiles:', rpcRes.error.message);
          return supabase.from('profiles').select('*').order('created_at', { ascending: false });
        })(),
        fetchWithCatch(supabase.from('stores').select('*, owner:profiles!stores_owner_id_fkey(full_name, phone_number)').order('created_at', { ascending: false }), 'stores'),
        fetchWithCatch(supabase.from('products').select('*, stores(store_name)').order('created_at', { ascending: false }), 'products'),
        fetchWithCatch(supabase.from('orders').select('*').order('created_at', { ascending: false }), 'orders'),
        fetchWithCatch(supabase.from('platform_settings').select('*'), 'platform_settings'),
        fetchWithCatch(supabase.from('audit_logs').select('*').order('created_at', { ascending: false }).limit(100), 'audit_logs'),
        fetchWithCatch(supabase.from('announcements').select('*').order('created_at', { ascending: false }), 'announcements'),
        fetchWithCatch(supabase.from('withdrawals').select('*').order('created_at', { ascending: false }), 'withdrawals'),
        fetchWithCatch(supabase.from('profiles').select('*').not('profile_type', 'eq', 'client').order('created_at', { ascending: false }), 'couriers'),
        fetchWithCatch(supabase.from('promotions').select('*').order('created_at', { ascending: false }).limit(20), 'promotions'),
        fetchWithCatch(supabase.from('platform_logs').select('*').order('created_at', { ascending: false }), 'platform_logs'),
        fetchWithCatch(supabase.from('system_health_logs').select('*').order('created_at', { ascending: false }), 'system_health_logs'),
        fetchWithCatch(supabase.from('housekeeping_tasks').select('*').order('last_run', { ascending: false }), 'housekeeping_tasks')
      ]);
      
      const usersList = usersRes.data || [];
      const rawOrdersList = ordersRes.data || [];
      const productsList = productsRes.data || [];
      const allOrdersResult = rawOrdersList.map((o: any) => ({
        ...o,
        profiles: o.user_id ? usersList.find((p: any) => p.id === o.user_id) : null
      }));
      const pendingStatuses = ['pending', 'accepted', 'preparing', 'in_transit'];
      const vendorsList = (vendorsRes.data || []).map((store: any) => ({
        ...store,
        pending_orders_count: rawOrdersList.filter(
          (o: any) => o.store_id === store.id && pendingStatuses.includes(o.status)
        ).length
      }));
      const couriersList = (couriersRes.data || []).map((c: any) => ({
        ...c,
        // Treat both legacy 'on_delivery' and canonical 'en_course' as active
        active_deliveries_count: (['on_delivery', 'en_course'].includes(c.courier_status)) ? 1 : 0
      }));
      const promotionsList = promotionsRes.data || [];
      
      const settingsList = settingsRes.data || [];
      const logsList = logsRes.data || [];
      const announcementList = announcementRes.data || [];
      const withdrawalsList = (withdrawalsRes.data || []).map((w: any) => ({
        ...w,
        stores: w.store_id ? vendorsList.find((s: any) => s.id === w.store_id) : null,
        profiles: w.profile_id ? usersList.find((p: any) => p.id === w.profile_id) : null
      }));
      const platformLogsList = platformLogsRes.data || [];
      const healthLogsList = healthLogsRes.data || [];
      const housekeepingTasksList = housekeepingTasksRes.data || [];

      if (usersList) setAllUsers(usersList);
      if (vendorsList) setAllVendors(vendorsList);
      if (productsList) setAllProducts(productsList);
      if (allOrdersResult) setAllOrdersList(allOrdersResult);
      if (logsList) setAuditLogs(logsList);
      if (announcementList) setAnnouncements(announcementList);
      if (withdrawalsList) setWithdrawals(withdrawalsList);
      if (couriersList) setAllCouriers(couriersList);
      if (promotionsList) setPromotions(promotionsList);
      if (platformLogsList) setPlatformLogs(platformLogsList);
      if (healthLogsList) setHealthLogs(healthLogsList);
      if (housekeepingTasksList) setHousekeepingTasks(housekeepingTasksList);
      if (settingsList && settingsList.length > 0) {
        const getVal = (id: string, fallback: string) => {
          const row = settingsList.find((s: any) => s.id === id);
          return row && row.value !== undefined && row.value !== null ? String(row.value) : fallback;
        };
        setPlatformSettings(prev => ({
          ...prev,
          commission: getVal('commission_rate', prev.commission),
          withdrawalDelay: getVal('withdrawal_delay', prev.withdrawalDelay),
          referralBonus: getVal('referral_bonus', prev.referralBonus),
          minWithdrawal: getVal('min_withdrawal', prev.minWithdrawal),
          maintenanceMode: getVal('maintenance_mode', prev.maintenanceMode),
          maxWithdrawalDaily: getVal('max_withdraw_daily', prev.maxWithdrawalDaily),
          supportContact: getVal('support_contact', prev.supportContact),
          supportWhatsapp: getVal('support_whatsapp', prev.supportWhatsapp),
          supportPhone: getVal('support_phone', prev.supportPhone),
        }));
      }

      // Calculations
      const validRevenueStatuses = ['paid', 'accepted', 'preparing', 'in_transit', 'shipped', 'delivered'];
      const totalRevenue = allOrdersResult.filter(o => validRevenueStatuses.includes(o.status)).reduce((sum, o) => sum + (Number(o.total_amount) || 0), 0) || 0;
      
      const thirtyDaysAgo = new Date();
      thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
      const recentUsersCount = usersList.filter(u => new Date(u.created_at) > thirtyDaysAgo).length || 0;

      // 3. Set Platform Settings from DB
      const settingsMap: any = {};
      settingsList.forEach(s => {
        if (s.id === 'commission_rate') settingsMap.commission = s.value;
        if (s.id === 'withdrawal_delay') settingsMap.withdrawalDelay = s.value;
        if (s.id === 'referral_bonus') settingsMap.referralBonus = s.value;
        if (s.id === 'min_withdrawal') settingsMap.minWithdrawal = s.value;
        if (s.id === 'maintenance_mode') settingsMap.maintenanceMode = s.value;
        if (s.id === 'max_withdraw_daily') settingsMap.maxWithdrawalDaily = s.value;
        if (s.id === 'support_contact')  settingsMap.supportContact  = s.value;
        if (s.id === 'support_whatsapp') settingsMap.supportWhatsapp = s.value;
        if (s.id === 'support_phone')    settingsMap.supportPhone    = s.value;
      });
      setPlatformSettings(prev => ({ ...prev, ...settingsMap }));

      const currentCommissionRate = Number(settingsMap.commission || platformSettings.commission) / 100 || 0.05;
      const estimatedCommission = allOrdersResult.filter(o => validRevenueStatuses.includes(o.status))
        .reduce((sum, o) => {
          const itemSubtotal = (Number(o.total_amount) - (Number(o.delivery_fee) || 0)) / (1 + currentCommissionRate);
          return sum + (itemSubtotal * currentCommissionRate);
        }, 0);

      setStats({
        totalUsers: usersList.length,
        totalVendors: vendorsList.length,
        totalSales: totalRevenue,
        platformNet: platformLogsList.length > 0 
          ? platformLogsList.reduce((sum: number, log: any) => sum + Number(log.amount), 0) 
          : estimatedCommission,
        activeListings: productsList.length,
        pendingVendors: vendorsList.filter(v => v.store_status === 'pending' || (!v.store_status && !v.is_verified_store)).length || 0,
        monthlyGrowth: usersList.length ? Math.round((recentUsersCount / usersList.length) * 100) : 0,
        pendingCouriers: couriersList.filter(c => c.courier_status === 'inactive' && c.profile_type !== 'courier').length || 0
      });

      // 4. Generate Real Chart Data based on current sales
      const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
      const currentMonth = new Date().getMonth();
      const last7Months = Array.from({ length: 7 }, (_, i) => {
        const d = new Date();
        d.setMonth(currentMonth - (6 - i));
        return {
          name: months[d.getMonth()],
          value: allOrdersResult.filter(o => {
            const oDate = new Date(o.created_at);
            return oDate.getMonth() === d.getMonth() && o.status === 'paid';
          }).reduce((sum, o) => sum + Number(o.total_amount), 0) || 0
        };
      });
      setChartData(last7Months);

      // 5. Calculate Top Products
      if (productsList.length > 0 && allOrdersResult.length > 0) {
        const productSales: any = {};
        allOrdersResult.filter(o => o.status === 'paid').forEach(o => {
          if (o.items) {
            o.items.forEach((item: any) => {
              productSales[item.id] = (productSales[item.id] || 0) + 1;
            });
          }
        });

        const topProducts = productsList
          .map(p => ({
            name: p.title.substring(0, 15),
            sales: productSales[p.id] || 0,
            fullName: p.title
          }))
          .sort((a, b) => b.sales - a.sales)
          .slice(0, 5);
        
        setTopProductsData(topProducts);
      }
    } catch (err: any) {
      console.error("Dashboard fetch error:", err);
      showToast(err.message || "Impossible de charger les données du tableau de bord.", "error");
    } finally {
      setLoading(false);
    }
  };

  const [allProducts, setAllProducts] = useState<any[]>([]);
  const [allOrdersList, setAllOrdersList] = useState<any[]>([]);
  const [auditLogs, setAuditLogs] = useState<any[]>([]);
  const [announcements, setAnnouncements] = useState<any[]>([]);
  const [withdrawals, setWithdrawals] = useState<any[]>([]);
  // H-6: Track which withdrawal is currently being processed to disable its buttons
  const [processingWithdrawalId, setProcessingWithdrawalId] = useState<string | null>(null);
  const [platformLogs, setPlatformLogs] = useState<any[]>([]);
  const [healthLogs, setHealthLogs] = useState<any[]>([]);
  const [housekeepingTasks, setHousekeepingTasks] = useState<any[]>([]);
  const [newAnnouncement, setNewAnnouncement] = useState({ title: '', content: '', target: 'all' });
  const [selectedLog, setSelectedLog] = useState<any>(null);
  const [promoSubTab, setPromoSubTab] = useState<'campaigns' | 'announcements'>('campaigns');

  // ── Orders Lifecycle State ───────────────────────────────────────────────────
  type OrderLifecycleTab = 'a_preparer' | 'a_assigner' | 'en_cours' | 'livre';
  const [orderLifecycleTab, setOrderLifecycleTab] = useState<OrderLifecycleTab>('a_preparer');
  const [assignDrawerOrder, setAssignDrawerOrder] = useState<any | null>(null);
  const [assigningCourierId, setAssigningCourierId] = useState<string>('');
  const [isAssigning, setIsAssigning] = useState(false);

  const logAction = async (action: string, entity_type: string, entity_id: string, new_data: any) => {
    try {
      await logAuditEvent({
        userId: user?.id || null,
        action,
        entityType: entity_type,
        entityId: entity_id,
        storeId: null,
        data: new_data,
      });
    } catch (err: any) {
      console.warn('[AuditLog] Log error:', err?.message);
    }
  };

  const filteredUsers = useMemo(() => {
    const query = searchQuery.toLowerCase();
    return allUsers.filter(u => {
      const role = u.is_admin ? 'admin' : (u.profile_type === 'vendor' ? 'vendor' : u.profile_type === 'courier' ? 'courier' : 'client');
      const matchesSearch =
        u.full_name?.toLowerCase().includes(query) ||
        u.email?.toLowerCase().includes(query) ||
        u.phone_number?.toLowerCase().includes(query) ||
        u.id?.toLowerCase().includes(query);
      const matchesRole = userRoleFilter === 'all' || role === userRoleFilter;
      const matchesStatus =
        userStatusFilter === 'all' ||
        (userStatusFilter === 'suspended' && u.account_status === 'suspended') ||
        (userStatusFilter === 'active' && u.account_status !== 'suspended') ||
        (userStatusFilter === 'missing_phone' && !u.phone_number);
      return matchesSearch && matchesRole && matchesStatus;
    });
  }, [allUsers, searchQuery, userRoleFilter, userStatusFilter]);

  const filteredVendors = useMemo(() => {
    return allVendors.filter(v => 
      (v.store_name?.toLowerCase().includes(searchQuery.toLowerCase())) ||
      (v.id?.toLowerCase().includes(searchQuery.toLowerCase())) ||
      (v.store_category?.toLowerCase().includes(searchQuery.toLowerCase()))
    );
  }, [allVendors, searchQuery]);

  const [productModerationFilter, setProductModerationFilter] = useState<'all' | 'pending' | 'approved' | 'rejected'>('all');

  const filteredProducts = useMemo(() => {
    return allProducts.filter(p => {
      const matchesSearch =
        (p.title?.toLowerCase().includes(searchQuery.toLowerCase())) ||
        (p.id?.toLowerCase().includes(searchQuery.toLowerCase())) ||
        (p.stores?.store_name?.toLowerCase().includes(searchQuery.toLowerCase()));
      const matchesMod =
        productModerationFilter === 'all' ||
        (p.moderation_status ?? 'approved') === productModerationFilter;
      return matchesSearch && matchesMod;
    });
  }, [allProducts, searchQuery, productModerationFilter]);

  const filteredOrders = useMemo(() => {
    return allOrdersList.filter(o => 
      (o.id?.toLowerCase().includes(searchQuery.toLowerCase())) ||
      (o.profiles?.full_name?.toLowerCase().includes(searchQuery.toLowerCase()))
    );
  }, [allOrdersList, searchQuery]);

  // ── Order Lifecycle Buckets ──────────────────────────────────────────────────
  const ordersAPreparer = useMemo(() =>
    filteredOrders.filter(o => ['paid', 'confirmed', 'accepted'].includes(o.status ?? ''))
  , [filteredOrders]);

  const ordersAAssigner = useMemo(() =>
    filteredOrders.filter(o => ['preparing', 'ready_for_pickup'].includes(o.status ?? ''))
  , [filteredOrders]);

  const ordersEnCours = useMemo(() =>
    filteredOrders.filter(o => ['in_transit', 'shipped'].includes(o.status ?? ''))
  , [filteredOrders]);

  const ordersLivre = useMemo(() =>
    filteredOrders.filter(o => ['delivered', 'cancelled'].includes(o.status ?? ''))
  , [filteredOrders]);

  // ── Active couriers available for assignment ─────────────────────────────────
  const availableCouriers = useMemo(() =>
    allCouriers.filter(c =>
      c.courier_status === 'disponible' ||
      c.courier_status === 'active' ||
      c.courier_status === 'approved'
    )
  , [allCouriers]);

  // ── Financial breakdown for an order ────────────────────────────────────────
  const getFinancialBreakdown = (order: any) => {
    const commissionRate = Number(platformSettings.commission || 5) / 100;
    const total = Number(order.total_amount) || 0;
    const deliveryFee = Number(order.delivery_fee) || 0;
    const subtotal = total - deliveryFee;
    const commission = Math.round(subtotal * commissionRate);
    const vendorShare = Math.round(subtotal - commission);
    return { total, deliveryFee, commission, vendorShare };
  };

  // ── Assign courier to an order ───────────────────────────────────────────────
  const assignCourier = async (orderId: string, courierId: string) => {
    if (!courierId) {
      showToast('Veuillez sélectionner un livreur.', 'info');
      return;
    }
    setIsAssigning(true);
    // Optimistic UI update
    setAllOrdersList(prev =>
      prev.map(o =>
        o.id === orderId ? { ...o, courier_id: courierId, status: 'in_transit' } : o
      )
    );
    setAssignDrawerOrder(null);
    setAssigningCourierId('');

    // A-BUG-1 FIX: Use the admin_assign_courier_to_order SECURITY DEFINER RPC
    // instead of a raw orders.update(). The raw update was setting courier_id
    // and status but never creating a deliveries row, causing
    // complete_courier_delivery (and thus courier payout) to fail silently.
    const { data: rpcData, error } = await supabase.rpc('admin_assign_courier_to_order', {
      p_order_id:   orderId,
      p_courier_id: courierId,
    });
    const result = rpcData as { success: boolean; error?: string } | null;

    if (error || !result?.success) {
      showToast('Erreur lors de l\'assignation : ' + (error?.message ?? result?.error ?? 'Échec'), 'error');
      fetchData(); // revert optimistic update
    } else {
      logAction('ASSIGN_COURIER', 'order', orderId, { courier_id: courierId });
      showToast('Livreur assigné. Commande en transit ! 🛵', 'success');
    }
    setIsAssigning(false);
  };

  const deleteUser = async (userId: string) => {
    if (userId === user?.id) return;
    const confirmed = await askConfirm(
      "Supprimer l'utilisateur ?", 
      "Cette action est irréversible et supprimera toutes les données associées."
    );
    if (!confirmed) return;
    
    const { error } = await supabase.from('profiles').delete().eq('id', userId);
    if (!error) {
      logAction('DELETE_USER', 'user', userId, { deleted_at: new Date().toISOString() });
      fetchData();
    }
  };

  const verifyVendor = async (vendorId: string, currentStatus: boolean) => {
    const { error } = await supabase
      .from('stores')
      .update({ is_verified_store: !currentStatus })
      .eq('id', vendorId);
    
    if (!error) {
      logAction('VERIFY_VENDOR', 'store', vendorId, { verified: !currentStatus });
      fetchData();
    }
  };

  const [platformSettings, setPlatformSettings] = useState(() => {
    const saved = localStorage.getItem('fatibara_admin_settings');
    return saved ? JSON.parse(saved) : {
      commission: '5',
      withdrawalDelay: '3',
      referralBonus: '10000',
      minWithdrawal: '50000',
      maintenanceMode: 'false',
      maxWithdrawalDaily: '5000000',
      supportContact: 'support@fatibara.gn',
      supportWhatsapp: '224666923393',
      supportPhone: '+224 666 92 33 93',
    };
  });

  const toggleAdmin = async (userId: string, currentStatus: boolean) => {
    if (userId === user?.id) {
       showToast("Vous ne pouvez pas retirer vos propres droits d'admin.", "error");
       return;
    }
    // admin_toggle_is_admin is SECURITY DEFINER — bypasses RLS correctly.
    const { error } = await supabase.rpc('admin_toggle_is_admin', {
      target_user_id: userId,
      new_value:      !currentStatus,
    });
    if (error) {
      showToast('Erreur : ' + error.message, 'error');
    } else {
      logAction('TOGGLE_ADMIN', 'user', userId, { is_admin: !currentStatus });
      showToast(!currentStatus ? 'Droits admin accordés.' : 'Droits admin retirés.', 'success');
      fetchData();
    }
  };

  const toggleProfileType = async (userId: string, currentType: string) => {
    const newType = currentType === 'courier' ? 'client' : 'courier';
    // admin_update_user_role is SECURITY DEFINER — bypasses RLS correctly.
    // It also handles the courier_profiles upsert internally.
    const { error } = await supabase.rpc('admin_update_user_role', {
      target_user_id:   userId,
      new_profile_type: newType,
    });
    if (error) {
      showToast('Erreur : ' + error.message, 'error');
    } else {
      logAction('UPDATE_PROFILE_TYPE', 'user', userId, { type: newType });
      fetchData();
      showToast(`Rôle mis à jour : ${newType.toUpperCase()}`, 'success');
    }
  };

  const deleteProduct = async (productId: string) => {
    const confirmed = await askConfirm(
      "Supprimer le produit ?",
      `Voulez-vous vraiment supprimer ce produit de l'écosystème ${APP_NAME} ?`
    );
    if (!confirmed) return;
    const { error } = await supabase.from('products').delete().eq('id', productId);
    if (!error) {
      logAction('DELETE_PRODUCT', 'product', productId, { deleted_at: new Date().toISOString() });
      fetchData();
    }
  };

  // ── Product Visibility Toggle ───────────────────────────────────────────────
  const toggleProductVisibility = async (productId: string, isCurrentlyVisible: boolean) => {
    const { error } = await supabase
      .from('products')
      .update({ is_visible: !isCurrentlyVisible })
      .eq('id', productId);
    if (!error) {
      logAction('TOGGLE_PRODUCT_VISIBILITY', 'product', productId, { is_visible: !isCurrentlyVisible });
      showToast(
        !isCurrentlyVisible
          ? 'Produit rendu visible sur la vitrine.'
          : 'Produit masqué de la vitrine client.',
        'success'
      );
      // Optimistic local update — avoids full refetch for a simple toggle
      setAllProducts(prev =>
        prev.map(p => p.id === productId ? { ...p, is_visible: !isCurrentlyVisible } : p)
      );
    } else {
      showToast('Erreur lors du changement de visibilité : ' + error.message, 'error');
    }
  };

  // ── Product Moderation (approve / reject pending submissions) ───────────────
  const moderateProduct = async (productId: string, status: 'approved' | 'rejected', note?: string) => {
    const { error } = await supabase.rpc('admin_moderate_product', {
      p_product_id: productId,
      p_status:     status,
      p_note:       note ?? null,
    });
    if (!error) {
      logAction('MODERATE_PRODUCT', 'product', productId, { status, note });
      showToast(
        status === 'approved'
          ? '✅ Produit approuvé — maintenant visible en boutique.'
          : '🚫 Produit rejeté — le vendeur en sera informé.',
        'success'
      );
      // Optimistic local update
      setAllProducts(prev =>
        prev.map(p =>
          p.id === productId
            ? { ...p, moderation_status: status, is_active: status === 'approved' }
            : p
        )
      );
    } else {
      showToast('Erreur de modération : ' + error.message, 'error');
    }
  };

  // ── User Account Soft-Ban Toggle ────────────────────────────────────────────
  const toggleUserAccountStatus = async (userId: string, currentStatus: string) => {
    if (userId === user?.id) {
      showToast("Vous ne pouvez pas suspendre votre propre compte.", "error");
      return;
    }
    const newStatus = currentStatus === 'suspended' ? 'active' : 'suspended';
    // admin_update_account_status is SECURITY DEFINER — bypasses RLS correctly.
    const { error } = await supabase.rpc('admin_update_account_status', {
      target_user_id: userId,
      new_status:     newStatus,
    });
    if (error) {
      showToast('Erreur lors de la mise à jour du statut : ' + error.message, 'error');
    } else {
      logAction('UPDATE_ACCOUNT_STATUS', 'user', userId, { account_status: newStatus });
      showToast(
        newStatus === 'suspended'
          ? 'Compte utilisateur suspendu. Session bloquée.'
          : 'Compte utilisateur réactivé avec succès.',
        newStatus === 'suspended' ? 'info' : 'success'
      );
      // Optimistic local update
      setAllUsers(prev =>
        prev.map(u => u.id === userId ? { ...u, account_status: newStatus } : u)
      );
    }
  };

  const updateOrderStatus = async (orderId: string, newStatus: string) => {
    // For delivered: use the atomic complete_courier_delivery RPC (if a courier
    // is assigned) or complete_vendor_order — both handle financial settlement
    // in a single transaction. Direct update is only for non-terminal statuses.
    if (newStatus === 'delivered') {
      try {
        // Prefer the courier RPC when a courier is assigned
        const order = allOrdersList.find(o => o.id === orderId);
        if (order?.courier_id) {
          const { data, error } = await supabase.rpc('complete_courier_delivery', {
            p_order_id: orderId,
            p_otp: null, // admin bypass — no OTP required
          });
          if (error) throw error;
          const result = data as { success: boolean; error?: string };
          if (!result.success && result.error && !result.error.includes('OTP')) {
            throw new Error(result.error);
          }
        } else {
          // No courier — use admin RPC to update status, then settle financials
          const { data: rpcData, error: updateErr } = await supabase
            .rpc('admin_update_order_status', { p_order_id: orderId, p_status: 'delivered' });
          if (updateErr) throw updateErr;
          const rpcResult = rpcData as { success: boolean; error?: string };
          if (!rpcResult?.success) throw new Error(rpcResult?.error ?? 'Échec mise à jour statut');
          const { processOrderFinancials } = await import('../services/financialService');
          await processOrderFinancials(orderId);
        }
        logAction('UPDATE_ORDER_STATUS', 'order', orderId, { status: newStatus });
        fetchData();
      } catch (fErr: any) {
        showToast('Erreur lors de la finalisation : ' + fErr.message, 'error');
      }
      return;
    }

    if (newStatus === 'cancelled') {
      const { data: rpcData, error } = await supabase
        .rpc('admin_update_order_status', { p_order_id: orderId, p_status: newStatus });
      const rpcResult = rpcData as { success: boolean; error?: string } | null;
      if (!error && rpcResult?.success) {
        try {
          const { refundOrderFinancials } = await import('../services/financialService');
          await refundOrderFinancials(orderId, 'Annulée par Administrateur');
        } catch (rErr) {
          console.error('Refund failed in admin dashboard:', rErr);
        }
        logAction('UPDATE_ORDER_STATUS', 'order', orderId, { status: newStatus });
        fetchData();
      } else {
        showToast('Erreur : ' + (error?.message ?? rpcResult?.error ?? 'Échec'), 'error');
      }
      return;
    }

    // Non-terminal status changes (accepted, preparing, ready_for_pickup …)
    const { data: ntRpcData, error: ntError } = await supabase
      .rpc('admin_update_order_status', { p_order_id: orderId, p_status: newStatus });
    const ntResult = ntRpcData as { success: boolean; error?: string } | null;
    if (!ntError && ntResult?.success) {
      logAction('UPDATE_ORDER_STATUS', 'order', orderId, { status: newStatus });
      fetchData();
    } else {
      showToast('Erreur : ' + (ntError?.message ?? ntResult?.error ?? 'Échec'), 'error');
    }
  };

  const [isSavingSettings, setIsSavingSettings] = useState(false);
  const saveSettings = async () => {
    setIsSavingSettings(true);
    try {
      const updates = [
        { id: 'commission_rate', value: String(platformSettings.commission || '2') },
        { id: 'withdrawal_delay', value: String(platformSettings.withdrawalDelay || '4') },
        { id: 'referral_bonus', value: String(platformSettings.referralBonus || '5000') },
        { id: 'min_withdrawal', value: String(platformSettings.minWithdrawal || '15000') },
        { id: 'maintenance_mode', value: String(platformSettings.maintenanceMode || 'false') },
        { id: 'max_withdraw_daily', value: String(platformSettings.maxWithdrawalDaily || '10000000') },
        { id: 'support_contact',  value: String(platformSettings.supportContact || 'support@fatibara.gn') },
        { id: 'support_whatsapp', value: String(platformSettings.supportWhatsapp || '224613101091') },
        { id: 'support_phone',    value: String(platformSettings.supportPhone || '+224 613 10 10 91') },
      ];

      const { error } = await supabase.from('platform_settings').upsert(updates);
      if (error) throw error;
      
      localStorage.setItem('fatibara_admin_settings', JSON.stringify(platformSettings));
      logAction('UPDATE_SETTINGS', 'setting', 'global', updates);
      showToast("Configuration système enregistrée avec succès.", "success");
    } catch (err: any) {
      showToast("Erreur lors de la mise à jour : " + err.message, "error");
    } finally {
      setIsSavingSettings(false);
    }
  };

  const processWithdrawal = async (id: string, storeId: string, amount: number, status: 'processed' | 'rejected') => {
    // H-6: Prevent duplicate RPC calls if admin clicks twice
    if (processingWithdrawalId === id) return;

    // H-5: Guard against null/zero amount silently showing as "0 GNF"
    const safeAmount = amount ?? 0;
    if (safeAmount <= 0) {
      showToast("Montant invalide — veuillez recharger la page.", "error");
      return;
    }

    try {
      if (status === 'processed') {
        const confirmed = await askConfirm(`Approuver ce retrait de ${formatGNF(safeAmount)} ?`);
        if (!confirmed) return;
      } else {
        const reason = await askPrompt("Raison du rejet :", "Veuillez indiquer pourquoi ce retrait est refusé.");
        if (reason === null) return;
        if (!reason.trim()) {
          showToast("Une raison est obligatoire pour le rejet.", "info");
          return;
        }
        // Store reason for use below
        (processWithdrawal as any)._lastReason = reason;
      }

      // H-6: Set processing state AFTER confirmation so button disables only during RPC
      setProcessingWithdrawalId(id);

      // C-1: Snapshot current state for rollback before optimistic update
      const snapshot = withdrawals.slice();

      // Optimistic UI update
      setWithdrawals(prev =>
        prev.map(w => w.id === id ? { ...w, status: status === 'processed' ? 'processed' : 'rejected' } : w)
      );

      try {
        if (status === 'processed') {
          await withdrawalService.approveWithdrawal(id);
        } else {
          await withdrawalService.rejectWithdrawal(id, (processWithdrawal as any)._lastReason);
        }
        logAction(status === 'processed' ? 'APPROVE_WITHDRAWAL' : 'REJECT_WITHDRAWAL', 'withdrawal', id, { status });
        showToast(`Retrait ${status === 'processed' ? 'approuvé ✓' : 'rejeté'} avec succès.`, 'success');
      } catch (rpcError: any) {
        // C-1: Roll back to snapshot instead of full fetchData() which races Realtime
        setWithdrawals(snapshot);
        console.error("Finance action failed:", rpcError);
        showToast("Erreur: " + rpcError.message, 'error');
      }
    } catch (dialogError: any) {
      // Dialog cancelled or unexpected error — no state change needed
      console.error("processWithdrawal dialog error:", dialogError);
    } finally {
      setProcessingWithdrawalId(null);
    }
  };

  const publishAnnouncement = async () => {
    if (!newAnnouncement.title || !newAnnouncement.content) {
      showToast("Titre et contenu requis.", "info");
      return;
    }
    
    const { error } = await supabase.from('announcements').insert({
      title: newAnnouncement.title,
      content: newAnnouncement.content,
      target_type: newAnnouncement.target,
      is_active: true
    });
    
    if (!error) {
      logAction('PUBLISH_ANNOUNCEMENT', 'announcement', 'new', { title: newAnnouncement.title });
      setNewAnnouncement({ title: '', content: '', target: 'all' });
      fetchData();
      showToast("Intelligence de bord publiée au réseau !", "success");
    } else {
      showToast("Échec de publication : " + error.message, "error");
    }
  };

  const toggleStoreVerification = async (storeId: string, currentStatus: boolean) => {
    const { error } = await supabase
      .from('stores')
      .update({ is_verified_store: !currentStatus })
      .eq('id', storeId);
    
    if (!error) {
      logAction('VERIFY_STORE', 'store', storeId, { verified: !currentStatus });
      showToast(`Boutique ${!currentStatus ? 'vérifiée' : 'dé-vérifiée'} avec succès.`, 'success');
      fetchData();
    }
  };

  const setVendorStatus = async (storeId: string, newStatus: 'active' | 'pending' | 'suspended') => {
    const { error } = await supabase
      .from('stores')
      .update({ store_status: newStatus })
      .eq('id', storeId);
    if (error) {
      showToast(`Échec de la mise à jour : ${error.message}`, 'error');
      return;
    }
    const statusLabels: Record<string, string> = {
      active: 'Opérationnel ✅',
      pending: 'En Attente de Vérification 🟡',
      suspended: 'Suspendu 🚫',
    };
    logAction('UPDATE_STORE_STATUS', 'store', storeId, { status: newStatus });
    showToast(`Boutique : ${statusLabels[newStatus]}`, 'success');
    fetchData();
  };

  const archiveVendor = async (storeId: string) => {
    const confirmed = await askConfirm(
      'Désactiver & Archiver cette boutique ?',
      'La boutique sera immédiatement masquée de la plateforme. Les données historiques sont préservées. Cette action peut être annulée par un administrateur.'
    );
    if (!confirmed) return;
    const { error } = await supabase
      .from('stores')
      .update({ store_status: 'archived' })
      .eq('id', storeId);
    if (error) {
      showToast(`Échec de l'archivage : ${error.message}`, 'error');
      return;
    }
    logAction('ARCHIVE_STORE', 'store', storeId, { archived_at: new Date().toISOString() });
    showToast('Boutique archivée et masquée de la plateforme.', 'info');
    fetchData();
  };

  const permanentDeleteVendor = async (vendor: any) => {
    const balance = Number(vendor.balance || 0);
    const pendingOrders = Number(vendor.pending_orders_count || 0);
    if (balance !== 0) {
      showToast(
        `Suppression impossible — Solde actif : ${formatGNF(balance)}. Soldez le compte avant de supprimer.`,
        'error'
      );
      return;
    }
    if (pendingOrders > 0) {
      showToast(
        `Suppression impossible — ${pendingOrders} commande(s) en cours. Attendez la complétion avant de supprimer.`,
        'error'
      );
      return;
    }
    const confirmed = await askConfirm(
      `Supprimer définitivement « ${vendor.store_name || 'Cette boutique'} » ?`,
      'ATTENTION : Cette action est IRRÉVERSIBLE. Toutes les données (produits, historique) seront effacées.'
    );
    if (!confirmed) return;
    const { error } = await supabase.from('stores').delete().eq('id', vendor.id);
    if (error) {
      showToast(`Échec de la suppression : ${error.message}`, 'error');
      return;
    }
    logAction('DELETE_STORE', 'store', vendor.id, { deleted_at: new Date().toISOString() });
    showToast('Boutique définitivement supprimée.', 'success');
    fetchData();
  };

  // A-1: setCourierStatus — syncs both profiles.courier_status (legacy) and
  // courier_profiles.status (canonical) so accept_order_batch suspension guard works.
  const setCourierStatus = async (
    courierId: string,
    newStatus: 'disponible' | 'en_course' | 'hors_ligne' | 'suspendu',
    courier: any
  ) => {
    const cashHeld = Number(courier.cash_in_hand || 0);
    const isActive = courier.active_deliveries_count > 0;
    if ((newStatus === 'hors_ligne' || newStatus === 'suspendu') && (isActive || cashHeld > 0)) {
      if (isActive) showToast('Impossible — Le livreur est en course active.', 'error');
      else showToast(`Impossible — Cash non remis : ${formatGNF(cashHeld)}.`, 'error');
      return;
    }
    // Canonical map: legacy courier_status → courier_profiles.status
    const canonicalStatus = (
      newStatus === 'disponible' || newStatus === 'en_course'
        ? 'active'
        : newStatus === 'suspendu'
          ? 'suspended'
          : 'inactive'
    ) as 'active' | 'suspended' | 'inactive';

    // admin_set_courier_status is SECURITY DEFINER — bypasses RLS correctly
    // and syncs both profiles.courier_status + courier_profiles.status atomically.
    const { error } = await supabase.rpc('admin_set_courier_status', {
      target_user_id:       courierId,
      new_courier_status:   newStatus,
      new_canonical_status: canonicalStatus,
    });
    if (error) { showToast(`Échec : ${error.message}`, 'error'); return; }

    const labels: Record<string, string> = {
      disponible: 'Disponible 🟢',
      en_course:  'En Course 🔵',
      hors_ligne: 'Hors Ligne ⚫',
      suspendu:   'Suspendu 🔴',
    };
    logAction('UPDATE_COURIER_STATUS', 'user', courierId, { status: newStatus });
    showToast(`Livreur : ${labels[newStatus]}`, 'success');
    fetchData();
  };

  const createPromotion = async () => {
    const title = await askPrompt("Nom de la promotion (ex: Soldes d'Été) :");
    if (!title) return;
    
    const type = await askPrompt("Type (tapez l'un des trois): flash_deal, bogo, ou global_discount", "Type de remise") as any;
    if (!['flash_deal', 'bogo', 'global_discount'].includes(type)) {
      showToast("Type de promotion invalide", "error");
      return;
    }

    const valueStr = await askPrompt("Valeur de la remise (Entier/Décimal) :");
    const value = Number(valueStr);
    if (isNaN(value) || !valueStr) return;

    const { error } = await supabase.from('promotions').insert({
      title,
      promo_type: type,
      discount_type: 'percentage',
      discount_value: value,
      start_at: new Date().toISOString(),
      end_at: new Date(Date.now() + 86400000 * 7).toISOString(), // 7 days
      status: 'active'
    });

    if (!error) {
      showToast("Promotion créée !", "success");
      fetchData();
    }
  };

  const deletePromotion = async (id: string) => {
    const confirmed = await askConfirm("Supprimer cette promotion ?");
    if (!confirmed) return;
    const { error } = await supabase.from('promotions').delete().eq('id', id);
    if (!error) {
      showToast("Promotion supprimée", "success");
      fetchData();
    }
  };

  const deleteAnnouncement = async (id: string) => {
    const confirmed = await askConfirm("Void Signal?", "Voulez-vous supprimer cette transmission ?");
    if (!confirmed) return;
    const { error } = await supabase.from('announcements').delete().eq('id', id);
    if (!error) {
      logAction('DELETE_ANNOUNCEMENT', 'announcement', id, { deleted_at: new Date().toISOString() });
      fetchData();
      showToast("Signal supprimé", "info");
    }
  };

  const handleClearCache = async () => {
    const confirmed = await askConfirm("Vider le cache ?", "Cette action effacera le cache local, supprimera les Service Workers et rechargera l'application.");
    if (!confirmed) return;
    
    localStorage.clear();
    sessionStorage.clear();
    
    if ('serviceWorker' in navigator) {
      try {
        const registrations = await navigator.serviceWorker.getRegistrations();
        for (let registration of registrations) {
          await registration.unregister();
        }
      } catch (e) {
        console.error('Service Worker unregistration failed: ', e);
      }
    }
    
    window.location.href = '/';
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="flex flex-col items-center gap-4">
          <ShieldAlert className="w-12 h-12 text-[#ff6600] animate-bounce" />
          <div className="animate-pulse text-[11px] font-bold tracking-wider text-[#ff6600]">Accès Sécurisé en cours...</div>
        </div>
      </div>
    );
  }

  if (!isAdmin) return null;

  return (
    <div className="min-h-screen flex bg-slate-50 text-slate-800 dark:bg-[#090b0e] dark:text-slate-100 selection:bg-[#ff6600]/40 overflow-hidden font-sans relative">
      {/* Mobile Menu Toggle */}
      <button 
        onClick={() => setIsMobileMenuOpen(true)}
        className="lg:hidden fixed top-6 right-6 z-[60] p-4 bg-[#ff6600] rounded-2xl shadow-lg text-white"
      >
        <Menu className="w-6 h-6" />
      </button>

      {/* Side Navigation */}
      <motion.aside 
        initial={false}
        animate={{ 
          width: isSidebarCollapsed ? '96px' : '280px',
          x: 0 
        }}
        transition={{ duration: 0.3, ease: "circOut" }}
        className="h-screen border-r border-slate-200 dark:border-white/5 bg-white dark:bg-[#0b0f17] flex flex-col relative z-20 shrink-0 overflow-hidden hidden lg:flex"
      >
        <div className="px-5 border-b border-slate-200 dark:border-white/5 flex items-center justify-between h-20 shrink-0">
          <AnimatePresence mode="wait">
            {!isSidebarCollapsed && (
              <motion.div
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -10 }}
                className="overflow-hidden whitespace-nowrap"
              >
                <h2 className="text-lg font-extrabold tracking-tight text-slate-800 dark:text-white uppercase">{APP_NAME}<span className="text-[#ff6600]"> Admin</span></h2>
              </motion.div>
            )}
          </AnimatePresence>

          <button 
            onClick={() => setIsSidebarCollapsed(!isSidebarCollapsed)}
            className="p-2 bg-slate-50 dark:bg-white/5 border border-slate-200 dark:border-white/10 rounded-xl hover:bg-slate-100 dark:hover:bg-white/10 hover:border-[#ff6600]/30 dark:hover:border-[#ff6600]/30 transition-all group shrink-0"
            title={isSidebarCollapsed ? "Développer le menu" : "Réduire le menu"}
          >
            <motion.div
              animate={{ rotate: isSidebarCollapsed ? 180 : 0 }}
              transition={{ duration: 0.3 }}
            >
              <ChevronRight className="w-4 h-4 text-[#ff6600]" />
            </motion.div>
          </button>
        </div>

        <nav className="flex-1 min-h-0 overflow-y-auto px-3 py-3 pb-10 space-y-4 select-none scrollbar-thin scrollbar-thumb-slate-300 dark:scrollbar-thumb-white/10 scrollbar-track-transparent">
          <div className="space-y-4">
            {navGroups.map((group, gIdx) => (
              <div key={gIdx} className="space-y-1">
                <AnimatePresence>
                  {!isSidebarCollapsed && (
                    <motion.h4
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      exit={{ opacity: 0 }}
                      className="text-[10px] font-bold text-orange-500/80 uppercase tracking-wider pt-2 pb-1 px-3"
                    >
                      {group.label}
                    </motion.h4>
                  )}
                </AnimatePresence>

                <div className="space-y-1">
                  {group.items.map(item => {
                    const Icon = item.icon;
                    return (
                      <button
                        key={item.id}
                        onClick={() => setActiveTab(item.id)}
                        className={`w-full flex items-center gap-3.5 px-3 py-2.5 rounded-xl transition-all duration-200 group relative ${
                          activeTab === item.id
                            ? 'bg-orange-600 text-white font-semibold shadow-md shadow-orange-600/30'
                            : 'text-slate-600 dark:text-white/60 hover:bg-slate-100 dark:hover:bg-white/5 hover:text-slate-900 dark:hover:text-white'
                        }`}
                      >
                        <Icon className={`w-4.5 h-4.5 shrink-0 ${
                          activeTab === item.id
                            ? 'text-white'
                            : 'text-orange-400/80 group-hover:text-orange-400 transition-colors'
                        }`} />

                        <AnimatePresence>
                          {!isSidebarCollapsed && (
                            <motion.span
                              initial={{ opacity: 0, x: -5 }}
                              animate={{ opacity: 1, x: 0 }}
                              exit={{ opacity: 0, x: -5 }}
                              className="text-xs font-semibold whitespace-nowrap overflow-hidden"
                            >
                              {item.label}
                            </motion.span>
                          )}
                        </AnimatePresence>

                        {activeTab === item.id && (
                          <motion.div
                            layoutId="activeSideTab"
                            className="absolute left-0 top-1/2 -translate-y-1/2 w-1 h-5 bg-white rounded-r-full"
                          />
                        )}
                        {/* Badge for pending counts */}
                        {'badge' in item && (item as any).badge > 0 && (
                          <span className="absolute top-2 right-2 w-4 h-4 bg-rose-500 text-white text-[8px] font-black rounded-full flex items-center justify-center shadow-sm shadow-rose-500/40">
                            {(item as any).badge > 9 ? '9+' : (item as any).badge}
                          </span>
                        )}
                      </button>
                    );
                  })}
                </div>
              </div>
            ))}
          </div>
        </nav>

        <div className="p-3.5 border-t border-slate-200 dark:border-white/5 bg-white dark:bg-[#0b0f17] shrink-0 relative z-10 shadow-[0_-4px_12px_rgba(0,0,0,0.05)] dark:shadow-[0_-4px_12px_rgba(0,0,0,0.25)]">
           <button
             onClick={async () => { await supabase.auth.signOut(); navigate('/login'); }}
             className={`w-full flex items-center justify-center gap-3 px-3.5 py-2.5 bg-rose-500/5 border border-rose-500/20 rounded-xl text-xs font-bold tracking-wider text-rose-500 hover:bg-rose-500/15 hover:border-rose-500/40 transition-all group overflow-hidden ${isSidebarCollapsed ? 'px-0' : ''}`}
           >
             <LogOut className="w-4.5 h-4.5 shrink-0" />
             {!isSidebarCollapsed && <span className="whitespace-nowrap">Se déconnecter</span>}
           </button>
        </div>
      </motion.aside>

      {/* Mobile Drawer */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <>
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsMobileMenuOpen(false)}
              className="fixed inset-0 bg-black/60 backdrop-blur-sm z-[70] lg:hidden"
            />
            <motion.aside 
              initial={{ x: '-100%' }}
              animate={{ x: 0 }}
              exit={{ x: '-100%' }}
              transition={{ type: 'spring', damping: 25, stiffness: 200 }}
              className="fixed inset-y-0 left-0 w-72 bg-white dark:bg-[#0b0f17] border-r border-slate-200 dark:border-white/5 z-[80] lg:hidden flex flex-col"
            >
              <div className="px-5 border-b border-slate-200 dark:border-white/5 flex items-center justify-between shrink-0 h-20">
                <div>
                  <h2 className="text-lg font-bold text-slate-800 dark:text-white uppercase tracking-tight">{APP_NAME}</h2>
                  <p className="text-[10px] font-bold text-slate-400 dark:text-white/20 uppercase tracking-widest mt-1">Espace Admin</p>
                </div>
                <button onClick={() => setIsMobileMenuOpen(false)} className="p-2 text-slate-400 dark:text-white/40 hover:text-slate-600 dark:hover:text-white">
                  <X className="w-6 h-6" />
                </button>
              </div>

              <nav className="flex-1 min-h-0 overflow-y-auto p-3.5 pb-10 space-y-4">
                {navGroups.map((group, grpIdx) => (
                  <div key={grpIdx} className="space-y-1">
                    <h4 className="text-[10px] font-bold text-orange-500/80 uppercase tracking-wider pt-2 pb-1 px-3">
                      {group.label}
                    </h4>
                    <div className="space-y-1">
                      {group.items.map(item => {
                        const Icon = item.icon;
                        return (
                          <button
                            key={item.id}
                            onClick={() => { setActiveTab(item.id); setIsMobileMenuOpen(false); }}
                            className={`w-full flex items-center gap-3.5 px-3 py-2.5 rounded-xl transition-all duration-200 text-left ${
                              activeTab === item.id
                                ? 'bg-orange-600 text-white font-semibold shadow-md shadow-orange-600/30'
                                : 'text-slate-600 dark:text-white/60 hover:bg-slate-50 dark:hover:bg-white/5 hover:text-slate-900 dark:hover:text-white'
                            }`}
                          >
                            <Icon className={`w-4.5 h-4.5 shrink-0 ${
                              activeTab === item.id ? 'text-white' : 'text-orange-400/80'
                            }`} />
                            <span className="text-xs font-semibold">{item.label}</span>
                          </button>
                        );
                      })}
                    </div>
                  </div>
                ))}
              </nav>
              <div className="p-3.5 border-t border-slate-200 dark:border-white/5 bg-white dark:bg-[#0b0f17] shrink-0">
                <button
                  onClick={async () => { await supabase.auth.signOut(); navigate('/login'); }}
                  className="w-full flex items-center justify-center gap-3 px-4 py-2.5 rounded-xl bg-rose-500/5 border border-rose-500/20 text-rose-500 hover:bg-rose-500/15 hover:border-rose-500/40 transition-all text-xs font-bold"
                >
                  <LogOut className="w-4.5 h-4.5 shrink-0" />
                  Se déconnecter
                </button>
              </div>
            </motion.aside>
          </>
        )}
      </AnimatePresence>

      {/* Main Content Area */}
      <div className="flex-grow flex flex-col h-screen overflow-hidden relative">
        <header className="h-20 lg:h-24 border-b border-slate-200 dark:border-white/5 bg-white/80 dark:bg-[#0b0f17]/80 backdrop-blur-3xl flex items-center justify-between px-6 lg:px-12 relative z-10">
          <div className="flex items-center gap-4 lg:gap-8">
            <div className="flex items-center gap-3">
              <div className="flex flex-col">
                <div className="flex items-center gap-1.5 text-xs text-slate-500 dark:text-slate-400">
                  <span>Console Admin</span>
                  <span className="text-slate-300 dark:text-slate-600">/</span>
                  <span className="text-[#ff6600] font-medium">{navGroups.flatMap(g => g.items).find(i => i.id === activeTab)?.label || activeTab}</span>
                </div>
                <h1 className="text-base lg:text-lg font-bold text-slate-800 dark:text-white tracking-tight truncate max-w-[200px] lg:max-w-none">
                  {navGroups.flatMap(g => g.items).find(i => i.id === activeTab)?.label || activeTab}
                </h1>
              </div>
            </div>
            
            <div className="hidden xl:flex items-center gap-2.5 px-3.5 py-2 bg-slate-100/80 dark:bg-white/5 border border-slate-200/80 dark:border-white/10 rounded-xl ml-2 relative group focus-within:border-[#ff6600] transition-colors">
              <Search className="w-3.5 h-3.5 text-slate-400 dark:text-white/30 group-focus-within:text-[#ff6600] transition-colors" />
              <input 
                type="text" 
                placeholder="Recherche globale (commandes, utilisateurs, boutiques)…"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="bg-transparent border-none text-xs font-medium focus:outline-none w-64 placeholder:text-slate-400 dark:placeholder:text-white/20 text-slate-800 dark:text-white"
              />
            </div>
          </div>

          <div className="flex items-center gap-3 lg:gap-6">
            <div className="hidden sm:flex items-center gap-2 px-3 py-1.5 bg-emerald-50 dark:bg-emerald-500/10 border border-emerald-200/80 dark:border-emerald-500/20 rounded-full">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
              <span className="text-[11px] font-semibold text-emerald-700 dark:text-emerald-400">Système opérationnel</span>
            </div>

            <div className="hidden md:flex items-center gap-3 text-right">
              <div>
                <div className="text-[10px] font-bold text-slate-700 dark:text-white uppercase tracking-widest leading-none mb-1">Support {APP_NAME}</div>
                <div className="text-[8px] font-semibold text-slate-400 dark:text-white/20 uppercase tracking-wider">Super-Admin</div>
              </div>
              <div className="w-10 h-10 lg:w-11 lg:h-11 rounded-xl bg-gradient-to-tr from-[#ff6600] to-orange-400 p-[1px]">
                 <div className="w-full h-full rounded-xl bg-white dark:bg-[#050505] flex items-center justify-center">
                    <img 
                      src={`https://ui-avatars.com/api/?name=Admin&background=4f46e5&color=fff&size=128`} 
                      onError={(e) => {
                        (e.currentTarget as HTMLImageElement).src = `https://api.dicebear.com/7.x/initials/svg?seed=Admin`;
                      }}
                      className="w-full h-full rounded-xl object-cover opacity-90" 
                      alt="AvatarAdmin"
                    />
                 </div>
              </div>
              {/* Direct logout button */}
              <button
                onClick={async () => { await supabase.auth.signOut(); navigate('/login'); }}
                title="Se déconnecter"
                className="w-9 h-9 flex items-center justify-center rounded-xl bg-rose-500/10 border border-rose-500/20 text-rose-500 hover:bg-rose-500/20 hover:border-rose-500/40 transition-all"
              >
                <LogOut className="w-4 h-4" />
              </button>
            </div>

            <div className="h-6 w-[1px] bg-slate-200 dark:bg-white/5" />
            <button 
              onClick={fetchData}
              className="p-2 lg:p-2.5 bg-slate-50 dark:bg-white/5 border border-slate-200 dark:border-white/10 rounded-xl text-slate-500 dark:text-white/60 hover:bg-slate-100 dark:hover:bg-white/10 hover:border-[#ff6600]/30 dark:hover:border-[#ff6600]/30 transition-all group"
            >
              <Activity className="w-4 h-4 lg:w-4.5 lg:h-4.5 group-hover:rotate-180 transition-transform duration-700" />
            </button>
          </div>
        </header>

        <main className="flex-grow overflow-y-auto p-4 lg:p-12 custom-scrollbar bg-slate-50 dark:bg-[#090b0e]">
          <div className="max-w-[1600px] mx-auto space-y-8 lg:space-y-16">
            <AnimatePresence mode="wait">
              {activeTab === 'overview' && (
                <motion.div 
                  key="overview"
                  initial={{ opacity: 0, scale: 0.98, y: 15 }}
                  animate={{ opacity: 1, scale: 1, y: 0 }}
                  exit={{ opacity: 0, scale: 0.98, y: -15 }}
                  transition={{ duration: 0.3 }}
                  className="space-y-8"
                >
                  {/* Status Banner */}
                  <div className="relative p-8 lg:p-12 bg-gradient-to-r from-orange-500 via-orange-600 to-red-600 rounded-[2rem] overflow-hidden shadow-lg shadow-orange-500/10">
                    <div className="absolute top-0 right-0 w-[400px] h-[400px] bg-white/10 blur-[100px] rounded-full -mr-32 -mt-32" />
                    
                    <div className="relative z-10 flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
                      <div className="space-y-2">
                        <div className="flex items-center gap-3">
                           <div className="px-3 py-1 bg-white/20 backdrop-blur-md rounded-lg text-[9px] font-bold uppercase tracking-wider text-white">Statut Système : En ligne</div>
                        </div>
                        <h2 className="text-3xl lg:text-5xl font-extrabold tracking-tight text-white">Tableau de bord</h2>
                        <div className="flex items-center gap-3 text-white/70 text-xs font-semibold">
                           <span>Vue d'ensemble</span>
                           <div className="h-2 w-2 rounded-full bg-white/40" />
                           <span>Mise à jour en temps réel</span>
                        </div>
                      </div>
                      
                      <div className="flex flex-col sm:flex-row gap-4 w-full md:w-auto">
                        <div className="w-full md:w-auto p-5 bg-white/10 backdrop-blur-md border border-white/20 rounded-2xl flex flex-col gap-1 min-w-[180px]">
                           <span className="text-[10px] font-bold uppercase tracking-wider text-white/60">Chiffre d'Affaires</span>
                           <span className="text-2xl font-black text-white">{formatGNF(stats.totalSales)}</span>
                        </div>
                        <div className="w-full md:w-auto p-5 bg-white/10 backdrop-blur-md border border-white/20 rounded-2xl flex flex-col gap-1 min-w-[180px]">
                           <span className="text-[10px] font-bold uppercase tracking-wider text-white/60">Commissions Plateforme</span>
                           <span className="text-2xl font-black text-white">{formatGNF(stats.platformNet)}</span>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Core Metrics Monitor */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                    <StatCard 
                      label="Volume des Ventes" 
                      value={formatGNF(stats.totalSales)} 
                      icon={Coins} 
                      trend="+14.2%" 
                      color="primary"
                    />
                    <StatCard 
                      label="Total Utilisateurs" 
                      value={stats.totalUsers} 
                      icon={Users} 
                      trend={stats.totalUsers === 0 ? "Initialisation..." : "+125"} 
                      color={stats.totalUsers === 0 ? "primary" : "blue"}
                    />
                    <StatCard 
                      label="Total Vendeurs" 
                      value={stats.totalVendors} 
                      icon={Store} 
                      trend={stats.totalVendors === 0 ? "Audit Requis" : "+12"} 
                      color={stats.totalVendors === 0 ? "primary" : "green"}
                    />
                    <StatCard 
                      label="Taux de Croissance" 
                      value={`${stats.monthlyGrowth}%`} 
                      icon={TrendingUp} 
                      trend="Optimal"
                      color="purple"
                    />
                  </div>

                  {/* Actions Requises */}
                  <div className="bg-white dark:bg-[#111622] border border-slate-200 dark:border-white/5 rounded-3xl p-6 lg:p-8 relative overflow-hidden shadow-sm dark:shadow-md">
                    <div className="flex items-center gap-3 mb-6">
                      <div className="w-2.5 h-2.5 rounded-full bg-[#ff6600] animate-pulse" />
                      <h3 className="text-xs font-bold text-slate-800 dark:text-white uppercase tracking-wider">Actions requises</h3>
                    </div>
                    
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                      <QuickActionTile 
                        label="Demandes de Retrait" 
                        count={withdrawals.filter(w => w.status === 'pending').length} 
                        onClick={() => setActiveTab('finance')}
                        icon={Coins}
                        color="amber"
                      />
                      <QuickActionTile 
                        label="Validation Boutiques" 
                        count={stats.pendingVendors} 
                        onClick={() => setActiveTab('vendors')}
                        icon={Store}
                        color="indigo"
                      />
                      <QuickActionTile 
                        label="Agrément Livreurs" 
                        count={stats.pendingCouriers} 
                        onClick={() => setActiveTab('couriers')}
                        icon={Monitor}
                        color="emerald"
                      />
                      <QuickActionTile 
                        label="Logs Système" 
                        count={auditLogs.length > 999 ? '999+' : auditLogs.length} 
                        onClick={() => setActiveTab('logs')}
                        icon={FileText}
                        color="blue"
                      />
                    </div>
                  </div>

                  {stats.totalUsers === 0 && (
                    <div className="bg-red-500/5 dark:bg-[#ff6600]/10 border border-red-500/20 dark:border-[#ff6600]/30 rounded-[2rem] p-8 text-center space-y-4">
                      <AlertTriangle className="w-12 h-12 text-red-500 dark:text-[#ff6600] mx-auto animate-pulse" />
                      <div className="max-w-2xl mx-auto">
                        <h3 className="text-xl font-bold text-slate-800 dark:text-white uppercase tracking-tight mb-2">Base de Données Non Initialisée</h3>
                        <p className="text-slate-500 dark:text-slate-400 text-sm leading-relaxed mb-6">
                          Aucun utilisateur n'a été trouvé dans le système. Assurez-vous d'avoir exécuté les scripts SQL d'infrastructure dans votre console Supabase pour activer les déclencheurs et les tables de profils.
                        </p>
                        <div className="flex flex-wrap justify-center gap-3">
                          <div className="px-4 py-2 bg-slate-100 dark:bg-white/5 border border-slate-200 dark:border-white/15 rounded-xl text-[10px] font-semibold text-slate-600 dark:text-white/60">
                            Mode : {import.meta.env.DEV ? 'Développement' : 'Production'}
                          </div>
                          <div className="px-4 py-2 bg-slate-100 dark:bg-white/5 border border-slate-200 dark:border-white/15 rounded-xl text-[10px] font-semibold text-slate-600 dark:text-white/60">
                            ID : {user?.id}
                          </div>
                          <div className="px-4 py-2 bg-slate-100 dark:bg-white/5 border border-slate-200 dark:border-white/15 rounded-xl text-[10px] font-semibold text-slate-600 dark:text-white/60">
                            Email : {user?.email}
                          </div>
                        </div>
                      </div>
                    </div>
                  )}

                  {/* Main Content Split */}
                  <div className="grid grid-cols-1 xl:grid-cols-3 gap-8 items-start">
                    <div className="xl:col-span-2 space-y-8">
                      {/* Primary Analytic Chart */}
                      <div className="bg-white dark:bg-[#111622] border border-slate-200 dark:border-white/5 rounded-3xl p-6 lg:p-8 shadow-sm dark:shadow-md">
                        <div className="flex items-center justify-between mb-8">
                          <div>
                            <h3 className="text-lg font-bold text-slate-800 dark:text-white">Flux des Ventes</h3>
                            <p className="text-[10px] font-semibold text-slate-400 dark:text-slate-500 uppercase mt-0.5">Évolution mensuelle des ventes</p>
                          </div>
                          <div className="flex gap-4">
                            <div className="flex items-center gap-2 px-3 py-1.5 bg-[#ff6600]/10 border border-[#ff6600]/20 rounded-xl">
                              <div className="w-1.5 h-1.5 rounded-full bg-[#ff6600]" />
                              <span className="text-[10px] font-bold text-orange-500 uppercase">Ventes</span>
                            </div>
                          </div>
                        </div>
                        
                        <div className="h-[300px] min-h-[300px] w-full">
                          <ResponsiveContainer width="100%" height="100%" minWidth={0} minHeight={0}>
                            <AreaChart data={chartData}>
                              <defs>
                                <linearGradient id="colorValue" x1="0" y1="0" x2="0" y2="1">
                                  <stop offset="5%" stopColor="#ff6600" stopOpacity={0.3}/>
                                  <stop offset="95%" stopColor="#ff6600" stopOpacity={0}/>
                                </linearGradient>
                              </defs>
                              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke={isDarkMode ? "rgba(255,255,255,0.03)" : "rgba(0,0,0,0.05)"} />
                              <XAxis 
                                dataKey="name" 
                                axisLine={false} 
                                tickLine={false} 
                                tick={{ fontSize: 10, fontStyle: 'normal', fill: isDarkMode ? 'rgba(255,255,255,0.4)' : 'rgba(0,0,0,0.4)' }}
                              />
                              <YAxis 
                                axisLine={false} 
                                tickLine={false} 
                                tick={{ fontSize: 10, fontStyle: 'normal', fill: isDarkMode ? 'rgba(255,255,255,0.4)' : 'rgba(0,0,0,0.4)' }}
                              />
                              <Tooltip 
                                contentStyle={{ 
                                  backgroundColor: isDarkMode ? '#1e293b' : '#ffffff', 
                                  border: isDarkMode ? '1px solid rgba(255,255,255,0.1)' : '1px solid rgba(0,0,0,0.1)',
                                  borderRadius: '12px',
                                  fontSize: '11px',
                                  fontWeight: 600,
                                  color: isDarkMode ? '#fff' : '#000',
                                }}
                                itemStyle={{ color: '#ff6600' }}
                              />
                              <Area 
                                type="monotone" 
                                dataKey="value" 
                                stroke="#ff6600" 
                                strokeWidth={4} 
                                fillOpacity={1} 
                                fill="url(#colorValue)" 
                                animationDuration={1500}
                              />
                            </AreaChart>
                          </ResponsiveContainer>
                        </div>
                      </div>

                      {/* Performance Benchmarks / Top Products */}
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                         <div className="bg-white dark:bg-[#111622] border border-slate-200 dark:border-white/5 rounded-3xl p-6 lg:p-8 shadow-sm dark:shadow-md flex flex-col h-[400px]">
                            <div className="mb-6">
                               <h3 className="text-lg font-bold text-slate-800 dark:text-white">Produits Populaires</h3>
                               <p className="text-[10px] font-semibold text-slate-400 dark:text-slate-500 uppercase mt-0.5">Top 5 des articles vendus</p>
                            </div>
                            
                            <div className="flex-grow min-h-0">
                              <ResponsiveContainer width="100%" height="100%" minWidth={0} minHeight={0}>
                                <BarChart data={topProductsData} layout="vertical">
                                   <XAxis type="number" hide />
                                   <YAxis 
                                     dataKey="name" 
                                     type="category" 
                                     axisLine={false} 
                                     tickLine={false} 
                                     width={100}
                                     tick={{ fontSize: 10, fontStyle: 'normal', fill: isDarkMode ? 'rgba(255,255,255,0.4)' : 'rgba(0,0,0,0.4)' }}
                                   />
                                   <Tooltip 
                                     cursor={{ fill: isDarkMode ? 'rgba(255,255,255,0.02)' : 'rgba(0,0,0,0.02)' }}
                                     contentStyle={{ 
                                       backgroundColor: isDarkMode ? '#1e293b' : '#ffffff', 
                                       border: isDarkMode ? '1px solid rgba(255,255,255,0.1)' : '1px solid rgba(0,0,0,0.1)',
                                       borderRadius: '12px',
                                       color: isDarkMode ? '#fff' : '#000',
                                     }}
                                   />
                                   <Bar dataKey="sales" radius={[0, 8, 8, 0]} barSize={16}>
                                     {topProductsData.map((entry, index) => (
                                       <Cell key={`cell-${index}`} fill={index === 0 ? '#ff6600' : 'rgba(255,102,0,0.25)'} />
                                     ))}
                                   </Bar>
                                </BarChart>
                              </ResponsiveContainer>
                            </div>
                         </div>

                         <div className="bg-[#ff6600] p-8 lg:p-10 rounded-3xl text-white relative overflow-hidden group h-[400px] shadow-lg shadow-orange-500/10 flex flex-col justify-between">
                            <div className="absolute top-0 right-0 w-48 h-48 bg-white/10 rounded-full -mr-24 -mt-24 blur-2xl group-hover:scale-110 transition-transform duration-700" />
                            <div>
                              <Activity className="w-10 h-10 mb-6 text-white" />
                              <h3 className="text-xs font-bold tracking-wider uppercase opacity-80 mb-2">Rappels et Astuces</h3>
                              <p className="text-xl font-bold mb-3 leading-snug">Gestion Opérationnelle</p>
                              <p className="text-sm opacity-80 leading-relaxed">Pensez à vérifier régulièrement les demandes de retrait et à valider les nouveaux livreurs pour maintenir la fluidité du service de livraison.</p>
                            </div>
                            <button 
                              onClick={fetchData}
                              className="flex items-center justify-center gap-2 text-[11px] font-bold tracking-wider uppercase bg-white text-[#ff6600] px-6 py-4 rounded-xl hover:bg-slate-50 transition-all active:scale-95 shadow-sm w-fit"
                            >
                              <span>Actualiser les données</span>
                              <ChevronRight className="w-4 h-4" />
                            </button>
                         </div>
                      </div>
                    </div>

                    {/* Activity Feed Column */}
                    <div className="space-y-8">
                      <div className="bg-white dark:bg-[#111622] border border-slate-200 dark:border-white/5 p-6 lg:p-8 rounded-3xl relative overflow-hidden shadow-sm dark:shadow-md flex flex-col h-[650px]">
                        <div className="flex items-center justify-between mb-6 shrink-0">
                          <div className="flex items-center gap-2">
                             <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse shadow-[0_0_8px_rgba(16,185,129,0.5)]" />
                             <h3 className="text-xs font-bold text-slate-800 dark:text-white uppercase tracking-wider">Activité Récente</h3>
                          </div>
                          <div className="flex gap-1 items-end h-4">
                             <div className="w-1 h-2 bg-[#ff6600] animate-[pulse_1s_infinite_0s] rounded-full" />
                             <div className="w-1 h-3.5 bg-[#ff6600] animate-[pulse_1s_infinite_0.1s] rounded-full" />
                             <div className="w-1 h-2.5 bg-[#ff6600] animate-[pulse_1s_infinite_0.2s] rounded-full" />
                          </div>
                        </div>
                        
                        <div className="flex-grow overflow-y-auto no-scrollbar space-y-4 pr-1">
                          {auditLogs.length > 0 ? (
                            auditLogs.map((log, idx) => (
                              <div key={log.id || idx} className="relative pl-5 border-l border-slate-200 dark:border-white/10 group/entry pb-1">
                                <div className="absolute left-[-3.5px] top-1.5 w-1.5 h-1.5 rounded-full bg-[#ff6600] group-hover/entry:scale-125 transition-transform" />
                                <div className="space-y-1">
                                  <div className="flex justify-between items-center">
                                    <span className="text-[9px] font-bold text-orange-500 uppercase tracking-wide">{(log.action || log.new_data?.action || 'ACTION').replace(/_/g, ' ')}</span>
                                    <span className="text-[9px] text-slate-400 dark:text-white/30 uppercase tracking-widest">{new Date(log.created_at).toLocaleTimeString()}</span>
                                  </div>
                                  <p className="text-xs text-slate-600 dark:text-white/60 leading-tight">
                                    <span className="font-semibold text-slate-800 dark:text-white">{allUsers.find(u => u.id === log.user_id)?.full_name || log.user_id?.substring(0, 8) || 'Système'}</span> a modifié {log.entity_type}
                                  </p>
                                </div>
                              </div>
                            ))
                          ) : (
                            <div className="flex flex-col items-center justify-center h-full text-center space-y-3">
                               <FileText className="w-8 h-8 text-slate-300 dark:text-white/10" />
                               <p className="text-xs font-semibold text-slate-400 dark:text-white/20 uppercase tracking-wider">Aucune activité récente</p>
                            </div>
                          )}
                        </div>
                        
                        <button 
                          onClick={() => setActiveTab('logs')}
                          className="mt-6 py-4 border border-slate-200 dark:border-white/5 bg-slate-50 dark:bg-white/[0.01] rounded-xl text-[10px] font-bold tracking-wider uppercase text-slate-500 dark:text-white/40 hover:bg-slate-100 dark:hover:bg-white/5 hover:text-slate-800 dark:hover:text-white transition-all shrink-0"
                        >
                           Voir l'historique complet
                        </button>
                      </div>

                      <div className="bg-white dark:bg-[#111622] border border-slate-200 dark:border-white/5 p-6 lg:p-8 rounded-3xl relative overflow-hidden shadow-sm dark:shadow-md">
                        <div className="flex items-center gap-4 mb-4">
                           <div className="w-10 h-10 rounded-xl bg-emerald-500/10 flex items-center justify-center">
                              <Activity className="w-5 h-5 text-emerald-500" />
                           </div>
                           <div>
                              <p className="text-[10px] font-bold text-emerald-500 uppercase tracking-wider">Statut Général</p>
                              <p className="text-lg font-bold text-slate-800 dark:text-white">Système Optimisé</p>
                           </div>
                        </div>
                        <div className="h-1.5 w-full bg-slate-100 dark:bg-white/5 rounded-full overflow-hidden">
                          <motion.div initial={{ width: 0 }} animate={{ width: '96%' }} className="h-full bg-emerald-500" />
                        </div>
                        <p className="text-[9px] font-semibold text-slate-400 dark:text-white/30 uppercase tracking-wider mt-3">Latence moyenne : 45ms</p>
                      </div>
                    </div>
                  </div>
                </motion.div>
              )}

              {activeTab === 'finance' && (() => {
                // ── Vault Metrics (null-safe calculations) ──────────────────────
                const escrowStatuses = ['in_transit', 'shipped'];
                const grossVolumeStatuses = ['paid', 'accepted', 'preparing', 'in_transit', 'shipped', 'delivered'];
                const commissionRate = Number(platformSettings.commission || 5) / 100;

                const grossVolume = allOrdersList
                  .filter(o => grossVolumeStatuses.includes(o.status ?? ''))
                  .reduce((sum, o) => sum + (Number(o.total_amount) || 0), 0) || 0;

                const netCommissions = allOrdersList
                  .filter(o => grossVolumeStatuses.includes(o.status ?? ''))
                  .reduce((sum, o) => {
                    const total = Number(o.total_amount) || 0;
                    const fee = Number(o.delivery_fee) || 0;
                    const subtotal = total - fee;
                    return sum + Math.round(subtotal * commissionRate);
                  }, 0) || 0;

                const escrowFunds = allOrdersList
                  .filter(o => escrowStatuses.includes(o.status ?? ''))
                  .reduce((sum, o) => sum + (Number(o.total_amount) || 0), 0) || 0;

                const pendingWithdrawalsTotal = withdrawals
                  .filter(w => w.status === 'pending')
                  .reduce((sum, w) => sum + (Number(w.amount) || 0), 0) || 0;

                // ── Courier earnings (delivered orders grouped by courier) ──────
                const courierEarningsMap: Record<string, { courierId: string; name: string; earnings: number; deliveries: number }> = {};
                allOrdersList
                  .filter(o => o.status === 'delivered' && o.courier_id)
                  .forEach(o => {
                    const cId = o.courier_id as string;
                    const fee = Number(o.delivery_fee) || 0;
                    if (!courierEarningsMap[cId]) {
                      const courier = allCouriers.find((c: any) => c.id === cId);
                      courierEarningsMap[cId] = {
                        courierId: cId,
                        name: courier?.full_name || courier?.phone || `Coursier #${cId.substring(0, 6)}`,
                        earnings: 0,
                        deliveries: 0,
                      };
                    }
                    courierEarningsMap[cId].earnings += fee;
                    courierEarningsMap[cId].deliveries += 1;
                  });
                const courierEarningsList = Object.values(courierEarningsMap)
                  .sort((a, b) => b.earnings - a.earnings);

                return (
                <motion.div 
                  key="finance"
                  initial={{ opacity: 0, scale: 0.98, y: 15 }}
                  animate={{ opacity: 1, scale: 1, y: 0 }}
                  exit={{ opacity: 0, scale: 0.98, y: -15 }}
                  transition={{ duration: 0.3 }}
                  className="space-y-8"
                >
                  {/* ─── MARKETPLACE VAULT METRICS ──────────────────────────── */}
                  <div>
                    <div className="flex items-center gap-3 mb-5">
                      <div className="w-1 h-6 rounded-full bg-gradient-to-b from-[#ff6600] to-orange-400" />
                      <h2 className="text-xs font-black tracking-widest uppercase text-slate-500 dark:text-white/40">Marketplace Vault — Capital en Temps Réel</h2>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-5">

                      {/* Chiffre d'Affaires Brut */}
                      <div className="relative bg-gradient-to-br from-[#ff6600]/[0.08] to-orange-500/[0.03] dark:from-[#ff6600]/[0.12] dark:to-transparent border border-[#ff6600]/20 dark:border-[#ff6600]/15 p-6 rounded-3xl overflow-hidden group hover:border-[#ff6600]/40 transition-all duration-300">
                        <div className="absolute -top-6 -right-6 w-24 h-24 bg-[#ff6600]/20 rounded-full blur-2xl group-hover:scale-125 transition-transform duration-500" />
                        <div className="absolute bottom-0 left-0 w-full h-0.5 bg-gradient-to-r from-[#ff6600]/40 via-orange-400/20 to-transparent" />
                        <div className="flex items-start justify-between mb-4">
                          <div className="p-2.5 rounded-xl bg-[#ff6600]/10 border border-[#ff6600]/20">
                            <TrendingUp className="w-4 h-4 text-[#ff6600]" />
                          </div>
                          <span className="text-[9px] font-black tracking-widest uppercase text-[#ff6600]/60 bg-[#ff6600]/10 px-2 py-1 rounded-full">LengoPay</span>
                        </div>
                        <p className="text-[10px] font-bold text-slate-500 dark:text-white/40 tracking-wider uppercase mb-1">Chiffre d'Affaires Brut</p>
                        <p className="text-2xl lg:text-3xl font-black text-[#ff6600] tracking-tight tabular-nums">
                          {formatGNF(grossVolume)}
                        </p>
                        <p className="text-[10px] text-slate-400 dark:text-white/25 mt-2 font-medium">Total des paiements LengoPay traités</p>
                      </div>

                      {/* Commissions Nettes Fatibara */}
                      <div className="relative bg-gradient-to-br from-emerald-500/[0.08] to-emerald-500/[0.02] dark:from-emerald-500/[0.10] dark:to-transparent border border-emerald-500/20 dark:border-emerald-500/15 p-6 rounded-3xl overflow-hidden group hover:border-emerald-400/40 transition-all duration-300">
                        <div className="absolute -top-6 -right-6 w-24 h-24 bg-emerald-500/15 rounded-full blur-2xl group-hover:scale-125 transition-transform duration-500" />
                        <div className="absolute bottom-0 left-0 w-full h-0.5 bg-gradient-to-r from-emerald-500/40 via-emerald-400/20 to-transparent" />
                        <div className="flex items-start justify-between mb-4">
                          <div className="p-2.5 rounded-xl bg-emerald-500/10 border border-emerald-500/20">
                            <Banknote className="w-4 h-4 text-emerald-500" />
                          </div>
                          <span className="text-[9px] font-black tracking-widest uppercase text-emerald-500/60 bg-emerald-500/10 px-2 py-1 rounded-full">{platformSettings.commission || 5}% cut</span>
                        </div>
                        <p className="text-[10px] font-bold text-slate-500 dark:text-white/40 tracking-wider uppercase mb-1">Commissions Nettes Fatibara</p>
                        <p className="text-2xl lg:text-3xl font-black text-emerald-500 tracking-tight tabular-nums">
                          {formatGNF(netCommissions)}
                        </p>
                        <p className="text-[10px] text-slate-400 dark:text-white/25 mt-2 font-medium">Profit cumulatif de la marketplace</p>
                      </div>

                      {/* Fonds sous Séquestre */}
                      <div className="relative bg-gradient-to-br from-blue-500/[0.08] to-blue-500/[0.02] dark:from-blue-500/[0.10] dark:to-transparent border border-blue-500/20 dark:border-blue-500/15 p-6 rounded-3xl overflow-hidden group hover:border-blue-400/40 transition-all duration-300">
                        <div className="absolute -top-6 -right-6 w-24 h-24 bg-blue-500/15 rounded-full blur-2xl group-hover:scale-125 transition-transform duration-500" />
                        <div className="absolute bottom-0 left-0 w-full h-0.5 bg-gradient-to-r from-blue-500/40 via-blue-400/20 to-transparent" />
                        <div className="flex items-start justify-between mb-4">
                          <div className="p-2.5 rounded-xl bg-blue-500/10 border border-blue-500/20">
                            <Wallet className="w-4 h-4 text-blue-400" />
                          </div>
                          <span className="text-[9px] font-black tracking-widest uppercase text-blue-400/60 bg-blue-500/10 px-2 py-1 rounded-full">En Cours</span>
                        </div>
                        <p className="text-[10px] font-bold text-slate-500 dark:text-white/40 tracking-wider uppercase mb-1">Fonds sous Séquestre</p>
                        <p className="text-2xl lg:text-3xl font-black text-blue-400 tracking-tight tabular-nums">
                          {formatGNF(escrowFunds)}
                        </p>
                        <p className="text-[10px] text-slate-400 dark:text-white/25 mt-2 font-medium">Bloqué en transit — libéré à la livraison</p>
                      </div>
                    </div>
                  </div>

                  {/* ─── REGISTRE DE TRÉSORERIE ──────────────────────────────── */}
                  <div className="bg-white dark:bg-[#111622] border border-slate-200 dark:border-white/5 rounded-3xl overflow-hidden shadow-sm dark:shadow-md">
                    <div className="p-6 lg:p-8 border-b border-slate-200 dark:border-white/5 flex flex-wrap justify-between items-center gap-6">
                      <div>
                        <h2 className="text-xl font-bold text-slate-800 dark:text-white">Registre de Trésorerie</h2>
                        <p className="text-[10px] font-semibold text-slate-400 dark:text-slate-500 uppercase mt-0.5">Demandes de Retrait — Soldes Vendeurs — Coursiers</p>
                      </div>
                      <div className="flex bg-slate-100 dark:bg-black/45 p-1 rounded-xl border border-slate-200 dark:border-white/5 gap-0.5">
                        <button 
                          onClick={() => setFinanceSubTab('withdrawals')}
                          className={`px-4 py-2 rounded-lg text-[10px] font-bold tracking-wider uppercase transition-all ${financeSubTab === 'withdrawals' ? 'bg-[#ff6600] text-white shadow-sm' : 'text-slate-500 dark:text-white/40 hover:text-slate-800 dark:hover:text-white'}`}
                        >
                          Retraits {withdrawals.filter(w => w.status === 'pending').length > 0 && <span className="ml-1 bg-white/20 text-white rounded-full text-[9px] px-1.5 py-0.5 font-black">{withdrawals.filter(w => w.status === 'pending').length}</span>}
                        </button>
                        <button 
                          onClick={() => setFinanceSubTab('commissions')}
                          className={`px-4 py-2 rounded-lg text-[10px] font-bold tracking-wider uppercase transition-all ${financeSubTab === 'commissions' ? 'bg-[#ff6600] text-white shadow-sm' : 'text-slate-500 dark:text-white/40 hover:text-slate-800 dark:hover:text-white'}`}
                        >
                          Commissions
                        </button>
                        <button 
                          onClick={() => setFinanceSubTab('couriers')}
                          className={`px-4 py-2 rounded-lg text-[10px] font-bold tracking-wider uppercase transition-all ${financeSubTab === 'couriers' ? 'bg-[#ff6600] text-white shadow-sm' : 'text-slate-500 dark:text-white/40 hover:text-slate-800 dark:hover:text-white'}`}
                        >
                          Coursiers
                        </button>
                      </div>
                    </div>

                    <div className="p-6 lg:p-8">
                      <AnimatePresence mode="wait">

                        {/* ── WITHDRAWAL LEDGER ──────────────────────────────── */}
                        {financeSubTab === 'withdrawals' && (
                          <motion.div
                            key="withdrawals-table"
                            initial={{ opacity: 0, x: -8 }}
                            animate={{ opacity: 1, x: 0 }}
                            exit={{ opacity: 0, x: 8 }}
                            transition={{ duration: 0.2 }}
                          >
                            {/* Pending total pill */}
                            {pendingWithdrawalsTotal > 0 && (
                              <div className="mb-5 flex items-center gap-3 p-3.5 rounded-xl bg-amber-500/8 dark:bg-amber-500/10 border border-amber-500/20">
                                <div className="w-2 h-2 rounded-full bg-amber-500 animate-pulse" />
                                <p className="text-xs font-bold text-amber-600 dark:text-amber-400">
                                  {withdrawals.filter(w => w.status === 'pending').length} demande(s) en attente —&nbsp;
                                  <span className="tabular-nums">{formatGNF(pendingWithdrawalsTotal)}</span> à régler
                                </p>
                              </div>
                            )}
                            <div className="overflow-x-auto custom-scrollbar">
                              <table className="w-full text-left border-collapse">
                                <thead>
                                  <tr className="bg-slate-50 dark:bg-white/[0.02]">
                                    <th className="px-5 py-3.5 text-[10px] font-bold tracking-wider uppercase text-slate-500 dark:text-white/40 rounded-l-xl">Bénéficiaire</th>
                                    <th className="px-5 py-3.5 text-[10px] font-bold tracking-wider uppercase text-slate-500 dark:text-white/40">Montant Demandé</th>
                                    <th className="px-5 py-3.5 text-[10px] font-bold tracking-wider uppercase text-slate-500 dark:text-white/40">Date</th>
                                    <th className="px-5 py-3.5 text-[10px] font-bold tracking-wider uppercase text-slate-500 dark:text-white/40">Statut</th>
                                    <th className="px-5 py-3.5 text-[10px] font-bold tracking-wider uppercase text-slate-500 dark:text-white/40 text-right rounded-r-xl">Actions</th>
                                  </tr>
                                </thead>
                                <tbody className="divide-y divide-slate-100 dark:divide-white/5">
                                  {withdrawals.length > 0 ? withdrawals.map(w => (
                                    <tr key={w.id} className="group hover:bg-slate-50/80 dark:hover:bg-white/[0.025] transition-all">
                                      <td className="px-5 py-4">
                                        <p className="font-bold text-slate-800 dark:text-white text-sm group-hover:text-[#ff6600] transition-colors">
                                          {w.stores?.store_name || w.profiles?.full_name || 'Inconnu'}
                                        </p>
                                        <span className="text-[9px] text-slate-400 dark:text-white/30 uppercase tracking-wider font-semibold">
                                          {w.store_id ? 'Boutique Vendeur' : 'Livreur / Utilisateur'}
                                        </span>
                                      </td>
                                      <td className="px-5 py-4">
                                        <span className="text-sm font-black text-slate-800 dark:text-white tabular-nums">
                                          {formatGNF(Number(w.amount) || 0)}
                                        </span>
                                        
                                      </td>
                                      <td className="px-5 py-4">
                                        <span className="text-[11px] font-semibold text-slate-500 dark:text-white/30 tabular-nums">
                                          {w.created_at ? new Date(w.created_at).toLocaleDateString('fr-GN', { day: '2-digit', month: 'short', year: 'numeric' }) : '—'}
                                        </span>
                                      </td>
                                      <td className="px-5 py-4">
                                        <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-[10px] font-bold tracking-wider uppercase ${
                                          w.status === 'processed'
                                            ? 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400'
                                            : w.status === 'pending'
                                            ? 'bg-amber-500/10 text-amber-600 dark:text-amber-400'
                                            : 'bg-red-500/10 text-red-600 dark:text-red-400'
                                        }`}>
                                          <span className={`w-1.5 h-1.5 rounded-full ${
                                            w.status === 'processed' ? 'bg-emerald-500' : w.status === 'pending' ? 'bg-amber-500 animate-pulse' : 'bg-red-500'
                                          }`} />
                                          {w.status === 'processed' ? 'Settled' : w.status === 'pending' ? 'En Attente' : 'Rejeté'}
                                        </span>
                                      </td>
                                      <td className="px-5 py-4 text-right">
                                        {w.status === 'pending' && (
                                          <div className="flex justify-end gap-2">
                                            {/* H-6: Buttons disabled while this row's RPC is in-flight */}
                                            <button
                                              onClick={() => processWithdrawal(w.id, w.store_id, w.amount, 'processed')}
                                              disabled={processingWithdrawalId === w.id}
                                              className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-emerald-500 text-white rounded-lg text-[10px] font-bold uppercase hover:bg-emerald-600 active:scale-95 transition-all shadow-sm shadow-emerald-500/30 disabled:opacity-50 disabled:cursor-not-allowed"
                                            >
                                              {processingWithdrawalId === w.id
                                                ? <span className="w-3 h-3 border-2 border-white/40 border-t-white rounded-full animate-spin" />
                                                : <CheckCircle className="w-3 h-3" />
                                              }
                                              Approuver le virement
                                            </button>
                                            <button
                                              onClick={() => processWithdrawal(w.id, w.store_id, w.amount, 'rejected')}
                                              disabled={processingWithdrawalId === w.id}
                                              className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-red-500/10 text-red-500 dark:text-red-400 border border-red-500/20 rounded-lg text-[10px] font-bold uppercase hover:bg-red-500 hover:text-white active:scale-95 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
                                            >
                                              <XCircle className="w-3 h-3" />
                                              Rejeter
                                            </button>
                                          </div>
                                        )}
                                        {w.status !== 'pending' && (
                                          <span className="text-[10px] text-slate-300 dark:text-white/15 font-semibold uppercase tracking-wider">—</span>
                                        )}
                                      </td>
                                    </tr>
                                  )) : (
                                    <tr>
                                      <td colSpan={5} className="py-16 text-center">
                                        <div className="flex flex-col items-center gap-2">
                                          <Wallet className="w-8 h-8 text-slate-200 dark:text-white/10" />
                                          <p className="text-slate-400 dark:text-white/20 font-bold uppercase text-[11px] tracking-wider">Aucune demande de retrait</p>
                                        </div>
                                      </td>
                                    </tr>
                                  )}
                                </tbody>
                              </table>
                            </div>
                          </motion.div>
                        )}

                        {/* ── COMMISSIONS LOG ───────────────────────────────── */}
                        {financeSubTab === 'commissions' && (
                          <motion.div
                            key="commissions-table"
                            initial={{ opacity: 0, x: -8 }}
                            animate={{ opacity: 1, x: 0 }}
                            exit={{ opacity: 0, x: 8 }}
                            transition={{ duration: 0.2 }}
                          >
                            <div className="overflow-x-auto custom-scrollbar">
                              <table className="w-full text-left border-collapse min-w-full">
                                <thead>
                                  <tr className="bg-slate-50 dark:bg-white/[0.02]">
                                    <th className="px-5 py-3.5 text-[10px] font-bold tracking-wider uppercase text-slate-500 dark:text-white/40 rounded-l-xl">Source</th>
                                    <th className="px-5 py-3.5 text-[10px] font-bold tracking-wider uppercase text-slate-500 dark:text-white/40">Commission</th>
                                    <th className="px-5 py-3.5 text-[10px] font-bold tracking-wider uppercase text-slate-500 dark:text-white/40 rounded-r-xl">Date</th>
                                  </tr>
                                </thead>
                                <tbody className="divide-y divide-slate-100 dark:divide-white/5">
                                  {platformLogs.length > 0 ? platformLogs.map(log => (
                                    <tr key={log.id} className="group hover:bg-slate-50 dark:hover:bg-white/[0.02] transition-all">
                                      <td className="px-5 py-4">
                                        <p className="font-bold text-slate-800 dark:text-white text-[13px] group-hover:text-[#ff6600] transition-colors">Commande #{log.order_id?.substring(0, 8) || '—'}</p>
                                        <span className="text-[10px] text-slate-400 dark:text-white/30 uppercase tracking-wider font-semibold">{log.description || 'Commission de transaction'}</span>
                                      </td>
                                      <td className="px-5 py-4">
                                        <span className="text-sm font-black text-emerald-500 tabular-nums">
                                          + {formatGNF(Number(log.amount) || 0)}
                                        </span>
                                      </td>
                                      <td className="px-5 py-4">
                                        <span className="text-[11px] font-semibold text-slate-500 dark:text-white/30 tabular-nums">
                                          {log.created_at ? new Date(log.created_at).toLocaleString('fr-GN') : '—'}
                                        </span>
                                      </td>
                                    </tr>
                                  )) : (
                                    <tr>
                                      <td colSpan={3} className="py-16 text-center">
                                        <div className="flex flex-col items-center gap-2">
                                          <Coins className="w-8 h-8 text-slate-200 dark:text-white/10" />
                                          <p className="text-slate-400 dark:text-white/20 font-bold uppercase text-[11px] tracking-wider">Aucune commission enregistrée</p>
                                        </div>
                                      </td>
                                    </tr>
                                  )}
                                </tbody>
                              </table>
                            </div>
                          </motion.div>
                        )}

                        {/* ── COURIER EARNINGS LOG ──────────────────────────── */}
                        {financeSubTab === 'couriers' && (
                          <motion.div
                            key="couriers-earnings"
                            initial={{ opacity: 0, x: -8 }}
                            animate={{ opacity: 1, x: 0 }}
                            exit={{ opacity: 0, x: 8 }}
                            transition={{ duration: 0.2 }}
                          >
                            <div className="mb-4 flex items-center justify-between">
                              <p className="text-[10px] font-bold text-slate-400 dark:text-white/30 uppercase tracking-wider">
                                {courierEarningsList.length} coursier(s) actif(s) — gains issus des livraisons confirmées
                              </p>
                              <span className="text-[10px] font-black tabular-nums text-slate-600 dark:text-white/50">
                                Total versé : {formatGNF(courierEarningsList.reduce((s, c) => s + c.earnings, 0))}
                              </span>
                            </div>
                            {courierEarningsList.length > 0 ? (
                              <div className="space-y-3">
                                {courierEarningsList.map((courier, idx) => {
                                  const maxEarnings = courierEarningsList[0]?.earnings || 1;
                                  const pct = Math.round(((courier.earnings || 0) / (maxEarnings || 1)) * 100);
                                  return (
                                    <div
                                      key={courier.courierId}
                                      className="group flex items-center gap-4 p-4 rounded-2xl bg-slate-50 dark:bg-white/[0.02] border border-slate-100 dark:border-white/5 hover:border-[#ff6600]/20 transition-all"
                                    >
                                      {/* Rank */}
                                      <div className={`w-8 h-8 rounded-xl flex items-center justify-center text-[11px] font-black shrink-0 ${
                                        idx === 0 ? 'bg-amber-400/20 text-amber-500' :
                                        idx === 1 ? 'bg-slate-300/30 text-slate-500 dark:text-white/50' :
                                        idx === 2 ? 'bg-orange-400/15 text-orange-500' :
                                        'bg-slate-100 dark:bg-white/5 text-slate-400 dark:text-white/30'
                                      }`}>
                                        #{idx + 1}
                                      </div>
                                      {/* Avatar */}
                                      <div className="w-9 h-9 rounded-full bg-gradient-to-br from-[#ff6600]/20 to-orange-400/10 flex items-center justify-center shrink-0">
                                        <Bike className="w-4 h-4 text-[#ff6600]/70" />
                                      </div>
                                      {/* Info */}
                                      <div className="flex-1 min-w-0">
                                        <div className="flex items-center justify-between mb-1.5">
                                          <p className="text-sm font-bold text-slate-800 dark:text-white truncate group-hover:text-[#ff6600] transition-colors">{courier.name}</p>
                                          <div className="flex items-center gap-3 shrink-0 ml-2">
                                            <span className="text-[10px] text-slate-400 dark:text-white/30 font-semibold tabular-nums">
                                              {courier.deliveries} livraison{courier.deliveries > 1 ? 's' : ''}
                                            </span>
                                            <span className="text-sm font-black text-emerald-500 tabular-nums">
                                              {formatGNF(courier.earnings || 0)}
                                            </span>
                                          </div>
                                        </div>
                                        {/* Progress bar */}
                                        <div className="w-full h-1.5 bg-slate-200 dark:bg-white/5 rounded-full overflow-hidden">
                                          <motion.div
                                            initial={{ width: 0 }}
                                            animate={{ width: `${pct}%` }}
                                            transition={{ duration: 0.6, delay: idx * 0.05, ease: 'easeOut' }}
                                            className="h-full rounded-full bg-gradient-to-r from-[#ff6600] to-orange-400"
                                          />
                                        </div>
                                      </div>
                                    </div>
                                  );
                                })}
                              </div>
                            ) : (
                              <div className="py-16 flex flex-col items-center gap-3">
                                <Bike className="w-10 h-10 text-slate-200 dark:text-white/10" />
                                <p className="text-slate-400 dark:text-white/20 font-bold uppercase text-[11px] tracking-wider">Aucun gain de coursier enregistré</p>
                                <p className="text-slate-300 dark:text-white/15 text-xs text-center max-w-xs">Les gains apparaîtront lorsque des livraisons seront marquées comme confirmées.</p>
                              </div>
                            )}
                          </motion.div>
                        )}

                      </AnimatePresence>
                    </div>
                  </div>
                </motion.div>
                );
              })()}

            {activeTab === 'promotions' && (
              <motion.div 
                key="promotions"
                initial={{ opacity: 0, scale: 0.98, y: 15 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.98, y: -15 }}
                transition={{ duration: 0.3 }}
                className="space-y-8"
              >
                <div className="bg-white dark:bg-[#111622] border border-slate-200 dark:border-white/5 rounded-3xl overflow-hidden shadow-sm dark:shadow-md">
                  <div className="p-6 lg:p-8 border-b border-slate-200 dark:border-white/5 flex flex-wrap justify-between items-center gap-6">
                    <div>
                      <h2 className="text-xl font-bold text-slate-800 dark:text-white">Messages & Annonces</h2>
                      <p className="text-[10px] font-semibold text-slate-400 dark:text-slate-500 uppercase mt-0.5">Gestion des campagnes promotionnelles et des annonces</p>
                    </div>
                    <div className="flex bg-slate-100 dark:bg-black/45 p-1 rounded-xl border border-slate-200 dark:border-white/5">
                      <button 
                        onClick={() => setPromoSubTab('campaigns')}
                        className={`px-6 py-2 rounded-lg text-[10px] font-bold tracking-wider uppercase transition-all ${promoSubTab === 'campaigns' ? 'bg-[#ff6600] text-white shadow-sm' : 'text-slate-500 dark:text-white/40 hover:text-slate-800 dark:hover:text-white'}`}
                      >
                        Campagnes
                      </button>
                      <button 
                        onClick={() => setPromoSubTab('announcements')}
                        className={`px-6 py-2 rounded-lg text-[10px] font-bold tracking-wider uppercase transition-all ${promoSubTab === 'announcements' ? 'bg-[#ff6600] text-white shadow-sm' : 'text-slate-500 dark:text-white/40 hover:text-slate-800 dark:hover:text-white'}`}
                      >
                        Annonces
                      </button>
                    </div>
                  </div>

                  <AnimatePresence mode="wait">
                    {promoSubTab === 'campaigns' ? (
                      <motion.div 
                        key="campaigns-list"
                        initial={{ opacity: 0, x: -10 }}
                        animate={{ opacity: 1, x: 0 }}
                        exit={{ opacity: 0, x: 10 }}
                        className="p-0"
                      >
                        <div className="p-6 border-b border-slate-100 dark:border-white/5 flex justify-end">
                          <button 
                            onClick={createPromotion}
                            className="bg-[#ff6600] text-white px-5 py-2.5 rounded-xl text-xs font-bold uppercase hover:bg-orange-600 transition-all active:scale-95 shadow-sm"
                          >
                            + Nouvelle Campagne
                          </button>
                        </div>
                        <div className="overflow-x-auto custom-scrollbar">
                          <table className="w-full text-left border-collapse">
                            <thead>
                              <tr className="bg-slate-50 dark:bg-white/[0.02]">
                                <th className="px-6 py-4 text-[10px] font-bold tracking-wider uppercase text-slate-500 dark:text-white/40">Titre de la campagne</th>
                                <th className="px-6 py-4 text-[10px] font-bold tracking-wider uppercase text-slate-500 dark:text-white/40">Réduction</th>
                                <th className="px-6 py-4 text-[10px] font-bold tracking-wider uppercase text-slate-500 dark:text-white/40">Durée</th>
                                <th className="px-6 py-4 text-[10px] font-bold tracking-wider uppercase text-slate-500 dark:text-white/40 text-right">Actions</th>
                              </tr>
                            </thead>
                            <tbody className="divide-y divide-slate-100 dark:divide-white/5">
                              {promotions.length > 0 ? promotions.map(promo => (
                                <tr key={promo.id} className="group hover:bg-slate-50 dark:hover:bg-white/[0.02] transition-all">
                                  <td className="px-6 py-4">
                                     <p className="font-bold text-slate-800 dark:text-white text-sm group-hover:text-orange-500 transition-colors">{promo.title}</p>
                                     <p className="text-[10px] font-bold text-orange-500 uppercase tracking-wide mt-0.5">{promo.promo_type}</p>
                                  </td>
                                  <td className="px-6 py-4 text-lg font-bold text-slate-800 dark:text-white">
                                     -{promo.discount_value}<span className="text-xs font-semibold">%</span>
                                  </td>
                                  <td className="px-6 py-4">
                                     <div className="flex flex-col text-[11px] text-slate-500 dark:text-slate-400 font-medium">
                                        <span>Début : {new Date(promo.start_at).toLocaleDateString()}</span>
                                        <span className="opacity-60">Fin : {new Date(promo.end_at).toLocaleDateString()}</span>
                                     </div>
                                  </td>
                                  <td className="px-6 py-4 text-right">
                                     <button 
                                       onClick={() => deletePromotion(promo.id)}
                                       className="p-2 text-slate-400 hover:text-red-500 hover:bg-red-500/10 rounded-lg transition-all"
                                     >
                                        <Trash2 className="w-4 h-4" />
                                     </button>
                                  </td>
                                </tr>
                              )) : (
                                <tr>
                                  <td colSpan={4} className="py-16 text-center text-slate-400 dark:text-white/20 font-bold uppercase text-[11px] tracking-wider">Aucune promotion enregistrée</td>
                                </tr>
                              )}
                            </tbody>
                          </table>
                        </div>
                      </motion.div>
                    ) : (
                      <motion.div 
                        key="announcements-list"
                        initial={{ opacity: 0, x: 10 }}
                        animate={{ opacity: 1, x: 0 }}
                        exit={{ opacity: 0, x: -10 }}
                        className="p-6 lg:p-8 space-y-8"
                      >
                        {/* New Announcement Form */}
                        <div className="bg-slate-50 dark:bg-white/[0.02] border border-slate-100 dark:border-white/5 p-6 rounded-2xl space-y-6">
                          <h3 className="text-xs font-bold text-slate-700 dark:text-white/60 uppercase tracking-wider">Diffuser une annonce globale</h3>
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div className="space-y-2">
                              <label className="text-[10px] font-bold text-slate-400 dark:text-white/30 uppercase tracking-wider ml-1">Titre de l'annonce</label>
                              <input 
                                type="text"
                                value={newAnnouncement.title}
                                onChange={(e) => setNewAnnouncement({...newAnnouncement, title: e.target.value})}
                                placeholder="Maintenance planifiée, offre spéciale..."
                                className="w-full bg-white dark:bg-black/25 border border-slate-200 dark:border-white/10 rounded-xl px-4 py-3 text-slate-800 dark:text-white font-semibold text-sm outline-none focus:border-[#ff6600] focus:ring-1 focus:ring-[#ff6600] transition-all"
                              />
                            </div>
                            <div className="space-y-2">
                              <label className="text-[10px] font-bold text-slate-400 dark:text-white/30 uppercase tracking-wider ml-1">Cible de l'annonce</label>
                              <select
                                value={newAnnouncement.target}
                                onChange={(e) => setNewAnnouncement({...newAnnouncement, target: e.target.value})}
                                className="form-select"
                              >
                                <option value="all">Tous les utilisateurs</option>
                                <option value="vendors">Vendeurs uniquement</option>
                                <option value="couriers">Livreurs uniquement</option>
                                <option value="clients">Clients uniquement</option>
                              </select>
                            </div>
                          </div>
                          <div className="space-y-2">
                            <label className="text-[10px] font-bold text-slate-400 dark:text-white/30 uppercase tracking-wider ml-1">Contenu de l'annonce</label>
                            <textarea 
                              rows={3}
                              value={newAnnouncement.content}
                              onChange={(e) => setNewAnnouncement({...newAnnouncement, content: e.target.value})}
                              placeholder="Écrivez le message de votre annonce ici..."
                              className="w-full bg-white dark:bg-black/25 border border-slate-200 dark:border-white/10 rounded-xl px-4 py-3 text-slate-800 dark:text-white font-semibold text-sm outline-none focus:border-[#ff6600] focus:ring-1 focus:ring-[#ff6600] transition-all resize-none"
                            ></textarea>
                          </div>
                          <div className="flex justify-end">
                            <button 
                              onClick={publishAnnouncement}
                              className="bg-emerald-500 text-white px-6 py-3 rounded-xl text-xs font-bold uppercase hover:bg-emerald-600 transition-all active:scale-95 flex items-center gap-2 shadow-sm"
                            >
                              <Send className="w-4 h-4" /> Publier l'annonce
                            </button>
                          </div>
                        </div>

                        {/* Recent Announcements List */}
                        <div className="space-y-4">
                           <h3 className="text-xs font-bold text-slate-700 dark:text-white/60 uppercase tracking-wider">Historique des annonces</h3>
                           <div className="grid grid-cols-1 gap-4">
                             {announcements.length > 0 ? announcements.map(ann => (
                               <div key={ann.id} className="bg-white dark:bg-[#111622] border border-slate-200 dark:border-white/10 p-6 rounded-2xl group hover:border-[#ff6600]/30 transition-all relative overflow-hidden shadow-sm">
                                  <div className="absolute top-4 right-4 opacity-0 group-hover:opacity-100 transition-opacity">
                                    <button 
                                      onClick={() => deleteAnnouncement(ann.id)}
                                      className="p-1.5 text-slate-400 hover:text-red-500 transition-colors"
                                    >
                                      <Trash2 className="w-4 h-4" />
                                    </button>
                                  </div>
                                  <div className="flex justify-between items-start mb-3">
                                    <div>
                                      <h4 className="text-base font-bold text-slate-800 dark:text-white">{ann.title}</h4>
                                      <div className="flex items-center gap-3 mt-1 text-[10px] font-semibold text-slate-400">
                                        <span className="text-[#ff6600]">Cible : {ann.target_type}</span>
                                        <span>•</span>
                                        <span>{new Date(ann.created_at).toLocaleString()}</span>
                                      </div>
                                    </div>
                                    <Megaphone className="w-5 h-5 text-slate-300 dark:text-white/10 group-hover:text-orange-500/20 transition-colors" />
                                  </div>
                                  <p className="text-sm text-slate-600 dark:text-white/60 leading-relaxed font-medium">{ann.content}</p>
                               </div>
                             )) : (
                               <div className="py-16 text-center border border-dashed border-slate-200 dark:border-white/10 rounded-2xl">
                                 <p className="text-xs font-bold text-slate-400 dark:text-white/20 uppercase tracking-wider">Aucune annonce diffusée</p>
                               </div>
                             )}
                           </div>
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              </motion.div>
            )}

            {activeTab === 'couriers' && (
              <motion.div
                key="couriers"
                initial={{ opacity: 0, scale: 0.98, y: 15 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.98, y: -15 }}
                transition={{ duration: 0.3 }}
              >
                {/* ── Fleet Header ── */}
                <div className="flex flex-wrap items-start justify-between gap-4 mb-6">
                  <div>
                    <h2 className="text-xl font-bold text-slate-800 dark:text-white">Flotte de Livraison</h2>
                    <p className="text-[10px] font-semibold text-slate-400 dark:text-slate-500 uppercase mt-0.5">
                      {allCouriers.length} livreurs enregistrés
                    </p>
                  </div>
                  <div className="flex flex-wrap gap-2 text-[9px] font-bold uppercase tracking-wider">
                    <span className="px-2.5 py-1.5 bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/20 rounded-lg">
                      🟢 {allCouriers.filter(c => ['disponible','active'].includes(c.courier_status)).length} Disponibles
                    </span>
                    <span className="px-2.5 py-1.5 bg-blue-500/10 text-blue-600 dark:text-blue-400 border border-blue-500/20 rounded-lg">
                      🔵 {allCouriers.filter(c => ['en_course','on_delivery'].includes(c.courier_status)).length} En Course
                    </span>
                    <span className="px-2.5 py-1.5 bg-slate-200/70 text-slate-500 dark:bg-white/5 dark:text-white/30 border border-slate-300 dark:border-white/10 rounded-lg">
                      ⚫ {allCouriers.filter(c => ['hors_ligne','inactive'].includes(c.courier_status)).length} Hors Ligne
                    </span>
                    <span className="px-2.5 py-1.5 bg-red-500/10 text-red-600 dark:text-red-400 border border-red-500/20 rounded-lg">
                      🔴 {allCouriers.filter(c => ['suspendu','suspended'].includes(c.courier_status)).length} Suspendus
                    </span>
                  </div>
                </div>

                {/* ── Courier Cards Grid ── */}
                {allCouriers.length > 0 ? (
                  <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
                    {allCouriers.map(courier => {
                      // Normalize legacy status values to canonical
                      const rawStatus = courier.courier_status || 'hors_ligne';
                      type CourierStatus = 'disponible' | 'en_course' | 'hors_ligne' | 'suspendu';
                      const statusNorm: CourierStatus =
                        rawStatus === 'active'       ? 'disponible' :
                        rawStatus === 'on_delivery'  ? 'en_course'  :
                        rawStatus === 'inactive'     ? 'hors_ligne' :
                        rawStatus === 'suspended'    ? 'suspendu'   :
                        rawStatus as CourierStatus;

                      const statusCfg: Record<CourierStatus, { label: string; pill: string; dot: string; icon: React.ReactNode }> = {
                        disponible: { label: 'Disponible', dot: 'bg-emerald-500',  pill: 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border-emerald-500/20',  icon: <Wifi className="w-2.5 h-2.5" /> },
                        en_course:  { label: 'En Course',  dot: 'bg-blue-500',     pill: 'bg-blue-500/10 text-blue-600 dark:text-blue-400 border-blue-500/20',              icon: <Zap className="w-2.5 h-2.5" /> },
                        hors_ligne: { label: 'Hors Ligne', dot: 'bg-slate-400',    pill: 'bg-slate-100 text-slate-500 dark:bg-white/5 dark:text-white/30 border-slate-200 dark:border-white/10', icon: <WifiOff className="w-2.5 h-2.5" /> },
                        suspendu:   { label: 'Suspendu',   dot: 'bg-red-500',      pill: 'bg-red-500/10 text-red-600 dark:text-red-400 border-red-500/20',                  icon: <Ban className="w-2.5 h-2.5" /> },
                      };
                      const cfg = statusCfg[statusNorm];

                      const cashHeld      = Number(courier.cash_in_hand   || 0);
                      const walletBalance = Number(courier.courier_wallet  || 0);
                      const deliveries    = Number(courier.total_deliveries || 0);
                      const rating        = Number(courier.courier_rating   || 0);
                      const isBlocked     = courier.active_deliveries_count > 0 || cashHeld > 0;

                      const vehicleConfig: Record<string, { label: string; icon: React.ReactNode }> = {
                        moto:    { label: 'Moto',    icon: <Bike className="w-3 h-3" /> },
                        voiture: { label: 'Voiture', icon: <Car  className="w-3 h-3" /> },
                        velo:    { label: 'Vélo',    icon: <Bike className="w-3 h-3" /> },
                      };
                      const vehicle = courier.vehicle_type ? vehicleConfig[courier.vehicle_type] : null;

                      return (
                        <div
                          key={courier.id}
                          className={`bg-white dark:bg-[#111622] border rounded-3xl p-6 relative overflow-hidden shadow-sm dark:shadow-md group transition-all duration-300 ${
                            statusNorm === 'suspendu'  ? 'border-red-500/30 dark:border-red-500/20' :
                            statusNorm === 'en_course' ? 'border-blue-500/30 dark:border-blue-500/20' :
                            statusNorm === 'disponible'? 'border-slate-200 dark:border-white/5 hover:border-emerald-500/30' :
                            'border-slate-200 dark:border-white/5'
                          }`}
                        >
                          <div className="absolute inset-0 bg-gradient-to-br from-[#ff6600]/[0.02] to-transparent opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none" />

                          {/* ── Header: Avatar + Status ── */}
                          <div className="flex justify-between items-start mb-5 relative z-10">
                            <div className="relative">
                              <div className="w-14 h-14 bg-slate-100 dark:bg-white/5 rounded-2xl overflow-hidden border border-slate-200 dark:border-white/10">
                                <img
                                  src={courier.avatar_url || `https://api.dicebear.com/7.x/avataaars/svg?seed=${courier.id}`}
                                  alt=""
                                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                                />
                              </div>
                              <span className={`absolute -bottom-0.5 -right-0.5 w-3 h-3 rounded-full border-2 border-white dark:border-[#111622] ${cfg.dot}`} />
                            </div>

                            <div className="flex flex-col items-end gap-1.5">
                              <span className={`flex items-center gap-1 px-2.5 py-1 border rounded-lg text-[9px] font-bold tracking-wider uppercase ${cfg.pill}`}>
                                {cfg.icon}
                                {cfg.label}
                              </span>
                              {/* Vehicle + Zone badges */}
                              <div className="flex gap-1">
                                {vehicle ? (
                                  <span className="flex items-center gap-1 px-2 py-0.5 bg-slate-100 dark:bg-white/5 border border-slate-200 dark:border-white/10 rounded-md text-[8px] font-bold text-slate-500 dark:text-white/35 uppercase">
                                    {vehicle.icon}{vehicle.label}
                                  </span>
                                ) : (
                                  <span className="px-2 py-0.5 bg-slate-100/50 dark:bg-white/[0.03] border border-dashed border-slate-200 dark:border-white/10 rounded-md text-[8px] font-semibold text-slate-300 dark:text-white/15 uppercase">Véhicule ?</span>
                                )}
                                {courier.courier_zone ? (
                                  <span className="flex items-center gap-1 px-2 py-0.5 bg-orange-500/8 border border-orange-500/15 rounded-md text-[8px] font-bold text-orange-500 uppercase">
                                    <MapPin className="w-2.5 h-2.5" />{courier.courier_zone}
                                  </span>
                                ) : (
                                  <span className="px-2 py-0.5 bg-slate-100/50 dark:bg-white/[0.03] border border-dashed border-slate-200 dark:border-white/10 rounded-md text-[8px] font-semibold text-slate-300 dark:text-white/15 uppercase">Zone ?</span>
                                )}
                              </div>
                            </div>
                          </div>

                          {/* ── Name + Contact ── */}
                          <h3 className="text-base font-extrabold text-slate-800 dark:text-white uppercase mb-1 tracking-tight group-hover:text-orange-500 transition-colors relative z-10 truncate">
                            {courier.full_name || 'Livreur Sans Nom'}
                          </h3>
                          <div className="flex flex-wrap gap-1.5 mb-4 relative z-10">
                            {/* Phone — styled chip or CTA if missing */}
                            {courier.phone || courier.phone_number ? (
                              <a
                                href={`tel:${courier.phone || courier.phone_number}`}
                                className="flex items-center gap-1 px-2.5 py-1 bg-slate-50 dark:bg-white/5 border border-slate-200 dark:border-white/10 rounded-lg text-[9px] font-bold text-slate-600 dark:text-white/50 hover:border-emerald-500/40 hover:text-emerald-600 transition-all"
                              >
                                <PhoneCall className="w-2.5 h-2.5" />
                                {courier.phone || courier.phone_number}
                              </a>
                            ) : (
                              <span className="flex items-center gap-1 px-2.5 py-1 bg-slate-100/50 dark:bg-white/[0.03] border border-dashed border-slate-200 dark:border-white/10 rounded-lg text-[9px] font-semibold text-slate-300 dark:text-white/15">
                                <PhoneCall className="w-2.5 h-2.5" />Numéro manquant
                              </span>
                            )}
                            {courier.email && (
                              <span className="px-2.5 py-1 bg-slate-50 dark:bg-white/5 border border-slate-200 dark:border-white/10 rounded-lg text-[9px] font-medium text-slate-400 dark:text-white/25 truncate max-w-[140px]">
                                {courier.email}
                              </span>
                            )}
                          </div>

                          {/* ── Metrics Row ── */}
                          <div className="grid grid-cols-3 gap-2 mb-4 relative z-10">
                            {/* Wallet */}
                            <div className={`rounded-2xl p-3 border transition-all ${
                              walletBalance > 0
                                ? 'bg-orange-500/5 dark:bg-orange-500/8 border-orange-500/20'
                                : 'bg-slate-50 dark:bg-white/[0.03] border-slate-200 dark:border-white/5'
                            }`}>
                              <div className="flex items-center gap-1 mb-1">
                                <Wallet className={`w-2.5 h-2.5 ${walletBalance > 0 ? 'text-orange-500' : 'text-slate-300 dark:text-white/20'}`} />
                                <span className="text-[7px] font-bold uppercase tracking-wider text-slate-400 dark:text-white/20">Wallet</span>
                              </div>
                              <span className={`text-sm font-black leading-none ${ walletBalance > 0 ? 'text-orange-500' : 'text-slate-400 dark:text-white/30' }`}>
                                {formatGNF(walletBalance)}
                              </span>
                            </div>

                            {/* Cash in Hand */}
                            <div className={`rounded-2xl p-3 border transition-all ${
                              cashHeld > 50000 ? 'bg-red-500/8 border-red-500/25' :
                              cashHeld > 0     ? 'bg-amber-500/8 border-amber-500/20' :
                              'bg-slate-50 dark:bg-white/[0.03] border-slate-200 dark:border-white/5'
                            }`}>
                              <div className="flex items-center gap-1 mb-1">
                                <Package className={`w-2.5 h-2.5 ${ cashHeld > 50000 ? 'text-red-500' : cashHeld > 0 ? 'text-amber-500' : 'text-slate-300 dark:text-white/20' }`} />
                                <span className="text-[7px] font-bold uppercase tracking-wider text-slate-400 dark:text-white/20">Cash</span>
                              </div>
                              <span className={`text-sm font-black leading-none ${ cashHeld > 50000 ? 'text-red-500' : cashHeld > 0 ? 'text-amber-500' : 'text-slate-400 dark:text-white/30' }`}>
                                {formatGNF(cashHeld)}
                              </span>
                            </div>

                            {/* Deliveries + Rating */}
                            <div className="rounded-2xl p-3 border bg-slate-50 dark:bg-white/[0.03] border-slate-200 dark:border-white/5 flex flex-col justify-between">
                              <div className="flex items-center gap-1 mb-1">
                                <Package className="w-2.5 h-2.5 text-slate-300 dark:text-white/20" />
                                <span className="text-[7px] font-bold uppercase tracking-wider text-slate-400 dark:text-white/20">Livr.</span>
                              </div>
                              <span className="text-sm font-black text-slate-600 dark:text-white/50 leading-none">{deliveries}</span>
                            </div>
                          </div>

                          {/* ── Rating bar ── */}
                          <div className="flex items-center gap-2 mb-4 relative z-10">
                            <div className="flex gap-0.5">
                              {[1,2,3,4,5].map(i => (
                                <Star
                                  key={i}
                                  className={`w-3 h-3 ${ i <= Math.round(rating) ? 'text-amber-400 fill-amber-400' : 'text-slate-200 dark:text-white/10' }`}
                                />
                              ))}
                            </div>
                            <span className="text-[10px] font-bold text-slate-500 dark:text-white/30">
                              {rating > 0 ? rating.toFixed(1) : 'Pas encore noté'}
                            </span>
                          </div>

                          {/* ── Status Lifecycle Controls ── */}
                          <div className="relative z-10 space-y-2">
                            {/* Row 1: 4 lifecycle buttons */}
                            <div className="grid grid-cols-4 gap-1">
                              {([
                                { s: 'disponible' as const, label: 'Dispo',   icon: <Wifi className="w-2.5 h-2.5" />,    active: 'bg-emerald-500 text-white border-emerald-500 shadow-sm shadow-emerald-500/30', inactive: 'hover:bg-emerald-500/10 hover:text-emerald-600 hover:border-emerald-500/30' },
                                { s: 'en_course'  as const, label: 'Course',  icon: <Zap className="w-2.5 h-2.5" />,    active: 'bg-blue-500 text-white border-blue-500 shadow-sm shadow-blue-500/30',         inactive: 'hover:bg-blue-500/10 hover:text-blue-600 hover:border-blue-500/30' },
                                { s: 'hors_ligne' as const, label: 'Hors Lgn',icon: <WifiOff className="w-2.5 h-2.5" />,active: 'bg-slate-500 text-white border-slate-500',                                       inactive: 'hover:bg-slate-500/10 hover:text-slate-600 hover:border-slate-500/30' },
                                { s: 'suspendu'   as const, label: 'Suspend', icon: <Ban className="w-2.5 h-2.5" />,    active: 'bg-red-500 text-white border-red-500 shadow-sm shadow-red-500/30',             inactive: 'hover:bg-red-500/10 hover:text-red-600 hover:border-red-500/30' },
                              ] as const).map(({ s, label, icon, active, inactive }) => {
                                const isCurrent = statusNorm === s;
                                const guardBlocked = (s === 'hors_ligne' || s === 'suspendu') && isBlocked;
                                const tooltipMsg = isBlocked
                                  ? courier.active_deliveries_count > 0
                                    ? 'Livreur en course active'
                                    : `Cash non remis : ${formatGNF(cashHeld)}`
                                  : undefined;
                                return (
                                  <button
                                    key={s}
                                    onClick={() => !guardBlocked && !isCurrent && setCourierStatus(courier.id, s, courier)}
                                    disabled={isCurrent || guardBlocked}
                                    title={tooltipMsg}
                                    className={`flex flex-col items-center justify-center gap-0.5 py-2 rounded-xl text-[8px] font-bold tracking-wider uppercase border transition-all ${
                                      isCurrent
                                        ? active
                                        : guardBlocked
                                          ? 'bg-slate-50 dark:bg-white/[0.02] text-slate-300 dark:text-white/15 border-slate-200 dark:border-white/5 cursor-not-allowed'
                                          : `bg-slate-50 dark:bg-white/5 text-slate-500 dark:text-white/40 border-slate-200 dark:border-white/10 active:scale-95 ${inactive}`
                                    }`}
                                  >
                                    {icon}
                                    {label}
                                  </button>
                                );
                              })}
                            </div>

                            {/* Guard notice */}
                            {isBlocked && (
                              <div className="flex items-center gap-1.5 px-3 py-2 bg-amber-500/8 border border-amber-500/20 rounded-xl">
                                <AlertTriangle className="w-3 h-3 text-amber-500 flex-shrink-0" />
                                <span className="text-[8px] font-semibold text-amber-600 dark:text-amber-400">
                                  {courier.active_deliveries_count > 0
                                    ? 'En course — Hors ligne & suspension bloqués'
                                    : `Cash collecté (${formatGNF(cashHeld)}) — Remboursement requis`
                                  }
                                </span>
                              </div>
                            )}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                ) : (
                  <div className="bg-white dark:bg-[#111622] border border-slate-200 dark:border-white/5 rounded-3xl py-20 text-center">
                    <div className="flex flex-col items-center gap-4">
                      <div className="w-14 h-14 bg-slate-100 dark:bg-white/5 rounded-2xl flex items-center justify-center border border-slate-200 dark:border-white/10 text-slate-300 dark:text-white/10">
                        <Bike className="w-7 h-7" />
                      </div>
                      <div>
                        <p className="text-xs font-bold tracking-wider text-slate-400 dark:text-white/40 uppercase">Aucun livreur enregistré</p>
                        <p className="text-[10px] font-semibold tracking-wider text-slate-300 dark:text-slate-600 uppercase mt-1">Les profils de livraison s'afficheront ici</p>
                      </div>
                    </div>
                  </div>
                )}
              </motion.div>
            )}

            {activeTab === 'users' && (
              <motion.div 
                key="users"
                initial={{ opacity: 0, scale: 0.98, y: 15 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.98, y: -15 }}
                transition={{ duration: 0.3 }}
                className="bg-white dark:bg-[#111622] border border-slate-200 dark:border-white/5 rounded-3xl overflow-hidden shadow-sm dark:shadow-md"
              >
                <div className="p-6 lg:p-8 border-b border-slate-200 dark:border-white/5 flex flex-col xl:flex-row xl:items-center justify-between gap-6">
                  <div>
                    <h2 className="text-xl font-bold text-slate-800 dark:text-white">Registre Utilisateurs</h2>
                    <div className="flex items-center gap-4 mt-1.5">
                      <div className="flex items-center gap-1.5 px-2.5 py-1 bg-orange-500/10 rounded-lg border border-orange-500/20">
                         <Users className="w-3.5 h-3.5 text-orange-500" />
                         <span className="text-[10px] font-bold text-orange-500 tracking-wider uppercase">Inscrits : {allUsers.length}</span>
                      </div>
                      <div className="text-[10px] font-semibold text-slate-400 dark:text-white/30 uppercase tracking-wider">Base de données active</div>
                    </div>
                  </div>
                  
                  <div className="grid w-full xl:w-auto grid-cols-1 sm:grid-cols-3 gap-2">
                    <div className="relative group sm:col-span-3 xl:w-[380px]">
                      <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500 dark:text-white/40 group-focus-within:text-[#ff6600] transition-colors" />
                      <input
                        type="text"
                        placeholder="Nom, email, téléphone ou ID…"
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        className="bg-slate-50 dark:bg-black/25 border border-slate-200 dark:border-white/10 rounded-xl pl-10 pr-4 py-2.5 w-full text-xs font-semibold text-slate-800 dark:text-white placeholder:text-slate-400 dark:placeholder:text-white/35 focus:border-[#ff6600] focus:ring-1 focus:ring-[#ff6600] transition-all outline-none"
                      />
                    </div>
                    <select value={userRoleFilter} onChange={(e) => setUserRoleFilter(e.target.value as typeof userRoleFilter)} className="bg-slate-50 dark:bg-black/25 border border-slate-200 dark:border-white/10 rounded-xl px-3 py-2 text-[10px] font-bold text-slate-600 dark:text-white/70 outline-none">
                      <option value="all">Tous les rôles</option><option value="client">Clients</option><option value="vendor">Vendeurs</option><option value="courier">Livreurs</option><option value="admin">Admins</option>
                    </select>
                    <select value={userStatusFilter} onChange={(e) => setUserStatusFilter(e.target.value as typeof userStatusFilter)} className="bg-slate-50 dark:bg-black/25 border border-slate-200 dark:border-white/10 rounded-xl px-3 py-2 text-[10px] font-bold text-slate-600 dark:text-white/70 outline-none">
                      <option value="all">Tous les statuts</option><option value="active">Actifs</option><option value="suspended">Suspendus</option><option value="missing_phone">Sans téléphone</option>
                    </select>
                    <div className="hidden sm:flex items-center justify-center rounded-xl bg-slate-100 dark:bg-white/5 text-[10px] font-bold text-slate-500 dark:text-white/50">{filteredUsers.length} résultat{filteredUsers.length > 1 ? 's' : ''}</div>
                  </div>
                </div>

                <div className="overflow-x-auto custom-scrollbar">
                  <table className="w-full text-left border-collapse">
                    <thead>
                      <tr className="bg-slate-50 dark:bg-white/[0.02]">
                        <th className="px-6 py-4 text-[10px] font-bold tracking-wider uppercase text-slate-500 dark:text-white/40">Utilisateur</th>
                        <th className="px-6 py-4 text-[10px] font-bold tracking-wider uppercase text-slate-600 dark:text-white/50">Rôle & statut</th>
                        <th className="px-6 py-4 text-[10px] font-bold tracking-wider uppercase text-slate-600 dark:text-white/50">Contact</th>
                        <th className="px-6 py-4 text-[10px] font-bold tracking-wider uppercase text-slate-500 dark:text-white/40">Date d'Inscription</th>
                        <th className="px-6 py-4 text-[10px] font-bold tracking-wider uppercase text-slate-500 dark:text-white/40 text-right">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 dark:divide-white/5">
                      {filteredUsers.map((u) => {
                        // ── Graceful name degradation ──
                        const displayName = u.full_name || u.phone_number || u.email || `User-${u.id.substring(0, 6)}`;
                        const avatarLetter = (u.full_name?.[0] || u.phone_number?.[0] || u.email?.[0] || 'U').toUpperCase();

                        // ── Account status ──
                        const isSuspended = u.account_status === 'suspended';

                        // ── Verification state ──
                        const phoneVerified = Boolean(u.phone_verified);
                        const hasPhone = Boolean(u.phone_number);

                        return (
                        <tr
                          key={u.id}
                          className={`group hover:bg-slate-50 dark:hover:bg-white/[0.02] transition-all ${
                            isSuspended ? 'bg-red-500/[0.02] dark:bg-red-500/[0.03]' : ''
                          }`}
                        >
                          {/* ── User Identity Cell ── */}
                          <td className="px-6 py-4">
                            <div className="flex items-center gap-3">
                              <div className="relative">
                                <div className={`w-9 h-9 rounded-lg border flex items-center justify-center font-bold text-sm shadow-sm ${
                                  isSuspended
                                    ? 'bg-red-500/10 dark:bg-red-500/15 border-red-500/20 text-red-500'
                                    : 'bg-orange-500/10 dark:bg-orange-500/20 border-orange-500/20 text-[#ff6600]'
                                }`}>
                                  {avatarLetter}
                                </div>
                                {/* Online / admin / suspended status dot */}
                                <div className={`absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 rounded-full border-2 border-white dark:border-[#111622] ${
                                  isSuspended ? 'bg-red-500' : u.is_admin ? 'bg-purple-500' : 'bg-emerald-500'
                                }`} />
                              </div>

                              <div>
                                <div className="flex items-center gap-2 flex-wrap">
                                  <p className={`font-bold text-sm transition-colors ${
                                    isSuspended
                                      ? 'text-red-500/80 dark:text-red-400/80'
                                      : 'text-slate-800 dark:text-white group-hover:text-orange-500'
                                  }`}>
                                    {displayName}
                                    {isSuspended && (
                                      <span className="ml-1.5 text-[9px] font-bold tracking-wider uppercase px-1.5 py-0.5 bg-red-500/10 text-red-500 border border-red-500/20 rounded-md align-middle">
                                        Suspendu
                                      </span>
                                    )}
                                  </p>
                                </div>

                                {/* Email sub-row */}
                                {u.email && (
                                  <p className="text-[10px] font-semibold text-slate-400 dark:text-white/20 tracking-wider uppercase mt-0.5">{u.email}</p>
                                )}
                                <button
                                  onClick={() => { navigator.clipboard?.writeText(u.id); showToast('Identifiant copié.', 'success'); }}
                                  title="Copier l'identifiant complet"
                                  className="mt-1 text-[10px] font-mono font-medium text-slate-500 dark:text-white/40 hover:text-orange-500 transition-colors"
                                >
                                  ID {u.id.slice(0, 8)}… · copier
                                </button>

                                {/* ── Verification pill ── */}
                                <div className="flex items-center gap-1.5 mt-1.5 flex-wrap">
                                  {hasPhone ? (
                                    <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[9px] font-bold tracking-wider uppercase border ${
                                      phoneVerified
                                        ? 'bg-emerald-500/8 text-emerald-600 dark:text-emerald-400 border-emerald-500/20'
                                        : 'bg-slate-100 dark:bg-white/5 text-slate-400 dark:text-white/25 border-slate-200 dark:border-white/10'
                                    }`}>
                                      <Phone className="w-2.5 h-2.5" />
                                      {phoneVerified ? '🟢 Tél. Vérifié' : '⚪ Non Vérifié'}
                                    </span>
                                  ) : (
                                    <span className="inline-flex items-center gap-1 px-2 py-0.5 bg-slate-100/50 dark:bg-white/[0.03] border border-dashed border-slate-200 dark:border-white/10 rounded-md text-[9px] font-semibold text-slate-300 dark:text-white/15 uppercase">
                                      <Phone className="w-2.5 h-2.5" />⚪ Sans téléphone
                                    </span>
                                  )}
                                </div>
                              </div>
                            </div>
                          </td>

                          {/* ── Role & account status ── */}
                          <td className="px-6 py-4">
                            {(() => {
                              const role = u.is_admin ? 'Administrateur' : u.profile_type === 'vendor' ? 'Vendeur' : u.profile_type === 'courier' ? 'Livreur' : 'Client';
                              const roleClass = u.is_admin ? 'bg-purple-500/10 text-purple-600 dark:text-purple-300 border-purple-500/25' : u.profile_type === 'vendor' ? 'bg-orange-500/10 text-orange-600 dark:text-orange-300 border-orange-500/25' : u.profile_type === 'courier' ? 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-300 border-emerald-500/25' : 'bg-slate-100 dark:bg-white/5 text-slate-600 dark:text-white/65 border-slate-200 dark:border-white/10';
                              return <div className="flex flex-col items-start gap-2"><span className={`px-2.5 py-1 border rounded-lg text-[9px] font-bold tracking-wider uppercase ${roleClass}`}>{role}</span><span className={`inline-flex items-center gap-1.5 text-[10px] font-semibold ${isSuspended ? 'text-red-500' : 'text-emerald-600 dark:text-emerald-400'}`}><span className={`w-1.5 h-1.5 rounded-full ${isSuspended ? 'bg-red-500' : 'bg-emerald-500'}`} />{isSuspended ? 'Suspendu' : 'Actif'}</span></div>;
                            })()}
                          </td>

                          <td className="px-6 py-4">
                            <p className="text-xs font-semibold text-slate-700 dark:text-white/75">{u.phone_number || '—'}</p>
                            <p className="text-[10px] font-medium text-slate-500 dark:text-white/45 mt-1">{u.email || 'Aucun email'}</p>
                          </td>

                          {/* ── Date ── */}
                          <td className="px-6 py-4 text-xs font-semibold text-slate-500 dark:text-white/40">
                             {new Date(u.created_at).toLocaleDateString()}
                          </td>

                          {/* ── Consolidated actions in detail drawer ── */}
                          <td className="px-6 py-4 text-right">
                             <div className="flex justify-end items-center gap-2">
                               <button onClick={() => setSelectedUser(u)} className="inline-flex items-center gap-1.5 px-3 py-1.5 border border-slate-200 dark:border-white/10 rounded-lg text-[10px] font-bold tracking-wider uppercase text-slate-600 dark:text-white/70 hover:border-orange-500/40 hover:text-orange-500 transition-all"><Eye className="w-3.5 h-3.5" />Voir</button>
                             </div>
                          </td>
                        </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>

                <AnimatePresence>
                  {selectedUser && (() => {
                    const u = selectedUser;
                    const isSuspended = u.account_status === 'suspended';
                    const displayName = u.full_name || u.phone_number || u.email || `Utilisateur`;
                    const avatarLetter = (displayName[0] || 'U').toUpperCase();
                    const role = u.is_admin ? 'Administrateur' : u.profile_type === 'vendor' ? 'Vendeur' : u.profile_type === 'courier' ? 'Livreur' : 'Client';
                    const roleColor = u.is_admin
                      ? { bg: 'bg-purple-500/15', text: 'text-purple-400', border: 'border-purple-500/25', dot: 'bg-purple-500' }
                      : u.profile_type === 'vendor'
                      ? { bg: 'bg-orange-500/15', text: 'text-orange-400', border: 'border-orange-500/25', dot: 'bg-orange-500' }
                      : u.profile_type === 'courier'
                      ? { bg: 'bg-emerald-500/15', text: 'text-emerald-400', border: 'border-emerald-500/25', dot: 'bg-emerald-500' }
                      : { bg: 'bg-slate-500/10', text: 'text-slate-400 dark:text-white/50', border: 'border-slate-200 dark:border-white/10', dot: 'bg-slate-400' };
                    const avatarColor = u.is_admin ? 'bg-purple-500/20 text-purple-400' : u.profile_type === 'vendor' ? 'bg-orange-500/20 text-orange-400' : u.profile_type === 'courier' ? 'bg-emerald-500/20 text-emerald-400' : 'bg-slate-100 dark:bg-white/10 text-slate-500 dark:text-white/60';
                    const statusDotColor = isSuspended ? 'bg-red-500' : u.is_admin ? 'bg-purple-500' : 'bg-emerald-500';

                    // Derive order stats for this user from already-loaded data
                    const userOrders = allOrdersList.filter((o: any) => o.user_id === u.id);
                    const completedOrders = userOrders.filter((o: any) => o.status === 'delivered');
                    const totalSpend = userOrders
                      .filter((o: any) => ['paid','accepted','preparing','in_transit','delivered'].includes(o.status))
                      .reduce((sum: number, o: any) => sum + (Number(o.total_amount) || 0), 0);
                    const recentOrders = [...userOrders]
                      .sort((a: any, b: any) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime())
                      .slice(0, 3);

                    const orderStatusLabel: Record<string, { label: string; cls: string }> = {
                      delivered:  { label: 'Livré',      cls: 'bg-emerald-500/10 text-emerald-500 border-emerald-500/20' },
                      paid:       { label: 'Payé',       cls: 'bg-blue-500/10 text-blue-400 border-blue-500/20' },
                      in_transit: { label: 'En route',   cls: 'bg-amber-500/10 text-amber-400 border-amber-500/20' },
                      preparing:  { label: 'Préparation',cls: 'bg-amber-500/10 text-amber-400 border-amber-500/20' },
                      accepted:   { label: 'Accepté',    cls: 'bg-blue-500/10 text-blue-400 border-blue-500/20' },
                      pending:    { label: 'En attente', cls: 'bg-slate-500/10 text-slate-400 border-slate-500/20' },
                      cancelled:  { label: 'Annulé',     cls: 'bg-red-500/10 text-red-400 border-red-500/20' },
                    };

                    const isSelf = u.id === user?.id;

                    // How many days since the user joined
                    const daysSince = u.created_at
                      ? Math.floor((Date.now() - new Date(u.created_at).getTime()) / 86400000)
                      : null;
                    const memberSince = daysSince === null ? '—' : daysSince === 0 ? "Aujourd'hui" : daysSince === 1 ? 'Hier' : `Il y a ${daysSince}j`;

                    return <>
                      {/* Backdrop */}
                      <motion.div
                        initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
                        onClick={() => setSelectedUser(null)}
                        className="fixed inset-0 z-[90] bg-slate-950/60 backdrop-blur-sm"
                      />

                      {/* Panel */}
                      <motion.aside
                        initial={{ x: '100%' }} animate={{ x: 0 }} exit={{ x: '100%' }}
                        transition={{ type: 'spring', damping: 30, stiffness: 300 }}
                        className="fixed z-[100] inset-y-0 right-0 w-full max-w-lg bg-white dark:bg-[#0f1320] border-l border-slate-200 dark:border-white/8 shadow-2xl overflow-y-auto flex flex-col"
                      >
                        {/* ── Header ── */}
                        <div className="sticky top-0 z-10 bg-white/90 dark:bg-[#0f1320]/90 backdrop-blur-md border-b border-slate-100 dark:border-white/8 px-6 py-4 flex items-center justify-between gap-3">
                          <button
                            onClick={() => setSelectedUser(null)}
                            className="flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-wider text-slate-500 hover:text-slate-700 dark:hover:text-white/70 transition-colors"
                          >
                            <X className="w-3.5 h-3.5" />
                            Fermer
                          </button>
                          <span className="text-[10px] font-bold tracking-[0.18em] uppercase text-orange-500">Profil utilisateur</span>
                          {/* copy UUID */}
                          <button
                            onClick={() => { navigator.clipboard?.writeText(u.id); showToast('ID copié.', 'success'); }}
                            title="Copier l'identifiant système"
                            className="flex items-center gap-1 text-[10px] font-mono text-slate-400 dark:text-white/25 hover:text-orange-500 transition-colors"
                          >
                            <Hash className="w-3 h-3" />
                            {u.id.slice(0, 8)}…
                          </button>
                        </div>

                        <div className="flex-1 px-6 py-6 space-y-6">

                          {/* ── Identity Hero ── */}
                          <div className="flex items-start gap-4">
                            {/* Avatar */}
                            <div className="relative shrink-0">
                              <div className={`w-16 h-16 rounded-2xl flex items-center justify-center text-2xl font-black ${avatarColor}`}>
                                {avatarLetter}
                              </div>
                              <div className={`absolute -bottom-1 -right-1 w-4 h-4 rounded-full border-2 border-white dark:border-[#0f1320] ${statusDotColor}`} />
                            </div>

                            {/* Name + role + status */}
                            <div className="flex-1 min-w-0">
                              <h3 className="text-xl font-black text-slate-900 dark:text-white leading-tight truncate">{displayName}</h3>
                              <div className="flex items-center gap-2 mt-1.5 flex-wrap">
                                <span className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-lg text-[10px] font-bold tracking-wider uppercase border ${roleColor.bg} ${roleColor.text} ${roleColor.border}`}>
                                  <span className={`w-1.5 h-1.5 rounded-full ${roleColor.dot}`} />
                                  {role}
                                </span>
                                <span className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-lg text-[10px] font-bold tracking-wider uppercase border ${
                                  isSuspended
                                    ? 'bg-red-500/10 text-red-400 border-red-500/20'
                                    : 'bg-emerald-500/10 text-emerald-500 border-emerald-500/20'
                                }`}>
                                  <span className={`w-1.5 h-1.5 rounded-full ${isSuspended ? 'bg-red-500' : 'bg-emerald-500'}`} />
                                  {isSuspended ? 'Suspendu' : 'Actif'}
                                </span>
                              </div>
                            </div>
                          </div>

                          {/* ── Activity Stats Row ── */}
                          <div className="grid grid-cols-3 gap-3">
                            {[
                              { label: 'Commandes', value: userOrders.length, icon: ShoppingBag, color: 'text-blue-500', bg: 'bg-blue-500/8' },
                              { label: 'Livrées', value: completedOrders.length, icon: CheckCircle, color: 'text-emerald-500', bg: 'bg-emerald-500/8' },
                              { label: 'Dépenses', value: totalSpend > 0 ? formatGNF(totalSpend) : '—', icon: Wallet, color: 'text-orange-500', bg: 'bg-orange-500/8', small: true },
                            ].map(({ label, value, icon: Icon, color, bg, small }) => (
                              <div key={label} className={`rounded-2xl ${bg} border border-white/5 p-3.5 flex flex-col gap-1.5`}>
                                <Icon className={`w-4 h-4 ${color}`} />
                                <p className={`font-black ${small ? 'text-sm' : 'text-xl'} text-slate-900 dark:text-white leading-none`}>{value}</p>
                                <p className="text-[10px] font-semibold uppercase tracking-wider text-slate-500 dark:text-white/35">{label}</p>
                              </div>
                            ))}
                          </div>

                          {/* ── Identity & Contact Card ── */}
                          <div className="rounded-2xl bg-slate-50 dark:bg-white/[0.03] border border-slate-200 dark:border-white/8 overflow-hidden">

                            {/* Email row */}
                            <div className="flex items-center gap-3 px-4 py-3.5 border-b border-slate-100 dark:border-white/8">
                              <div className="w-8 h-8 rounded-xl bg-blue-500/10 flex items-center justify-center shrink-0">
                                <Mail className="w-4 h-4 text-blue-500" />
                              </div>
                              <div className="flex-1 min-w-0">
                                <p className="text-[10px] font-bold uppercase tracking-widest text-slate-400 dark:text-white/30 mb-0.5">Email</p>
                                {u.email ? (
                                  <div className="flex items-center gap-2 flex-wrap">
                                    <span className="text-sm font-semibold text-slate-800 dark:text-white break-all leading-tight">{u.email}</span>
                                    {u.email_confirmed ? (
                                      <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded-md text-[9px] font-bold uppercase tracking-wider bg-emerald-500/10 text-emerald-500 border border-emerald-500/20">
                                        <span className="w-1 h-1 rounded-full bg-emerald-500" />
                                        Vérifié
                                      </span>
                                    ) : (
                                      <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded-md text-[9px] font-bold uppercase tracking-wider bg-amber-500/10 text-amber-500 border border-amber-500/20">
                                        <span className="w-1 h-1 rounded-full bg-amber-500" />
                                        Non vérifié
                                      </span>
                                    )}
                                  </div>
                                ) : (
                                  <span className="text-sm text-slate-400 dark:text-white/30 italic">Aucun email</span>
                                )}
                              </div>
                              {u.email && (
                                <button
                                  onClick={() => { navigator.clipboard?.writeText(u.email); showToast('Email copié !', 'success'); }}
                                  title="Copier l'email"
                                  className="shrink-0 p-1.5 rounded-lg hover:bg-slate-200 dark:hover:bg-white/10 text-slate-400 hover:text-blue-500 transition-colors"
                                >
                                  <Copy className="w-3.5 h-3.5" />
                                </button>
                              )}
                            </div>

                            {/* Phone row */}
                            <div className="flex items-center gap-3 px-4 py-3.5 border-b border-slate-100 dark:border-white/8">
                              <div className="w-8 h-8 rounded-xl bg-emerald-500/10 flex items-center justify-center shrink-0">
                                <Phone className="w-4 h-4 text-emerald-500" />
                              </div>
                              <div className="flex-1 min-w-0">
                                <p className="text-[10px] font-bold uppercase tracking-widest text-slate-400 dark:text-white/30 mb-0.5">Téléphone</p>
                                {u.phone_number ? (
                                  <span className="text-sm font-semibold text-slate-800 dark:text-white">{u.phone_number}</span>
                                ) : (
                                  <span className="text-sm text-slate-400 dark:text-white/30 italic">Non renseigné</span>
                                )}
                              </div>
                              {u.phone_number && (
                                <button
                                  onClick={() => { navigator.clipboard?.writeText(u.phone_number); showToast('Téléphone copié !', 'success'); }}
                                  title="Copier le téléphone"
                                  className="shrink-0 p-1.5 rounded-lg hover:bg-slate-200 dark:hover:bg-white/10 text-slate-400 hover:text-emerald-500 transition-colors"
                                >
                                  <Copy className="w-3.5 h-3.5" />
                                </button>
                              )}
                            </div>

                            {/* Wallet balance row */}
                            <div className="flex items-center gap-3 px-4 py-3.5 border-b border-slate-100 dark:border-white/8">
                              <div className="w-8 h-8 rounded-xl bg-orange-500/10 flex items-center justify-center shrink-0">
                                <Wallet className="w-4 h-4 text-orange-500" />
                              </div>
                              <div className="flex-1 min-w-0">
                                <p className="text-[10px] font-bold uppercase tracking-widest text-slate-400 dark:text-white/30 mb-0.5">Solde portefeuille</p>
                                <span className={`text-sm font-black ${ (u.wallet_balance || 0) > 0 ? 'text-orange-500' : 'text-slate-400 dark:text-white/30' }`}>
                                  {formatGNF(Number(u.wallet_balance) || 0)}
                                </span>
                              </div>
                            </div>

                            {/* Last seen row */}
                            <div className="flex items-center gap-3 px-4 py-3.5 border-b border-slate-100 dark:border-white/8">
                              <div className="w-8 h-8 rounded-xl bg-slate-500/10 flex items-center justify-center shrink-0">
                                <Clock className="w-4 h-4 text-slate-400" />
                              </div>
                              <div className="flex-1 min-w-0">
                                <p className="text-[10px] font-bold uppercase tracking-widest text-slate-400 dark:text-white/30 mb-0.5">Dernière connexion</p>
                                {u.last_sign_in_at ? (
                                  <span className="text-sm font-semibold text-slate-700 dark:text-white/80">
                                    {new Date(u.last_sign_in_at).toLocaleDateString('fr-FR', { day: 'numeric', month: 'short', year: 'numeric' })}
                                    <span className="ml-1.5 text-slate-400 dark:text-white/30 font-normal">
                                      à {new Date(u.last_sign_in_at).toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' })}
                                    </span>
                                  </span>
                                ) : (
                                  <span className="text-sm text-slate-400 dark:text-white/30 italic">Jamais connecté</span>
                                )}
                              </div>
                            </div>

                            {/* Member since row */}
                            <div className="flex items-center gap-3 px-4 py-3.5">
                              <div className="w-8 h-8 rounded-xl bg-purple-500/10 flex items-center justify-center shrink-0">
                                <Calendar className="w-4 h-4 text-purple-400" />
                              </div>
                              <div className="flex-1 min-w-0">
                                <p className="text-[10px] font-bold uppercase tracking-widest text-slate-400 dark:text-white/30 mb-0.5">Membre depuis</p>
                                <span className="text-sm font-semibold text-slate-700 dark:text-white/80">
                                  {memberSince}
                                  {u.created_at && (
                                    <span className="ml-1.5 text-slate-400 dark:text-white/30 font-normal">
                                      · {new Date(u.created_at).toLocaleDateString('fr-FR', { day: 'numeric', month: 'long', year: 'numeric' })}
                                    </span>
                                  )}
                                </span>
                              </div>
                            </div>
                          </div>

                          {/* ── Recent Orders ── */}
                          <div>
                            <div className="flex items-center justify-between mb-3">
                              <p className="text-[10px] font-bold tracking-[0.14em] uppercase text-slate-500 dark:text-white/35">Commandes récentes</p>
                              {userOrders.length > 3 && (
                                <button
                                  onClick={() => { setSelectedUser(null); setActiveTab('orders'); }}
                                  className="flex items-center gap-1 text-[10px] font-bold text-orange-500 hover:underline"
                                >
                                  Voir tout <ArrowRight className="w-3 h-3" />
                                </button>
                              )}
                            </div>
                            {recentOrders.length === 0 ? (
                              <div className="rounded-2xl bg-slate-50 dark:bg-white/[0.03] border border-dashed border-slate-200 dark:border-white/10 p-5 text-center">
                                <ShoppingBag className="w-6 h-6 text-slate-300 dark:text-white/20 mx-auto mb-1.5" />
                                <p className="text-xs text-slate-400 dark:text-white/30">Aucune commande pour le moment</p>
                              </div>
                            ) : (
                              <div className="space-y-2">
                                {recentOrders.map((o: any) => {
                                  const badge = orderStatusLabel[o.status] ?? { label: o.status, cls: 'bg-slate-500/10 text-slate-400 border-slate-500/20' };
                                  return (
                                    <div key={o.id} className="flex items-center justify-between gap-3 rounded-xl bg-slate-50 dark:bg-white/[0.03] border border-slate-100 dark:border-white/8 px-4 py-3">
                                      <div className="min-w-0">
                                        <p className="text-xs font-bold text-slate-800 dark:text-white truncate">#{o.id.slice(0, 8).toUpperCase()}</p>
                                        <p className="text-[10px] text-slate-400 mt-0.5">{new Date(o.created_at).toLocaleDateString('fr-FR')}</p>
                                      </div>
                                      <div className="flex items-center gap-2 shrink-0">
                                        <span className={`px-2 py-0.5 rounded-md text-[9px] font-bold uppercase tracking-wider border ${badge.cls}`}>{badge.label}</span>
                                        <span className="text-xs font-black text-slate-700 dark:text-white/80">{formatGNF(Number(o.total_amount) || 0)}</span>
                                      </div>
                                    </div>
                                  );
                                })}
                              </div>
                            )}
                          </div>

                          {/* ── Account Management ── */}
                          {isSelf ? (
                            <div className="rounded-2xl bg-slate-50 dark:bg-white/[0.03] border border-dashed border-slate-200 dark:border-white/10 p-4 text-center">
                              <p className="text-xs text-slate-500">Vous ne pouvez pas modifier votre propre compte ici.</p>
                            </div>
                          ) : (
                            <div className="space-y-4">
                              <p className="text-[10px] font-bold tracking-[0.14em] uppercase text-slate-500 dark:text-white/35">Gestion du compte</p>

                              {/* Status toggle */}
                              <div className="flex items-center justify-between rounded-2xl bg-slate-50 dark:bg-white/[0.03] border border-slate-200 dark:border-white/8 px-4 py-3.5">
                                <div>
                                  <p className="text-sm font-semibold text-slate-800 dark:text-white">Compte actif</p>
                                  <p className="text-[11px] text-slate-500 mt-0.5">{isSuspended ? 'Ce compte est bloqué' : "L'utilisateur peut se connecter"}</p>
                                </div>
                                <button
                                  onClick={() => toggleUserAccountStatus(u.id, u.account_status || 'active')}
                                  className="transition-colors"
                                  title={isSuspended ? 'Réactiver' : 'Suspendre'}
                                >
                                  {isSuspended
                                    ? <ToggleLeft className="w-9 h-9 text-slate-300 dark:text-white/20 hover:text-emerald-500 transition-colors" />
                                    : <ToggleRight className="w-9 h-9 text-emerald-500 hover:text-slate-400 transition-colors" />
                                  }
                                </button>
                              </div>

                              {/* Role segmented control */}
                              <div className="rounded-2xl bg-slate-50 dark:bg-white/[0.03] border border-slate-200 dark:border-white/8 p-4 space-y-3">
                                <p className="text-xs font-semibold text-slate-600 dark:text-white/60">Rôle du compte</p>
                                <div className="grid grid-cols-3 gap-2">
                                  {[
                                    { key: 'client',  label: '🧑 Client',        active: !u.is_admin && u.profile_type !== 'courier' },
                                    { key: 'courier', label: '🚴 Livreur',       active: !u.is_admin && u.profile_type === 'courier' },
                                    { key: 'admin',   label: '🛡️ Admin',          active: !!u.is_admin },
                                  ].map(({ key, label, active }) => (
                                    <button
                                      key={key}
                                      onClick={() => {
                                        if (key === 'admin') toggleAdmin(u.id, u.is_admin);
                                        else if (key === 'courier') toggleProfileType(u.id, u.profile_type);
                                        else {
                                          // Clicking client: remove courier role if courier, remove admin if admin
                                          if (u.is_admin) toggleAdmin(u.id, true);
                                          else if (u.profile_type === 'courier') toggleProfileType(u.id, 'courier');
                                        }
                                      }}
                                      className={`py-2 rounded-xl text-[11px] font-bold transition-all border ${
                                        active
                                          ? 'bg-orange-500 text-white border-orange-500 shadow-sm shadow-orange-500/30'
                                          : 'bg-white dark:bg-white/5 text-slate-600 dark:text-white/50 border-slate-200 dark:border-white/10 hover:border-orange-500/40'
                                      }`}
                                    >
                                      {label}
                                    </button>
                                  ))}
                                </div>
                              </div>

                              {/* Danger Zone */}
                              <div className="rounded-2xl border border-red-500/20 bg-red-500/5 p-4 space-y-3">
                                <div className="flex items-center gap-2">
                                  <AlertTriangle className="w-4 h-4 text-red-500 shrink-0" />
                                  <p className="text-xs font-bold text-red-500 uppercase tracking-wider">Zone de danger</p>
                                </div>
                                <p className="text-[11px] text-slate-500 dark:text-white/40 leading-relaxed">
                                  La suppression est définitive et irréversible. Toutes les données associées à ce compte seront perdues.
                                </p>
                                <button
                                  onClick={() => deleteUser(u.id)}
                                  className="w-full inline-flex items-center justify-center gap-2 py-2.5 rounded-xl border border-red-500/30 text-sm font-bold text-red-500 hover:bg-red-500 hover:text-white transition-all"
                                >
                                  <Trash2 className="w-4 h-4" />
                                  Supprimer ce compte
                                </button>
                              </div>
                            </div>
                          )}
                        </div>
                      </motion.aside>
                    </>;
                  })()}
                </AnimatePresence>
              </motion.div>
            )}

            {activeTab === 'vendors' && (
              <motion.div 
                key="vendors"
                initial={{ opacity: 0, scale: 0.98, y: 15 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.98, y: -15 }}
                transition={{ duration: 0.3 }}
              >
                {/* Vendor Tab Header */}
                <div className="flex items-center justify-between mb-6">
                  <div>
                    <h2 className="text-xl font-bold text-slate-800 dark:text-white">Gestion des Vendeurs</h2>
                    <p className="text-[10px] font-semibold text-slate-400 dark:text-slate-500 uppercase mt-0.5">
                      {filteredVendors.filter(v => v.store_status !== 'archived').length} boutiques actives · {filteredVendors.filter(v => v.store_status === 'archived').length} archivées
                    </p>
                  </div>
                  <div className="flex gap-2 text-[9px] font-bold uppercase tracking-wider">
                    <span className="px-2.5 py-1.5 bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/20 rounded-lg">
                      ✓ {filteredVendors.filter(v => v.store_status === 'active').length} Opérationnels
                    </span>
                    <span className="px-2.5 py-1.5 bg-amber-500/10 text-amber-600 dark:text-amber-400 border border-amber-500/20 rounded-lg">
                      ⏳ {filteredVendors.filter(v => v.store_status === 'pending' || (!v.store_status && !v.is_verified_store)).length} En attente
                    </span>
                    <span className="px-2.5 py-1.5 bg-red-500/10 text-red-600 dark:text-red-400 border border-red-500/20 rounded-lg">
                      🚫 {filteredVendors.filter(v => v.store_status === 'suspended').length} Suspendus
                    </span>
                  </div>
                </div>

                {/* Vendor Cards Grid — non-archived */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
                  {filteredVendors.filter(v => v.store_status !== 'archived').map(v => {
                    const status = v.store_status || (v.is_verified_store ? 'active' : 'pending');
                    const balance = Number(v.balance || 0);
                    const pendingOrders = Number(v.pending_orders_count || 0);
                    const statusConfig: Record<string, { label: string; pill: string; dot: string }> = {
                      active:    { label: 'Opérationnel', pill: 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border-emerald-500/20', dot: 'bg-emerald-500' },
                      pending:   { label: 'En Attente',   pill: 'bg-amber-500/10 text-amber-600 dark:text-amber-400 border-amber-500/20',   dot: 'bg-amber-400' },
                      suspended: { label: 'Suspendu',     pill: 'bg-red-500/10 text-red-600 dark:text-red-400 border-red-500/20',           dot: 'bg-red-500' },
                      archived:  { label: 'Archivé',      pill: 'bg-slate-500/10 text-slate-500 dark:text-slate-400 border-slate-500/20',   dot: 'bg-slate-400' },
                    };
                    const cfg = statusConfig[status] || statusConfig.pending;
                    return (
                      <div key={v.id} className={`bg-white dark:bg-[#111622] border rounded-3xl p-6 relative overflow-hidden shadow-sm dark:shadow-md group transition-all duration-300 ${
                        status === 'suspended' ? 'border-red-500/30 dark:border-red-500/20' :
                        status === 'pending'   ? 'border-amber-500/30 dark:border-amber-500/20' :
                        'border-slate-200 dark:border-white/5 hover:border-[#ff6600]/40'
                      }`}>
                        {/* Subtle hover glow */}
                        <div className="absolute inset-0 bg-gradient-to-br from-[#ff6600]/[0.02] to-transparent opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none" />

                        {/* ── Header: Logo + Status badges ── */}
                        <div className="flex justify-between items-start mb-5 relative z-10">
                          <div className="relative">
                            <div className="w-14 h-14 bg-slate-100 dark:bg-black/20 rounded-2xl border border-slate-200 dark:border-white/10 flex items-center justify-center overflow-hidden p-0.5">
                              <div className="w-full h-full bg-white dark:bg-black rounded-[0.85rem] overflow-hidden flex items-center justify-center">
                                {v.logo_url ? (
                                  <img src={v.logo_url} alt="" className="w-full h-full object-cover" />
                                ) : (
                                  <Store className="w-7 h-7 text-orange-500" />
                                )}
                              </div>
                            </div>
                            {/* Live status dot */}
                            <span className={`absolute -bottom-0.5 -right-0.5 w-3 h-3 rounded-full border-2 border-white dark:border-[#111622] ${cfg.dot}`} />
                          </div>

                          <div className="flex flex-col items-end gap-1.5">
                            {/* Operational Status Pill */}
                            <span className={`flex items-center gap-1 px-2.5 py-1 border rounded-lg text-[9px] font-bold tracking-wider uppercase ${cfg.pill}`}>
                              {status === 'active'    && <CheckCircle className="w-2.5 h-2.5" />}
                              {status === 'pending'   && <Clock className="w-2.5 h-2.5" />}
                              {status === 'suspended' && <Ban className="w-2.5 h-2.5" />}
                              {cfg.label}
                            </span>
                            {/* Verification pill */}
                            {v.is_verified_store && (
                              <span className="px-2 py-0.5 bg-sky-500/10 text-sky-600 dark:text-sky-400 border border-sky-500/20 rounded-md text-[8px] font-bold tracking-wider uppercase">
                                ✓ Identité vérifiée
                              </span>
                            )}
                            <span className="text-[8px] font-mono font-semibold text-slate-300 dark:text-white/15 uppercase">#{v.id.substring(0,8)}</span>
                          </div>
                        </div>

                        {/* ── Store Name + Meta ── */}
                        <h3 className="text-base font-extrabold text-slate-800 dark:text-white uppercase mb-1 tracking-tight group-hover:text-orange-500 transition-colors relative z-10 truncate">
                          {v.store_name || 'Boutique Sans Nom'}
                        </h3>
                        <div className="flex flex-wrap gap-1.5 mb-3 relative z-10">
                          <span className="px-2 py-0.5 bg-orange-500/8 dark:bg-orange-500/10 border border-orange-500/15 rounded-md text-[9px] font-bold text-orange-500 uppercase">
                            {v.store_category || 'Catégorie Inconnue'}
                          </span>
                          {v.location_commune && (
                            <span className="px-2 py-0.5 bg-slate-100 dark:bg-white/5 border border-slate-200 dark:border-white/10 rounded-md text-[9px] font-semibold text-slate-500 dark:text-white/30 uppercase">
                              📍 {v.location_commune}
                            </span>
                          )}
                        </div>
                        <p className="text-[11px] font-medium text-slate-500 dark:text-white/35 mb-4 leading-relaxed line-clamp-2 relative z-10">
                          {v.description || 'Aucune description disponible pour cette boutique.'}
                        </p>

                        {/* ── Metrics Row ── */}
                        <div className="grid grid-cols-3 gap-2 mb-4 relative z-10">
                          {/* Balance — highlighted metric */}
                          <div className={`col-span-2 rounded-2xl p-3.5 border transition-all ${
                            balance > 0
                              ? 'bg-orange-500/5 dark:bg-orange-500/8 border-orange-500/20'
                              : 'bg-slate-50 dark:bg-white/[0.03] border-slate-200 dark:border-white/5'
                          }`}>
                            <div className="flex items-center gap-1.5 mb-1">
                              <Wallet className={`w-3 h-3 ${balance > 0 ? 'text-orange-500' : 'text-slate-400 dark:text-white/25'}`} />
                              <span className="text-[8px] font-bold tracking-wider text-slate-400 dark:text-white/20 uppercase">Solde Wallet</span>
                            </div>
                            <span className={`text-lg font-black leading-none ${balance > 0 ? 'text-orange-500' : 'text-slate-400 dark:text-white/30'}`}>
                              {formatGNF(balance)}
                            </span>
                          </div>
                          {/* Pending orders */}
                          <div className={`rounded-2xl p-3.5 border transition-all ${
                            pendingOrders > 0
                              ? 'bg-amber-500/8 border-amber-500/20'
                              : 'bg-slate-50 dark:bg-white/[0.03] border-slate-200 dark:border-white/5'
                          }`}>
                            <span className={`block text-[8px] font-bold tracking-wider mb-1 uppercase ${
                              pendingOrders > 0 ? 'text-amber-500' : 'text-slate-400 dark:text-white/20'
                            }`}>Cmd.</span>
                            <span className={`text-lg font-black leading-none ${
                              pendingOrders > 0 ? 'text-amber-500' : 'text-slate-500 dark:text-white/30'
                            }`}>{pendingOrders}</span>
                          </div>
                        </div>

                        {/* ── Status Lifecycle Controls ── */}
                        <div className="relative z-10 space-y-2">
                          {/* Row 1: Lifecycle pills */}
                          <div className="grid grid-cols-3 gap-1.5">
                            <button
                              onClick={() => setVendorStatus(v.id, 'active')}
                              disabled={status === 'active'}
                              title="Marquer comme Opérationnel"
                              className={`flex items-center justify-center gap-1 py-2 rounded-xl text-[9px] font-bold tracking-wider uppercase border transition-all active:scale-95 ${
                                status === 'active'
                                  ? 'bg-emerald-500 text-white border-emerald-500 cursor-default shadow-sm shadow-emerald-500/30'
                                  : 'bg-slate-50 dark:bg-white/5 text-slate-500 dark:text-white/40 border-slate-200 dark:border-white/10 hover:bg-emerald-500/10 hover:text-emerald-600 hover:border-emerald-500/30'
                              }`}
                            >
                              <PlayCircle className="w-3 h-3" />
                              Actif
                            </button>
                            <button
                              onClick={() => setVendorStatus(v.id, 'pending')}
                              disabled={status === 'pending'}
                              title="Mettre en attente de vérification"
                              className={`flex items-center justify-center gap-1 py-2 rounded-xl text-[9px] font-bold tracking-wider uppercase border transition-all active:scale-95 ${
                                status === 'pending'
                                  ? 'bg-amber-400 text-white border-amber-400 cursor-default shadow-sm shadow-amber-400/30'
                                  : 'bg-slate-50 dark:bg-white/5 text-slate-500 dark:text-white/40 border-slate-200 dark:border-white/10 hover:bg-amber-500/10 hover:text-amber-600 hover:border-amber-500/30'
                              }`}
                            >
                              <Clock className="w-3 h-3" />
                              Attente
                            </button>
                            <button
                              onClick={() => setVendorStatus(v.id, 'suspended')}
                              disabled={status === 'suspended'}
                              title="Suspendre cette boutique"
                              className={`flex items-center justify-center gap-1 py-2 rounded-xl text-[9px] font-bold tracking-wider uppercase border transition-all active:scale-95 ${
                                status === 'suspended'
                                  ? 'bg-red-500 text-white border-red-500 cursor-default shadow-sm shadow-red-500/30'
                                  : 'bg-slate-50 dark:bg-white/5 text-slate-500 dark:text-white/40 border-slate-200 dark:border-white/10 hover:bg-red-500/10 hover:text-red-600 hover:border-red-500/30'
                              }`}
                            >
                              <Ban className="w-3 h-3" />
                              Suspend.
                            </button>
                          </div>

                          {/* Row 2: Utility tools */}
                          <div className="flex gap-1.5">
                            {/* Verify toggle */}
                            <button
                              onClick={() => toggleStoreVerification(v.id, !!v.is_verified_store)}
                              className={`flex-1 py-2 rounded-xl text-[9px] font-bold tracking-wider uppercase border transition-all active:scale-95 ${
                                v.is_verified_store
                                  ? 'bg-sky-500/15 text-sky-600 dark:text-sky-400 border-sky-500/30 hover:bg-sky-500/25'
                                  : 'bg-slate-50 dark:bg-white/5 text-slate-500 dark:text-white/40 border-slate-200 dark:border-white/10 hover:border-sky-500/40 hover:text-sky-600'
                              }`}
                            >
                              {v.is_verified_store ? '✓ Dé-vérifier' : 'Vérifier ID'}
                            </button>

                            {/* Documents */}
                            <button
                              onClick={async () => {
                                if (!v.verification_document_url) {
                                  showToast("Aucun document d'identité répertorié.", "info");
                                  return;
                                }
                                const { data, error } = await supabase.storage
                                  .from('verification-documents')
                                  .createSignedUrl(v.verification_document_url, 600);
                                if (data?.signedUrl) {
                                  window.open(data.signedUrl, '_blank');
                                } else {
                                  console.error("Signed URL error:", error);
                                  showToast("Impossible d'accéder au document sécurisé.", "error");
                                }
                              }}
                              title="Voir les documents d'identité"
                              className="p-2 border border-slate-200 dark:border-white/10 rounded-xl bg-slate-50 dark:bg-white/5 text-slate-400 hover:border-sky-500 hover:text-sky-500 transition-all active:scale-95"
                            >
                              <FileText className="w-3.5 h-3.5" />
                            </button>

                            {/* Archive (soft-delete) */}
                            <button
                              onClick={() => archiveVendor(v.id)}
                              title="Désactiver et archiver cette boutique"
                              className="p-2 border border-slate-200 dark:border-white/10 rounded-xl bg-slate-50 dark:bg-white/5 text-slate-400 hover:border-amber-500 hover:bg-amber-500/10 hover:text-amber-600 transition-all active:scale-95"
                            >
                              <Archive className="w-3.5 h-3.5" />
                            </button>

                            {/* Permanent Delete — guarded */}
                            <button
                              onClick={() => permanentDeleteVendor(v)}
                              title={balance > 0 ? `Impossible : solde ${formatGNF(balance)}` : pendingOrders > 0 ? `Impossible : ${pendingOrders} cmd. en cours` : 'Supprimer définitivement'}
                              className={`p-2 border rounded-xl transition-all active:scale-95 ${
                                balance > 0 || pendingOrders > 0
                                  ? 'border-slate-200 dark:border-white/5 bg-slate-50 dark:bg-white/[0.02] text-slate-300 dark:text-white/15 cursor-not-allowed'
                                  : 'border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-white/5 text-slate-400 hover:border-red-500 hover:bg-red-500/10 hover:text-red-500'
                              }`}
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>

                {/* ── Archived Vendors Accordion ── */}
                {filteredVendors.some(v => v.store_status === 'archived') && (
                  <details className="group/archive">
                    <summary className="flex items-center gap-2 cursor-pointer select-none mb-4 list-none">
                      <div className="flex items-center gap-2 px-4 py-2.5 bg-slate-100 dark:bg-white/5 border border-slate-200 dark:border-white/10 rounded-2xl text-[10px] font-bold text-slate-500 dark:text-white/40 uppercase tracking-wider hover:border-slate-300 dark:hover:border-white/20 transition-all">
                        <Archive className="w-3.5 h-3.5" />
                        Boutiques Archivées ({filteredVendors.filter(v => v.store_status === 'archived').length})
                        <ChevronRight className="w-3.5 h-3.5 transition-transform group-open/archive:rotate-90" />
                      </div>
                    </summary>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                      {filteredVendors.filter(v => v.store_status === 'archived').map(v => {
                        const balance = Number(v.balance || 0);
                        const pendingOrders = Number(v.pending_orders_count || 0);
                        return (
                          <div key={v.id} className="bg-slate-50 dark:bg-white/[0.02] border border-dashed border-slate-300 dark:border-white/10 rounded-2xl p-4 opacity-70 hover:opacity-90 transition-opacity">
                            <div className="flex items-center justify-between mb-3">
                              <div className="flex items-center gap-2">
                                <div className="w-8 h-8 rounded-xl bg-slate-200 dark:bg-white/10 flex items-center justify-center">
                                  {v.logo_url ? <img src={v.logo_url} alt="" className="w-full h-full object-cover rounded-xl" /> : <Store className="w-4 h-4 text-slate-400" />}
                                </div>
                                <div>
                                  <p className="text-[11px] font-bold text-slate-600 dark:text-white/50 uppercase">{v.store_name || 'Sans Nom'}</p>
                                  <p className="text-[9px] text-slate-400 dark:text-white/25">{v.store_category}</p>
                                </div>
                              </div>
                              <span className="px-2 py-1 bg-slate-200/50 dark:bg-white/5 border border-slate-300 dark:border-white/10 rounded-lg text-[8px] font-bold text-slate-400 uppercase tracking-wider">
                                Archivé
                              </span>
                            </div>
                            <div className="flex items-center justify-between">
                              <span className="text-[10px] text-slate-400">
                                Solde : <span className="font-bold text-slate-600 dark:text-white/40">{formatGNF(balance)}</span>
                              </span>
                              <div className="flex gap-1">
                                {/* Restore to active */}
                                <button
                                  onClick={() => setVendorStatus(v.id, 'active')}
                                  title="Restaurer la boutique"
                                  className="px-2.5 py-1.5 text-[8px] font-bold uppercase tracking-wider bg-emerald-500/10 text-emerald-600 border border-emerald-500/20 rounded-lg hover:bg-emerald-500/20 transition-all active:scale-95"
                                >
                                  Restaurer
                                </button>
                                {/* Permanent delete */}
                                <button
                                  onClick={() => permanentDeleteVendor(v)}
                                  title={balance > 0 ? `Solde non nul` : pendingOrders > 0 ? `Commandes en cours` : 'Supprimer définitivement'}
                                  className={`p-1.5 border rounded-lg transition-all ${
                                    balance > 0 || pendingOrders > 0
                                      ? 'border-slate-200 dark:border-white/5 text-slate-300 dark:text-white/15 cursor-not-allowed'
                                      : 'border-slate-200 dark:border-white/10 text-slate-400 hover:border-red-500 hover:text-red-500'
                                  }`}
                                >
                                  <Trash2 className="w-3 h-3" />
                                </button>
                              </div>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </details>
                )}
              </motion.div>
            )}

            {activeTab === 'orders' && (
              <>
                {/* ── Courier Assignment Drawer ─────────────────────────────────── */}
                <AnimatePresence>
                  {assignDrawerOrder && (
                    <>
                      {/* Backdrop */}
                      <motion.div
                        key="drawer-backdrop"
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        exit={{ opacity: 0 }}
                        transition={{ duration: 0.2 }}
                        className="fixed inset-0 bg-black/60 backdrop-blur-sm z-[90]"
                        onClick={() => { setAssignDrawerOrder(null); setAssigningCourierId(''); }}
                      />
                      {/* Drawer panel */}
                      <motion.div
                        key="drawer-panel"
                        initial={{ x: '100%', opacity: 0 }}
                        animate={{ x: 0, opacity: 1 }}
                        exit={{ x: '100%', opacity: 0 }}
                        transition={{ type: 'spring', stiffness: 300, damping: 35 }}
                        className="fixed right-0 top-0 bottom-0 w-full max-w-md bg-[#0b0f17] border-l border-white/10 z-[95] flex flex-col shadow-2xl"
                      >
                        {/* Drawer header */}
                        <div className="p-6 border-b border-white/10 flex items-center justify-between">
                          <div>
                            <h3 className="text-lg font-bold text-white flex items-center gap-2">
                              <span className="text-xl">🛵</span> Assigner un Livreur
                            </h3>
                            <p className="text-[11px] text-white/40 font-semibold uppercase tracking-wider mt-0.5">
                              Commande #{(assignDrawerOrder.id || '').substring(0, 8).toUpperCase()}
                            </p>
                          </div>
                          <button
                            onClick={() => { setAssignDrawerOrder(null); setAssigningCourierId(''); }}
                            className="p-2 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 transition-all"
                          >
                            <X className="w-4 h-4 text-white/60" />
                          </button>
                        </div>

                        {/* Order summary chip */}
                        <div className="px-6 py-4 border-b border-white/5">
                          <div className="p-4 rounded-2xl bg-white/[0.04] border border-white/10">
                            <div className="flex items-start justify-between gap-4">
                              <div>
                                <p className="text-[10px] font-bold uppercase tracking-widest text-white/30 mb-1">Destinataire</p>
                                <p className="text-sm font-bold text-white">{assignDrawerOrder.profiles?.full_name || 'Client anonyme'}</p>
                                <p className="text-[11px] text-white/40 mt-0.5">
                                  {(() => {
                                    const addr = assignDrawerOrder.shipping_address;
                                    if (!addr) return 'Adresse non renseignée';
                                    const parsed = typeof addr === 'string' ? JSON.parse(addr) : addr;
                                    return [parsed.commune, parsed.quartier, parsed.region].filter(Boolean).join(', ') || 'Zone inconnue';
                                  })()}
                                </p>
                              </div>
                              <div className="text-right">
                                <p className="text-[10px] font-bold uppercase tracking-widest text-white/30 mb-1">Total</p>
                                <p className="text-base font-black text-[#ff6600]">{formatGNF(Number(assignDrawerOrder.total_amount || 0))}</p>
                              </div>
                            </div>
                          </div>
                        </div>

                        {/* Couriers list */}
                        <div className="flex-1 overflow-y-auto px-6 py-4 space-y-3 custom-scrollbar">
                          <p className="text-[10px] font-bold uppercase tracking-widest text-white/30 mb-3">
                            Livreurs disponibles ({availableCouriers.length})
                          </p>
                          {availableCouriers.length === 0 ? (
                            <div className="flex flex-col items-center justify-center py-16 text-center">
                              <Bike className="w-10 h-10 text-white/10 mb-3" />
                              <p className="text-white/40 text-sm font-semibold">Aucun livreur disponible</p>
                              <p className="text-white/20 text-xs mt-1">Tous les livreurs sont occupés ou hors-ligne</p>
                            </div>
                          ) : (
                            availableCouriers.map(courier => {
                              // Zone matching logic
                              const vendorZone = (() => {
                                const store = allVendors.find((v: any) => v.id === assignDrawerOrder.store_id);
                                return (store?.region || store?.operating_zone || '').toLowerCase();
                              })();
                              const courierZone = (courier.operating_zone || courier.region || '').toLowerCase();
                              const isZoneMatch = vendorZone && courierZone && courierZone.includes(vendorZone);
                              const isSelected = assigningCourierId === courier.id;

                              return (
                                <button
                                  key={courier.id}
                                  onClick={() => setAssigningCourierId(isSelected ? '' : courier.id)}
                                  className={`w-full text-left p-4 rounded-2xl border transition-all duration-200 group relative ${
                                    isSelected
                                      ? 'bg-[#ff6600]/15 border-[#ff6600]/50 shadow-lg shadow-[#ff6600]/10'
                                      : 'bg-white/[0.03] border-white/10 hover:bg-white/[0.06] hover:border-white/20'
                                  }`}
                                >
                                  {isZoneMatch && (
                                    <span className="absolute top-3 right-3 text-[9px] font-black uppercase tracking-widest px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                                      ✦ Zone idéale
                                    </span>
                                  )}
                                  <div className="flex items-center gap-3">
                                    <div className={`w-10 h-10 rounded-xl flex items-center justify-center font-black text-sm shrink-0 ${
                                      isSelected ? 'bg-[#ff6600] text-white' : 'bg-white/5 text-white/60'
                                    }`}>
                                      {(courier.full_name || courier.display_name || 'L').charAt(0).toUpperCase()}
                                    </div>
                                    <div className="flex-1 min-w-0">
                                      <p className="text-sm font-bold text-white truncate">
                                        {courier.full_name || courier.display_name || 'Livreur sans nom'}
                                      </p>
                                      <div className="flex items-center gap-2 mt-0.5">
                                        <span className="text-[10px] text-white/40">
                                          {courierZone ? courierZone.charAt(0).toUpperCase() + courierZone.slice(1) : 'Zone non définie'}
                                        </span>
                                        {courier.phone && (
                                          <span className="text-[10px] text-white/30">· {courier.phone}</span>
                                        )}
                                      </div>
                                    </div>
                                    <div className={`w-5 h-5 rounded-full border-2 shrink-0 flex items-center justify-center transition-all ${
                                      isSelected ? 'border-[#ff6600] bg-[#ff6600]' : 'border-white/20'
                                    }`}>
                                      {isSelected && <div className="w-2 h-2 rounded-full bg-white" />}
                                    </div>
                                  </div>
                                </button>
                              );
                            })
                          )}
                        </div>

                        {/* Confirm button */}
                        <div className="p-6 border-t border-white/10">
                          <button
                            onClick={() => assignCourier(assignDrawerOrder.id, assigningCourierId)}
                            disabled={!assigningCourierId || isAssigning}
                            className="w-full py-4 rounded-2xl font-black text-sm uppercase tracking-widest transition-all active:scale-[0.98] disabled:opacity-40 disabled:cursor-not-allowed"
                            style={{
                              background: assigningCourierId ? 'linear-gradient(135deg, #ff6600, #ff8c42)' : undefined,
                              backgroundColor: assigningCourierId ? undefined : 'rgba(255,255,255,0.05)',
                              color: assigningCourierId ? 'white' : 'rgba(255,255,255,0.3)',
                              boxShadow: assigningCourierId ? '0 8px 24px rgba(255,102,0,0.35)' : 'none'
                            }}
                          >
                            {isAssigning ? 'Assignation en cours...' : '🚀 Confirmer l\'expédition'}
                          </button>
                          {!assigningCourierId && (
                            <p className="text-center text-[10px] text-white/25 font-semibold mt-3 uppercase tracking-wider">
                              Sélectionnez un livreur pour activer
                            </p>
                          )}
                        </div>
                      </motion.div>
                    </>
                  )}
                </AnimatePresence>

                {/* ── Main Orders View ──────────────────────────────────────────── */}
                <motion.div 
                  key="orders"
                  initial={{ opacity: 0, scale: 0.98, y: 15 }}
                  animate={{ opacity: 1, scale: 1, y: 0 }}
                  exit={{ opacity: 0, scale: 0.98, y: -15 }}
                  transition={{ duration: 0.3 }}
                  className="space-y-6"
                >
                  {/* ── Header ── */}
                  <div className="bg-white dark:bg-[#111622] border border-slate-200 dark:border-white/5 rounded-3xl p-6 lg:p-8">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                      <div>
                        <div className="flex items-center gap-3 mb-1">
                          <h2 className="text-xl font-bold text-slate-800 dark:text-white">Opérations & Dispatch</h2>
                          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 bg-emerald-500/10 border border-emerald-500/25 rounded-lg">
                            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                            <span className="text-[10px] font-black text-emerald-600 dark:text-emerald-400 uppercase tracking-widest">Live</span>
                          </span>
                        </div>
                        <p className="text-[11px] font-semibold text-slate-400 dark:text-white/30 uppercase tracking-wider">
                          Centre de dispatch — {allOrdersList.length} commandes totales
                        </p>
                      </div>
                      {/* Summary pills */}
                      <div className="flex flex-wrap gap-2">
                        <span className="px-3 py-1.5 bg-amber-500/10 border border-amber-500/20 rounded-xl text-[10px] font-black text-amber-600 dark:text-amber-400 uppercase tracking-wider">
                          📥 {ordersAPreparer.length} à préparer
                        </span>
                        <span className="px-3 py-1.5 bg-violet-500/10 border border-violet-500/20 rounded-xl text-[10px] font-black text-violet-600 dark:text-violet-400 uppercase tracking-wider">
                          🛵 {ordersAAssigner.length} à assigner
                        </span>
                        <span className="px-3 py-1.5 bg-blue-500/10 border border-blue-500/20 rounded-xl text-[10px] font-black text-blue-600 dark:text-blue-400 uppercase tracking-wider">
                          🔵 {ordersEnCours.length} en cours
                        </span>
                        <span className="px-3 py-1.5 bg-emerald-500/10 border border-emerald-500/20 rounded-xl text-[10px] font-black text-emerald-600 dark:text-emerald-400 uppercase tracking-wider">
                          ✅ {ordersLivre.length} livrés
                        </span>
                      </div>
                    </div>

                    {/* 4-Tab Segmentation */}
                    <div className="mt-6 p-1.5 bg-slate-100 dark:bg-white/[0.04] border border-slate-200 dark:border-white/10 rounded-2xl grid grid-cols-2 sm:grid-cols-4 gap-1.5">
                      {([
                        { id: 'a_preparer' as OrderLifecycleTab, emoji: '📥', label: 'À Préparer', count: ordersAPreparer.length, color: 'amber' },
                        { id: 'a_assigner' as OrderLifecycleTab, emoji: '🛵', label: 'À Assigner', count: ordersAAssigner.length, color: 'violet', pulse: ordersAAssigner.length > 0 },
                        { id: 'en_cours' as OrderLifecycleTab, emoji: '🔵', label: 'En Cours', count: ordersEnCours.length, color: 'blue' },
                        { id: 'livre' as OrderLifecycleTab, emoji: '✅', label: 'Livré & Archivé', count: ordersLivre.length, color: 'emerald' },
                      ] as Array<{ id: OrderLifecycleTab; emoji: string; label: string; count: number; color: string; pulse?: boolean }>).map(tab => (
                        <button
                          key={tab.id}
                          onClick={() => setOrderLifecycleTab(tab.id)}
                          className={`relative flex flex-col items-center gap-1 py-3 px-2 rounded-xl text-center font-bold transition-all duration-200 ${
                            orderLifecycleTab === tab.id
                              ? 'bg-white dark:bg-[#1a2035] shadow-lg border border-slate-200 dark:border-white/10 text-slate-800 dark:text-white'
                              : 'text-slate-500 dark:text-white/30 hover:text-slate-700 dark:hover:text-white/60 hover:bg-white/50 dark:hover:bg-white/[0.03]'
                          }`}
                        >
                          <span className="text-lg">{tab.emoji}</span>
                          <span className="text-[10px] uppercase tracking-wider leading-tight hidden sm:block">{tab.label}</span>
                          <span className={`inline-flex items-center justify-center min-w-[20px] h-5 px-1.5 rounded-full text-[9px] font-black transition-all ${
                            orderLifecycleTab === tab.id
                              ? `bg-[#ff6600] text-white`
                              : 'bg-slate-200 dark:bg-white/10 text-slate-500 dark:text-white/40'
                          } ${tab.pulse && orderLifecycleTab !== tab.id ? 'animate-pulse' : ''}`}>
                            {tab.count}
                          </span>
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* ── Order Cards Grid ── */}
                  {(() => {
                    const currentOrders = orderLifecycleTab === 'a_preparer' ? ordersAPreparer
                      : orderLifecycleTab === 'a_assigner' ? ordersAAssigner
                      : orderLifecycleTab === 'en_cours' ? ordersEnCours
                      : ordersLivre;

                    if (currentOrders.length === 0) {
                      return (
                        <div className="flex flex-col items-center justify-center py-24 bg-white dark:bg-[#111622] border border-slate-200 dark:border-white/5 rounded-3xl">
                          <div className="w-16 h-16 rounded-2xl bg-slate-100 dark:bg-white/5 flex items-center justify-center mb-4">
                            <Package className="w-7 h-7 text-slate-400 dark:text-white/20" />
                          </div>
                          <p className="text-slate-600 dark:text-white/50 font-bold text-base">Aucune commande dans cette phase</p>
                          <p className="text-slate-400 dark:text-white/25 text-sm mt-1">Cette file d\'attente est vide pour l\'instant</p>
                        </div>
                      );
                    }

                    return (
                      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                        {currentOrders.map(order => {
                          const breakdown = getFinancialBreakdown(order);
                          const statusMap: Record<string, { label: string; cls: string }> = {
                            paid:             { label: 'Payé',            cls: 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border-emerald-500/25' },
                            confirmed:        { label: 'Confirmé',        cls: 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border-emerald-500/25' },
                            accepted:         { label: 'Accepté',         cls: 'bg-sky-500/10 text-sky-600 dark:text-sky-400 border-sky-500/25' },
                            preparing:        { label: 'En préparation',  cls: 'bg-violet-500/10 text-violet-600 dark:text-violet-400 border-violet-500/25' },
                            ready_for_pickup: { label: 'Prêt à enlever',  cls: 'bg-amber-500/10 text-amber-600 dark:text-amber-400 border-amber-500/25' },
                            in_transit:       { label: 'En transit',      cls: 'bg-[#ff6600]/10 text-orange-600 dark:text-orange-400 border-[#ff6600]/25' },
                            shipped:          { label: 'Expédié',         cls: 'bg-[#ff6600]/10 text-orange-600 dark:text-orange-400 border-[#ff6600]/25' },
                            delivered:        { label: 'Livré ✅',        cls: 'bg-slate-100 text-slate-600 dark:bg-white/8 dark:text-white/60 border-slate-200 dark:border-white/10' },
                            cancelled:        { label: 'Annulée',         cls: 'bg-rose-500/10 text-rose-600 dark:text-rose-400 border-rose-500/25' },
                          };
                          const statusInfo = statusMap[order.status ?? ''] ?? { label: order.status ?? 'Inconnu', cls: 'bg-slate-100 text-slate-500 border-slate-200 dark:bg-white/5 dark:text-white/30 dark:border-white/10' };

                          const courierName = (() => {
                            if (!order.courier_id) return null;
                            const c = allCouriers.find((c: any) => c.id === order.courier_id);
                            return c?.full_name || c?.display_name || 'Livreur assigné';
                          })();

                          return (
                            <motion.div
                              key={order.id}
                              layout
                              initial={{ opacity: 0, y: 12 }}
                              animate={{ opacity: 1, y: 0 }}
                              exit={{ opacity: 0, y: -12 }}
                              transition={{ duration: 0.25 }}
                              className="bg-white dark:bg-[#111622] border border-slate-200 dark:border-white/8 rounded-2xl overflow-hidden group hover:border-[#ff6600]/30 dark:hover:border-[#ff6600]/25 transition-all duration-300 shadow-sm dark:shadow-none hover:shadow-md dark:hover:shadow-[#ff6600]/5"
                            >
                              {/* Card Header */}
                              <div className="flex items-start justify-between p-5 pb-4">
                                <div className="flex items-start gap-3">
                                  <div className="w-10 h-10 rounded-xl bg-[#ff6600]/10 border border-[#ff6600]/20 flex items-center justify-center shrink-0">
                                    <ShoppingBag className="w-4.5 h-4.5 text-[#ff6600]" style={{ width: '18px', height: '18px' }} />
                                  </div>
                                  <div>
                                    <p className="font-mono text-xs text-[#ff6600] font-black">#{(order.id || '').substring(0, 8).toUpperCase()}</p>
                                    <p className="text-[10px] text-slate-400 dark:text-white/30 font-semibold mt-0.5">
                                      {order.created_at ? new Date(order.created_at).toLocaleDateString('fr-FR', { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' }) : '—'}
                                    </p>
                                  </div>
                                </div>
                                <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 border rounded-lg text-[10px] font-black tracking-wider uppercase ${statusInfo.cls}`}>
                                  {statusInfo.label}
                                </span>
                              </div>

                              {/* Customer & Tracking */}
                              <div className="px-5 pb-4 flex items-center justify-between gap-4">
                                <div className="flex-1 min-w-0">
                                  <p className="text-sm font-bold text-slate-800 dark:text-white truncate">
                                    {order.profiles?.full_name || 'Client anonyme'}
                                  </p>
                                  <p className="text-[10px] text-slate-400 dark:text-white/30 font-semibold truncate">
                                    {(() => {
                                      const addr = order.shipping_address;
                                      if (!addr) return 'Adresse non renseignée';
                                      try {
                                        const p = typeof addr === 'string' ? JSON.parse(addr) : addr;
                                        return [p.commune, p.quartier].filter(Boolean).join(', ') || 'Zone inconnue';
                                      } catch { return 'Adresse invalide'; }
                                    })()}
                                  </p>
                                </div>
                                <div className="text-right shrink-0">
                                  {order.tracking_number && (
                                    <p className="text-[10px] font-mono text-slate-500 dark:text-white/40">{order.tracking_number}</p>
                                  )}
                                  {order.delivery_otp && (
                                    <span className="inline-block mt-0.5 px-2 py-0.5 bg-[#ff6600]/15 rounded text-[9px] text-orange-600 dark:text-orange-400 font-black border border-[#ff6600]/20">OTP: {order.delivery_otp}</span>
                                  )}
                                </div>
                              </div>

                              {/* Courier assigned badge */}
                              {courierName && (
                                <div className="mx-5 mb-3 px-3 py-2 bg-blue-500/8 dark:bg-blue-500/10 border border-blue-500/20 rounded-xl flex items-center gap-2">
                                  <Bike className="w-3.5 h-3.5 text-blue-500 shrink-0" />
                                  <p className="text-[11px] font-bold text-blue-600 dark:text-blue-400 truncate">{courierName}</p>
                                </div>
                              )}

                              {/* ── Financial Breakdown ── */}
                              <div className="mx-5 mb-4 rounded-2xl bg-slate-50 dark:bg-white/[0.03] border border-slate-200 dark:border-white/8 overflow-hidden">
                                <div className="px-4 py-2.5 border-b border-slate-200 dark:border-white/8">
                                  <p className="text-[9px] font-black uppercase tracking-[0.15em] text-slate-400 dark:text-white/25">Répartition Financière</p>
                                </div>
                                <div className="divide-y divide-slate-100 dark:divide-white/5">
                                  <div className="flex items-center justify-between px-4 py-2.5">
                                    <div className="flex items-center gap-2">
                                      <div className="w-1.5 h-1.5 rounded-full bg-slate-400 dark:bg-white/30" />
                                      <span className="text-[11px] font-semibold text-slate-500 dark:text-white/40">Montant Total</span>
                                    </div>
                                    <span className="text-[12px] font-black text-slate-800 dark:text-white tabular-nums">
                                      {formatGNF(breakdown.total)}
                                    </span>
                                  </div>
                                  <div className="flex items-center justify-between px-4 py-2.5">
                                    <div className="flex items-center gap-2">
                                      <div className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                                      <span className="text-[11px] font-semibold text-slate-500 dark:text-white/40">Part du Vendeur</span>
                                    </div>
                                    <span className="text-[12px] font-black text-emerald-600 dark:text-emerald-400 tabular-nums">
                                      {formatGNF(breakdown.vendorShare)}
                                    </span>
                                  </div>
                                  <div className="flex items-center justify-between px-4 py-2.5">
                                    <div className="flex items-center gap-2">
                                      <div className="w-1.5 h-1.5 rounded-full bg-[#ff6600]" />
                                      <span className="text-[11px] font-semibold text-slate-500 dark:text-white/40">
                                        Commission ({platformSettings.commission || 5}%)
                                      </span>
                                    </div>
                                    <span className="text-[12px] font-black text-[#ff6600] tabular-nums">
                                      {formatGNF(breakdown.commission)}
                                    </span>
                                  </div>
                                  <div className="flex items-center justify-between px-4 py-2.5">
                                    <div className="flex items-center gap-2">
                                      <div className="w-1.5 h-1.5 rounded-full bg-blue-500" />
                                      <span className="text-[11px] font-semibold text-slate-500 dark:text-white/40">Frais de Livraison</span>
                                    </div>
                                    <span className="text-[12px] font-black text-blue-600 dark:text-blue-400 tabular-nums">
                                      {formatGNF(breakdown.deliveryFee)}
                                    </span>
                                  </div>
                                </div>
                              </div>

                              {/* ── Card Action Footer ── */}
                              <div className="px-5 pb-5">
                                {orderLifecycleTab === 'a_preparer' && (
                                  <div className="flex gap-2">
                                    <button
                                      onClick={() => updateOrderStatus(order.id, 'preparing')}
                                      className="flex-1 py-2.5 rounded-xl text-[11px] font-black uppercase tracking-wider bg-violet-500/10 text-violet-600 dark:text-violet-400 border border-violet-500/25 hover:bg-violet-500 hover:text-white hover:border-violet-500 transition-all active:scale-95"
                                    >
                                      🍳 Marquer En Préparation
                                    </button>
                                    <button
                                      onClick={() => updateOrderStatus(order.id, 'cancelled')}
                                      className="px-3 py-2.5 rounded-xl text-[11px] font-black uppercase tracking-wider bg-rose-500/8 text-rose-500 border border-rose-500/20 hover:bg-rose-500 hover:text-white transition-all active:scale-95"
                                      title="Annuler la commande"
                                    >
                                      <XCircle className="w-4 h-4" />
                                    </button>
                                  </div>
                                )}
                                {orderLifecycleTab === 'a_assigner' && (
                                  <div className="flex gap-2">
                                    <button
                                      onClick={() => { setAssignDrawerOrder(order); setAssigningCourierId(''); }}
                                      className="flex-1 py-2.5 rounded-xl text-[11px] font-black uppercase tracking-wider transition-all active:scale-95"
                                      style={{
                                        background: 'linear-gradient(135deg, #ff6600, #ff8c42)',
                                        color: 'white',
                                        boxShadow: '0 4px 16px rgba(255,102,0,0.30)'
                                      }}
                                    >
                                      🛵 Assigner un Livreur
                                    </button>
                                    <button
                                      onClick={() => updateOrderStatus(order.id, 'cancelled')}
                                      className="px-3 py-2.5 rounded-xl text-[11px] font-black uppercase tracking-wider bg-rose-500/8 text-rose-500 border border-rose-500/20 hover:bg-rose-500 hover:text-white transition-all active:scale-95"
                                      title="Annuler la commande"
                                    >
                                      <XCircle className="w-4 h-4" />
                                    </button>
                                  </div>
                                )}
                                {orderLifecycleTab === 'en_cours' && (
                                  <button
                                    onClick={() => updateOrderStatus(order.id, 'delivered')}
                                    className="w-full py-2.5 rounded-xl text-[11px] font-black uppercase tracking-wider bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/25 hover:bg-emerald-500 hover:text-white hover:border-emerald-500 transition-all active:scale-95"
                                  >
                                    ✅ Confirmer Livraison
                                  </button>
                                )}
                                {orderLifecycleTab === 'livre' && (
                                  <div className="flex items-center justify-center gap-2 py-2">
                                    <Archive className="w-3.5 h-3.5 text-slate-400 dark:text-white/20" />
                                    <span className="text-[10px] font-semibold text-slate-400 dark:text-white/25 uppercase tracking-wider">
                                      {order.status === 'cancelled' ? 'Commande annulée — archivée' : 'Transaction finalisée — archivée'}
                                    </span>
                                  </div>
                                )}
                              </div>
                            </motion.div>
                          );
                        })}
                      </div>
                    );
                  })()}
                </motion.div>
              </>
            )}

            {activeTab === 'products' && (
              <div className="w-full">
                {/* ── Moderation filter bar + Trending refresh ─────────── */}
                <div className="flex items-center gap-2 px-1 mb-6 flex-wrap justify-between">
                  {/* Refresh Ventes Flash button */}
                  <button
                    id="admin-refresh-trending-btn"
                    onClick={refreshTrendingMV}
                    disabled={isRefreshingMV}
                    className="ml-auto flex items-center gap-2 px-4 py-2 rounded-xl bg-[#ff6600] hover:bg-[#e65c00] disabled:opacity-50 disabled:cursor-not-allowed text-white text-[11px] font-black uppercase tracking-wide transition-all shadow-sm shadow-orange-200 dark:shadow-none"
                  >
                    {isRefreshingMV ? (
                      <svg className="w-3.5 h-3.5 animate-spin" fill="none" viewBox="0 0 24 24">
                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8z" />
                      </svg>
                    ) : (
                      <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" strokeWidth="2.5" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
                      </svg>
                    )}
                    {isRefreshingMV ? 'Actualisation…' : 'Rafraîchir Ventes Flash'}
                  </button>
                </div>

                {/* Moderation filters */}
                <div className="flex items-center gap-2 px-1 mb-4 flex-wrap">
                  {(['all', 'pending', 'approved', 'rejected'] as const).map(f => {
                    const counts: Record<string, number> = {
                      all:      allProducts.length,
                      pending:  allProducts.filter(p => (p.moderation_status ?? 'approved') === 'pending').length,
                      approved: allProducts.filter(p => (p.moderation_status ?? 'approved') === 'approved').length,
                      rejected: allProducts.filter(p => (p.moderation_status ?? 'approved') === 'rejected').length,
                    };
                    const labels: Record<string, string> = { all: 'Tous', pending: 'En attente', approved: 'Approuvés', rejected: 'Rejetés' };
                    const colors: Record<string, string> = {
                      all:      productModerationFilter === 'all'      ? 'bg-[#ff6600] text-white' : 'bg-white dark:bg-gray-800 text-gray-600 dark:text-gray-300',
                      pending:  productModerationFilter === 'pending'  ? 'bg-amber-500 text-white' : 'bg-white dark:bg-gray-800 text-gray-600 dark:text-gray-300',
                      approved: productModerationFilter === 'approved' ? 'bg-green-500 text-white' : 'bg-white dark:bg-gray-800 text-gray-600 dark:text-gray-300',
                      rejected: productModerationFilter === 'rejected' ? 'bg-red-500 text-white'   : 'bg-white dark:bg-gray-800 text-gray-600 dark:text-gray-300',
                    };
                    return (
                      <button
                        key={f}
                        onClick={() => setProductModerationFilter(f)}
                        className={`flex items-center gap-1.5 px-4 py-2 rounded-xl border border-gray-200 dark:border-white/10 text-[11px] font-black uppercase tracking-wide transition-all ${colors[f]}`}
                      >
                        {labels[f]}
                        {counts[f] > 0 && (
                          <span className={`rounded-full px-1.5 py-0.5 text-[9px] font-black ${
                            productModerationFilter === f ? 'bg-white/20' : 'bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-300'
                          }`}>{counts[f]}</span>
                        )}
                      </button>
                    );
                  })}
                </div>

              <motion.div 
                key="products"
                initial={{ opacity: 0, scale: 0.98 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.98 }}
                transition={{ duration: 0.3 }}
                className={filteredProducts.length > 0 ? "grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6" : "flex flex-col items-center justify-center py-20 bg-white dark:bg-[#111622] border border-slate-200 dark:border-white/5 rounded-3xl shadow-sm dark:shadow-md mx-6 w-full"}
              >
                {filteredProducts.length > 0 ? filteredProducts.map((p) => {
                  // ── Stock metrics ──
                  const stockQty: number = p.stock_quantity ?? p.stock ?? null;
                  const hasStock = stockQty !== null && stockQty !== undefined;
                  const isOutOfStock = hasStock && stockQty <= 0;

                  // ── Visibility ──
                  const isVisible: boolean = p.is_visible ?? true;

                  return (
                  <div
                    key={p.id}
                    className={`bg-white dark:bg-[#111622] border rounded-2xl overflow-hidden shadow-sm dark:shadow-md group transition-all duration-300 relative ${
                      !isVisible
                        ? 'border-slate-300 dark:border-white/10 opacity-60 grayscale-[30%]'
                        : 'border-slate-200 dark:border-white/5 hover:border-[#ff6600]/40'
                    }`}
                  >
                    {/* ── Hidden overlay banner ── */}
                    {!isVisible && (
                      <div className="absolute top-0 left-0 right-0 z-20 flex items-center justify-center gap-1.5 py-1.5 bg-slate-800/80 dark:bg-black/70 backdrop-blur-sm">
                        <EyeOff className="w-3 h-3 text-slate-300" />
                        <span className="text-[9px] font-bold text-slate-300 uppercase tracking-widest">Masqué de la vitrine</span>
                      </div>
                    )}

                    <div className="relative aspect-[4/5] overflow-hidden group/img">
                      <img
                        src={p.image_urls?.[0]}
                        alt=""
                        className="w-full h-full object-cover group-hover/img:scale-105 transition-transform duration-500"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-slate-900/60 via-transparent to-transparent" />

                      {/* ── Top-right: ID chip + Visibility toggle ── */}
                      <div className="absolute top-3 right-3 flex flex-col items-end gap-1.5 z-10">
                        <span className="px-2 py-1 bg-white/90 dark:bg-black/60 backdrop-blur-md border border-slate-200 dark:border-white/10 rounded-lg text-[9px] font-bold text-slate-800 dark:text-white uppercase shadow-sm">
                          ID: {p.id.substring(0,8).toUpperCase()}
                        </span>
                        {/* Eye toggle */}
                        <button
                          onClick={(e) => { e.stopPropagation(); toggleProductVisibility(p.id, isVisible); }}
                          title={isVisible ? 'Masquer de la vitrine client' : 'Rendre visible sur la vitrine'}
                          className={`p-1.5 rounded-lg backdrop-blur-md border transition-all active:scale-90 shadow-sm ${
                            isVisible
                              ? 'bg-white/80 dark:bg-black/50 border-white/20 text-slate-600 dark:text-white/60 hover:bg-[#ff6600] hover:text-white hover:border-[#ff6600]'
                              : 'bg-[#ff6600] border-[#ff6600] text-white'
                          }`}
                        >
                          {isVisible ? <Eye className="w-3.5 h-3.5" /> : <EyeOff className="w-3.5 h-3.5" />}
                        </button>
                      </div>

                      {/* ── Top-left: Stock badge ── */}
                      {hasStock && (
                        <div className="absolute top-3 left-3 z-10">
                          {isOutOfStock ? (
                            <span className="flex items-center gap-1 px-2 py-1 bg-red-600 border border-red-400/30 rounded-lg text-[9px] font-black text-white uppercase tracking-wider shadow-lg animate-pulse">
                              <Package className="w-2.5 h-2.5" />
                              Rupture de Stock
                            </span>
                          ) : (
                            <span className={`flex items-center gap-1 px-2 py-1 rounded-lg text-[9px] font-bold uppercase tracking-wider shadow-sm border ${
                              stockQty <= 5
                                ? 'bg-amber-500/90 border-amber-400/30 text-white'
                                : 'bg-emerald-600/90 border-emerald-400/30 text-white'
                            }`}>
                              <Package className="w-2.5 h-2.5" />
                              En Stock : {stockQty} unité{stockQty > 1 ? 's' : ''}
                            </span>
                          )}
                        </div>
                      )}

                      <div className="absolute bottom-4 left-4 right-4">
                        <p className="text-[10px] font-bold text-orange-400 tracking-wider mb-1 uppercase drop-shadow-md">{p.stores?.store_name || 'Boutique Inconnue'}</p>
                        <h3 className="font-bold text-white text-lg tracking-tight leading-tight uppercase line-clamp-2 drop-shadow-md">{p.title}</h3>
                      </div>
                    </div>

                    <div className="p-5">
                      <div className="flex items-center gap-2 mb-3">
                        <div className="w-2 h-2 rounded-full bg-[#ff6600]" />
                        <span className="text-[10px] font-bold text-slate-400 dark:text-white/20 tracking-wider uppercase">{p.category || 'Catégorie Générale'}</span>
                        {/* Inline out-of-stock fallback if stock_quantity field absent */}
                        {!hasStock && (
                          <span className="ml-auto px-1.5 py-0.5 bg-slate-100 dark:bg-white/5 border border-dashed border-slate-200 dark:border-white/10 rounded text-[8px] font-semibold text-slate-300 dark:text-white/15 uppercase">
                            Stock N/A
                          </span>
                        )}
                      </div>

                      <div className="flex items-center justify-between pt-4 border-t border-slate-100 dark:border-white/5">
                        <div>
                           <span className="text-[9px] font-bold text-slate-400 dark:text-white/20 tracking-wider mb-0.5 uppercase block">Prix</span>
                           <p className="font-extrabold text-slate-800 dark:text-white text-lg tracking-tight">{formatGNF(Number(p.price_gnf))}</p>
                        </div>
                        <div className="flex gap-2">
                          {/* Hard-delete — demoted to trash icon */}
                          <button
                            onClick={() => deleteProduct(p.id)}
                            title="Supprimer définitivement ce produit"
                            className="p-2.5 bg-slate-50 dark:bg-white/5 border border-slate-200 dark:border-white/10 rounded-xl text-slate-400 hover:text-red-500 hover:bg-red-500/10 transition-all active:scale-95 shadow-sm"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>

                      {/* ── Moderation action bar (pending only) ── */}
                      {(p.moderation_status ?? 'approved') === 'pending' && (
                        <div className="flex gap-2 mt-3 pt-3 border-t border-amber-100 dark:border-amber-900/20">
                          <button
                            onClick={() => moderateProduct(p.id, 'approved')}
                            className="flex-1 flex items-center justify-center gap-1.5 py-2 rounded-xl bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-900/30 text-green-700 dark:text-green-400 text-[10px] font-black uppercase tracking-wide hover:bg-green-100 transition-colors active:scale-95"
                          >
                            ✅ Approuver
                          </button>
                          <button
                            onClick={() => moderateProduct(p.id, 'rejected', 'Rejeté par l\'administrateur')}
                            className="flex-1 flex items-center justify-center gap-1.5 py-2 rounded-xl bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-900/30 text-red-700 dark:text-red-400 text-[10px] font-black uppercase tracking-wide hover:bg-red-100 transition-colors active:scale-95"
                          >
                            🚫 Rejeter
                          </button>
                        </div>
                      )}
                    </div>
                  </div>
                  );
                }) : (
                  <div className="flex flex-col items-center gap-4">
                    <div className="w-16 h-16 rounded-2xl bg-slate-50 dark:bg-white/5 border border-slate-200 dark:border-white/10 flex items-center justify-center">
                       <Store className="w-8 h-8 text-slate-400 dark:text-white/10" />
                    </div>
                    <div className="text-center">
                      <p className="text-xs font-bold tracking-wider text-slate-400 dark:text-white/40 uppercase">Inventaire vide</p>
                      <p className="text-[10px] font-semibold text-slate-400 dark:text-slate-500 uppercase mt-1">Aucun produit enregistré pour le moment</p>
                    </div>
                  </div>
                )}
              </motion.div>
              </div>
            )}

            {activeTab === 'settings' && (
              <motion.div 
                key="settings"
                initial={{ opacity: 0, y: 12 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -12 }}
                transition={{ duration: 0.25 }}
                className="max-w-5xl mx-auto space-y-7 pb-16"
              >
                {/* Page Header */}
                <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 border-b border-slate-200/80 dark:border-white/10 pb-6">
                  <div>
                    <div className="flex items-center gap-2 text-xs font-semibold text-orange-600 dark:text-orange-400 mb-1">
                      <Settings className="w-4 h-4" />
                      <span>Configuration Globale & Protocoles</span>
                    </div>
                    <h2 className="text-2xl font-bold text-slate-900 dark:text-white tracking-tight">
                      Paramètres du Système
                    </h2>
                    <p className="text-sm text-slate-500 dark:text-slate-400 mt-1 max-w-2xl">
                      Définissez les barèmes de commissions, la cadence de déblocage des virements et les coordonnées d'assistance de {APP_NAME}.
                    </p>
                  </div>

                  <div className="flex items-center gap-2.5 shrink-0">
                    <button
                      type="button"
                      onClick={() => {
                        fetchData();
                        showToast("Données rechargées depuis la base.", "info");
                      }}
                      className="inline-flex items-center gap-2 px-3.5 py-2.5 text-xs font-semibold text-slate-700 dark:text-slate-300 bg-white dark:bg-white/5 border border-slate-200 dark:border-white/10 rounded-xl hover:bg-slate-50 dark:hover:bg-white/10 transition-colors shadow-sm"
                    >
                      <RefreshCw className="w-3.5 h-3.5" />
                      Actualiser
                    </button>
                    <button
                      type="button"
                      onClick={saveSettings}
                      disabled={isSavingSettings}
                      className="inline-flex items-center gap-2 px-5 py-2.5 text-xs font-semibold text-white bg-gradient-to-r from-orange-500 to-[#ff6600] rounded-xl hover:from-orange-600 hover:to-orange-500 active:scale-[0.98] transition-all shadow-md shadow-orange-500/25 disabled:opacity-50"
                    >
                      {isSavingSettings ? (
                        <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                      ) : (
                        <Save className="w-3.5 h-3.5" />
                      )}
                      <span>{isSavingSettings ? "Enregistrement…" : "Enregistrer les modifications"}</span>
                    </button>
                  </div>
                </div>

                {/* Section 1: Commissions & Règlements */}
                <div className="bg-white dark:bg-[#0f141d] border border-slate-200/90 dark:border-white/10 rounded-2xl p-6 lg:p-7 shadow-sm">
                  <div className="flex items-start gap-4 mb-6">
                    <div className="w-10 h-10 rounded-xl bg-orange-50 dark:bg-orange-500/10 border border-orange-200/80 dark:border-orange-500/20 flex items-center justify-center shrink-0 text-orange-600 dark:text-orange-400">
                      <Percent className="w-5 h-5" />
                    </div>
                    <div>
                      <h3 className="text-base font-bold text-slate-900 dark:text-white">
                        Modèle Économique & Commissions
                      </h3>
                      <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                        Pourcentage prélevé sur les commandes finalisées et période de séquestre sécuritaire.
                      </p>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <SettingField 
                      label="Commission de la Plateforme" 
                      value={platformSettings.commission} 
                      onChange={(e: any) => setPlatformSettings({...platformSettings, commission: e.target.value})}
                      suffix="%"
                      placeholder="ex: 2"
                      description="Taux appliqué sur le sous-total de chaque article vendu par un marchand."
                    />
                    <SettingField 
                      label="Cycle de Règlement Sécuritaire" 
                      value={platformSettings.withdrawalDelay} 
                      onChange={(e: any) => setPlatformSettings({...platformSettings, withdrawalDelay: e.target.value})}
                      suffix="Jours"
                      placeholder="ex: 4"
                      description="Délai de rétention anti-litige avant que les fonds deviennent éligibles au retrait."
                    />
                  </div>

                  {/* Dynamic calculation preview */}
                  <div className="mt-5 p-4 rounded-xl bg-slate-50 dark:bg-white/[0.02] border border-slate-200/80 dark:border-white/5 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 text-xs">
                    <div className="flex items-center gap-2.5 text-slate-600 dark:text-slate-300">
                      <span className="w-2 h-2 rounded-full bg-orange-500"></span>
                      <span>Simulation pour une commande de <strong className="font-semibold text-slate-900 dark:text-white">100 000 GNF</strong> :</span>
                    </div>
                    <div className="flex items-center gap-3 font-mono font-medium text-slate-700 dark:text-slate-300">
                      <span>Vendeur : <strong className="text-emerald-600 dark:text-emerald-400">{formatGNF(Math.round(100000 * (1 - (Number(platformSettings.commission) || 0) / 100)))}</strong></span>
                      <span className="text-slate-300 dark:text-slate-700">·</span>
                      <span>Plateforme : <strong className="text-orange-600 dark:text-orange-400">{formatGNF(Math.round(100000 * ((Number(platformSettings.commission) || 0) / 100)))}</strong></span>
                    </div>
                  </div>
                </div>

                {/* Section 2: Trésorerie & Retraits */}
                <div className="bg-white dark:bg-[#0f141d] border border-slate-200/90 dark:border-white/10 rounded-2xl p-6 lg:p-7 shadow-sm">
                  <div className="flex items-start gap-4 mb-6">
                    <div className="w-10 h-10 rounded-xl bg-emerald-50 dark:bg-emerald-500/10 border border-emerald-200/80 dark:border-emerald-500/20 flex items-center justify-center shrink-0 text-emerald-600 dark:text-emerald-400">
                      <Wallet className="w-5 h-5" />
                    </div>
                    <div>
                      <h3 className="text-base font-bold text-slate-900 dark:text-white">
                        Trésorerie & Seuils Financiers
                      </h3>
                      <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                        Plafonds de sécurité pour les virements marchands (Orange Money, MTN MoMo, virement).
                      </p>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <SettingField 
                      label="Montant Minimum de Retrait" 
                      value={platformSettings.minWithdrawal} 
                      onChange={(e: any) => setPlatformSettings({...platformSettings, minWithdrawal: e.target.value})}
                      suffix="GNF"
                      placeholder="ex: 15000"
                      description="Solde disponible minimum exigé pour soumettre une demande."
                    />
                    <SettingField 
                      label="Plafond de Retrait par 24h" 
                      value={platformSettings.maxWithdrawalDaily} 
                      onChange={(e: any) => setPlatformSettings({...platformSettings, maxWithdrawalDaily: e.target.value})}
                      suffix="GNF"
                      placeholder="ex: 10000000"
                      description="Limite quotidienne autorisée par boutique pour prévenir les fraudes."
                    />
                    <SettingField 
                      label="Prime de Parrainage Marchand" 
                      value={platformSettings.referralBonus} 
                      onChange={(e: any) => setPlatformSettings({...platformSettings, referralBonus: e.target.value})}
                      suffix="GNF"
                      placeholder="ex: 5000"
                      description="Bonus crédité au parrain dès la validation de la première commande du filleul."
                    />
                  </div>
                </div>

                {/* Section 3: Assistance & Support Client */}
                <div className="bg-white dark:bg-[#0f141d] border border-slate-200/90 dark:border-white/10 rounded-2xl p-6 lg:p-7 shadow-sm">
                  <div className="flex items-start gap-4 mb-6">
                    <div className="w-10 h-10 rounded-xl bg-blue-50 dark:bg-blue-500/10 border border-blue-200/80 dark:border-blue-500/20 flex items-center justify-center shrink-0 text-blue-600 dark:text-blue-400">
                      <PhoneCall className="w-5 h-5" />
                    </div>
                    <div>
                      <h3 className="text-base font-bold text-slate-900 dark:text-white">
                        Canaux d'Assistance & Support Client
                      </h3>
                      <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                        Coordonnées directes affichées aux acheteurs et vendeurs sur la plateforme et les factures.
                      </p>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <SettingField 
                      label="Email de Contact Support" 
                      value={platformSettings.supportContact} 
                      onChange={(e: any) => setPlatformSettings({...platformSettings, supportContact: e.target.value})}
                      prefix="@"
                      placeholder="support@fatibara.gn"
                      description="Adresse de correspondance officielle pour les réclamations."
                    />
                    <SettingField 
                      label="WhatsApp Support Client" 
                      value={platformSettings.supportWhatsapp || ''} 
                      onChange={(e: any) => setPlatformSettings({
                        ...platformSettings,
                        supportWhatsapp: e.target.value.replace(/[\s+\-()]/g, '')
                      })}
                      prefix="+224"
                      placeholder="613101091"
                      description="Numéro sans indicatif. Active le bouton WhatsApp sur le suivi de commande."
                    />
                    <SettingField 
                      label="Ligne Téléphonique Directe" 
                      value={platformSettings.supportPhone || ''} 
                      onChange={(e: any) => setPlatformSettings({
                        ...platformSettings,
                        supportPhone: e.target.value
                      })}
                      prefix="📞"
                      placeholder="+224 613 10 10 91"
                      description="Numéro vocal affiché aux clients si aucun livreur n'est encore assigné."
                    />
                  </div>
                </div>

                {/* Section 4: Zone d'Opérations & Maintenance */}
                <div className="bg-slate-900 dark:bg-[#0a0d14] border border-slate-800 dark:border-white/10 rounded-2xl p-6 lg:p-7 shadow-sm text-white">
                  <div className="flex items-center gap-3 mb-2">
                    <AlertTriangle className="w-5 h-5 text-amber-400" />
                    <h3 className="text-base font-bold text-white">
                      Zone Opérationnelle & Maintenance
                    </h3>
                  </div>
                  <p className="text-xs text-slate-400 mb-6 leading-relaxed max-w-2xl">
                    Commandes de gestion directe pour la disponibilité publique de la marketplace et la synchronisation des données locales.
                  </p>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    {/* Maintenance Mode Toggle Card */}
                    <div className="bg-white/5 border border-white/10 rounded-xl p-4 flex flex-col justify-between space-y-4">
                      <div>
                        <div className="flex items-center justify-between mb-2">
                          <span className="text-xs font-semibold text-slate-300">Mode Maintenance</span>
                          <span className={`px-2 py-0.5 text-[10px] font-bold rounded-full ${
                            platformSettings.maintenanceMode === 'true'
                              ? 'bg-rose-500/20 text-rose-400 border border-rose-500/30'
                              : 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                          }`}>
                            {platformSettings.maintenanceMode === 'true' ? 'Activé' : 'Normal'}
                          </span>
                        </div>
                        <p className="text-[11px] text-slate-400 leading-normal">
                          {platformSettings.maintenanceMode === 'true'
                            ? "La marketplace affiche une page d'attente pour tous les visiteurs non-admin."
                            : "La marketplace fonctionne normalement et accepte les visites et commandes."}
                        </p>
                      </div>
                      <button
                        type="button"
                        onClick={async () => {
                          const next = platformSettings.maintenanceMode === 'true' ? 'false' : 'true';
                          setPlatformSettings({...platformSettings, maintenanceMode: next});
                          showToast(`Mode Maintenance : ${next === 'true' ? 'ACTIVÉ' : 'DÉSACTIVÉ'}`, "info");
                        }}
                        className={`w-full py-2.5 px-3 rounded-lg text-xs font-semibold transition-all shadow-sm ${
                          platformSettings.maintenanceMode === 'true'
                            ? 'bg-emerald-600 hover:bg-emerald-500 text-white'
                            : 'bg-rose-600 hover:bg-rose-500 text-white'
                        }`}
                      >
                        {platformSettings.maintenanceMode === 'true' ? "Désactiver le Mode Maintenance" : "Activer le Mode Maintenance"}
                      </button>
                    </div>

                    {/* Purge Cache Card */}
                    <div className="bg-white/5 border border-white/10 rounded-xl p-4 flex flex-col justify-between space-y-4">
                      <div>
                        <div className="flex items-center justify-between mb-2">
                          <span className="text-xs font-semibold text-slate-300">Cache Local & Service Worker</span>
                          <Trash2 className="w-4 h-4 text-amber-400" />
                        </div>
                        <p className="text-[11px] text-slate-400 leading-normal">
                          Efface les données temporaires mises en cache par le navigateur pour forcer un rechargement propre.
                        </p>
                      </div>
                      <button
                        type="button"
                        onClick={handleClearCache}
                        className="w-full py-2.5 px-3 rounded-lg text-xs font-semibold bg-white/10 hover:bg-white/20 text-slate-200 border border-white/10 transition-all flex items-center justify-center gap-2"
                      >
                        <Trash2 className="w-3.5 h-3.5 text-amber-400" />
                        Vider le Cache & Recharger
                      </button>
                    </div>

                    {/* Reset Configuration Card */}
                    <div className="bg-white/5 border border-white/10 rounded-xl p-4 flex flex-col justify-between space-y-4">
                      <div>
                        <div className="flex items-center justify-between mb-2">
                          <span className="text-xs font-semibold text-slate-300">Restaurer les Valeurs</span>
                          <RotateCcw className="w-4 h-4 text-slate-400" />
                        </div>
                        <p className="text-[11px] text-slate-400 leading-normal">
                          Restaure les paramètres d'origine recommandés pour la marketplace.
                        </p>
                      </div>
                      <button
                        type="button"
                        onClick={async () => {
                          const confirmed = await askConfirm(
                            "Restaurer les réglages par défaut ?",
                            "Les valeurs recommandées seront réappliquées dans le formulaire."
                          );
                          if (!confirmed) return;
                          localStorage.removeItem('fatibara_admin_settings');
                          setPlatformSettings({
                            commission: '2',
                            withdrawalDelay: '4',
                            referralBonus: '5000',
                            minWithdrawal: '15000',
                            maintenanceMode: 'false',
                            maxWithdrawalDaily: '10000000',
                            supportContact: 'support@fatibara.gn',
                            supportWhatsapp: '224613101091',
                            supportPhone: '+224 613 10 10 91',
                          });
                          showToast("Valeurs standards restaurées.", "info");
                        }}
                        className="w-full py-2.5 px-3 rounded-lg text-xs font-semibold bg-white/10 hover:bg-white/20 text-slate-200 border border-white/10 transition-all flex items-center justify-center gap-2"
                      >
                        <RotateCcw className="w-3.5 h-3.5" />
                        Rétablir les Défauts
                      </button>
                    </div>
                  </div>
                </div>
              </motion.div>
            )}

            {activeTab === 'logs' && (
              <motion.div 
                key="logs"
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -15 }}
                transition={{ duration: 0.3 }}
                className="space-y-6"
              >
                <div className="bg-white dark:bg-[#111622] border border-slate-200 dark:border-white/5 rounded-3xl p-6 lg:p-8 shadow-sm dark:shadow-md relative overflow-hidden">
                  <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-8">
                    <div>
                      <h2 className="text-xl font-bold text-slate-800 dark:text-white flex items-center gap-3">
                        <Activity className="w-5 h-5 text-orange-500 animate-pulse" /> Moniteur d'Activité & Audit
                      </h2>
                      <p className="text-[10px] font-semibold text-slate-400 dark:text-slate-500 uppercase mt-0.5">Surveillance en temps réel des actions système</p>
                    </div>
                    <button className="px-4 py-2 bg-slate-100 hover:bg-slate-200 dark:bg-white/5 dark:hover:bg-white/10 text-slate-700 dark:text-white/60 border border-slate-200 dark:border-white/10 rounded-xl text-[10px] font-bold tracking-wider uppercase transition-all">
                      Archiver le Flux
                    </button>
                  </div>

                  <div className="space-y-3 font-mono">
                    {auditLogs.length > 0 ? auditLogs.map((log, i) => {
                      const logActionName = String(log.action || log.new_data?.action || 'ACTION');
                      return (
                      <div 
                        key={i} 
                        onClick={() => setSelectedLog(log)}
                        className="flex items-center gap-4 p-4 bg-slate-50 dark:bg-white/[0.01] rounded-xl border border-slate-200 dark:border-white/5 group hover:border-[#ff6600]/30 hover:bg-slate-100 dark:hover:bg-white/[0.03] transition-all cursor-pointer"
                      >
                        <div className={`w-2.5 h-2.5 rounded-full ${
                          logActionName.includes('DELETE') ? 'bg-red-500' :
                          logActionName.includes('UPDATE') ? 'bg-amber-500' :
                          logActionName.includes('VERIFY') ? 'bg-emerald-500' :
                          'bg-[#ff6600]'
                        }`} />
                        <span className="text-[11px] font-bold text-slate-400 dark:text-white/30 tracking-wider tabular-nums">
                          {new Date(log.created_at).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit', second:'2-digit'})}
                        </span>
                        <div className="flex-grow">
                          <p className="text-[13px] font-bold tracking-tight text-slate-800 dark:text-white/80 uppercase">
                            <span className="text-orange-500 mr-2">[{logActionName}]</span>
                            {log.entity_type} <span className="text-slate-400 dark:text-white/20 text-[10px]">#{log.entity_id?.substring(0,8)}</span>
                          </p>
                          <p className="text-[10px] font-semibold text-slate-400 dark:text-slate-500 mt-0.5 uppercase tracking-wider">
                            Opérateur : {allUsers.find(u => u.id === log.user_id)?.full_name || log.user_id?.substring(0, 8) || 'Système'}
                          </p>
                        </div>
                        <div className="hidden xl:block">
                           <span className="text-[10px] font-bold text-slate-400 dark:text-white/10 tracking-wider uppercase">{new Date(log.created_at).toLocaleDateString()}</span>
                        </div>
                      </div>
                    );}) : (
                      <div className="py-20 text-center text-[10px] font-bold text-slate-400 dark:text-white/20 tracking-widest uppercase">Aucun log d'activité détecté</div>
                    )}
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                   <div className="bg-white dark:bg-[#111622] border border-slate-200 dark:border-white/5 rounded-3xl p-6 shadow-sm dark:shadow-md group hover:border-emerald-500/30 transition-all duration-300 overflow-hidden relative">
                     <h3 className="text-[10px] font-bold text-slate-400 dark:text-white/20 tracking-wider mb-6 uppercase">Disponibilité Plateforme</h3>
                     <div className="flex items-center gap-6">
                        <div className="w-14 h-14 bg-emerald-500/10 rounded-2xl border border-emerald-500/20 flex items-center justify-center shadow-sm transition-all duration-300">
                           <Monitor className="w-6 h-6 text-emerald-500" />
                        </div>
                        <div>
                           <p className="text-3xl font-extrabold text-slate-800 dark:text-white tracking-tight leading-none mb-1">99.98%</p>
                           <p className="text-[10px] font-semibold text-slate-400 dark:text-white/10 tracking-wider uppercase">Stabilité du réseau Fatibara</p>
                        </div>
                     </div>
                   </div>
                   <div className="bg-white dark:bg-[#111622] border border-slate-200 dark:border-white/5 rounded-3xl p-6 shadow-sm dark:shadow-md group hover:border-[#ff6600]/30 transition-all duration-300 overflow-hidden relative">
                     <h3 className="text-[10px] font-bold text-slate-400 dark:text-white/20 tracking-wider mb-6 uppercase">Version Logicielle</h3>
                     <div className="flex items-center gap-6">
                        <div className="w-14 h-14 bg-[#ff6600]/10 rounded-2xl border border-[#ff6600]/20 flex items-center justify-center shadow-sm transition-all duration-300">
                           <ShieldAlert className="w-6 h-6 text-orange-500" />
                        </div>
                        <div>
                           <p className="text-3xl font-extrabold text-slate-800 dark:text-white tracking-tight leading-none mb-1">V2.0.0</p>
                           <p className="text-[10px] font-semibold text-slate-400 dark:text-white/15 tracking-wider uppercase">{PARENT_BRAND}</p>
                        </div>
                     </div>
                   </div>
                </div>
              </motion.div>
            )}

            {activeTab === 'announcements' && (
              <motion.div 
                key="announcements"
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -15 }}
                transition={{ duration: 0.3 }}
                className="space-y-8"
              >
                 <div className="bg-white dark:bg-[#111622] border border-slate-200 dark:border-white/5 rounded-3xl p-6 lg:p-8 shadow-sm dark:shadow-md relative overflow-hidden group">
                    <h2 className="text-xl font-bold text-slate-800 dark:text-white mb-2 flex items-center gap-3">
                      <Mail className="w-6 h-6 text-orange-500 animate-bounce" /> Diffuser une Annonce
                    </h2>
                    <p className="text-[10px] font-semibold text-slate-400 dark:text-slate-500 uppercase mb-8">Publication de messages sur le réseau {APP_NAME}</p>
                    
                    <div className="space-y-6">
                       <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                          <div>
                             <label className="text-[10px] font-bold text-slate-400 dark:text-white/20 tracking-wider mb-2 block uppercase">Titre du message</label>
                             <input 
                               type="text" 
                               value={newAnnouncement.title}
                               onChange={(e) => setNewAnnouncement({...newAnnouncement, title: e.target.value})}
                               className="w-full bg-slate-50 dark:bg-white/[0.03] border border-slate-200 dark:border-white/10 rounded-2xl px-5 py-3.5 text-slate-800 dark:text-white font-semibold tracking-wide outline-none focus:border-[#ff6600]/50 transition-all placeholder:text-slate-400 dark:placeholder:text-white/15" 
                               placeholder="Entrez le titre..." 
                             />
                          </div>
                          <div>
                             <label className="text-[10px] font-bold text-slate-400 dark:text-white/20 tracking-wider mb-2 block uppercase">Audience cible</label>
                             <select 
                               value={newAnnouncement.target}
                               onChange={(e) => setNewAnnouncement({...newAnnouncement, target: e.target.value})}
                               className="w-full bg-slate-50 dark:bg-white/[0.03] border border-slate-200 dark:border-white/10 rounded-2xl px-5 py-3.5 text-slate-800 dark:text-white font-semibold tracking-wide outline-none focus:border-[#ff6600]/50 transition-all"
                             >
                                <option value="all">Tout le monde</option>
                                <option value="vendor">Boutiques uniquement</option>
                                <option value="user">Clients uniquement</option>
                             </select>
                          </div>
                       </div>
                       <div>
                          <label className="text-[10px] font-bold text-slate-400 dark:text-white/20 tracking-wider mb-2 block uppercase">Contenu du message</label>
                          <textarea 
                            value={newAnnouncement.content}
                            onChange={(e) => setNewAnnouncement({...newAnnouncement, content: e.target.value})}
                            className="w-full bg-slate-50 dark:bg-white/[0.03] border border-slate-200 dark:border-white/10 rounded-3xl p-5 text-slate-800 dark:text-white font-medium text-sm min-h-[150px] outline-none focus:border-[#ff6600]/50 transition-all placeholder:text-slate-400 dark:placeholder:text-white/15 leading-relaxed" 
                            placeholder="Saisissez votre annonce ici..." 
                          />
                       </div>
                       <div className="pt-2">
                          <button 
                            onClick={publishAnnouncement}
                            className="w-full bg-[#ff6600] text-white font-bold tracking-wider py-4 rounded-xl hover:bg-orange-600 active:scale-[0.98] transition-all shadow-sm"
                          >
                            Diffuser l'Annonce
                          </button>
                       </div>
                    </div>
                 </div>

                 <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {announcements.map(ann => (
                      <div key={ann.id} className="bg-white dark:bg-[#111622] border border-slate-200 dark:border-white/5 rounded-3xl p-6 group hover:border-[#ff6600]/30 transition-all duration-300 relative overflow-hidden shadow-sm dark:shadow-md">
                         <div className="flex justify-between items-start mb-6">
                            <div>
                               <h4 className="text-lg font-bold text-slate-800 dark:text-white mb-2 group-hover:text-orange-500 transition-colors">{ann.title}</h4>
                               <span className="px-2.5 py-1 bg-orange-500/10 text-orange-600 dark:text-orange-400 border border-orange-500/20 rounded-lg text-[9px] font-bold tracking-wider uppercase">Cible : {ann.target_role === 'vendor' ? 'Vendeurs' : ann.target_role === 'user' ? 'Clients' : 'Général'}</span>
                            </div>
                            <button 
                               onClick={() => deleteAnnouncement(ann.id)}
                               className="p-2.5 text-slate-400 hover:text-red-500 hover:bg-red-500/10 rounded-xl transition-all border border-slate-200 dark:border-white/10 active:scale-95 shadow-sm"
                            >
                               <Trash2 className="w-4 h-4" />
                            </button>
                         </div>
                         <p className="text-xs text-slate-600 dark:text-slate-400 mb-6 leading-relaxed line-clamp-3 group-hover:text-slate-700 dark:group-hover:text-slate-300 transition-colors">{ann.content}</p>
                         <div className="flex justify-between items-center text-[10px] font-bold text-slate-400 dark:text-white/20 tracking-wider uppercase pt-4 border-t border-slate-100 dark:border-white/5">
                            <span>ID: {ann.id.split('-')[0].toUpperCase()}</span>
                            <span>{new Date(ann.created_at).toLocaleDateString()}</span>
                         </div>
                      </div>
                    ))}
                 </div>

                 {/* ── Vendor Invitation Panel ─────────────────────────────── */}
                 <div className="mt-10 pt-8 border-t border-slate-100 dark:border-white/5">
                   <VendorInvitationPanel />
                 </div>
              </motion.div>
            )}

            {activeTab === 'system-health' && (
              <motion.div 
                key="system-health"
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -15 }}
                transition={{ duration: 0.3 }}
                className="space-y-6"
              >
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  <div className="bg-white dark:bg-[#111622] border border-slate-200 dark:border-white/5 rounded-3xl p-6 shadow-sm dark:shadow-md">
                    <h3 className="text-lg font-bold text-slate-800 dark:text-white mb-6">Santé des Composants</h3>
                    <div className="space-y-3">
                      {healthLogs.map((log: any) => (
                        <div key={log.id} className="flex justify-between items-center p-3.5 bg-slate-50 dark:bg-white/[0.02] border border-slate-200/50 dark:border-white/5 rounded-2xl">
                          <span className="font-semibold text-sm text-slate-700 dark:text-white/80">{log.component}</span>
                          <span className={`px-2 py-0.5 rounded-lg text-[9px] font-bold uppercase tracking-wider ${log.status === 'ok' ? 'bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 border border-emerald-500/20' : 'bg-red-500/15 text-red-600 dark:text-red-400 border border-red-500/20'}`}>{log.status}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                  <div className="bg-white dark:bg-[#111622] border border-slate-200 dark:border-white/5 rounded-3xl p-6 shadow-sm dark:shadow-md">
                    <h3 className="text-lg font-bold text-slate-800 dark:text-white mb-6">Tâches de Maintenance</h3>
                    <div className="space-y-3">
                      {housekeepingTasks.map((task: any) => (
                        <div key={task.id} className="flex justify-between items-center p-3.5 bg-slate-50 dark:bg-white/[0.02] border border-slate-200/50 dark:border-white/5 rounded-2xl">
                          <span className="font-semibold text-sm text-slate-700 dark:text-white/80">{task.task_name}</span>
                          <span className="px-2 py-0.5 bg-slate-100 dark:bg-white/5 border border-slate-200 dark:border-white/10 rounded-lg text-[9px] font-bold text-slate-500 dark:text-white/30 uppercase tracking-wider">{task.status}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </motion.div>
            )}

            {activeTab === 'applications' && (
              <motion.div
                key="applications"
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -15 }}
                transition={{ duration: 0.3 }}
              >
                <AdminApplicationsQueue
                  pendingVendors={allVendors
                    .filter(v => v.store_status === 'pending' || (!v.store_status && !v.is_verified_store))
                    .map(v => ({
                      ...v,
                      // Use joined owner profile data (from the select join)
                      owner_phone: v.owner?.phone_number || v.contact_phone || v.whatsapp_number || '',
                      // Authentication email is not exposed through public.profiles.
                      owner_email: '',
                      owner_name: v.owner?.full_name || v.store_name || '',
                    }))
                  }
                  pendingCouriers={allCouriers.filter(c => c.courier_status === 'inactive' && c.profile_type !== 'courier')}
                  supportWhatsapp={platformSettings.supportWhatsapp || '224666923393'}
                  onRefresh={fetchData}
                  onLogAction={logAction}
                  askPrompt={askPrompt}
                />
              </motion.div>
            )}

          </AnimatePresence>
        </div>
      </main>

      {/* Admin Custom Prompt Modal */}
      <AnimatePresence>
        {promptConfig?.isOpen && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[100] flex items-center justify-center p-6 bg-slate-900/60 dark:bg-black/80 backdrop-blur-sm"
            onClick={() => {
              promptConfig.resolve(null);
              setPromptConfig(null);
            }}
          >
            <motion.div 
              initial={{ scale: 0.95, opacity: 0, y: 15 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.95, opacity: 0, y: 15 }}
              onClick={(e) => e.stopPropagation()}
              className="bg-white dark:bg-[#111622] border border-slate-200 dark:border-white/10 p-6 lg:p-8 rounded-3xl w-full max-w-md flex flex-col gap-6 shadow-xl relative overflow-hidden"
            >
              <div>
                <h3 className="text-xl font-bold text-slate-800 dark:text-white mb-1">{promptConfig.title}</h3>
                {promptConfig.description && (
                  <p className="text-[10px] text-slate-400 dark:text-slate-500 font-bold uppercase tracking-wider">{promptConfig.description}</p>
                )}
              </div>
              
              <div className="relative">
                <input
                  id="adminPromptInput"
                  type="text"
                  autoFocus
                  className="w-full px-4 py-3 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-white/[0.03] text-slate-800 dark:text-white font-semibold focus:outline-none focus:border-[#ff6600] transition-all placeholder:text-slate-400 dark:placeholder:text-white/10 text-sm"
                  placeholder="Entrez la valeur..."
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') {
                      promptConfig.resolve((e.target as HTMLInputElement).value);
                      setPromptConfig(null);
                    }
                  }}
                />
              </div>
              
              <div className="flex gap-4">
                <button
                  onClick={() => {
                    promptConfig.resolve(null);
                    setPromptConfig(null);
                  }}
                  className="flex-1 py-2.5 px-4 rounded-xl font-bold text-[10px] tracking-wider text-slate-500 dark:text-white/40 hover:bg-slate-100 dark:hover:bg-white/5 transition-all uppercase"
                >
                  Annuler
                </button>
                <button
                  onClick={() => {
                    const input = document.getElementById('adminPromptInput') as HTMLInputElement;
                    promptConfig.resolve(input.value);
                    setPromptConfig(null);
                  }}
                  className="flex-1 py-2.5 px-4 rounded-xl font-bold text-[10px] tracking-wider text-white bg-[#ff6600] hover:bg-orange-600 transition-all shadow-sm uppercase"
                >
                  Valider
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}

        {confirmConfig?.isOpen && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[100] flex items-center justify-center p-6 bg-slate-900/60 dark:bg-black/80 backdrop-blur-sm"
            onClick={() => {
              confirmConfig.resolve(false);
              setConfirmConfig(null);
            }}
          >
            <motion.div 
              initial={{ scale: 0.95, opacity: 0, y: 15 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.95, opacity: 0, y: 15 }}
              onClick={(e) => e.stopPropagation()}
              className="bg-white dark:bg-[#111622] border border-slate-200 dark:border-white/10 p-6 lg:p-8 rounded-3xl w-full max-w-md flex flex-col gap-6 shadow-xl text-center relative overflow-hidden"
            >
              <div className="w-14 h-14 bg-red-500/10 border border-red-500/20 rounded-2xl flex items-center justify-center mx-auto shadow-sm animate-pulse">
                <AlertTriangle className="w-8 h-8 text-red-500" />
              </div>
              
              <div>
                <h3 className="text-xl font-bold text-slate-800 dark:text-white mb-2">{confirmConfig.title}</h3>
                {confirmConfig.description && (
                  <p className="text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider leading-relaxed">{confirmConfig.description}</p>
                )}
              </div>
              
              <div className="flex gap-4 mt-2">
                <button
                  onClick={() => {
                    confirmConfig.resolve(false);
                    setConfirmConfig(null);
                  }}
                  className="flex-1 py-2.5 px-4 rounded-xl font-bold text-[10px] tracking-wider text-slate-500 dark:text-white/40 hover:bg-slate-100 dark:hover:bg-white/5 transition-all uppercase"
                >
                  Annuler
                </button>
                <button
                  onClick={() => {
                    confirmConfig.resolve(true);
                    setConfirmConfig(null);
                  }}
                  className="flex-1 py-2.5 px-4 rounded-xl font-bold text-[10px] tracking-wider text-white bg-red-600 hover:bg-red-700 transition-all shadow-sm uppercase"
                >
                  Confirmer
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Audit Log Detail Modal */}
        <AnimatePresence>
          {selectedLog && (
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 z-[110] flex items-center justify-center p-6 bg-slate-900/60 dark:bg-black/80 backdrop-blur-sm"
              onClick={() => setSelectedLog(null)}
            >
              <motion.div 
                initial={{ scale: 0.95, opacity: 0, y: 15 }}
                animate={{ scale: 1, opacity: 1, y: 0 }}
                exit={{ scale: 0.95, opacity: 0, y: 15 }}
                onClick={(e) => e.stopPropagation()}
                className="bg-white dark:bg-[#111622] border border-slate-200 dark:border-white/10 p-6 lg:p-8 rounded-3xl w-full max-w-2xl flex flex-col gap-6 shadow-xl relative overflow-hidden"
              >
                <div className="flex justify-between items-start">
                  <div>
                    <h3 className="text-xl font-bold text-slate-800 dark:text-white">Détails de l'Audit</h3>
                    <p className="text-[10px] text-slate-400 dark:text-white/40 font-semibold tracking-wider uppercase mt-0.5">ID Log : {selectedLog.id}</p>
                  </div>
                  <button onClick={() => setSelectedLog(null)} className="p-2 bg-slate-50 dark:bg-white/5 border border-slate-200 dark:border-white/10 rounded-xl hover:bg-red-500/10 hover:text-red-500 text-slate-400 transition-all">
                    <X className="w-5 h-5" />
                  </button>
                </div>
                
                <div className="grid grid-cols-2 gap-4 bg-slate-50 dark:bg-white/[0.02] p-5 rounded-2xl border border-slate-200/50 dark:border-white/5">
                  <div>
                    <span className="block text-[10px] font-bold text-slate-400 dark:text-white/20 uppercase tracking-wider mb-0.5">Action</span>
                    <span className="text-orange-500 font-bold uppercase">[{selectedLog.action}]</span>
                  </div>
                  <div>
                    <span className="block text-[10px] font-bold text-slate-400 dark:text-white/20 uppercase tracking-wider mb-0.5">Date & Heure</span>
                    <span className="text-slate-800 dark:text-white font-bold">{new Date(selectedLog.created_at).toLocaleString()}</span>
                  </div>
                  <div>
                    <span className="block text-[10px] font-bold text-slate-400 dark:text-white/20 uppercase tracking-wider mb-0.5">Type d'entité</span>
                    <span className="text-slate-800 dark:text-white font-bold">{selectedLog.entity_type}</span>
                  </div>
                  <div>
                    <span className="block text-[10px] font-bold text-slate-400 dark:text-white/20 uppercase tracking-wider mb-0.5">ID Cible</span>
                    <span className="text-slate-800 dark:text-white font-mono text-xs truncate max-w-[200px]" title={selectedLog.entity_id}>{selectedLog.entity_id}</span>
                  </div>
                </div>
                
                <div className="space-y-2">
                  <span className="block text-[10px] font-bold text-slate-400 dark:text-white/20 uppercase tracking-wider">Données modifiées (Payload)</span>
                  <div className="bg-slate-900 border border-slate-950 p-4 rounded-2xl overflow-auto max-h-[250px] custom-scrollbar">
                    <pre className="text-emerald-400 font-mono text-[11px] leading-relaxed">
                      {JSON.stringify(selectedLog.new_data, null, 2)}
                    </pre>
                  </div>
                </div>

                <div className="pt-2 flex justify-end">
                   <button 
                     onClick={() => setSelectedLog(null)}
                     className="px-6 py-2.5 bg-slate-800 text-white dark:bg-white dark:text-black rounded-xl text-[10px] font-bold tracking-wider uppercase hover:bg-[#ff6600] dark:hover:bg-[#ff6600] hover:text-white dark:hover:text-white transition-all shadow-sm active:scale-95"
                   >
                     Fermer
                   </button>
                </div>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}

function StatCard({ label, value, icon: Icon, trend, color = 'primary' }: any) {
  const colorClasses: any = {
    primary: 'text-[#ff6600] bg-[#ff6600]/10 border-[#ff6600]/20 shadow-sm',
    blue: 'text-blue-500 bg-blue-500/10 border-blue-500/20 shadow-sm',
    green: 'text-emerald-500 bg-emerald-500/10 border-emerald-500/20 shadow-sm',
    purple: 'text-purple-500 bg-purple-500/10 border-purple-500/20 shadow-sm'
  };

  const trendColor = trend.includes('+') ? 'text-emerald-500' : 'text-slate-400 dark:text-white/30';

  return (
    <div className="bg-white dark:bg-[#111622] p-6 lg:p-8 rounded-3xl border border-slate-200 dark:border-white/5 shadow-sm dark:shadow-md relative overflow-hidden group hover:border-[#ff6600]/50 dark:hover:border-[#ff6600]/50 transition-all duration-300">
      <div className={`absolute -right-12 -top-12 w-48 h-48 opacity-[0.03] dark:opacity-[0.05] rounded-full blur-[80px] group-hover:opacity-[0.08] dark:group-hover:opacity-[0.15] transition-all duration-1000 ${
        color === 'primary' ? 'bg-[#ff6600]' : color === 'blue' ? 'bg-blue-400' : 'bg-emerald-400'
      }`} />
      
      <div className="flex justify-between items-start mb-6 relative z-10">
        <div className={`w-12 h-12 rounded-2xl border flex items-center justify-center transition-all duration-500 shadow-sm group-hover:scale-105 ${colorClasses[color]}`}>
          <Icon className="w-5 h-5" />
        </div>
        <div className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-slate-50 dark:bg-white/[0.03] border border-slate-200 dark:border-white/10 ${trendColor} text-[9px] font-bold tracking-wider uppercase`}>
          <TrendingUp className="w-3.5 h-3.5" />
          {trend}
        </div>
      </div>
      
      <div className="relative z-10">
        <h3 className="text-[10px] font-bold tracking-wider text-slate-400 dark:text-white/30 mb-2 uppercase group-hover:text-slate-500 dark:group-hover:text-white/50 transition-colors">{label}</h3>
        <p className="text-3xl font-extrabold text-slate-800 dark:text-white tracking-tight leading-none flex items-baseline gap-2">
           {value}
           <span className="w-1.5 h-1.5 rounded-full bg-[#ff6600] animate-pulse" />
        </p>
      </div>
      
      <div className="mt-6 h-1 w-full bg-slate-100 dark:bg-white/[0.03] rounded-full overflow-hidden relative z-10">
         <motion.div 
           initial={{ width: 0 }}
           animate={{ width: '75%' }}
           transition={{ duration: 1.5, ease: "easeOut" }}
           className={`h-full ${color === 'primary' ? 'bg-[#ff6600] shadow-[0_0_10px_rgba(255,102,0,0.3)]' : 'bg-slate-300 dark:bg-white/20'}`}
         />
      </div>
    </div>
  );
}

function DataCell({ children, label }: any) {
  return (
    <div className="p-4 lg:p-6 border border-slate-200 dark:border-white/5 rounded-2xl bg-slate-50 dark:bg-white/[0.01] group hover:bg-slate-100 dark:hover:bg-white/[0.03] transition-all hover:border-[#ff6600]/30">
      <div className="text-[9px] font-bold text-slate-400 dark:text-white/30 uppercase tracking-widest mb-1.5 group-hover:text-orange-500 transition-colors">{label}</div>
      <div className="text-slate-800 dark:text-white font-bold tracking-wider uppercase text-[12px] lg:text-[13px]">{children}</div>
    </div>
  );
}

function AdminTable({ headers, children }: { headers: string[], children: React.ReactNode }) {
  return (
    <div className="bg-white dark:bg-[#111622] border border-slate-200 dark:border-white/10 rounded-2xl lg:rounded-[2rem] overflow-hidden shadow-sm dark:shadow-md relative">
      <div className="absolute top-0 left-0 w-full h-[1px] bg-gradient-to-r from-transparent via-[#ff6600]/30 to-transparent" />
      <div className="overflow-x-auto custom-scrollbar">
        <table className="w-full text-left border-collapse min-w-full">
          <thead>
            <tr className="border-b border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-white/[0.01]">
              {headers.map((h) => (
                <th key={h} className="px-6 py-4 lg:px-8 lg:py-5 text-[10px] lg:text-[11px] font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">{h}</th>
              ))}
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 dark:divide-white/5 text-slate-700 dark:text-slate-300">
            {children}
          </tbody>
        </table>
      </div>
    </div>
  );
}

interface SettingFieldProps {
  label: string;
  value: string | number;
  onChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
  description?: string;
  suffix?: string;
  prefix?: string;
  placeholder?: string;
  type?: string;
  icon?: any;
}

function SettingField({
  label,
  value,
  onChange,
  description,
  suffix,
  prefix,
  placeholder,
  type = 'text',
  icon: Icon,
}: SettingFieldProps) {
  return (
    <div className="group space-y-1.5">
      <div className="flex items-center justify-between">
        <label className="text-xs font-semibold text-slate-700 dark:text-slate-200 group-focus-within:text-[#ff6600] transition-colors flex items-center gap-1.5">
          {Icon && <Icon className="w-3.5 h-3.5 text-slate-400 dark:text-slate-500 group-focus-within:text-[#ff6600] transition-colors" />}
          {label}
        </label>
        {suffix && (
          <span className="text-[11px] font-mono font-medium text-slate-400 dark:text-slate-500">
            {suffix}
          </span>
        )}
      </div>

      <div className="relative flex items-center">
        {prefix && (
          <div className="absolute left-3.5 text-xs font-semibold text-slate-400 dark:text-slate-500 select-none pointer-events-none">
            {prefix}
          </div>
        )}
        <input
          type={type}
          value={value ?? ''}
          onChange={onChange}
          placeholder={placeholder || 'Entrez la valeur…'}
          className={`w-full bg-slate-50 dark:bg-white/[0.04] border border-slate-200 dark:border-white/10 rounded-xl py-2.5 text-sm font-semibold text-slate-800 dark:text-white placeholder:text-slate-400 dark:placeholder:text-white/20 focus:outline-none focus:border-[#ff6600] focus:ring-2 focus:ring-[#ff6600]/15 transition-all ${
            prefix ? 'pl-9 pr-4' : 'px-3.5'
          } ${suffix ? 'pr-14' : ''}`}
        />
        {suffix && (
          <div className="absolute right-3.5 text-xs font-semibold text-slate-400 dark:text-slate-500 select-none pointer-events-none">
            {suffix}
          </div>
        )}
      </div>

      {description && (
        <p className="text-[11px] text-slate-500 dark:text-slate-400 leading-relaxed">
          {description}
        </p>
      )}
    </div>
  );
}

function QuickActionTile({ label, count, onClick, icon: Icon, color }: any) {
  const colorClasses: any = {
    indigo: 'text-[#ff6600] hover:bg-[#ff6600] hover:text-white',
    amber: 'text-amber-500 hover:bg-amber-600 hover:text-white',
    emerald: 'text-emerald-500 hover:bg-emerald-600 hover:text-white',
    blue: 'text-blue-500 hover:bg-blue-600 hover:text-white',
  };

  return (
    <button 
      onClick={onClick}
      className={`p-6 lg:p-8 rounded-2xl border transition-all duration-300 flex flex-col gap-6 text-left group relative overflow-hidden bg-slate-50 dark:bg-white/[0.02] border-slate-200 dark:border-white/5 hover:border-[#ff6600]/30 dark:hover:border-[#ff6600]/30 hover:shadow-md hover:bg-white dark:hover:bg-white/[0.04] ${colorClasses[color]}`}
    >
      <div className="flex justify-between items-start relative z-10">
        <div className="p-3 bg-slate-200/50 dark:bg-black/20 rounded-xl">
          <Icon className="w-5 h-5 opacity-80 group-hover:opacity-100 group-hover:scale-105 transition-all duration-300" />
        </div>
        {count > 0 && Number(count) !== 0 && (
          <motion.span 
            animate={{ opacity: [0.6, 1, 0.6] }}
            transition={{ duration: 2, repeat: Infinity }}
            className="px-2 py-0.5 bg-[#ff6600]/10 dark:bg-white/10 rounded text-[9px] font-bold tracking-wider text-[#ff6600] dark:text-white/60"
          >
            ACTIF
          </motion.span>
        )}
      </div>
      <div className="relative z-10">
        <span className="text-[10px] font-bold uppercase tracking-wider block mb-1 opacity-50 group-hover:opacity-75 transition-opacity">{label}</span>
        <div className="flex items-baseline gap-3">
          <span className="text-3xl font-extrabold tracking-tight text-slate-800 dark:text-white">{count}</span>
          <span className="text-[9px] font-bold uppercase tracking-wider opacity-30 group-hover:opacity-50 transition-opacity text-slate-400 dark:text-white/30">En attente</span>
        </div>
      </div>
      
      <div className="absolute -right-8 -bottom-8 w-24 h-24 bg-white/5 blur-2xl rounded-full opacity-0 group-hover:opacity-100 transition-opacity duration-700" />
    </button>
  );
}
