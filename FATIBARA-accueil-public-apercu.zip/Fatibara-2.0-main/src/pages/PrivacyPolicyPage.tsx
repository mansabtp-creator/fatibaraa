import React, { useEffect } from 'react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import SEO from '../components/SEO';
import { APP_NAME } from '../lib/constants';
import { Shield, Eye, Lock, Database, Globe, Mail } from 'lucide-react';

export default function PrivacyPolicyPage() {
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  const lastUpdated = '23 Juillet 2026';

  return (
    <div className="min-h-screen flex flex-col bg-gray-50 transition-colors duration-500">
      <SEO
        title={`Politique de Confidentialité | ${APP_NAME}`}
        description={`Découvrez comment ${APP_NAME} collecte, utilise et protège vos données personnelles. Marketplace en Guinée respectueuse de votre vie privée.`}
      />
      <Header />

      <main className="flex-grow pt-10 pb-20 border-t border-gray-100">
        <div className="max-w-4xl mx-auto px-4 md:px-10 mt-12">

          {/* Page header */}
          <div className="text-center mb-16">
            <div className="w-24 h-24 bg-orange-50 rounded-3xl flex items-center justify-center mx-auto mb-6 text-[#ff6600] shadow-sm border border-orange-100">
              <Shield className="w-12 h-12" />
            </div>
            <h1 className="text-3xl md:text-5xl font-bold text-gray-900 tracking-tight mb-4 leading-tight">
              Politique de<br />Confidentialité
            </h1>
            <p className="text-gray-500 font-medium">Dernière mise à jour : {lastUpdated}</p>
          </div>

          {/* Quick summary */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-14">
            {[
              { icon: Eye, title: 'Transparence', desc: 'Nous vous disons exactement quelles données nous collectons et pourquoi.' },
              { icon: Lock, title: 'Sécurité', desc: 'Vos données sont stockées de manière chiffrée sur des serveurs sécurisés.' },
              { icon: Globe, title: 'Contrôle', desc: 'Vous pouvez demander la suppression de vos données à tout moment.' },
            ].map(({ icon: Icon, title, desc }) => (
              <div key={title} className="bg-white border border-gray-100 rounded-2xl p-5 text-center shadow-sm">
                <div className="w-10 h-10 bg-orange-50 rounded-xl flex items-center justify-center mx-auto mb-3 text-[#ff6600]">
                  <Icon className="w-5 h-5" />
                </div>
                <h3 className="font-black text-gray-900 text-[14px] mb-1">{title}</h3>
                <p className="text-[12px] text-gray-500 font-medium leading-relaxed">{desc}</p>
              </div>
            ))}
          </div>

          {/* Content sections */}
          <div className="space-y-10">

            <Section title="1. Qui sommes-nous ?">
              <p>
                {APP_NAME} est une marketplace en ligne opérant en République de Guinée. Notre siège social est situé à Conakry, Guinée.
                Pour toute question relative à la protection de vos données, contactez-nous à : <a href="mailto:privacy@fatibara.com" className="text-[#ff6600] font-bold hover:underline">privacy@fatibara.com</a>.
              </p>
            </Section>

            <Section title="2. Données que nous collectons">
              <ul className="list-disc pl-5 space-y-2">
                <li><strong>Données de compte :</strong> nom complet, adresse e-mail, numéro de téléphone lors de l'inscription.</li>
                <li><strong>Données de profil :</strong> photo de profil, adresse de livraison, préférences de langue.</li>
                <li><strong>Données de transaction :</strong> historique des commandes, montants, modes de paiement utilisés (Mobile Money).</li>
                <li><strong>Données techniques :</strong> adresse IP, type de navigateur, pages visitées, durée de session (via cookies et analytics).</li>
                <li><strong>Données vendeur :</strong> nom de boutique, catalogue de produits, coordonnées bancaires ou Mobile Money pour les reversements.</li>
              </ul>
            </Section>

            <Section title="3. Finalités du traitement">
              <ul className="list-disc pl-5 space-y-2">
                <li>Traitement et livraison des commandes.</li>
                <li>Vérification des identités vendeurs (conformité KYC).</li>
                <li>Prévention de la fraude et sécurisation des transactions Mobile Money.</li>
                <li>Amélioration de notre service via l'analyse d'usage (Google Analytics 4).</li>
                <li>Communication par e-mail ou SMS pour les mises à jour de commande.</li>
                <li>Affichage de recommandations personnalisées.</li>
              </ul>
            </Section>

            <Section title="4. Base légale du traitement">
              <ul className="list-disc pl-5 space-y-2">
                <li><strong>Exécution du contrat :</strong> traitement des commandes, versements vendeurs.</li>
                <li><strong>Intérêt légitime :</strong> sécurité, prévention de la fraude, amélioration du service.</li>
                <li><strong>Consentement :</strong> notifications marketing, cookies analytiques non essentiels.</li>
                <li><strong>Obligation légale :</strong> conservation des données financières conformément à la réglementation guinéenne.</li>
              </ul>
            </Section>

            <Section title="5. Partage de vos données">
              <p>
                Nous ne vendons jamais vos données personnelles. Nous pouvons les partager uniquement avec :
              </p>
              <ul className="list-disc pl-5 space-y-2 mt-3">
                <li><strong>Prestataires de paiement :</strong> Lengo Pay, Orange Money, MTN MoMo pour le traitement des paiements.</li>
                <li><strong>Hébergement :</strong> Supabase (serveurs en Union Européenne) et Vercel (CDN mondial).</li>
                <li><strong>Analytics :</strong> Google Analytics 4 (données anonymisées).</li>
                <li><strong>Vendeurs :</strong> votre nom et adresse de livraison pour l'expédition de vos commandes.</li>
                <li><strong>Autorités compétentes :</strong> uniquement sur réquisition légale.</li>
              </ul>
            </Section>

            <Section title="6. Conservation des données">
              <ul className="list-disc pl-5 space-y-2">
                <li>Données de compte : conservées pendant la durée d'activité du compte + 2 ans après fermeture.</li>
                <li>Données de transaction : 5 ans (obligation comptable).</li>
                <li>Logs techniques : 90 jours.</li>
                <li>Cookies non essentiels : 13 mois maximum.</li>
              </ul>
            </Section>

            <Section title="7. Vos droits">
              <p>Conformément à la loi applicable, vous disposez des droits suivants :</p>
              <ul className="list-disc pl-5 space-y-2 mt-3">
                <li><strong>Droit d'accès :</strong> obtenir une copie de vos données personnelles.</li>
                <li><strong>Droit de rectification :</strong> corriger des données inexactes.</li>
                <li><strong>Droit à l'effacement :</strong> demander la suppression de votre compte et de vos données.</li>
                <li><strong>Droit à la portabilité :</strong> recevoir vos données dans un format structuré.</li>
                <li><strong>Droit d'opposition :</strong> vous opposer au marketing direct à tout moment.</li>
              </ul>
              <p className="mt-3">
                Pour exercer ces droits, écrivez à : <a href="mailto:privacy@fatibara.com" className="text-[#ff6600] font-bold hover:underline">privacy@fatibara.com</a>.
                Nous répondons dans un délai de 30 jours.
              </p>
            </Section>

            <Section title="8. Cookies">
              <p>
                Nous utilisons des cookies essentiels (authentification, panier) et des cookies analytiques (Google Analytics 4, Vercel Speed Insights).
                Vous pouvez refuser les cookies non essentiels via les paramètres de votre navigateur.
                Les cookies essentiels ne peuvent pas être désactivés sans impacter le fonctionnement du site.
              </p>
            </Section>

            <Section title="9. Sécurité">
              <p>
                Vos données sont protégées par chiffrement TLS en transit et au repos. Nos bases de données sont sécurisées
                via Row Level Security (RLS) Supabase. Seuls les employés autorisés y accèdent selon le principe du moindre privilège.
                En cas de violation de données, nous vous notifierons dans les 72 heures.
              </p>
            </Section>

            <Section title="10. Modifications de cette politique">
              <p>
                Nous pouvons mettre à jour cette politique. En cas de modification substantielle, nous vous notifierons par e-mail
                et afficherons une bannière sur le site. La date de dernière mise à jour est indiquée en haut de cette page.
              </p>
            </Section>

            {/* Contact */}
            <div className="bg-orange-50 border border-orange-100 rounded-2xl p-6 flex items-start gap-4">
              <div className="w-10 h-10 bg-[#ff6600] rounded-xl flex items-center justify-center text-white shrink-0">
                <Mail className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-black text-gray-900 mb-1">Des questions ?</h3>
                <p className="text-[13px] text-gray-600 font-medium">
                  Contactez notre équipe de protection des données à{' '}
                  <a href="mailto:privacy@fatibara.com" className="text-[#ff6600] font-bold hover:underline">
                    privacy@fatibara.com
                  </a>.
                </p>
              </div>
            </div>

          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}

// ─── Section helper ───────────────────────────────────────────────────────────

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <section>
      <div className="flex items-center gap-3 mb-4">
        <Database className="w-5 h-5 text-[#ff6600] shrink-0" />
        <h2 className="text-lg font-black text-gray-900 tracking-tight">{title}</h2>
      </div>
      <div className="pl-8 text-[14px] text-gray-600 font-medium leading-relaxed space-y-2">
        {children}
      </div>
    </section>
  );
}
