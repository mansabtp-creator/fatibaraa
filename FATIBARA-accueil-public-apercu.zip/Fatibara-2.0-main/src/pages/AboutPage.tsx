import React, { useEffect } from 'react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import SEO from '../components/SEO';
import { 
  Store, 
  Utensils, 
  Ticket, 
  PiggyBank, 
  Link as LinkIcon, 
  Globe, 
  Rocket, 
  Phone, 
  CheckCircle2,
  Truck,
  CalendarDays,
  Crown,
  Eye,
  Flag,
  Sparkles
} from 'lucide-react';
import { 
  PARENT_BRAND
} from '../lib/constants';

const FILIALES = [
  { 
    name: "FATIBARA E-COMMERCE", 
    tag: "E-COMMERCE",
    desc: "Permet aux commerçants et aux consommateurs d'acheter et de vendre facilement des produits et services, même sans boutique physique.", 
    icon: Store, 
    color: "text-[#ff6600]", 
    bg: "bg-orange-50",
    border: "border-orange-100"
  },
  { 
    name: "FATINÈMA", 
    tag: "FOOD DELIVERY",
    desc: "Une plateforme de commande et de livraison de repas permettant aux utilisateurs de découvrir et de savourer les spécialités locales et internationales.", 
    icon: Utensils, 
    color: "text-orange-500", 
    bg: "bg-orange-50",
    border: "border-orange-100"
  },
  { 
    name: "FATI-BILLETS", 
    tag: "TICKETING",
    desc: "Une solution moderne de billetterie en ligne permettant l'achat sécurisé de billets pour les concerts, matchs, festivals, spectacles et autres événements.", 
    icon: Ticket, 
    color: "text-purple-500", 
    bg: "bg-purple-50",
    border: "border-purple-100"
  },
  { 
    name: "FATI-TONTINE", 
    tag: "FINTECH",
    desc: "Une plateforme digitale dédiée à la gestion des tontines et de l'épargne communautaire, favorisant l'inclusion financière et la solidarité.", 
    icon: PiggyBank, 
    color: "text-emerald-500", 
    bg: "bg-emerald-50",
    border: "border-emerald-100"
  },
  { 
    name: "FATI-LINK", 
    tag: "NETWORKING",
    desc: "Un réseau de mise en relation qui connecte entreprises, professionnels et particuliers afin de créer des opportunités d'affaires, de partenariats et de services.", 
    icon: LinkIcon, 
    color: "text-blue-500", 
    bg: "bg-blue-50",
    border: "border-blue-100"
  },
  { 
    name: "FATI-TRANSPORT", 
    tag: "TRANSPORT & LOGISTIQUE",
    desc: "Une plateforme innovante dédiée aux services de transport et de logistique, facilitant le déplacement des personnes ainsi que l'acheminement des marchandises. FATI-TRANSPORT ambitionne de moderniser la mobilité et de simplifier les échanges commerciaux grâce à des solutions fiables, accessibles et efficaces.", 
    icon: Truck, 
    color: "text-indigo-500", 
    bg: "bg-indigo-50",
    border: "border-indigo-100"
  },
  { 
    name: "LIOEVENTS", 
    tag: "ÉVÉNEMENTIEL",
    desc: "Une filiale de FATIGLOBAL spécialisée dans l'organisation, la gestion et la promotion d'événements professionnels, culturels, artistiques et institutionnels. Elle accompagne les entreprises, organisations et particuliers dans la réalisation d'événements tels que les conférences, concerts, cérémonies, salons et spectacles, tout en offrant des solutions modernes en communication, coordination et billetterie. LIOEVENTS contribue à la valorisation des talents et au développement du secteur événementiel en Guinée et en Afrique.", 
    icon: CalendarDays, 
    color: "text-rose-500", 
    bg: "bg-rose-50",
    border: "border-rose-100"
  },
  { 
    name: "LA COURONNE D'AFRIQUE", 
    tag: "CULTURE & BEAUTÉ",
    desc: "Un prestigieux concours panafricain de beauté, de mode, de leadership et de promotion culturelle réunissant Miss, Mister et Mannequins. Cette plateforme met en lumière les talents africains, valorise la diversité culturelle du continent et offre à la jeunesse africaine une opportunité unique de représenter son pays sur une scène internationale. Son objectif principal est également d'accompagner les lauréats dans le financement de projets innovants créateurs d'emplois et bénéfiques au développement de leur pays.", 
    icon: Crown, 
    color: "text-amber-500", 
    bg: "bg-amber-50",
    border: "border-amber-100"
  },
];

export default function AboutPage() {
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  return (
    <div className="min-h-screen flex flex-col bg-gray-50 transition-colors duration-500">
      <SEO title={`À Propos | ${PARENT_BRAND}`} description={`Découvrez l'histoire de ${PARENT_BRAND}, fondée par Lamine Traoré, et ses filiales innovantes en Guinée et en Afrique.`} />
      <Header />
      
      <main className="flex-grow pt-10 pb-20">
        <div className="max-w-6xl mx-auto px-4 md:px-10">
          
          {/* Hero Section */}
          <div className="text-center max-w-4xl mx-auto mb-20 mt-10">
            <div className="inline-flex items-center justify-center p-5 bg-[#ff6600] rounded-3xl shadow-sm mb-8 text-white">
               <Globe className="w-10 h-10" />
            </div>
            <h1 className="text-4xl md:text-6xl font-black text-gray-900 tracking-tight mb-8 leading-tight">
              L'écosystème <br/><span className="text-[#ff6600]">{PARENT_BRAND}</span>
            </h1>
            <p className="text-xl font-medium text-gray-600 leading-relaxed max-w-3xl mx-auto">
              FATIGLOBAL est une société guinéenne née en 2023 avec une mission claire : apporter des solutions innovantes adaptées aux besoins locaux et contribuer au rayonnement de la Guinée et de l'Afrique. Fondée par <strong className="text-[#ff6600] font-bold">Lamine Traoré</strong>, l'entreprise a commencé son aventure à Conakry avec la création de FATIBARA E-COMMERCE, la première plateforme de vente en ligne 100 % guinéenne.
            </p>
          </div>

          {/* Vision & Mission Grid */}
          <div className="grid md:grid-cols-2 gap-8 mb-24">
            <div className="bg-white p-10 md:p-12 rounded-[2.5rem] shadow-sm border border-gray-100 relative overflow-hidden group hover:shadow-md transition-all">
              <div className="absolute top-0 right-0 w-32 h-32 bg-orange-50 rounded-bl-[100px] -z-10 transition-transform group-hover:scale-110"></div>
              <div className="w-16 h-16 bg-orange-100 text-[#ff6600] rounded-2xl flex items-center justify-center mb-8 shadow-sm">
                <Flag className="w-8 h-8" />
              </div>
              <h2 className="text-3xl font-bold text-gray-900 tracking-tight mb-6">Notre Mission</h2>
              <p className="text-gray-600 text-lg leading-relaxed font-medium">
                Moderniser le quotidien des Guinéens et des Africains grâce à des solutions fiables, accessibles et créatrices d'opportunités, tout en valorisant les talents, l'innovation et l'excellence africaine.
              </p>
            </div>

            <div className="bg-[#ff6600] p-10 md:p-12 rounded-[2.5rem] shadow-sm border border-orange-500 relative overflow-hidden group hover:shadow-md transition-all text-white">
              <div className="absolute top-0 right-0 w-32 h-32 bg-orange-500 rounded-bl-[100px] -z-10 transition-transform group-hover:scale-110"></div>
              <div className="w-16 h-16 bg-white/20 text-white rounded-2xl flex items-center justify-center mb-8 shadow-sm backdrop-blur-sm">
                <Eye className="w-8 h-8" />
              </div>
              <h2 className="text-3xl font-bold text-white tracking-tight mb-6">Notre Vision</h2>
              <p className="text-orange-50 text-lg leading-relaxed font-medium">
                Construire l'un des plus grands écosystèmes africains de services numériques, de mobilité, de commerce, d'événementiel et de promotion des talents, capable de transformer durablement la vie des populations.
              </p>
            </div>
          </div>

          {/* The Filiales Grid */}
          <div className="mb-24">
            <div className="text-center mb-14">
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900 tracking-tight mb-6">Un écosystème en pleine croissance</h2>
              <p className="text-gray-500 font-medium text-lg max-w-3xl mx-auto">
                Au fil du temps, FATIGLOBAL est devenue une société mère regroupant plusieurs filiales et projets majeurs, chacun répondant à une problématique du quotidien ou contribuant au développement économique, social et culturel du continent :
              </p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
               {FILIALES.map((filiale, idx) => (
                 <div key={idx} className="bg-white p-8 md:p-10 rounded-[2rem] border border-gray-100 shadow-sm hover:border-gray-200 hover:shadow-lg transition-all duration-300 group flex flex-col h-full">
                    <div className="flex items-center justify-between mb-8">
                       <div className={`w-16 h-16 rounded-2xl flex items-center justify-center ${filiale.bg} ${filiale.color} shadow-sm group-hover:scale-110 group-hover:-rotate-3 transition-transform duration-300`}>
                          <filiale.icon className="w-8 h-8" />
                       </div>
                       <span className={`text-[10px] sm:text-xs font-bold uppercase tracking-wider ${filiale.color} ${filiale.bg} px-4 py-2 rounded-xl border ${filiale.border}`}>
                         {filiale.tag}
                       </span>
                    </div>
                    <h3 className="text-2xl font-bold text-gray-900 tracking-tight mb-4">{filiale.name}</h3>
                    <p className="text-base font-medium text-gray-500 leading-relaxed flex-grow">
                      {filiale.desc}
                    </p>
                 </div>
               ))}
            </div>
          </div>

          {/* Impact & Positioning */}
          <div className="bg-gray-900 rounded-[3rem] shadow-xl p-10 md:p-16 mb-24 relative overflow-hidden">
            <div className="absolute top-0 right-0 w-64 h-64 bg-gray-800 rounded-full blur-3xl -z-0 opacity-50 mix-blend-screen"></div>
            <div className="absolute bottom-0 left-0 w-64 h-64 bg-[#ff6600] rounded-full blur-3xl -z-0 opacity-20 mix-blend-screen"></div>
            
            <div className="relative z-10 text-center max-w-3xl mx-auto">
              <h2 className="text-3xl md:text-4xl font-bold text-white tracking-tight mb-10">
                Aujourd'hui, FATIGLOBAL se positionne comme :
              </h2>
              
              <div className="grid md:grid-cols-1 gap-4 max-w-2xl mx-auto text-left">
                {[
                  "Un moteur de développement économique.",
                  "Un acteur majeur de l'innovation numérique.",
                  "Un promoteur de la jeunesse, de la culture et du leadership africain.",
                  "Un créateur d'opportunités pour les entreprises et les particuliers.",
                  "Un symbole de fierté nationale et panafricaine."
                ].map((item, i) => (
                  <div key={i} className="flex items-center gap-4 bg-gray-800/50 backdrop-blur-sm border border-gray-700/50 p-5 rounded-2xl hover:bg-gray-800 transition-colors">
                    <div className="w-8 h-8 rounded-full bg-[#ff6600]/20 flex items-center justify-center flex-shrink-0">
                        <CheckCircle2 className="w-5 h-5 text-[#ff6600]" />
                    </div>
                    <span className="text-gray-100 font-medium text-lg">{item}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Et Demain */}
          <div className="bg-white rounded-[3rem] shadow-sm border border-gray-100 p-10 md:p-16 mb-20">
             <div className="flex flex-col lg:flex-row gap-12 items-center">
               <div className="flex-1">
                 <div className="flex items-center gap-4 mb-8">
                   <div className="w-14 h-14 bg-orange-50 rounded-2xl flex items-center justify-center text-[#ff6600]">
                     <Rocket className="w-7 h-7" />
                   </div>
                   <h3 className="text-3xl font-bold text-gray-900 tracking-tight">Et Demain ?</h3>
                 </div>
                 
                 <div className="space-y-6 text-gray-600 font-medium text-lg leading-relaxed">
                   <p className="text-[#ff6600] font-bold text-2xl">L'aventure ne fait que commencer.</p>
                   <p>
                     Avec FATIGLOBAL, ses filiales FATIBARA E-COMMERCE, FATINÈMA, FATI-BILLETS, FATI-TONTINE, FATI-LINK, FATI-TRANSPORT et LIOEVENTS, ainsi que son grand projet panafricain LA COURONNE D'AFRIQUE, nous voulons continuer à innover, à créer des opportunités et à développer des solutions adaptées aux réalités de la Guinée et de l'Afrique.
                   </p>
                   <p>
                     Notre ambition est de bâtir un groupe africain de référence capable d'impacter positivement des millions de personnes à travers le continent.
                   </p>
                   <p>
                     Parce qu'ensemble, nous pouvons construire une Afrique plus dynamique, plus connectée, plus prospère et plus influente sur la scène mondiale.
                   </p>
                   <p className="flex items-start md:items-center gap-4 font-bold text-gray-900 bg-gray-50 p-6 rounded-2xl border border-gray-100 mt-8">
                     <Rocket className="w-6 h-6 text-[#ff6600] flex-shrink-0 mt-1 md:mt-0" />
                     <span>FATIGLOBAL – Une vision, plusieurs solutions, un seul objectif : construire l'Afrique de demain.</span>
                   </p>
                 </div>
               </div>

               <div className="w-full lg:w-[350px] bg-gray-50 rounded-[2.5rem] p-8 border border-gray-100 text-center flex-shrink-0">
                  <div className="w-24 h-24 rounded-[2rem] bg-white border border-gray-100 flex items-center justify-center text-gray-700 font-black text-3xl shadow-sm mx-auto mb-6 transform -rotate-3 hover:rotate-0 transition-transform">
                    LT
                  </div>
                  <div className="text-gray-900 font-bold text-xl tracking-wide mb-2">Lamine Traoré</div>
                  <div className="text-[#ff6600] text-sm font-semibold mb-4 leading-relaxed">
                    Fondateur et Président-Directeur Général de FATIGLOBAL, de ses filiales et promoteur de LA COURONNE D'AFRIQUE.
                  </div>
               </div>
             </div>
          </div>

          {/* CTA Section */}
          <div className="text-center bg-gradient-to-br from-[#ff6600] to-[#e65c00] rounded-[3rem] shadow-lg p-10 md:p-20 relative overflow-hidden">
            <div className="absolute top-0 right-0 w-64 h-64 bg-white/10 rounded-full blur-3xl -z-0"></div>
            <div className="absolute bottom-0 left-0 w-64 h-64 bg-white/10 rounded-full blur-3xl -z-0"></div>
            
            <div className="relative z-10">
              <div className="w-20 h-20 bg-white/20 backdrop-blur-md rounded-[2rem] mx-auto mb-8 flex items-center justify-center text-white shadow-sm border border-white/30 hover:scale-110 transition-transform">
                 <Sparkles className="w-10 h-10" />
              </div>
              <p className="text-white font-medium text-lg md:text-xl mb-6 max-w-3xl mx-auto leading-relaxed">
                 💡 Vous êtes commerçant, entrepreneur, investisseur, professionnel, artiste, étudiant, passionné d'événements ou jeune talent africain ?
              </p>
              <h2 className="text-3xl md:text-4xl font-black text-white tracking-tight mb-12 leading-tight">
                Rejoignez dès aujourd'hui l'écosystème FATIGLOBAL et participez à la transformation de l'Afrique ! 🌍✨
              </h2>
              
              <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
                <a href="/login" className="inline-flex items-center justify-center gap-3 bg-white text-[#ff6600] px-10 py-5 rounded-2xl font-bold text-lg hover:bg-gray-50 transition-colors shadow-lg active:scale-95 w-full sm:w-auto">
                  Rejoindre FATIGLOBAL
                </a>
                <a href="tel:+224660345858" className="inline-flex items-center justify-center gap-3 bg-transparent text-white border-2 border-white/30 px-10 py-5 rounded-2xl font-bold text-lg hover:bg-white/10 transition-colors shadow-sm active:scale-95 w-full sm:w-auto">
                  <Phone className="w-6 h-6" />
                  Nous contacter
                </a>
              </div>
            </div>
          </div>

        </div>
      </main>
      
      <div className="md:hidden h-16"></div>
      <Footer />
    </div>
  );
}
