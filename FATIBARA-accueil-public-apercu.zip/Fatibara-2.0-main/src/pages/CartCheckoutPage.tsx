import React, { useEffect, useState, useMemo, useRef, useCallback } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { useAppContext } from '../context/AppContext';
import { useStore } from '../store/useStore';
import { useCommerceStore } from '../store/useCommerceStore';
import { useToast } from '../context/ToastContext';
import Header from '../components/Header';
import Footer from '../components/Footer';
import { MapPin, Truck, CreditCard, CheckCircle, ArrowLeft, AlertCircle, Wallet, ShoppingBag, Store, Loader2, Zap, Tag, Smartphone } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import AppSelect from '../components/ui/AppSelect';
import confetti from 'canvas-confetti';
import AddressPinPicker from '../components/AddressPinPicker';
import { hapticFeedback } from '../lib/haptics';
import { calculateDeliveryFee, FREE_DELIVERY_THRESHOLD } from '../utils/delivery';
import { safeNotify } from '../utils/notifications';
import { friendlyError } from '../lib/utils';
import { calculateProductPrice } from '../utils/pricing';
import { APP_NAME } from '../lib/constants';
import { analytics } from '../lib/analytics';
import { formatGNF } from '../utils/formatters';
import { walletCheckoutService } from '../services/walletCheckoutService';

import { CheckCircle2 } from 'lucide-react';

const CheckoutSteps = ({ currentStep }: { currentStep: number }) => (
  <div className="flex items-center justify-between mb-8 max-w-lg mx-auto">
    {[
      { step: 1, label: 'Adresse' },
      { step: 2, label: 'Paiement' },
      { step: 3, label: 'Confirmé' }
    ].map((s) => (
      <React.Fragment key={s.step}>
        <div className="flex flex-col items-center gap-2 relative z-10 bg-brand-bg px-2">
          <div className={`w-10 h-10 rounded-full flex items-center justify-center font-bold text-sm transition-all duration-300 ${
            currentStep > s.step
              ? 'bg-[#ff6600] text-white shadow-lg shadow-[#ff6600]/30'
              : currentStep === s.step
              ? 'bg-[#ff6600] text-white shadow-lg shadow-[#ff6600]/40 ring-4 ring-[#ff6600]/20'
              : 'bg-gray-100 dark:bg-gray-800 text-gray-400 dark:text-gray-500'
          }`}>
            {currentStep > s.step
              ? <CheckCircle2 className="w-5 h-5" />
              : s.step}
          </div>
          <span className={`text-xs font-bold transition-colors ${
            currentStep >= s.step ? 'text-[#ff6600]' : 'text-gray-400 dark:text-gray-500'
          }`}>{s.label}</span>
        </div>
        {s.step < 3 && (
          <div className="flex-1 h-1 rounded-full overflow-hidden bg-gray-100 dark:bg-gray-800 -mx-6">
            <div
              className="h-full bg-[#ff6600] transition-all duration-500 ease-out"
              style={{ width: currentStep > s.step ? '100%' : '0%' }}
            />
          </div>
        )}
      </React.Fragment>
    ))}
  </div>
);



import { GUINEA_LOCATIONS, ALL_REGIONS } from '../constants/locations';

export default function CartCheckoutPage() {
  const navigate = useNavigate();
  const { user, walletBalance, refreshProfile, savedAddress, setSavedAddress } = useAppContext();
  const { cart, removeFromCart } = useCommerceStore();
  const { modeEconomie } = useStore();
  const { showToast } = useToast();
  
  const [products, setProducts] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [addressErrors, setAddressErrors] = useState<{ quartier?: string, indications?: string }>({});
  const [step, setStep] = useState(1);
  const [paymentStep, setPaymentStep] = useState<'selection' | 'waiting_pin' | 'processing'>('selection');
  const [isProcessing, setIsProcessing] = useState(false);
  const [lastOrderIds, setLastOrderIds] = useState<string[]>([]);
  const [isAwaitingConfirmation, setIsAwaitingConfirmation] = useState(false);
  const [orderConfirmed, setOrderConfirmed] = useState(false);
  const masterTrackingOrderIdRef = React.useRef<string | null>(null);
  const vendorGroupsRef = React.useRef<any[]>([]);
  // Guard against double-submit (tapping Pay twice)
  const isSubmittingRef = React.useRef(false);
  // Track coupon application time so we can clear it if cart changes (L-5)
  const couponAppliedAtRef = React.useRef<number | null>(null);

  // ── USSD PIN timeout ────────────────────────────────────────────────────────
  const PIN_TIMEOUT_SECONDS = 60;
  const [pinCountdown, setPinCountdown] = useState(PIN_TIMEOUT_SECONDS);
  const pinTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const pinIntervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const clearPinTimers = useCallback(() => {
    if (pinTimeoutRef.current) { clearTimeout(pinTimeoutRef.current); pinTimeoutRef.current = null; }
    if (pinIntervalRef.current) { clearInterval(pinIntervalRef.current); pinIntervalRef.current = null; }
  }, []);

  const startPinTimer = useCallback(() => {
    clearPinTimers();
    setPinCountdown(PIN_TIMEOUT_SECONDS);
    pinIntervalRef.current = setInterval(() => {
      setPinCountdown(prev => Math.max(0, prev - 1));
    }, 1000);
    pinTimeoutRef.current = setTimeout(() => {
      clearPinTimers();
      setPaymentStep('selection');
      setIsAwaitingConfirmation(false);
      setIsProcessing(false);
      showToast('⏱️ La demande de paiement a expiré ou été annulée. Veuillez réessayer.', 'warning');
    }, PIN_TIMEOUT_SECONDS * 1000);
  }, [clearPinTimers, showToast]);

  // Cleanup on unmount
  useEffect(() => () => clearPinTimers(), [clearPinTimers]);

  // Always refresh wallet balance when the checkout page mounts so the
  // displayed balance is current — Realtime may not have fired yet on first render.
  useEffect(() => {
    if (user) void refreshProfile();
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user?.id]);

  const handleNextStep = () => {
    let hasError = false;
    const errors: any = {};
    if (!quartier) {
      errors.quartier = "Veuillez entrer un quartier.";
      hasError = true;
    }
    if (!indications || indications.trim().length < 5) {
      errors.indications = "Veuillez fournir des indications plus précises (min. 5 caractères).";
      hasError = true;
    }
    
    if (hasError) {
      setAddressErrors(errors);
      showToast("Veuillez remplir correctement l'adresse", 'warning');
      hapticFeedback('warning');
      return;
    }
    setAddressErrors({});
    setStep(2);
  };

  const [couponCode, setCouponCode] = useState('');
  const [appliedCoupon, setAppliedCoupon] = useState<any>(null);
  const [couponLoading, setCouponLoading] = useState(false);
  const [couponError, setCouponError] = useState('');

  // Address State
  const [region, setRegion] = useState('Conakry');
  const [commune, setCommune] = useState('Ratoma');

  const availableCommunes = GUINEA_LOCATIONS[region as keyof typeof GUINEA_LOCATIONS] || [];

  const handleRegionChange = (newRegion: string) => {
    setRegion(newRegion);
    const communes = GUINEA_LOCATIONS[newRegion as keyof typeof GUINEA_LOCATIONS] || [];
    setCommune(communes[0] || '');
    hapticFeedback('light');
  };
  const [quartier, setQuartier] = useState('');
  const [indications, setIndications] = useState('');
  const [phoneNumber, setPhoneNumber] = useState('');

  // Payment State
  const [paymentMethod, setPaymentMethod] = useState<'orange' | 'mtn' | 'wallet' | 'cash'>('wallet');

  // Phone Network Auto-Detection (Guinea)
  const detectedCarrier = useMemo(() => {
    const p = phoneNumber.replace(/\D/g, '');
    if (p.startsWith('62') || p.startsWith('61')) return 'orange';
    if (p.startsWith('66')) return 'mtn';
    if (p.startsWith('65')) return 'cellcom';
    return null;
  }, [phoneNumber]);

  // Auto-switch payment method based on phone prefix
  useEffect(() => {
    if (detectedCarrier === 'orange' || detectedCarrier === 'mtn') {
      if (paymentMethod !== 'wallet' && paymentMethod !== 'cash' && paymentMethod !== detectedCarrier) {
        setPaymentMethod(detectedCarrier);
        hapticFeedback('light');
      }
    }
  }, [detectedCarrier, paymentMethod]);

  useEffect(() => {
    if (cart.length === 0 && step < 3 && !orderConfirmed) {
      navigate('/');
      return;
    }
    fetchProducts();
  }, []);

  // L-5: Clear applied coupon if the cart changes after coupon was applied
  useEffect(() => {
    if (appliedCoupon && couponAppliedAtRef.current !== null) {
      setAppliedCoupon(null);
      setCouponCode('');
      setCouponError('');
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [cart.length]);

  // Real-time listener for order status — watches by masterTrackingOrderId
  // H-3: Use a unique channel name per tracking ID to avoid multi-tab collisions
  useEffect(() => {
    if (!lastOrderIds.length || !isAwaitingConfirmation) return;
    if (!masterTrackingOrderIdRef.current) return;

    const channel = supabase
      .channel(`cart_order_updates_${masterTrackingOrderIdRef.current}`)
      .on('postgres_changes', {
        event: 'UPDATE',
        schema: 'public',
        table: 'orders',
        // Filter on the tracking_number we stamped on every order in this batch
        filter: `tracking_number=eq.${masterTrackingOrderIdRef.current}`,
      }, (payload: any) => {
        // 'paid' is NEVER set on orders.status — it only appears on financial_status.
        // Real success signal: financial_status='paid' (webhook fired) or
        // status='accepted' (vendor accepted the order alongside payment confirmation).
        const isConfirmed =
          payload.new.financial_status === 'paid'      ||
          payload.new.financial_status === 'processed' ||
          payload.new.status           === 'accepted'  ||
          payload.new.status           === 'confirmed';

        if (isConfirmed && !orderConfirmed) {
          clearPinTimers();
          setOrderConfirmed(true);
          setIsAwaitingConfirmation(false);
          hapticFeedback('reward');
          setStep(3);

          useCommerceStore.getState().clearCart(user?.id);

          // Save address to profile
          if (user && region && commune) {
            const newAddress = { region, commune, quartier, indications, phone: phoneNumber };
            setSavedAddress(newAddress);
            supabase.from('profiles').update({ saved_address: newAddress }).eq('id', user.id).then();
          }

          // Notify vendors
          vendorGroupsRef.current.forEach(group => {
            safeNotify({
              user_id: group.vendorId,
              type: 'order',
              title: 'Nouvelle Vente !',
              message: `Un client a payé — ${group.items.length} article(s) en attente de préparation.`
            });
          });
        } else if (payload.new.status === 'cancelled' || payload.new.financial_status === 'failed') {
          clearPinTimers();
          setIsAwaitingConfirmation(false);
          setIsProcessing(false);
          setPaymentStep('selection');
          setStep(2);
          showToast(`❌ Paiement annulé: ${payload.new.notes || 'Veuillez réessayer.'}`, 'error');
        }
      })
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [lastOrderIds, isAwaitingConfirmation]);

  const fetchProducts = async () => {
    const productIds = cart.map(i => i.product_id);
    const { data, error } = await supabase
      .from('products')
      .select('*, stores(id, owner_id, store_name, location_commune, location_region)')
      .in('id', productIds);

    if (!error && data) {
      setProducts(data);
    }
    setLoading(false);
  };

  useEffect(() => {
    if (savedAddress) {
      setRegion(savedAddress.region);
      setCommune(savedAddress.commune);
      setQuartier(savedAddress.quartier);
      setIndications(savedAddress.indications || '');
      if (savedAddress.phone) setPhoneNumber(savedAddress.phone);
    }
  }, [savedAddress]);

  // Group items by vendor
  const groupedItems = cart.reduce((acc: any, item) => {
    const details = products.find(p => p.id === item.product_id);
    if (!details) return acc;
    const vendorId = details?.stores?.owner_id || 'unknown';
    if (!acc[vendorId]) acc[vendorId] = [];
    acc[vendorId].push({ ...item, details });
    return acc;
  }, {});

  // Calculate costs per vendor group
  const vendorGroups = Object.keys(groupedItems).map(vendorId => {
    const items = groupedItems[vendorId];
    const subtotal = items.reduce((sum: number, item: any) => {
      if (!item.details) return sum;
      const isProMember = user?.profile_type === 'pro';
      const priceInfo = calculateProductPrice(item.details, item.quantity, isProMember, item.selected_variations);
      return sum + (priceInfo.finalPrice * item.quantity);
    }, 0);
    
    // Simple delivery fee per vendor
    const vendorCommune = items[0].details?.stores?.location_commune || 'Ratoma';
    const vendorRegion  = items[0].details?.stores?.location_region  || 'Conakry'; // ISSUE-8: use real vendor region
    const { fee } = calculateDeliveryFee(
      { region: vendorRegion, commune: vendorCommune },
      { region, commune }
    );
    
    return {
      vendorId,
      storeId: items[0].details?.stores?.id || null,
      vendorName: items[0].details?.stores?.store_name || 'Boutique',
      items,
      subtotal,
      deliveryFee: fee
    };
  });

  const totalSubtotal = vendorGroups.reduce((sum, g) => sum + g.subtotal, 0);
  
  // Calculate discount
  const discountAmount = appliedCoupon 
    ? (totalSubtotal * (appliedCoupon.discount_percentage / 100)) 
    : 0;

  const rawTotalDelivery = vendorGroups.reduce((sum, g) => sum + g.deliveryFee, 0);
  const totalDelivery = totalSubtotal >= FREE_DELIVERY_THRESHOLD ? 0 : rawTotalDelivery;
  const PLATFORM_FEE_RATE = 0.05;
  const netSubtotal = totalSubtotal - discountAmount;
  const platformFee = Math.round(netSubtotal * PLATFORM_FEE_RATE);
  const grandTotal = netSubtotal + platformFee + totalDelivery;

  const handleApplyCoupon = async () => {
    if (!couponCode) return;
    setCouponLoading(true);
    setCouponError('');
    try {
      const { data, error } = await supabase.from('coupons')
        .select('*')
        .eq('code', couponCode.toUpperCase())
        .eq('is_active', true)
        .single();
        
      if (error || !data) throw new Error("Code promo invalide");
      
      if (data.min_order_value && totalSubtotal < data.min_order_value) {
        throw new Error(`Minimum d'achat: ${data.min_order_value.toLocaleString()} GNF`);
      }
      if (data.usage_limit && data.usage_count >= data.usage_limit) {
        throw new Error("Ce code promo a atteint sa limite d'utilisation");
      }
      if (data.expires_at && new Date(data.expires_at) < new Date()) {
        throw new Error("Ce code promo a expiré");
      }
      
      setAppliedCoupon(data);
      // L-5: Record when the coupon was applied so we can detect cart changes
      couponAppliedAtRef.current = Date.now();
    } catch (err: any) {
      setCouponError(err.message);
      setAppliedCoupon(null);
    } finally {
      setCouponLoading(false);
    }
  };

  const handlePlaceOrder = async () => {
    // Guard: prevent double-submit from rapid taps
    if (isSubmittingRef.current) return;
    isSubmittingRef.current = true;

    if (!user) {
      showToast("Veuillez vous connecter pour finaliser l'achat.", "info");
      navigate(`/login?redirect=${encodeURIComponent(window.location.pathname)}`);
      isSubmittingRef.current = false;
      return;
    }
    // H-4: Removed stale client-side balance pre-check. The process_wallet_checkout RPC
    // enforces sufficient funds atomically server-side with a user-friendly error message.
    // A stale AppContext walletBalance can cause false "Solde insuffisant" rejections.

    setIsProcessing(true);
    try {
      vendorGroupsRef.current = vendorGroups;
      // M-5: Use crypto.randomUUID() suffix to eliminate 1/1000 collision risk
      const masterTrackingOrderId = `ORD-${Date.now()}-${crypto.randomUUID().slice(0, 8)}`;
      masterTrackingOrderIdRef.current = masterTrackingOrderId;

      // 1. Prepare Payloads
      const payloadOrders: any[] = [];
      const payloadDeliveries: any[] = [];
      const payloadOrderItems: any[] = [];

      for (const group of vendorGroups) {
        const groupProportionalDiscount = discountAmount * (group.subtotal / totalSubtotal);
        // Use the same PLATFORM_FEE_RATE as the display total so the deducted
        // wallet amount always matches what the buyer saw in the summary.
        const groupNet = group.subtotal - groupProportionalDiscount;
        const groupTotal = groupNet * (1 + PLATFORM_FEE_RATE);
        const validVendorId = (group.vendorId && group.vendorId.length >= 32) ? group.vendorId : null;
        const validStoreId = (group.storeId && group.storeId.length >= 32) ? group.storeId : null;

        const orderEntry: any = {
          user_id: user.id,
          customer_name: (user.user_metadata?.full_name as string | undefined) || user.email || `Client ${APP_NAME}`,
          items_count: group.items.reduce((sum: number, i: any) => sum + i.quantity, 0),
          total_amount: groupTotal + group.deliveryFee,
          delivery_fee: group.deliveryFee,
          status: 'pending',
          // M-4: Use cryptographically secure random OTP instead of Math.random()
          delivery_otp: (() => {
            const arr = new Uint32Array(1);
            crypto.getRandomValues(arr);
            return (1000 + (arr[0] % 9000)).toString();
          })(),
          tracking_number: masterTrackingOrderId,
          shipping_address: { 
            region, commune, quartier, indications, phone: phoneNumber,
            payment_method: paymentMethod,
            payment_id: paymentMethod === 'wallet' ? 'wallet' : (paymentMethod === 'cash' ? 'cod' : 'mobile'),
            vendor_delivery_fee: group.deliveryFee
          }
        };
        if (validVendorId) orderEntry.vendor_id = validVendorId;
        if (validStoreId) orderEntry.store_id = validStoreId;

        payloadOrders.push(orderEntry);
        // ISSUE-9: status 'pending' (not 'assigned') — courier assignment happens later.
        // Delivery location is structured address data, not hardcoded GPS.
        payloadDeliveries.push({
          status: 'pending',
          current_location: { region, commune, quartier }
        });

        const items = group.items.map((item: any) => ({
          product_id: item.details?.id || item.product_id,
          quantity: item.quantity,
          price_at_purchase: calculateProductPrice(item.details, item.quantity, user?.profile_type === 'pro', item.selected_variations).finalPrice,
          selected_variations: item.selected_variations || {}
        }));
        payloadOrderItems.push(items);
      }
      
      // ── 2. COD: atomic order creation via RPC (no payment API needed) ─────────
      // Uses process_cart_checkout instead of 3 separate inserts — if the delivery
      // or order_items step fails the whole thing rolls back, no orphan orders.
      if (paymentMethod === 'cash') {
        const { data: codResult, error: codErr } = await supabase.rpc('process_cart_checkout', {
          p_user_id:        user.id,
          p_payment_method: 'cash',
          p_orders:         payloadOrders,
          p_deliveries:     payloadDeliveries,
          p_order_items:    payloadOrderItems,
          // C-4: Pass coupon code so server atomically increments usage_count
          p_coupon_code:    appliedCoupon?.code ?? null,
        });
        if (codErr) throw new Error(`Erreur création commande: ${codErr.message}`);

        // M-6: Capture COD order IDs so "Suivre ma commande" works on the success screen
        if (Array.isArray(codResult) && codResult.length > 0) {
          setLastOrderIds(codResult.map((r: any) => r.id));
        }

        // Notify all vendors atomically after all orders are safely created
        for (const group of vendorGroups) {
          safeNotify({
            user_id: group.vendorId,
            type: 'order',
            title: 'Nouvelle commande COD !',
            message: `Un client a commandé ${group.items.length} article(s) à livrer contre paiement.`
          });
        }
      }

      // ── 3. Mobile Money: call payment API first, then atomic order creation ────
      // Persist the payment intent before contacting the gateway. The gateway
      // verifies the tracking number and authoritative amount from these rows.
      // Failed/expired attempts are cancelled by cancel_unpaid_mobile_order,
      // which also restores the stock reserved by the order_items trigger.
      if (paymentMethod === 'orange' || paymentMethod === 'mtn') {
        if (!phoneNumber || phoneNumber.length < 8) {
          throw new Error('Veuillez saisir un numéro de téléphone valide.');
        }
        // M-1: Block Cellcom numbers — unsupported by LengoPay
        if (detectedCarrier === 'cellcom') {
          throw new Error('Cellcom n\'est pas supporté. Veuillez utiliser Orange Money ou MTN MoMo.');
        }

        const { data: mmResult, error: mmErr } = await supabase.rpc('process_cart_checkout', {
          p_user_id:        user.id,
          p_payment_method: paymentMethod,
          p_orders:         payloadOrders,
          p_deliveries:     payloadDeliveries,
          p_order_items:    payloadOrderItems,
          // C-4: Pass coupon code so server atomically increments usage_count
          p_coupon_code:    appliedCoupon?.code ?? null,
        });
        if (mmErr) throw new Error(`Erreur création commande: ${mmErr.message}`);

        const insertedIds = (mmResult as any[]).map((r: any) => r.id);
        setLastOrderIds(insertedIds);

        let paymentData: any;
        try {
          const { data: sessionData } = await supabase.auth.getSession();
          const token = sessionData.session?.access_token;
          const reqHeaders: Record<string, string> = { 'Content-Type': 'application/json' };
          if (token) reqHeaders['Authorization'] = `Bearer ${token}`;

          const paymentRes = await fetch('/api/payment/mobile', {
            method: 'POST',
            headers: reqHeaders,
            body: JSON.stringify({
              amount:   grandTotal,
              phone:    phoneNumber,
              orderId:  masterTrackingOrderId,
              provider: paymentMethod === 'orange' ? 'ORANGE' : 'MTN',
            }),
          });
          paymentData = await paymentRes.json().catch(() => ({}));
          if (!paymentRes.ok || (!paymentData.success && !paymentData.payment_url)) {
            throw new Error(paymentData.error || paymentData.description || paymentData.message || 'Le paiement a échoué.');
          }
        } catch (paymentError) {
          await Promise.all(insertedIds.map((id) =>
            supabase.rpc('cancel_unpaid_mobile_order', {
              p_order_id: id,
              p_reason: 'Initialisation du paiement mobile échouée',
            })
          ));
          throw paymentError;
        }

        if (paymentData.payment_url) {
          // L-7: On desktop open in a new tab to preserve React state so back-navigation
          // doesn't orphan the order. On mobile, full redirect is unavoidable.
          const isMobile = /Mobi|Android|iPhone/i.test(navigator.userAgent);
          if (isMobile) {
            window.location.href = paymentData.payment_url;
          } else {
            window.open(paymentData.payment_url, '_blank', 'noopener,noreferrer');
            // Show a waiting state — the user will complete payment in the new tab
            showToast('Paiement ouvert dans un nouvel onglet. Validez puis revenez ici.', 'info');
            setPaymentStep('waiting_pin');
            startPinTimer();
            setIsAwaitingConfirmation(true);
          }
          return;
        }

        showToast(paymentData.message || 'Demande envoyée ! Validez sur votre téléphone.', 'success');
        setPaymentStep('waiting_pin');
        startPinTimer();
        setIsAwaitingConfirmation(true);
        return; // Wait for Realtime listener to advance to step 3
      }

      // ── 4. Wallet: atomic payment + order creation via service (with direct fallback) ──
      if (paymentMethod === 'wallet') {
        const walletRes = await walletCheckoutService.processCheckout({
          userId: user.id,
          totalAmount: Math.round(grandTotal),
          orders: payloadOrders,
          deliveries: payloadDeliveries,
          orderItems: payloadOrderItems,
          couponCode: appliedCoupon?.code
        });

        await refreshProfile();

        // Store order IDs so the success screen can link to "Suivre mes commandes"
        if (walletRes.orderIds && walletRes.orderIds.length > 0) {
          setLastOrderIds(walletRes.orderIds);
        }

        useCommerceStore.getState().clearCart(user.id);

        for (const group of vendorGroups) {
          safeNotify({
            user_id: group.vendorId,
            type:    'order',
            title:   'Nouvelle Vente !',
            message: `Un client a payé par portefeuille — ${group.items.length} article(s) prêts à préparer.`
          });
        }
      }

      // ── 5. Shared post-success: COD + Wallet advance to step 3 ───────────────
      // (Mobile money returns early above to wait for the Realtime webhook)
      if (paymentMethod === 'cash') {
        useCommerceStore.getState().clearCart(user.id);
      }

      // Save delivery address to profile for next time
      if (user && region && commune) {
        const newAddress = { region, commune, quartier, indications, phone: phoneNumber };
        setSavedAddress(newAddress);
        supabase.from('profiles').update({ saved_address: newAddress }).eq('id', user.id).then();
      }

      setStep(3);
      hapticFeedback('reward');
      confetti({ particleCount: 200, spread: 90, origin: { y: 0.6 }, colors: ['#ff6600', '#000000', '#FFCC00'] });

      // GA4 / Vercel Analytics — purchase event (revenue tracking)
      void analytics.purchase(masterTrackingOrderId, grandTotal);
    } catch (err) {
      console.error(err);
      showToast(friendlyError(err), "error");
    } finally {
      isSubmittingRef.current = false;
      if (!isAwaitingConfirmation) setIsProcessing(false);
    }
  };

  if (loading) return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-brand-bg gap-6 p-8 text-center animate-pulse">
      <div className="w-24 h-24 bg-brand-surface-light rounded-[2rem]" />
      <div className="space-y-4 w-full max-w-xs">
        <div className="h-6 bg-brand-surface-light rounded w-3/4 mx-auto" />
        <div className="h-4 bg-brand-surface-light rounded w-1/2 mx-auto" />
      </div>
    </div>
  );

  return (
    <div className="min-h-screen flex flex-col bg-brand-bg">
      <Header />
      <main className="flex-grow max-w-5xl mx-auto w-full px-3 md:px-10 py-6 md:py-10">
        <div className="flex flex-col lg:flex-row gap-8 md:gap-12">
          
          <div className="flex-1 space-y-10">
             <CheckoutSteps currentStep={step} />
             
             {step === 1 && (
               <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4">
                 <div className="bg-white dark:bg-gray-900 rounded-3xl border border-gray-200 dark:border-gray-700 p-6 md:p-8 shadow-sm space-y-6">
                    <div className="flex items-center gap-3 mb-2">
                       <button onClick={() => navigate(-1)} className="p-2 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-lg transition-colors">
                          <ArrowLeft className="w-5 h-5 text-gray-600 dark:text-gray-400" />
                       </button>
                       <div className="w-10 h-10 bg-orange-50 rounded-xl flex items-center justify-center text-[#ff6600]">
                         <MapPin className="w-5 h-5" />
                       </div>
                       <h2 className="text-xl md:text-2xl font-bold text-gray-900 dark:text-white tracking-tight">Où livrons-nous ?</h2>
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 md:gap-6">
                        <div className="form-field">
                           <label className="form-label">Région</label>
                           <AppSelect
                             value={region}
                             onChange={(v) => handleRegionChange(v)}
                             icon={<MapPin className="w-4 h-4" />}
                             options={ALL_REGIONS.map(r => ({ value: r, label: r }))}
                           />
                        </div>
                        <div className="form-field">
                           <label className="form-label">Préfecture / Commune</label>
                           <AppSelect
                             value={commune}
                             onChange={(v) => setCommune(v)}
                             icon={<MapPin className="w-4 h-4" />}
                             options={availableCommunes.map(c => ({ value: c, label: c }))}
                           />
                        </div>
                       <div className="space-y-4">
                         <label className="form-label">Localisation Visuelle</label>
                         <div className={`border ${addressErrors.quartier ? 'border-red-500' : 'border-gray-200 dark:border-gray-700'} shadow-sm p-2 bg-white dark:bg-gray-900`}>
                           <AddressPinPicker region={region} onSelect={(val) => { setQuartier(val); if(addressErrors.quartier) setAddressErrors({...addressErrors, quartier: undefined}); }} />
                         </div>
                         {addressErrors.quartier && (
                           <div className="form-error">
                             <AlertCircle className="w-3.5 h-3.5" />
                             <span>{addressErrors.quartier}</span>
                           </div>
                         )}
                         {quartier ? (
                           <div className="p-3 bg-[#ff6600]/10 border border-[#ff6600]/20 rounded-[1.25rem] flex items-center gap-3 text-[#ff6600]">
                             <CheckCircle className="w-4 h-4 md:w-5 md:h-5 flex-shrink-0" />
                             <span className="text-[12px] md:text-[13px] font-bold leading-tight">{quartier}</span>
                           </div>
                         ) : (
                           <div className="p-3 bg-orange-50 border border-orange-100 rounded-[1.25rem] flex items-center gap-2 text-orange-600 text-[11px] font-bold">
                             <AlertCircle className="w-3.5 h-3.5" /> Touchez la carte pour définir un point de repère précis.
                           </div>
                         )}
                       </div>
                    </div>

                    <div className="form-field">
                        <label className="form-label">Indications (Repères, etc.)</label>
                        <textarea
                          placeholder="Ex: À côté de la pharmacie, portail noir..."
                          value={indications}
                          onChange={(e) => { setIndications(e.target.value); if(addressErrors.indications) setAddressErrors({...addressErrors, indications: undefined}); }}
                          className={`form-textarea ${addressErrors.indications ? 'is-error' : ''}`}
                        />
                        {addressErrors.indications && (
                          <div className="form-error">
                            <AlertCircle className="w-3.5 h-3.5" />
                            <span>{addressErrors.indications}</span>
                          </div>
                        )}
                    </div>
                 </div>
                 
                 <button 
                   onClick={handleNextStep}
                   className="w-full bg-[#ff6600] text-white py-4 md:py-4 rounded-xl text-[16px] font-bold hover:bg-[#e62e00] active:scale-[0.98] shadow-sm transition-all disabled:opacity-50"
                 >
                   Continuer vers le paiement
                 </button>
               </div>
             )}

             {step === 2 && (
               <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4">
                 {paymentStep === 'waiting_pin' ? (
                   <div className="bg-white dark:bg-gray-900 border-2 border-[#ff6600] shadow-xl rounded-3xl p-8 text-center space-y-6">
                     <div className="w-20 h-20 bg-orange-50 rounded-full flex items-center justify-center mx-auto relative">
                       <Smartphone className="w-10 h-10 text-[#ff6600]" />
                       <div className="absolute inset-0 bg-[#ff6600] rounded-full animate-ping opacity-20"></div>
                     </div>
                     <div>
                       <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-2">Vérifiez votre téléphone</h2>
                       <p className="text-gray-600 dark:text-gray-400">
                         Une demande de paiement a été envoyée au <span className="font-bold text-[#ff6600]">{phoneNumber}</span>.
                         <br />Veuillez saisir votre code PIN secret pour confirmer.
                       </p>
                     </div>

                     <div className="p-4 bg-gray-50 dark:bg-gray-800 rounded-2xl space-y-3">
                       <div className="flex items-center justify-center gap-4">
                         <Loader2 className="w-5 h-5 text-[#ff6600] animate-spin" />
                         <span className="text-sm font-bold text-gray-900 dark:text-white uppercase tracking-widest">En attente de confirmation...</span>
                       </div>
                       <p className="text-[10px] text-gray-500 font-bold uppercase">Ne fermez pas cette page</p>
                       {/* Live countdown — L-2: show "Expiré" at 0 instead of frozen 00s */}
                       <div className="flex items-center justify-center gap-2 pt-1">
                         {pinCountdown <= 0 ? (
                           <span className="text-3xl font-black tabular-nums text-red-500">Expiré</span>
                         ) : (
                           <>
                             <span
                               className="text-3xl font-black tabular-nums"
                               style={{ color: pinCountdown <= 15 ? '#ef4444' : pinCountdown <= 30 ? '#f59e0b' : '#ff6600' }}
                             >
                               {String(pinCountdown).padStart(2, '0')}s
                             </span>
                             <span className="text-[10px] text-gray-400 font-bold uppercase tracking-wider">avant expiration</span>
                           </>
                         )}
                       </div>
                     </div>

                     <div className="pt-4 space-y-4">
                       <p className="text-xs text-gray-500 italic">
                         Si vous ne recevez pas de notification, composez :
                         <br />
                         <span className="font-bold text-gray-900 dark:text-white">Orange: *144# | MTN: *440#</span>
                       </p>
                       <button 
                         onClick={() => {
                           clearPinTimers();
                           setPaymentStep('selection');
                           setIsAwaitingConfirmation(false);
                           setIsProcessing(false);
                         }}
                         className="text-sm font-bold text-[#ff6600] hover:underline"
                       >
                         Annuler et changer de méthode
                       </button>
                     </div>
                   </div>
                 ) : (
                   <>
                     <div className="bg-white dark:bg-gray-900 rounded-3xl border border-gray-200 dark:border-gray-700 p-6 md:p-8 shadow-sm space-y-6 md:space-y-8">
                     <div className="flex items-center gap-3">
                        <button onClick={() => setStep(1)} className="p-2 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-lg transition-colors">
                           <ArrowLeft className="w-5 h-5 text-gray-600 dark:text-gray-400" />
                        </button>
                        <div className="w-10 h-10 bg-orange-50 rounded-xl flex items-center justify-center text-[#ff6600]">
                          <CreditCard className="w-5 h-5" />
                        </div>
                        <h2 className="text-xl md:text-2xl font-bold text-gray-900 dark:text-white tracking-tight">Mode de Paiement</h2>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                        {['orange', 'mtn', 'wallet', 'cash'].map((m: any) => (
                          <button 
                            key={m}
                            onClick={() => setPaymentMethod(m)}
                            className={`p-4 rounded-2xl border transition-all flex items-center justify-between gap-4 ${paymentMethod === m ? 'border-[#ff6600] bg-orange-50/50 shadow-sm ring-1 ring-[#ff6600]' : 'border-gray-200 dark:border-gray-700 hover:border-gray-300 hover:bg-gray-50 dark:bg-gray-800'}`}
                          >
                            <div className="flex items-center gap-3">
                               <div className={`p-2 rounded-xl flex items-center justify-center w-12 h-12 ${paymentMethod === m ? 'bg-[#ff6600] text-white shadow-sm' : 'bg-gray-100 text-gray-500 dark:text-gray-400'}`}>
                                 {m === 'wallet' ? <Wallet className="w-5 h-5" /> : m === 'orange' ? <div className='font-black text-[12px]'>OM</div> : m === 'mtn' ? <div className='font-black text-[12px]'>MTN</div> : <div className='font-black text-[12px]'>CASH</div>}
                               </div>
                               <span className={`text-sm font-bold text-left leading-tight ${paymentMethod === m ? 'text-[#ff6600]' : 'text-gray-700 dark:text-gray-300'}`}>
                                 {m === 'wallet' ? 'Mon Solde' : m === 'orange' ? 'Orange Money' : m === 'mtn' ? 'MTN MoMo' : 'Cash (COD)'}
                                 {m === 'wallet' && <span className="block text-xs font-normal text-gray-500 mt-0.5">Dispo: {formatGNF(walletBalance)}</span>}
                                 {m === 'cash' && <span className="block text-[10px] font-normal text-gray-500 mt-0.5">Payer à la livraison</span>}
                               </span>
                            </div>
                            <div className={`w-5 h-5 rounded-full border-2 flex items-center justify-center ${paymentMethod === m ? 'border-[#ff6600] bg-[#ff6600]' : 'border-gray-300'}`}>
                              {paymentMethod === m && <div className="w-2 h-2 bg-white rounded-full"></div>}
                            </div>
                          </button>
                        ))}
                     </div>
                     
                     {paymentMethod !== 'wallet' && paymentMethod !== 'cash' && (
                        <div className="space-y-3 bg-gray-50 dark:bg-gray-800/50 p-6 rounded-2xl border border-gray-100 dark:border-gray-800">
                           <label className="text-sm font-semibold text-gray-700 dark:text-gray-300">Numéro de téléphone ({paymentMethod === 'orange' ? 'Orange' : 'MTN'})</label>
                           <div className="relative flex items-center">
                             <input 
                               placeholder="Ex: 622 XX XX XX"
                               value={phoneNumber}
                               onChange={(e) => {
                                 const val = e.target.value.replace(/\D/g, '').slice(0, 9);
                                 setPhoneNumber(val);
                               }}
                               type="tel"
                               className="w-full bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-700 rounded-xl p-4 md:p-5 pr-24 text-xl font-bold text-gray-900 dark:text-white tracking-wide focus:ring-2 focus:ring-[#ff6600] focus:border-transparent transition-all outline-none placeholder:text-gray-300"
                             />
                             <AnimatePresence>
                               {detectedCarrier && (
                                 <motion.div 
                                   initial={{ opacity: 0, scale: 0.8 }}
                                   animate={{ opacity: 1, scale: 1 }}
                                   exit={{ opacity: 0, scale: 0.8 }}
                                   className="absolute right-4 flex items-center"
                                 >
                                   {detectedCarrier === 'orange' && (
                                     <span className="bg-[#ff6600] text-white text-[11px] font-black tracking-wider px-3 py-1.5 rounded-lg shadow-sm">
                                       ORANGE
                                     </span>
                                   )}
                                   {detectedCarrier === 'mtn' && (
                                     <span className="bg-[#ffcc00] text-black text-[11px] font-black tracking-wider px-3 py-1.5 rounded-lg shadow-sm">
                                       MTN
                                     </span>
                                   )}
                                   {detectedCarrier === 'cellcom' && (
                                     <span className="bg-[#e4002b] text-white text-[11px] font-black tracking-wider px-3 py-1.5 rounded-lg shadow-sm">
                                       CELLCOM
                                     </span>
                                   )}
                                 </motion.div>
                               )}
                             </AnimatePresence>
                           </div>
                           <p className="text-xs text-gray-500 dark:text-gray-400">Assurez-vous d'avoir votre téléphone à portée de main pour valider le paiement.</p>
                        </div>
                     )}
                  </div>

                  {/* M-1: Cellcom warning banner */}
                  {detectedCarrier === 'cellcom' && (
                    <div className="flex items-start gap-3 p-4 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-500/30 rounded-2xl">
                      <AlertCircle className="w-5 h-5 text-red-500 shrink-0 mt-0.5" />
                      <p className="text-sm font-semibold text-red-700 dark:text-red-400">
                        Cellcom n'est pas pris en charge. Veuillez utiliser un numéro <strong>Orange Money</strong> ou <strong>MTN MoMo</strong>.
                      </p>
                    </div>
                  )}

                  {/* H-4: Removed stale walletBalance check from disabled prop — RPC enforces server-side */}
                  <button 
                    onClick={handlePlaceOrder}
                    disabled={isProcessing || (paymentMethod !== 'wallet' && paymentMethod !== 'cash' && (phoneNumber.length < 8 || detectedCarrier === 'cellcom'))}
                    className="w-full bg-[#ff6600] text-white py-4 md:py-4 rounded-xl text-[16px] font-bold hover:bg-[#e62e00] transition-all shadow-sm active:scale-[0.98] flex items-center justify-center gap-2 md:gap-3 disabled:opacity-50"
                  >
                    {isProcessing ? <><Loader2 className="w-5 h-5 animate-spin" /> Traitement en cours...</> : paymentMethod === 'cash' ? 'Commander (COD)' : 'Payer maintenant'}
                  </button>
                    </>
                  )}
                </div>
             )}

             {step === 3 && (
               <div className="text-center space-y-8 animate-in zoom-in-95 p-8 md:p-12 bg-white dark:bg-gray-900 rounded-3xl border border-gray-200 dark:border-gray-700 shadow-sm relative overflow-hidden">
                  <div className="absolute top-0 left-0 w-full h-[6px] bg-[#16a34a]"></div>
                  <div className="w-24 h-24 bg-green-50 rounded-[2rem] text-[#16a34a] flex items-center justify-center mx-auto shadow-sm">
                     <CheckCircle className="w-12 h-12" />
                  </div>
                  <div>
                    <h2 className="text-2xl md:text-3xl font-bold text-gray-900 dark:text-white tracking-tight mb-4">Félicitations !</h2>
                    <p className="text-gray-600 dark:text-gray-400 max-w-md mx-auto font-medium text-[15px]">
                       Votre commande a été confirmée avec succès. Elle sera bientôt traitée.
                    </p>
                  </div>
                  <div className="flex flex-col sm:flex-row gap-3 md:gap-4 justify-center">
                     <Link to="/dashboard" className="bg-gray-900 text-white px-6 py-3.5 md:px-8 rounded-xl text-[14px] font-bold tracking-wide hover:bg-[#ff6600] transition-all text-center shadow-sm active:scale-[0.98]">Suivre mes commandes</Link>
                     <Link to="/" className="bg-white dark:bg-gray-900 text-gray-700 px-6 py-3.5 md:px-8 border border-gray-300 rounded-xl text-[14px] font-bold tracking-wide hover:bg-gray-50 dark:bg-gray-800 transition-all text-center shadow-sm active:scale-[0.98]">Retour Accueil</Link>
                  </div>
               </div>
             )}
          </div>

          {/* Sidebar Summary */}
          {step < 3 && (
            <div className="w-full lg:w-[24rem] space-y-6">
               <div className="bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-700 p-6 md:p-8 rounded-3xl shadow-sm">
                  <h3 className="text-sm font-bold text-gray-900 dark:text-white mb-4 border-b border-gray-100 dark:border-gray-800 pb-4 flex items-center gap-2">
                     <ShoppingBag className="w-5 h-5" /> Votre Panier
                  </h3>
                  
                  <div className="space-y-6 md:space-y-8">
                     {vendorGroups.map((group) => (
                       <div key={group.vendorId} className="space-y-4">
                          <div className="flex items-center gap-2 text-gray-700 bg-gray-100 px-3 py-1.5 rounded-lg inline-flex border border-gray-200 dark:border-gray-700">
                             <Store className="w-4 h-4" />
                             <span className="text-xs font-bold uppercase tracking-wider">{group.vendorName}</span>
                          </div>
                          
                          <div className="space-y-3">
                            {group.items.map((item: any) => {
                               const priceInfo = calculateProductPrice(item.details, item.quantity, user?.profile_type === 'pro', item.selected_variations);
                               return (
                                 <div key={`${item.product_id}-${JSON.stringify(item.selected_variations)}`} className="flex gap-4 p-3 bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-700 rounded-2xl shadow-sm">
                                    <div className="w-16 h-16 bg-gray-50 dark:bg-gray-800 rounded-xl border border-gray-100 dark:border-gray-800 overflow-hidden shrink-0">
                                       <img src={item.details?.image_urls?.[0]} className="w-full h-full object-cover" />
                                    </div>
                                    <div className="flex-1 min-w-0 flex flex-col justify-center">
                                       <h4 className="text-sm font-bold text-gray-900 dark:text-white truncate tracking-tight mb-0.5">{item.details?.title}</h4>
                                       
                                       {item.selected_variations && Object.keys(item.selected_variations).length > 0 && (
                                         <p className="text-[10px] font-bold text-gray-400 uppercase mb-1">
                                           {Object.entries(item.selected_variations).map(([k, v]) => `${k}: ${v}`).join(' | ')}
                                         </p>
                                       )}

                                       <div className="flex items-baseline gap-2">
                                          <p className="text-sm font-bold text-[#ff6600] tracking-tight">{item.quantity} × {priceInfo.finalPrice.toLocaleString()} <span className="text-[10px] uppercase font-bold text-gray-500 dark:text-gray-400">GNF</span></p>
                                          {priceInfo.discountAmount > 0 && (
                                            <span className="text-[10px] text-gray-400 line-through font-medium">
                                              {priceInfo.basePrice.toLocaleString()}
                                            </span>
                                          )}
                                       </div>
                                    </div>
                                 </div>
                               );
                             })}
                          </div>

                          <div className="flex justify-between items-center bg-gray-50 dark:bg-gray-800 p-4 rounded-xl border border-gray-200 dark:border-gray-700">
                             <div className="flex items-center gap-2 text-gray-700 dark:text-gray-300">
                                <Truck className="w-4 h-4" />
                                <span className="text-sm font-semibold">Frais de livraison</span>
                             </div>
                             <span className="text-sm font-bold text-orange-500">
                                {totalDelivery === 0 ? <span className="text-[#16a34a]">Offerte</span> : group.deliveryFee > 0 ? `${group.deliveryFee.toLocaleString()} GNF` : 'Gratuit'}
                             </span>
                          </div>
                       </div>
                     ))}
                  </div>

                  <div className="mt-8 pt-8 border-t border-gray-100 dark:border-gray-800 space-y-5">
                     <h4 className="text-sm font-bold text-gray-900 dark:text-white mb-3">Réduction ou Code Promo</h4>
                     
                     <div className="flex bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-700 rounded-xl shadow-sm overflow-hidden mb-4">
                       <input 
                         type="text" 
                         value={couponCode}
                         onChange={(e) => setCouponCode(e.target.value)}
                         placeholder="Entrez votre code" 
                         className="flex-1 bg-transparent px-4 py-3 text-sm font-semibold text-gray-900 dark:text-white outline-none border-r border-gray-200 dark:border-gray-700 placeholder:text-gray-400"
                         disabled={!!appliedCoupon || couponLoading}
                       />
                       <button 
                         onClick={appliedCoupon ? () => { setAppliedCoupon(null); setCouponCode(''); } : handleApplyCoupon}
                         disabled={couponLoading || (!couponCode && !appliedCoupon)}
                         className={`px-6 py-3 text-sm font-bold transition-all focus:outline-none ${appliedCoupon ? 'bg-red-50 text-[#e62e00] hover:bg-red-100' : 'bg-gray-50 dark:bg-gray-800 text-gray-700 hover:bg-gray-100'}`}
                       >
                         {couponLoading ? <Loader2 className="w-4 h-4 animate-spin mx-auto" /> : appliedCoupon ? 'Annuler' : 'Appliquer'}
                       </button>
                     </div>
                     {couponError && <p className="text-[#e62e00] text-xs font-semibold px-2">{couponError}</p>}
                     {appliedCoupon && (
                       <div className="flex justify-between text-sm font-semibold text-gray-700 dark:text-gray-300 border-b border-gray-100 dark:border-gray-800 pb-2">
                          <span className="text-[#16a34a] flex items-center gap-1.5"><Tag className="w-4 h-4"/> Promo ({appliedCoupon.code})</span>
                          <span className="text-[#16a34a]">-{formatGNF(discountAmount)}</span>
                       </div>
                     )}

                     <div className="flex justify-between items-center text-sm font-semibold text-gray-700 dark:text-gray-300">
                        <span>Frais de service Fatibara <span className="text-[10px] font-medium text-gray-400">(5%)</span></span>
                        <span>{formatGNF(platformFee)}</span>
                     </div>

                     <div className="flex justify-between items-end border-t border-gray-100 dark:border-gray-800 pt-4 mt-4">
                        <span className="text-base font-bold text-gray-900 dark:text-white">Total à payer</span>
                        <div className="text-right">
                           <span className="text-3xl font-bold text-[#ff6600] tracking-tight tabular-nums leading-none">{Math.floor(grandTotal).toLocaleString("fr-FR")}</span>
                           <span className="text-[11px] font-bold text-gray-500 dark:text-gray-400 ml-1.5 uppercase align-top">GNF</span>
                        </div>
                     </div>
                  </div>

                  <div className="mt-8 p-4 bg-green-50 border border-green-100 rounded-2xl space-y-3">
                     <div className="flex items-start gap-4">
                        <div className="w-10 h-10 bg-white dark:bg-gray-900 rounded-full flex items-center justify-center shrink-0 shadow-sm border border-green-200">
                           <CheckCircle className="w-5 h-5 text-[#16a34a]" />
                        </div>
                        <p className="text-xs font-semibold text-green-900 dark:text-green-800 pt-1">
                           Paiements sécurisés par LengoPay. Les vendeurs sont payés à la livraison.
                        </p>
                     </div>
                     <div className="pt-3 border-t border-green-100 flex items-center justify-center gap-2">
                        <Tag className="w-3 h-3 text-[#16a34a]" />
                        <span className="text-[10px] font-black tracking-widest text-[#16a34a]/60 uppercase">Alpha Financial Core v3.0</span>
                     </div>
                  </div>
               </div>
            </div>
          )}

        </div>
      </main>
      <Footer />
    </div>
  );
}
