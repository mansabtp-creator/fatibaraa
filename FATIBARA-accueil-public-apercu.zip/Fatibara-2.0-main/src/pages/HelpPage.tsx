import React, { useState, useEffect } from 'react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import SEO from '../components/SEO';
import { motion, AnimatePresence } from 'motion/react';
import { APP_NAME } from '../lib/constants';
import { 
  LifeBuoy, 
  Search, 
  ChevronDown, 
  MessageCircle, 
  Mail, 
  Truck, 
  CreditCard, 
  ShieldAlert, 
  Store 
} from 'lucide-react';

const FAQ_CATEGORIES = [
  {
    icon: Truck,
    title: "Livraison & Suivi",
    color: "text-blue-500",
    bg: "bg-blue-50 dark:bg-blue-500/10",
    questions: [
      { q: "Quels sont les délais de livraison en Guinée ?", a: "Pour Conakry, la livraison s'effectue généralement en 24h à 48h. Pour l'intérieur du pays, prévoyez entre 3 et 5 jours ouvrables selon la région." },
      { q: "Comment suivre ma commande ?", a: "Dès que votre commande est expédiée, vous recevez un SMS avec un lien de suivi. Vous pouvez également suivre vos commandes en temps réel depuis l'onglet 'Compte' de l'application." },
      { q: "Que faire si je suis absent lors de la livraison ?", a: "Notre livreur vous contactera par téléphone. En cas d'absence, la livraison sera reprogrammée pour le lendemain sans frais supplémentaires." }
    ]
  },
  {
    icon: CreditCard,
    title: "Paiements & Remboursements",
    color: "text-emerald-500",
    bg: "bg-emerald-50 dark:bg-emerald-500/10",
    questions: [
      { q: "Quels sont les moyens de paiement acceptés ?", a: "Nous acceptons Orange Money, Mobile Money, le paiement à la livraison (sous certaines conditions), et les cartes bancaires via notre portail sécurisé." },
      { q: "Le paiement en ligne est-il sécurisé ?", a: "Absolument. Nous utilisons un cryptage de bout en bout et nous ne stockons aucune information bancaire sur nos serveurs." },
      { q: "Comment obtenir un remboursement ?", a: "Si l'article est défectueux ou non conforme, vous disposez de 7 jours pour demander un retour via votre espace client. Le remboursement est initié après vérification par la boutique." }
    ]
  },
  {
    icon: Store,
    title: "Vendeurs & Boutiques",
    color: "text-brand-secondary",
    bg: "bg-brand-secondary/10",
    questions: [
      { q: `Comment devenir vendeur sur ${APP_NAME} ?`, a: "Cliquez sur 'Devenir Vendeur' dans le menu ou en bas de page. La création de boutique est gratuite et vous donne accès à un tableau de bord professionnel." },
      { q: "Quelles sont les commissions ?", a: `${APP_NAME} prend une commission transparente uniquement sur les ventes réussies, variant de 3% à 8% selon la catégorie de produit.` }
    ]
  },
  {
    icon: ShieldAlert,
    title: "Sécurité & Garanties",
    color: "text-[#ff6600]",
    bg: "bg-[#ff6600]/10",
    questions: [
      { q: "Les produits sont-ils sous garantie ?", a: "Tous les produits électroniques neufs vendus par nos boutiques vérifiées bénéficient d'une garantie minimale de 6 mois." },
      { q: "Que faire si je suspecte une contrefaçon ?", a: "Nous avons une politique de tolérance zéro envers les contrefaçons. Veuillez signaler l'article immédiatement via le bouton 'Signaler' sur la page du produit." }
    ]
  }
];

// FAQ Item Component
interface AccordionItemProps {
  question: string;
  answer: string;
  searchQuery: string;
  key?: any;
}

function AccordionItem({ question, answer, searchQuery }: AccordionItemProps) {
  const [isOpen, setIsOpen] = useState(false);
  
  // Highlight search logic (basic)
  const isMatch = searchQuery && (question.toLowerCase().includes(searchQuery.toLowerCase()) || answer.toLowerCase().includes(searchQuery.toLowerCase()));
  
  if (searchQuery && !isMatch) {
    return null; // hide if it doesn't match search
  }

  return (
    <div className={`border border-gray-200 overflow-hidden transition-all duration-300 ${isOpen ? 'bg-[#ff6600] shadow-sm -translate-y-1' : 'bg-white hover:shadow-sm hover:-translate-y-1'}`}>
      <button 
        onClick={() => setIsOpen(!isOpen)}
        className="w-full px-5 py-4 flex items-center justify-between gap-4 text-left border-none outline-none"
      >
        <span className={`font-bold text-[13px] tracking-wider ${isOpen ? 'text-white' : 'text-gray-900'}`}>{question}</span>
        <ChevronDown className={`w-5 h-5 flex-shrink-0 transition-transform duration-300 ${isOpen ? 'rotate-180 text-white' : 'text-gray-900'}`} />
      </button>
      
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.3, ease: 'easeOut' }}
            className="overflow-hidden bg-white border-t border-gray-200"
          >
            <div className="px-5 py-5 text-[14px] font-bold text-gray-900 leading-relaxed">
              {answer}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

export default function HelpPage() {
  const [searchQuery, setSearchQuery] = useState('');
  
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  return (
    <div className="min-h-screen flex flex-col bg-gray-50 transition-colors duration-500">
      <SEO title={`Aide & Support | ${APP_NAME}`} description={`Centre d'aide ${APP_NAME}. Trouvez des réponses à vos questions sur la livraison, les paiements, et les retours.`} />
      <Header />
      
      <main className="flex-grow pb-20">
        {/* Support Hero */}
        <div className="bg-gray-900 text-white pt-16 pb-20 px-4 relative overflow-hidden border-b border-gray-200">
          <div className="max-w-4xl mx-auto text-center relative z-10">
            <div className="w-16 h-16 bg-white border border-gray-200 shadow-sm flex items-center justify-center mx-auto mb-6">
              <LifeBuoy className="w-8 h-8 text-gray-900" />
            </div>
            <h1 className="text-3xl md:text-5xl font-bold mb-6 tracking-wider uppercase">Comment pouvons-nous<br className="hidden md:block"/> vous aider ?</h1>
            
            {/* Search Bar */}
            <div className="max-w-2xl mx-auto relative group">
              <div className="absolute inset-y-0 left-5 flex items-center pointer-events-none">
                <Search className="w-5 h-5 text-gray-900" />
              </div>
              <input 
                type="text" 
                placeholder="Rechercher 'Orange Money', 'Livraison'..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-white text-gray-900 border border-gray-200 py-4 pl-14 pr-6 focus:outline-none focus:translate-x-[2px] focus:translate-y-[2px] shadow-sm focus:shadow-sm transition-all font-bold tracking-wider text-[12px] placeholder:text-gray-900/50"
              />
            </div>
          </div>
        </div>

        {/* Support Container */}
        <div className="max-w-4xl mx-auto px-4 md:px-8 mt-12 relative z-20">
          
          {/* Quick Contact Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-16">
             <div className="bg-white p-6 border border-gray-200 shadow-sm flex items-start gap-5 hover:translate-y-[2px] hover:translate-x-[2px] hover:shadow-sm transition-all group">
                <div className="w-12 h-12 bg-green-400 border border-gray-200 flex items-center justify-center flex-shrink-0 text-green-950 shadow-sm">
                   <MessageCircle className="w-6 h-6" />
                </div>
                <div>
                   <h3 className="font-bold text-gray-900 text-lg mb-1 tracking-wider">Support WhatsApp</h3>
                   <p className="text-[11px] font-bold tracking-wider text-gray-900 opacity-80 mb-3">Réponse rapide de notre équipe locale de 8h à 20h.</p>
                   <button className="text-[12px] font-bold text-gray-900 tracking-wider hover:text-[#ff6600]">Démarrer le chat &rarr;</button>
                </div>
             </div>
             
             <div className="bg-white p-6 border border-gray-200 shadow-sm flex items-start gap-5 hover:translate-y-[2px] hover:translate-x-[2px] hover:shadow-sm transition-all group">
                <div className="w-12 h-12 bg-[#ff6600] border border-gray-200 flex items-center justify-center flex-shrink-0 text-white shadow-sm">
                   <Mail className="w-6 h-6" />
                </div>
                <div>
                   <h3 className="font-bold text-gray-900 text-lg mb-1 tracking-wider">Email</h3>
                   <p className="text-[11px] font-bold tracking-wider text-gray-900 opacity-80 mb-3">Pour les demandes complexes ou les vendeurs pros.</p>
                   <button className="text-[12px] font-bold text-gray-900 tracking-wider hover:text-[#ff6600]">support@{APP_NAME.toLowerCase()}.com &rarr;</button>
                </div>
             </div>
          </div>

          {/* FAQ Sections */}
          <h2 className="text-2xl font-bold text-gray-900 tracking-wider uppercase mb-8 pb-4 border-b border-gray-200 inline-block">Foire Aux Questions</h2>
          
          <div className="space-y-8">
            {FAQ_CATEGORIES.map((category, idx) => (
              <div key={idx} className="bg-white p-6 md:p-8 border border-gray-200 shadow-sm">
                <div className="flex items-center gap-4 mb-6 pb-4 border-b border-gray-200 border-dashed">
                  <div className={`w-12 h-12 border border-gray-200 shadow-sm flex items-center justify-center ${category.bg} ${category.color}`}>
                    <category.icon className="w-6 h-6" />
                  </div>
                  <h3 className="text-lg font-bold text-gray-900 tracking-wider">{category.title}</h3>
                </div>
                
                <div className="space-y-4">
                  {category.questions.map((faq, fIdx) => (
                    <AccordionItem key={fIdx} question={faq.q} answer={faq.a} searchQuery={searchQuery} />
                  ))}
                </div>
              </div>
            ))}
          </div>

        </div>
      </main>
      
      {/* Spacing for mobile bottom nav */}
      <div className="md:hidden h-16"></div>
      <Footer />
    </div>
  );
}
