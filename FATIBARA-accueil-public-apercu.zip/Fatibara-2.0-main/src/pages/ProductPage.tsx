import React, { useEffect, useState } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { supabase, safeSupabaseQuery } from '../lib/supabase';
import { useAppContext } from '../context/AppContext';
import { useStore } from '../store/useStore';
import { useCommerceStore } from '../store/useCommerceStore';
import Header from '../components/Header';
import Footer from '../components/Footer';
import { Skeleton } from '../components/ui/Skeleton';
import PriceHistory from '../components/PriceHistory';
import DeliveryCalculator from '../components/DeliveryCalculator';
import RecentlyViewedBar from '../components/RecentlyViewedBar';
import ProductReviews from '../components/ProductReviews';
import { BadgeShelf } from '../components/SellerBadges';
import Rating from '../components/Rating';
import { 
  ShieldCheck, 
  Clock, 
  MessageCircle, 
  ShoppingBag, 
  ArrowLeft, 
  Share2, 
  Heart, 
  Zap, 
  MessageSquare, 
  ShoppingCart, 
  Search,
  Smartphone,
  Truck,
  Flag
} from 'lucide-react';

import { motion, AnimatePresence } from 'motion/react';
import confetti from 'canvas-confetti';
import SEO from '../components/SEO';
import { useToast } from '../context/ToastContext';
import { shareProduct } from '../lib/share';
import { calculateProductPrice } from '../utils/pricing';
import { heroUrl, thumbUrl } from '../utils/imageUtils';
import { APP_NAME } from '../lib/constants';
import ReportModal from '../components/ReportModal';
import { analytics } from '../lib/analytics';

export default function ProductPage() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { showToast } = useToast();
  const { proMode, followedVendors, toggleFollowVendor, openChat, user } = useAppContext();
  const { modeEconomie, addRecentlyViewed } = useStore();
  const { wishlist, toggleWishlist, addToCart, cart } = useCommerceStore();
  
  const [product, setProduct] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [showReport, setShowReport] = useState(false);
  const [activeImage, setActiveImage] = useState(0);
  const [selectedVariation, setSelectedVariation] = useState<Record<string, string>>({});
  const [quantity, setQuantity] = useState(1);
  const [isAddingToCart, setIsAddingToCart] = useState(false);

  const isFavorite = product ? wishlist.includes(product.id) : false;
  const isProMember = user?.profile_type === 'pro';
  
  const priceInfo = product ? calculateProductPrice(product, quantity, isProMember, selectedVariation) : null;
  const displayPrice = priceInfo?.finalPrice || 0;
  const originalPrice = priceInfo?.basePrice || 0;
  const hasDiscount = (priceInfo?.discountAmount || 0) > 0;
  const discountPercent = priceInfo?.discountPercent || 0;

  useEffect(() => {
    async function fetchProduct() {
      if (!id) return;
      
      setLoading(true);
      
      const uuidRegex = /^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$/;
      if (!id || !uuidRegex.test(id)) {
        console.error('Invalid product ID format:', id);
        setLoading(false);
        setProduct(null);
        return;
      }
      
      try {
        const { data, error } = await safeSupabaseQuery(
          supabase
          .from('products')
          .select(`
            *,
            stores (
              id,
              store_name,
              owner_id,
              avatar_url,
              location_commune,
              is_verified_store,
              rating,
              store_status,
              response_rate
            )
          `)
          .eq('id', id)
          // A deleted product is a normal outcome for a saved/shared URL.
          // maybeSingle() returns null rather than a PGRST116/HTTP 406 error,
          // allowing the dedicated not-found page below to render quietly.
          .maybeSingle()
        );

        if (error) {
          throw error;
        }
        if (!data) {
          setProduct(null);
          return;
        }
        setProduct(data);
        addRecentlyViewed(id);

        // Track the product view anonymously
        supabase.from('product_views').insert([{
          product_id: id
        }]).then(({ error }) => {
          if (error) console.error("View tracking error", error);
        });

        // GA4 / Vercel Analytics — fire after data is set
        void analytics.viewProduct(data.id, data.title ?? data.name ?? 'Produit');
      } catch (error) {
        console.error('Error fetching product:', error);
        showToast('Erreur lors du chargement du produit', 'error');
      } finally {
        setLoading(false);
      }
    }

    fetchProduct();
    window.scrollTo(0, 0);
  }, [id, addRecentlyViewed, showToast]);

  const handleShare = async () => {
    shareProduct(
      product?.title || 'Produit',
      window.location.href,
      showToast
    );
  };

  const handleOpenChat = async () => {
    if (!product?.stores?.id) return;
    try {
      // buyer = current user (don't pass owner_id as userId — that breaks RLS)
      await openChat(product.stores.id, product.title, undefined, product.id);
    } catch (err) {
      console.error('Chat error:', err);
      showToast('Erreur d\'ouverture du chat', 'error');
    }
  };

  const handleAddToCart = async () => {
    if (!product) return;
    
    // Check if variations are available and selected
    const hasVariants = product.variants && product.variants.length > 0;
    if (hasVariants) {
      // Need to ensure both size and color (if they exist in variants) are picked
      const availableSizes = Array.from(new Set(product.variants.map((v: any) => v.size).filter(Boolean)));
      const availableColors = Array.from(new Set(product.variants.map((v: any) => v.color).filter(Boolean)));
      
      if (availableSizes.length > 0 && !selectedVariation.size) {
        showToast("Veuillez sélectionner une taille.", "warning");
        return;
      }
      if (availableColors.length > 0 && !selectedVariation.color) {
        showToast("Veuillez sélectionner une couleur.", "warning");
        return;
      }
    }

    const currentCartItem = cart.find(item => item.product_id === product.id && JSON.stringify(item.selected_variations || {}) === JSON.stringify(selectedVariation || {}));
    const currentQty = currentCartItem ? currentCartItem.quantity : 0;
    
    if (currentQty + quantity > (product.stock_quantity ?? 100)) {
      showToast(`Stock insuffisant. Il ne reste que ${product.stock_quantity} en stock.`, "warning");
      return;
    }

    setIsAddingToCart(true);
    
    try {
      await addToCart(product.id, quantity, selectedVariation, user?.id);
      showToast('Ajouté au panier !', 'success');
      
      // Track cart event
      if (product?.stores?.id) {
        supabase.from('cart_events').insert([{
          total_value: (product.price_gnf || 0) * quantity,
          items: [{ product_id: product.id, quantity, variations: selectedVariation }],
          store_id: product.stores.id,
          user_id: user?.id,
          status: 'abandoned'
        }]).then();
      }

      // GA4 / Vercel Analytics
      void analytics.addToCart(product.id, (product.price_gnf ?? 0) * quantity);
      
      // Confetti effect
      const rect = document.getElementById('add-to-cart-btn')?.getBoundingClientRect();
      if (rect) {
        confetti({
          particleCount: 100,
          spread: 70,
          origin: { 
            x: (rect.left + rect.width / 2) / window.innerWidth, 
            y: (rect.top + rect.height / 2) / window.innerHeight 
          },
          colors: ['#ff6600', '#ff9933', '#ffcc99']
        });
      }
    } catch (err) {
      showToast('Erreur lors de l\'ajout au panier', 'error');
    } finally {
      setIsAddingToCart(false);
    }
  };

  const handleToggleWishlist = async () => {
    if (!product) return;
    try {
      await toggleWishlist(product.id, user?.id);
      showToast(isFavorite ? 'Retiré des favoris' : 'Ajouté aux favoris', 'success');
    } catch (err) {
      showToast('Erreur wishlist', 'error');
    }
  };

  const handleBuyNow = () => {
    if (!product?.id) return;
    navigate(`/checkout/${product.id}?qty=${quantity}${Object.keys(selectedVariation).length > 0 ? `&variation=${JSON.stringify(selectedVariation)}` : ''}`);
  };

  const isFollowing = product?.stores?.id ? followedVendors.includes(product.stores.id) : false;

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-950 pb-20">
        <Header />
        <div className="max-w-7xl mx-auto px-4 pt-4 md:pt-10">
           <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 md:gap-16">
              <Skeleton className="aspect-square rounded-3xl" />
              <div className="space-y-6">
                <Skeleton className="h-12 w-3/4 rounded-xl" />
                <Skeleton className="h-8 w-1/4 rounded-xl" />
                <Skeleton className="h-32 w-full rounded-2xl" />
                <div className="flex gap-4">
                  <Skeleton className="h-16 flex-1 rounded-2xl" />
                  <Skeleton className="h-16 flex-1 rounded-2xl" />
                </div>
              </div>
           </div>
        </div>
      </div>
    );
  }

  if (!product) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-950 flex flex-col">
        <Header />
        <div className="flex-1 flex flex-col items-center justify-center p-8 text-center">
          <div className="w-24 h-24 bg-white dark:bg-gray-900 border border-gray-100 dark:border-white/10 rounded-3xl shadow-sm flex items-center justify-center mb-6 text-gray-400">
            <Search className="w-12 h-12" />
          </div>
          <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-2 tracking-tight">Produit introuvable</h2>
          <p className="text-gray-500 dark:text-gray-400 mb-8 font-medium max-w-md">Ce produit n'existe plus ou a été retiré par le vendeur.</p>
          <Link to="/" className="inline-block bg-[#ff6600] text-white px-8 py-4 rounded-xl font-semibold tracking-wide hover:bg-[#e62e00] shadow-sm transition-all active:scale-95">
            Retour à l'accueil
          </Link>
        </div>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-brand-bg dark:bg-gray-950 selection:bg-[#ff6600] selection:text-white transition-colors duration-500">
      <SEO 
        title={product.title} 
        description={product.description || `Achetez ${product.title} en Guinée sur ${APP_NAME}. Livraison Conakry et grandes villes.`}
        image={product.image_urls?.[0]}
        url={`https://www.fatibara.com/product/${product.id}`}
        type="product"
        keywords={`${product.title}, ${product.category}, ${APP_NAME}, Guinée, Conakry, achat en ligne`}
      />
      
      <Header />
      
      {/* Sticky Mobile Navigation */}
      <div className="lg:hidden fixed top-0 left-0 right-0 z-40 bg-white/90 dark:bg-gray-950/90 backdrop-blur-md border-b border-gray-100 dark:border-white/5 py-3 px-4 flex items-center justify-between shadow-sm transition-colors">
        <button onClick={() => navigate(-1)} className="p-2.5 bg-gray-50 dark:bg-gray-900 border border-gray-200 dark:border-white/10 rounded-xl text-gray-700 dark:text-white font-bold text-[13px] flex items-center gap-2 active:scale-95 transition-transform hover:text-[#ff6600]">
           <ArrowLeft className="w-4 h-4" /> Retour
        </button>
        <div className="flex items-center gap-2">
          <button onClick={handleShare} aria-label="Partager ce produit" className="p-2.5 bg-gray-50 dark:bg-gray-900 border border-gray-200 dark:border-white/10 rounded-xl text-gray-700 dark:text-white active:scale-95 transition-transform hover:text-[#ff6600]">
              <Share2 className="w-4 h-4" />
          </button>
          <button onClick={handleToggleWishlist} aria-label="Ajouter aux favoris" className={`p-2.5 bg-gray-50 dark:bg-gray-900 border border-gray-200 dark:border-white/10 rounded-xl active:scale-95 transition-all ${isFavorite ? 'text-[#e62e00] border-red-200 bg-red-50 dark:bg-red-900/20' : 'text-gray-700 dark:text-white hover:text-[#e62e00]'}`}>
              <Heart className={`w-4 h-4 ${isFavorite ? 'fill-current text-[#e62e00]' : ''}`} />
          </button>
          <button onClick={() => setShowReport(true)} title="Signaler ce produit" className="p-2.5 bg-gray-50 dark:bg-gray-900 border border-gray-200 dark:border-white/10 rounded-xl text-gray-400 active:scale-95 transition-transform hover:text-red-500">
            <Flag className="w-4 h-4" />
          </button>
        </div>
      </div>

      <main className="max-w-7xl mx-auto px-4 pt-20 md:pt-14 pb-20">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-10 lg:gap-16">
          {/* Gallery Section */}
          <div className="space-y-6">
            <div 
              id="status-card"
              className="relative aspect-square bg-gray-50 dark:bg-gray-900 rounded-[2rem] border border-gray-100 dark:border-white/10 shadow-sm overflow-hidden group"
            >
              <AnimatePresence mode="wait">
                <motion.img 
                  key={activeImage}
                  initial={{ opacity: 0, scale: 1.05 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.95 }}
                  transition={{ duration: 0.4 }}
                  src={modeEconomie ? `${heroUrl(product.image_urls[activeImage])}&blur=4&q=30` : heroUrl(product.image_urls[activeImage])} 
                  alt={product.title}
                  className="w-full h-full object-cover group-hover:scale-[1.02] transition-transform duration-700 ease-out"
                  referrerPolicy="no-referrer"
                />
              </AnimatePresence>
              
              <div className="absolute inset-0 bg-black/5 dark:bg-white/5 pointer-events-none" />

              {/* Status Badge */}
              <div className="absolute top-6 left-6 flex flex-col gap-3 pointer-events-none">
                {product.stock_quantity <= 3 && (
                  <div className="bg-white/90 dark:bg-gray-900/90 backdrop-blur text-[#e62e00] dark:text-red-400 px-4 py-2 rounded-xl text-[11px] font-bold uppercase tracking-wider shadow-sm flex items-center gap-2 border border-red-100 dark:border-red-900/20">
                    <Clock className="w-4 h-4 animate-pulse" /> Urgent : Stock Limité
                  </div>
                )}
                <div className="bg-gray-900/80 dark:bg-black/80 backdrop-blur text-[#16a34a] px-4 py-2 rounded-xl text-[11px] font-bold uppercase tracking-wider opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                  <span className="flex items-center gap-1"><ShieldCheck className="w-3.5 h-3.5"/> Qualité Certifiée</span>
                </div>
              </div>

              {/* Gallery Controls (Desktop) */}
              <div className="absolute bottom-6 right-6 flex gap-3 opacity-0 group-hover:opacity-100 transition-all duration-300">
                 <button onClick={handleShare} aria-label="Partager ce produit" className="w-12 h-12 bg-white/90 dark:bg-gray-800/90 backdrop-blur rounded-2xl flex items-center justify-center text-gray-700 dark:text-white hover:text-[#ff6600] dark:hover:text-[#ff6600] transition-colors active:scale-95 shadow-sm">
                    <Share2 className="w-5 h-5" />
                 </button>
                 <button onClick={handleToggleWishlist} aria-label="Ajouter aux favoris" className={`w-12 h-12 bg-white/90 dark:bg-gray-800/90 backdrop-blur rounded-2xl flex items-center justify-center transition-colors active:scale-95 shadow-sm ${isFavorite ? 'text-[#e62e00]' : 'text-gray-700 dark:text-white hover:text-[#e62e00]'}`}>
                    <Heart className={`w-5 h-5 ${isFavorite ? 'fill-current' : ''}`} />
                 </button>
              </div>
            </div>

            <div className="flex gap-3 overflow-x-auto no-scrollbar pb-4 px-1">
              {product.image_urls.map((url: string, index: number) => (
                <button
                  key={index}
                  onClick={() => setActiveImage(index)}
                  className={`relative w-20 h-20 md:w-24 md:h-24 rounded-2xl overflow-hidden transition-all duration-300 flex-shrink-0 ${
                    activeImage === index ? 'opacity-100 ring-2 ring-[#ff6600] ring-offset-2' : 'opacity-60 hover:opacity-100'
                  }`}
                >
                  <img 
                    src={thumbUrl(url)} 
                    alt={`Photo ${index + 1} de ${product?.title || 'produit'}`} 
                    className="w-full h-full object-cover"
                    referrerPolicy="no-referrer"
                  />
                </button>
              ))}
            </div>
          </div>

          {/* Info Section */}
          <div className="flex flex-col">
            <div className="mb-4">
              <span className="text-[11px] font-bold uppercase tracking-wider text-gray-500 bg-gray-100 px-3 py-1.5 rounded-lg border border-gray-200 inline-block">{product.category}</span>
            </div>
            
            <h1 className="text-3xl sm:text-4xl md:text-5xl lg:text-5xl font-bold text-gray-900 dark:text-white tracking-tight leading-[1.1] mb-6 md:mb-8">
              {product.title}
            </h1>

            <div className="flex flex-col gap-6">
            <div className="bg-white dark:bg-[#1A1D21] p-6 sm:p-8 md:p-8 rounded-[2.5rem] border border-gray-100 dark:border-white/5 shadow-sm relative z-10 transition-colors">
                <div className="flex flex-col gap-6">
                  {product.seo_description && (
                    <div className="mb-2">
                       <p className="text-[11px] font-black text-[#ff6600] uppercase tracking-widest italic mb-1">Résumé Elite AI</p>
                       <p className="text-[12px] font-bold text-gray-500 dark:text-gray-400 leading-relaxed italic border-l-2 border-[#ff6600]/30 pl-3">
                         {product.seo_description}
                       </p>
                    </div>
                  )}
                  
                  <div className="flex flex-col gap-2">
                    <span className="text-[11px] font-bold text-gray-500 dark:text-gray-400 uppercase tracking-widest">Prix de l'article</span>
                    
                    {/* Discount Tooltip / Alert */}
                    {hasDiscount && (
                       <div className="flex flex-wrap items-center gap-3 mb-1">
                          <span className="text-xl md:text-2xl font-bold text-gray-400 dark:text-gray-600 line-through tracking-tight">{originalPrice.toLocaleString()} GNF</span>
                          <span className="text-[11px] font-bold text-white bg-[#e62e00] px-2 py-1 rounded-md uppercase tracking-wider shadow-sm animate-pulse">-{discountPercent}% RÉDUCTION</span>
                          
                          {priceInfo?.isProPrice && (
                            <span className="text-[10px] font-bold text-white bg-[#16a34a] px-2 py-1 rounded-md uppercase tracking-wider flex items-center gap-1">
                              <Zap className="w-3 h-3 fill-current" /> PRIX PRO
                            </span>
                          )}
                       </div>
                    )}
                    
                    {/* Volume Discount Specific Tag if not yet applied but available */}
                    {(!priceInfo?.isVolumeDiscount && product.volume_discount_qty && product.volume_discount_percent) && (
                       <div className="mb-1">
                          <span className="text-[11px] font-bold text-gray-500 bg-gray-100 dark:bg-gray-800 px-3 py-1.5 rounded-lg uppercase tracking-wide inline-block border border-gray-200 dark:border-gray-700">
                             Achetez {product.volume_discount_qty}, Débloquez {product.volume_discount_percent}% de remise !
                          </span>
                       </div>
                    )}

                    <div className="flex items-baseline gap-3">
                      <span className={`text-4xl sm:text-5xl md:text-5xl font-bold ${hasDiscount ? 'text-[#e62e00] dark:text-red-500' : 'text-[#ff6600] dark:text-white'} tracking-tight leading-none whitespace-nowrap`}>
                        {displayPrice.toLocaleString()} <span className={`text-lg sm:text-xl md:text-xl font-bold text-gray-600 ml-1`}>GNF</span>
                      </span>
                      {isProMember && (
                        <motion.div 
                          initial={{ scale: 0 }} animate={{ scale: 1 }}
                          className="bg-[#16a34a] text-white p-2 flex items-center gap-1 rounded-xl shadow-sm text-xs font-bold uppercase"
                        >
                          <Zap className="w-4 h-4 fill-current" /> MEMBRE PRO
                        </motion.div>
                      )}
                    </div>
                  </div>

                  <div className="flex flex-wrap items-center gap-4 py-5 border-y border-gray-100 dark:border-white/5">
                    <div className="flex items-center gap-2 px-3 py-1.5 bg-emerald-50 dark:bg-emerald-500/10 border border-emerald-100 dark:border-emerald-500/20 rounded-lg shadow-sm">
                      <ShieldCheck className="w-4 h-4 text-emerald-500" />
                      <span className="text-[10px] font-black uppercase tracking-[0.15em] text-emerald-600">
                        Vérifié {APP_NAME} Elite
                      </span>
                    </div>
                    <div className="w-px h-6 bg-gray-200 dark:bg-white/10" />
                    <Rating rating={product.stores?.rating || 4.5} showText={true} />
                  </div>

                  {product.variants && product.variants.length > 0 && (
                    <div className="space-y-6">
                      {/* Sizes */}
                      {Array.from(new Set(product.variants.map((v: any) => v.size).filter(Boolean))).length > 0 && (
                        <div className="space-y-3">
                          <h4 className="text-[11px] font-black text-gray-400 uppercase tracking-widest italic">Taille Disponible</h4>
                          <div className="flex flex-wrap gap-2">
                            {Array.from(new Set(product.variants.map((v: any) => v.size).filter(Boolean))).map((size: any, i) => (
                              <button 
                                key={i} 
                                onClick={() => setSelectedVariation({ ...selectedVariation, size })}
                                className={`px-4 py-2 rounded-xl border text-[12px] font-black transition-all ${
                                  selectedVariation.size === size 
                                    ? 'bg-gray-900 text-white border-gray-900 shadow-lg' 
                                    : 'bg-white dark:bg-gray-800 border-gray-100 dark:border-white/5 text-gray-700 dark:text-gray-300 hover:border-[#ff6600]'
                                }`}
                              >
                                {size}
                              </button>
                            ))}
                          </div>
                        </div>
                      )}

                      {/* Colors */}
                      {Array.from(new Set(product.variants.map((v: any) => v.color).filter(Boolean))).length > 0 && (
                        <div className="space-y-3">
                          <h4 className="text-[11px] font-black text-gray-400 uppercase tracking-widest italic">Couleur / Style</h4>
                          <div className="flex flex-wrap gap-2">
                            {Array.from(new Set(product.variants.map((v: any) => v.color).filter(Boolean))).map((color: any, i) => (
                              <button 
                                key={i} 
                                onClick={() => setSelectedVariation({ ...selectedVariation, color })}
                                className={`px-4 py-2 rounded-xl border text-[12px] font-black transition-all ${
                                  selectedVariation.color === color 
                                    ? 'bg-gray-900 text-white border-gray-900 shadow-lg' 
                                    : 'bg-white dark:bg-gray-800 border-gray-100 dark:border-white/5 text-gray-700 dark:text-gray-300 hover:border-[#ff6600]'
                                }`}
                              >
                                {color}
                              </button>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  )}

                  {/* Quantity Selector */}
                  <div className="space-y-3">
                    <h4 className="text-[12px] font-bold text-gray-900 dark:text-white uppercase tracking-wider">Quantité</h4>
                    <div className="flex items-center gap-4 bg-gray-50 dark:bg-gray-900/50 w-fit p-1 rounded-xl border border-gray-200 dark:border-white/5">
                      <button 
                        onClick={() => setQuantity(Math.max(1, quantity - 1))}
                        className="w-10 h-10 flex items-center justify-center bg-white dark:bg-gray-800 rounded-lg shadow-sm text-gray-600 dark:text-white hover:text-[#ff6600] transition-colors disabled:opacity-50 font-bold text-lg border border-gray-100"
                        disabled={quantity <= 1}
                      >
                        -
                      </button>
                      <span className="w-8 text-center font-bold text-gray-900 dark:text-white">{quantity}</span>
                      <button 
                        onClick={() => setQuantity(quantity + 1)}
                        disabled={quantity >= (product.stock_quantity ?? 100)}
                        className="w-10 h-10 flex items-center justify-center bg-white dark:bg-gray-800 rounded-lg shadow-sm text-gray-600 dark:text-white hover:text-[#ff6600] disabled:hover:text-gray-400 transition-colors font-bold text-lg border border-gray-100 disabled:opacity-50"
                      >
                        +
                      </button>
                    </div>
                  </div>

                  <div className="flex flex-col sm:flex-row gap-3 pt-4">
                    {product.stores?.store_status === 'holiday' ? (
                      <div className="flex-[3] flex items-center justify-center p-6 bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-400 h-14 sm:h-16 rounded-xl font-bold uppercase tracking-wider text-[12px] text-center border border-gray-200 dark:border-white/10">
                        Le vendeur est en pause.
                      </div>
                    ) : (
                      <div className="flex-[3] flex flex-row gap-3">
                        <button 
                          id="add-to-cart-btn"
                          onClick={handleAddToCart}
                          disabled={isAddingToCart || product.stock_quantity <= 0}
                          className="flex-1 bg-white dark:bg-gray-800 border-2 border-[#ff6600]/30 text-[#ff6600] h-14 sm:h-16 rounded-xl font-bold uppercase tracking-wider text-[12px] flex items-center justify-center gap-2 hover:bg-orange-50 dark:hover:bg-orange-900/20 hover:border-[#ff6600] active:scale-[0.98] transition-all disabled:opacity-50 disabled:cursor-not-allowed"
                        >
                          <ShoppingCart className="w-5 h-5" /> 
                          {product.stock_quantity <= 0 ? 'ÉPUISÉ' : (isAddingToCart ? '...' : 'Panier')}
                        </button>
                        <button 
                          onClick={handleBuyNow}
                          disabled={product.stock_quantity <= 0}
                          className="flex-[2] bg-[#ff6600] text-white h-14 sm:h-16 rounded-xl font-bold uppercase tracking-wider text-[13px] flex items-center justify-center gap-2 hover:bg-[#e62e00] shadow-md shadow-[#ff6600]/20 active:scale-[0.98] transition-all group disabled:opacity-50 disabled:cursor-not-allowed disabled:bg-gray-400 disabled:shadow-none"
                        >
                          <ShoppingBag className="w-5 h-5 group-hover:-rotate-12 transition-transform" /> {product.stock_quantity <= 0 ? 'RUPTURE DE STOCK' : 'ACHETER'}
                        </button>
                      </div>
                    )}
                    <button 
                      onClick={handleOpenChat}
                      className="flex-1 bg-gray-900 dark:bg-gray-800 border border-white/10 h-14 sm:h-16 rounded-xl font-bold uppercase tracking-wider text-[12px] flex items-center justify-center gap-2 text-white hover:bg-gray-700 shadow-md active:scale-[0.98] transition-all group min-w-[60px]"
                    >
                      <MessageSquare className="w-5 h-5 group-hover:scale-110 transition-transform shrink-0" />
                      <span>Chat</span>
                    </button>
                  </div>

                  {/* Trust Signals & Payment Badges */}
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mt-6 pt-6 border-t border-gray-100 dark:border-white/5 transform-gpu">
                    {[
                      { emoji: '🟠', label: 'Orange Money', color: 'text-[#ff6600]', bg: 'bg-orange-50 dark:bg-orange-900/10', border: 'border-orange-200 dark:border-orange-800/30' },
                      { emoji: '🟡', label: 'MTN MoMo', color: 'text-yellow-600 dark:text-yellow-400', bg: 'bg-yellow-50 dark:bg-yellow-900/10', border: 'border-yellow-200 dark:border-yellow-800/30' },
                      { icon: Truck, label: 'Livraison Gratuite', color: 'text-emerald-600 dark:text-emerald-400', bg: 'bg-emerald-50 dark:bg-emerald-900/10', border: 'border-emerald-200 dark:border-emerald-800/30' },
                      { icon: ShieldCheck, label: `Garanti ${APP_NAME}`, color: 'text-blue-600 dark:text-blue-400', bg: 'bg-blue-50 dark:bg-blue-900/10', border: 'border-blue-200 dark:border-blue-800/30' },
                    ].map((badge: any, i) => (
                      <div key={i} className={`flex flex-col items-center justify-center text-center gap-1.5 p-3 ${badge.bg || 'bg-gray-50 dark:bg-gray-800/50'} border ${badge.border || 'border-gray-200 dark:border-gray-700/50'} hover:scale-[1.02] transition-all rounded-xl shadow-sm`}>
                        {badge.emoji
                          ? <span className="text-xl leading-none">{badge.emoji}</span>
                          : <badge.icon className={`w-5 h-5 ${badge.color || 'text-[#ff6600]'}`} />
                        }
                        <span className={`text-[9px] font-black uppercase tracking-widest ${badge.color || 'text-gray-700 dark:text-gray-300'}`}>{badge.label}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* Description & Store Meta */}
              <div className="space-y-12">
                <div className="bg-white dark:bg-gray-900 p-6 md:p-8 rounded-3xl border border-gray-200 dark:border-gray-800 shadow-sm">
                  <h3 className="text-[14px] font-bold text-gray-900 dark:text-white uppercase tracking-wider mb-6 flex items-center gap-3">
                     <span className="w-1.5 h-6 bg-[#ff6600] rounded-full"></span> Description du Produit
                  </h3>
                  <p className="text-[15px] text-gray-700 dark:text-gray-300 leading-relaxed font-medium whitespace-pre-line">
                    {product.description}
                  </p>
                </div>

                 <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="bg-white dark:bg-gray-900 p-5 border border-gray-200 dark:border-white/10 rounded-3xl shadow-sm flex items-center justify-between group transition-all">
                       <div className="flex items-center gap-4 cursor-pointer overflow-hidden" onClick={() => product?.stores?.store_name && navigate(`/boutique/${product.stores.store_name}`)}>
                          <div className="w-14 h-14 border border-gray-200 rounded-full overflow-hidden bg-gray-50 shrink-0">
                            <img src={product?.stores?.avatar_url || 'https://picsum.photos/seed/s/100/100'} alt={product?.stores?.store_name} className="w-full h-full object-cover" />
                          </div>
                          <div className="overflow-hidden">
                            <h4 className="text-[13px] font-bold uppercase text-gray-900 dark:text-white tracking-wider flex items-center gap-1 truncate group-hover:text-[#ff6600]">
                              {product?.stores?.store_name || APP_NAME}
                              {product?.stores?.is_verified_store && <ShieldCheck className="w-3.5 h-3.5 text-[#16a34a]" />}
                            </h4>
                            <span className="text-[10px] font-bold uppercase text-gray-500 tracking-wider truncate block mt-0.5">{product?.stores?.location_commune || 'Conakry'}</span>
                          </div>
                       </div>
                       <button 
                         onClick={(e) => {
                           e.stopPropagation();
                           if (product?.stores?.id) toggleFollowVendor(product.stores.id);
                         }}
                         className={`px-4 py-2 rounded-xl text-[10px] font-bold tracking-wider transition-all ${
                           isFollowing 
                             ? 'bg-gray-100 text-gray-600 border border-gray-200' 
                             : 'bg-white text-gray-900 border border-gray-300 shadow-sm hover:border-gray-400'
                         }`}
                       >
                         {isFollowing ? 'SUIVI' : 'SUIVRE'}
                       </button>
                    </div>

                    <div className="bg-gray-900 text-white p-5 rounded-3xl flex flex-col justify-center gap-1 shadow-sm">
                       <div className="text-[11px] font-bold text-gray-400 uppercase tracking-wider">Taux de réponse</div>
                       <div className="text-2xl font-bold tracking-tight">{product?.stores?.response_rate || '98'}% <span className="text-[10px] font-bold text-[#16a34a] uppercase tracking-wider ml-2 px-2 py-0.5 bg-green-500/10 border border-green-500/20 rounded-md">Très Rapide</span></div>
                    </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Extended Features */}
        <div className="mt-16 lg:mt-24 space-y-16 lg:space-y-24">
          <BadgeShelf badges={['verified', 'fast_shipper', 'top_rated', 'premium']} />
          
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2">
              <ProductReviews productId={id || ''} />
            </div>
            <div className="space-y-8">
              <PriceHistory productId={id || ''} currentPrice={product.price_gnf} />
              <DeliveryCalculator productLocation={product.location_commune} />
            </div>
          </div>

          <RecentlyViewedBar />
        </div>
      </main>

      {/* Floating Action Bar for Mobile */}
      <motion.div 
        initial={{ y: 100 }}
        animate={{ y: 0 }}
        className="lg:hidden fixed bottom-0 left-0 right-0 z-50 flex gap-2 bg-white/95 dark:bg-gray-900/95 backdrop-blur-md border-t border-gray-200 dark:border-white/5 p-3 shadow-[0_-4px_20px_-10px_rgba(0,0,0,0.1)]"
      >
        <button 
          onClick={handleOpenChat}
          className="flex-1 bg-gray-100 text-gray-900 h-14 rounded-xl border border-gray-200 font-bold uppercase tracking-wider text-[11px] flex items-center justify-center gap-1 shadow-sm active:scale-95 transition-all"
        >
          <MessageCircle className="w-4 h-4" /> <span className="hidden sm:inline">Message</span>
        </button>
        <button 
          onClick={handleBuyNow}
          className="flex-[2] bg-[#ff6600] text-white h-14 rounded-xl font-bold uppercase tracking-wider text-[12px] flex items-center justify-center gap-1.5 shadow-sm active:scale-[0.98] transition-all"
        >
          <ShoppingBag className="w-5 h-5" /> Acheter
        </button>
      </motion.div>

      <Footer />

      {/* Report modal */}
      {showReport && product && (
        <ReportModal
          contentType="product"
          contentId={product.id}
          contentLabel={product.title}
          onClose={() => setShowReport(false)}
        />
      )}
    </div>
  );
}
