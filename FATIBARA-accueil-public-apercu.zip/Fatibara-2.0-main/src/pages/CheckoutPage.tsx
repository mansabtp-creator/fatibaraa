import React, { useEffect, useState, useMemo, useRef, useCallback } from 'react';
import { useParams, Link, useNavigate, useSearchParams } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { useAppContext } from '../context/AppContext';
import { useStore } from '../store/useStore';
import { useToast } from '../context/ToastContext';
import Header from '../components/Header';
import Footer from '../components/Footer';
import { Skeleton } from '../components/ui/Skeleton';
import AddressPinPicker from '../components/AddressPinPicker';
import { MapPin, Truck, CreditCard, CheckCircle, ArrowLeft, AlertCircle, Wallet, ShieldCheck, Zap, Info, Smartphone, ExternalLink, Loader2, ShoppingBag, Store } from 'lucide-react';
import { BadgeShelf } from '../components/SellerBadges';
import { motion, AnimatePresence } from 'motion/react';
import confetti from 'canvas-confetti';
import { hapticFeedback } from '../lib/haptics';
import { friendlyError } from '../lib/utils';
import { calculateDeliveryFee, FREE_DELIVERY_THRESHOLD } from '../utils/delivery';
import { calculateProductPrice } from '../utils/pricing';
import { APP_NAME } from '../lib/constants';
import { formatGNF } from '../utils/formatters';
import { safeNotify } from '../utils/notifications';
import { useNetworkRetry } from '../hooks/useNetworkRetry';
import { walletCheckoutService } from '../services/walletCheckoutService';

import ReviewModal from '../components/ReviewModal';
import LiveOrderTracking from '../components/LiveOrderTracking';

import { GUINEA_LOCATIONS, ALL_REGIONS } from '../constants/locations';

export default function CheckoutPage() {
  const { id } = useParams();
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const { proMode, user, walletBalance, refreshProfile, savedAddress, setSavedAddress, loyaltyPoints } = useAppContext();
  const { modeEconomie } = useStore();
  const { showToast } = useToast();
  const { withRetry } = useNetworkRetry();
  
  // 1. Basic State
  const [product, setProduct] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [fetchError, setFetchError] = useState<string | null>(null);
  const [step, setStep] = useState(1);
  const [hasAutoFilled, setHasAutoFilled] = useState(false);
  const [lastOrderId, setLastOrderId] = useState('');
  const [lastOrderUUID, setLastOrderUUID] = useState('');
  const [paymentStep, setPaymentStep] = useState<'selection' | 'waiting_pin' | 'processing'>('selection');
  const [paymentError, setPaymentError] = useState<string | null>(null);
  const [isAwaitingConfirmation, setIsAwaitingConfirmation] = useState(false);
  const [orderConfirmed, setOrderConfirmed] = useState(false);
  const [couponCode, setCouponCode] = useState('');
  const [discountPercentage, setDiscountPercentage] = useState(0);
  const [checkingCoupon, setCheckingCoupon] = useState(false);
  const [isRedeemingPoints, setIsRedeemingPoints] = useState(false);
  const [pointsDiscount, setPointsDiscount] = useState(0);

  // ── USSD PIN timeout ────────────────────────────────────────────────────────
  const PIN_TIMEOUT_SECONDS = 60;
  const [pinCountdown, setPinCountdown] = useState(PIN_TIMEOUT_SECONDS);
  const pinTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const pinIntervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const clearPinTimers = useCallback(() => {
    if (pinTimeoutRef.current) { clearTimeout(pinTimeoutRef.current); pinTimeoutRef.current = null; }
    if (pinIntervalRef.current) { clearInterval(pinIntervalRef.current); pinIntervalRef.current = null; }
  }, []);

  const startPinTimer = useCallback(() => {
    clearPinTimers();
    setPinCountdown(PIN_TIMEOUT_SECONDS);
    pinIntervalRef.current = setInterval(() => {
      setPinCountdown(prev => Math.max(0, prev - 1));
    }, 1000);
    pinTimeoutRef.current = setTimeout(() => {
      clearPinTimers();
      setPaymentStep('selection');
      setIsAwaitingConfirmation(false);
      setIsProcessingPayment(false);
      showToast('⏱️ La demande de paiement a expiré ou été annulée. Veuillez réessayer.', 'warning');
    }, PIN_TIMEOUT_SECONDS * 1000);
  }, [clearPinTimers, showToast]);

  // Cleanup on unmount
  useEffect(() => () => clearPinTimers(), [clearPinTimers]);

  // 2. Address & Logistics State
  const [region, setRegion] = useState('Conakry');
  const [commune, setCommune] = useState('Ratoma');

  const availableCommunes = GUINEA_LOCATIONS[region as keyof typeof GUINEA_LOCATIONS] || [];

  const handleRegionChange = (newRegion: string) => {
    setRegion(newRegion);
    const communes = GUINEA_LOCATIONS[newRegion as keyof typeof GUINEA_LOCATIONS] || [];
    setCommune(communes[0] || '');
    hapticFeedback('light');
  };
  const [quartier, setQuartier] = useState('');
  const [indications, setIndications] = useState('');
  const [eta, setEta] = useState<string | null>(null);
  const [distance, setDistance] = useState<number | null>(null);
  const [deliveryFee, setDeliveryFee] = useState(0);
  const [calculatingLogistics, setCalculatingLogistics] = useState(false);
  
  // 3. UI & Interaction State
  const [showReviewModal, setShowReviewModal] = useState(false);
  const [paymentMethod, setPaymentMethod] = useState<'orange' | 'mtn' | 'wallet' | 'cash'>('wallet');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [isProcessingPayment, setIsProcessingPayment] = useState(false);

  // Phone Network Auto-Detection (Guinea)
  const detectedCarrier = useMemo(() => {
    const p = phoneNumber.replace(/\D/g, '');
    if (p.startsWith('62') || p.startsWith('61')) return 'orange';
    if (p.startsWith('66')) return 'mtn';
    if (p.startsWith('65')) return 'cellcom';
    return null;
  }, [phoneNumber]);

  // Auto-switch payment method based on phone prefix, with user feedback
  useEffect(() => {
    if (detectedCarrier === 'orange' || detectedCarrier === 'mtn') {
      if (paymentMethod !== 'wallet' && paymentMethod !== 'cash' && paymentMethod !== detectedCarrier) {
        setPaymentMethod(detectedCarrier);
        hapticFeedback('light');
        const name = detectedCarrier === 'orange' ? 'Orange Money' : 'MTN MoMo';
        showToast(`✓ ${name} détecté automatiquement`, 'success');
      }
    }
  }, [detectedCarrier, paymentMethod]);

  // Ref for isAwaitingConfirmation — lets the Realtime callback read the
  // current value without being listed in the effect deps (which would cause
  // the WebSocket to be torn down and re-created on every boolean flip).
  const isAwaitingConfirmationRef = useRef(false);
  useEffect(() => {
    isAwaitingConfirmationRef.current = isAwaitingConfirmation;
  }, [isAwaitingConfirmation]);

  // Landmarks
  const LANDMARKS = ['Mosquée', 'École', 'Pharmacie', 'Station', 'Marché', 'Rond-point'];

  const appendLandmark = (landmark: string) => {
    setIndications(prev => {
      const trimmed = prev.trim();
      return trimmed ? `${trimmed}, près de ${landmark.toLowerCase()}` : `Près de ${landmark.toLowerCase()}`;
    });
    hapticFeedback('light');
  };

  // 4. Derived State
  const qtyParam = useMemo(() => parseInt(searchParams.get('qty') || '1'), [searchParams]);
  const [quantity, setQuantity] = useState(qtyParam);

  // Parse variation from "Buy Now" flow: /checkout/:id?qty=1&variation={...}
  const [selectedVariation] = useState<Record<string, string>>(() => {
    try {
      const v = searchParams.get('variation');
      return v ? JSON.parse(decodeURIComponent(v)) : {};
    } catch {
      return {};
    }
  });

  // 5. Effects
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  // Subscribe to realtime order updates.
  // IMPORTANT: isAwaitingConfirmation is intentionally NOT in the dep array —
  // it's read via ref inside the callback. Adding it here would destroy and
  // re-create the WebSocket on every toggle, which is very costly on slow
  // mobile networks in Guinea.
  useEffect(() => {
    if (!lastOrderId) return;

    const channel = supabase
      .channel('order_status_updates')
      .on('postgres_changes', {
        event: 'UPDATE',
        schema: 'public',
        table: 'orders',
        filter: lastOrderId.startsWith('ORD-') ? `tracking_number=eq.${lastOrderId}` : `id=eq.${lastOrderId}`,
      }, (payload: any) => {
        // Only act on events when we're actually waiting for a confirmation.
        if (!isAwaitingConfirmationRef.current) return;

        const isConfirmed =
          payload.new.financial_status === 'paid'      ||
          payload.new.financial_status === 'processed' ||
          payload.new.status           === 'accepted'  ||
          payload.new.status           === 'confirmed';

        if (isConfirmed) {
          setOrderConfirmed(true);
          setIsAwaitingConfirmation(false);
          hapticFeedback('reward');
        } else if (payload.new.status === 'cancelled' || payload.new.financial_status === 'failed') {
          setIsAwaitingConfirmation(false);
          setIsProcessingPayment(false);
          setStep(2); // Go back to payment step
          showToast(`❌ Paiement échoué ou annulé: ${payload.new.notes || 'Veuillez réessayer.'}`, "error");
          hapticFeedback('error');
        }
      })
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [lastOrderId]);

  // Handle automatic step advancement upon confirmation
  useEffect(() => {
    if (orderConfirmed) {
      setStep(3);
    }
  }, [orderConfirmed]);

  // AI Assistant for Commune Prediction
  useEffect(() => {
    if (!quartier) return;
    const lowerQ = quartier.toLowerCase();
    
    let newCommune = commune;
    let newEta = 'Aujourd\'hui entre 14h et 18h'; 

    if (lowerQ.includes('kaloum') || lowerQ.includes('almamya') || lowerQ.includes('boulbinet')) {
      newCommune = 'Kaloum';
      newEta = 'Livraison Express: d\'ici 2 heures';
    } else if (lowerQ.includes('dixinn') || lowerQ.includes('cameroun') || lowerQ.includes('hafia')) {
      newCommune = 'Dixinn';
      newEta = 'Livraison Rapide: d\'ici 3 heures';
    } else if (lowerQ.includes('matam') || lowerQ.includes('coleah') || lowerQ.includes('bonfi')) {
      newCommune = 'Matam';
    } else if (lowerQ.includes('ratoma') || lowerQ.includes('kipé') || lowerQ.includes('nongo') || lowerQ.includes('lamba')) {
      newCommune = 'Ratoma';
    } else if (lowerQ.includes('matoto') || lowerQ.includes('entag') || lowerQ.includes('gbessia') || lowerQ.includes('yimbaya')) {
      newCommune = 'Matoto';
      newEta = 'Aujourd\'hui avant 19h';
    }

    if (newCommune !== commune && region === 'Conakry') {
      setCommune(newCommune);
      hapticFeedback('bloom');
    }
    setEta(newEta);
  }, [quartier]);

  // Auto-fill from saved address
  useEffect(() => {
    if (savedAddress && !hasAutoFilled) {
      setRegion(savedAddress.region);
      setCommune(savedAddress.commune);
      setQuartier(savedAddress.quartier);
      setIndications(savedAddress.indications || '');
      if (savedAddress.phone) {
        setPhoneNumber(savedAddress.phone);
      }
      setHasAutoFilled(true);
    }
  }, [savedAddress, hasAutoFilled]);

  // Fetch product details
  useEffect(() => {
    async function fetchProduct() {
      if (!id) return;
      try {
        setLoading(true);
        const { data, error } = await supabase
          .from('products')
          .select('*, stores(id, store_name, location_commune, location_region, owner_id)')
          .eq('id', id)
          .single();
        
        if (error) {
          throw error;
        }
        if (!data) throw new Error("Produit introuvable");

        setProduct({
          ...data,
          vendorRegion: data.stores?.location_region || 'Conakry',
          vendorCommune: data.stores?.location_commune || 'Ratoma'
        });
      } catch (err: any) {
        console.error("Fetch product failure:", err);
        setFetchError(friendlyError(err));
      } finally {
        setLoading(false);
      }
    }
    fetchProduct();
  }, [id]);

  const [vendorDeliveryFee, setVendorDeliveryFee] = useState(0);
  // Guard against double-submit from rapid taps
  const isSubmittingRef = React.useRef(false);
  const [addressErrors, setAddressErrors] = useState<{ quartier?: string, indications?: string }>({});
  
  const handleAddressSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    let hasError = false;
    const errors: any = {};
    if (!quartier) {
      errors.quartier = "Veuillez sélectionner un quartier sur la carte.";
      hasError = true;
    }
    if (!indications || indications.trim().length < 5) {
      errors.indications = "Veuillez fournir des indications plus précises (min. 5 caractères).";
      hasError = true;
    }
    
    if (hasError) {
      setAddressErrors(errors);
      showToast("Veuillez remplir correctement l'adresse", 'warning');
      hapticFeedback('warning');
      return;
    }
    setAddressErrors({});
    
    setCalculatingLogistics(true);
    
    // Real Logistics Calculation via Utility
    const isSameRegion = region === product.vendorRegion;
    
    const { fee, distance: dist } = calculateDeliveryFee(
      { region: product.vendorRegion, commune: product.vendorCommune },
      { region, commune }
    );
    
    const priceInfo = calculateProductPrice(product, quantity, proMode);
    const currentSubtotal = priceInfo.finalPrice * quantity;
    
    setDistance(dist);
    setVendorDeliveryFee(fee);
    
    if (currentSubtotal >= FREE_DELIVERY_THRESHOLD) {
      setDeliveryFee(0);
      setEta(`Livraison estimée: d'ici quelques heures (Gratuit)`);
    } else {
      setDeliveryFee(fee);
      setEta(`Livraison estimée: d'ici quelques heures`);
    }

    hapticFeedback('selection');
    setCalculatingLogistics(false);
    setStep(2);
  };

  const displayPrice = useMemo(() => {
    if (!product) return 0;
    const priceInfo = calculateProductPrice(product, quantity, proMode);
    return priceInfo.finalPrice;
  }, [product, quantity, proMode]);

  const subtotal = displayPrice * quantity;
  const serviceFee = 0;
  const totalPrice = Math.max(0, (subtotal * (1 - discountPercentage / 100)) + serviceFee + deliveryFee - pointsDiscount);

  const handleRedeemPoints = async () => {
    if (!user) return;
    if (loyaltyPoints < 100) {
      showToast("Il vous faut au moins 100 points pour une réduction.", "error");
      return;
    }
    if (pointsDiscount > 0) return; // Already redeemed

    setIsRedeemingPoints(true);
    try {
      // CU-BUG-1 FIX: Verify server-side balance before applying discount.
      // The previous implementation used a fake setTimeout with no server check,
      // meaning the discount was applied to the UI total with no validation.
      // Now we read the live loyalty_points from the DB to prevent stale-state exploits.
      const { data: profile, error: profileErr } = await supabase
        .from('profiles')
        .select('loyalty_points')
        .eq('id', user.id)
        .single();

      if (profileErr || !profile) throw new Error('Impossible de vérifier vos points.');

      const serverPoints = profile.loyalty_points ?? 0;
      if (serverPoints < 100) {
        showToast("Solde de points insuffisant (vérification serveur).", "error");
        return;
      }

      const discount = Math.floor(serverPoints / 100) * 5000;
      setPointsDiscount(discount);
      showToast(`Bravo ! ${formatGNF(discount)} déduits de votre commande.`, "success");
      hapticFeedback('reward');
    } catch (err: any) {
      showToast(err.message || "Erreur lors de la validation des points.", "error");
    } finally {
      setIsRedeemingPoints(false);
    }
  };

  const applyCoupon = async () => {
    setCheckingCoupon(true);
    const { data, error } = await supabase
      .from('coupons')
      .select('discount_percentage')
      .eq('code', couponCode)
      .eq('is_active', true)
      .single();

    if (data && !error) {
       setDiscountPercentage(data.discount_percentage);
    } else {
       showToast("Code promo invalide ou expiré", "error");
       setDiscountPercentage(0);
    }
    setCheckingCoupon(false);
  }

  const handlePaymentSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Guard: prevent double-submit from rapid taps
    if (isSubmittingRef.current) return;
    isSubmittingRef.current = true;

    if (paymentMethod !== 'wallet' && paymentMethod !== 'cash' && !phoneNumber) {
      isSubmittingRef.current = false;
      return;
    }

    // CU-BUG-3 FIX: Refresh the wallet balance from the server before evaluating
    // the wallet gate. AppContext.walletBalance is loaded once at login and can
    // be stale if the user topped up in another tab or session.
    if (paymentMethod === 'wallet') {
      await refreshProfile();
    }

    if (paymentMethod === 'wallet' && walletBalance < totalPrice) {
      showToast(`Solde insuffisant dans votre portefeuille ${APP_NAME}.`, "error");
      isSubmittingRef.current = false;
      return;
    }

    if (!user) {
      showToast("Veuillez vous connecter pour finaliser l'achat.", "info");
      navigate(`/login?redirect=${encodeURIComponent(window.location.pathname + window.location.search)}`);
      return;
    }

    setIsProcessingPayment(true);
    setPaymentError(null);
    
    try {
      const checkoutOrderId = crypto.randomUUID();
      const displayOrderId = `ORD-${Date.now()}-${Math.floor(Math.random() * 1000)}`;
      const validVendorId = (product.stores?.owner_id && product.stores.owner_id.length > 20) ? product.stores.owner_id : null;

      const orderEntry: any = {
        user_id: user.id,
        customer_name: (user.user_metadata?.full_name as string | undefined) || user.email || `Client ${APP_NAME}`,
        items_count: quantity,
        total_amount: totalPrice,
        delivery_fee: deliveryFee,
        status: 'pending',
        tracking_number: displayOrderId,
        delivery_otp: Math.floor(1000 + Math.random() * 9000).toString(),
        shipping_address: {
          region, commune, quartier, indications, phone: phoneNumber || user.email,
          payment_method: paymentMethod,
          payment_id: paymentMethod === 'wallet' ? 'wallet' : (paymentMethod === 'cash' ? 'cod' : checkoutOrderId),
          vendor_delivery_fee: vendorDeliveryFee,
        }
      };
      if (validVendorId) orderEntry.vendor_id = validVendorId;
      if (product.stores?.id) orderEntry.store_id = product.stores.id;

      const orderItemsEntry = [{
        product_id: product.id,
        quantity: quantity,
        price_at_purchase: displayPrice,
        selected_variations: Object.keys(selectedVariation).length > 0 ? selectedVariation : {}
      }];
      
      let dbOrderId: string | null = null;
      
      // Wallet Flow: Use the atomic RPC to deduct money and insert order in one transaction
      if (paymentMethod === 'wallet') {
        const payloadOrders = [orderEntry];
        const payloadDeliveries = [{
          status: 'pending',
          current_location: { region, commune, quartier }
        }];
        const payloadOrderItems = [[{
          product_id: product.id,
          quantity: quantity,
          price_at_purchase: displayPrice
        }]];

        const walletRes = await walletCheckoutService.processCheckout({
          userId: user.id,
          totalAmount: Math.round(totalPrice),
          orders: payloadOrders,
          deliveries: payloadDeliveries,
          orderItems: payloadOrderItems
        });

        if (walletRes.orderIds && walletRes.orderIds.length > 0) {
          dbOrderId = walletRes.orderIds[0];
        }
        await refreshProfile();
      } else if (paymentMethod === 'cash') {
        // Cash only — insert immediately, no payment API needed
        orderEntry.status = 'confirmed';
        const { data: dbOrder, error: orderErr } = await supabase.from('orders').insert([orderEntry]).select('id').single();
        if (orderErr) throw orderErr;
        dbOrderId = dbOrder.id;
        await supabase.from('order_items').insert([{...orderItemsEntry[0], order_id: dbOrderId}]);
      }

      // Mobile Money Flow
      if (paymentMethod === 'orange' || paymentMethod === 'mtn') {
        // Persist the payment intent before gateway verification. The mobile
        // endpoint reads this tracking number to calculate the real amount.
        const { data: mmResult, error: mmErr } = await supabase.rpc('process_cart_checkout', {
          p_user_id: user.id,
          p_payment_method: paymentMethod,
          p_orders: [orderEntry],
          p_deliveries: [{ status: 'pending', current_location: { region, commune, quartier } }],
          p_order_items: [orderItemsEntry],
        });
        if (mmErr) throw new Error(`Erreur création commande: ${mmErr.message}`);
        dbOrderId = (mmResult as any[])?.[0]?.id ?? null;
        if (!dbOrderId) throw new Error('Erreur création commande: identifiant manquant.');

        let data: any;
        try {
          const { data: sessionData } = await supabase.auth.getSession();
          const token = sessionData.session?.access_token;
          const reqHeaders: Record<string, string> = { 'Content-Type': 'application/json' };
          if (token) reqHeaders['Authorization'] = `Bearer ${token}`;

          const response = await withRetry(
            () => fetch('/api/payment/mobile', {
              method: 'POST',
              headers: reqHeaders,
              body: JSON.stringify({
                amount: totalPrice,
                phone: phoneNumber,
                orderId: displayOrderId,
                provider: paymentMethod === 'orange' ? 'ORANGE' : 'MTN'
              }),
            }),
            { maxAttempts: 3, retryMessage: 'Connexion instable. Nouvelle tentative de paiement\u2026' }
          );
          const text = await response.text();
          try { data = JSON.parse(text); } catch { throw new Error('Erreur de format de réponse (JSON attendu).'); }
          if (!response.ok || !data.success) {
            throw new Error(data.error || data.message || "Échec de l'initialisation du paiement.");
          }
        } catch (paymentError) {
          await supabase.rpc('cancel_unpaid_mobile_order', {
            p_order_id: dbOrderId,
            p_reason: 'Initialisation du paiement mobile échouée',
          });
          throw paymentError;
        }

        if (data.payment_url) {
          showToast("Redirection vers le centre de paiement sécurisé...", "info");
          setTimeout(() => { window.location.href = data.payment_url; }, 1500);
          return;
        }
        
        // Deduct loyalty points BEFORE returning for mobile money
        if (pointsDiscount > 0 && loyaltyPoints >= 100) {
          const pointsUsed = Math.floor(loyaltyPoints / 100) * 100;
          supabase.rpc('increment_loyalty_points', { user_id: user.id, points: -pointsUsed })
            .then(() => {})
            .catch(err => console.warn('Points deduction failed (non-blocking):', err));
        }

        showToast("Demande envoyée ! Veuillez confirmer sur votre téléphone.", "success");
        setPaymentStep('waiting_pin');
        startPinTimer();
        setLastOrderId(displayOrderId);
        if (dbOrderId) setLastOrderUUID(dbOrderId);
        setIsAwaitingConfirmation(true);
        return;
      }

      // Cash Flow (Order is already inserted and confirmed)

      // Points processing — runs for wallet and cash (mobile money returns early above
      // so points are deducted before the gateway call below).
      if (pointsDiscount > 0 && loyaltyPoints >= 100) {
        const pointsUsed = Math.floor(loyaltyPoints / 100) * 100;
        try {
          await supabase.rpc('increment_loyalty_points', { user_id: user.id, points: -pointsUsed });
        } catch (err) {
          console.warn('Points deduction failed (non-blocking):', err);
        }
      }

      setLastOrderId(displayOrderId);
      if (dbOrderId) setLastOrderUUID(dbOrderId);
      setIsAwaitingConfirmation(false);
      setOrderConfirmed(true);

      // Save Address to Profile
      if (user && region && commune) {
         const newAddress = { region, commune, quartier, indications, phone: phoneNumber };
         setSavedAddress(newAddress);
         supabase.from('profiles').update({ saved_address: newAddress }).eq('id', user.id).then();
      }

      // Notify
      if (product.stores?.owner_id) {
          await safeNotify({
            user_id: product.stores.owner_id,
            type: 'order',
            title: 'Nouvelle Vente !',
            message: `Un client a commandé: ${product.title}. Veuillez préparer le colis.`
          });
      }

      hapticFeedback('reward');
      setStep(3);
      confetti({ particleCount: 150, spread: 70, origin: { y: 0.6 }, colors: ['#ff6600', '#000000', '#FFFFFF'] });
    } catch (err: any) {
      console.error("Payment error:", err);
      // ISSUE-6: use friendlyError so no raw DB error messages leak to users
      showToast(friendlyError(err), "error");
    } finally {
      setIsProcessingPayment(false);
      isSubmittingRef.current = false; // BUG-1: always reset guard so retries work
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex flex-col bg-white dark:bg-gray-900">
        <Header />
        <main className="flex-grow p-4 md:p-10 max-w-4xl mx-auto w-full">
          <div className="space-y-6">
            <Skeleton className="w-48 h-8 rounded-full" />
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <Skeleton className="md:col-span-2 h-96 rounded-3xl" />
              <Skeleton className="h-64 rounded-3xl" />
            </div>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  if (fetchError || !product) {
    return (
      <div className="min-h-screen flex flex-col bg-gray-50 dark:bg-gray-800">
        <Header />
        <main className="flex-grow flex items-center justify-center p-4">
           <div className="bg-red-500/10 border border-red-500/20 text-red-500 px-6 py-10 rounded-[2.5rem] flex flex-col items-center gap-6 text-center max-w-md">
              <AlertCircle className="w-16 h-16" />
              <h3 className="text-2xl font-bold uppercase tracking-tighter">Oups ! Commande bloquée</h3>
              <p className="text-[15px] font-medium leading-relaxed">{fetchError || "Nous n'avons pas pu charger les détails de ce produit."}</p>
              <Link 
                to="/"
                className="bg-gray-900 text-brand-inverse px-10 py-5 rounded-full text-[13px] font-bold tracking-wider hover:scale-105 active:scale-95 transition-all shadow-xl"
              >
                Retourner à la boutique
              </Link>
           </div>
        </main>
        <Footer />
      </div>
    );
  }

  const baseImageUrl = product.image_urls?.[0] || 'https://picsum.photos/seed/fallback/800/800';
  const imageUrl = modeEconomie ? `${baseImageUrl}?blur=2&q=50` : baseImageUrl;

  return (
    <div className="min-h-screen flex flex-col bg-gray-50 dark:bg-gray-800">
      <Header />
      <main className="flex-grow max-w-4xl mx-auto w-full px-3 md:px-10 py-4 md:py-8 border-t border-gray-200 dark:border-gray-700 mt-4">
        <button onClick={() => step > 1 && step < 3 ? setStep(step - 1) : navigate(-1)} className="inline-flex items-center gap-2 text-[12px] tracking-wider font-bold text-gray-900 dark:text-white hover:translate-x-[-4px] mb-4 md:mb-8 transition-all min-h-[44px]">
          <ArrowLeft className="w-4 h-4" /> Retour
        </button>

        <div className="flex flex-col md:flex-row gap-6 md:gap-10">
          {/* Main Checkout Area */}
          <div className="flex-1">
            {/* Step Indicators */}
            <div className="flex items-center mb-10 md:mb-12 border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-900 p-4 shadow-sm relative z-20">
              <div className="flex flex-col sm:flex-row items-center gap-2 sm:gap-3 flex-1">
                <div className={`w-8 h-8 flex items-center justify-center text-[12px] font-bold border border-gray-200 dark:border-gray-700 ${step >= 1 ? 'bg-[#ff6600] text-white shadow-sm' : 'bg-gray-50 dark:bg-gray-800 text-gray-900 dark:text-white'}`}>1</div>
                <span className={`text-[10px] sm:text-[11px] tracking-wider font-bold ${step >= 1 ? 'text-gray-900 dark:text-white' : 'text-gray-900 dark:text-white/50'}`}>Livraison</span>
              </div>
              <div className={`h-1 flex-1 border-t border-dashed ${step >= 2 ? 'border-[#ff6600]' : 'border-gray-200 dark:border-gray-700/30'}`} />
              <div className="flex flex-col sm:flex-row items-center gap-2 sm:gap-3 flex-1 justify-center">
                <div className={`w-8 h-8 flex items-center justify-center text-[12px] font-bold border border-gray-200 dark:border-gray-700 ${step >= 2 ? 'bg-[#ff6600] text-white shadow-sm' : 'bg-gray-50 dark:bg-gray-800 text-gray-900 dark:text-white'}`}>2</div>
                <span className={`text-[10px] sm:text-[11px] tracking-wider font-bold ${step >= 2 ? 'text-gray-900 dark:text-white' : 'text-gray-900 dark:text-white/50'}`}>Paiement</span>
              </div>
              <div className={`h-1 flex-1 border-t border-dashed ${step >= 3 ? 'border-[#ff6600]' : 'border-gray-200 dark:border-gray-700/30'}`} />
              <div className="flex flex-col sm:flex-row items-center gap-2 sm:gap-3 flex-1 justify-end">
                <div className={`w-8 h-8 flex items-center justify-center text-[12px] font-bold border border-gray-200 dark:border-gray-700 ${step >= 3 ? 'bg-[#ff6600] text-white shadow-sm' : 'bg-gray-50 dark:bg-gray-800 text-gray-900 dark:text-white'}`}>3</div>
                <span className={`text-[10px] sm:text-[11px] tracking-wider font-bold ${step >= 3 ? 'text-gray-900 dark:text-white' : 'text-gray-900 dark:text-white/50'}`}>Confirmation</span>
              </div>
            </div>

            {/* Step 1: Address */}
            {step === 1 && (
              <form onSubmit={handleAddressSubmit} className="space-y-6 md:space-y-8 animate-in fade-in slide-in-from-bottom-4">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between mb-2 md:mb-4 gap-2">
                  <h2 className="text-xl md:text-2xl font-bold text-gray-900 dark:text-white tracking-wider uppercase flex items-center gap-2 md:gap-3">
                    <MapPin className="w-5 h-5 md:w-7 md:h-7 text-[#ff6600]" /> Détails Livraison
                  </h2>
                  {hasAutoFilled && (
                    <div className="flex self-start sm:self-auto items-center gap-1.5 md:gap-2 text-[9px] md:text-[10px] font-bold text-green-950 bg-green-400 px-2.5 py-1 md:px-3 md:py-1.5 border border-gray-200 dark:border-gray-700 shadow-sm tracking-wider animate-in zoom-in">
                      <Zap className="w-3 h-3 md:w-3.5 md:h-3.5" /> 1-Click Prêt
                    </div>
                  )}
                </div>

                <div className="p-5 md:p-8 bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-700 shadow-sm space-y-6 md:space-y-8 relative overflow-hidden">
                  {hasAutoFilled && (
                     <div className="absolute top-0 left-0 w-full h-[6px] bg-green-400 border-b border-gray-200 dark:border-gray-700"></div>
                  )}
                  
                  {hasAutoFilled && (
                    <div className="bg-green-400 p-4 border border-gray-200 dark:border-gray-700 flex flex-col md:flex-row gap-4 items-start md:items-center justify-between shadow-sm">
                      <div>
                        <p className="text-[12px] font-bold text-green-950 tracking-wider mb-1">Votre adresse par défaut est chargée</p>
                        <p className="text-sm font-bold text-green-950/80">Si cette adresse est correcte, validez directement pour continuer.</p>
                      </div>
                    </div>
                  )}

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <label className="text-sm font-semibold text-gray-700 dark:text-gray-300">Région Administrative</label>
                      <select 
                        value={region} 
                        onChange={(e) => handleRegionChange(e.target.value)}
                        className="w-full bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-700 rounded-xl p-4 text-sm font-medium text-gray-900 dark:text-white outline-none focus:ring-2 focus:ring-[#ff6600] focus:border-transparent appearance-none"
                      >
                        {ALL_REGIONS.map(r => <option key={r} value={r}>{r}</option>)}
                      </select>
                    </div>
                    
                    <div className="space-y-2 animate-in zoom-in-95">
                      <label className="text-sm font-semibold text-gray-700 dark:text-gray-300">Préfecture / Commune</label>
                      <select 
                        value={commune} 
                        onChange={(e) => setCommune(e.target.value)}
                        className="w-full bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-700 rounded-xl p-4 text-sm font-medium text-gray-900 dark:text-white outline-none focus:ring-2 focus:ring-[#ff6600] focus:border-transparent appearance-none"
                      >
                        {availableCommunes.map(c => <option key={c} value={c}>{c}</option>)}
                      </select>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <label className="text-[11px] md:text-[12px] font-bold tracking-wider text-gray-900 dark:text-white ml-1">Localisation Visuelle</label>
                    <div className={`border ${addressErrors.quartier ? 'border-red-500' : 'border-gray-200 dark:border-gray-700'} shadow-sm p-2 bg-white dark:bg-gray-900`}>
                      <AddressPinPicker region={region} onSelect={(val) => { setQuartier(val); if(addressErrors.quartier) setAddressErrors({...addressErrors, quartier: undefined}); }} />
                    </div>
                    {addressErrors.quartier && (
                      <div className="flex items-center gap-1.5 text-red-500 text-xs mt-1.5 font-bold uppercase tracking-wider">
                        <AlertCircle className="w-3.5 h-3.5" />
                        <span>{addressErrors.quartier}</span>
                      </div>
                    )}
                    
                    {/* Location Feedback + ETA Engine */}
                    {quartier ? (
                      <div className="space-y-2">
                        <div className="p-3 md:p-4 bg-[#ff6600]/10 border border-[#ff6600]/20 rounded-[1.25rem] flex items-center gap-3 text-[#ff6600] animate-in slide-in-from-top-2">
                            <CheckCircle className="w-4 h-4 md:w-5 md:h-5 flex-shrink-0" />
                            <span className="text-[12px] md:text-[13px] font-bold leading-tight">{quartier}</span>
                        </div>
                        {eta && (
                          <div className="pl-2 flex items-center gap-2 text-gray-900 dark:text-white animate-in fade-in">
                            <Truck className="w-4 h-4 text-brand-text-dim" />
                            <span className="text-[11px] font-bold">{eta}</span>
                          </div>
                        )}
                      </div>
                    ) : (
                       <div className="p-3 bg-orange-50 border border-orange-100 rounded-[1.25rem] flex items-center gap-2 text-orange-600 text-[11px] font-bold">
                         <AlertCircle className="w-3.5 h-3.5" /> Touchez la carte pour définir un point de repère précis.
                       </div>
                    )}
                  </div>

                  <div className="space-y-2">
                    <label className="flex justify-between items-center text-[11px] md:text-[12px] font-bold tracking-wider text-gray-900 dark:text-white ml-1">
                      <span>Indications Livreur</span>
                      <span className="text-[10px] bg-gray-900 text-white px-2 py-0.5 tracking-wider border border-gray-200 dark:border-gray-700">Obligatoire</span>
                    </label>
                    
                    {/* Landmark Chips */}
                    <div className="flex flex-wrap gap-2 mb-3">
                      {LANDMARKS.map(lm => (
                        <button
                          key={lm}
                          type="button"
                          onClick={() => appendLandmark(lm)}
                          className="bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-700 hover:bg-[#ff6600] hover:text-white text-[10px] font-bold text-gray-900 dark:text-white min-h-[44px] px-4 tracking-wider transition-all active:-translate-y-1 hover:shadow-sm shadow-sm hover:translate-x-[-2px] hover:translate-y-[-2px] flex items-center justify-center"
                        >
                          + {lm}
                        </button>
                      ))}
                    </div>

                    <textarea 
                      required
                      value={indications}
                      onChange={(e) => { setIndications(e.target.value); if(addressErrors.indications) setAddressErrors({...addressErrors, indications: undefined}); }}
                      placeholder="Ex: Portail noir à côté de la pharmacie..." 
                      className={`w-full bg-white dark:bg-gray-900 border ${addressErrors.indications ? 'border-red-500' : 'border-gray-200 dark:border-gray-700'} rounded-xl p-4 md:p-5 text-sm font-medium text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-[#ff6600] focus:border-transparent transition-all min-h-[100px] md:min-h-[120px] placeholder:text-gray-400`} 
                    />
                    {addressErrors.indications && (
                      <div className="flex items-center gap-1.5 text-red-500 text-xs mt-1.5 font-bold uppercase tracking-wider">
                        <AlertCircle className="w-3.5 h-3.5" />
                        <span>{addressErrors.indications}</span>
                      </div>
                    )}
                  </div>
                </div>

                <div className="px-1 md:px-0 pb-6 md:pb-0">
                  <button 
                    type="submit" 
                    disabled={calculatingLogistics || !quartier || !indications.trim()}
                    className="group w-full bg-[#ff6600] text-white py-4 md:py-4 rounded-xl text-[16px] font-bold flex items-center justify-center gap-3 transition-all hover:bg-[#e62e00] shadow-sm disabled:opacity-50"
                  >
                    {calculatingLogistics ? (
                      <><Zap className="w-5 h-5 animate-pulse" /> Routage...</>
                    ) : (
                      <>Paiement <Smartphone className="w-4 h-4 md:w-5 md:h-5 group-hover:translate-x-1 transition-transform" /></>
                    )}
                  </button>
                </div>
              </form>
            )}

            {/* Step 2: Payment */}
            {step === 2 && (
              <div className="space-y-6 md:space-y-8 animate-in fade-in slide-in-from-bottom-4 mb-24 md:mb-0">
                {paymentStep === 'waiting_pin' ? (
                  <div className="bg-white dark:bg-gray-900 border-2 border-[#ff6600] shadow-xl rounded-3xl p-8 text-center space-y-6">
                    <div className="w-20 h-20 bg-orange-50 rounded-full flex items-center justify-center mx-auto relative">
                      <Smartphone className="w-10 h-10 text-[#ff6600]" />
                      <div className="absolute inset-0 bg-[#ff6600] rounded-full animate-ping opacity-20"></div>
                    </div>
                    <div>
                      <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-2">Vérifiez votre téléphone</h2>
                      <p className="text-gray-600 dark:text-gray-400">
                        Une demande de paiement a été envoyée au <span className="font-bold text-[#ff6600]">{phoneNumber}</span>.
                        <br />Veuillez saisir votre code PIN secret pour confirmer.
                      </p>
                    </div>

                    <div className="p-4 bg-gray-50 dark:bg-gray-800 rounded-2xl space-y-3">
                      <div className="flex items-center justify-center gap-4">
                        <Loader2 className="w-5 h-5 text-[#ff6600] animate-spin" />
                        <span className="text-sm font-bold text-gray-900 dark:text-white uppercase tracking-widest">En attente de confirmation...</span>
                      </div>
                      <p className="text-[10px] text-gray-500 font-bold uppercase">Ne fermez pas cette page</p>
                      {/* Live countdown */}
                      <div className="flex items-center justify-center gap-2 pt-1">
                        <span
                          className="text-3xl font-black tabular-nums"
                          style={{ color: pinCountdown <= 15 ? '#ef4444' : pinCountdown <= 30 ? '#f59e0b' : '#ff6600' }}
                        >
                          {String(pinCountdown).padStart(2, '0')}s
                        </span>
                        <span className="text-[10px] text-gray-400 font-bold uppercase tracking-wider">avant expiration</span>
                      </div>
                    </div>

                    <div className="pt-4 space-y-4">
                      <p className="text-xs text-gray-500 italic">
                        Si vous ne recevez pas de notification, composez :
                        <br />
                        <span className="font-bold text-gray-900 dark:text-white">Orange: *144# | MTN: *440#</span>
                      </p>
                      <button 
                        onClick={() => {
                          clearPinTimers();
                          setPaymentStep('selection');
                          setIsAwaitingConfirmation(false);
                          setIsProcessingPayment(false);
                        }}
                        className="text-sm font-bold text-[#ff6600] hover:underline"
                      >
                        Annuler et changer de méthode
                      </button>
                    </div>
                  </div>
                ) : (
                  <div className="bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-700 shadow-sm rounded-3xl p-5 md:p-8">
                    <h2 className="text-xl md:text-2xl font-bold text-gray-900 dark:text-white tracking-wider uppercase flex items-center gap-2 md:gap-3 mb-8">
                      <CreditCard className="w-5 h-5 md:w-7 md:h-7 text-[#ff6600]" /> Informations Paiement
                    </h2>
                    
                    {/* ISSUE-11: Show real delivery status based on calculated fee */}
                    <div className={`flex flex-col sm:flex-row items-start sm:items-center justify-between p-4 md:p-6 ${deliveryFee === 0 ? 'bg-emerald-50 dark:bg-emerald-500/10 border border-emerald-100 dark:border-emerald-500/20' : 'bg-orange-50 dark:bg-orange-500/10 border border-orange-100 dark:border-orange-500/20'} rounded-2xl mb-8 gap-4`}>
                    <div className="flex items-center gap-3">
                      <div className={`w-12 h-12 bg-white dark:bg-gray-900 rounded-full flex items-center justify-center flex-shrink-0 shadow-sm ${deliveryFee === 0 ? 'text-[#16a34a] border border-emerald-100 dark:border-emerald-500/20' : 'text-[#ff6600] border border-orange-100 dark:border-orange-500/20'}`}>
                        <Truck className="w-6 h-6" />
                      </div>
                      <div>
                        <p className="text-sm font-bold text-gray-900 dark:text-white leading-none mb-1.5">
                          {deliveryFee === 0 ? 'Livraison Gratuite' : 'Frais de Livraison'}
                        </p>
                        <p className={`text-xs font-semibold ${deliveryFee === 0 ? 'text-[#16a34a]' : 'text-[#ff6600]'}`}>
                          {region === product.vendorRegion ? 'Directe à domicile' : `Vers : ${region}`}
                        </p>
                      </div>
                    </div>
                    <div className="mt-2 sm:mt-0 text-left sm:text-right">
                      {deliveryFee === 0 ? (
                        <p className="text-lg flex items-center gap-1 font-bold text-[#16a34a]"><CheckCircle className="w-4 h-4" /> GRATUIT</p>
                      ) : (
                        <p className="text-lg font-bold text-[#ff6600]">{deliveryFee.toLocaleString('fr-FR')} GNF</p>
                      )}
                      <p className="text-[10px] font-semibold text-gray-500 uppercase mt-1">Prise en charge incluse</p>
                    </div>
                  </div>

                  <form onSubmit={handlePaymentSubmit} className="space-y-8 md:space-y-10">
                    <div className="space-y-3">
                      <h4 className="text-sm font-semibold text-gray-700 dark:text-gray-300">Réduction ou Code Promo</h4>
                      <div className="flex bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-700 rounded-xl shadow-sm overflow-hidden">
                        <input type="text" value={couponCode} onChange={(e) => setCouponCode(e.target.value)} className="flex-1 min-w-0 bg-transparent px-4 py-3 text-sm font-semibold text-gray-900 dark:text-white outline-none border-r border-gray-200 dark:border-gray-700 placeholder:text-gray-400" placeholder="Entrez votre code" />
                        <button type="button" onClick={applyCoupon} disabled={checkingCoupon} className="whitespace-nowrap shrink-0 px-4 py-3 text-sm font-bold bg-gray-50 dark:bg-gray-800 text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 transition-all active:scale-95 disabled:opacity-50 min-h-[44px] sm:w-[150px]">{checkingCoupon ? '...' : 'Appliquer'}</button>
                      </div>
                    </div>

                    <div className="space-y-3">
                      <label className="text-sm font-semibold text-gray-700 dark:text-gray-300">Fidélité {APP_NAME}</label>
                      <div className="p-4 bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 flex items-center justify-between rounded-xl">
                         <div>
                            <p className="text-sm font-bold text-gray-900 dark:text-white mb-1">{loyaltyPoints} Points Disponibles</p>
                            <p className="text-xs font-semibold text-gray-500">100 pts = 5,000 GNF de réduction</p>
                         </div>
                         <button 
                           type="button"
                           disabled={isRedeemingPoints || loyaltyPoints < 100 || pointsDiscount > 0}
                           onClick={handleRedeemPoints}
                           className="bg-gray-900 dark:bg-gray-700 text-white px-4 py-2 font-bold text-sm hover:bg-[#ff6600] disabled:opacity-50 transition-all active:scale-95 rounded-lg shadow-sm"
                         >
                           {isRedeemingPoints ? '...' : pointsDiscount > 0 ? 'Utilisé' : 'Utiliser'}
                         </button>
                      </div>
                    </div>

                    <div className="space-y-3">
                      <label className="text-sm font-semibold text-gray-700 dark:text-gray-300">Choix du Guichet</label>
                      <div className="space-y-3">
                      {/* ── TILE A: Fatibara Wallet (Primary / Recommended) ── */}
                      {user && (() => {
                        const hasSufficientBalance = walletBalance >= totalPrice;
                        const deficit = Math.max(0, totalPrice - walletBalance);
                        return (
                          <div
                            id="payment-tile-wallet"
                            role="button"
                            tabIndex={0}
                            onClick={() => setPaymentMethod('wallet')}
                            onKeyDown={(e) => {
                              if (e.key === 'Enter' || e.key === ' ') {
                                e.preventDefault();
                                setPaymentMethod('wallet');
                              }
                            }}
                            className={`w-full text-left p-5 rounded-2xl border-2 transition-all cursor-pointer focus:outline-none focus:ring-2 focus:ring-emerald-500/50 ${
                              paymentMethod === 'wallet'
                                ? hasSufficientBalance
                                  ? 'border-emerald-500 bg-emerald-500/5 dark:bg-emerald-500/10'
                                  : 'border-amber-500 bg-amber-500/5 dark:bg-amber-500/10'
                                : 'border-gray-200 dark:border-gray-700 hover:border-gray-300 dark:hover:border-gray-600 bg-white dark:bg-gray-900'
                            }`}
                          >
                            <div className="flex items-center justify-between mb-3">
                              <div className="flex items-center gap-2.5">
                                <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${
                                  paymentMethod === 'wallet'
                                    ? hasSufficientBalance ? 'bg-emerald-500 text-white' : 'bg-amber-500 text-white'
                                    : 'bg-gray-100 dark:bg-gray-800 text-gray-500'
                                }`}>
                                  <Wallet className="w-5 h-5" />
                                </div>
                                <div>
                                  <p className="text-sm font-black text-gray-900 dark:text-white uppercase tracking-tight">Solde Fatibara Wallet</p>
                                  <p className="text-[11px] font-bold text-gray-500 tabular-nums">
                                    {formatGNF(walletBalance)} disponible
                                  </p>
                                </div>
                              </div>
                              {hasSufficientBalance ? (
                                <span className="shrink-0 flex items-center gap-1.5 px-3 py-1.5 bg-emerald-500 text-white text-[10px] font-black uppercase tracking-wider rounded-full">
                                  <Zap className="w-3 h-3" /> Payer en 1-Clic
                                </span>
                              ) : (
                                <span className="shrink-0 px-2.5 py-1 bg-gray-100 dark:bg-gray-800 text-[10px] font-black text-gray-400 uppercase tracking-wider rounded-full border border-gray-200 dark:border-gray-700">
                                  RECOMMANDÉ
                                </span>
                              )}
                            </div>

                            {/* Insufficient balance warning + topup CTA */}
                            {paymentMethod === 'wallet' && !hasSufficientBalance && (
                              <div className="mt-3 pt-3 border-t border-amber-200 dark:border-amber-500/30">
                                <div className="flex items-center gap-2 mb-3">
                                  <AlertCircle className="w-4 h-4 text-amber-600 dark:text-amber-400 shrink-0" />
                                  <p className="text-xs font-bold text-amber-700 dark:text-amber-400">
                                    Solde insuffisant — Manque{' '}
                                    <span className="font-black">{formatGNF(deficit)}</span>
                                  </p>
                                </div>
                                <button
                                  id="topup-and-pay-btn"
                                  type="button"
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    navigate(`/dashboard?tab=wallet&topup=${deficit}`);
                                  }}
                                  className="w-full min-h-[44px] rounded-xl bg-amber-500 hover:bg-amber-600 text-white text-xs font-black uppercase tracking-wider transition-all active:scale-95 flex items-center justify-center gap-2"
                                >
                                  <Zap className="w-3.5 h-3.5" />
                                  Recharger {formatGNF(deficit)} &amp; Payer
                                </button>
                              </div>
                            )}
                          </div>
                        );
                      })()}

                      {/* ── TILE B: Mobile Money (Fallback) ── */}
                      <div
                        id="payment-tile-mobilemoney"
                        role="button"
                        tabIndex={0}
                        onClick={() => setPaymentMethod(detectedCarrier === 'mtn' ? 'mtn' : 'orange')}
                        onKeyDown={(e) => {
                          if (e.key === 'Enter' || e.key === ' ') {
                            e.preventDefault();
                            setPaymentMethod(detectedCarrier === 'mtn' ? 'mtn' : 'orange');
                          }
                        }}
                        className={`w-full text-left p-5 rounded-2xl border-2 transition-all cursor-pointer focus:outline-none focus:ring-2 focus:ring-[#ff6600]/50 ${
                          (paymentMethod === 'orange' || paymentMethod === 'mtn')
                            ? 'border-[#ff6600] bg-orange-50/50 dark:bg-[#ff6600]/5'
                            : 'border-gray-200 dark:border-gray-700 hover:border-gray-300 dark:hover:border-gray-600 bg-white dark:bg-gray-900'
                        }`}
                      >
                        <div className="flex items-center justify-between mb-3">
                          <div className="flex items-center gap-2.5">
                            <div className={`w-10 h-10 rounded-xl flex items-center justify-center text-lg ${
                              paymentMethod === 'orange' || paymentMethod === 'mtn'
                                ? 'bg-[#ff6600]/15 border border-[#ff6600]/30'
                                : 'bg-gray-100 dark:bg-gray-800'
                            }`}>
                              📱
                            </div>
                            <div>
                              <p className="text-sm font-black text-gray-900 dark:text-white uppercase tracking-tight">Mobile Money</p>
                              <p className="text-[11px] font-bold text-gray-500">Orange Money · MTN MoMo</p>
                            </div>
                          </div>
                          <div className="flex items-center gap-1.5">
                            {/* Sub-selector: Orange / MTN */}
                            {['orange', 'mtn'].map((m: any) => (
                              <button
                                key={m}
                                type="button"
                                id={`carrier-${m}`}
                                onClick={(e) => { e.stopPropagation(); setPaymentMethod(m); }}
                                className={`px-3 py-1.5 rounded-lg text-[10px] font-black uppercase tracking-wider transition-all border ${
                                  paymentMethod === m
                                    ? m === 'orange'
                                      ? 'bg-orange-500 text-white border-orange-500'
                                      : 'bg-yellow-400 text-black border-yellow-400'
                                    : 'bg-gray-100 dark:bg-gray-800 text-gray-500 border-gray-200 dark:border-gray-700'
                                }`}
                              >
                                {m === 'orange' ? '🟠 OM' : '🟡 MTN'}
                              </button>
                            ))}
                          </div>
                        </div>
                      </div>

                      {/* Cash on Delivery tile */}
                      <button
                        id="payment-tile-cash"
                        type="button"
                        onClick={() => setPaymentMethod('cash')}
                        className={`w-full text-left px-5 py-4 rounded-2xl border-2 transition-all flex items-center gap-3 ${
                          paymentMethod === 'cash'
                            ? 'border-gray-900 dark:border-white bg-gray-50 dark:bg-white/5'
                            : 'border-gray-200 dark:border-gray-700 hover:border-gray-300 bg-white dark:bg-gray-900'
                        }`}
                      >
                        <div className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${
                          paymentMethod === 'cash' ? 'bg-gray-900 dark:bg-white text-white dark:text-gray-900' : 'bg-gray-100 dark:bg-gray-800 text-gray-500'
                        }`}>
                          <Truck className="w-5 h-5" />
                        </div>
                        <div>
                          <p className="text-sm font-black text-gray-900 dark:text-white uppercase tracking-tight">Paiement à la Livraison</p>
                          <p className="text-[11px] font-bold text-gray-500">Cash on Delivery (COD)</p>
                        </div>
                      </button>
                    </div>

                    <AnimatePresence mode="wait">
                      {paymentMethod !== 'wallet' && (
                        <motion.div 
                          key="phone-input"
                          initial={{ height: 0, opacity: 0 }}
                          animate={{ height: 'auto', opacity: 1 }}
                          exit={{ height: 0, opacity: 0 }}
                          className="space-y-4 overflow-hidden"
                        >
                          <label className="text-sm font-semibold text-gray-700 dark:text-gray-300">Numéro de téléphone ({paymentMethod === 'orange' ? 'Orange' : 'MTN'})</label>
                          <div className="relative flex items-center">
                            <input 
                              type="tel" 
                              required
                              value={phoneNumber}
                              onChange={(e) => {
                                const val = e.target.value.replace(/\D/g, '').slice(0, 9);
                                setPhoneNumber(val);
                              }}
                              placeholder="Ex: 622 XX XX XX" 
                              className="w-full bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-700 rounded-xl p-4 md:p-5 pr-24 text-xl font-bold text-gray-900 dark:text-white tracking-wide focus:ring-2 focus:ring-[#ff6600] focus:border-transparent transition-all outline-none placeholder:text-gray-300" 
                            />
                            <AnimatePresence>
                              {detectedCarrier && (
                                <motion.div 
                                  initial={{ opacity: 0, scale: 0.8 }}
                                  animate={{ opacity: 1, scale: 1 }}
                                  exit={{ opacity: 0, scale: 0.8 }}
                                  className="absolute right-4 flex items-center"
                                >
                                  {detectedCarrier === 'orange' && (
                                    <span className="bg-[#ff6600] text-white text-[11px] font-black tracking-wider px-3 py-1.5 rounded-lg shadow-sm">
                                      ORANGE
                                    </span>
                                  )}
                                  {detectedCarrier === 'mtn' && (
                                    <span className="bg-[#ffcc00] text-black text-[11px] font-black tracking-wider px-3 py-1.5 rounded-lg shadow-sm">
                                      MTN
                                    </span>
                                  )}
                                  {detectedCarrier === 'cellcom' && (
                                    <span className="bg-[#e4002b] text-white text-[11px] font-black tracking-wider px-3 py-1.5 rounded-lg shadow-sm">
                                      CELLCOM
                                    </span>
                                  )}
                                </motion.div>
                              )}
                            </AnimatePresence>
                          </div>
                          <div className="flex items-start gap-4 p-6 bg-gray-900 text-white rounded-2xl shadow-lg tracking-wider text-[12px] leading-relaxed mt-6 relative overflow-hidden ring-2 ring-[#ff6600]/20">
                            <div className="absolute top-0 right-0 p-2 opacity-5">
                               <Smartphone className="w-20 h-20" />
                            </div>
                            <div className="flex flex-col gap-3 relative z-10 w-full">
                               <div className="flex items-center gap-3">
                                  <div className="w-8 h-8 rounded-full bg-[#ff6600] text-white flex items-center justify-center font-black text-xs animate-pulse">!</div>
                                  <span className="font-bold text-sm tracking-wide">CONFIRMATION SUR TÉLÉPHONE</span>
                               </div>
                               <p className="opacity-90 font-medium">
                                  Cliquez sur <span className="font-bold text-white bg-white/10 px-1.5 py-0.5 rounded">Confirmer & Payer</span>, puis entrez votre code PIN sur votre téléphone pour valider.
                               </p>
                               <div className="flex justify-between items-center bg-white/5 p-3 rounded-lg border border-white/10">
                                   <span className="font-mono text-lg tracking-widest text-[#ff6600] font-bold">Orange: *144*4*2#</span>
                                   <span className="font-mono text-lg tracking-widest text-[#ff6600] font-bold">MTN: *115#</span>
                               </div>
                            </div>
                          </div>
                        </motion.div>
                      )}
                    </AnimatePresence>

                    {/* ── Fee Breakdown ── */}
                    <div className="space-y-2 pt-6 border-t border-gray-200 dark:border-gray-700 border-dashed">
                      <div className="flex justify-between items-center text-sm text-gray-600 dark:text-gray-400 font-medium px-1">
                        <span>Sous-total</span>
                        <span className="tabular-nums font-bold">{subtotal.toLocaleString('fr-FR')} GNF</span>
                      </div>
                      {discountPercentage > 0 && (
                        <div className="flex justify-between items-center text-sm text-emerald-600 dark:text-emerald-400 font-bold px-1">
                          <span>Réduction ({discountPercentage}%)</span>
                          <span className="tabular-nums">-{Math.round(subtotal * discountPercentage / 100).toLocaleString('fr-FR')} GNF</span>
                        </div>
                      )}
                      {pointsDiscount > 0 && (
                        <div className="flex justify-between items-center text-sm text-emerald-600 dark:text-emerald-400 font-bold px-1">
                          <span>Points fidélité</span>
                          <span className="tabular-nums">-{pointsDiscount.toLocaleString('fr-FR')} GNF</span>
                        </div>
                      )}
                      <div className="flex justify-between items-center text-sm text-gray-600 dark:text-gray-400 font-medium px-1">
                        <span>Livraison</span>
                        {deliveryFee === 0
                          ? <span className="font-black text-emerald-600 dark:text-emerald-400">GRATUIT</span>
                          : <span className="tabular-nums font-bold">{deliveryFee.toLocaleString('fr-FR')} GNF</span>
                        }
                      </div>
                      <div className="flex justify-between items-center text-xl font-black text-gray-900 dark:text-white py-2 px-1 border-t border-gray-200 dark:border-gray-700 mt-1">
                        <span>Total</span>
                        <div className="flex flex-col items-end">
                          {(discountPercentage > 0 || pointsDiscount > 0) && (
                            <span className="text-sm text-gray-400 line-through font-medium tabular-nums">
                              {(subtotal + serviceFee + deliveryFee).toLocaleString('fr-FR')} GNF
                            </span>
                          )}
                          <span className="tabular-nums">{totalPrice.toLocaleString('fr-FR')} GNF</span>
                        </div>
                      </div>
                    </div>

                    <button 
                        type="submit" 
                        disabled={
                          isProcessingPayment ||
                          isAwaitingConfirmation ||
                          (paymentMethod === 'wallet' && walletBalance < totalPrice) ||
                          (paymentMethod !== 'wallet' && paymentMethod !== 'cash' && !phoneNumber)
                        }
                        className="group w-full bg-[#ff6600] text-white py-4 md:py-4 rounded-xl text-[16px] font-bold hover:bg-[#e62e00] transition-all shadow-sm active:scale-[0.98] flex items-center justify-center gap-2 md:gap-3 disabled:opacity-50"
                      >
                        {isProcessingPayment ? (
                          <><Loader2 className="w-5 h-5 animate-spin" /> Autorisation en cours...</>
                        ) : isAwaitingConfirmation ? (
                          <><Loader2 className="w-5 h-5 animate-spin" /> En attente de confirmation...</>
                        ) : paymentMethod === 'wallet' ? (
                          <><Zap className="w-5 h-5" /> Payer en 1-Clic — {totalPrice.toLocaleString('fr-FR')} GNF</>
                        ) : (
                          <>Confirmer &amp; Payer {totalPrice.toLocaleString('fr-FR')} GNF <ExternalLink className="w-5 h-5 group-hover:scale-110 transition-transform" /></>
                        )}
                      </button>
                      
                      <div className="flex items-center justify-center gap-6 pt-4">
                         {[1, 2, 3].map(i => (
                           <div key={i} className="h-2 w-8 bg-gray-900 opacity-20"></div>
                         ))}
                      </div>
                    </div>
                  </form>
                </div>
              )}
              </div>
            )}

            {/* Step 3: Success & Live Tracking */}
            {step === 3 && (
              <div className="space-y-8 animate-in zoom-in-95 duration-500">
                <div className="text-center p-8 md:p-12 bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-700 shadow-sm rounded-3xl relative overflow-hidden">
                  <div className="w-20 h-20 md:w-24 md:h-24 bg-green-50 text-green-600 rounded-full flex items-center justify-center mx-auto mb-8">
                    <Zap className="w-10 h-10 md:w-12 md:h-12 fill-green-600" />
                  </div>
                  <h2 className="text-2xl md:text-3xl font-bold text-gray-900 dark:text-white mb-4">Félicitations !</h2>
                  <p className="text-sm md:text-base font-medium text-gray-600 dark:text-gray-400 mb-8 max-w-md mx-auto leading-relaxed">
                    Votre commande <span className="font-bold text-gray-900 dark:text-white">#{lastOrderId.slice(0, 8)}</span> a été confirmée avec succès. Elle sera bientôt traitée.
                  </p>
                  <div className="flex flex-col sm:flex-row gap-4 justify-center">
                    <Link to="/" className="inline-block bg-gray-100 dark:bg-gray-800 text-gray-900 dark:text-white py-4 px-8 rounded-xl text-sm font-bold hover:bg-gray-200 dark:hover:bg-gray-700 transition-all active:scale-[0.98]">
                      Continuer mes achats
                    </Link>
                    <button 
                      onClick={() => setShowReviewModal(true)}
                      className="inline-block bg-[#ff6600] text-white py-4 px-8 rounded-xl text-sm font-bold hover:bg-[#e62e00] transition-all active:scale-[0.98] shadow-sm"
                    >
                      Noter le vendeur
                    </button>
                  </div>
                </div>

                <ReviewModal 
                  isOpen={showReviewModal}
                  onClose={() => setShowReviewModal(false)}
                  productId={product.id}
                  orderId={lastOrderId}
                  onSuccess={() => setShowReviewModal(false)}
                />

                <LiveOrderTracking orderId={lastOrderId} orderUUID={lastOrderUUID} region={region} quartier={quartier} />
                
                <div className="p-8 bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-700 shadow-sm rounded-3xl text-center">
                   <div className="w-12 h-12 bg-orange-50 rounded-full flex items-center justify-center mx-auto mb-4">
                     <ShieldCheck className="w-6 h-6 text-[#ff6600]" />
                   </div>
                   <h4 className="text-base font-bold text-gray-900 dark:text-white mb-2">Achat Protégé</h4>
                   <p className="text-sm text-gray-600 dark:text-gray-400 max-w-sm mx-auto">
                     Le paiement est bloqué jusqu'à ce que vous confirmiez la réception. En cas de problème, notre support intervient en moins de 15 minutes.
                   </p>
                </div>
              </div>
            )}
          </div>

            {/* Order Summary Sidebar */}
            <div className={`w-full md:w-[22rem] flex-shrink-0 ${step === 3 ? 'hidden' : 'block'}`}>
              <div className="bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-700 shadow-sm rounded-3xl p-6 md:p-8 sticky top-[110px] mb-6 md:mb-0">
                <h3 className="text-lg font-bold text-gray-900 dark:text-white mb-6 md:mb-8 border-b border-gray-100 dark:border-gray-800 pb-4 flex items-center gap-2">
                  <ShoppingBag className="w-5 h-5" /> Résumé Commande
                </h3>
                
                <div className="flex gap-4 mb-6 md:mb-8">
                  <div className="w-16 h-16 md:w-20 md:h-20 border border-gray-200 dark:border-gray-700 rounded-xl overflow-hidden flex-shrink-0 bg-gray-50 dark:bg-gray-800">
                     <img src={imageUrl} alt={product.title} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                  </div>
                  <div className="flex flex-col justify-center">
                    <h4 className="text-sm font-semibold text-gray-900 dark:text-white leading-tight mb-1.5 line-clamp-2">{product.title}</h4>
                    <div className="flex items-center gap-3 bg-gray-100 dark:bg-gray-800 rounded-full px-2 py-1 shadow-sm self-start">
                      <button 
                        type="button" 
                        onClick={() => setQuantity(Math.max(1, quantity - 1))}
                        disabled={step !== 1}
                        className="w-6 h-6 flex items-center justify-center rounded-full bg-white dark:bg-gray-700 shadow-sm font-bold text-gray-700 dark:text-gray-300 hover:bg-gray-50 active:scale-95 disabled:opacity-50"
                      >
                        -
                      </button>
                      <span className="text-xs font-bold text-gray-900 dark:text-white w-4 text-center">{quantity}</span>
                      <button 
                        type="button" 
                        onClick={() => setQuantity(quantity + 1)}
                        disabled={step !== 1}
                        className="w-6 h-6 flex items-center justify-center rounded-full bg-white dark:bg-gray-700 shadow-sm font-bold text-gray-700 dark:text-gray-300 hover:bg-gray-50 active:scale-95 disabled:opacity-50"
                      >
                        +
                      </button>
                    </div>
                  </div>
                </div>

                <div className="space-y-4 px-1 text-sm border-b border-gray-100 dark:border-gray-800 pb-6 mb-6">
                  <h4 className="text-xs font-bold text-gray-500 mb-2">Détails du paiement</h4>
                  <div className="flex justify-between items-center text-gray-600 dark:text-gray-400 font-semibold">
                    <span>Sous-total</span>
                     <span className="text-gray-900 dark:text-white text-base">{formatGNF(subtotal)}</span>
                  </div>
                  <div className="flex justify-between items-center group font-semibold text-gray-600 dark:text-gray-400">
                    <span className="flex items-center gap-1.5">
                      Frais Livraison {step === 1 && <span className="w-2 h-2 rounded-full bg-[#ff6600] animate-pulse" />}
                    </span>
                    <span className={`text-base ${step > 1 ? 'text-emerald-500 font-bold' : 'text-[#ff6600] italic text-sm'}`}>
                      {step > 1 ? `Gratuit` : 'Calcul en cours...'}
                    </span>
                  </div>

                </div>

                <div className="space-y-6">
                  <div className="flex justify-between items-end px-1 pt-2">
                    <span className="text-base font-bold text-gray-900 dark:text-white">Net à payer</span>
                    <div className="text-right">
                      <span className="text-3xl font-bold text-[#ff6600] tracking-tight tabular-nums leading-none">
                        {step > 1 ? Math.floor(totalPrice).toLocaleString('fr-FR') : Math.floor(subtotal + serviceFee).toLocaleString('fr-FR')}
                      </span>
                      <span className="text-[11px] font-bold text-gray-500 dark:text-gray-400 ml-1.5 uppercase align-top">GNF</span>
                    </div>
                  </div>

                  <div className="mt-8 p-4 bg-green-50 rounded-2xl flex items-start gap-3 border border-green-100">
                     <div className="w-8 h-8 rounded-full bg-white flex items-center justify-center shrink-0 border border-green-200">
                        <ShieldCheck className="w-4 h-4 text-[#16a34a]" />
                     </div>
                     <div>
                       <p className="text-[12px] font-semibold text-green-900">
                         Paiements sécurisés par Lengo Pay. Les vendeurs sont payés à la livraison.
                       </p>
                       <p className="text-[11px] font-medium text-green-700/80 mt-1 opacity-90">Vendeur : {product.stores?.store_name || 'Vendeur Indépendant'}</p>
                     </div>
                  </div>
                </div>
              </div>
            </div>
        </div>
      </main>
      <Footer />
    </div>
  );
}
