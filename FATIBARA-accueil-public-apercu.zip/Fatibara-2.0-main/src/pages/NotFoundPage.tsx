import React from 'react';
import { Link } from 'react-router-dom';
import Header from '../components/Header';
import Footer from '../components/Footer';
import SEO from '../components/SEO';
import { Home, Search } from 'lucide-react';
import { APP_NAME } from '../lib/constants';

export default function NotFoundPage() {
  return (
    <div className="min-h-screen flex flex-col bg-brand-bg dark:bg-gray-950 text-gray-900 dark:text-white">
      <SEO title="Page Non Trouvée" keywords={`404, ${APP_NAME}, Guinée`} />
      <Header />
      <main className="flex-grow flex flex-col items-center justify-center p-6 text-center">
        <div className="w-24 h-24 bg-orange-50 dark:bg-[#ff6600]/10 rounded-[2rem] flex items-center justify-center text-[#ff6600] mb-8 shadow-sm border border-orange-100 dark:border-[#ff6600]/20">
          <span className="text-4xl font-bold tracking-tight">404</span>
        </div>
        <h1 className="text-3xl md:text-5xl font-bold text-gray-900 dark:text-white tracking-tight mb-4">Oups ! Page introuvable</h1>
        <p className="text-gray-500 dark:text-gray-400 font-medium text-[15px] mb-10 max-w-md">
          Il semble que la page que vous cherchez n'existe pas ou a été déplacée.
        </p>
        <div className="flex flex-col sm:flex-row gap-4">
          <Link to="/" className="inline-flex justify-center items-center gap-2 bg-[#ff6600] text-white px-8 py-3.5 rounded-xl font-semibold text-[14px] shadow-sm hover:bg-[#e62e00] active:scale-[0.98] transition-all">
            <Home className="w-5 h-5" /> Retour à l'accueil
          </Link>
          <Link to="/search" className="inline-flex justify-center items-center gap-2 bg-white dark:bg-gray-900 text-gray-700 dark:text-gray-200 border border-gray-200 dark:border-white/10 px-8 py-3.5 rounded-xl font-semibold text-[14px] hover:bg-gray-50 dark:hover:bg-gray-800 hover:text-gray-900 dark:hover:text-white shadow-sm active:scale-[0.98] transition-all">
            <Search className="w-5 h-5" /> Rechercher
          </Link>
        </div>
      </main>
      <Footer />
    </div>
  );
}
