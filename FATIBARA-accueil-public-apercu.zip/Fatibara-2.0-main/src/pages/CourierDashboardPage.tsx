import React, { useEffect, useState, useRef, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { useAppContext } from '../context/AppContext';
import CourierLayout from '../components/CourierLayout';
import TransactionalWallet from '../components/TransactionalWallet';
import {
  Truck, MapPin, Clock, CheckCircle, AlertCircle, Phone, Navigation,
  ShieldCheck, Wallet, ChevronRight, Package, Star, Zap, Loader2,
  MessageSquare, History, Banknote, Timer, ExternalLink, Volume2, VolumeX,
  User, XCircle, BarChart3, Settings2, CheckSquare, Square, Layers,
  Filter, Camera, LogOut, Copy, AlertTriangle, TrendingUp,
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts';
import { hapticFeedback } from '../lib/haptics';
import { useToast } from '../context/ToastContext';
import { APP_NAME } from '../lib/constants';

import { startChime, stopChime } from '../utils/orderChime';
import PushNotificationToggle from '../components/PushNotificationToggle';
import CourierSettingsTab from '../components/courier/CourierSettingsTab';
import { formatGNF } from '../utils/formatters';
import { compressImage, validateImageFile } from '../utils/imageCompression';
import { isGeolocationPermitted, safeWatchPosition, CONAKRY_CENTER } from '../utils/geolocation';

// ─── Types ────────────────────────────────────────────────────────────────────

type OrderStatus =
  | 'paid' | 'preparing' | 'ready_for_pickup'
  | 'picked_up'    // UI-only: maps to 'in_transit' in DB so vendor sees it correctly
  // 'arriving_soon' is a UI-only state: written to deliveries.arriving_soon but
  // NOT to orders.status. localStatusOverridesRef preserves it across DB fetches.
  | 'in_transit' | 'arriving_soon'
  | 'delivered' | 'cancelled';

type ActiveTab = 'mission' | 'pool' | 'wallet' | 'history' | 'settings';

const MAX_CONCURRENT_ORDERS = 5;

const CONAKRY_COMMUNES = [
  'Ratoma', 'Matoto', 'Matam', 'Kaloum', 'Dixinn',
  'Lambanyi', 'Kissosso', 'Bambeto', 'Wanindara', 'Cosa',
  'Sonfonia', 'Koloma', 'Nongo',
];

// ─── Helpers ──────────────────────────────────────────────────────────────────

/** French-readable status labels for the courier status pill */
const STATUS_LABELS: Record<string, string> = {
  preparing:        'En préparation',
  ready_for_pickup: 'Prêt au retrait',
  picked_up:        'Récupéré',
  in_transit:       'En route',
  arriving_soon:    'Arrivée imminente',
  delivered:        'Livré',
  cancelled:        'Annulé',
};

/** Delivery SLA in minutes — used for ETA countdown */
const DELIVERY_SLA_MINS = 45;

function formatWaitTime(createdAt: string): string {
  const mins = Math.floor((Date.now() - new Date(createdAt).getTime()) / 60_000);
  if (mins < 1) return "À l'instant";
  if (mins < 60) return `${mins} min`;
  return `${Math.floor(mins / 60)}h ${mins % 60}m`;
}

/** Live elapsed time since a timestamp, ticking every second */
function useElapsedTime(since: string | null | undefined): string {
  const [elapsed, setElapsed] = useState('');
  useEffect(() => {
    if (!since) { setElapsed(''); return; }
    const tick = () => {
      const secs = Math.floor((Date.now() - new Date(since).getTime()) / 1000);
      const m = Math.floor(secs / 60);
      const s = secs % 60;
      setElapsed(m > 0 ? `${m}m ${s.toString().padStart(2,'0')}s` : `${s}s`);
    };
    tick();
    const id = setInterval(tick, 1000);
    return () => clearInterval(id);
  }, [since]);
  return elapsed;
}

/** ETA remaining minutes from a start timestamp + SLA */
function useEtaMinutes(startedAt: string | null | undefined): number | null {
  const [remaining, setRemaining] = useState<number | null>(null);
  useEffect(() => {
    if (!startedAt) { setRemaining(null); return; }
    const tick = () => {
      const elapsed = (Date.now() - new Date(startedAt).getTime()) / 60_000;
      setRemaining(Math.max(0, Math.round(DELIVERY_SLA_MINS - elapsed)));
    };
    tick();
    const id = setInterval(tick, 30_000);
    return () => clearInterval(id);
  }, [startedAt]);
  return remaining;
}

function isCashOrder(order: any): boolean {
  const method = order?.shipping_address?.payment_method;
  if (method) return method === 'cash';
  return order?.financial_status !== 'paid';
}

/** Rows per page for server-side history pagination */
const PAGE_SIZE = 20;

function getDeliveryEarnings(order: any): number {
  return Math.round(((order?.delivery_fee || order?.vendor_delivery_fee || 0) * 0.8));
}

function getMapsUrl(address: any): string {
  const parts = [address?.quartier, address?.commune, 'Conakry', 'Guinée']
    .filter(Boolean).join(', ');
  return `https://maps.google.com/?q=${encodeURIComponent(parts)}`;
}

/** Get best available phone for a courier order */
function getOrderPhone(order: any): string | null {
  return order?.contact_phone
    || order?.profiles?.phone_number
    || order?.shipping_address?.phone
    || null;
}

const ABANDON_REASONS = [
  'Panne de moto',
  'Accident de route',
  'Client injoignable',
  'Zone inaccessible',
  'Urgence personnelle',
  'Autre raison',
];

// ─── Active Order Card ────────────────────────────────────────────────────────

interface ActiveOrderCardProps {
  order: any;
  otpValue: string;
  onOtpChange: (val: string) => void;
  onUpdateStatus: (orderId: string, newStatus: OrderStatus) => void;
  onAbandon: (orderId: string) => void;
  onVerifyOtp: (orderId: string) => void;
  verifyingOtp: boolean;
  onReportProblem: (orderId: string) => void;
  isUpdatingStatus?: boolean;
}

function ActiveOrderCard({
  order,
  otpValue,
  onOtpChange,
  onUpdateStatus,
  onAbandon,
  onVerifyOtp,
  verifyingOtp,
  onReportProblem,
  isUpdatingStatus = false,
}: ActiveOrderCardProps) {
  const elapsedTime = useElapsedTime(order?.updated_at);
  const etaMins = useEtaMinutes(
    ['in_transit', 'arriving_soon'].includes(order?.status) ? order?.updated_at : null
  );
  const [copied, setCopied] = useState(false);

  const copyOrderId = () => {
    navigator.clipboard.writeText(order.id).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    });
  };

  const phone = getOrderPhone(order);

  return (
    <motion.div
      layoutId={`order-${order.id}`}
      className="bg-[#0a0a0a] border border-white/10 rounded-[2.5rem] overflow-hidden shadow-2xl relative"
    >
      {/* Progress bar */}
      <div
        className="absolute top-0 left-0 h-[5px] bg-gradient-to-r from-[#ff6600] to-[#ff8c00] transition-all duration-700"
        style={{
          width: ({
            preparing:        '20%',
            ready_for_pickup: '40%',
            picked_up:        '55%',
            in_transit:       '70%',
            arriving_soon:    '90%',
            delivered:        '100%',
            cancelled:        '0%',
          } as Record<string, string>)[order.status] ?? '50%',
        }}
      />

      <div className="p-6 space-y-5">
        {/* Header */}
        <div className="flex justify-between items-start">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 bg-[#ff6600]/10 border border-[#ff6600]/20 rounded-full text-[9px] font-bold text-[#ff6600] tracking-wider mb-3">
              <Clock className="w-3 h-3" />
              {STATUS_LABELS[order.status] ?? order.status.replace(/_/g, ' ').toUpperCase()}
            </div>
            <div className="flex items-center gap-2">
              <h3 className="text-2xl font-black text-white tracking-tighter uppercase">#{order.id.slice(0, 8)}</h3>
              <button
                onClick={copyOrderId}
                title="Copier l'ID commande"
                className="p-1.5 rounded-lg bg-white/5 border border-white/10 hover:bg-white/10 transition-all"
              >
                {copied
                  ? <CheckCircle className="w-3.5 h-3.5 text-emerald-400" />
                  : <Copy className="w-3.5 h-3.5 text-white/30" />}
              </button>
            </div>
          </div>
          <div className="text-right">
            <p className="text-[9px] font-bold text-white/30 tracking-widest mb-1">Vos gains</p>
            <p className="text-xl font-black text-emerald-400">
              +{formatGNF(getDeliveryEarnings(order))} <span className="text-sm">GNF</span>
            </p>
            {isCashOrder(order) && (
              <div className="mt-1 flex items-center justify-end gap-1 text-[9px] font-bold text-amber-400">
                <Banknote className="w-3 h-3" />
                Encaissez {formatGNF(order.total_amount)} GNF
              </div>
            )}
          </div>
        </div>

        {/* Customer + timer row */}
        <div className="flex items-center justify-between bg-white/[0.03] border border-white/5 rounded-xl px-4 py-3">
          <div className="flex items-center gap-2">
            <User className="w-3.5 h-3.5 text-white/30" />
            <span className="text-[11px] font-bold text-white">
              {order.profiles?.full_name ?? order.shipping_address?.phone ?? 'Client'}
            </span>
          </div>
          <div className="flex items-center gap-1.5 text-[10px] font-black text-amber-400">
            <Timer className="w-3 h-3" />
            {elapsedTime || '—'}
          </div>
        </div>

        {/* Route card */}
        <div className="space-y-3 bg-white/[0.03] border border-white/5 rounded-2xl p-4">
          <div className="flex items-start gap-3">
            <div className="w-7 h-7 bg-[#ff6600]/10 border border-[#ff6600]/20 rounded-lg flex items-center justify-center shrink-0 mt-0.5">
              <div className="w-2 h-2 bg-[#ff6600] rounded-full animate-pulse" />
            </div>
            <div>
              <p className="text-[9px] font-bold text-white/30 tracking-widest uppercase mb-0.5">Point de Retrait</p>
              <p className="text-[13px] font-bold text-white">{order.stores?.store_name ?? '—'}</p>
              <p className="text-[11px] text-white/40">{order.stores?.location_commune ?? 'Conakry'}</p>
            </div>
          </div>
          <div className="ml-3.5 border-l border-dashed border-white/10 h-3" />
          <div className="flex items-start gap-3">
            <div className="w-7 h-7 bg-emerald-500/10 border border-emerald-500/20 rounded-lg flex items-center justify-center shrink-0 mt-0.5">
              <MapPin className="w-3.5 h-3.5 text-emerald-400" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-[9px] font-bold text-white/30 tracking-widest uppercase mb-0.5">Destination Client</p>
              <p className="text-[13px] font-bold text-white">
                {order.shipping_address?.commune ?? '—'} — {order.shipping_address?.quartier ?? '—'}
              </p>
              {order.shipping_address?.indications && (
                <p className="text-[11px] text-white/40 mt-0.5 italic">{order.shipping_address.indications}</p>
              )}
            </div>
          </div>
        </div>

        {/* ETA countdown — shown when in transit */}
        {etaMins !== null && (
          <div className={`flex items-center gap-2 px-4 py-2.5 rounded-xl border text-[11px] font-black tracking-wider ${
            etaMins > 15 ? 'bg-emerald-500/10 border-emerald-500/20 text-emerald-400' :
            etaMins > 5  ? 'bg-amber-500/10 border-amber-500/20 text-amber-400' :
                           'bg-rose-500/10 border-rose-500/20 text-rose-400 animate-pulse'
          }`}>
            <Timer className="w-3.5 h-3.5" />
            {etaMins === 0 ? 'Délai dépassé !' : `~${etaMins} min restantes (ETA)`}
          </div>
        )}

        {/* Contact + Navigation */}
        <div className="flex flex-wrap gap-2">
          {phone ? (
            <a
              href={`tel:${phone}`}
              className="flex items-center gap-2 px-4 py-2.5 bg-white/5 border border-white/10 rounded-xl text-[10px] font-bold text-white tracking-wider hover:bg-white/10 transition-all"
            >
              <Phone className="w-3.5 h-3.5" /> Appeler
            </a>
          ) : (
            <span className="flex items-center gap-2 px-4 py-2.5 bg-white/5 border border-white/10 rounded-xl text-[10px] font-bold text-white/30 tracking-wider cursor-not-allowed">
              <Phone className="w-3.5 h-3.5" /> Pas de numéro
            </span>
          )}
          {phone && (
            <a
              href={`https://wa.me/${phone.replace(/\+/g, '')}?text=${encodeURIComponent(`Bonjour, c'est votre livreur ${APP_NAME}. Je suis en route avec votre commande #${order.id.slice(0,8).toUpperCase()} !`)}`}
              target="_blank" rel="noopener noreferrer"
              className="flex items-center gap-2 px-4 py-2.5 bg-emerald-500/10 border border-emerald-500/20 rounded-xl text-[10px] font-bold text-emerald-400 tracking-wider hover:bg-emerald-500 hover:text-white transition-all"
            >
              <MessageSquare className="w-3.5 h-3.5" /> WhatsApp
            </a>
          )}
          <a
            href={getMapsUrl(order.shipping_address)} target="_blank" rel="noopener noreferrer"
            className="flex items-center gap-2 px-4 py-2.5 bg-blue-500/10 border border-blue-500/20 rounded-xl text-[10px] font-bold text-blue-400 tracking-wider hover:bg-blue-500 hover:text-white transition-all"
          >
            <ExternalLink className="w-3.5 h-3.5" /> Itinéraire
          </a>
        </div>

        {/* Problem report + Abandon */}
        <div className="flex items-center justify-between pt-3 border-t border-white/5">
          <button
            onClick={() => onReportProblem(order.id)}
            className="flex items-center gap-2 text-[9px] font-bold text-rose-500 tracking-wider hover:bg-rose-500/10 px-3 py-2 rounded-lg transition-all"
          >
            <AlertCircle className="w-3.5 h-3.5" /> Signaler
          </button>
          <button
            onClick={() => onAbandon(order.id)}
            className="flex items-center gap-2 text-[9px] font-bold text-orange-400 tracking-wider hover:bg-orange-500/10 px-3 py-2 rounded-lg transition-all border border-orange-500/20"
          >
            <XCircle className="w-3.5 h-3.5" /> Abandonner
          </button>
        </div>

        {/* Action Buttons */}
        <div className="space-y-3 pt-2 border-t border-white/5">
          {order.status === 'preparing' && (
            <button
              onClick={() => onUpdateStatus(order.id, 'ready_for_pickup')}
              disabled={isUpdatingStatus}
              className="w-full bg-white/5 border border-white/10 text-white py-4 rounded-2xl text-[11px] font-black tracking-wider hover:bg-white/10 transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
            >
              {isUpdatingStatus ? <span className="w-3.5 h-3.5 border-2 border-white/40 border-t-white rounded-full animate-spin" /> : null}
              {isUpdatingStatus ? 'Traitement...' : 'Colis prêt ? Confirmer la préparation'}
            </button>
          )}
          {order.status === 'ready_for_pickup' && (
            <button
              onClick={() => onUpdateStatus(order.id, 'picked_up')}
              disabled={isUpdatingStatus}
              className="w-full bg-[#ff6600] hover:bg-[#e65c00] text-white py-4 rounded-2xl text-[11px] font-black tracking-wider shadow-xl shadow-[#ff6600]/20 transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
            >
              {isUpdatingStatus ? <span className="w-3.5 h-3.5 border-2 border-white/40 border-t-white rounded-full animate-spin" /> : '🏍️'}
              {isUpdatingStatus ? 'Traitement...' : 'Colis récupéré — Démarrer le trajet'}
            </button>
          )}
          {order.status === 'in_transit' && (
            <button
              onClick={() => onUpdateStatus(order.id, 'arriving_soon')}
              disabled={isUpdatingStatus}
              className="w-full bg-[#ff6600] hover:bg-[#e65c00] text-white py-4 rounded-2xl text-[11px] font-black tracking-wider transition-all disabled:opacity-50 disabled:cursor-not-allowed"
            >
              📍 Signaler mon arrivée proche
            </button>
          )}
          {(order.status === 'in_transit' || order.status === 'arriving_soon') && (
            <div className="bg-white/[0.03] border border-white/10 p-5 rounded-2xl space-y-4">
              <div className="text-center">
                <p className="text-[9px] font-bold text-[#ff6600] tracking-widest uppercase mb-1">Finalisation Sécurisée</p>
                <h4 className="text-lg font-black text-white uppercase tracking-tighter">Code OTP Client</h4>
                <p className="text-[10px] text-white/30 font-medium mt-1">Saisissez le code affiché sur l'écran du client</p>
              </div>

              {/* 4-digit auto-advancing OTP boxes */}
              <div className="flex items-center justify-center gap-3">
                {[0, 1, 2, 3].map((idx) => (
                  <input
                    key={idx}
                    id={`otp-box-${order.id}-${idx}`}
                    type="tel"
                    inputMode="numeric"
                    maxLength={1}
                    value={otpValue[idx] ?? ''}
                    autoComplete="one-time-code"
                    onChange={(e) => {
                      const digit = e.target.value.replace(/\D/g, '').slice(-1);
                      const arr = (otpValue + '    ').slice(0, 4).split('');
                      arr[idx] = digit;
                      const next = arr.join('').replace(/ /g, '');
                      onOtpChange(next);
                      hapticFeedback('light');
                      if (digit && idx < 3) {
                        (document.getElementById(`otp-box-${order.id}-${idx + 1}`) as HTMLInputElement)?.focus();
                      }
                    }}
                    onKeyDown={(e) => {
                      if (e.key === 'Backspace' && !otpValue[idx] && idx > 0) {
                        const arr = (otpValue + '    ').slice(0, 4).split('');
                        arr[idx - 1] = '';
                        onOtpChange(arr.join('').replace(/ /g, '').slice(0, idx - 1));
                        (document.getElementById(`otp-box-${order.id}-${idx - 1}`) as HTMLInputElement)?.focus();
                      }
                    }}
                    onPaste={(e) => {
                      e.preventDefault();
                      const pasted = e.clipboardData.getData('text').replace(/\D/g, '').slice(0, 4);
                      onOtpChange(pasted);
                      const focusIdx = Math.min(pasted.length, 3);
                      (document.getElementById(`otp-box-${order.id}-${focusIdx}`) as HTMLInputElement)?.focus();
                    }}
                    className={`w-14 h-16 rounded-2xl font-mono text-2xl text-center outline-none transition-all border-2 ${
                      otpValue[idx]
                        ? 'border-orange-500 bg-slate-900 text-white shadow-lg shadow-orange-500/20 ring-2 ring-orange-500/30'
                        : 'border-slate-700 bg-slate-900 text-white focus:border-orange-500 focus:ring-2 focus:ring-orange-500/30'
                    }`}
                  />
                ))}
              </div>

              <button
                disabled={otpValue.length < 4 || verifyingOtp}
                onClick={() => onVerifyOtp(order.id)}
                className={`w-full py-4 rounded-2xl text-[11px] font-bold tracking-wider transition-all flex items-center justify-center gap-3 ${
                  otpValue.length < 4 || verifyingOtp
                    ? 'bg-slate-800 text-slate-500 cursor-not-allowed border border-slate-700/50'
                    : 'bg-orange-500 hover:bg-orange-600 text-white shadow-lg shadow-orange-500/25 active:scale-[0.98]'
                }`}
              >
                {verifyingOtp
                  ? <Loader2 className="w-4 h-4 animate-spin" />
                  : <><ShieldCheck className="w-4 h-4" /> Vérifier &amp; Terminer</>}
              </button>
            </div>
          )}
        </div>
      </div>
    </motion.div>
  );
}

// ─── Main Component ───────────────────────────────────────────────────────────

export default function CourierDashboardPage() {
  const { user, isAuthLoading, courierStatus } = useAppContext();
  const navigate = useNavigate();
  const { showToast } = useToast();

  const [loading, setLoading] = useState(true);
  const [availableOrders, setAvailableOrders] = useState<any[]>([]);
  // ── MULTI-ORDER STATE (replaces single activeOrder) ───────────────────────
  const [activeOrders, setActiveOrders] = useState<any[]>([]);
  const [otpValues, setOtpValues] = useState<Record<string, string>>({});
  // ── Per-order abandon modal state ──────────────────────────────────────────
  const [abandoningOrderId, setAbandoningOrderId] = useState<string | null>(null);
  const [abandonReason, setAbandonReason] = useState(ABANDON_REASONS[0]);
  const [abandoning, setAbandoning] = useState(false);
  // ── Pool multi-select state ────────────────────────────────────────────────
  const [selectedPoolIds, setSelectedPoolIds] = useState<Set<string>>(new Set());
  const [batchAccepting, setBatchAccepting] = useState(false);
  // ── Pool zone filter ───────────────────────────────────────────────────────
  const [poolZoneFilter, setPoolZoneFilter] = useState<string>('');
  // ── Other state ───────────────────────────────────────────────────────────
  const [historyOrders, setHistoryOrders] = useState<any[]>([]);
  // Server-side pagination for history — each page adds 20 rows fetched from the DB
  const [historyPage, setHistoryPage] = useState(0);
  const [historyHasMore, setHistoryHasMore] = useState(false);
  const [historyLoadingMore, setHistoryLoadingMore] = useState(false);
  const [weeklyEarnings, setWeeklyEarnings] = useState<{day:string; amount:number}[]>([]);
  const [courierStats, setCourierStats] = useState({
    todayDeliveries: 0, totalEarnings: 0, todayEarnings: 0, rating: 5.0,
  });
  const [isOnline, setIsOnline] = useState(false);
  const [togglingOnline, setTogglingOnline] = useState(false);
  const [verifyingOtpId, setVerifyingOtpId] = useState<string | null>(null);
  // Per-order loading state for status updates (prevents double-tap)
  const [updatingStatusId, setUpdatingStatusId] = useState<string | null>(null);
  // Loading state for cash-confirm finalization button
  const [isFinalizingDelivery, setIsFinalizingDelivery] = useState(false);
  const [activeTab, setActiveTab] = useState<ActiveTab>('mission');
  const [chimeEnabled, setChimeEnabled] = useState<boolean>(() => {
    try { return localStorage.getItem('courier_chime') !== 'false'; }
    catch { return true; }
  });
  // Cash collection confirm
  const [showCashConfirm, setShowCashConfirm] = useState(false);
  const [pendingDeliveryId, setPendingDeliveryId] = useState<string | null>(null);
  const [promptConfig, setPromptConfig] = useState<{
    isOpen: boolean; title: string; description?: string;
    resolve: (value: string | null) => void;
  } | null>(null);
  const [courierZone, setCourierZone] = useState<string>('');
  const [savingZone, setSavingZone] = useState(false);
  const [zoneDirty, setZoneDirty] = useState(false);
  const [isSimulatingLocation, setIsSimulatingLocation] = useState(() => !isGeolocationPermitted());
  // GPS error toast (shown at most once per session)
  const [gpsErrorShown, setGpsErrorShown] = useState(false);

  // ── Courier Security Fields ──────────────────────────────────────────────
  const [securityProfile, setSecurityProfile] = useState({
    phone_number: '',
    license_plate_number: '',
    vehicle_type: 'motorcycle' as 'motorcycle' | 'car' | 'bicycle' | 'foot',
  });
  const [savingSecurityProfile, setSavingSecurityProfile] = useState(false);
  const [securityProfileDirty, setSecurityProfileDirty] = useState(false);

  // ── Avatar Upload ─────────────────────────────────────────────────────────
  const [avatarUrl, setAvatarUrl] = useState<string | null>(null);
  const [uploadingAvatar, setUploadingAvatar] = useState(false);
  const avatarFileRef = useRef<HTMLInputElement>(null);

  // ── Rejection reason (shown in banner when courierStatus === 'rejected') ──
  const [courierRejectionReason, setCourierRejectionReason] = useState<string | null>(null);

  // ── Refs for stale-closure-safe access inside fetchData/realtime ──────────
  const chimeEnabledRef = useRef(chimeEnabled);
  useEffect(() => { chimeEnabledRef.current = chimeEnabled; }, [chimeEnabled]);
  const isOnlineRef = useRef(isOnline);
  useEffect(() => { isOnlineRef.current = isOnline; }, [isOnline]);
  // ── Reconnect timer ref (fix: prevent firing after unmount) ───────────────
  const reconnectTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  // ── Debounce ref for realtime-triggered fetchData ─────────────────────────
  const fetchDebounceRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  // ── arriving_soon local status overrides ──────────────────────────────────
  // Tracks orders whose 'arriving_soon' status was set locally but not
  // persisted to orders.status in the DB. Survives across fetchData calls
  // so the "Arrivée imminente" badge doesn't disappear when the DB
  // returns 'in_transit' on the next realtime-triggered refetch.
  const localStatusOverridesRef = useRef<Record<string, OrderStatus>>({});

  const handleAvatarUpload = async (file: File) => {
    if (!user?.id) return;

    // Client-side validation (type + 10 MB raw size cap)
    const validationError = validateImageFile(file, 10);
    if (validationError) {
      showToast(validationError, 'error');
      return;
    }

    setUploadingAvatar(true);

    // Compress to max 500 KB / 1200 px before upload (critical for 3G)
    let uploadFile: Blob;
    try {
      uploadFile = await compressImage(file, { maxSizeKB: 500, maxDimension: 1200 });
    } catch {
      uploadFile = file; // compression failed — upload original
    }

    // Always upload as JPEG after compression
    const path = `${user.id}/avatar.jpg`;
    const { error: uploadError } = await supabase.storage
      .from('avatars')
      .upload(path, uploadFile, {
        upsert: true,
        contentType: 'image/jpeg',
        cacheControl: '3600',
      });
    if (uploadError) {
      showToast(`Échec du téléversement : ${uploadError.message}. Réessayez en re-sélectionnant la photo.`, 'error');
      setUploadingAvatar(false);
      return;
    }
    const { data: urlData } = supabase.storage.from('avatars').getPublicUrl(path);
    const publicUrl = urlData.publicUrl + '?t=' + Date.now();
    const { error: updateError } = await supabase.from('profiles')
      .update({ avatar_url: publicUrl })
      .eq('id', user.id);
    if (updateError) {
      showToast('Photo téléversée mais profil non mis à jour : ' + updateError.message, 'error');
    } else {
      setAvatarUrl(publicUrl);
      showToast('Photo de profil mise à jour ✓', 'success');
      hapticFeedback('success');
    }
    setUploadingAvatar(false);
  };

  const prevPoolCount = useRef(0);

  const askPrompt = (title: string, description?: string): Promise<string | null> =>
    new Promise((resolve) => setPromptConfig({ isOpen: true, title, description, resolve }));

  // ── WakeLock — keeps screen alive whenever any order is in-transit ──────────
  // Intentionally separate from the GPS effect so the lock is always released
  // regardless of whether real GPS or simulation mode is active.
  useEffect(() => {
    const hasActiveDelivery = activeOrders.some(o =>
      ['in_transit', 'arriving_soon'].includes(o.status)
    );
    if (!hasActiveDelivery || !('wakeLock' in navigator)) return;

    let wakeLock: WakeLockSentinel | null = null;
    let isCancelled = false;

    // Check permissions policy or wrap request safely to avoid noisy violations in iframes
    try {
      const requestLock = async () => {
        try {
          if ('permissions' in navigator && (navigator.permissions as any).query) {
            try {
              const status = await (navigator.permissions as any).query({ name: 'screen-wake-lock' });
              if (status.state === 'denied') return;
            } catch {
              // Permission query not supported for screen-wake-lock in all browsers, continue safely
            }
          }
          if (isCancelled) return;
          const lock = await (navigator as any).wakeLock.request('screen');
          if (isCancelled) {
            lock.release().catch(() => {});
          } else {
            wakeLock = lock;
          }
        } catch (e: any) {
          // In iframe or sandboxed preview, screen-wake-lock is disabled by policy. Suppress noisy logs.
          const msg = e?.message || '';
          if (!msg.includes('permissions policy') && !msg.includes('not allowed')) {
            console.warn('[CourierDashboard] WakeLock unavailable:', msg);
          }
        }
      };
      requestLock();
    } catch {
      // Ignored
    }

    return () => {
      isCancelled = true;
      wakeLock?.release().catch(() => {});
    };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [activeOrders]);

  // ── GPS Tracking — broadcasts location for ALL active in_transit orders ───
  useEffect(() => {
    let watchId: number | null = null;
    let simInterval: any = null;

    const inTransitOrders = activeOrders.filter(o =>
      ['in_transit', 'arriving_soon'].includes(o.status)
    );

    if (inTransitOrders.length === 0) return;

    const UUID_REGEX = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;

    const broadcastLocation = async (lat: number, lng: number) => {
      if (typeof lat !== 'number' || typeof lng !== 'number' || isNaN(lat) || isNaN(lng)) return;

      for (const o of inTransitOrders) {
        if (!o?.id) continue;
        if (!UUID_REGEX.test(o.id)) {
          // Synthetic or demo order ID — skip DB persistence to avoid Postgres UUID cast errors
          continue;
        }

        const payload = {
          order_id: o.id,
          courier_id: user?.id || null,
          lat,
          lng,
          updated_at: new Date().toISOString(),
        };

        try {
          // 1. Try atomic RPC update
          const { error: rpcErr } = await supabase.rpc('update_courier_location', {
            p_order_id: o.id,
            p_lat: lat,
            p_lng: lng,
          });

          // 2. Direct table upsert fallback
          if (rpcErr) {
            const { error: upsertErr } = await supabase.from('courier_locations').upsert(
              payload,
              { onConflict: 'order_id' }
            );

            // 3. Backend service-role proxy fallback if RLS or client blocked
            if (upsertErr) {
              await fetch('/api/courier/location', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                  orderId: o.id,
                  courierId: user?.id,
                  lat,
                  lng,
                }),
              }).catch(() => {});
            }
          }
        } catch (err) {
          // Silent catch to prevent unhandled background rejection
          console.debug('[CourierDelivery] Location broadcast note:', err);
        }
      }
    };

    if (isSimulatingLocation || !isGeolocationPermitted()) {
      let lat = CONAKRY_CENTER.lat, lng = CONAKRY_CENTER.lng;
      simInterval = setInterval(async () => {
        lat += (Math.random() - 0.5) * 0.001;
        lng += (Math.random() - 0.5) * 0.001;
        await broadcastLocation(lat, lng);
      }, 5000);
    } else {
      watchId = safeWatchPosition(
        async (coords) => {
          await broadcastLocation(coords.latitude, coords.longitude);
        },
        () => {
          // If restricted or unavailable, silently transition to simulation
          setIsSimulatingLocation(true);
        },
        { enableHighAccuracy: true, maximumAge: 30000, timeout: 27000 },
      );
      if (watchId === null) {
        setIsSimulatingLocation(true);
      }
    }
    return () => {
      if (watchId !== null && typeof navigator !== 'undefined' && navigator.geolocation) {
        navigator.geolocation.clearWatch(watchId);
      }
      if (simInterval) clearInterval(simInterval);
    };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [activeOrders, user, isSimulatingLocation]);

  // ── Data Fetcher ───────────────────────────────────────────────────────────
  // fetchingRef prevents parallel in-flight requests when tabs are switched rapidly.
  const fetchingRef = useRef(false);

  const fetchData = useCallback(async (silent = false) => {
    if (!user?.id) return;
    // S-2: in-flight guard — skip if a fetch is already running (silent refreshes only;
    // non-silent/initial loads are always allowed to proceed).
    if (silent && fetchingRef.current) return;
    fetchingRef.current = true;
    if (!silent) setLoading(true);
    try {
      const [activeRes, poolRes, profileRes, txRes, historyRes] = await Promise.all([
        // ── MULTI-ROW query (was .maybeSingle()) ──────────────────────────────
        supabase.from('orders').select('*')
          .eq('courier_id', user.id)
          .not('status', 'in', '(delivered,cancelled)'),
        // Exclude vendor_self_delivery orders — they are fulfilled by the vendor's
        // own rider and must never appear in the external courier pool.
        supabase.from('orders').select('*').eq('status', 'ready_for_pickup')
          .is('courier_id', null)
          .neq('fulfillment_type', 'vendor_self_delivery')
          .order('created_at', { ascending: true }),
        supabase.from('profiles').select('wallet_balance, is_courier_online, courier_zone, phone_number, license_plate_number, vehicle_type, avatar_url, courier_rating, courier_rejection_reason')
          .eq('id', user.id).single(),
        supabase.from('wallet_transactions').select('amount').eq('profile_id', user.id)
          .eq('type', 'delivery_fee')
          .gte('created_at', new Date(new Date().setHours(0,0,0,0)).toISOString()),
        // History: first page on every background refresh (server-side pagination).
        // PAGE_SIZE rows fetched — if exactly PAGE_SIZE come back, there may be more.
        supabase.from('orders').select('*').eq('courier_id', user.id)
          .in('status', ['delivered', 'cancelled'])
          .order('updated_at', { ascending: false })
          .range(0, PAGE_SIZE - 1),
      ]);

      const fetchedActive = activeRes.data || [];
      const allOrders = [...fetchedActive, ...(poolRes.data || []), ...(historyRes.data || [])].filter(Boolean);
      const userIds = [...new Set(allOrders.map((o: any) => o.user_id).filter(Boolean))] as string[];
      const vendorIds = [...new Set(allOrders.map((o: any) => o.vendor_id).filter(Boolean))] as string[];

      const [profilesRes, storesRes] = await Promise.all([
        userIds.length
          ? supabase.from('profiles').select('id, full_name, phone_number').in('id', userIds)
          : Promise.resolve({ data: [] as any[] }),
        vendorIds.length
          ? supabase.from('stores').select('id, store_name, location_commune, owner_id')
              .or(`owner_id.in.(${vendorIds.join(',')})`)
          : Promise.resolve({ data: [] as any[] }),
      ]);

      const profiles = (profilesRes.data || []) as any[];
      const stores = (storesRes.data || []) as any[];
      const enrich = (o: any) => ({
        ...o,
        profiles: profiles.find((p: any) => p.id === o.user_id) ?? null,
        stores: stores.find((s: any) => s.owner_id === o.vendor_id) ?? null,
      });

      const newPool = (poolRes.data || []).map(enrich);
      const newActive = fetchedActive.map(enrich);

      // Chime when new orders appear in pool — use refs to avoid stale closure
      if (chimeEnabledRef.current && isOnlineRef.current && newPool.length > prevPoolCount.current) {
        startChime();
        setTimeout(stopChime, 4000);
        const top = newPool[0];
        showToast(`🏍️ Nouvelle course ! +${formatGNF(getDeliveryEarnings(top))}`, 'success');
      }
      prevPoolCount.current = newPool.length;

      // Re-apply any local arriving_soon overrides so DB refetches don't
      // wipe badges that haven't yet reached a terminal state.
      const overrides = localStatusOverridesRef.current;
      const activeWithOverrides = newActive.map((o: any) =>
        overrides[o.id] ? { ...o, status: overrides[o.id] } : o
      );
      // Clean up overrides for orders that are now in a terminal DB state
      newActive.forEach((o: any) => {
        if (['delivered', 'cancelled'].includes(o.status)) {
          delete overrides[o.id];
        }
      });

      setActiveOrders(activeWithOverrides);
      setAvailableOrders(newPool);
      // Reset to first page on a background refresh
      const historyPage0 = (historyRes.data || []).map(enrich);
      setHistoryOrders(historyPage0);
      setHistoryPage(0);
      setHistoryHasMore((historyRes.data?.length ?? 0) >= PAGE_SIZE);
      setIsOnline(profileRes.data?.is_courier_online ?? false);
      if (profileRes.data) {
        setSecurityProfile({
          phone_number: profileRes.data.phone_number || '',
          license_plate_number: profileRes.data.license_plate_number || '',
          vehicle_type: profileRes.data.vehicle_type || 'motorcycle',
        });
      }
      setCourierZone(profileRes.data?.courier_zone ?? '');
      setZoneDirty(false); // reset dirty flag — zone is now in sync with DB
      if (profileRes.data?.avatar_url) setAvatarUrl(profileRes.data.avatar_url);

      // Store rejection reason for display in the banner
      if (profileRes.data?.courier_rejection_reason) {
        setCourierRejectionReason(profileRes.data.courier_rejection_reason);
      }

      const walletBalance = profileRes.data?.wallet_balance ?? 0;

      const todayEarnings = (txRes.data || []).reduce((s: number, t: any) => s + Number(t.amount), 0);
      setCourierStats({
        todayDeliveries: txRes.data?.length ?? 0,
        totalEarnings: walletBalance,
        todayEarnings,
        rating: profileRes.data?.courier_rating ? Number(profileRes.data.courier_rating) : 5.0,
      });

      // Weekly earnings chart (last 7 days)
      const sevenDaysAgo = new Date();
      sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 6);
      sevenDaysAgo.setHours(0, 0, 0, 0);
      const { data: weekTxs } = await supabase
        .from('wallet_transactions')
        .select('amount, created_at')
        .eq('profile_id', user.id)
        .eq('type', 'delivery_fee')
        .gte('created_at', sevenDaysAgo.toISOString());

      const dayMap: Record<string, number> = {};
      for (let i = 6; i >= 0; i--) {
        const d = new Date();
        d.setDate(d.getDate() - i);
        const key = d.toLocaleDateString('fr-FR', { weekday: 'short' });
        dayMap[key] = 0;
      }
      (weekTxs || []).forEach((tx: any) => {
        const key = new Date(tx.created_at).toLocaleDateString('fr-FR', { weekday: 'short' });
        if (key in dayMap) dayMap[key] += Number(tx.amount);
      });
      setWeeklyEarnings(Object.entries(dayMap).map(([day, amount]) => ({ day, amount })));
    } catch (err: any) {
      console.error('Courier fetch error:', err);
      if (!silent) showToast(err.message || 'Erreur de chargement', 'error');
    } finally {
      if (!silent) setLoading(false);
      fetchingRef.current = false;
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user?.id]);

  // ── Auto-refresh wallet balance when user switches to the Portefeuille tab ──
  useEffect(() => {
    if (activeTab === 'wallet') {
      fetchData(true);
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [activeTab]);

  // ── Debounced silent fetchData — used by realtime callbacks ──────────────
  const debouncedFetch = useCallback(() => {
    if (fetchDebounceRef.current) clearTimeout(fetchDebounceRef.current);
    fetchDebounceRef.current = setTimeout(() => {
      fetchDebounceRef.current = null;
      fetchData(true);
    }, 500);
  }, [fetchData]);

  // ── Realtime Subscriptions ─────────────────────────────────────────────────
  useEffect(() => {
    if (!user?.id) return;
    fetchData();

    let channels: ReturnType<typeof supabase.channel>[] = [];

    const cleanup = () => {
      channels.forEach((ch) => supabase.removeChannel(ch));
      channels = [];
    };

    const subscribeAll = () => {
      cleanup();

      const onClosed = () => {
        // Use a ref-stored timer to survive component unmount safely
        if (reconnectTimerRef.current) return;
        reconnectTimerRef.current = setTimeout(() => {
          reconnectTimerRef.current = null;
          subscribeAll();
        }, 5_000);
      };
      const onSubscribed = () => {
        if (reconnectTimerRef.current) { clearTimeout(reconnectTimerRef.current); reconnectTimerRef.current = null; }
      };

      const activeCh = supabase
        .channel(`courier_active_${user.id}`)
        .on('postgres_changes', { event: '*', schema: 'public', table: 'orders', filter: `courier_id=eq.${user.id}` },
          debouncedFetch)
        .on('system', {}, ({ status }: { status: string }) => {
          if (status === 'CLOSED') onClosed(); else if (status === 'SUBSCRIBED') onSubscribed();
        })
        .subscribe();

      // Pool channel: listen for UPDATE events where status becomes ready_for_pickup.
      // Previously also had an INSERT filter (courier_id=is.null) which fired for
      // every new order including vendor_self_delivery ones — causing unnecessary
      // fetchData calls. The UPDATE on status=ready_for_pickup is sufficient because
      // orders transition from 'pending' → 'ready_for_pickup' via vendor action.
      const poolCh = supabase
        .channel(`courier_pool_watch_${user.id}`)
        .on('postgres_changes', { event: 'UPDATE', schema: 'public', table: 'orders', filter: `status=eq.ready_for_pickup` },
          debouncedFetch)
        .on('system', {}, ({ status }: { status: string }) => {
          if (status === 'CLOSED') onClosed(); else if (status === 'SUBSCRIBED') onSubscribed();
        })
        .subscribe();

      // ── Realtime wallet balance sync ─────────────────────────────────────────
      const walletBalanceCh = supabase
        .channel(`courier_wallet_balance_${user.id}`)
        .on('postgres_changes', {
          event: 'UPDATE',
          schema: 'public',
          table: 'profiles',
          filter: `id=eq.${user.id}`,
        }, debouncedFetch)
        .on('system', {}, ({ status }: { status: string }) => {
          if (status === 'CLOSED') onClosed(); else if (status === 'SUBSCRIBED') onSubscribed();
        })
        .subscribe();

      // Re-fetch silently on any new wallet_transaction
      const walletTxCh = supabase
        .channel(`courier_wallet_tx_${user.id}`)
        .on('postgres_changes', {
          event: 'INSERT',
          schema: 'public',
          table: 'wallet_transactions',
          filter: `profile_id=eq.${user.id}`,
        }, debouncedFetch)
        .on('system', {}, ({ status }: { status: string }) => {
          if (status === 'CLOSED') onClosed(); else if (status === 'SUBSCRIBED') onSubscribed();
        })
        .subscribe();

      channels = [activeCh, poolCh, walletBalanceCh, walletTxCh];
    };

    subscribeAll();

    return () => {
      if (reconnectTimerRef.current) { clearTimeout(reconnectTimerRef.current); reconnectTimerRef.current = null; }
      if (fetchDebounceRef.current) { clearTimeout(fetchDebounceRef.current); fetchDebounceRef.current = null; }
      cleanup();
    };
  }, [user?.id, fetchData, debouncedFetch]);

  // ── Online/Offline Toggle ──────────────────────────────────────────────────
  const toggleOnline = async () => {
    if (!user?.id) return;

    if (!isOnline && !securityProfile.license_plate_number?.trim()) {
      showToast(
        "Veuillez renseigner votre numéro de plaque avant d'activer votre statut.",
        'error'
      );
      hapticFeedback('error');
      setActiveTab('settings');
      return;
    }

    setTogglingOnline(true);
    hapticFeedback('selection');
    const newState = !isOnline;
    const { error } = await supabase.from('profiles').update({ is_courier_online: newState }).eq('id', user.id);
    if (error) {
      showToast('Erreur de mise à jour du statut', 'error');
    } else {
      setIsOnline(newState);
      showToast(newState ? '🟢 Vous êtes En Service !' : '⏸️ Vous êtes En Pause.', newState ? 'success' : 'info');
      if (!newState) stopChime();
    }
    setTogglingOnline(false);
  };

  // ── Accept Single Order (quick-accept from pool) ───────────────────────────
  const acceptOrder = async (orderId: string) => {
    hapticFeedback('selection');

    if (!isOnline) {
      showToast("Passez En Service avant d'accepter une course.", 'warning');
      hapticFeedback('error');
      return;
    }

    // ── CAPACITY GUARD (replaces single-order lock) ────────────────────────
    if (activeOrders.length >= MAX_CONCURRENT_ORDERS) {
      showToast(`Capacité maximale atteinte (${MAX_CONCURRENT_ORDERS} missions actives).`, 'warning');
      hapticFeedback('error');
      return;
    }

    const { data, error } = await supabase
      .from('orders').update({ courier_id: user?.id })
      .eq('id', orderId).eq('status', 'ready_for_pickup').is('courier_id', null).select();
    if (error) {
      showToast(error.message || "Erreur lors de l'acceptation", 'error');
      hapticFeedback('error');
    } else if (!data || data.length === 0) {
      showToast('Désolé, cette course a déjà été acceptée.', 'error');
      hapticFeedback('error');
      fetchData(true);
    } else {
      hapticFeedback('reward');
      showToast('Course acceptée ! Rendez-vous à la boutique.', 'success');
      // Optimistic update — move from pool to active immediately (no flicker)
      const accepted = data[0];
      setAvailableOrders(prev => prev.filter(o => o.id !== orderId));
      setActiveOrders(prev => [...prev, accepted]);
      setSelectedPoolIds(prev => { const s = new Set(prev); s.delete(orderId); return s; });
      setActiveTab('mission');
      fetchData(true);
    }
  };

  // ── Accept Batch Orders (multi-select via RPC) ─────────────────────────────
  const acceptOrderBatch = async (orderIds: string[]) => {
    if (!user?.id || orderIds.length === 0) return;
    hapticFeedback('selection');

    if (!isOnline) {
      showToast("Passez En Service avant d'accepter des courses.", 'warning');
      return;
    }

    if (activeOrders.length >= MAX_CONCURRENT_ORDERS) {
      showToast(`Capacité maximale atteinte (${MAX_CONCURRENT_ORDERS} missions actives).`, 'warning');
      hapticFeedback('error');
      return;
    }

    setBatchAccepting(true);
    try {
      const { data, error } = await supabase.rpc('accept_order_batch', {
        p_order_ids: orderIds,
        p_courier_id: user.id,
      });
      if (error) throw error;
      if (data?.error) throw new Error(data.error);

      const acceptedCount = (data?.accepted as string[] | undefined)?.length ?? 0;
      const skippedCount  = (data?.skipped as string[] | undefined)?.length ?? 0;

      if (acceptedCount > 0) {
        hapticFeedback('reward');
        showToast(
          `${acceptedCount} course${acceptedCount > 1 ? 's' : ''} acceptée${acceptedCount > 1 ? 's' : ''} !${skippedCount > 0 ? ` (${skippedCount} déjà prise${skippedCount > 1 ? 's' : ''})` : ''}`,
          'success'
        );
        setSelectedPoolIds(new Set());
        setActiveTab('mission');
        fetchData(true);
      } else {
        showToast('Toutes les courses sélectionnées ont déjà été prises.', 'error');
        hapticFeedback('error');
        fetchData(true);
      }
    } catch (err: any) {
      showToast(err.message || "Erreur lors de l'acceptation groupée", 'error');
      hapticFeedback('error');
    } finally {
      setBatchAccepting(false);
    }
  };

  // ── Courier status machine ────────────────────────────────────────────────
  // Mirrors the vendor ALLOWED_TRANSITIONS pattern. Prevents the courier from
  // writing an arbitrary status to the DB via the raw .update() path even if
  // the UI buttons are conditionally rendered correctly.
  // NOTE: 'arriving_soon' is a local-UI-only state (no DB write).
  // NOTE: 'picked_up' is the UI label for 'in_transit' in the DB.
  const COURIER_ALLOWED_TRANSITIONS: Record<string, OrderStatus[]> = {
    preparing:        ['ready_for_pickup'],
    ready_for_pickup: ['picked_up'],          // picked_up → writes 'in_transit' to DB
    in_transit:       ['arriving_soon', 'delivered'],
    arriving_soon:    ['delivered'],
    // Terminal states — no forward transitions allowed
    delivered:        [],
    cancelled:        [],
  };

  // ── Update Status ──────────────────────────────────────────────────────────
  const updateStatus = async (orderId: string, newStatus: OrderStatus) => {
    // Guard: prevent concurrent updates on the same order
    if (updatingStatusId === orderId) return;

    hapticFeedback('light');

    const order = activeOrders.find(o => o.id === orderId);

    // Guard: terminal state lock
    if (order && ['delivered', 'cancelled'].includes(order.status)) {
      showToast('Cette commande est dans un état terminal.', 'warning');
      return;
    }

    // Guard: ALLOWED_TRANSITIONS — block invalid state jumps
    const currentStatus = order?.status ?? '';
    const allowed = COURIER_ALLOWED_TRANSITIONS[currentStatus] ?? [];
    if (!allowed.includes(newStatus)) {
      showToast(`Transition invalide : ${currentStatus} → ${newStatus}`, 'warning');
      return;
    }

    // 'arriving_soon' — write a flag to the deliveries table so the customer
    // tracking page (which subscribes to DB changes) advances its UI step.
    // The status is NOT persisted to orders.status in the DB, so we store it
    // in localStatusOverridesRef to survive across fetchData() re-fetches.
    if (newStatus === 'arriving_soon') {
      localStatusOverridesRef.current[orderId] = 'arriving_soon';
      setActiveOrders(prev => prev.map(o => o.id === orderId ? { ...o, status: 'arriving_soon' } : o));
      // Best-effort write — update existing deliveries row first to avoid RLS 403 insert error
      supabase
        .from('deliveries')
        .update({ arriving_soon: true })
        .eq('order_id', orderId)
        .then(({ error, count }) => {
          if (error || count === 0) {
            supabase.from('deliveries').upsert({ order_id: orderId, arriving_soon: true }, { onConflict: 'order_id' }).then(() => {});
          }
        });
      showToast('Signalement envoyé : vous approchez !', 'success');
      return;
    }

    setUpdatingStatusId(orderId);
    // Optimistic update for instant UI feedback
    const previousStatus = order?.status;
    const dbStatus = newStatus === 'picked_up' ? 'in_transit' : newStatus;
    setActiveOrders(prev => prev.map(o => o.id === orderId ? { ...o, status: newStatus } : o));

    try {
      const { error } = await supabase
        .from('orders').update({ status: dbStatus, updated_at: new Date().toISOString() }).eq('id', orderId);
      if (error) {
        // Rollback optimistic update
        if (previousStatus) setActiveOrders(prev => prev.map(o => o.id === orderId ? { ...o, status: previousStatus } : o));
        showToast(error.message || 'Erreur de mise à jour', 'error');
      } else {
        showToast('Statut mis à jour ✓', 'success');
        fetchData(true);
      }
    } finally {
      setUpdatingStatusId(null);
    }
  };

  // ── Abandon Mission ────────────────────────────────────────────────────────
  const abandonMission = async () => {
    if (!abandoningOrderId) return;
    setAbandoning(true);
    hapticFeedback('warning');
    try {
      const { data, error } = await supabase.rpc('cancel_courier_assignment', {
        p_order_id: abandoningOrderId,
        p_reason: abandonReason,
      });
      if (error) throw error;
      if (data?.success === false) throw new Error(data.error);
      hapticFeedback('error');
      showToast('Mission libérée. La commande est de retour dans le pool.', 'info');
      setAbandoningOrderId(null);
      fetchData(true);
    } catch (err: any) {
      showToast(err.message || "Erreur lors de l'abandon", 'error');
    } finally {
      setAbandoning(false);
    }
  };

  // ── OTP Verify — with cash collection confirm step ─────────────────────────
  // OTP is sent to the server; comparison happens inside complete_courier_delivery
  // (SECURITY DEFINER). The delivery_otp value is never read on the client.
  const verifyOtpAndComplete = async (orderId: string) => {
    const otp = otpValues[orderId] ?? '';
    if (otp.length < 4) return;
    setVerifyingOtpId(orderId);

    const order = activeOrders.find(o => o.id === orderId);
    if (!order) { setVerifyingOtpId(null); return; }

    // Guard: block OTP verification on orders already in a terminal state
    if (['delivered', 'completed', 'cancelled'].includes(order.status)) {
      showToast('Cette commande a déjà été livrée ou annulée.', 'warning');
      setVerifyingOtpId(null);
      return;
    }

    try {
      // For COD orders ask for cash-collection confirmation first.
      // We do NOT clear verifyingOtpId here — it stays set so the OTP button
      // remains disabled while the cash-confirm modal is open. It is cleared
      // by finalizeDelivery (via setShowCashConfirm(false)) or when the modal
      // is cancelled (see Cash Collection Confirm Modal cancel handler).
      if (isCashOrder(order)) {
        setPendingDeliveryId(orderId);
        setShowCashConfirm(true);
        return; // spinner remains; finalizeDelivery will clear it when done
      }
      await finalizeDelivery(orderId, otp);
    } catch (err: any) {
      showToast(err.message || 'Erreur de vérification', 'error');
    } finally {
      // Only clear the spinner for the non-COD path — COD path clears it
      // inside finalizeDelivery / cash-confirm cancel handler.
      if (!isCashOrder(activeOrders.find(o => o.id === orderId))) {
        setVerifyingOtpId(null);
      }
    }
  };

  // ── Finalize Delivery — atomic settlement via complete-delivery API / RPC ──
  // This call verifies the OTP, credits the courier wallet,
  // settles the vendor, and marks the order delivered — all in one transaction.
  const finalizeDelivery = async (orderId: string, otp?: string) => {
    setIsFinalizingDelivery(true);
    try {
      let data: { success: boolean; error?: string; courier_payout?: number } | null = null;

      // 1. Try secure backend endpoint first (bypasses RLS & stale RPC limitations)
      try {
        const { data: sessionData } = await supabase.auth.getSession();
        const token = sessionData.session?.access_token;
        if (token) {
          const resp = await fetch('/api/courier/complete-delivery', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              'Authorization': `Bearer ${token}`,
            },
            body: JSON.stringify({ orderId, otp: otp ?? null }),
          });
          const json = await resp.json();
          if (resp.ok && json.success) {
            data = json;
          } else if (json.error) {
            if (json.error.includes('OTP')) {
              hapticFeedback('warning');
              showToast(json.error, 'error');
              return;
            }
            throw new Error(json.error);
          }
        }
      } catch (apiErr: any) {
        if (apiErr.message && (apiErr.message.includes('OTP') || apiErr.message.includes('livrée') || apiErr.message.includes('annulée') || apiErr.message.includes('autorisé'))) {
          throw apiErr;
        }
        console.warn('[CourierDashboard] API endpoint fallback to RPC:', apiErr.message);
      }

      // 2. Fallback to Supabase RPC if backend endpoint didn't handle it
      if (!data) {
        const result = await supabase.rpc('complete_courier_delivery', {
          p_order_id: orderId,
          p_otp: otp ?? null,
        });

        if (result.error) throw new Error(result.error.message);

        data = result.data as { success: boolean; error?: string; courier_payout?: number };
        if (!data.success) {
          if (data.error?.includes('OTP')) {
            hapticFeedback('warning');
            showToast('Code OTP incorrect, veuillez réessayer.', 'error');
            return;
          }
          throw new Error(data.error || 'Erreur de finalisation');
        }
      }

      hapticFeedback('reward');
      const earning = data.courier_payout ? ` (+${formatGNF(data.courier_payout)})` : '';
      showToast(`🎉 Livraison terminée ! Gains crédités${earning}`, 'success');
      setOtpValues(prev => { const next = { ...prev }; delete next[orderId]; return next; });
      setVerifyingOtpId(null); // clear COD OTP spinner now that delivery is settled
      setShowCashConfirm(false);
      setPendingDeliveryId(null);
      setActiveTab('history');
      fetchData();
    } catch (err: any) {
      showToast(err.message || 'Erreur de finalisation', 'error');
    } finally {
      setIsFinalizingDelivery(false);
    }
  };

  // ── Pool toggle helper ─────────────────────────────────────────────────────
  const togglePoolSelection = (orderId: string) => {
    setSelectedPoolIds(prev => {
      const next = new Set(prev);
      if (next.has(orderId)) next.delete(orderId);
      else next.add(orderId);
      return next;
    });
  };

  // ── Filtered pool with preferred zone sort ────────────────────────────────
  const filteredPool = (() => {
    const orders = poolZoneFilter
      ? availableOrders.filter(o => o.shipping_address?.commune === poolZoneFilter)
      : availableOrders;
    // Sort: preferred zone first, then by order age (oldest first)
    return [...orders].sort((a, b) => {
      const aPreferred = courierZone && a.shipping_address?.commune === courierZone ? -1 : 0;
      const bPreferred = courierZone && b.shipping_address?.commune === courierZone ? -1 : 0;
      if (aPreferred !== bPreferred) return aPreferred - bPreferred;
      return new Date(a.created_at).getTime() - new Date(b.created_at).getTime();
    });
  })();

  // ── Cash confirm pending order lookup ──────────────────────────────────────
  const pendingCashOrder = pendingDeliveryId ? activeOrders.find(o => o.id === pendingDeliveryId) : null;

  // ── Guard: auth not yet resolved ─────────────────────────────────────────
  // CourierAuthGuard (in CourierLayout) already blocks rendering until auth is
  // resolved and the courier role is confirmed. These guards are kept as a
  // lightweight safety net in case the page is ever rendered outside CourierLayout.
  if (isAuthLoading || !user) {
    return (
      <div className="min-h-screen bg-[#0a0a0a] flex items-center justify-center">
        <div className="flex flex-col items-center gap-4">
          <Loader2 className="w-12 h-12 text-[#ff6600] animate-spin" />
          <p className="text-[10px] font-bold text-white/30 tracking-widest uppercase">Vérification session…</p>
        </div>
      </div>
    );
  }

  if (loading && activeOrders.length === 0 && availableOrders.length === 0) {
    return (
      <div className="min-h-screen bg-[#0a0a0a] flex items-center justify-center">
        <div className="flex flex-col items-center gap-4">
          <Loader2 className="w-12 h-12 text-[#ff6600] animate-spin" />
          <p className="text-[10px] font-bold text-white/30 tracking-widest uppercase">Chargement du tableau de bord…</p>
        </div>
      </div>
    );
  }

  return (
    <CourierLayout isOnline={isOnline} onToggleOnline={toggleOnline} togglingOnline={togglingOnline} avatarUrl={avatarUrl}>
      <div className="max-w-5xl mx-auto w-full px-4 py-8">

        {/* ── Courier Approval Status Banner ────────────────────────────── */}
        {courierStatus === 'inactive' && (
          <div className="bg-amber-500/10 border border-amber-500/20 p-5 rounded-3xl flex items-start gap-4 mb-6">
            <div className="w-10 h-10 bg-amber-500/20 rounded-2xl flex items-center justify-center shrink-0 animate-pulse">
              <ShieldCheck className="w-5 h-5 text-amber-500" />
            </div>
            <div>
              <p className="text-sm font-black text-amber-400 uppercase tracking-widest mb-1">Dossier en cours d'examen</p>
              <p className="text-[11px] font-medium text-amber-400/70 leading-relaxed">
                Votre candidature a bien été reçue. Notre équipe examine votre profil sous <strong className="text-amber-400">24h</strong>.
                Vous recevrez une notification dès l'activation de votre compte livreur.
              </p>
            </div>
          </div>
        )}
        {courierStatus === 'rejected' && (
          <div className="bg-rose-500/10 border border-rose-500/20 p-5 rounded-3xl flex items-start gap-4 mb-6">
            <div className="w-10 h-10 bg-rose-500/20 rounded-2xl flex items-center justify-center shrink-0">
              <AlertCircle className="w-5 h-5 text-rose-500" />
            </div>
            <div className="flex-1">
              <p className="text-sm font-black text-rose-400 uppercase tracking-widest mb-1">Candidature refusée</p>
              <p className="text-[11px] font-medium text-rose-400/70 leading-relaxed mb-2">
                Votre dossier n'a pas été validé. Contactez notre équipe pour comprendre les raisons et soumettre à nouveau.
              </p>
              {courierRejectionReason && (
                <p className="text-[10px] font-bold text-rose-300 bg-rose-500/10 border border-rose-500/20 rounded-xl px-3 py-2 mb-3">
                  Motif : {courierRejectionReason}
                </p>
              )}
              <a
                href="https://wa.me/224666923393?text=Bonjour%2C%20ma%20candidature%20livreur%20a%20%C3%A9t%C3%A9%20refus%C3%A9e.%20Je%20voudrais%20en%20savoir%20plus."
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 px-4 py-2 bg-rose-600 text-white rounded-xl text-[10px] font-black uppercase tracking-widest hover:bg-rose-700 transition-all"
              >
                Contacter le Support
              </a>
            </div>
          </div>
        )}

        {/* ── Profile Header ── */}
        <div className="bg-[#111] border border-white/5 p-6 md:p-8 rounded-[2.5rem] shadow-2xl flex flex-col md:flex-row justify-between items-start md:items-center gap-6 mb-8 overflow-hidden relative">
          <div className="absolute top-0 left-0 w-full h-[5px] bg-gradient-to-r from-[#ff6600] via-[#ff8c00] to-[#ff6600]" />
          <div className="flex items-center gap-5">
            {/* Avatar — tappable to open upload picker */}
            <button
              onClick={() => avatarFileRef.current?.click()}
              disabled={uploadingAvatar}
              className="relative w-16 h-16 rounded-2xl shrink-0 overflow-hidden group focus:outline-none"
              title="Changer la photo de profil"
            >
              <img
                src={avatarUrl || `https://api.dicebear.com/7.x/avataaars/svg?seed=${user?.id}`}
                alt="Avatar"
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-black/60 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                {uploadingAvatar
                  ? <Loader2 className="w-5 h-5 text-white animate-spin" />
                  : <Camera className="w-5 h-5 text-white" />
                }
              </div>
            </button>
            <div>
              <h1 className="text-2xl font-bold text-white tracking-tighter uppercase leading-tight">
                {user?.user_metadata?.full_name ?? user?.email?.split('@')[0] ?? 'Livreur Pro'}
              </h1>
              <div className="flex items-center gap-3 mt-1">
                <span className="flex items-center gap-1 text-[10px] font-bold text-yellow-400 tracking-[2px] uppercase">
                  <Star className="w-3 h-3 fill-yellow-400" />{courierStats.rating.toFixed(1)}
                </span>
                <span className="text-white/20">•</span>
                <span className="text-[10px] font-bold text-white/40 tracking-wider">
                  {courierStats.todayDeliveries} livraisons aujourd'hui
                </span>
                {/* Active missions indicator */}
                {activeOrders.length > 0 && (
                  <>
                    <span className="text-white/20">•</span>
                    <span className="flex items-center gap-1 text-[10px] font-bold text-[#ff6600] tracking-wider">
                      <Layers className="w-3 h-3" />
                      {activeOrders.length}/{MAX_CONCURRENT_ORDERS} missions
                    </span>
                  </>
                )}
              </div>
            </div>
          </div>
          <div className="flex flex-wrap gap-3 w-full md:w-auto">
            <div className="flex-1 md:flex-none bg-white/5 border border-white/10 p-4 rounded-2xl text-center min-w-[120px]">
              <p className="text-[9px] font-bold text-slate-400 tracking-widest uppercase mb-1">Aujourd'hui</p>
              <p className="text-lg font-black text-emerald-400">{formatGNF(courierStats.todayEarnings)}</p>
            </div>
            <div className="flex-1 md:flex-none bg-white/5 border border-white/10 p-4 rounded-2xl text-center min-w-[120px]">
              <p className="text-[9px] font-bold text-slate-400 tracking-widest uppercase mb-1">Solde total</p>
              <p className="text-lg font-black text-white">{formatGNF(courierStats.totalEarnings)}</p>
            </div>
          </div>
        </div>


        {/* ── Tabs ── */}
        <div className="relative mb-8">
          <div className="flex items-center gap-2 overflow-x-auto pb-2 no-scrollbar">
            {([
              { key: 'mission', label: 'Missions', icon: Navigation, badge: activeOrders.length },
              { key: 'pool',    label: 'Pool',      icon: Package,    badge: availableOrders.length },
              { key: 'wallet',  label: 'Portefeuille', icon: Wallet,  badge: 0 },
              { key: 'history', label: 'Historique',   icon: History, badge: 0 },
              { key: 'settings', label: 'Paramètres',  icon: Settings2, badge: 0 },
            ] as const).map(({ key, label, icon: Icon, badge }) => (
              <button key={key} onClick={async () => {
                // Warn if leaving settings with unsaved changes using an in-app
                // modal instead of window.confirm() which is suppressed in PWA
                // standalone mode (iOS silently returns false).
                if (activeTab === 'settings' && securityProfileDirty && key !== 'settings') {
                  const ok = await askPrompt(
                    'Modifications non enregistrées',
                    'Tapez OK pour quitter sans enregistrer, ou annulez pour rester.',
                  );
                  if (!ok || ok.trim().toLowerCase() !== 'ok') return;
                }
                setActiveTab(key);
              }}
                className={[
                  'flex items-center gap-2 px-5 py-2.5 rounded-full text-[10px] font-black tracking-[0.25em] uppercase whitespace-nowrap transition-all',
                  activeTab === key
                    ? 'bg-[#ff6600] text-white shadow-lg shadow-[#ff6600]/30'
                    : 'bg-white/5 text-white/40 border border-white/10 hover:bg-white/10 hover:text-white/70',
                ].join(' ')}>
                <Icon className="w-3.5 h-3.5" />
                {label}
                {badge > 0 && (
                  <span className={`px-1.5 py-0.5 rounded-full text-[8px] font-black ${activeTab === key ? 'bg-white/20 text-white' : 'bg-emerald-500 text-white'}`}>
                    {badge}
                  </span>
                )}
              </button>
            ))}
            <button
              onClick={() => {
                const next = !chimeEnabled;
                setChimeEnabled(next);
                try { localStorage.setItem('courier_chime', String(next)); } catch {}
                if (!next) stopChime();
              }}
              title={chimeEnabled ? 'Désactiver le son' : 'Activer le son'}
              className="ml-auto flex-shrink-0 w-9 h-9 rounded-full bg-white/5 border border-white/10 flex items-center justify-center text-white/40 hover:text-white hover:bg-white/10 transition-all"
            >
              {chimeEnabled ? <Volume2 className="w-3.5 h-3.5" /> : <VolumeX className="w-3.5 h-3.5" />}
            </button>
          </div>
          {/* Right-side fade gradient — hints at more tabs on small screens */}
          <div className="pointer-events-none absolute top-0 right-10 bottom-2 w-12 bg-gradient-to-l from-[#0a0a0a] to-transparent" />
        </div>

        {/* ══════════════════ TAB CONTENT ══════════════════ */}
        <AnimatePresence mode="wait">

          {/* ── WALLET ── */}
          {activeTab === 'wallet' && (
            <motion.div key="wallet" initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
              <TransactionalWallet type="courier" id={user?.id || ''} />
            </motion.div>
          )}

          {/* ── HISTORY ── */}
          {activeTab === 'history' && (
            <motion.div key="history" initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} className="space-y-4">
              <h2 className="text-lg font-black text-white uppercase tracking-widest flex items-center gap-2">
                <History className="w-5 h-5 text-[#ff6600]" /> Historique des Livraisons
              </h2>

              {/* ── Weekly Performance KPI Summary ── */}
              {weeklyEarnings.some(d => d.amount > 0) && (() => {
                const bestDay = weeklyEarnings.reduce((a, b) => a.amount >= b.amount ? a : b);
                const totalWeek = weeklyEarnings.reduce((s, d) => s + d.amount, 0);
                const deliveredCount = historyOrders.filter(o => o.status === 'delivered').length;
                return (
                  <div className="grid grid-cols-3 gap-3">
                    <div className="bg-white/[0.03] border border-white/8 rounded-2xl p-4 text-center">
                      <TrendingUp className="w-4 h-4 text-[#ff6600] mx-auto mb-1" />
                      <p className="text-[9px] font-bold text-white/30 tracking-widest uppercase mb-1">Meilleure journée</p>
                      <p className="text-sm font-black text-emerald-400">{formatGNF(bestDay.amount)}</p>
                      <p className="text-[9px] text-white/30 mt-0.5">{bestDay.day}</p>
                    </div>
                    <div className="bg-white/[0.03] border border-white/8 rounded-2xl p-4 text-center">
                      <Package className="w-4 h-4 text-[#ff6600] mx-auto mb-1" />
                      <p className="text-[9px] font-bold text-white/30 tracking-widest uppercase mb-1">Livraisons (7j)</p>
                      <p className="text-sm font-black text-white">{deliveredCount}</p>
                    </div>
                    <div className="bg-white/[0.03] border border-white/8 rounded-2xl p-4 text-center">
                      <Wallet className="w-4 h-4 text-[#ff6600] mx-auto mb-1" />
                      <p className="text-[9px] font-bold text-white/30 tracking-widest uppercase mb-1">Total (7j)</p>
                      <p className="text-sm font-black text-emerald-400">{formatGNF(totalWeek)}</p>
                    </div>
                  </div>
                );
              })()}

              {/* Weekly earnings chart */}
              {weeklyEarnings.some(d => d.amount > 0) && (
                <div className="bg-white/[0.03] border border-white/8 rounded-2xl p-5">
                  <p className="text-[9px] font-black text-white/30 tracking-widest uppercase mb-4 flex items-center gap-2">
                    <BarChart3 className="w-3.5 h-3.5 text-[#ff6600]" /> Gains des 7 derniers jours
                  </p>
                  <ResponsiveContainer width="100%" height={100} minWidth={0} minHeight={0}>
                    <BarChart data={weeklyEarnings} barSize={20}>
                      <XAxis dataKey="day" tick={{ fontSize: 9, fill: '#ffffff40', fontWeight: 700 }} axisLine={false} tickLine={false} />
                      <YAxis hide />
                      <Tooltip
                        contentStyle={{ background: '#111', border: '1px solid rgba(255,255,255,0.1)', borderRadius: 12, fontSize: 11 }}
                        formatter={(v: number) => [formatGNF(v), 'Gains']}
                        labelStyle={{ color: '#ffffff60' }}
                      />
                      <Bar dataKey="amount" fill="#ff6600" radius={[4,4,0,0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              )}

              {historyOrders.length === 0 ? (
                <motion.div
                  initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }}
                  className="py-16 px-6 text-center border border-dashed border-white/10 rounded-[2rem] space-y-4"
                >
                  <div className="text-5xl">🚀</div>
                  <div>
                    <p className="text-[13px] font-black text-white/70 tracking-tight mb-1">
                      Votre première course vous attend !
                    </p>
                    <p className="text-[11px] font-medium text-white/30 leading-relaxed">
                      Acceptez une mission dans le pool et commencez à gagner dès maintenant.
                    </p>
                  </div>
                  <div className="inline-flex items-center gap-2 px-4 py-2 bg-[#ff6600]/10 border border-[#ff6600]/20 rounded-full">
                    <span className="text-[10px] font-black text-[#ff6600] tracking-wider">
                      Jusqu'à 80 % des frais de livraison vous reviennent
                    </span>
                  </div>
                </motion.div>
              ) : (
                <>
                  {historyOrders.map((order) => (
                    <motion.div key={order.id} initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }}
                      className="flex items-center gap-4 bg-white/[0.03] border border-white/8 p-4 rounded-2xl">
                      <div className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${order.status === 'delivered' ? 'bg-emerald-500/10' : 'bg-rose-500/10'}`}>
                        {order.status === 'delivered'
                          ? <CheckCircle className="w-5 h-5 text-emerald-400" />
                          : <AlertCircle className="w-5 h-5 text-rose-400" />}
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-[12px] font-bold text-white truncate">
                          {order.stores?.store_name ?? '—'} → {order.shipping_address?.commune ?? '—'}
                        </p>
                        <p className="text-[10px] text-white/30 mt-0.5">
                          #{order.id.slice(0,8).toUpperCase()} · {new Date(order.updated_at).toLocaleDateString('fr-FR', { day:'2-digit', month:'short', hour:'2-digit', minute:'2-digit' })}
                        </p>
                        {order.status === 'cancelled' && order.cancellation_reason && (
                          <p className="text-[9px] font-bold text-rose-400/70 mt-1 flex items-center gap-1">
                            <AlertTriangle className="w-2.5 h-2.5" />{order.cancellation_reason}
                          </p>
                        )}
                      </div>
                      <div className="text-right shrink-0">
                        <p className={`text-[13px] font-black ${order.status === 'delivered' ? 'text-emerald-400' : 'text-white/30'}`}>
                          {order.status === 'delivered' ? `+${formatGNF(getDeliveryEarnings(order))}` : '—'}
                        </p>
                        {isCashOrder(order) && (
                          <span className="text-[9px] font-bold text-amber-400 bg-amber-500/10 px-2 py-0.5 rounded-full">CASH</span>
                        )}
                      </div>
                    </motion.div>
                  ))}
                  {historyHasMore && (
                    <button
                      disabled={historyLoadingMore}
                      onClick={async () => {
                        if (!user?.id || historyLoadingMore) return;
                        setHistoryLoadingMore(true);
                        const nextPage = historyPage + 1;
                        try {
                          const { data } = await supabase
                            .from('orders')
                            .select('*')
                            .eq('courier_id', user.id)
                            .in('status', ['delivered', 'cancelled'])
                            .order('updated_at', { ascending: false })
                            .range(nextPage * PAGE_SIZE, nextPage * PAGE_SIZE + PAGE_SIZE - 1);
                          if (data && data.length > 0) {
                            setHistoryOrders(prev => [...prev, ...data]);
                            setHistoryPage(nextPage);
                            setHistoryHasMore(data.length >= PAGE_SIZE);
                          } else {
                            setHistoryHasMore(false);
                          }
                        } finally {
                          setHistoryLoadingMore(false);
                        }
                      }}
                      className="w-full py-3 rounded-2xl border border-white/10 text-[11px] font-black text-white/40 hover:text-white hover:border-white/20 tracking-widest uppercase transition-all flex items-center justify-center gap-2 disabled:opacity-50"
                    >
                      {historyLoadingMore
                        ? <><Loader2 className="w-3.5 h-3.5 animate-spin" /> Chargement...</>
                        : 'Charger plus'}
                    </button>
                  )}
                </>
              )}
            </motion.div>
          )}

          {/* ── SETTINGS ── */}
          {activeTab === 'settings' && (
            <CourierSettingsTab
              userId={user.id}
              avatarUrl={avatarUrl}
              uploadingAvatar={uploadingAvatar}
              onAvatarUpload={handleAvatarUpload}
              courierZone={courierZone}
              setCourierZone={setCourierZone}
              zoneDirty={zoneDirty}
              setZoneDirty={setZoneDirty}
              savingZone={savingZone}
              setSavingZone={setSavingZone}
              onZoneSaved={() => setZoneDirty(false)}
              securityProfile={securityProfile}
              setSecurityProfile={setSecurityProfile}
              securityProfileDirty={securityProfileDirty}
              setSecurityProfileDirty={setSecurityProfileDirty}
              savingSecurityProfile={savingSecurityProfile}
              setSavingSecurityProfile={setSavingSecurityProfile}
              isOnline={isOnline}
              togglingOnline={togglingOnline}
              toggleOnline={toggleOnline}
              chimeEnabled={chimeEnabled}
              setChimeEnabled={setChimeEnabled}
              stopChime={stopChime}
              showToast={showToast}
              hapticFeedback={hapticFeedback}
            />
          )}

          {/* ── MISSION + POOL ── */}
          {(activeTab === 'mission' || activeTab === 'pool') && (
            <motion.div key="orders-view" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
              className="grid grid-cols-1 lg:grid-cols-3 gap-8">

              {/* ═══════════ Active Missions Column ═══════════ */}
              <div className="lg:col-span-2 space-y-6">
                <div className="flex items-center justify-between">
                  <h2 className="text-xl font-black text-white uppercase tracking-widest flex items-center gap-2">
                    <Navigation className="w-5 h-5 text-[#ff6600]" /> Missions Actives
                  </h2>
                  {activeOrders.length > 0 && (
                    <span className="text-[10px] font-black text-white/40 bg-white/5 border border-white/10 px-3 py-1.5 rounded-full">
                      {activeOrders.length} / {MAX_CONCURRENT_ORDERS}
                    </span>
                  )}
                </div>

                {/* Capacity bar */}
                {activeOrders.length > 0 && (
                  <div className="bg-white/[0.03] border border-white/8 rounded-2xl p-4">
                    <div className="flex justify-between text-[9px] font-bold text-white/30 tracking-widest uppercase mb-2">
                      <span>Capacité</span>
                      <span className={activeOrders.length >= MAX_CONCURRENT_ORDERS ? 'text-rose-400' : 'text-emerald-400'}>
                        {activeOrders.length >= MAX_CONCURRENT_ORDERS ? 'PLEIN' : `${MAX_CONCURRENT_ORDERS - activeOrders.length} dispo`}
                      </span>
                    </div>
                  <div className="h-1.5 bg-white/10 rounded-full overflow-hidden">
                      <div
                        className={`h-full rounded-full transition-all duration-500 ${
                          activeOrders.length >= MAX_CONCURRENT_ORDERS ? 'bg-rose-500' :
                          activeOrders.length >= 3 ? 'bg-amber-500' : 'bg-emerald-500'
                        }`}
                        style={{ width: `${(activeOrders.length / MAX_CONCURRENT_ORDERS) * 100}%` }}
                      />
                    </div>
                  </div>
                )}

                {/* GPS simulation toggle — DEV MODE ONLY */}
                {import.meta.env.DEV && activeOrders.some(o => ['in_transit', 'arriving_soon'].includes(o.status)) && (
                  <label className="flex items-center gap-3 p-3 bg-white/[0.02] border border-white/5 rounded-xl cursor-pointer">
                    <input type="checkbox" checked={isSimulatingLocation}
                      onChange={(e) => setIsSimulatingLocation(e.target.checked)}
                      className="w-4 h-4 rounded border-white/20 bg-black accent-[#ff6600]" />
                    <span className="text-[10px] font-bold text-white/30 tracking-wider">Simuler GPS (Mode Démo)</span>
                  </label>
                )}

                {/* Active order cards list */}
                {activeOrders.length > 0 ? (
                  <div className="space-y-6">
                    {activeOrders.map((order) => (
                      <React.Fragment key={order.id}>
                      <ActiveOrderCard
                        order={order}
                        otpValue={otpValues[order.id] ?? ''}
                        onOtpChange={(val) => setOtpValues(prev => ({ ...prev, [order.id]: val }))}
                        onUpdateStatus={updateStatus}
                        onAbandon={(id) => { setAbandoningOrderId(id); setAbandonReason(ABANDON_REASONS[0]); }}
                        onVerifyOtp={verifyOtpAndComplete}
                        verifyingOtp={verifyingOtpId === order.id}
                        onReportProblem={async (id) => {
                          const problem = await askPrompt('Signaler un problème', 'Accident, panne, client injoignable…');
                          if (problem && user?.id) {
                            await supabase.from('courier_reports').insert({
                              courier_id: user.id,
                              order_id: id,
                              description: problem,
                            });
                            showToast(`Signalement enregistré. Nous vous contacterons bientôt.`, 'info');
                          }
                        }}
                      />
                      </React.Fragment>
                    ))}
                  </div>
                ) : (
                  <div className="bg-[#111] border border-dashed border-white/10 rounded-[2.5rem] p-12 text-center flex flex-col items-center gap-5">
                    <div className="w-20 h-20 bg-[#ff6600]/5 border border-[#ff6600]/15 rounded-full flex items-center justify-center">
                      <Truck className="w-9 h-9 text-[#ff6600]/40" />
                    </div>
                    <div>
                      <h3 className="text-base font-black text-white uppercase tracking-tighter">Aucune mission active</h3>
                      <p className="text-[11px] text-slate-400 mt-1.5 leading-relaxed">Vous n'avez aucune livraison en cours.{"\n"}Acceptez des courses dans le pool pour commencer.</p>
                    </div>
                    <button onClick={() => setActiveTab('pool')}
                      className="flex items-center gap-2 bg-[#ff6600] hover:bg-[#e65c00] text-white px-6 py-3 rounded-xl text-[10px] font-black tracking-wider transition-all shadow-lg shadow-[#ff6600]/20">
                      <Package className="w-3.5 h-3.5" /> Voir le Pool de courses
                    </button>
                  </div>
                )}
              </div>

              {/* ═══════════ Pool Column ═══════════ */}
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <h2 className="text-xl font-black text-white uppercase tracking-widest flex items-center gap-2">
                    <Package className="w-5 h-5 text-[#ff6600]" /> Pool
                  </h2>
                  {!isOnline && <span className="text-[9px] font-bold text-amber-400 bg-amber-500/10 border border-amber-500/20 px-2.5 py-1 rounded-full">HORS LIGNE</span>}
                </div>

                {/* ── Zone Filter Toolbar ── */}
                {isOnline && availableOrders.length > 0 && (
                  <div className="space-y-2">
                    <div className="flex items-center gap-1.5 text-[9px] font-black text-white/30 tracking-widest uppercase">
                      <Filter className="w-3 h-3" /> Filtrer par zone
                    </div>
                    <div className="flex flex-wrap gap-1.5">
                      <button
                        onClick={() => setPoolZoneFilter('')}
                        className={`px-2.5 py-1 rounded-lg text-[9px] font-black tracking-wider transition-all border ${
                          poolZoneFilter === ''
                            ? 'bg-[#ff6600] text-white border-[#ff6600]'
                            : 'bg-white/5 text-white/30 border-white/10 hover:border-white/20'
                        }`}
                      >
                        Toutes
                      </button>
                      {[...new Set(availableOrders.map(o => o.shipping_address?.commune).filter(Boolean))].map(commune => (
                        <button
                          key={commune}
                          onClick={() => setPoolZoneFilter(commune === poolZoneFilter ? '' : commune)}
                          className={`px-2.5 py-1 rounded-lg text-[9px] font-black tracking-wider transition-all border ${
                            poolZoneFilter === commune
                              ? 'bg-[#ff6600] text-white border-[#ff6600]'
                              : 'bg-white/5 text-white/30 border-white/10 hover:border-white/20'
                          }`}
                        >
                          {commune}
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                {/* ── Batch Accept CTA ── */}
                {selectedPoolIds.size > 0 && (
                  <motion.div
                    initial={{ opacity: 0, y: -8 }} animate={{ opacity: 1, y: 0 }}
                    className="bg-[#ff6600]/10 border border-[#ff6600]/30 rounded-2xl p-4 flex items-center gap-3"
                  >
                    <div className="flex-1">
                      <p className="text-[11px] font-black text-white tracking-wider">
                        {selectedPoolIds.size} course{selectedPoolIds.size > 1 ? 's' : ''} sélectionnée{selectedPoolIds.size > 1 ? 's' : ''}
                      </p>
                      <p className="text-[9px] text-white/40 mt-0.5">
                        Total estimé : +{formatGNF(
                          availableOrders
                            .filter(o => selectedPoolIds.has(o.id))
                            .reduce((sum, o) => sum + getDeliveryEarnings(o), 0)
                        )}
                      </p>
                    </div>
                    <button
                      onClick={() => acceptOrderBatch([...selectedPoolIds])}
                      disabled={batchAccepting || activeOrders.length >= MAX_CONCURRENT_ORDERS}
                      className="flex items-center gap-2 bg-[#ff6600] hover:bg-[#e65c00] disabled:opacity-50 text-white px-4 py-2.5 rounded-xl text-[10px] font-black tracking-wider transition-all"
                    >
                      {batchAccepting
                        ? <Loader2 className="w-3.5 h-3.5 animate-spin" />
                        : <Layers className="w-3.5 h-3.5" />}
                      Accepter
                    </button>
                  </motion.div>
                )}

                <AnimatePresence mode="popLayout">
                  {!isOnline ? (
                    <motion.div key="offline-pool" initial={{ opacity: 0 }} animate={{ opacity: 1 }}
                      className="p-10 text-center bg-white/[0.02] rounded-2xl border border-dashed border-white/10">
                      <p className="text-[10px] font-bold text-slate-400 tracking-wider">Activez "En Service" pour voir les courses disponibles.</p>
                    </motion.div>
                  ) : filteredPool.length === 0 ? (
                    <motion.div key="empty-pool" initial={{ opacity: 0 }} animate={{ opacity: 1 }}
                      className="p-10 text-center bg-[#111] rounded-2xl border border-dashed border-white/10 flex flex-col items-center gap-4">
                      <div className="w-14 h-14 bg-[#ff6600]/5 border border-[#ff6600]/15 rounded-full flex items-center justify-center">
                        <Package className="w-6 h-6 text-[#ff6600]/40" />
                      </div>
                      <div>
                        <p className="text-[12px] font-black text-white uppercase tracking-tight">
                          {poolZoneFilter ? `Aucune course à ${poolZoneFilter}` : 'Aucune commande disponible'}
                        </p>
                        <p className="text-[10px] text-slate-300 mt-1">
                          {poolZoneFilter
                            ? 'Essayez une autre zone ou supprimez le filtre.'
                            : 'Le pool est vide pour le moment.'}
                        </p>
                      </div>
                    </motion.div>
                  ) : filteredPool.map((order) => {
                    const isSelected = selectedPoolIds.has(order.id);
                    const atCapacity = activeOrders.length >= MAX_CONCURRENT_ORDERS;
                    const isPreferredZone = courierZone && order.shipping_address?.commune === courierZone;
                    const isStale = (Date.now() - new Date(order.created_at).getTime()) > 20 * 60_000;
                    return (
                      <motion.div
                        key={order.id} layout
                        initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, scale: 0.9 }}
                        className={`bg-[#111] border p-5 rounded-2xl transition-all group shadow-xl ${
                          isPreferredZone
                            ? 'border-yellow-500/40 shadow-yellow-500/5'
                            : isSelected
                            ? 'border-[#ff6600]/60 shadow-[#ff6600]/10'
                            : 'border-white/10 hover:border-[#ff6600]/40'
                        }`}
                      >
                        <div className="flex justify-between items-center mb-3">
                          <div className="flex items-center gap-2">
                            {/* ── Multi-select checkbox ── */}
                            <button
                              onClick={() => togglePoolSelection(order.id)}
                              disabled={atCapacity && !isSelected}
                              title={atCapacity && !isSelected ? 'Capacité maximale atteinte' : ''}
                              className="shrink-0 text-white/30 hover:text-[#ff6600] transition-colors disabled:opacity-30"
                            >
                              {isSelected
                                ? <CheckSquare className="w-4 h-4 text-[#ff6600]" />
                                : <Square className="w-4 h-4" />}
                            </button>
                            <span className="bg-[#ff6600]/10 text-[#ff6600] px-2.5 py-1 rounded-full text-[9px] font-bold tracking-wider">
                              {order.stores?.location_commune ?? 'Conakry'}
                            </span>
                            {isPreferredZone && (
                              <span className="bg-yellow-500/10 text-yellow-400 border border-yellow-500/20 px-2 py-1 rounded-full text-[8px] font-bold flex items-center gap-1">
                                ⭐ Zone Préférée
                              </span>
                            )}
                            {isCashOrder(order) && (
                              <span className="bg-amber-500/10 text-amber-400 border border-amber-500/20 px-2 py-1 rounded-full text-[8px] font-bold flex items-center gap-1">
                                <Banknote className="w-2.5 h-2.5" /> CASH
                              </span>
                            )}
                          </div>
                          <span className="text-[13px] font-black text-emerald-400">+{getDeliveryEarnings(order).toLocaleString()} GNF</span>
                        </div>
                        {/* Stale order warning */}
                        {isStale && (
                          <div className="flex items-center gap-2 px-3 py-2 bg-amber-500/10 border border-amber-500/20 rounded-xl mb-3">
                            <AlertTriangle className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                            <p className="text-[9px] font-bold text-amber-400">
                              En attente depuis {formatWaitTime(order.created_at)} — le vendeur vous attend !
                            </p>
                          </div>
                        )}
                        <h4 className="text-[13px] font-black text-white tracking-tight uppercase line-clamp-1 mb-1">{order.stores?.store_name ?? '—'}</h4>
                        <div className="flex items-center gap-1.5 text-[10px] font-medium text-white/40 mb-3">
                          <MapPin className="w-3 h-3" />
                          {order.shipping_address?.commune ?? '—'}, {order.shipping_address?.quartier ?? '—'}
                        </div>
                        <div className="flex items-center gap-3 mb-4 text-[9px] font-bold text-white/30">
                          <span className="flex items-center gap-1">
                            <Timer className="w-3 h-3 text-amber-400" />
                            <span className="text-amber-400">{formatWaitTime(order.created_at)}</span>
                          </span>
                          <span>•</span>
                          <span>{formatGNF(order.total_amount)}</span>
                        </div>
                        <button
                          onClick={() => acceptOrder(order.id)}
                          disabled={atCapacity}
                          className="w-full bg-white/5 border border-white/10 text-white py-3 rounded-xl text-[10px] font-black tracking-wider group-hover:bg-[#ff6600] group-hover:border-[#ff6600] disabled:opacity-30 disabled:cursor-not-allowed transition-all flex items-center justify-center gap-2"
                        >
                          Accepter la mission <ChevronRight className="w-3.5 h-3.5" />
                        </button>
                        {atCapacity && (
                          <p className="text-[9px] text-rose-400/70 text-center mt-2">Capacité maximale atteinte ({MAX_CONCURRENT_ORDERS}/{MAX_CONCURRENT_ORDERS})</p>
                        )}
                      </motion.div>
                    );
                  })}
                </AnimatePresence>

                <div className="bg-blue-500/8 border border-blue-500/15 p-5 rounded-2xl">
                  <div className="flex items-center gap-2 text-blue-400 mb-2">
                    <ShieldCheck className="w-4 h-4" />
                    <p className="text-[10px] font-black tracking-wider uppercase">Conseil Sécurité</p>
                  </div>
                  <p className="text-[10px] font-medium text-blue-400/60 leading-relaxed">
                    Ne donnez jamais le colis sans avoir validé le code OTP du client. C'est votre seule preuve de livraison.
                  </p>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* ── Prompt Modal ── */}
      <AnimatePresence>
        {promptConfig?.isOpen && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/80 backdrop-blur-md"
            onClick={() => {
              promptConfig.resolve(null);
              setPromptConfig(null);
              showToast('Signalement annulé', 'info');
            }}>
            <motion.div initial={{ scale: 0.9, opacity: 0, y: 20 }} animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.9, opacity: 0, y: 20 }} onClick={(e) => e.stopPropagation()}
              className="bg-[#111] border border-white/10 p-8 rounded-[2rem] w-full max-w-md flex flex-col gap-5 shadow-2xl">
              <div>
                <h3 className="text-xl font-black text-white tracking-tight uppercase mb-1">{promptConfig.title}</h3>
                {promptConfig.description && <p className="text-[11px] text-white/40 font-bold tracking-wider">{promptConfig.description}</p>}
              </div>
              <input id="courierPromptInput" type="text" autoFocus
                className="w-full p-4 rounded-xl border border-white/10 bg-white/5 text-white font-medium focus:outline-none focus:ring-2 focus:ring-[#ff6600] transition-all text-sm"
                placeholder="Décrivez ici…"
                onKeyDown={(e) => { if (e.key === 'Enter') { promptConfig.resolve((e.target as HTMLInputElement).value); setPromptConfig(null); }}} />
              <div className="flex gap-3">
                <button onClick={() => { promptConfig.resolve(null); setPromptConfig(null); }}
                  className="flex-1 py-4 rounded-xl font-black text-[10px] tracking-wider text-white/40 hover:text-white hover:bg-white/5 transition-all">ANNULER</button>
                <button onClick={() => {
                  const input = document.getElementById('courierPromptInput') as HTMLInputElement;
                  promptConfig.resolve(input.value); setPromptConfig(null);
                }} className="flex-1 py-4 rounded-xl font-black text-[10px] tracking-wider text-white bg-[#ff6600] hover:bg-[#e62e00] transition-all shadow-lg shadow-[#ff6600]/20">ENVOYER</button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ── Abandon Mission Modal (per-order) ── */}
      <AnimatePresence>
        {abandoningOrderId && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/80 backdrop-blur-md"
            onClick={() => setAbandoningOrderId(null)}>
            <motion.div initial={{ scale: 0.9, opacity: 0, y: 20 }} animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.9, opacity: 0, y: 20 }} onClick={e => e.stopPropagation()}
              className="bg-[#111] border border-orange-500/20 p-8 rounded-[2rem] w-full max-w-md flex flex-col gap-5 shadow-2xl">
              <div>
                <div className="flex items-center gap-3 mb-2">
                  <div className="w-10 h-10 bg-orange-500/10 rounded-xl flex items-center justify-center">
                    <XCircle className="w-5 h-5 text-orange-400" />
                  </div>
                  <div>
                    <h3 className="text-xl font-black text-white tracking-tight uppercase">Abandonner la mission</h3>
                    <p className="text-[9px] text-white/30 font-bold tracking-wider">#{abandoningOrderId.slice(0,8).toUpperCase()}</p>
                  </div>
                </div>
                <p className="text-[11px] text-white/40 font-bold tracking-wider">
                  La commande retournera dans le pool et sera disponible pour un autre livreur.
                </p>
              </div>
              <div className="space-y-2">
                <p className="text-[9px] font-black text-white/30 tracking-widest uppercase">Raison</p>
                {ABANDON_REASONS.map(reason => (
                  <button key={reason} onClick={() => setAbandonReason(reason)}
                    className={`w-full text-left px-4 py-3 rounded-xl text-[11px] font-bold tracking-wider transition-all border ${
                      abandonReason === reason
                        ? 'bg-orange-500/15 border-orange-500/40 text-orange-300'
                        : 'bg-white/[0.03] border-white/10 text-white/50 hover:border-white/20'
                    }`}>
                    {reason}
                  </button>
                ))}
              </div>
              <div className="flex gap-3 pt-2">
                <button onClick={() => setAbandoningOrderId(null)}
                  className="flex-1 py-4 rounded-xl font-black text-[10px] tracking-wider text-white/40 hover:text-white hover:bg-white/5 transition-all">
                  ANNULER
                </button>
                <button onClick={abandonMission} disabled={abandoning}
                  className="flex-1 py-4 rounded-xl font-black text-[10px] tracking-wider text-white bg-orange-500 hover:bg-orange-400 disabled:opacity-50 transition-all flex items-center justify-center gap-2">
                  {abandoning ? <Loader2 className="w-4 h-4 animate-spin" /> : <XCircle className="w-4 h-4" />}
                  CONFIRMER L'ABANDON
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ── Cash Collection Confirm Modal ── */}
      <AnimatePresence>
        {showCashConfirm && pendingDeliveryId && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/90 backdrop-blur-md">
            <motion.div initial={{ scale: 0.9, opacity: 0, y: 20 }} animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.9, opacity: 0, y: 20 }}
              className="bg-[#111] border border-amber-500/30 p-8 rounded-[2rem] w-full max-w-md flex flex-col gap-6 shadow-2xl text-center">
              <div className="w-16 h-16 bg-amber-500/10 border border-amber-500/20 rounded-2xl flex items-center justify-center mx-auto">
                <Banknote className="w-8 h-8 text-amber-400" />
              </div>
              <div>
                <p className="text-[9px] font-black text-amber-400 tracking-widest uppercase mb-2">Paiement Cash</p>
                <h3 className="text-2xl font-black text-white tracking-tighter uppercase mb-2">Avez-vous encaissé ?</h3>
                <p className="text-[12px] text-white/50 font-medium leading-relaxed">
                  Confirmez avoir reçu{' '}
                  <span className="text-amber-400 font-black text-base">
                    {formatGNF(pendingCashOrder?.total_amount)}
                  </span>
                  {' '}du client avant de valider la livraison.
                </p>
              </div>
              <div className="flex gap-3">
                <button
                  onClick={() => {
                    // Also clear the OTP spinner so the courier can re-tap
                    // the verify button if they choose to wait and try again.
                    setVerifyingOtpId(null);
                    setShowCashConfirm(false);
                    setPendingDeliveryId(null);
                  }}
                  disabled={isFinalizingDelivery}
                  className="flex-1 py-4 rounded-xl font-black text-[10px] tracking-wider text-white/40 hover:text-white hover:bg-white/5 transition-all border border-white/10 disabled:opacity-30 disabled:cursor-not-allowed">
                  NON, ATTENDRE
                </button>
                <button
                  onClick={() => finalizeDelivery(pendingDeliveryId, otpValues[pendingDeliveryId])}
                  disabled={isFinalizingDelivery}
                  className="flex-1 py-4 rounded-xl font-black text-[10px] tracking-wider text-white bg-emerald-600 hover:bg-emerald-500 transition-all shadow-xl flex items-center justify-center gap-2 disabled:opacity-60 disabled:cursor-not-allowed">
                  {isFinalizingDelivery
                    ? <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                    : <CheckCircle className="w-4 h-4" />}
                  {isFinalizingDelivery ? 'Traitement...' : 'OUI, ENCAISSÉ'}
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </CourierLayout>
  );
}
