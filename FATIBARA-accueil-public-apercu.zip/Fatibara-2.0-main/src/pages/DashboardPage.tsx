import React, { useState, useEffect } from 'react';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import Header from '../components/Header';
import Footer from '../components/Footer';
import { useAppContext } from '../context/AppContext';
import { Wallet, Package, Heart, Settings, ArrowRight, Store, Plus, MapPin, Phone, ShieldCheck, CreditCard, Truck, Loader2, Bell, Eye, EyeOff, Filter, ChevronDown, CheckCircle2, Clock, Activity } from 'lucide-react';
import { supabase, safeSupabaseQuery } from '../lib/supabase';
import AuthModal from '../components/AuthModal';
import LoyaltyHub from '../components/LoyaltyHub';
import ProductCard from '../components/ProductCard';
import AddressManager from '../components/AddressManager';
import ReviewModal from '../components/ReviewModal';
import CourierRatingModal from '../components/CourierRatingModal';
import OrderTimeline from '../components/OrderTimeline';
import { useStore } from '../store/useStore';
import { useCommerceStore } from '../store/useCommerceStore';
import { useToast } from '../context/ToastContext';
import { MessageSquare, Share2, Star, AlertTriangle, X, FileText } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { refundOrderFinancials } from '../services/financialService';
import PushNotificationToggle from '../components/PushNotificationToggle';
import { APP_NAME } from '../lib/constants';
import { getStatusLabel } from '../utils/formatters';

import TransactionalWallet from '../components/TransactionalWallet';
import { Skeleton } from '../components/ui/Skeleton';

const MenuCard = ({ onClick, icon: Icon, title, description }: { onClick: () => void, icon: any, title: string, description: string }) => (
  <button onClick={onClick} className="flex items-center justify-between p-4 md:p-6 bg-white dark:bg-gray-900 rounded-2xl border border-gray-100 dark:border-gray-800 hover:border-[#ff6600]/30 hover:shadow-md transition-all group shadow-sm text-left w-full min-h-[72px] md:min-h-[88px]">
    <div className="flex items-center gap-4 md:gap-5">
      <div className="w-10 h-10 md:w-14 md:h-14 bg-gray-50 dark:bg-gray-800 rounded-xl flex items-center justify-center text-gray-500 group-hover:bg-orange-50 group-hover:text-[#ff6600] transition-colors shrink-0">
        <Icon className="w-5 h-5 md:w-7 md:h-7" />
      </div>
      <div>
        <div className="font-bold text-[14px] md:text-[16px] text-gray-900 dark:text-white tracking-tight">{title}</div>
        <div className="text-[11px] md:text-[12px] font-medium text-gray-500 dark:text-gray-400 line-clamp-1 mt-0.5">{description}</div>
      </div>
    </div>
    <ArrowRight className="w-4 h-4 md:w-5 md:h-5 shrink-0 text-gray-300 group-hover:text-[#ff6600] group-hover:translate-x-1 transition-all" />
  </button>
);

import { friendlyError } from '../lib/utils';

export default function DashboardPage() {
  const { walletBalance, followedVendors, user, isAuthLoading, profileType, refreshProfile, loyaltyPoints, referralCode, courierStatus, setIsChatOpen } = useAppContext();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const { isDarkMode, setIsDarkMode } = useStore();
  const { wishlist } = useCommerceStore();
  const { showToast } = useToast();
  
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  
  const [loading, setLoading] = useState(true);
  const [storeData, setStoreData] = useState<any>(null);
  
  // Dashboard Navigation State
  const [activeView, setActiveView] = useState<'overview' | 'orders' | 'wishlist' | 'address' | 'wallet' | 'settings'>('overview');
  const [activeOrderId, setActiveOrderId] = useState<string | null>(null);
  
  // Review Modal State
  const [reviewOrder, setReviewOrder] = useState<any>(null);
  const [courierRatingOrder, setCourierRatingOrder] = useState<any>(null);

  // Orders and Wishlist State
  const [myOrders, setMyOrders] = useState<any[]>([]);
  const [orderStatusFilter, setOrderStatusFilter] = useState<'all' | 'pending' | 'processing' | 'completed' | 'cancelled'>('all');
  const [detailsOrder, setDetailsOrder] = useState<any | null>(null);
  const [wishlistProducts, setWishlistProducts] = useState<any[]>([]);
  const [loadingData, setLoadingData] = useState(false);

  // Wallet & Pro State
  const [showDashBalance, setShowDashBalance] = useState(false);
  const [isToppingUp, setIsToppingUp] = useState(false);
  const [isCancellingOrder, setIsCancellingOrder] = useState(false);
  const [isUpgrading, setIsUpgrading] = useState(false);
  const [confirmConfig, setConfirmConfig] = useState<{
    isOpen: boolean;
    orderId: string | null;
  }>({ isOpen: false, orderId: null });

  const confirmCancelOrder = async () => {
    if (!confirmConfig.orderId || isCancellingOrder || !user) return;
    setIsCancellingOrder(true);
    try {
      // ISSUE-19: Server-side ownership + cancellability check BEFORE calling the
      // financial RPC. This prevents any client-side manipulation from cancelling
      // orders that don't belong to this user or are in a non-cancellable state.
      const { data: orderCheck, error: checkErr } = await supabase
        .from('orders')
        .select('id, status, user_id')
        .eq('id', confirmConfig.orderId)
        .eq('user_id', user.id) // ownership enforced at query level
        .in('status', ['pending', 'accepted']) // only cancellable statuses
        .maybeSingle();

      if (checkErr) throw checkErr;
      if (!orderCheck) {
        showToast("Cette commande ne peut plus être annulée.", "error");
        setConfirmConfig({ isOpen: false, orderId: null });
        return;
      }

      await refundOrderFinancials(confirmConfig.orderId, 'Annulation par le client');
      await refreshProfile(); // refresh wallet balance after refund
      setMyOrders(prev => prev.map(o => o.id === confirmConfig.orderId ? {...o, status: 'cancelled'} : o));
      showToast("Commande annulée et remboursée sur votre solde", "success");
      setConfirmConfig({ isOpen: false, orderId: null });
    } catch(err) {
      showToast("Erreur lors de l'annulation", "error");
    } finally {
      setIsCancellingOrder(false);
    }
  };

  // ── URL-driven tab activation ────────────────────────────────────────────
  // Runs once on mount: reads ?tab= and ?status= query params so that direct
  // navigation to /dashboard?tab=wallet (or after a LengoPay redirect) opens
  // the correct view and shows an appropriate toast.
  useEffect(() => {
    const tab = searchParams.get('tab');
    const status = searchParams.get('status');
    const VALID_TABS = ['overview', 'orders', 'wishlist', 'address', 'wallet', 'settings'] as const;
    if (tab && (VALID_TABS as readonly string[]).includes(tab)) {
      setActiveView(tab as typeof VALID_TABS[number]);
    }
    if (status === 'success') {
      showToast('Recharge confirmée ! Votre solde a été mis à jour.', 'success');
    } else if (status === 'failure') {
      showToast('La recharge a échoué. Veuillez réessayer.', 'error');
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []); // intentionally runs once on mount

  useEffect(() => {
    async function checkStore() {
      if (isAuthLoading) return;
      if (!user) {
        setLoading(false);
        return;
      }

      try {
        const { data, error } = await safeSupabaseQuery<any>(
          supabase
            .from('stores')
            .select('*')
            .eq('owner_id', user.id)
            .maybeSingle()
        );
        
        if (data) setStoreData(data);
      } catch (err) {
        // Normal if no store exists
      } finally {
        setLoading(false);
      }
    }
    checkStore();
  }, [user, isAuthLoading]);

  // Resilient fetch for user orders with safe fallbacks and mapping
  const fetchOrders = React.useCallback(async (silent = false) => {
    if (!user) return;
    if (!silent) setLoadingData(true);
    try {
      // Primary query: rich joined data with products
      const primaryQuery = supabase
        .from('orders')
        .select(`
          id,
          tracking_number,
          status,
          financial_status,
          total_amount,
          payment_method,
          created_at,
          courier_id,
          delivery_otp,
          shipping_address,
          order_items(*, product:products(id, title, price_gnf, image_urls, category, stock_quantity))
        `)
        .eq('user_id', user.id)
        .order('created_at', { ascending: false });

      const { data, error } = await safeSupabaseQuery<any[]>(primaryQuery, 'select', 'orders');

      if (!error && data) {
        const mapped = data.map((o: any) => ({
          ...o,
          order_items: (o.order_items || []).map((item: any) => ({
            ...item,
            price: Number(item.price ?? item.price_at_purchase ?? item.unit_price ?? item.product?.price_gnf ?? 0),
            product: item.product || {
              title: item.title || 'Article commandé',
              image_urls: item.image_url ? [item.image_url] : []
            }
          }))
        }));
        setMyOrders(mapped);
        return;
      }

      // If primary query encounters an error (nested join failure / PGRST cache), fallback to clean query
      console.warn("Primary orders query encountered an error, trying resilient fallback...", error);
      const fallbackQuery = supabase
        .from('orders')
        .select('id, tracking_number, status, financial_status, total_amount, payment_method, created_at, courier_id, delivery_otp, shipping_address, order_items(*)')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false });

      const { data: fallbackData, error: fallbackError } = await safeSupabaseQuery<any[]>(fallbackQuery, 'select', 'orders_fallback');

      if (fallbackError) {
        throw fallbackError;
      }

      if (fallbackData) {
        const mappedFallback = fallbackData.map((o: any) => ({
          ...o,
          order_items: (o.order_items || []).map((item: any) => ({
            ...item,
            price: Number(item.price ?? item.price_at_purchase ?? item.unit_price ?? 0),
            product: {
              title: item.title || 'Article commandé',
              image_urls: item.image_url ? [item.image_url] : []
            }
          }))
        }));
        setMyOrders(mappedFallback);
      }
    } catch (err: any) {
      console.error("Error fetching user orders:", err);
      if (!silent) {
        showToast("Impossible de synchroniser l'historique des commandes", "error");
      }
    } finally {
      if (!silent) setLoadingData(false);
    }
  }, [user, showToast]);

  // Resilient fetch for wishlist products (decoupled from orders)
  const fetchWishlist = React.useCallback(async () => {
    if (!user) return;
    if (wishlist.length === 0) {
      setWishlistProducts([]);
      return;
    }
    setLoadingData(true);
    try {
      const { data, error } = await safeSupabaseQuery<any[]>(
        supabase
          .from('products')
          .select('*, stores(store_name, avatar_url)')
          .in('id', wishlist),
        'select',
        'wishlist_products'
      );
      if (error) throw error;
      setWishlistProducts(data || []);
    } catch (err: any) {
      console.error("Error fetching wishlist:", err);
      showToast("Erreur de chargement des favoris", "error");
    } finally {
      setLoadingData(false);
    }
  }, [user, wishlist, showToast]);

  // Trigger order retrieval when user views orders tab
  useEffect(() => {
    if (isAuthLoading || !user) return;
    if (activeView === 'orders') {
      fetchOrders();
    }
  }, [activeView, user?.id, isAuthLoading, fetchOrders]);

  // Trigger wishlist retrieval when user views wishlist tab
  useEffect(() => {
    if (isAuthLoading || !user) return;
    if (activeView === 'wishlist') {
      fetchWishlist();
    }
  }, [activeView, user?.id, wishlist.length, isAuthLoading, fetchWishlist]);

  // Real-time synchronization for order status changes
  useEffect(() => {
    if (!user?.id || activeView !== 'orders') return;

    const channel = supabase
      .channel(`dashboard-orders-live-${user.id}`)
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'orders',
          filter: `user_id=eq.${user.id}`,
        },
        () => {
          fetchOrders(true); // silent refresh without unmounting UI
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [user?.id, activeView, fetchOrders]);

  const handleUpgradeToPro = async () => {
    if (!user) return;
    
    const proCost = 50000; // Cost to upgrade
    if (walletBalance < proCost) {
      showToast(`Solde insuffisant. L'abonnement Pro coûte ${proCost.toLocaleString()} GNF.`, "error");
      return;
    }

    setIsUpgrading(true);
    try {
      const { error: rpcError } = await supabase.rpc('upgrade_user_to_pro', {
        p_user_id: user.id,
        p_cost: proCost
      });
      if (rpcError) throw rpcError;
      
      await refreshProfile();
      showToast("Félicitations ! Vous êtes maintenant membre Pro (Grossiste).", "success");
    } catch (err: any) {
      showToast("Erreur lors de l'abonnement.", "error");
    } finally {
      setIsUpgrading(false);
    }
  };

  // ── Order Filter Calculations for Dashboard History ───────────────────────
  const pendingOrdersCount = myOrders.filter(o => ['pending', 'confirmed', 'accepted'].includes(o.status)).length;
  const processingOrdersCount = myOrders.filter(o => ['preparing', 'processing', 'ready_for_pickup', 'in_transit', 'out_for_delivery'].includes(o.status)).length;
  const completedOrdersCount = myOrders.filter(o => o.status === 'delivered').length;
  const cancelledOrdersCount = myOrders.filter(o => ['cancelled', 'refunded'].includes(o.status)).length;

  const filteredOrders = myOrders.filter((order) => {
    if (orderStatusFilter === 'pending') {
      return ['pending', 'confirmed', 'accepted'].includes(order.status);
    }
    if (orderStatusFilter === 'processing') {
      return ['preparing', 'processing', 'ready_for_pickup', 'in_transit', 'out_for_delivery'].includes(order.status);
    }
    if (orderStatusFilter === 'completed') {
      return order.status === 'delivered';
    }
    if (orderStatusFilter === 'cancelled') {
      return ['cancelled', 'refunded'].includes(order.status);
    }
    return true;
  });

  if (loading) {
    return (
      <div className="min-h-screen flex flex-col bg-white dark:bg-gray-950">
        <Header />
        <main className="flex-grow flex items-center justify-center p-12">
          <div className="flex flex-col items-center gap-6 text-center">
            <div className="relative">
              <div className="w-14 h-14 border border-orange-100 border-t-[#ff6600] rounded-full animate-spin" />
              <ShieldCheck className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-5 h-5 text-[#ff6600]" />
            </div>
            <div className="space-y-1 block">
              <h2 className="text-xl font-bold text-gray-900 tracking-tight">Espace Sécurisé</h2>
              <p className="text-sm font-medium text-gray-500 animate-pulse">Synchronisation de vos données...</p>
            </div>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen flex flex-col bg-white dark:bg-gray-950">
        <Header />
        <main className="flex-grow flex flex-col items-center justify-center p-4 py-12 md:py-24">
          <div className="bg-white dark:bg-gray-900 p-8 md:p-12 max-w-xl w-full rounded-3xl border border-gray-100 dark:border-gray-800 text-center shadow-lg shadow-gray-200/50">
            <div className="w-16 h-16 bg-orange-50 dark:bg-orange-900/20 rounded-2xl flex items-center justify-center mx-auto mb-6 text-[#ff6600] shadow-sm border border-orange-100 dark:border-orange-900/40">
              <ShieldCheck className="w-8 h-8" />
            </div>
            <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-3 tracking-tight">Accès Réservé</h2>
            <p className="text-gray-500 font-medium mb-10 text-sm leading-relaxed">
              Connectez-vous pour accéder à votre inventaire, suivre vos commandes et gérer vos points fidélité.
            </p>
            <button 
              onClick={() => navigate('/login')}
              className="w-full bg-gray-900 text-white py-4 rounded-xl font-semibold hover:bg-gray-800 transition-all shadow-sm active:scale-[0.98]"
            >
              Se connecter / S'inscrire
            </button>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col bg-white dark:bg-gray-950">
      <Header />
      <main className="flex-grow max-w-5xl mx-auto w-full px-4 md:px-10 py-8 md:py-12">
        {/* Dashboard Navigation */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 md:mb-12 gap-4 md:gap-6">
          <div className="flex items-center gap-3 md:gap-4">
            {activeView !== 'overview' && (
              <button 
                onClick={() => setActiveView('overview')}
                className="p-2.5 md:p-3 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl hover:bg-gray-50 dark:hover:bg-gray-700 text-gray-500 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white transition-colors shrink-0 shadow-sm active:scale-95"
                title="Retour à mon espace"
              >
                <ArrowRight className="w-5 h-5 md:w-6 md:h-6 rotate-180" />
              </button>
            )}
            <div>
              <h1 className="text-2xl md:text-4xl font-bold text-gray-900 dark:text-white tracking-tight">
                {activeView === 'overview' ? 'Mon Espace' : activeView === 'orders' ? 'Mes Commandes' : activeView === 'address' ? 'Mon Adresse' : activeView === 'wallet' ? 'Mon Portefeuille' : activeView === 'settings' ? 'Préférences' : 'Favoris'}
              </h1>
              <p className="text-sm font-medium text-gray-500 mt-1 md:mt-2">Gérez vos préférences et suivez vos activités.</p>
            </div>
          </div>
          
          {/* Store Status Button */}
          {activeView === 'overview' && (
            !storeData ? (
              <button 
                onClick={() => navigate('/vendor-registration')}
                className="bg-[#ff6600] text-white w-full md:w-auto px-6 py-3 md:px-8 md:py-3.5 rounded-xl text-sm font-bold flex items-center justify-center gap-2 md:gap-2.5 hover:bg-[#e62e00] transition-all shadow-sm active:scale-[0.98] uppercase tracking-wide"
              >
                <Plus className="w-5 h-5 md:w-5 md:h-5 text-white/70" /> Devenir Vendeur
              </button>
            ) : (
              <div className="bg-orange-50 text-[#ff6600] border border-orange-100 rounded-xl w-full md:w-auto justify-center px-6 py-3.5 text-sm font-bold uppercase tracking-wide flex items-center gap-2.5 shadow-sm">
                <Store className="w-5 h-5" /> Active: {storeData.store_name}
              </div>
            )
          )}
        </div>

        {activeView === 'wallet' && (
          <div className="animate-in fade-in slide-in-from-bottom-4">
             <TransactionalWallet type="user" id={user.id} />
          </div>
        )}

        {activeView === 'address' && (
          <div className="animate-in fade-in slide-in-from-bottom-4">
             <AddressManager />
          </div>
        )}

        {activeView === 'overview' && (
          <div className="animate-in fade-in slide-in-from-bottom-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 md:gap-8 mb-8 md:mb-12">
              {/* VIP Loyalty Hub */}
              <div className="md:col-span-2">
                <LoyaltyHub points={loyaltyPoints} referralCode={referralCode} />
              </div>

              <div className="space-y-4 md:space-y-6">
                {/* Wallet Card */}
                <div 
                  role="button"
                  tabIndex={0}
                  onClick={() => setActiveView('wallet')}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' || e.key === ' ') {
                      e.preventDefault();
                      setActiveView('wallet');
                    }
                  }}
                  className="w-full bg-[#ff6600] text-white p-6 md:p-8 rounded-3xl shadow-lg shadow-[#ff6600]/20 relative overflow-hidden flex flex-col justify-between min-h-[180px] md:min-h-[200px] text-left hover:scale-[1.02] transition-all group cursor-pointer focus:outline-none focus:ring-2 focus:ring-[#ff6600]/50"
                >
                  <div className="absolute -right-10 -top-10 opacity-10 group-hover:scale-110 transition-transform duration-700">
                    <Wallet className="w-48 h-48 md:w-56 md:h-56 text-white" />
                  </div>
                  
                  <div className="relative z-10 w-full">
                    <div className="flex justify-between items-start">
                      <h2 className="text-[13px] font-bold text-orange-100 mb-2 md:mb-3 uppercase tracking-wider">Solde {APP_NAME}</h2>
                      {/* Balance visibility toggle — stops propagation so it doesn't navigate */}
                      <button
                        type="button"
                        onClick={(e) => { e.stopPropagation(); setShowDashBalance(prev => !prev); }}
                        className="flex items-center justify-center w-8 h-8 rounded-lg bg-white/20 hover:bg-white/30 text-white/80 hover:text-white transition-all active:scale-95 -mt-1"
                        title={showDashBalance ? 'Masquer le solde' : 'Afficher le solde'}
                        aria-label={showDashBalance ? 'Masquer le solde' : 'Afficher le solde'}
                      >
                        {showDashBalance ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                      </button>
                    </div>
                    <div className="text-3xl md:text-5xl font-black tracking-tight tabular-nums text-white flex items-end gap-2">
                       {showDashBalance ? walletBalance.toLocaleString() : '••••••'}
                       {showDashBalance && <span className="text-base md:text-xl font-bold text-orange-200 mb-1 tracking-wider">GNF</span>}
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-2 relative z-10 mt-6 text-[11px] font-black uppercase tracking-widest text-orange-100">
                    Voir Historique <ArrowRight className="w-3.5 h-3.5" />
                  </div>
                </div>

                {/* Quick Stats */}
                <div className="bg-white dark:bg-gray-900 rounded-2xl border border-gray-100 dark:border-gray-800 p-5 md:p-6 shadow-sm flex flex-col justify-center">
                  <div className="flex items-center gap-3 md:gap-4">
                    <div className="w-12 h-12 bg-rose-50 dark:bg-rose-900/20 rounded-xl flex items-center justify-center text-rose-500">
                      <Heart className="w-6 h-6" />
                    </div>
                    <div>
                      <div className="text-2xl md:text-3xl font-bold text-gray-900 dark:text-white tracking-tight leading-none mb-1">{followedVendors.length}</div>
                      <div className="text-xs font-medium text-gray-500">Boutiques suivies</div>
                    </div>
                  </div>
                </div>

                <button 
                  onClick={() => setIsChatOpen(true)}
                  className="w-full bg-white dark:bg-gray-900 border border-gray-100 dark:border-gray-800 rounded-2xl p-5 md:p-6 flex items-center justify-between hover:border-[#ff6600] dark:hover:border-[#ff6600] hover:bg-orange-50/30 dark:hover:bg-orange-900/10 transition-all shadow-sm hover:shadow-md group min-h-[80px] md:min-h-[100px]"
                >
                  <div className="flex items-center gap-3 md:gap-4">
                     <div className="w-12 h-12 md:w-14 md:h-14 bg-orange-50 dark:bg-orange-900/20 rounded-xl flex items-center justify-center text-[#ff6600] transition-colors">
                       <MessageSquare className="w-6 h-6 md:w-7 md:h-7" />
                     </div>
                     <div className="text-left">
                       <div className="text-[14px] md:text-[16px] font-bold text-gray-900 dark:text-white tracking-tight">Support VIP Libre</div>
                       <div className="text-[11px] md:text-[12px] font-medium text-gray-500 dark:text-gray-400 mt-0.5">Chat en direct 24/7</div>
                     </div>
                  </div>
                  <ArrowRight className="w-4 h-4 md:w-5 md:h-5 text-gray-300 group-hover:text-[#e62e00] group-hover:translate-x-1 transition-all" />
                </button>

                {profileType !== 'pro' && profileType !== 'admin' ? (
                  <button 
                    onClick={handleUpgradeToPro}
                    disabled={isUpgrading}
                    className="w-full bg-gradient-to-r from-amber-500 to-yellow-500 rounded-2xl p-5 md:p-6 flex items-center justify-between text-white transition-all shadow-sm hover:shadow-md group min-h-[80px] md:min-h-[100px]"
                  >
                    <div className="flex items-center gap-3 md:gap-4 text-left">
                       <div className="w-12 h-12 md:w-14 md:h-14 bg-white/20 rounded-xl flex items-center justify-center text-white transition-colors">
                         {isUpgrading ? <Loader2 className="w-6 h-6 animate-spin" /> : <Star className="w-6 h-6 md:w-7 md:h-7" />}
                       </div>
                       <div>
                         <div className="text-[14px] md:text-[16px] font-bold tracking-tight">Devenir Grossiste</div>
                         <div className="text-[11px] md:text-[12px] font-medium text-white/80 mt-0.5">50 000 GNF / à vie</div>
                       </div>
                    </div>
                  </button>
                ) : (
                  <div className="w-full bg-amber-50 dark:bg-amber-900/20 border border-amber-100 dark:border-amber-900/40 rounded-2xl p-5 md:p-6 flex items-center gap-3 md:gap-4 shadow-sm min-h-[80px] md:min-h-[100px]">
                      <div className="w-12 h-12 md:w-14 md:h-14 bg-amber-100 dark:bg-amber-900/40 rounded-xl flex items-center justify-center text-amber-600 dark:text-amber-400">
                        <Star className="w-6 h-6 md:w-7 md:h-7" />
                      </div>
                      <div className="text-left">
                        <div className="text-[14px] md:text-[16px] font-bold text-amber-900 tracking-tight">Membre Grossiste</div>
                        <div className="text-[11px] md:text-[12px] font-medium text-amber-700 mt-0.5">Tarifs préférentiels activés</div>
                      </div>
                  </div>
                )}
              </div>
            </div>

            {/* Menu List */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 md:gap-6 mb-12 md:mb-20">
              {storeData && (
                <Link to="/vendor/dashboard" className="flex items-center justify-between p-4 md:p-6 bg-white dark:bg-gray-900 border border-gray-100 dark:border-gray-800 rounded-2xl hover:border-gray-300 dark:hover:border-gray-700 hover:shadow-md transition-all group shadow-sm min-h-[72px] md:min-h-[88px] md:col-span-2">
                  <div className="flex items-center gap-4 md:gap-5">
                    <div className="w-12 h-12 md:w-14 md:h-14 bg-gray-50 rounded-xl flex items-center justify-center text-gray-500 group-hover:bg-orange-50 group-hover:text-[#ff6600] transition-colors">
                      <Store className="w-6 h-6 md:w-7 md:h-7" />
                    </div>
                    <div>
                      <div className="font-bold text-[14px] md:text-[16px] text-gray-900 dark:text-white tracking-tight">Gérer ma boutique</div>
                      <div className="text-[11px] md:text-[12px] font-medium text-gray-500 dark:text-gray-400 mt-0.5">{storeData.store_name}</div>
                    </div>
                  </div>
                  <ArrowRight className="w-4 h-4 md:w-5 md:h-5 text-gray-300 group-hover:text-[#ff6600] group-hover:translate-x-1 transition-all" />
                </Link>
              )}
              <MenuCard onClick={() => setActiveView('orders')} icon={Package} title="Mes Commandes" description="Historique complet, suivi & re-commande" />
              {courierStatus ? (
                <Link to="/livreur/dashboard" className="flex items-center justify-between p-4 md:p-6 bg-[#16a34a] text-white rounded-2xl hover:bg-green-700 transition-all group shadow-sm min-h-[72px] md:min-h-[88px]">
                  <div className="flex items-center gap-4 md:gap-5">
                    <div className="w-12 h-12 md:w-14 md:h-14 bg-white/20 rounded-xl flex items-center justify-center text-white transition-colors">
                      <Truck className="w-6 h-6 md:w-7 md:h-7" />
                    </div>
                    <div>
                      <div className="font-bold text-[14px] md:text-[16px] text-white tracking-tight">Espace Livreur</div>
                      <div className="text-[11px] md:text-[12px] font-medium text-green-100 mt-0.5">Voir mes livraisons</div>
                    </div>
                  </div>
                  <ArrowRight className="w-4 h-4 md:w-5 md:h-5 text-white/70 group-hover:text-white group-hover:translate-x-1 transition-all" />
                </Link>
              ) : (
                profileType !== 'vendor' && (
                  <Link to="/courier-onboarding" className="flex items-center justify-between p-4 md:p-6 bg-[#16a34a] text-white rounded-2xl hover:bg-green-700 transition-all group shadow-sm min-h-[72px] md:min-h-[88px]">
                    <div className="flex items-center gap-4 md:gap-5">
                      <div className="w-12 h-12 md:w-14 md:h-14 bg-white/20 rounded-xl flex items-center justify-center text-white transition-colors">
                        <Truck className="w-6 h-6 md:w-7 md:h-7" />
                      </div>
                      <div>
                        <div className="font-bold text-[14px] md:text-[16px] text-white tracking-tight">Gagner de l'argent</div>
                        <div className="text-[11px] md:text-[12px] font-medium text-green-100 mt-0.5">Devenir Livreur Partner</div>
                      </div>
                    </div>
                    <ArrowRight className="w-4 h-4 md:w-5 md:h-5 text-white/70 group-hover:text-white group-hover:translate-x-1 transition-all" />
                  </Link>
                )
              )}
              <MenuCard onClick={() => setActiveView('wallet')} icon={Wallet} title="Portefeuille" description="Gérer mon solde & recharges" />
              <MenuCard onClick={() => setActiveView('wishlist')} icon={Heart} title="Favoris" description="Voir vos articles sauvegardés" />
              <MenuCard onClick={() => setActiveView('address')} icon={MapPin} title="Adresses" description="Gérer mes lieux de livraison" />
              <MenuCard onClick={() => setActiveView('settings' as any)} icon={Settings} title="Préférences" description="Thème & sécurisation" />
              
              <button 
                onClick={async () => {
                  await supabase.auth.signOut();
                  navigate('/');
                }}
                className="flex items-center justify-between p-4 md:p-6 bg-white dark:bg-gray-900 border border-rose-100 dark:border-rose-900/40 hover:bg-rose-50 dark:hover:bg-rose-900/20 rounded-2xl transition-all group shadow-sm w-full text-left md:col-span-2"
              >
                  <div className="flex items-center gap-4 md:gap-5">
                    <div className="w-12 h-12 md:w-14 md:h-14 bg-rose-50 dark:bg-rose-900/20 group-hover:bg-rose-100 dark:group-hover:bg-rose-900/40 rounded-xl flex items-center justify-center text-rose-500 transition-colors">
                      <Settings className="w-6 h-6 md:w-7 md:h-7" />
                    </div>
                    <div>
                      <div className="font-bold text-[14px] md:text-[16px] text-gray-900 group-hover:text-rose-600 tracking-tight">Se déconnecter</div>
                      <div className="text-[11px] md:text-[12px] font-medium text-gray-500 dark:text-gray-400 mt-0.5">Fin de session</div>
                    </div>
                  </div>
                  <ArrowRight className="w-4 h-4 md:w-5 md:h-5 text-gray-300 group-hover:text-rose-500 group-hover:translate-x-1 transition-all" />
              </button>
            </div>
          </div>
          )}

        {activeView === 'orders' && (
          <div className="animate-in fade-in slide-in-from-bottom-4">
            <div className="mb-6 p-4 rounded-2xl bg-orange-50 dark:bg-orange-950/40 border border-orange-200 dark:border-orange-900/50 flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-sm">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-[#ff6600]/10 text-[#ff6600] flex items-center justify-center font-bold">
                  <Package className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-xs font-bold text-gray-900 dark:text-white">Page Historique Dédiée</h4>
                  <p className="text-[11px] text-gray-500 dark:text-gray-400">Recommander des articles en 1 clic, reçus d'achat et filtres avancés.</p>
                </div>
              </div>
              <button
                onClick={() => navigate('/orders')}
                className="px-4 py-2 rounded-xl bg-[#ff6600] text-white hover:bg-[#e65c00] text-xs font-bold transition-all flex items-center justify-center gap-1.5 shrink-0 shadow-sm"
              >
                <span>Ouvrir l'historique complet</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
            {activeOrderId ? (
              <div className="space-y-8">
                <button 
                  onClick={() => setActiveOrderId(null)}
                  className="flex items-center gap-2 text-[13px] font-semibold text-gray-500 hover:text-gray-900 transition-colors min-h-[44px]"
                >
                  <ArrowRight className="w-4 h-4 rotate-180" /> Retour aux commandes
                </button>
                <div className="min-h-[500px]">
                   <OrderTimeline 
                     currentStatus={myOrders.find(o => o.id === activeOrderId)?.status || 'pending'} 
                     orderId={activeOrderId} 
                   />
                </div>
              </div>
            ) : (
              loadingData ? (
                <div className="space-y-6">
                  {[1, 2, 3].map((i) => (
                    <Skeleton key={i} className="h-48 md:h-56 w-full rounded-3xl" />
                  ))}
                </div>
              ) : myOrders.length === 0 ? (
                <div className="text-center py-12 md:py-20 bg-white dark:bg-gray-900 rounded-3xl border border-gray-100 dark:border-gray-800 shadow-sm">
                  <Package className="w-12 h-12 md:w-16 md:h-16 text-gray-300 mx-auto mb-4 md:mb-6" />
                  <h3 className="text-lg md:text-xl font-bold text-gray-900 dark:text-white mb-2 tracking-tight">Aucune commande</h3>
                  <p className="text-gray-500 font-medium mb-6 md:mb-8">Vous n'avez pas encore passé de commande sur {APP_NAME}.</p>
                  <Link to="/" className="inline-flex bg-gray-900 text-white px-8 py-3.5 rounded-xl text-sm font-semibold hover:bg-gray-800 transition-all shadow-sm active:scale-[0.98]">
                    Explorer le catalogue
                  </Link>
                </div>
              ) : (
                <div className="space-y-6">
                  {/* Order History Status Filter Dropdown & Quick Toggles */}
                  <div className="bg-white dark:bg-gray-900 p-4 md:p-5 rounded-2xl border border-gray-100 dark:border-gray-800 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
                    <div className="flex items-center gap-2.5">
                      <div className="w-9 h-9 rounded-xl bg-orange-50 dark:bg-orange-950/40 text-[#ff6600] flex items-center justify-center font-bold">
                        <Filter className="w-4 h-4" />
                      </div>
                      <div>
                        <h4 className="text-xs font-bold text-gray-900 dark:text-white">Filtrer l'historique</h4>
                        <p className="text-[11px] text-gray-500 dark:text-gray-400">
                          {filteredOrders.length} sur {myOrders.length} commande{myOrders.length > 1 ? 's' : ''} affichée{filteredOrders.length > 1 ? 's' : ''}
                        </p>
                      </div>
                    </div>

                    <div className="flex flex-col sm:flex-row sm:items-center gap-3">
                      {/* Filter Dropdown */}
                      <div className="relative inline-block w-full sm:w-auto">
                        <select
                          aria-label="Filtrer les commandes par statut"
                          value={orderStatusFilter}
                          onChange={(e) => setOrderStatusFilter(e.target.value as any)}
                          className="w-full sm:w-auto appearance-none bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl px-4 py-2.5 pr-10 text-xs font-bold text-gray-900 dark:text-white hover:border-[#ff6600] focus:outline-none focus:ring-2 focus:ring-[#ff6600]/30 transition-all cursor-pointer shadow-sm"
                        >
                          <option value="all">Toutes les commandes ({myOrders.length})</option>
                          <option value="pending">En attente / Confirmées ({pendingOrdersCount})</option>
                          <option value="processing">En cours de livraison ({processingOrdersCount})</option>
                          <option value="completed">Livrées / Terminées ({completedOrdersCount})</option>
                          {cancelledOrdersCount > 0 && (
                            <option value="cancelled">Annulées ({cancelledOrdersCount})</option>
                          )}
                        </select>
                        <ChevronDown className="w-4 h-4 text-gray-400 absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                      </div>

                      {/* Quick Filter Pills */}
                      <div className="flex items-center gap-1.5 overflow-x-auto pb-1 sm:pb-0 scrollbar-none">
                        <button
                          type="button"
                          onClick={() => setOrderStatusFilter('all')}
                          className={`px-3 py-1.5 rounded-lg text-[11px] font-bold transition-all shrink-0 ${
                            orderStatusFilter === 'all'
                              ? 'bg-gray-900 text-white dark:bg-white dark:text-gray-900 shadow-sm'
                              : 'bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-400 hover:bg-gray-200 dark:hover:bg-gray-700'
                          }`}
                        >
                          Toutes ({myOrders.length})
                        </button>
                        <button
                          type="button"
                          onClick={() => setOrderStatusFilter('pending')}
                          className={`px-3 py-1.5 rounded-lg text-[11px] font-bold transition-all shrink-0 ${
                            orderStatusFilter === 'pending'
                              ? 'bg-amber-500 text-white shadow-sm'
                              : 'bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-400 hover:bg-gray-200 dark:hover:bg-gray-700'
                          }`}
                        >
                          En attente ({pendingOrdersCount})
                        </button>
                        <button
                          type="button"
                          onClick={() => setOrderStatusFilter('processing')}
                          className={`px-3 py-1.5 rounded-lg text-[11px] font-bold transition-all shrink-0 ${
                            orderStatusFilter === 'processing'
                              ? 'bg-blue-600 text-white shadow-sm'
                              : 'bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-400 hover:bg-gray-200 dark:hover:bg-gray-700'
                          }`}
                        >
                          En cours ({processingOrdersCount})
                        </button>
                        <button
                          type="button"
                          onClick={() => setOrderStatusFilter('completed')}
                          className={`px-3 py-1.5 rounded-lg text-[11px] font-bold transition-all shrink-0 ${
                            orderStatusFilter === 'completed'
                              ? 'bg-emerald-600 text-white shadow-sm'
                              : 'bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-400 hover:bg-gray-200 dark:hover:bg-gray-700'
                          }`}
                        >
                          Livrées ({completedOrdersCount})
                        </button>
                      </div>
                    </div>
                  </div>

                  {filteredOrders.length === 0 ? (
                    <div className="text-center py-12 md:py-16 bg-white dark:bg-gray-900 rounded-3xl border border-gray-100 dark:border-gray-800 shadow-sm">
                      <Filter className="w-10 h-10 text-gray-300 mx-auto mb-3" />
                      <h3 className="text-base font-bold text-gray-900 dark:text-white mb-1">Aucune commande trouvée</h3>
                      <p className="text-xs text-gray-500 dark:text-gray-400 mb-5">
                        Aucune commande ne correspond au filtre sélectionné (
                        {orderStatusFilter === 'pending'
                          ? 'En attente'
                          : orderStatusFilter === 'processing'
                          ? 'En cours'
                          : orderStatusFilter === 'completed'
                          ? 'Livrées'
                          : orderStatusFilter === 'cancelled'
                          ? 'Annulées'
                          : 'Toutes'}
                        ).
                      </p>
                      <button
                        type="button"
                        onClick={() => setOrderStatusFilter('all')}
                        className="px-5 py-2.5 rounded-xl bg-orange-50 dark:bg-orange-950/40 text-[#ff6600] font-bold text-xs hover:bg-[#ff6600] hover:text-white transition-all shadow-sm"
                      >
                        Afficher toutes les commandes ({myOrders.length})
                      </button>
                    </div>
                  ) : (
                    filteredOrders.map((order) => (
                      <div key={order.id} className="bg-white dark:bg-gray-900 rounded-3xl border border-gray-100 dark:border-gray-800 p-6 md:p-8 shadow-sm hover:shadow-md transition-all flex flex-col gap-6 group">
                        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                           <div className="flex items-center gap-3">
                             <div className="w-10 h-10 bg-gray-50 dark:bg-gray-800 rounded-xl flex items-center justify-center text-gray-500 font-bold text-[9px] leading-tight text-center px-1">
                               {order.tracking_number ? order.tracking_number.slice(-6) : order.id.substring(0,6)}
                             </div>
                             <div>
                                                              <span className={`px-3 py-1.5 rounded-xl text-[11px] font-black uppercase tracking-wider shadow-sm flex items-center gap-1.5 w-fit ${
                                 ['pending', 'confirmed', 'accepted'].includes(order.status)
                                   ? 'bg-amber-50 dark:bg-amber-950/40 text-amber-700 dark:text-amber-400 border border-amber-200 dark:border-amber-900/50'
                                   : ['preparing', 'processing', 'ready_for_pickup', 'in_transit', 'out_for_delivery'].includes(order.status)
                                   ? 'bg-blue-50 dark:bg-blue-950/40 text-blue-700 dark:text-blue-400 border border-blue-200 dark:border-blue-900/50'
                                   : order.status === 'delivered'
                                   ? 'bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-400 border border-emerald-200 dark:border-emerald-900/50'
                                   : 'bg-rose-50 dark:bg-rose-950/40 text-rose-700 dark:text-rose-400 border border-rose-200 dark:border-rose-900/50'
                               }`}>
                                 <span className="text-xs">{getStatusLabel(order.status).emoji}</span>
                                 <span>{getStatusLabel(order.status).label}</span>
                               </span>
                               <p className="text-[11px] font-medium text-gray-500 mt-1">
                                 {order.tracking_number || `#${order.id.substring(0,8)}`} · {new Date(order.created_at).toLocaleDateString('fr-FR')}
                               </p>
                             </div>
                           </div>
                           <div className="text-left md:text-right">
                             <p className="text-xl font-black text-gray-900 dark:text-white tracking-tight">{order.total_amount?.toLocaleString()} <span className="text-xs font-medium text-gray-500">GNF</span></p>
                             <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mt-1">Mode: {order.payment_method || 'N/A'}</p>
                           </div>
                        </div>

                        {/* Items List */}
                        <div className="flex items-center gap-3 overflow-x-auto pb-2 scrollbar-none">
                           {order.order_items?.map((item: any, idx: number) => (
                             <div key={idx} className="flex-shrink-0 flex items-center gap-3 bg-gray-50 dark:bg-gray-800/50 p-2 rounded-2xl border border-gray-100 dark:border-gray-800">
                               <div className="w-12 h-12 rounded-xl overflow-hidden shadow-sm">
                                 <img 
                                   src={item.product?.image_urls?.[0] || 'https://images.unsplash.com/photo-1560393464-5c69a73c5770?q=80&w=200'} 
                                   alt={item.product?.title || item.title || 'Article'}
                                   className="w-full h-full object-cover"
                                 />
                               </div>
                               <div className="pr-4">
                                 <p className="text-[11px] font-bold text-gray-900 dark:text-white line-clamp-1 max-w-[120px]">{item.product?.title || item.title || 'Article'}</p>
                                 {item.selected_variations && Object.keys(item.selected_variations).length > 0 && (
                                    <p className="text-[9px] font-bold text-gray-400 uppercase mt-0.5">
                                      {Object.entries(item.selected_variations).map(([k, v]) => `${k}: ${v}`).join(' | ')}
                                    </p>
                                 )}
                                 <p className="text-[10px] font-medium text-gray-500">Qte: {item.quantity}</p>
                               </div>
                             </div>
                           ))}
                        </div>

                        <div className="flex flex-col sm:flex-row gap-3 pt-4 border-t border-gray-50 dark:border-gray-800">
                          {order.status === 'delivered' && (
                            <>
                              <button 
                                onClick={() => setReviewOrder(order)}
                                className="px-5 py-2.5 bg-yellow-50 dark:bg-yellow-900/20 text-yellow-700 dark:text-yellow-400 rounded-xl text-xs font-black uppercase tracking-widest hover:bg-yellow-100 transition-all flex items-center justify-center gap-2"
                              >
                                <Star className="w-4 h-4 fill-current" /> Avis Produit
                              </button>
                              {order.courier_id && (
                                <button 
                                  onClick={() => setCourierRatingOrder(order)}
                                  className="px-5 py-2.5 bg-emerald-50 dark:bg-emerald-900/20 text-emerald-700 dark:text-emerald-400 rounded-xl text-xs font-black uppercase tracking-widest hover:bg-emerald-100 transition-all flex items-center justify-center gap-2"
                                >
                                  <Truck className="w-4 h-4" /> Noter Livreur
                                </button>
                              )}
                            </>
                          )}
                          {/* Block self-cancel once payment is captured — contact support for refunds */}
                          {order.status === 'pending' &&
                           order.financial_status !== 'paid' &&
                           order.financial_status !== 'processed' && (
                             <button 
                               onClick={() => setConfirmConfig({ isOpen: true, orderId: order.id })}
                               className="px-5 py-2.5 bg-rose-50 dark:bg-rose-900/20 text-rose-600 dark:text-rose-400 rounded-xl text-xs font-black uppercase tracking-widest hover:bg-rose-100 transition-all flex items-center justify-center gap-2"
                             >
                               <AlertTriangle className="w-4 h-4" /> Annuler
                             </button>
                           )}
                          <button 
                            onClick={() => setDetailsOrder(order)}
                            className="px-5 py-3 bg-gray-100 dark:bg-gray-800 text-gray-700 dark:text-gray-300 rounded-xl text-xs font-black uppercase tracking-widest hover:bg-gray-200 dark:hover:bg-gray-700 transition-all flex items-center justify-center gap-2"
                          >
                            <FileText className="w-4 h-4" /> Détails & Facture
                          </button>
                          <button 
                            onClick={() => setActiveOrderId(order.id)}
                            className="flex-1 sm:flex-none px-6 py-3 bg-gray-900 dark:bg-[#ff6600] text-white rounded-xl text-xs font-black uppercase tracking-widest hover:shadow-lg transition-all"
                          >
                            Suivre la livraison
                          </button>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              )
            )}
          </div>
        )}

        {activeView === 'settings' && (
          <div className="animate-in fade-in slide-in-from-bottom-4 space-y-6">
             
             {/* General Settings Card */}
             <div className="bg-white dark:bg-gray-900 rounded-3xl border border-gray-100 dark:border-gray-800 p-6 md:p-8 shadow-sm">
                <div className="flex items-center gap-4 mb-6 pb-6 border-b border-gray-100">
                  <div className="w-12 h-12 bg-gray-50 rounded-xl flex items-center justify-center text-gray-500 shadow-sm border border-gray-100">
                    <Settings className="w-6 h-6" />
                  </div>
                  <div>
                    <h2 className="text-lg md:text-xl font-bold text-gray-900 tracking-tight">Thème de l'App</h2>
                    <p className="text-sm font-medium text-gray-500 mt-0.5">Personnalisez votre expérience.</p>
                  </div>
                </div>
                
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="font-semibold text-gray-900">Mode Sombre</h3>
                    <p className="text-xs font-medium text-gray-500 mt-1">Réduit la fatigue oculaire.</p>
                  </div>
                  
                  {/* Theme Toggle Switch */}
                  <div className="flex items-center">
                    <button 
                      onClick={() => setIsDarkMode(!isDarkMode)}
                      className={`relative inline-flex h-8 w-14 items-center rounded-full transition-colors focus:outline-none ${isDarkMode ? 'bg-[#ff6600]' : 'bg-gray-200'}`}
                    >
                      <span className={`inline-block h-6 w-6 rounded-full bg-white transition-transform ${isDarkMode ? 'translate-x-7' : 'translate-x-1'}`} />
                    </button>
                  </div>
                </div>
             </div>
             
             {/* Note: AddressManager is also technically a setting, so it might be good to link it here or embed it. */}
             <div className="bg-white dark:bg-gray-900 rounded-3xl border border-gray-100 dark:border-gray-800 p-6 md:p-8 flex items-center justify-between shadow-sm">
                <div>
                  <h3 className="font-semibold text-gray-900">Gestion des Adresses</h3>
                  <p className="text-xs font-medium text-gray-500 mt-1">Modifiez vos adresses de livraison.</p>
                </div>
                <button
                  onClick={() => setActiveView('address')}
                  className="px-6 py-2.5 bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl text-sm font-semibold text-gray-700 hover:bg-gray-100 transition-all"
                >
                  Gérer
                </button>
             </div>

             {/* Notifications push */}
             <div className="bg-white dark:bg-gray-900 rounded-3xl border border-gray-100 dark:border-gray-800 p-6 md:p-8 shadow-sm">
               <div className="flex items-center gap-4 mb-5 pb-5 border-b border-gray-100 dark:border-gray-800">
                 <div className="w-12 h-12 bg-gray-50 dark:bg-white/5 rounded-xl flex items-center justify-center text-gray-500 shadow-sm border border-gray-100 dark:border-white/10">
                   <Bell className="w-6 h-6" />
                 </div>
                 <div>
                   <h2 className="text-lg md:text-xl font-bold text-gray-900 dark:text-white tracking-tight">Notifications</h2>
                   <p className="text-sm font-medium text-gray-500 mt-0.5">Alertes commandes et livraisons.</p>
                 </div>
               </div>
               <PushNotificationToggle />
             </div>
          </div>
        )}

        {activeView === 'wishlist' && (
          <div className="animate-in fade-in slide-in-from-bottom-4">
            {loadingData ? (
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 md:gap-6">
                {[1, 2, 3, 4].map(i => (
                  <Skeleton key={i} className="h-64 md:h-80 w-full rounded-[2rem]" />
                ))}
              </div>
            ) : wishlistProducts.length === 0 ? (
              <div className="text-center py-20 bg-white dark:bg-gray-900 rounded-3xl border border-gray-100 dark:border-gray-800 shadow-sm">
                <Heart className="w-16 h-16 text-gray-300 mx-auto mb-6" />
                <h3 className="text-xl font-bold text-gray-900 mb-2 tracking-tight">Votre liste est vide</h3>
                <p className="text-gray-500 font-medium mb-8">Découvrez nos produits et ajoutez-les à vos favoris.</p>
                <Link to="/" className="inline-flex bg-gray-900 text-white px-8 py-3.5 rounded-xl text-sm font-semibold hover:bg-gray-800 transition-all shadow-sm active:scale-[0.98]">
                  Explorer le catalogue
                </Link>
              </div>
            ) : (
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 md:gap-6">
                {wishlistProducts.map((product, index) => (
                  <ProductCard 
                     key={product.id} 
                     product={product} 
                     index={index} 
                     onShare={() => {}} 
                     onQuickView={() => {}} 
                  />
                ))}
              </div>
            )}
          </div>
        )}
      </main>
      <Footer />
      <AuthModal isOpen={isAuthModalOpen} onClose={() => setIsAuthModalOpen(false)} />
      
      {/* Custom Confirm Modal for Order Cancellation */}
      <AnimatePresence>
        {confirmConfig.isOpen && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-gray-900/80 backdrop-blur-sm"
            onClick={() => setConfirmConfig({ isOpen: false, orderId: null })}
          >
            <motion.div 
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              onClick={(e) => e.stopPropagation()}
              className="bg-white p-8 rounded-[2.5rem] w-full max-w-sm shadow-2xl border border-gray-100 text-center"
            >
              <div className="w-16 h-16 bg-rose-50 text-rose-500 rounded-2xl flex items-center justify-center mx-auto mb-6 shadow-sm border border-rose-100">
                <AlertTriangle className="w-8 h-8" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-2 tracking-tight">Annuler la commande ?</h3>
              <p className="text-sm font-medium text-gray-500 mb-8 leading-relaxed">
                Êtes-vous sûr de vouloir annuler cette commande ? Cette opération ne peut pas être annulée.
              </p>
              
              <div className="flex gap-3">
                <button
                  onClick={() => setConfirmConfig({ isOpen: false, orderId: null })}
                  className="flex-1 py-4 bg-gray-50 text-gray-700 rounded-xl text-sm font-bold hover:bg-gray-100 transition-all active:scale-[0.98]"
                >
                  Garder
                </button>
                <button
                  onClick={confirmCancelOrder}
                  disabled={isCancellingOrder}
                  className="flex-1 py-4 bg-rose-600 text-white rounded-xl text-sm font-bold hover:bg-rose-700 transition-all shadow-sm active:scale-[0.98] disabled:opacity-70 disabled:cursor-not-allowed flex items-center justify-center gap-2"
                >
                  {isCancellingOrder ? (
                    <><Loader2 className="w-4 h-4 animate-spin" /> Annulation...</>
                  ) : 'Oui, Annuler'}
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
      {/* Order Details Slide-Over Side Drawer */}
      <AnimatePresence>
        {detailsOrder && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[120] flex justify-end bg-gray-900/60 backdrop-blur-sm"
            onClick={() => setDetailsOrder(null)}
          >
            <motion.div
              initial={{ x: '100%' }}
              animate={{ x: 0 }}
              exit={{ x: '100%' }}
              transition={{ type: 'spring', damping: 25, stiffness: 200 }}
              onClick={(e) => e.stopPropagation()}
              className="w-full max-w-xl bg-white dark:bg-gray-900 h-full shadow-2xl flex flex-col overflow-hidden border-l border-gray-100 dark:border-gray-800"
            >
              {/* Drawer Header */}
              <div className="p-6 md:p-8 border-b border-gray-100 dark:border-gray-800 flex items-center justify-between bg-gray-50/50 dark:bg-gray-800/50">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 bg-orange-50 dark:bg-orange-950/40 text-[#ff6600] rounded-2xl flex items-center justify-center font-bold text-sm">
                    <FileText className="w-6 h-6" />
                  </div>
                  <div>
                    <h2 className="text-lg font-black text-gray-900 dark:text-white tracking-tight">Détails de la Commande</h2>
                    <p className="text-xs font-medium text-gray-500 mt-0.5">
                      {detailsOrder.tracking_number || `#${detailsOrder.id.substring(0, 8)}`} · {new Date(detailsOrder.created_at).toLocaleDateString('fr-FR', { day: 'numeric', month: 'long', year: 'numeric' })}
                    </p>
                  </div>
                </div>
                <button
                  onClick={() => setDetailsOrder(null)}
                  className="w-10 h-10 rounded-xl bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 flex items-center justify-center text-gray-500 hover:text-gray-900 dark:hover:text-white transition-all shadow-sm"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Drawer Content */}
              <div className="flex-1 overflow-y-auto p-6 md:p-8 space-y-6">
                {/* Status & Payment Banner */}
                <div className="grid grid-cols-2 gap-4">
                  <div className="bg-gray-50 dark:bg-gray-800/50 p-4 rounded-2xl border border-gray-100 dark:border-gray-800">
                    <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1">Statut Actuel</p>
                    <span className={`px-2.5 py-1 rounded-lg text-[10px] font-black uppercase tracking-wider inline-flex items-center gap-1.5 ${
                      ['pending', 'confirmed', 'accepted'].includes(detailsOrder.status)
                        ? 'bg-amber-50 text-amber-700 border border-amber-200'
                        : ['preparing', 'processing', 'ready_for_pickup', 'in_transit', 'out_for_delivery'].includes(detailsOrder.status)
                        ? 'bg-blue-50 text-blue-700 border border-blue-200'
                        : detailsOrder.status === 'delivered'
                        ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                        : 'bg-rose-50 text-rose-700 border border-rose-200'
                    }`}>
                      <span>{getStatusLabel(detailsOrder.status).emoji}</span>
                      <span>{getStatusLabel(detailsOrder.status).label}</span>
                    </span>
                  </div>
                  <div className="bg-gray-50 dark:bg-gray-800/50 p-4 rounded-2xl border border-gray-100 dark:border-gray-800">
                    <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1">Mode de Paiement</p>
                    <p className="text-xs font-bold text-gray-900 dark:text-white capitalize">{detailsOrder.payment_method || 'Paiement à la livraison'}</p>
                    <p className="text-[10px] font-medium text-emerald-600 mt-0.5">{detailsOrder.financial_status === 'paid' ? 'Payé' : 'En attente de paiement'}</p>
                  </div>
                </div>

                {/* Shipping & Delivery Details */}
                <div className="bg-gray-50 dark:bg-gray-800/50 p-5 rounded-2xl border border-gray-100 dark:border-gray-800 space-y-3">
                  <h3 className="text-xs font-black uppercase tracking-wider text-gray-900 dark:text-white flex items-center gap-2">
                    <MapPin className="w-4 h-4 text-[#ff6600]" /> Informations de Livraison
                  </h3>
                  <div className="space-y-2 text-xs text-gray-600 dark:text-gray-300">
                    <div className="flex justify-between">
                      <span className="font-medium text-gray-500">Adresse :</span>
                      <span className="font-bold text-right text-gray-900 dark:text-white">{detailsOrder.shipping_address || detailsOrder.address || 'Non spécifiée'}</span>
                    </div>
                    {detailsOrder.recipient_name && (
                      <div className="flex justify-between">
                        <span className="font-medium text-gray-500">Destinataire :</span>
                        <span className="font-bold text-right text-gray-900 dark:text-white">{detailsOrder.recipient_name}</span>
                      </div>
                    )}
                    {detailsOrder.phone && (
                      <div className="flex justify-between">
                        <span className="font-medium text-gray-500">Téléphone :</span>
                        <span className="font-bold text-right text-gray-900 dark:text-white">{detailsOrder.phone}</span>
                      </div>
                    )}
                    {detailsOrder.delivery_notes && (
                      <div className="flex justify-between">
                        <span className="font-medium text-gray-500">Instructions :</span>
                        <span className="font-bold text-right text-gray-900 dark:text-white">{detailsOrder.delivery_notes}</span>
                      </div>
                    )}
                  </div>
                </div>

                {/* Full Product List */}
                <div className="space-y-3">
                  <h3 className="text-xs font-black uppercase tracking-wider text-gray-900 dark:text-white flex items-center gap-2">
                    <Package className="w-4 h-4 text-[#ff6600]" /> Articles Commandés ({detailsOrder.order_items?.length || 0})
                  </h3>
                  <div className="space-y-3">
                    {detailsOrder.order_items?.map((item: any, idx: number) => (
                      <div key={idx} className="flex items-center gap-4 bg-gray-50 dark:bg-gray-800/50 p-3.5 rounded-2xl border border-gray-100 dark:border-gray-800">
                        <div className="w-14 h-14 rounded-xl overflow-hidden shadow-sm shrink-0 bg-white">
                          <img 
                            src={item.product?.image_urls?.[0] || 'https://images.unsplash.com/photo-1560393464-5c69a73c5770?q=80&w=200'} 
                            alt={item.product?.title || item.title || 'Article'}
                            className="w-full h-full object-cover"
                          />
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="text-xs font-bold text-gray-900 dark:text-white truncate">{item.product?.title || item.title || 'Article'}</p>
                          {item.selected_variations && Object.keys(item.selected_variations).length > 0 && (
                            <p className="text-[10px] font-medium text-gray-500 mt-0.5">
                              {Object.entries(item.selected_variations).map(([k, v]) => `${k}: ${v}`).join(' | ')}
                            </p>
                          )}
                          <p className="text-[11px] font-bold text-[#ff6600] mt-1">
                            {item.price?.toLocaleString()} GNF × {item.quantity}
                          </p>
                        </div>
                        <div className="text-right">
                          <p className="text-xs font-black text-gray-900 dark:text-white">
                            {((item.price || 0) * (item.quantity || 1)).toLocaleString()} GNF
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Financial Summary */}
                <div className="bg-gray-50 dark:bg-gray-800/50 p-5 rounded-2xl border border-gray-100 dark:border-gray-800 space-y-2 text-xs">
                  <div className="flex justify-between text-gray-500 font-medium">
                    <span>Sous-total articles</span>
                    <span>{detailsOrder.total_amount?.toLocaleString()} GNF</span>
                  </div>
                  <div className="flex justify-between text-gray-500 font-medium">
                    <span>Frais de livraison</span>
                    <span>Inclus ou Gratuit</span>
                  </div>
                  <div className="pt-2 border-t border-gray-200 dark:border-gray-700 flex justify-between text-sm font-black text-gray-900 dark:text-white">
                    <span>Total Général</span>
                    <span className="text-[#ff6600]">{detailsOrder.total_amount?.toLocaleString()} GNF</span>
                  </div>
                </div>
              </div>

              {/* Drawer Footer */}
              <div className="p-6 border-t border-gray-100 dark:border-gray-800 bg-gray-50/50 dark:bg-gray-800/50 flex gap-3">
                <button
                  onClick={() => {
                    const orderId = detailsOrder.id;
                    setDetailsOrder(null);
                    setActiveOrderId(orderId);
                  }}
                  className="flex-1 py-3.5 bg-gray-900 dark:bg-[#ff6600] text-white rounded-xl text-xs font-black uppercase tracking-widest hover:shadow-lg transition-all text-center"
                >
                  Suivre la livraison
                </button>
                <button
                  onClick={() => setDetailsOrder(null)}
                  className="px-6 py-3.5 bg-gray-200 dark:bg-gray-700 text-gray-700 dark:text-gray-200 rounded-xl text-xs font-black uppercase tracking-widest hover:bg-gray-300 transition-all"
                >
                  Fermer
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
      <ReviewModal 
        isOpen={!!reviewOrder} 
        onClose={() => setReviewOrder(null)} 
        productId={reviewOrder?.product_id}
        orderId={reviewOrder?.id}
        onSuccess={() => {
          // Successfully reviewed
        }}
      />
      <CourierRatingModal
        isOpen={!!courierRatingOrder}
        onClose={() => setCourierRatingOrder(null)}
        orderId={courierRatingOrder?.id}
        courierId={courierRatingOrder?.courier_id}
        onSuccess={() => {
          // Successfully rated courier
        }}
      />
    </div>
  );
}
