import React, { useEffect, useState, useRef } from 'react';
import { useParams, useSearchParams, Link, useNavigate } from 'react-router-dom';
import { CheckCircle, XCircle, ShoppingBag, ArrowRight, Home, RefreshCw, Clock } from 'lucide-react';
import { motion } from 'motion/react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import { supabase } from '../lib/supabase';
import { hapticFeedback } from '../lib/haptics';
import confetti from 'canvas-confetti';

export default function PaymentResultPage() {
  const { id: paramId } = useParams();
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  
  const queryOrderId = searchParams.get('orderId');
  const queryStatus = searchParams.get('status');
  
  const id = paramId || queryOrderId;
  const isSuccess = window.location.pathname.includes('success') || queryStatus === 'success';

  const [status, setStatus] = useState<'loading' | 'success' | 'failure' | 'pending'>('loading');
  const [order, setOrder] = useState<any>(null);
  const timerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    // Allow up to 12 s for the webhook to arrive and process before final verdict.
    // Each poll is 2 s apart, 6 attempts maximum.
    let attempts = 0;
    const MAX_ATTEMPTS = 6;

    async function pollOrder() {
      if (!id) {
        // P-9: No ID in URL at all — fall back to URL param hint
        setStatus('pending');
        return;
      }

      try {
        let query = supabase
          .from('orders')
          .select('id, status, financial_status, tracking_number');

        if (id.startsWith('ORD-')) {
          query = query.eq('tracking_number', id);
        } else {
          query = (query as any).eq('id', id);
        }

        const { data, error } = await query;
        if (error) throw error;

        const ordersArray = Array.isArray(data) ? data : data ? [data] : [];
        const ord = ordersArray[0];

        if (!ord) {
          // Order doesn't exist yet (webhook not arrived) — retry
          attempts++;
          if (attempts < MAX_ATTEMPTS) {
            timerRef.current = setTimeout(pollOrder, 2000);
          } else {
            // Webhook never arrived — trust URL param as last resort
            setStatus('pending');
          }
          return;
        }

        // Verify actual DB state — never trust URL param alone.
        // financial_status values: pending → paid → processed → failed/refunded
        // A wallet checkout lands as financial_status='paid' immediately after the RPC.
        // A mobile-money payment lands as financial_status='paid' after the webhook fires.
        // 'processed' = financials distributed to vendor/courier (post-delivery trigger).
        // 'processing' does NOT exist in the schema — checking for it caused the poll
        // to always retry 6× (12 s delay) before finally falling back to the URL param.
        const dbSuccess =
          ord.financial_status === 'paid'     ||
          ord.financial_status === 'processed'||
          ord.status          === 'accepted'  ||
          ord.status          === 'confirmed' ||
          ord.status          === 'delivered';

        const dbFailed =
          ord.status          === 'cancelled' ||
          ord.financial_status === 'failed'   ||
          ord.financial_status === 'refunded';

        if (dbSuccess) {
          setOrder(ord);
          setStatus('success');
          hapticFeedback('reward');
          confetti({
            particleCount: 150,
            spread: 70,
            origin: { y: 0.6 },
            colors: ['#ff6600', '#000000', '#FFFFFF'],
          });
        } else if (dbFailed) {
          setOrder(ord);
          setStatus('failure');
          hapticFeedback('error');
        } else {
          // Still pending — webhook hasn't fired yet. Retry.
          attempts++;
          if (attempts < MAX_ATTEMPTS) {
            timerRef.current = setTimeout(pollOrder, 2000);
          } else {
            // Webhook never arrived in 12 s — fall back to URL param so the
            // user isn't stuck on a spinner for a payment that already went through.
            setOrder(ord);
            setStatus('pending');
          }
        }
      } catch (err) {
        console.error('Order verification error:', err);
        // On DB error, fall back to URL param to avoid blocking the user
        setStatus('pending');
      }
    }

    pollOrder();
    return () => {
      if (timerRef.current) clearTimeout(timerRef.current);
    };
  }, [id, isSuccess]);

  return (
    <div className="min-h-screen flex flex-col bg-gray-50 dark:bg-gray-900">
      <Header />
      <main className="flex-grow flex items-center justify-center p-4 py-20">
        <div className="max-w-xl w-full">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-[2.5rem] p-8 md:p-12 shadow-2xl text-center relative overflow-hidden"
          >
            {status === 'success' ? (
              <div className="space-y-6">
                <div className="w-24 h-24 bg-green-100 dark:bg-green-500/10 rounded-full flex items-center justify-center mx-auto mb-8 border-4 border-white dark:border-gray-800 shadow-xl">
                  <CheckCircle className="w-12 h-12 text-green-500" />
                </div>
                
                <h1 className="text-3xl md:text-4xl font-black text-gray-900 dark:text-white uppercase tracking-tighter">
                  Paiement Réussi !
                </h1>
                
                <p className="text-gray-500 dark:text-gray-400 font-medium">
                  Merci de votre confiance. Votre commande <span className="font-bold text-gray-900 dark:text-white">#{id}</span> est maintenant en cours de préparation par le vendeur.
                </p>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-8">
                  <Link 
                    to={id ? `/orders?id=${id}` : '/orders'} 
                    className="flex items-center justify-center gap-2 bg-gray-900 text-white px-8 py-5 rounded-2xl font-bold hover:scale-105 active:scale-95 transition-all shadow-lg"
                  >
                    Suivre ma commande <ArrowRight className="w-4 h-4" />
                  </Link>
                  <Link 
                    to="/" 
                    className="flex items-center justify-center gap-2 bg-white dark:bg-gray-700 text-gray-900 dark:text-white border border-gray-200 dark:border-gray-600 px-8 py-5 rounded-2xl font-bold hover:bg-gray-50 dark:hover:bg-gray-600 transition-all"
                  >
                    Accueil <Home className="w-4 h-4" />
                  </Link>
                </div>
              </div>
            ) : status === 'failure' ? (
              <div className="space-y-6">
                <div className="w-24 h-24 bg-red-100 dark:bg-red-500/10 rounded-full flex items-center justify-center mx-auto mb-8 border-4 border-white dark:border-gray-800 shadow-xl">
                  <XCircle className="w-12 h-12 text-red-500" />
                </div>
                
                <h1 className="text-3xl md:text-4xl font-black text-gray-900 dark:text-white uppercase tracking-tighter">
                  Paiement Échoué
                </h1>
                
                <p className="text-gray-500 dark:text-gray-400 font-medium">
                  Nous n'avons pas pu finaliser votre transaction. Ne vous inquiétez pas, aucun montant n'a été prélevé ou la transaction a été annulée.
                </p>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-8">
                  <button 
                    onClick={() => {
                      // Navigate to cart so the user can retry with a fresh checkout.
                      // We never fetched order_items in the poll query so we can't
                      // reconstruct a product URL — cart is the safe fallback.
                      navigate('/checkout/cart');
                    }}
                    className="flex items-center justify-center gap-2 bg-[#ff6600] text-white px-8 py-5 rounded-2xl font-bold hover:scale-105 active:scale-95 transition-all shadow-lg"
                  >
                    Réessayer <RefreshCw className="w-4 h-4" />
                  </button>
                  <Link 
                    to="/help" 
                    className="flex items-center justify-center gap-2 bg-white text-gray-900 border border-gray-200 px-8 py-5 rounded-2xl font-bold hover:bg-gray-50 transition-all"
                  >
                    Besoin d'aide ?
                  </Link>
                </div>
              </div>
            ) : status === 'pending' ? (
              <div className="text-center space-y-4">
                <div className="w-20 h-20 bg-amber-500/10 rounded-3xl flex items-center justify-center mx-auto">
                  <Clock className="w-10 h-10 text-amber-500" />
                </div>
                <h2 className="text-2xl font-black text-gray-900 dark:text-white">Vérification en cours...</h2>
                <p className="text-gray-500 dark:text-gray-400 text-sm">Nous n'avons pas encore reçu la confirmation de votre paiement. Cela peut prendre quelques minutes.</p>
                <div className="flex flex-col gap-3 mt-6">
                  <button onClick={() => window.location.reload()} className="py-3 px-6 bg-[#ff6600] text-white rounded-2xl font-black text-sm hover:opacity-90 transition-all">
                    Vérifier à nouveau
                  </button>
                  <a href="/dashboard" className="py-3 px-6 bg-gray-100 dark:bg-white/5 text-gray-700 dark:text-gray-300 rounded-2xl font-black text-sm hover:opacity-90 transition-all text-center">
                    Voir mes commandes
                  </a>
                </div>
              </div>
            ) : (
              <div className="flex flex-col items-center gap-4 py-12">
                <div className="w-12 h-12 border-4 border-[#ff6600] border-t-transparent rounded-full animate-spin"></div>
                <p className="font-bold text-gray-500 uppercase tracking-widest text-xs">Confirmation du paiement...</p>
                <p className="text-xs text-gray-400 max-w-xs text-center">Ceci prend généralement moins de 5 secondes.</p>
              </div>
            )}
          </motion.div>
        </div>
      </main>
      <Footer />
    </div>
  );
}
