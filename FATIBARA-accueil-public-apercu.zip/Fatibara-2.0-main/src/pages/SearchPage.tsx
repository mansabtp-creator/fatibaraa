import React, { useState, useEffect } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import Header from '../components/Header';
import Footer from '../components/Footer';
import ProductCard from '../components/ProductCard';
import FlashDeals from '../components/FlashDeals';
import SEO from '../components/SEO';
import { supabase } from '../lib/supabase';
import { useToast } from '../context/ToastContext';
import { Filter, X, ChevronDown, SlidersHorizontal, PackageX, Loader2, Star } from 'lucide-react';
import { APP_NAME } from '../lib/constants';

const CATEGORIES = [
  'Électronique',
  'Mode & Vêtements',
  'Maison & Cuisine',
  'Beauté & Santé',
  'Cuisine Locale (Guinée)',
  'Artisanat',
  'Services'
];

import { ALL_PREFECTURES } from '../constants/locations';

const COMMUNES = ALL_PREFECTURES;

export default function SearchPage() {
  const { showToast } = useToast();
  const [searchParams, setSearchParams] = useSearchParams();
  const navigate = useNavigate();
  const initialQuery = searchParams.get('q') || '';
  
  const [products, setProducts] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [aiOptimizedQuery, setAiOptimizedQuery] = useState<string | null>(null);
  
  // Filtering state
  const [activeCategory, setActiveCategory] = useState<string | null>(searchParams.get('category'));
  const [activeCommune, setActiveCommune] = useState<string | null>(searchParams.get('commune'));
  const [minPrice, setMinPrice] = useState<string>('');
  const [maxPrice, setMaxPrice] = useState<string>(searchParams.get('maxPrice') || '');
  const [isFilterOpen, setIsFilterOpen] = useState(false);

  useEffect(() => {
    // Sync with URL params if they change
    const urlCat = searchParams.get('category');
    const urlMax = searchParams.get('maxPrice');
    const urlCommune = searchParams.get('commune');
    if (urlCat) setActiveCategory(urlCat);
    if (urlMax) setMaxPrice(urlMax);
    if (urlCommune) setActiveCommune(urlCommune);
  }, [searchParams]);

  useEffect(() => {
    async function fetchResults() {
      setLoading(true);
      try {
        let finalQueryTerm = initialQuery;
        
        // Use AI to optimize search query if it's longer than a few words, to prevent 0-match issues on intent-based searches
        if (initialQuery.length > 15 && initialQuery.includes(' ')) {
           const { parseSearchQuery } = await import('../services/geminiService');
           finalQueryTerm = await parseSearchQuery(initialQuery);
           if (finalQueryTerm !== initialQuery) {
              setAiOptimizedQuery(finalQueryTerm);
           }
        } else {
           setAiOptimizedQuery(null);
        }

        const storeSelect = activeCommune
          ? 'stores!inner (store_name, avatar_url, location_commune, is_verified_store)'
          : 'stores (store_name, avatar_url, location_commune, is_verified_store)';

        let queryBuilder = supabase
          .from('products')
          .select(`
            *,
            ${storeSelect}
          `)
          // SF-BUG-1 FIX: Exclude inactive and rejected products from search results.
          .eq('is_active', true)
          .neq('moderation_status', 'rejected');



        if (finalQueryTerm) {
          const words = finalQueryTerm.split(/\s+/).filter(w => w.length >= 2);
          if (words.length > 0) {
            words.forEach(word => {
              queryBuilder = queryBuilder.or(`title.ilike.%${word}%,description.ilike.%${word}%`);
            });
          }
        }
        
        if (activeCategory) {
          queryBuilder = queryBuilder.eq('category', activeCategory);
        }

        if (activeCommune) {
          queryBuilder = queryBuilder.eq('stores.location_commune', activeCommune);
        }
        
        if (minPrice && !isNaN(parseInt(minPrice))) {
          queryBuilder = queryBuilder.gte('price_gnf', parseInt(minPrice));
        }

        if (maxPrice && !isNaN(parseInt(maxPrice))) {
          queryBuilder = queryBuilder.lte('price_gnf', parseInt(maxPrice));
        }

        const { data, error } = await queryBuilder.limit(24);

        if (error) throw error;
        setProducts(data || []);
      } catch (err: any) {
        console.error("Error fetching search results:", err);
        showToast(err.message || 'Erreur lors du chargement des résultats', 'error');
      } finally {
        setLoading(false);
      }
    }

    fetchResults();
  }, [initialQuery, activeCategory, activeCommune, minPrice, maxPrice]);

  const applyFilters = (e: React.FormEvent) => {
    e.preventDefault();
    setIsFilterOpen(false);
  };

  const clearFilters = () => {
    setActiveCategory(null);
    setActiveCommune(null);
    setMinPrice('');
    setMaxPrice('');
    setIsFilterOpen(false);
    if (!initialQuery) {
      navigate('/');
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      <SEO 
        title={initialQuery ? `Résultats pour "${initialQuery}"` : "Tout le Marché"} 
        description={`Découvrez les meilleurs deals pour ${initialQuery || 'tout type de produits'} sur ${APP_NAME}. Livraison rapide en Guinée.`}
        keywords={`${initialQuery}, ${APP_NAME}, Guinée, Boutique`}
      />
      <Header />
      
      <main className="flex-grow max-w-7xl mx-auto w-full px-4 md:px-8 py-8 flex flex-col md:flex-row gap-8">
        
        {/* Mobile Filter Toggle */}
        <div className="md:hidden flex items-center justify-between bg-white p-4 border border-gray-200 shadow-sm mb-2 rounded-xl">
          <span className="font-bold text-gray-900 text-[13px] tracking-wider">Filtres</span>
          <button 
            onClick={() => setIsFilterOpen(!isFilterOpen)}
            aria-label="Filtrer les résultats"
            className="p-2 border border-gray-200 bg-gray-50 text-gray-900 active:translate-y-1 active:shadow-none shadow-sm hover:bg-[#ff6600] hover:text-white hover:border-[#ff6600] transition-all rounded-lg"
          >
            <SlidersHorizontal className="w-5 h-5" />
          </button>
        </div>

        {/* Sidebar Filters */}
        <aside className={`${isFilterOpen ? 'block' : 'hidden'} md:block w-full md:w-64 shrink-0`}>
          <div className="bg-white border border-gray-200 p-6 shadow-sm sticky top-24 rounded-2xl">
            <div className="flex items-center justify-between mb-6 pb-4 border-b border-gray-100">
              <h2 className="text-[14px] font-bold tracking-wider text-gray-900 flex items-center gap-2">
                <Filter className="w-4 h-4" /> Affiner
              </h2>
              {isFilterOpen && (
                <button onClick={() => setIsFilterOpen(false)} aria-label="Fermer les filtres" className="md:hidden">
                  <X className="w-5 h-5 text-gray-900" />
                </button>
              )}
            </div>

            <form onSubmit={applyFilters} className="space-y-6">
              {/* Category */}
              <div>
                <h3 className="text-[12px] font-bold text-gray-900 opacity-70 mb-3 uppercase">Catégories</h3>
                <div className="space-y-2">
                  <button 
                    type="button"
                    onClick={() => setActiveCategory(null)}
                    className={`w-full text-left px-4 py-2.5 text-[13px] font-bold transition-all rounded-xl ${!activeCategory ? 'bg-[#ff6600] text-white shadow-sm' : 'bg-transparent text-gray-700 hover:bg-gray-50'}`}
                  >
                    Toutes
                  </button>
                  {CATEGORIES.map(cat => (
                    <button 
                      key={cat}
                      type="button"
                      onClick={() => setActiveCategory(cat)}
                      className={`w-full text-left px-4 py-2.5 text-[13px] font-bold transition-all rounded-xl ${activeCategory === cat ? 'bg-orange-50 text-[#ff6600] shadow-sm' : 'bg-transparent text-gray-700 hover:bg-gray-50'}`}
                    >
                      {cat}
                    </button>
                  ))}
                </div>
              </div>

              {/* Commune Filter */}
              <div className="pt-6 border-t border-gray-100">
                <h3 className="text-[12px] font-bold text-gray-900 opacity-70 mb-3 uppercase">Commune</h3>
                <div className="grid grid-cols-2 gap-2">
                  <button 
                    type="button"
                    onClick={() => setActiveCommune(null)}
                    className={`text-center py-2 text-[11px] font-bold transition-all rounded-lg ${!activeCommune ? 'bg-[#ff6600] text-white shadow-sm' : 'bg-gray-50 text-gray-700 hover:bg-gray-100'}`}
                  >
                    Toutes
                  </button>
                  {COMMUNES.map(commune => (
                    <button 
                      key={commune}
                      type="button"
                      onClick={() => setActiveCommune(commune)}
                      className={`text-center py-2 text-[11px] font-bold transition-all rounded-lg ${activeCommune === commune ? 'bg-orange-50 text-[#ff6600] shadow-sm' : 'bg-gray-50 text-gray-700 hover:bg-gray-100'}`}
                    >
                      {commune}
                    </button>
                  ))}
                </div>
              </div>

              {/* Price Range */}
              <div className="pt-6 border-t border-gray-100">
                <h3 className="text-[12px] font-bold text-gray-900 opacity-70 mb-3 uppercase">Prix (GNF)</h3>
                <div className="flex items-center gap-2">
                  <input 
                    type="number" 
                    placeholder="Min" 
                    value={minPrice}
                    onChange={(e) => setMinPrice(e.target.value)}
                    className="w-full bg-gray-50 border border-gray-200 rounded-lg p-2 text-[12px] font-bold text-center outline-none focus:ring-1 focus:ring-[#ff6600] focus:border-[#ff6600] transition-all"
                  />
                  <span className="text-gray-400 font-bold">-</span>
                  <input 
                    type="number" 
                    placeholder="Max" 
                    value={maxPrice}
                    onChange={(e) => setMaxPrice(e.target.value)}
                    className="w-full bg-gray-50 border border-gray-200 rounded-lg p-2 text-[12px] font-bold text-center outline-none focus:ring-1 focus:ring-[#ff6600] focus:border-[#ff6600] transition-all"
                  />
                </div>
              </div>

              <div className="pt-4 flex flex-col gap-3">
                <button type="submit" className="w-full bg-[#ff6600] text-white py-3 rounded-xl text-[13px] font-bold tracking-wide hover:bg-[#e62e00] transition-all shadow-sm active:scale-[0.98]">
                  Appliquer
                </button>
                {(activeCategory || activeCommune || minPrice || maxPrice) && (
                  <button 
                    type="button"
                    onClick={clearFilters}
                    className="w-full bg-white text-gray-500 py-3 border border-gray-200 rounded-xl text-[13px] font-bold hover:bg-gray-50 hover:text-gray-700 transition-all active:scale-[0.98]"
                  >
                    Effacer
                  </button>
                )}
              </div>
            </form>
          </div>
        </aside>

        {/* Results Area */}
        <div className="flex-1">
          <FlashDeals />
          <div className="mb-6 flex flex-col md:flex-row md:items-end justify-between gap-4">
            <div>
              <h1 className="text-2xl md:text-3xl font-bold text-gray-900">
                {initialQuery ? `Résultats pour "${initialQuery}"` : activeCategory ? activeCategory : 'Tous les produits'}
              </h1>
              <p className="text-gray-500 font-medium text-[13px] mt-1">
                {loading ? 'Recherche en cours...' : `${products.length} produit(s) trouvé(s)`}
              </p>

              {aiOptimizedQuery && (
                <div className="mt-4 bg-orange-50 border border-orange-100 rounded-xl p-4 flex items-start gap-3 animate-in fade-in zoom-in duration-500">
                  <div className="mt-0.5"><div className="w-8 h-8 bg-gradient-to-br from-[#ff6600] to-[#e62e00] rounded-lg flex items-center justify-center shadow-sm"><span className="text-[10px] font-black text-white">AI</span></div></div>
                  <div>
                     <p className="text-[11px] font-bold text-[#ff6600] uppercase tracking-wider mb-1">Assistant {APP_NAME}</p>
                     <p className="text-[13px] font-semibold text-gray-800 leading-snug">J'ai optimisé votre texte pour chercher: <span className="bg-white text-[#ff6600] px-1.5 py-0.5 rounded-md border border-orange-100">{aiOptimizedQuery}</span></p>
                  </div>
                </div>
              )}
            </div>
          </div>

          {!loading && products.length > 0 && !activeCategory && (
            <div className="mb-8">
               <div className="flex items-center justify-between mb-4">
                  <h2 className="text-[14px] font-bold text-gray-900 flex items-center gap-2">
                    <Star className="w-4 h-4 text-[#ff6600] fill-[#ff6600]" /> Boutiques de Confiance
                  </h2>
               </div>
               <div className="flex gap-4 overflow-x-auto no-scrollbar pb-4">
                  {[
                    { name: 'Kadiatou Fashion', cat: 'Mode', rating: '4.9', img: 'https://images.unsplash.com/photo-1441986300917-64674bd600d8?w=200&h=200&fit=crop' },
                    { name: 'Diallo Électro', cat: 'High-Tech', rating: '4.8', img: 'https://images.unsplash.com/photo-1491933382434-50028619b5fe?w=200&h=200&fit=crop' },
                    { name: 'Conakry Market', cat: 'Alimentaire', rating: '4.7', img: 'https://images.unsplash.com/photo-1542838132-92c53300491e?w=200&h=200&fit=crop' },
                    { name: 'Guinée Artisanat', cat: 'Culture', rating: '5.0', img: 'https://images.unsplash.com/photo-1540200049848-d9813ea0e120?w=200&h=200&fit=crop' }
                  ].map((shop, i) => (
                    <button key={i} onClick={() => navigate(`/shop?q=${shop.name}`)} className="flex-shrink-0 w-36 bg-white border border-gray-100 rounded-xl p-3 hover:shadow-md hover:border-gray-200 transition-all group">
                       <div className="w-12 h-12 mx-auto rounded-full overflow-hidden mb-2 ring-2 ring-gray-50 group-hover:ring-orange-100 transition-all">
                          <img src={shop.img} alt={shop.name || 'Boutique'} className="w-full h-full object-cover" />
                       </div>
                       <h4 className="text-[12px] font-bold text-gray-900 truncate mb-1">{shop.name}</h4>
                       <div className="flex items-center justify-center gap-1.5">
                          <span className="text-[10px] font-medium text-gray-500">{shop.cat}</span>
                          <span className="text-[10px] font-bold text-[#16a34a]">★{shop.rating}</span>
                       </div>
                    </button>
                  ))}
               </div>
            </div>
          )}

          {loading ? (
            <div className="flex items-center justify-center py-32">
               <Loader2 className="w-8 h-8 animate-spin text-[#ff6600]" />
            </div>
          ) : products.length === 0 ? (
            <div className="bg-white border border-gray-200 rounded-3xl p-12 flex flex-col items-center text-center shadow-sm">
               <div className="w-20 h-20 bg-gray-50 rounded-full flex items-center justify-center mb-6">
                 <PackageX className="w-8 h-8 text-gray-400" />
               </div>
               <h3 className="text-xl font-bold text-gray-900 mb-2">Aucun produit trouvé</h3>
               <p className="text-gray-500 text-[13px] mb-8 max-w-sm">Nous n'avons pas trouvé de produits correspondant à vos critères. Essayez de modifier vos filtres.</p>
               <button onClick={clearFilters} className="bg-[#ff6600] text-white px-6 py-3 rounded-full text-[13px] font-bold tracking-wide hover:bg-[#e62e00] transition-all shadow-sm active:scale-95">
                 Voir tout le catalogue
               </button>
            </div>
          ) : (
            <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-4 gap-4 md:gap-6">
              {products.map((product, index) => (
                <ProductCard 
                  key={product.id} 
                  product={product} 
                  index={index} 
                  onShare={() => {}} 
                  onQuickView={() => {}} 
                />
              ))}
            </div>
          )}
        </div>
      </main>
      
      <Footer />
    </div>
  );
}
