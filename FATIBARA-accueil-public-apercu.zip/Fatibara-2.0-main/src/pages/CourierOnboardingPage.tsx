import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { supabase } from '../lib/supabase';
import { useAppContext } from '../context/AppContext';
import Header from '../components/Header';
import Footer from '../components/Footer';
import { 
  Truck, 
  Wallet, 
  MapPin, 
  Clock, 
  ShieldCheck, 
  CheckCircle2, 
  ArrowRight,
  Zap,
  Star,
  Users
} from 'lucide-react';
import { useToast } from '../context/ToastContext';
import { useNavigate } from 'react-router-dom';
import { APP_NAME } from '../lib/constants';

export default function CourierOnboardingPage() {
  const { user, refreshProfile, courierStatus } = useAppContext();
  const { showToast } = useToast();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [termsAccepted, setTermsAccepted] = useState(false);

  const applyForCourier = async () => {
    if (!user) {
       showToast("Veuillez vous connecter pour postuler.", "error");
       navigate('/login', { state: { from: { pathname: '/courier-onboarding' } } });
       return;
    }
    if (!termsAccepted) {
      showToast("Vous devez accepter les conditions avant de postuler.", "warning");
      return;
    }
    if (loading) return;
    
    setLoading(true);
    try {
      // ── Write all courier fields atomically ──────────────────────────────────
      // courier_status = 'inactive' means "pending admin approval".
      // active_role intentionally stays as the user's current role until the admin
      // approves — CourierAuthGuard checks courier_status, not active_role.
      // Admin sets active_role = 'courier' on approval (AdminApplicationsQueue).
      const { error } = await supabase
        .from('profiles')
        .update({
          courier_status: 'inactive',
          profile_type: 'courier',
          courier_terms_accepted_at: new Date().toISOString(),
        })
        .eq('id', user.id);

      if (error) throw error;

      showToast("Demande envoyée ! Nous vous contacterons bientôt.", "success");
      await refreshProfile();
      navigate('/livreur/dashboard');
    } catch (err: any) {
      showToast(err.message, "error");
    } finally {
      setLoading(false);
    }
  };


  useEffect(() => {
    // Only redirect couriers who are fully approved (active)
    // 'inactive' means pending admin review — they should stay and see their status
    if (courierStatus === 'active') {
      navigate('/livreur/dashboard');
    }
  }, [courierStatus, navigate]);

  if (courierStatus === 'inactive') {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50 dark:bg-[#0a0a0f] p-6">
        <div className="max-w-md w-full text-center space-y-6">
          <div className="w-20 h-20 bg-amber-500/10 rounded-3xl flex items-center justify-center mx-auto">
            <Clock className="w-10 h-10 text-amber-500" />
          </div>
          <div>
            <h2 className="text-2xl font-black text-gray-900 dark:text-white uppercase tracking-tighter">Candidature en cours d'examen</h2>
            <p className="text-gray-500 dark:text-gray-400 text-sm mt-2 font-medium">Notre équipe examine votre dossier. Vous recevrez une notification dès que votre compte sera activé.</p>
          </div>
          <div className="p-4 bg-amber-500/5 border border-amber-500/20 rounded-2xl">
            <p className="text-amber-600 dark:text-amber-400 text-xs font-black uppercase tracking-widest">⏳ Délai habituel : 24 à 48 heures</p>
          </div>
          <button
            onClick={() => navigate('/')}
            className="w-full py-3 bg-gray-900 dark:bg-white/10 text-white rounded-2xl font-black text-sm hover:opacity-90 transition-all"
          >
            Retour à l'accueil
          </button>
        </div>
      </div>
    );
  }

  const benefits = [
    {
      icon: Wallet,
      title: "Gagnez sur chaque livraison",
      desc: `Percevez 80% des frais de livraison instantanément sur votre compte ${APP_NAME}.`
    },
    {
      icon: Clock,
      title: "Travaillez quand vous voulez",
      desc: "Activez votre statut 'En ligne' uniquement quand vous êtes disponible."
    },
    {
      icon: ShieldCheck,
      title: "Paiements sécurisés",
      desc: "Grâce au code OTP client, chaque livraison validée est un paiement garanti."
    }
  ];

  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      <Header />
      
      <main className="flex-grow">
        {/* Banner Hero */}
        <section className="relative h-[60vh] md:h-[70vh] flex items-center justify-center overflow-hidden bg-gray-900">
          <div className="absolute inset-0 z-0">
             <img 
               src="/courier-hero.jpg" 
               className="w-full h-full object-cover opacity-40"
               alt="Livreur Fatibara en action"
             />
             <div className="absolute inset-0 bg-gradient-to-t from-brand-bg via-transparent to-transparent"></div>
          </div>

          <div className="relative z-10 max-w-5xl mx-auto px-6 text-center">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              className="inline-flex items-center gap-3 bg-[#ff6600] text-white px-6 py-3 rounded-full text-[12px] font-bold tracking-wider mb-8"
            >
              <Users className="w-5 h-5" /> Rejoignez le Squad
            </motion.div>
            
            <motion.h1 
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.1 }}
              className="text-6xl md:text-8xl font-bold text-white tracking-tighter uppercase mb-6 leading-[0.9]"
            >
              Devenez <span className="text-[#ff6600]">Livreur</span> {APP_NAME}
            </motion.h1>
            
            <motion.p 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.2 }}
              className="text-xl text-white/60 font-medium max-w-2xl mx-auto tracking-tight"
            >
              Augmentez vos revenus en livrant pour le plus grand marché digital de Guinée. 
              Utilisez votre moto, vélo ou voiture.
            </motion.p>
          </div>
        </section>

        {/* Benefits Grid */}
        <section className="py-24 max-w-7xl mx-auto px-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
            {benefits.map((benefit, idx) => (
              <motion.div 
                key={idx}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: idx * 0.1 }}
                className="bg-[#111] p-12 rounded-[3rem] border border-white/5 hover:border-[#ff6600]/30 transition-all group"
              >
                <div className="w-20 h-20 bg-gray-50 rounded-[2rem] flex items-center justify-center text-[#ff6600] mb-8 group-hover:scale-110 transition-transform">
                  <benefit.icon className="w-10 h-10" />
                </div>
                <h3 className="text-2xl font-bold text-white tracking-tighter uppercase mb-4">{benefit.title}</h3>
                <p className="text-white/40 font-medium leading-relaxed">{benefit.desc}</p>
              </motion.div>
            ))}
          </div>
        </section>

        {/* Social Proof Strip */}
        <section className="py-10 bg-[#0a0a0a] border-y border-white/5">
          <div className="max-w-5xl mx-auto px-6 grid grid-cols-3 gap-6 text-center">
            {[
              { value: '200+', label: 'Livreurs actifs' },
              { value: '150K GNF', label: 'Gain moyen / jour' },
              { value: '24h', label: 'Délai de validation' },
            ].map((stat, i) => (
              <motion.div key={i} initial={{ opacity: 0, y: 10 }} whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }} transition={{ delay: i * 0.1 }}
                className="space-y-1">
                <p className="text-2xl md:text-3xl font-black text-[#ff6600] tracking-tighter">{stat.value}</p>
                <p className="text-[10px] font-bold text-white/40 tracking-widest uppercase">{stat.label}</p>
              </motion.div>
            ))}
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-24 bg-[#ff6600]">
          <div className="max-w-4xl mx-auto px-6 text-center">
             <h2 className="text-4xl md:text-6xl font-bold text-white tracking-tighter uppercase mb-10 leading-none">
               Prêt à démarrer l'aventure ?
             </h2>

             {/* Terms acceptance */}
             <label className="inline-flex items-center gap-3 bg-white/10 border border-white/20 rounded-2xl px-6 py-4 mb-8 cursor-pointer hover:bg-white/20 transition-all">
               <input
                 type="checkbox"
                 checked={termsAccepted}
                 onChange={e => setTermsAccepted(e.target.checked)}
                 className="w-5 h-5 accent-white rounded"
               />
               <span className="text-[12px] font-bold text-white leading-relaxed">
                 J'accepte les conditions livreur et la commission{' '}
                 <span className="font-black underline">80 / 20</span>
               </span>
             </label>

             <div className="flex justify-center">
               <button 
                 onClick={applyForCourier}
                 disabled={loading || !termsAccepted}
                 className="bg-white text-[#ff6600] px-16 py-8 rounded-[2.5rem] text-xl font-bold tracking-wider hover:bg-white transition-all shadow-2xl flex items-center gap-6 mx-auto group disabled:opacity-60 disabled:cursor-not-allowed"
               >
                  {loading ? "Chargement..." : "Postuler maintenant"}
                  <ArrowRight className="w-6 h-6 group-hover:translate-x-2 transition-transform" />
               </button>
             </div>
             <p className="mt-8 text-white/70 font-bold uppercase text-[10px] tracking-[4px]">
                Validation sous 24h par notre équipe
             </p>
          </div>
        </section>

        {/* FAQ Preview */}
        <section className="py-24 max-w-5xl mx-auto px-6 text-center">
           <h2 className="text-3xl font-bold text-white uppercase tracking-tighter mb-16">Comment ça marche ?</h2>
           <div className="flex flex-col md:flex-row items-center justify-between gap-12 text-left">
              <div className="flex-1 space-y-4">
                 <div className="flex items-center gap-4">
                    <span className="w-10 h-10 bg-white/5 rounded-full flex items-center justify-center font-bold text-[#ff6600]">1</span>
                    <h4 className="font-bold text-white tracking-wider">Postulez en 1 clic</h4>
                 </div>
                 <p className="text-white/40 text-sm pl-14">Postulez directement depuis votre compte. Pas de formulaire complexe.</p>
              </div>
              <div className="flex-1 space-y-4">
                 <div className="flex items-center gap-4">
                    <span className="w-10 h-10 bg-white/5 rounded-full flex items-center justify-center font-bold text-[#ff6600]">2</span>
                    <h4 className="font-bold text-white tracking-wider">Vérification</h4>
                 </div>
                 <p className="text-white/40 text-sm pl-14">Nous vérifions votre profil et activons votre accès au pool de commandes.</p>
              </div>
              <div className="flex-1 space-y-4">
                 <div className="flex items-center gap-4">
                    <span className="w-10 h-10 bg-white/5 rounded-full flex items-center justify-center font-bold text-[#ff6600]">3</span>
                    <h4 className="font-bold text-white tracking-wider">Encaissez !</h4>
                 </div>
                 <p className="text-white/40 text-sm pl-14">Acceptez des missions, livrez avec succès et recevez vos gains.</p>
              </div>
           </div>
        </section>
      </main>

      <Footer />
    </div>
  );
}
