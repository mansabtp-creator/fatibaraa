import React, { useEffect } from 'react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import SEO from '../components/SEO';
import { APP_NAME } from '../lib/constants';
import { ShieldCheck, Scale, FileText } from 'lucide-react';

export default function TermsPage() {
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  const lastUpdated = "22 Avril 2026";

  return (
    <div className="min-h-screen flex flex-col bg-gray-50 transition-colors duration-500">
      <SEO title={`Conditions Générales d'Utilisation | ${APP_NAME}`} description={`Conditions générales d'utilisation et de vente de la marketplace ${APP_NAME} en Guinée.`} />
      <Header />
      
      <main className="flex-grow pt-10 pb-20 border-t border-gray-100">
        <div className="max-w-4xl mx-auto px-4 md:px-10 mt-12">
          
          {/* Header Section */}
          <div className="text-center mb-16">
            <div className="w-24 h-24 bg-orange-50 rounded-3xl flex items-center justify-center mx-auto mb-6 text-[#ff6600] shadow-sm border border-orange-100">
              <Scale className="w-12 h-12" />
            </div>
            <h1 className="text-3xl md:text-5xl font-bold text-gray-900 tracking-tight mb-4 leading-tight">
              Conditions Générales<br />d'Utilisation
            </h1>
            <p className="text-gray-500 font-semibold text-sm tracking-wide mb-6">
               Dernière mise à jour : {lastUpdated}
            </p>
            <div className="h-1.5 w-24 bg-[#ff6600] mx-auto rounded-full"></div>
          </div>

          {/* Abstract Quick Summary */}
          <div className="bg-white p-6 md:p-8 rounded-3xl shadow-sm border border-gray-100 mb-12 flex flex-col md:flex-row gap-6 items-center">
             <div className="w-16 h-16 bg-gray-50 rounded-2xl text-gray-400 border border-gray-100 flex items-center justify-center flex-shrink-0 shadow-sm">
                <FileText className="w-8 h-8" />
             </div>
             <div>
                <h3 className="text-xl font-bold text-gray-900 mb-2 tracking-tight">Résumé Rapide</h3>
                <p className="text-base text-gray-600 font-medium leading-relaxed">
                   {APP_NAME} est une plateforme de mise en relation (Marketplace) entre acheteurs et vendeurs professionnels en Guinée. En utilisant nos services, vous acceptez nos règles de bonne conduite, nos politiques de paiement (Orange Money, paiement à la livraison, etc.) et nos régulations de retour. 
                </p>
             </div>
          </div>

          {/* Full Text Document */}
          <div className="bg-white p-8 md:p-12 rounded-3xl shadow-sm border border-gray-100 max-w-none">
            
            <h2 className="text-xl md:text-2xl font-bold text-gray-900 mb-4 tracking-tight">1. Acceptation des Conditions</h2>
            <p className="text-base font-medium text-gray-600 leading-relaxed mb-10">
              L'accès et l'utilisation de l'application et du site web {APP_NAME} sont soumis aux présentes Conditions Générales d'Utilisation. En créant un compte ou en naviguant sur la plateforme, vous acceptez pleinement et sans réserve ces conditions. Si vous n'êtes pas d'accord avec ces termes, veuillez ne pas utiliser nos services.
            </p>

            <h2 className="text-xl md:text-2xl font-bold text-gray-900 mb-4 tracking-tight">2. Rôle de {APP_NAME}</h2>
            <p className="text-base font-medium text-gray-600 leading-relaxed mb-10">
              {APP_NAME} intervient exclusivement en tant qu'intermédiaire technologique. Nous mettons à disposition une plateforme permettant à des vendeurs tiers (boutiques locales en Guinée) de lister et vendre leurs produits à des acheteurs. Le contrat de vente est conclu directement entre l'acheteur et le vendeur. {APP_NAME} n'est pas propriétaire des biens vendus, sauf mention explicite "Vendu par {APP_NAME}".
            </p>

            <h2 className="text-xl md:text-2xl font-bold text-gray-900 mb-4 tracking-tight">3. Accès au Service et Comptes</h2>
            <p className="text-base font-medium text-gray-600 leading-relaxed mb-8">
              Pour effectuer des achats sécurisés, vous devez créer un compte en fournissant des informations véridiques (nom, numéro de téléphone, email). Vous êtes responsable de la confidentialité de vos identifiants. Toute activité effectuée sous votre compte sera considérée comme ayant été effectuée par vous. L'utilisation de faux numéros ou de fausses identités peut entraîner la suspension immédiate du compte.
            </p>

            <div className="bg-yellow-50 border border-yellow-100 rounded-2xl p-6 mb-10 flex flex-col md:flex-row items-center md:items-start gap-4 shadow-sm text-center md:text-left">
              <ShieldCheck className="w-8 h-8 text-yellow-600 flex-shrink-0" />
              <div>
                 <h4 className="text-base font-bold text-yellow-800 tracking-tight mb-2">Sécurité des Transactions</h4>
                 <p className="text-sm font-medium text-yellow-700 m-0">{APP_NAME} sécurise les transactions en agissant comme tiers de confiance. L'argent est conservé de manière sécurisée jusqu'à ce que la livraison soit complétée avec succès.</p>
              </div>
            </div>

            <h2 className="text-xl md:text-2xl font-bold text-gray-900 mb-4 tracking-tight">4. Paiements (Mobile Money)</h2>
            <p className="text-base font-medium text-gray-600 leading-relaxed mb-10">
              Les paiements sur {APP_NAME} peuvent être effectués par mobile money (Orange Money, MTN Mobile Money) ou par carte bancaire. Dans certains cas, le "Paiement à la livraison" est autorisé. Toutes les transactions électroniques sont traitées par nos partenaires agréés par la Banque Centrale de la République de Guinée (BCRG).
            </p>

            <h2 className="text-xl md:text-2xl font-bold text-gray-900 mb-4 tracking-tight">5. Politique de Retour et Remboursement</h2>
            <p className="text-base font-medium text-gray-600 leading-relaxed mb-10">
              Conformément à la politique globale de la plateforme, l'acheteur dispose d'un délai de 7 jours (à compter de la réception de la commande) pour signaler un produit défectueux ou non conforme à sa description. Le produit doit être retourné dans son emballage d'origine. Les articles de beauté, sous-vêtements, ou consommables ouverts ne sont pas éligibles au retour. Les modalités de remboursement sont traitées sur le portefeuille numérique du client ou via mobile money.
            </p>

            <h2 className="text-xl md:text-2xl font-bold text-gray-900 mb-4 tracking-tight">6. Données Personnelles (Confidentialité)</h2>
            <p className="text-base font-medium text-gray-600 leading-relaxed mb-10">
              Nous respectons votre vie privée. Les données récoltées (numéro de téléphone, adresse, préférences) servent uniquement à améliorer la qualité de notre service (suivi des livreurs, facturation, recommandations). {APP_NAME} s'engage à ne jamais revendre vos données à des tiers à des fins publicitaires.
            </p>

            <h2 className="text-xl md:text-2xl font-bold text-gray-900 mb-4 tracking-tight">7. Lois Applicables et Juridiction</h2>
            <p className="text-base font-medium text-gray-600 leading-relaxed">
              Ces CGU sont régies par la législation en vigueur en République de Guinée. En cas de litige entre un utilisateur et la plateforme, une solution à l'amiable sera toujours privilégiée. À défaut, les tribunaux compétents de Conakry seront saisis.
            </p>
            
          </div>
        </div>
      </main>
      
      <div className="md:hidden h-16"></div>
      <Footer />
    </div>
  );
}
