import React, { useState, useEffect, useMemo } from 'react';
import { Link, useNavigate, useParams, useSearchParams } from 'react-router-dom';
import { motion, AnimatePresence } from 'motion/react';
import {
  Package,
  Truck,
  RotateCcw,
  Search,
  ArrowRight,
  ShoppingBag,
  ExternalLink,
  Clock,
  CheckCircle2,
  AlertCircle,
  Copy,
  Check,
  ChevronDown,
  ChevronUp,
  MapPin,
  Printer,
  FileText,
  Star,
  ShieldCheck,
  Phone,
  HelpCircle,
  X,
  CreditCard,
  Building2,
  Calendar,
  Sparkles,
  RefreshCw,
  MessageCircle,
  Share2
} from 'lucide-react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import OrderTimeline from '../components/OrderTimeline';
import ReviewModal from '../components/ReviewModal';
import CourierRatingModal from '../components/CourierRatingModal';
import { Skeleton } from '../components/ui/Skeleton';
import { useAppContext } from '../context/AppContext';
import { useCommerceStore } from '../store/useCommerceStore';
import { useToast } from '../context/ToastContext';
import { supabase } from '../lib/supabase';
import { formatGNF, getStatusLabel, timeAgo } from '../utils/formatters';
import { APP_NAME } from '../lib/constants';
import { refundOrderFinancials } from '../services/financialService';

type FilterTab = 'all' | 'active' | 'delivered' | 'cancelled';

interface OrderItem {
  id: string;
  quantity: number;
  price?: number;
  price_at_purchase?: number;
  selected_variations?: Record<string, string>;
  product_id: string;
  product?: {
    id: string;
    title: string;
    price_gnf: number;
    image_urls?: string[];
    category?: string;
    stock_quantity?: number;
  };
}

interface OrderRecord {
  id: string;
  tracking_number?: string;
  status: string;
  financial_status?: string;
  total_amount: number;
  vendor_delivery_fee?: number;
  payment_method?: string;
  created_at: string;
  shipping_address?: any;
  contact_phone?: string;
  courier_id?: string;
  delivery_otp?: string;
  store_id?: string;
  store?: {
    id: string;
    store_name: string;
    avatar_url?: string;
  };
  order_items?: OrderItem[];
}

export default function OrdersPage() {
  const { user, isAuthLoading, setIsChatOpen, refreshProfile } = useAppContext();
  const { addToCart } = useCommerceStore();
  const { showToast } = useToast();
  const navigate = useNavigate();
  const { id: paramOrderId } = useParams<{ id?: string }>();
  const [searchParams, setSearchParams] = useSearchParams();

  // State
  const [orders, setOrders] = useState<OrderRecord[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [activeTab, setActiveTab] = useState<FilterTab>('all');
  const [expandedOrderId, setExpandedOrderId] = useState<string | null>(null);
  const [copiedTrackingId, setCopiedTrackingId] = useState<string | null>(null);

  // Per-item & Per-order Reordering Loaders
  const [reorderingItems, setReorderingItems] = useState<Record<string, boolean>>({});
  const [reorderingOrders, setReorderingOrders] = useState<Record<string, boolean>>({});
  const [lastReorderedCount, setLastReorderedCount] = useState<number | null>(null);

  // Modals
  const [reviewOrder, setReviewOrder] = useState<OrderRecord | null>(null);
  const [courierRatingOrder, setCourierRatingOrder] = useState<OrderRecord | null>(null);
  const [receiptOrder, setReceiptOrder] = useState<OrderRecord | null>(null);

  // Cancel order modal state
  const [cancelTargetOrder, setCancelTargetOrder] = useState<OrderRecord | null>(null);
  const [isCancelling, setIsCancelling] = useState(false);

  // Read URL query params (?id=xxx or /orders/:id)
  const targetOrderIdFromUrl = paramOrderId || searchParams.get('id');

  // Fetch orders
  const fetchOrders = async (showSkeleton = true) => {
    if (!user) {
      setIsLoading(false);
      return;
    }

    if (showSkeleton) setIsLoading(true);
    else setIsRefreshing(true);

    try {
      const { data, error } = await supabase
        .from('orders')
        .select(`
          id,
          tracking_number,
          status,
          financial_status,
          total_amount,
          vendor_delivery_fee,
          payment_method,
          created_at,
          shipping_address,
          courier_id,
          delivery_otp,
          store_id,
          store:stores(id, store_name, avatar_url),
          order_items(*, product:products(id, title, price_gnf, image_urls, category, stock_quantity))
        `)
        .eq('user_id', user.id)
        .order('created_at', { ascending: false });

      if (error) throw error;
      const mappedOrders = (data || []).map((o: any) => ({
        ...o,
        contact_phone: o.shipping_address?.phone || o.contact_phone || undefined,
        order_items: (o.order_items || []).map((item: any) => ({
          ...item,
          price: Number(item.price ?? item.price_at_purchase ?? item.unit_price ?? item.product?.price_gnf ?? 0),
          price_at_purchase: Number(item.price_at_purchase ?? item.unit_price ?? item.price ?? item.product?.price_gnf ?? 0),
        }))
      }));
      setOrders(mappedOrders);

      // Auto-expand and smooth-scroll to order from URL param if present
      if (targetOrderIdFromUrl && data && data.length > 0) {
        const found = data.find(
          (o: OrderRecord) =>
            o.id === targetOrderIdFromUrl ||
            o.tracking_number === targetOrderIdFromUrl ||
            o.id.startsWith(targetOrderIdFromUrl)
        );
        if (found) {
          setExpandedOrderId(found.id);
          setTimeout(() => {
            const el = document.getElementById(`order-${found.id}`);
            if (el) {
              el.scrollIntoView({ behavior: 'smooth', block: 'center' });
            }
          }, 350);
        }
      }
    } catch (err: any) {
      console.error('Erreur de chargement des commandes:', err);
      showToast('Impossible de charger vos commandes', 'error');
    } finally {
      setIsLoading(false);
      setIsRefreshing(false);
    }
  };

  useEffect(() => {
    if (!isAuthLoading) {
      fetchOrders();
    }
  }, [user, isAuthLoading, targetOrderIdFromUrl]);

  // Real-time subscription to order status updates
  useEffect(() => {
    if (!user) return;

    const channel = supabase
      .channel(`user-orders-live-${user.id}`)
      .on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'orders',
          filter: `user_id=eq.${user.id}`,
        },
        (payload: any) => {
          if (payload.new) {
            setOrders((prev) =>
              prev.map((ord) => (ord.id === payload.new.id ? { ...ord, ...payload.new } : ord))
            );
            const statusInfo = getStatusLabel(payload.new.status);
            showToast(
              `Statut de commande mis à jour: ${statusInfo.label} ${statusInfo.emoji}`,
              'info'
            );
          }
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [user]);

  // Copy tracking ID
  const handleCopyTracking = (tracking: string, id: string) => {
    navigator.clipboard.writeText(tracking);
    setCopiedTrackingId(id);
    showToast('Numéro de suivi copié !', 'success');
    setTimeout(() => {
      setCopiedTrackingId((cur) => (cur === id ? null : cur));
    }, 2000);
  };

  // Reorder Single Item with stock check
  const handleReorderItem = async (item: OrderItem) => {
    if (!item.product_id) return;
    if (item.product?.stock_quantity !== undefined && item.product.stock_quantity <= 0) {
      showToast(`${item.product?.title || 'Cet article'} est en rupture de stock.`, 'warning');
      return;
    }

    const itemKey = item.id || item.product_id;
    setReorderingItems((prev) => ({ ...prev, [itemKey]: true }));

    try {
      await addToCart(
        item.product_id,
        item.quantity || 1,
        item.selected_variations || {},
        user?.id
      );
      setLastReorderedCount(1);
      showToast(`${item.product?.title || 'Article'} ajouté au panier !`, 'success');
    } catch (err) {
      console.error('Erreur réapprovisionnement:', err);
      showToast("Impossible d'ajouter cet article au panier.", 'error');
    } finally {
      setReorderingItems((prev) => ({ ...prev, [itemKey]: false }));
    }
  };

  // Reorder Entire Order with out-of-stock filtering
  const handleReorderOrder = async (order: OrderRecord) => {
    if (!order.order_items || order.order_items.length === 0) return;
    setReorderingOrders((prev) => ({ ...prev, [order.id]: true }));

    try {
      let count = 0;
      for (const item of order.order_items) {
        if (item.product_id) {
          if (item.product?.stock_quantity !== undefined && item.product.stock_quantity <= 0) {
            continue;
          }
          await addToCart(
            item.product_id,
            item.quantity || 1,
            item.selected_variations || {},
            user?.id
          );
          count++;
        }
      }
      if (count > 0) {
        setLastReorderedCount(count);
        showToast(`${count} article(s) ajouté(s) au panier !`, 'success');
      } else {
        showToast('Les articles de cette commande sont actuellement épuisés.', 'warning');
      }
    } catch (err) {
      console.error('Erreur réapprovisionnement commande:', err);
      showToast("Erreur lors de l'ajout des articles au panier.", 'error');
    } finally {
      setReorderingOrders((prev) => ({ ...prev, [order.id]: false }));
    }
  };

  // Share Receipt on WhatsApp
  const handleShareReceiptWhatsApp = (order: OrderRecord) => {
    const itemsSummary =
      order.order_items
        ?.map(
          (it) =>
            `• ${it.product?.title || 'Article'} (x${it.quantity}) - ${formatGNF(
              it.price || it.price_at_purchase || it.product?.price_gnf
            )}`
        )
        .join('\n') || '';

    const text = encodeURIComponent(
      `🧾 *REÇU D'ACHAT ${APP_NAME}*\n` +
        `--------------------------------\n` +
        `🔢 Réf: #${order.tracking_number || order.id.slice(0, 8)}\n` +
        `📅 Date: ${new Date(order.created_at).toLocaleDateString('fr-FR')}\n` +
        `🏪 Boutique: ${order.store?.store_name || 'Boutique certifiée'}\n` +
        `--------------------------------\n` +
        `${itemsSummary}\n` +
        `--------------------------------\n` +
        `💰 *Total Payé: ${formatGNF(order.total_amount)}*\n` +
        `✅ Statut: ${getStatusLabel(order.status).label}\n` +
        `--------------------------------\n` +
        `Suivi en direct sur ${APP_NAME}`
    );
    window.open(`https://wa.me/?text=${text}`, '_blank');
  };

  // Cancel Order with graceful fallback
  const handleConfirmCancel = async () => {
    if (!cancelTargetOrder || isCancelling || !user) return;
    setIsCancelling(true);

    try {
      // Re-verify cancellability
      const { data: checkData, error: checkErr } = await supabase
        .from('orders')
        .select('id, status, user_id')
        .eq('id', cancelTargetOrder.id)
        .eq('user_id', user.id)
        .in('status', ['pending', 'accepted'])
        .maybeSingle();

      if (checkErr) throw checkErr;
      if (!checkData) {
        showToast('Cette commande ne peut plus être annulée directement.', 'error');
        setCancelTargetOrder(null);
        return;
      }

      // Try RPC refund, gracefully fallback to direct update if not applicable
      try {
        await refundOrderFinancials(cancelTargetOrder.id, 'Annulation par le client');
        await refreshProfile();
      } catch (refundErr) {
        console.warn('RPC refund exception, fallback to direct cancellation update:', refundErr);
        const { error: directErr } = await supabase
          .from('orders')
          .update({ status: 'cancelled' })
          .eq('id', cancelTargetOrder.id)
          .eq('user_id', user.id);
        if (directErr) throw directErr;
      }

      setOrders((prev) =>
        prev.map((o) => (o.id === cancelTargetOrder.id ? { ...o, status: 'cancelled' } : o))
      );
      showToast('Commande annulée avec succès.', 'success');
      setCancelTargetOrder(null);
    } catch (err) {
      console.error('Erreur annulation:', err);
      showToast("Erreur lors de l'annulation de la commande.", 'error');
    } finally {
      setIsCancelling(false);
    }
  };

  // Status categories
  const activeStatusList = [
    'pending',
    'confirmed',
    'accepted',
    'preparing',
    'processing',
    'ready_for_pickup',
    'in_transit',
    'out_for_delivery',
  ];
  const deliveredStatusList = ['delivered'];
  const cancelledStatusList = ['cancelled', 'canceled', 'refunded', 'disputed'];

  // Metrics calculation
  const metrics = useMemo(() => {
    const totalOrders = orders.length;
    const activeCount = orders.filter((o) => activeStatusList.includes(o.status)).length;
    const deliveredCount = orders.filter((o) => deliveredStatusList.includes(o.status)).length;
    const totalSpent = orders
      .filter((o) => o.status !== 'cancelled')
      .reduce((acc, curr) => acc + (Number(curr.total_amount) || 0), 0);

    return { totalOrders, activeCount, deliveredCount, totalSpent };
  }, [orders]);

  // Filtered & Searched Orders
  const filteredOrders = useMemo(() => {
    return orders.filter((order) => {
      // Tab filter
      if (activeTab === 'active' && !activeStatusList.includes(order.status)) return false;
      if (activeTab === 'delivered' && !deliveredStatusList.includes(order.status)) return false;
      if (activeTab === 'cancelled' && !cancelledStatusList.includes(order.status)) return false;

      // Search query filter
      if (searchQuery.trim()) {
        const query = searchQuery.toLowerCase().trim();
        const matchesId = order.id.toLowerCase().includes(query);
        const matchesTracking = order.tracking_number?.toLowerCase().includes(query);
        const matchesStore = order.store?.store_name?.toLowerCase().includes(query);
        const matchesProduct = order.order_items?.some((item) =>
          item.product?.title?.toLowerCase().includes(query)
        );
        return matchesId || matchesTracking || matchesStore || matchesProduct;
      }

      return true;
    });
  }, [orders, activeTab, searchQuery]);

  return (
    <div className="min-h-screen flex flex-col bg-gray-50 dark:bg-gray-950 text-gray-900 dark:text-gray-100 transition-colors">
      <Header />

      <main className="flex-grow pt-4 pb-16 md:pb-24 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto w-full">
        {/* Breadcrumb Navigation */}
        <nav className="flex items-center gap-2 text-xs font-semibold text-gray-500 dark:text-gray-400 mb-6">
          <Link to="/" className="hover:text-gray-900 dark:hover:text-white transition-colors">
            Accueil
          </Link>
          <span>/</span>
          <Link to="/dashboard" className="hover:text-gray-900 dark:hover:text-white transition-colors">
            Mon Compte
          </Link>
          <span>/</span>
          <span className="text-gray-900 dark:text-white font-bold">Mes Commandes</span>
        </nav>

        {/* Page Hero Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-8 pb-6 border-b border-gray-200 dark:border-gray-800">
          <div>
            <div className="flex items-center gap-3 mb-2">
              <span className="px-3 py-1 rounded-full text-xs font-extrabold uppercase tracking-wider bg-orange-100 dark:bg-orange-950/60 text-[#ff6600]">
                Espace Client
              </span>
              <span className="text-xs font-medium text-gray-500 dark:text-gray-400 flex items-center gap-1">
                <ShieldCheck className="w-4 h-4 text-emerald-500" />
                Garantie Livraison Sécurisée
              </span>
            </div>
            <h1 className="text-2xl sm:text-3xl md:text-4xl font-extrabold tracking-tight text-gray-900 dark:text-white">
              Historique des Commandes
            </h1>
            <p className="text-sm md:text-base text-gray-600 dark:text-gray-400 mt-1 max-w-2xl">
              Suivez l'acheminement de vos colis en temps réel, consultez vos factures et recommandez
              vos articles préférés en un seul clic.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={() => fetchOrders(false)}
              disabled={isRefreshing || isLoading}
              className="px-4 py-2.5 rounded-xl border border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-900 hover:bg-gray-50 dark:hover:bg-gray-800 text-xs font-bold transition-all flex items-center gap-2 text-gray-700 dark:text-gray-300 shadow-sm disabled:opacity-60"
              title="Rafraîchir"
            >
              <RefreshCw className={`w-4 h-4 ${isRefreshing ? 'animate-spin text-[#ff6600]' : ''}`} />
              <span className="hidden sm:inline">Actualiser</span>
            </button>
            <Link
              to="/checkout/cart"
              className="px-4 py-2.5 rounded-xl bg-[#ff6600] text-white hover:bg-[#e65c00] text-xs font-bold transition-all flex items-center gap-2 shadow-sm active:scale-95"
            >
              <ShoppingBag className="w-4 h-4" />
              <span>Voir le Panier</span>
            </Link>
          </div>
        </div>

        {/* KPI Summary Cards */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4 mb-8">
          <div className="bg-white dark:bg-gray-900 rounded-2xl p-4 sm:p-5 border border-gray-200/80 dark:border-gray-800 shadow-sm flex flex-col justify-between">
            <div className="flex items-center justify-between text-gray-500 dark:text-gray-400 mb-2">
              <span className="text-xs font-bold uppercase tracking-wider">Total Commandes</span>
              <Package className="w-4 h-4 text-blue-500" />
            </div>
            <div>
              <div className="text-2xl sm:text-3xl font-extrabold text-gray-900 dark:text-white">
                {metrics.totalOrders}
              </div>
              <p className="text-[11px] text-gray-500 mt-0.5">Enregistrées sur votre profil</p>
            </div>
          </div>

          <div className="bg-white dark:bg-gray-900 rounded-2xl p-4 sm:p-5 border border-gray-200/80 dark:border-gray-800 shadow-sm flex flex-col justify-between">
            <div className="flex items-center justify-between text-gray-500 dark:text-gray-400 mb-2">
              <span className="text-xs font-bold uppercase tracking-wider">En Acheminement</span>
              <Truck className="w-4 h-4 text-orange-500" />
            </div>
            <div>
              <div className="text-2xl sm:text-3xl font-extrabold text-orange-600 dark:text-orange-400">
                {metrics.activeCount}
              </div>
              <p className="text-[11px] text-gray-500 mt-0.5">Livraison active en cours</p>
            </div>
          </div>

          <div className="bg-white dark:bg-gray-900 rounded-2xl p-4 sm:p-5 border border-gray-200/80 dark:border-gray-800 shadow-sm flex flex-col justify-between">
            <div className="flex items-center justify-between text-gray-500 dark:text-gray-400 mb-2">
              <span className="text-xs font-bold uppercase tracking-wider">Livrées</span>
              <CheckCircle2 className="w-4 h-4 text-emerald-500" />
            </div>
            <div>
              <div className="text-2xl sm:text-3xl font-extrabold text-emerald-600 dark:text-emerald-400">
                {metrics.deliveredCount}
              </div>
              <p className="text-[11px] text-gray-500 mt-0.5">Remises avec succès</p>
            </div>
          </div>

          <div className="bg-white dark:bg-gray-900 rounded-2xl p-4 sm:p-5 border border-gray-200/80 dark:border-gray-800 shadow-sm flex flex-col justify-between">
            <div className="flex items-center justify-between text-gray-500 dark:text-gray-400 mb-2">
              <span className="text-xs font-bold uppercase tracking-wider">Dépenses Totales</span>
              <CreditCard className="w-4 h-4 text-purple-500" />
            </div>
            <div>
              <div className="text-lg sm:text-2xl font-extrabold text-gray-900 dark:text-white truncate">
                {formatGNF(metrics.totalSpent)}
              </div>
              <p className="text-[11px] text-gray-500 mt-0.5">Achats confirmés</p>
            </div>
          </div>
        </div>

        {/* Search & Filter Controls */}
        <div className="bg-white dark:bg-gray-900 rounded-2xl p-3 sm:p-4 border border-gray-200/80 dark:border-gray-800 shadow-sm mb-6 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
          {/* Status Tabs */}
          <div className="flex items-center gap-1 overflow-x-auto pb-1 sm:pb-0 scrollbar-none">
            <button
              onClick={() => setActiveTab('all')}
              className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all whitespace-nowrap flex items-center gap-2 ${
                activeTab === 'all'
                  ? 'bg-gray-900 dark:bg-white text-white dark:text-gray-900 shadow-sm'
                  : 'text-gray-600 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-800'
              }`}
            >
              <span>Toutes</span>
              <span className="text-[10px] px-1.5 py-0.2 rounded-md bg-white/20 dark:bg-black/20 font-black">
                {orders.length}
              </span>
            </button>

            <button
              onClick={() => setActiveTab('active')}
              className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all whitespace-nowrap flex items-center gap-2 ${
                activeTab === 'active'
                  ? 'bg-[#ff6600] text-white shadow-sm'
                  : 'text-gray-600 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-800'
              }`}
            >
              <span>En cours</span>
              <span className="text-[10px] px-1.5 py-0.2 rounded-md bg-white/20 dark:bg-black/20 font-black">
                {metrics.activeCount}
              </span>
            </button>

            <button
              onClick={() => setActiveTab('delivered')}
              className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all whitespace-nowrap flex items-center gap-2 ${
                activeTab === 'delivered'
                  ? 'bg-emerald-600 text-white shadow-sm'
                  : 'text-gray-600 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-800'
              }`}
            >
              <span>Livrées</span>
              <span className="text-[10px] px-1.5 py-0.2 rounded-md bg-white/20 dark:bg-black/20 font-black">
                {metrics.deliveredCount}
              </span>
            </button>

            <button
              onClick={() => setActiveTab('cancelled')}
              className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all whitespace-nowrap flex items-center gap-2 ${
                activeTab === 'cancelled'
                  ? 'bg-red-600 text-white shadow-sm'
                  : 'text-gray-600 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-800'
              }`}
            >
              <span>Annulées</span>
            </button>
          </div>

          {/* Search bar */}
          <div className="relative min-w-[240px] sm:max-w-xs w-full">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
            <input
              type="text"
              placeholder="Rechercher par N° commande, article..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-8 py-2 rounded-xl text-xs bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 text-gray-900 dark:text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-[#ff6600]/40 transition-all"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-2.5 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600 dark:hover:text-gray-200"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
        </div>

        {/* Content Section */}
        {isLoading ? (
          <div className="space-y-4">
            {[1, 2, 3].map((i) => (
              <div
                key={i}
                className="bg-white dark:bg-gray-900 rounded-2xl p-6 border border-gray-200/80 dark:border-gray-800 shadow-sm space-y-4"
              >
                <div className="flex justify-between items-center">
                  <div className="flex gap-3 items-center">
                    <Skeleton className="w-12 h-12 rounded-xl" />
                    <div className="space-y-2">
                      <Skeleton className="w-32 h-4 rounded-md" />
                      <Skeleton className="w-24 h-3 rounded-md" />
                    </div>
                  </div>
                  <Skeleton className="w-28 h-6 rounded-md" />
                </div>
                <Skeleton className="w-full h-20 rounded-xl" />
              </div>
            ))}
          </div>
        ) : filteredOrders.length === 0 ? (
          <div className="bg-white dark:bg-gray-900 rounded-3xl p-10 md:p-16 text-center border border-gray-200/80 dark:border-gray-800 shadow-sm max-w-xl mx-auto my-6">
            <div className="w-20 h-20 bg-orange-50 dark:bg-orange-950/40 rounded-3xl flex items-center justify-center text-[#ff6600] mx-auto mb-6 shadow-sm border border-orange-100 dark:border-orange-900/30">
              <Package className="w-10 h-10" />
            </div>
            <h2 className="text-xl md:text-2xl font-extrabold text-gray-900 dark:text-white tracking-tight mb-2">
              {searchQuery ? 'Aucun résultat trouvé' : 'Aucune commande enregistrée'}
            </h2>
            <p className="text-sm text-gray-500 dark:text-gray-400 max-w-sm mx-auto mb-8 leading-relaxed">
              {searchQuery
                ? `Aucune commande ne correspond à votre recherche "${searchQuery}". Essayez avec un autre mot-clé ou réinitialisez le filtre.`
                : `Vous n'avez pas encore passé de commande sur ${APP_NAME}. Découvrez des milliers de produits locaux aux meilleurs prix.`}
            </p>
            {searchQuery ? (
              <button
                onClick={() => {
                  setSearchQuery('');
                  setActiveTab('all');
                }}
                className="px-6 py-3 rounded-xl bg-gray-900 dark:bg-white text-white dark:text-gray-900 font-bold text-xs uppercase tracking-wider hover:opacity-90 transition-all shadow-sm"
              >
                Réinitialiser la recherche
              </button>
            ) : (
              <Link
                to="/shop"
                className="inline-flex items-center gap-2 px-8 py-3.5 rounded-xl bg-[#ff6600] text-white font-bold text-xs uppercase tracking-wider hover:bg-[#e65c00] transition-all shadow-lg shadow-orange-500/20 active:scale-95"
              >
                <Sparkles className="w-4 h-4" />
                Découvrir le Catalogue
              </Link>
            )}
          </div>
        ) : (
          <div className="space-y-6">
            {filteredOrders.map((order) => {
              const statusInfo = getStatusLabel(order.status);
              const isExpanded = expandedOrderId === order.id;
              const isDelivered = order.status === 'delivered';
              const isCancellable =
                order.status === 'pending' &&
                order.financial_status !== 'paid' &&
                order.financial_status !== 'processed';
              const isReorderingThisOrder = reorderingOrders[order.id];

              return (
                <div
                  key={order.id}
                  id={`order-${order.id}`}
                  className="bg-white dark:bg-gray-900 rounded-2xl md:rounded-3xl border border-gray-200/90 dark:border-gray-800 shadow-sm hover:shadow-md transition-all overflow-hidden flex flex-col group"
                >
                  {/* Order Card Header */}
                  <div className="p-4 sm:p-6 border-b border-gray-100 dark:border-gray-800 bg-gray-50/50 dark:bg-gray-900/60 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                    <div className="flex flex-wrap items-center gap-3">
                      {/* Tracking / ID Tag */}
                      <div className="flex items-center gap-1.5 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 px-3 py-1.5 rounded-xl">
                        <span className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">
                          Réf:
                        </span>
                        <span className="text-xs font-extrabold text-gray-900 dark:text-white font-mono">
                          {order.tracking_number || `#${order.id.slice(0, 8)}`}
                        </span>
                        <button
                          onClick={() =>
                            handleCopyTracking(order.tracking_number || order.id, order.id)
                          }
                          className="p-1 text-gray-400 hover:text-[#ff6600] transition-colors"
                          title="Copier le numéro"
                        >
                          {copiedTrackingId === order.id ? (
                            <Check className="w-3.5 h-3.5 text-emerald-500" />
                          ) : (
                            <Copy className="w-3.5 h-3.5" />
                          )}
                        </button>
                      </div>

                      {/* Date */}
                      <span className="text-xs text-gray-500 dark:text-gray-400 flex items-center gap-1">
                        <Calendar className="w-3.5 h-3.5 text-gray-400" />
                        {new Date(order.created_at).toLocaleDateString('fr-FR', {
                          day: 'numeric',
                          month: 'short',
                          year: 'numeric',
                        })}{' '}
                        · <span className="font-medium text-gray-400">{timeAgo(order.created_at)}</span>
                      </span>

                      {/* Store name if available */}
                      {order.store?.store_name && (
                        <span className="text-xs text-gray-500 dark:text-gray-400 flex items-center gap-1">
                          <Building2 className="w-3.5 h-3.5 text-gray-400" />
                          <span className="font-semibold text-gray-700 dark:text-gray-300">
                            {order.store.store_name}
                          </span>
                        </span>
                      )}
                    </div>

                    {/* Status Badge & Amount */}
                    <div className="flex items-center justify-between sm:justify-end gap-4">
                      {/* Status indicator */}
                      <div
                        className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-xl text-xs font-extrabold uppercase tracking-wider bg-gray-100 dark:bg-gray-800 ${statusInfo.color}`}
                      >
                        <span className="w-2 h-2 rounded-full bg-current animate-pulse" />
                        <span>{statusInfo.emoji}</span>
                        <span>{statusInfo.label}</span>
                      </div>

                      {/* Total */}
                      <div className="text-right">
                        <div className="text-base sm:text-lg font-black text-gray-900 dark:text-white leading-tight">
                          {formatGNF(order.total_amount)}
                        </div>
                        <div className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mt-0.5">
                          {order.payment_method === 'cod'
                            ? 'Paiement à la livraison'
                            : order.payment_method === 'orange'
                            ? 'Orange Money'
                            : order.payment_method === 'mtn'
                            ? 'MTN MoMo'
                            : order.payment_method || 'Payé'}
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Order Items List */}
                  <div className="p-4 sm:p-6 space-y-4">
                    <div className="divide-y divide-gray-100 dark:divide-gray-800">
                      {order.order_items?.map((item, idx) => {
                        const itemKey = item.id || item.product_id;
                        const isReorderingThisItem = reorderingItems[itemKey];
                        const productImg =
                          item.product?.image_urls?.[0] ||
                          'https://images.unsplash.com/photo-1560393464-5c69a73c5770?q=80&w=200';

                        return (
                          <div
                            key={item.id || idx}
                            className="py-3 sm:py-4 first:pt-0 last:pb-0 flex flex-col sm:flex-row sm:items-center justify-between gap-4"
                          >
                            <div className="flex items-center gap-3 sm:gap-4 min-w-0">
                              <Link
                                to={item.product_id ? `/product/${item.product_id}` : '#'}
                                className="w-16 h-16 sm:w-20 sm:h-20 rounded-2xl overflow-hidden bg-gray-100 dark:bg-gray-800 shrink-0 border border-gray-100 dark:border-gray-800 shadow-sm relative group/img"
                              >
                                <img
                                  src={productImg}
                                  alt={item.product?.title || 'Produit'}
                                  className="w-full h-full object-cover group-hover/img:scale-105 transition-transform duration-300"
                                />
                              </Link>

                              <div className="min-w-0 flex-1">
                                <Link
                                  to={item.product_id ? `/product/${item.product_id}` : '#'}
                                  className="text-xs sm:text-sm font-bold text-gray-900 dark:text-white hover:text-[#ff6600] transition-colors line-clamp-1"
                                >
                                  {item.product?.title || 'Article indisponible'}
                                </Link>

                                {item.selected_variations &&
                                  Object.keys(item.selected_variations).length > 0 && (
                                    <div className="flex flex-wrap gap-1.5 mt-1">
                                      {Object.entries(item.selected_variations).map(([k, v]) => (
                                        <span
                                          key={k}
                                          className="text-[10px] font-semibold text-gray-500 dark:text-gray-400 bg-gray-100 dark:bg-gray-800 px-2 py-0.5 rounded-md"
                                        >
                                          {k}: {v}
                                        </span>
                                      ))}
                                    </div>
                                  )}

                                <div className="flex items-center gap-3 mt-1.5 text-xs text-gray-500 dark:text-gray-400">
                                  <span>
                                    Quantité:{' '}
                                    <strong className="text-gray-800 dark:text-gray-200">
                                      {item.quantity}
                                    </strong>
                                  </span>
                                  <span>·</span>
                                  <span>
                                    Prix unitaire:{' '}
                                    <strong className="text-gray-800 dark:text-gray-200">
                                      {formatGNF(item.price || item.price_at_purchase || item.product?.price_gnf)}
                                    </strong>
                                  </span>
                                </div>
                              </div>
                            </div>

                            {/* Direct Per-Item Reorder Button */}
                            <div className="flex items-center justify-end sm:justify-start gap-2 shrink-0">
                              <button
                                onClick={() => handleReorderItem(item)}
                                disabled={isReorderingThisItem || !item.product_id}
                                className="px-3.5 py-2 rounded-xl border border-orange-200 dark:border-orange-900/60 bg-orange-50 dark:bg-orange-950/30 text-[#ff6600] hover:bg-orange-100 dark:hover:bg-orange-950/60 text-xs font-bold transition-all flex items-center gap-1.5 active:scale-95 disabled:opacity-50"
                                title="Recommander cet article"
                              >
                                {isReorderingThisItem ? (
                                  <RotateCcw className="w-3.5 h-3.5 animate-spin" />
                                ) : (
                                  <RotateCcw className="w-3.5 h-3.5" />
                                )}
                                <span>Recommander</span>
                              </button>
                            </div>
                          </div>
                        );
                      })}
                    </div>

                    {/* Delivery / Shipping details snippet */}
                    {order.shipping_address && (
                      <div className="p-3 rounded-xl bg-gray-50 dark:bg-gray-800/40 text-xs text-gray-600 dark:text-gray-400 flex flex-wrap items-center gap-x-4 gap-y-1">
                        <span className="flex items-center gap-1 font-semibold text-gray-700 dark:text-gray-300">
                          <MapPin className="w-3.5 h-3.5 text-gray-400" />
                          Destination:
                        </span>
                        <span>
                          {typeof order.shipping_address === 'string'
                            ? order.shipping_address
                            : `${order.shipping_address.commune || ''} ${
                                order.shipping_address.quartier || ''
                              } ${order.shipping_address.indications || ''}`.trim() ||
                              'Conakry'}
                        </span>
                        {order.contact_phone && (
                          <span className="flex items-center gap-1 text-gray-500">
                            <Phone className="w-3 h-3 text-gray-400" />
                            {order.contact_phone}
                          </span>
                        )}
                      </div>
                    )}
                  </div>

                  {/* Action Bar */}
                  <div className="p-4 sm:p-6 bg-gray-50 dark:bg-gray-900 border-t border-gray-100 dark:border-gray-800 flex flex-wrap items-center justify-between gap-3">
                    {/* Left: Reorder whole order button */}
                    <div className="flex flex-wrap items-center gap-2 w-full sm:w-auto">
                      <button
                        onClick={() => handleReorderOrder(order)}
                        disabled={isReorderingThisOrder}
                        className="flex-1 sm:flex-initial px-4 py-2.5 rounded-xl bg-[#ff6600] text-white hover:bg-[#e65c00] text-xs font-bold transition-all flex items-center justify-center gap-2 shadow-sm active:scale-95 disabled:opacity-60"
                      >
                        {isReorderingThisOrder ? (
                          <RotateCcw className="w-4 h-4 animate-spin" />
                        ) : (
                          <ShoppingBag className="w-4 h-4" />
                        )}
                        <span>Recommander la commande</span>
                      </button>

                      {/* Printable receipt button */}
                      <button
                        onClick={() => setReceiptOrder(order)}
                        className="px-3.5 py-2.5 rounded-xl border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 hover:bg-gray-100 dark:hover:bg-gray-700 text-gray-700 dark:text-gray-300 text-xs font-bold transition-all flex items-center justify-center gap-1.5"
                        title="Voir le reçu / la facture"
                      >
                        <FileText className="w-3.5 h-3.5" />
                        <span className="hidden sm:inline">Reçu</span>
                      </button>
                    </div>

                    {/* Right: Tracking & Action buttons */}
                    <div className="flex flex-wrap items-center gap-2 w-full sm:w-auto justify-end">
                      {/* Review product button for delivered */}
                      {isDelivered && (
                        <button
                          onClick={() => setReviewOrder(order)}
                          className="px-3.5 py-2.5 rounded-xl bg-amber-50 dark:bg-amber-950/40 text-amber-700 dark:text-amber-400 hover:bg-amber-100 dark:hover:bg-amber-900/60 text-xs font-bold transition-all flex items-center gap-1.5"
                        >
                          <Star className="w-3.5 h-3.5 fill-current" />
                          <span>Avis</span>
                        </button>
                      )}

                      {/* Courier rating button if assigned */}
                      {isDelivered && order.courier_id && (
                        <button
                          onClick={() => setCourierRatingOrder(order)}
                          className="px-3.5 py-2.5 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-400 hover:bg-emerald-100 dark:hover:bg-emerald-900/60 text-xs font-bold transition-all flex items-center gap-1.5"
                        >
                          <Truck className="w-3.5 h-3.5" />
                          <span>Noter livreur</span>
                        </button>
                      )}

                      {/* Cancel order button if pending */}
                      {isCancellable && (
                        <button
                          onClick={() => setCancelTargetOrder(order)}
                          className="px-3.5 py-2.5 rounded-xl bg-red-50 dark:bg-red-950/40 text-red-600 dark:text-red-400 hover:bg-red-100 dark:hover:bg-red-900/60 text-xs font-bold transition-all flex items-center gap-1.5"
                        >
                          <AlertCircle className="w-3.5 h-3.5" />
                          <span>Annuler</span>
                        </button>
                      )}

                      {/* Live Tracking Timeline Accordion Toggle */}
                      <button
                        onClick={() =>
                          setExpandedOrderId((cur) => (cur === order.id ? null : order.id))
                        }
                        className={`px-4 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-2 shadow-sm ${
                          isExpanded
                            ? 'bg-gray-900 dark:bg-white text-white dark:text-gray-900'
                            : 'bg-gray-200 dark:bg-gray-800 text-gray-900 dark:text-white hover:bg-gray-300 dark:hover:bg-gray-700'
                        }`}
                      >
                        <Truck className="w-3.5 h-3.5 text-[#ff6600]" />
                        <span>{isExpanded ? 'Masquer le suivi' : 'Suivre la livraison'}</span>
                        {isExpanded ? (
                          <ChevronUp className="w-3.5 h-3.5" />
                        ) : (
                          <ChevronDown className="w-3.5 h-3.5" />
                        )}
                      </button>
                    </div>
                  </div>

                  {/* Live Tracking Drawer / Accordion */}
                  <AnimatePresence>
                    {isExpanded && (
                      <motion.div
                        initial={{ height: 0, opacity: 0 }}
                        animate={{ height: 'auto', opacity: 1 }}
                        exit={{ height: 0, opacity: 0 }}
                        transition={{ duration: 0.3, ease: 'easeInOut' }}
                        className="overflow-hidden border-t border-gray-200 dark:border-gray-800 bg-gray-50/70 dark:bg-black/30"
                      >
                        <div className="p-4 sm:p-8">
                          <OrderTimeline currentStatus={order.status} orderId={order.id} />
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              );
            })}
          </div>
        )}
      </main>

      {/* Invoice / Receipt Modal */}
      <AnimatePresence>
        {receiptOrder && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in">
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-white dark:bg-gray-900 rounded-3xl max-w-lg w-full p-6 md:p-8 border border-gray-200 dark:border-gray-800 shadow-2xl relative max-h-[90vh] overflow-y-auto"
            >
              <button
                onClick={() => setReceiptOrder(null)}
                className="absolute top-5 right-5 p-2 rounded-full text-gray-400 hover:text-gray-600 dark:hover:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>

              <div id="printable-receipt" className="space-y-6">
                {/* Receipt Header */}
                <div className="flex items-center justify-between pb-4 border-b border-gray-100 dark:border-gray-800">
                  <div>
                    <h2 className="text-xl font-black text-gray-900 dark:text-white uppercase tracking-tight">
                      {APP_NAME}
                    </h2>
                    <p className="text-[11px] font-semibold text-[#ff6600] uppercase tracking-wider mt-0.5">
                      Reçu d'Achat Officiel
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="text-xs font-mono font-bold text-gray-500">
                      #{receiptOrder.tracking_number || receiptOrder.id.slice(0, 10).toUpperCase()}
                    </p>
                    <p className="text-[11px] text-gray-400">
                      {new Date(receiptOrder.created_at).toLocaleDateString('fr-FR')}
                    </p>
                  </div>
                </div>

                {/* Customer & Store Info */}
                <div className="grid grid-cols-2 gap-4 text-xs">
                  <div>
                    <span className="font-bold text-gray-400 uppercase tracking-wider text-[10px] block mb-1">
                      Boutique Vendeur
                    </span>
                    <p className="font-bold text-gray-900 dark:text-white">
                      {receiptOrder.store?.store_name || 'Partenaire Certifié'}
                    </p>
                  </div>
                  <div>
                    <span className="font-bold text-gray-400 uppercase tracking-wider text-[10px] block mb-1">
                      Client
                    </span>
                    <p className="font-bold text-gray-900 dark:text-white">
                      {user?.user_metadata?.full_name || user?.email || 'Client Privilège'}
                    </p>
                  </div>
                </div>

                {/* Items Summary */}
                <div className="border border-gray-100 dark:border-gray-800 rounded-2xl overflow-hidden">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-gray-50 dark:bg-gray-800/60 text-gray-500 font-bold">
                      <tr>
                        <th className="py-2.5 px-3">Article</th>
                        <th className="py-2.5 px-3 text-center">Qté</th>
                        <th className="py-2.5 px-3 text-right">Prix</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-100 dark:divide-gray-800">
                      {receiptOrder.order_items?.map((it, i) => (
                        <tr key={i}>
                          <td className="py-2.5 px-3 font-medium text-gray-900 dark:text-white">
                            {it.product?.title || 'Produit'}
                          </td>
                          <td className="py-2.5 px-3 text-center text-gray-600 dark:text-gray-400">
                            {it.quantity}
                          </td>
                          <td className="py-2.5 px-3 text-right font-bold text-gray-900 dark:text-white">
                            {formatGNF(it.price || it.price_at_purchase || it.product?.price_gnf)}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>

                {/* Total breakdown */}
                <div className="space-y-1.5 pt-2 border-t border-gray-100 dark:border-gray-800 text-xs">
                  <div className="flex justify-between text-gray-500">
                    <span>Frais de livraison</span>
                    <span>
                      {receiptOrder.vendor_delivery_fee
                        ? formatGNF(receiptOrder.vendor_delivery_fee)
                        : 'Inclus'}
                    </span>
                  </div>
                  <div className="flex justify-between text-base font-black text-gray-900 dark:text-white pt-2 border-t border-dashed border-gray-200 dark:border-gray-700">
                    <span>Total Payé</span>
                    <span className="text-[#ff6600]">{formatGNF(receiptOrder.total_amount)}</span>
                  </div>
                </div>

                <div className="pt-2 text-[10px] text-gray-400 text-center leading-relaxed">
                  Merci pour votre confiance sur {APP_NAME}. Pour toute question, contactez notre support client au +224 660 34 58 58.
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex flex-wrap gap-2 pt-6 border-t border-gray-100 dark:border-gray-800 mt-6 no-print">
                <button
                  onClick={() => handleShareReceiptWhatsApp(receiptOrder)}
                  className="flex-1 py-3 px-3 bg-[#25D366] hover:bg-[#20bd5a] text-white rounded-xl text-xs font-bold flex items-center justify-center gap-2 transition-all shadow-sm"
                  title="Partager le reçu sur WhatsApp"
                >
                  <MessageCircle className="w-4 h-4" />
                  <span>WhatsApp</span>
                </button>
                <button
                  onClick={() => window.print()}
                  className="flex-1 py-3 px-3 bg-gray-900 dark:bg-white text-white dark:text-gray-900 rounded-xl text-xs font-bold flex items-center justify-center gap-2 hover:opacity-90 transition-all shadow-sm"
                >
                  <Printer className="w-4 h-4" />
                  <span>Imprimer</span>
                </button>
                <button
                  onClick={() => setReceiptOrder(null)}
                  className="px-4 py-3 border border-gray-200 dark:border-gray-700 text-gray-700 dark:text-gray-300 rounded-xl text-xs font-bold hover:bg-gray-50 dark:hover:bg-gray-800 transition-all"
                >
                  Fermer
                </button>
              </div>

              {/* Print stylesheet */}
              <style dangerouslySetInnerHTML={{ __html: `
                @media print {
                  body * { visibility: hidden !important; }
                  #printable-receipt, #printable-receipt * { visibility: visible !important; }
                  #printable-receipt {
                    position: fixed !important;
                    left: 0 !important;
                    top: 0 !important;
                    width: 100% !important;
                    max-width: 100% !important;
                    margin: 0 !important;
                    padding: 24px !important;
                    background: white !important;
                    color: black !important;
                    box-shadow: none !important;
                    border: none !important;
                  }
                  .no-print, button { display: none !important; }
                }
              `}} />
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Floating Reorder Cart Notification Banner */}
      <AnimatePresence>
        {lastReorderedCount !== null && (
          <motion.div
            initial={{ y: 60, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: 60, opacity: 0 }}
            className="fixed bottom-20 md:bottom-8 left-1/2 -translate-x-1/2 z-40 bg-gray-900 text-white dark:bg-white dark:text-gray-900 px-5 py-3.5 rounded-2xl shadow-2xl flex items-center gap-3 sm:gap-4 border border-gray-700 dark:border-gray-200 max-w-[92vw]"
          >
            <div className="flex items-center gap-2 text-xs font-bold">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
              <span className="truncate">
                {lastReorderedCount} article(s) ajouté(s) à votre panier
              </span>
            </div>
            <Link
              to="/checkout/cart"
              className="px-3.5 py-1.5 rounded-xl bg-[#ff6600] text-white hover:bg-[#e65c00] text-xs font-extrabold flex items-center gap-1.5 transition-all shadow-sm shrink-0 whitespace-nowrap"
            >
              <ShoppingBag className="w-3.5 h-3.5" />
              <span>Voir le panier</span>
              <ArrowRight className="w-3 h-3" />
            </Link>
            <button
              onClick={() => setLastReorderedCount(null)}
              className="p-1 text-gray-400 hover:text-white dark:hover:text-black transition-colors shrink-0"
              title="Fermer"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Review Modal */}
      {reviewOrder && (
        <ReviewModal
          isOpen={!!reviewOrder}
          onClose={() => setReviewOrder(null)}
          productId={reviewOrder.order_items?.[0]?.product_id || ''}
          orderId={reviewOrder.id}
          onSuccess={() => {
            showToast('Avis enregistré avec succès !', 'success');
            setReviewOrder(null);
          }}
        />
      )}

      {/* Courier Rating Modal */}
      {courierRatingOrder && courierRatingOrder.courier_id && (
        <CourierRatingModal
          isOpen={!!courierRatingOrder}
          onClose={() => setCourierRatingOrder(null)}
          orderId={courierRatingOrder.id}
          courierId={courierRatingOrder.courier_id}
          onSuccess={() => {
            showToast('Note du livreur enregistrée !', 'success');
            setCourierRatingOrder(null);
          }}
        />
      )}

      {/* Cancel Order Confirmation Modal */}
      <AnimatePresence>
        {cancelTargetOrder && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in">
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-white dark:bg-gray-900 rounded-3xl max-w-md w-full p-6 border border-gray-200 dark:border-gray-800 shadow-2xl relative text-center"
            >
              <div className="w-14 h-14 rounded-2xl bg-red-100 dark:bg-red-950/60 text-red-600 dark:text-red-400 flex items-center justify-center mx-auto mb-4">
                <AlertCircle className="w-7 h-7" />
              </div>
              <h3 className="text-lg font-bold text-gray-900 dark:text-white mb-2">
                Confirmer l'annulation ?
              </h3>
              <p className="text-xs text-gray-500 dark:text-gray-400 mb-6 leading-relaxed">
                Êtes-vous sûr de vouloir annuler la commande #{cancelTargetOrder.tracking_number || cancelTargetOrder.id.slice(0, 8)} ?
                Le montant sera immédiatement recrédité sur votre portefeuille {APP_NAME}.
              </p>
              <div className="flex gap-3">
                <button
                  onClick={() => setCancelTargetOrder(null)}
                  disabled={isCancelling}
                  className="flex-1 py-3 rounded-xl border border-gray-200 dark:border-gray-700 text-gray-700 dark:text-gray-300 font-bold text-xs hover:bg-gray-50 dark:hover:bg-gray-800 transition-all"
                >
                  Conserver
                </button>
                <button
                  onClick={handleConfirmCancel}
                  disabled={isCancelling}
                  className="flex-1 py-3 rounded-xl bg-red-600 text-white font-bold text-xs hover:bg-red-700 transition-all flex items-center justify-center gap-2 shadow-sm"
                >
                  {isCancelling ? (
                    <RotateCcw className="w-4 h-4 animate-spin" />
                  ) : (
                    'Confirmer l\'annulation'
                  )}
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      <Footer />
    </div>
  );
}
