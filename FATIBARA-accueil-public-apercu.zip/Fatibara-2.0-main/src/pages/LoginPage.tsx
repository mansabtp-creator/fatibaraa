import React, { useState, useEffect } from 'react';
import { useNavigate, useSearchParams, useLocation } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { useToast } from '../context/ToastContext';
import { useAppContext } from '../context/AppContext';
import { ArrowRight, AlertCircle, CheckCircle2, Eye, EyeOff, WifiOff, RefreshCw } from 'lucide-react';
import { loginSchema, registerSchema, forgotPasswordSchema } from '../lib/validations';
import { z } from 'zod';
import { APP_NAME } from '../lib/constants';
import { getRedirectPath } from '../utils/authRedirect';
import { getHomeRouteForRole } from '../utils/routes';
import { getRedirectPathForRole } from '../lib/auth-redirect';

type AuthMode = 'login' | 'signup' | 'forgot_password' | 'success_signup' | 'success_reset';

/* ─── Fatibara Wordmark SVG ──────────────────────────────────────────────── */
function FatibaraLogo({ className = '' }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 120 40"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      aria-label="Fatibara"
    >
      {/* "F" letterform */}
      <rect x="2" y="6" width="3.5" height="28" rx="1.5" fill="#ff6600" />
      <rect x="2" y="6" width="14" height="3.5" rx="1.5" fill="#ff6600" />
      <rect x="2" y="18" width="10" height="3" rx="1.5" fill="#ff6600" />
      {/* Flame accent above F */}
      <path
        d="M7 5.5 C7 3 9.5 1 12 3 C10 1.5 13 0 13 2.5 C13 4.5 11 5.5 9 5.5 Z"
        fill="#ff6600"
        opacity="0.6"
      />
      {/* ATIBARA wordmark */}
      <text
        x="22"
        y="27"
        fontFamily="Inter, system-ui, sans-serif"
        fontWeight="900"
        fontSize="18"
        letterSpacing="-0.5"
        fill="currentColor"
      >
        ATIBARA
      </text>
    </svg>
  );
}

/* ─── Spinner ────────────────────────────────────────────────────────────── */
function Spinner() {
  return (
    <span
      className="inline-block w-5 h-5 rounded-full border-2 border-white/30 border-t-white animate-spin"
      aria-hidden="true"
    />
  );
}

/* ─── Reusable field wrapper ─────────────────────────────────────────────── */
function Field({
  label,
  error,
  action,
  children,
}: {
  label: string;
  error?: string;
  action?: React.ReactNode;
  children: React.ReactNode;
}) {
  return (
    <div className="space-y-1.5">
      <div className="flex items-center justify-between">
        <label className="text-[11px] font-bold tracking-widest text-gray-500 dark:text-gray-400 uppercase">
          {label}
        </label>
        {action}
      </div>
      {children}
      {error && (
        <div className="flex items-center gap-1.5 text-red-500 text-xs font-semibold pt-0.5">
          <AlertCircle className="w-3.5 h-3.5 shrink-0" />
          <span>{error}</span>
        </div>
      )}
    </div>
  );
}

const INPUT_BASE =
  'w-full bg-gray-50 dark:bg-gray-800/60 border border-gray-200 dark:border-gray-700 ' +
  'rounded-xl px-4 py-3.5 text-[14px] font-medium text-gray-900 dark:text-white ' +
  'placeholder:text-gray-400 dark:placeholder:text-gray-500 ' +
  'transition-all duration-200 outline-none ' +
  'focus:ring-2 focus:ring-[#ff6600]/40 focus:border-[#ff6600] ' +
  'disabled:opacity-50 disabled:cursor-not-allowed';

const INPUT_ERROR = 'border-red-400 focus:ring-red-400/30 focus:border-red-400';

/* ════════════════════════════════════════════════════════════════════════════
   LoginPage
   ════════════════════════════════════════════════════════════════════════════ */
export default function LoginPage() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [fullName, setFullName] = useState('');
  const [phone, setPhone] = useState('');
  const [authMode, setAuthMode] = useState<AuthMode>('login');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [networkError, setNetworkError] = useState(false);
  const [lastFormEvent, setLastFormEvent] = useState<React.FormEvent | null>(null);
  const [logoError, setLogoError] = useState(false);
  const [errors, setErrors] = useState<{
    email?: string;
    password?: string;
    confirmPassword?: string;
    full_name?: string;
    phone?: string;
  }>({});

  const { showToast } = useToast();
  const { user, isAuthLoading, isProfileReady, activeRole } = useAppContext();
  const navigate = useNavigate();
  const location = useLocation();
  const [searchParams] = useSearchParams();
  const rawRedirect = searchParams.get('redirect');
  const redirect = rawRedirect && 
    rawRedirect.startsWith('/') && 
    !rawRedirect.startsWith('//') && 
    !rawRedirect.startsWith('/login')
      ? rawRedirect
      : null;

  // ── Handle OAuth Errors in URL query/hash ────────────────────────────────
  useEffect(() => {
    const hashParams = new URLSearchParams(window.location.hash.replace(/^#/, ''));
    const errorParam = searchParams.get('error') || hashParams.get('error');
    const errorDesc = searchParams.get('error_description') || hashParams.get('error_description');
    const errorCode = searchParams.get('error_code') || hashParams.get('error_code');

    if (errorParam || errorDesc || errorCode) {
      console.warn('[LoginPage] OAuth callback error detected:', { errorParam, errorDesc, errorCode });
      const message = errorDesc
        ? decodeURIComponent(errorDesc.replace(/\+/g, ' '))
        : errorCode === '403' || errorParam === 'access_denied'
        ? 'Connexion Google non autorisée (403). Veuillez vérifier les identifiants ou utiliser email/mot de passe.'
        : 'Erreur lors de la connexion via Google.';
      showToast(message, 'error');
    }
  }, [searchParams, showToast]);

  // ── Authenticated visitor guard ─────────────────────────────────────────
  // When an already-authenticated user lands on /login AND the profile has
  // fully settled (isProfileReady), forward them immediately to their home
  // route. We wait for isProfileReady — not just isAuthLoading — to ensure
  // the activeRole is populated before we read it.
  useEffect(() => {
    if (
      !isAuthLoading &&
      isProfileReady &&
      user &&
      authMode !== 'success_signup' &&
      authMode !== 'success_reset'
    ) {
      // If a safe redirect param exists, honour it; otherwise use the
      // canonical role-based home derived from the centralized map.
      const safeRedirect = redirect || getRedirectPathForRole(activeRole);
      navigate(safeRedirect, { replace: true });
    }
  }, [user, isAuthLoading, isProfileReady, activeRole, authMode, redirect, navigate]);

  /* ── Validation ────────────────────────────────────────────────────────── */
  const validateForm = () => {
    try {
      if (authMode === 'login') {
        loginSchema.parse({ email, password });
      } else if (authMode === 'signup') {
        registerSchema.parse({ email, password, full_name: fullName, confirmPassword, phone });
      } else if (authMode === 'forgot_password') {
        forgotPasswordSchema.parse({ email });
      }
      setErrors({});
      return true;
    } catch (err) {
      if (err instanceof z.ZodError) {
        const fieldErrors: { [key: string]: string } = {};
        err.issues.forEach(e => {
          if (e.path[0]) fieldErrors[e.path[0] as string] = e.message;
        });
        setErrors(fieldErrors);
      }
      return false;
    }
  };

  const isNetworkError = (error: any): boolean => {
    if (error instanceof TypeError && error.message?.toLowerCase().includes('fetch')) return true;
    const msg = error.message?.toLowerCase() || '';
    if (msg.includes('network') || msg.includes('err_network') || msg.includes('err_name_not_resolved')) return true;
    return false;
  };

  const mapSupabaseError = (error: any) => {
    const msg = error.message?.toLowerCase() || '';
    if (msg.includes('invalid login credentials')) return 'Email ou mot de passe incorrect.';
    if (msg.includes('user already registered')) return 'Cet email est déjà utilisé.';
    if (msg.includes('rate limit')) return 'Trop de tentatives. Veuillez réessayer plus tard.';
    return error.message || 'Une erreur est survenue.';
  };

  /* ── Auth handler ──────────────────────────────────────────────────────── */
  const handleAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validateForm()) return;

    setNetworkError(false);
    setLastFormEvent(e);
    setLoading(true);
    try {
      if (authMode === 'login') {
        const {
          data: { user: authUser },
          error,
        } = await supabase.auth.signInWithPassword({ email, password });
        if (error) throw error;

        // ── Post-login redirect ─────────────────────────────────────────────
        // DO NOT navigate here. The useEffect watching [isProfileReady, activeRole]
        // is the single source of truth for post-login navigation. It correctly
        // waits for fetchProfile() to complete before reading activeRole.
        //
        // Navigating here would race with fetchProfile (which can take up to
        // 2.4 s) and consistently land vendors on '/' instead of their dashboard.
        //
        // Exception: honour an explicit ?redirect= param or a meaningful deep-link
        // (but NOT '/' — that's the default and would override role-based routing).
        const from = (location.state as any)?.from;
        const safeRedirect = redirect && redirect.startsWith('/') && !redirect.startsWith('//') ? redirect : null;
        if (safeRedirect) {
          navigate(safeRedirect, { replace: true });
        } else if (from?.pathname && from.pathname !== '/login' && from.pathname !== '/') {
          navigate(from.pathname + (from.search || '') + (from.hash || ''), { replace: true });
        }
        // else: do nothing — let the useEffect handle role-based redirect
      } else if (authMode === 'signup') {
        const { data, error } = await supabase.auth.signUp({
          email,
          password,
          options: { data: { full_name: fullName, phone: phone || null } },
        });
        if (error) throw error;

        if (data.session) {
          const from = (location.state as any)?.from;
          const safeRedirect = redirect && redirect.startsWith('/') && !redirect.startsWith('//') ? redirect : null;
          if (safeRedirect) {
            navigate(safeRedirect, { replace: true });
          } else if (from?.pathname && from.pathname !== '/login' && from.pathname !== '/') {
            navigate(from.pathname + (from.search || '') + (from.hash || ''), { replace: true });
          }
          // else: let the useEffect handle role-based redirect
        } else {
          setAuthMode('success_signup');
        }
      } else if (authMode === 'forgot_password') {
        const { error } = await supabase.auth.resetPasswordForEmail(email, {
          redirectTo: window.location.origin + '/reset-password',
        });
        if (error) throw error;
        setAuthMode('success_reset');
      }
    } catch (error: any) {
      if (isNetworkError(error)) {
        setNetworkError(true);
      } else {
        showToast(mapSupabaseError(error), 'error');
      }
    } finally {
      setLoading(false);
    }
  };

  const handleRetry = () => {
    if (lastFormEvent) handleAuth(lastFormEvent);
  };

  // checkRoleAndRedirect removed — post-login role-based navigation is now
  // handled exclusively by the useEffect that watches [isProfileReady, activeRole].
  // This eliminates the race condition where the redirect fired before
  // fetchProfile() had a chance to set activeRole, landing vendors on '/'.

  const handleGoogle = async () => {
    try {
      setLoading(true);
      // Construct a clean, canonical origin-based redirect URL
      // If a valid redirect target exists (e.g. /vendor/dashboard or /checkout), append it
      const targetPath = redirect ? redirect : '/';
      const callbackUrl = `${window.location.origin}${targetPath === '/' ? '' : targetPath}`;

      const { error } = await supabase.auth.signInWithOAuth({
        provider: 'google',
        options: {
          redirectTo: callbackUrl,
          queryParams: {
            access_type: 'offline',
            prompt: 'consent',
          },
        },
      });
      if (error) throw error;
    } catch (error: any) {
      console.error('Google OAuth error:', error);
      showToast(error.message || 'Échec de la connexion avec Google.', 'error');
    } finally {
      setLoading(false);
    }
  };

  const switchMode = (next: AuthMode) => {
    setAuthMode(next);
    setErrors({});
  };

  /* ── Success screens ───────────────────────────────────────────────────── */
  if (authMode === 'success_signup' || authMode === 'success_reset') {
    return (
      <PageShell>
        <Card>
          <div className="text-center py-4">
            <div className="w-16 h-16 bg-[#ff6600]/10 rounded-2xl flex items-center justify-center mx-auto mb-6">
              <CheckCircle2 className="w-8 h-8 text-[#ff6600]" />
            </div>
            <h2 className="text-2xl font-bold text-gray-900 dark:text-white tracking-tight mb-3">
              {authMode === 'success_signup' ? 'Vérifiez votre email' : 'Email envoyé'}
            </h2>
            <p className="text-gray-500 dark:text-gray-400 text-sm leading-relaxed mb-8 max-w-xs mx-auto">
              {authMode === 'success_signup'
                ? 'Un lien de confirmation vous a été envoyé. Cliquez dessus pour activer votre compte.'
                : 'Un lien pour réinitialiser votre mot de passe vous a été envoyé.'}
            </p>
            <PrimaryButton onClick={() => setAuthMode('login')}>
              Retour à la connexion
            </PrimaryButton>
          </div>
        </Card>
      </PageShell>
    );
  }

  /* ── Password strength indicator ──────────────────────────────────────── */
  const getStrength = () => {
    if (password.length === 0) return 0;
    let score = 0;
    if (password.length >= 8) score++;
    if (/[A-Z]/.test(password)) score++;
    if (/[0-9]/.test(password)) score++;
    if (/[^A-Za-z0-9]/.test(password)) score++;
    return score;
  };
  const strength = getStrength();
  const strengthColor = ['bg-gray-200', 'bg-red-400', 'bg-yellow-400', 'bg-blue-400', 'bg-green-500'][strength];

  const modeLabel = {
    login: 'Bon Retour',
    signup: 'Bienvenue',
    forgot_password: 'Mot de passe oublié',
  }[authMode as 'login' | 'signup' | 'forgot_password'];

  const modeSubtitle = {
    login: `Accédez à votre espace ${APP_NAME}`,
    signup: 'Rejoignez la communauté',
    forgot_password: 'Réinitialisez votre accès',
  }[authMode as 'login' | 'signup' | 'forgot_password'];

  /* ── Main render ───────────────────────────────────────────────────────── */
  return (
    <PageShell>
      <Card>
        {/* ── Header ── */}
        <div className="mb-9 text-center">
          {/* Official Fatibara logo */}
          <div className="flex items-center justify-center mb-6">
            {logoError ? (
              <span className="text-3xl font-black tracking-tight text-gray-900 dark:text-white flex items-center gap-2">
                <span className="w-10 h-10 rounded-2xl bg-[#ff6600] flex items-center justify-center text-white text-base font-black shadow-md">F</span>
                <span className="text-gray-900 dark:text-white font-black">{APP_NAME}</span>
              </span>
            ) : (
              <img
                src="https://miizhdzuxidilrzwdivk.supabase.co/storage/v1/object/public/assets/fatibara_logo-removebg-preview.png"
                alt={APP_NAME}
                className="h-12 w-auto object-contain max-w-[200px]"
                draggable={false}
                onError={() => setLogoError(true)}
              />
            )}
          </div>

          <h1 className="text-[28px] font-black text-gray-900 dark:text-white tracking-tight leading-tight">
            {modeLabel}
          </h1>
          <p className="text-[13px] text-gray-500 dark:text-gray-400 font-medium mt-1.5">
            {modeSubtitle}
          </p>
        </div>

        {/* ── Network error banner ── */}
        {networkError && (
          <div className="mb-5 flex flex-col items-center gap-3 bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-700/50 rounded-2xl px-4 py-4 text-center">
            <WifiOff className="w-6 h-6 text-amber-500 shrink-0" />
            <div>
              <p className="text-[13px] font-bold text-amber-800 dark:text-amber-300">Connexion impossible</p>
              <p className="text-[12px] text-amber-600 dark:text-amber-400 mt-0.5 leading-relaxed">
                Vérifiez votre connexion Internet et réessayez.
              </p>
            </div>
            <button
              type="button"
              onClick={handleRetry}
              disabled={loading}
              className="flex items-center gap-2 bg-amber-500 hover:bg-amber-600 text-white text-[12px] font-bold rounded-lg px-4 py-2 transition-all active:scale-[0.97] disabled:opacity-60"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              Réessayer
            </button>
          </div>
        )}

        {/* ── Form ── */}
        <form onSubmit={handleAuth} className="space-y-4" noValidate>
          {/* Full name — signup only */}
          {authMode === 'signup' && (
            <Field label="Nom complet" error={errors.full_name}>
              <input
                type="text"
                placeholder="Mamadou Diallo"
                value={fullName}
                disabled={loading}
                autoComplete="name"
                onChange={e => {
                  setFullName(e.target.value);
                  if (errors.full_name) setErrors({ ...errors, full_name: undefined });
                }}
                className={`${INPUT_BASE} ${errors.full_name ? INPUT_ERROR : ''}`}
              />
            </Field>
          )}

          {/* Email */}
          <Field label="Email" error={errors.email}>
            <input
              type="email"
              placeholder="votre@email.com"
              value={email}
              disabled={loading}
              autoComplete="email"
              onChange={e => {
                setEmail(e.target.value);
                if (errors.email) setErrors({ ...errors, email: undefined });
              }}
              className={`${INPUT_BASE} ${errors.email ? INPUT_ERROR : ''}`}
            />
          </Field>

          {/* Phone — signup only */}
          {authMode === 'signup' && (
            <Field label="Téléphone (optionnel)" error={errors.phone}>
              <input
                type="tel"
                placeholder="620 00 00 00"
                value={phone}
                disabled={loading}
                autoComplete="tel"
                onChange={e => {
                  setPhone(e.target.value);
                  if (errors.phone) setErrors({ ...errors, phone: undefined });
                }}
                className={`${INPUT_BASE} ${errors.phone ? INPUT_ERROR : ''}`}
              />
            </Field>
          )}

          {/* Password */}
          {authMode !== 'forgot_password' && (
            <Field
              label="Mot de passe"
              error={errors.password}
              action={
                authMode === 'login' ? (
                  <button
                    type="button"
                    onClick={() => switchMode('forgot_password')}
                    className="text-[11px] font-bold text-[#ff6600] hover:text-[#e62e00] transition-colors tracking-wide"
                  >
                    Oublié ?
                  </button>
                ) : undefined
              }
            >
              <div className="relative">
                <input
                  type={showPassword ? 'text' : 'password'}
                  placeholder="••••••••"
                  value={password}
                  disabled={loading}
                  autoComplete={authMode === 'login' ? 'current-password' : 'new-password'}
                  onChange={e => {
                    setPassword(e.target.value);
                    if (errors.password) setErrors({ ...errors, password: undefined });
                  }}
                  className={`${INPUT_BASE} pr-11 ${errors.password ? INPUT_ERROR : ''}`}
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(v => !v)}
                  className="absolute right-3.5 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600 dark:hover:text-gray-300 transition-colors focus:outline-none"
                  aria-label={showPassword ? 'Masquer le mot de passe' : 'Afficher le mot de passe'}
                >
                  {showPassword ? <EyeOff className="w-4.5 h-4.5" /> : <Eye className="w-4.5 h-4.5" />}
                </button>
              </div>

              {/* Password strength bar — signup only */}
              {authMode === 'signup' && password.length > 0 && (
                <div className="flex gap-1 mt-2">
                  {[1, 2, 3, 4].map(lvl => (
                    <div
                      key={lvl}
                      className={`h-1 flex-1 rounded-full transition-all duration-300 ${
                        strength >= lvl ? strengthColor : 'bg-gray-200 dark:bg-gray-700'
                      }`}
                    />
                  ))}
                </div>
              )}
            </Field>
          )}

          {/* Confirm password — signup only */}
          {authMode === 'signup' && (
            <Field label="Confirmer le mot de passe" error={errors.confirmPassword}>
              <div className="relative">
                <input
                  type={showPassword ? 'text' : 'password'}
                  placeholder="••••••••"
                  value={confirmPassword}
                  disabled={loading}
                  autoComplete="new-password"
                  onChange={e => {
                    setConfirmPassword(e.target.value);
                    if (errors.confirmPassword) setErrors({ ...errors, confirmPassword: undefined });
                  }}
                  className={`${INPUT_BASE} pr-11 ${errors.confirmPassword ? INPUT_ERROR : ''}`}
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(v => !v)}
                  className="absolute right-3.5 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600 dark:hover:text-gray-300 transition-colors focus:outline-none"
                  aria-label={showPassword ? 'Masquer le mot de passe' : 'Afficher le mot de passe'}
                >
                  {showPassword ? <EyeOff className="w-4.5 h-4.5" /> : <Eye className="w-4.5 h-4.5" />}
                </button>
              </div>
            </Field>
          )}

          {/* ── Submit button ── */}
          <div className="pt-2">
            <button
              type="submit"
              disabled={loading}
              className={`
                w-full flex items-center justify-center gap-2.5
                bg-[#ff6600] hover:bg-[#e62e00]
                text-white font-bold text-[14px] tracking-wide
                rounded-xl py-3.5
                shadow-lg shadow-[#ff6600]/25 hover:shadow-[#e62e00]/30
                transition-all duration-200 active:scale-[0.98]
                disabled:opacity-60 disabled:cursor-not-allowed disabled:active:scale-100
              `}
            >
              {loading ? (
                <>
                  <Spinner />
                  <span className="opacity-80">Traitement en cours…</span>
                </>
              ) : (
                <>
                  <span>
                    {authMode === 'login'
                      ? 'Se connecter'
                      : authMode === 'signup'
                      ? 'Créer mon compte'
                      : 'Envoyer le lien'}
                  </span>
                  <ArrowRight className="w-4 h-4" />
                </>
              )}
            </button>
          </div>
        </form>

        {/* ── Social / divider ── */}
        {authMode !== 'forgot_password' && (
          <>
            <div className="mt-7 flex items-center gap-4">
              <div className="h-px bg-gray-200 dark:bg-gray-700 flex-1" />
              <span className="text-[11px] font-semibold text-gray-400 dark:text-gray-500 uppercase tracking-widest">
                ou
              </span>
              <div className="h-px bg-gray-200 dark:bg-gray-700 flex-1" />
            </div>

            <button
              onClick={handleGoogle}
              type="button"
              disabled={loading}
              className="mt-5 w-full flex items-center justify-center gap-3 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl py-3.5 text-[13px] font-semibold text-gray-700 dark:text-gray-200 hover:bg-gray-50 dark:hover:bg-gray-700/70 active:scale-[0.98] transition-all disabled:opacity-50"
            >
              <svg className="w-[18px] h-[18px]" viewBox="0 0 24 24" aria-hidden="true">
                <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
                <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
                <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" />
                <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" />
              </svg>
              Continuer avec Google
            </button>
          </>
        )}

        {/* ── Mode switcher ── */}
        <div className="mt-7 pt-6 border-t border-gray-100 dark:border-gray-800 text-center">
          {authMode === 'forgot_password' ? (
            <button
              onClick={() => switchMode('login')}
              className="text-[13px] font-semibold text-[#ff6600] hover:text-[#e62e00] transition-colors"
            >
              ← Retour à la connexion
            </button>
          ) : (
            <p className="text-[13px] text-gray-500 dark:text-gray-400">
              {authMode === 'login' ? "Pas encore de compte ? " : 'Déjà membre ? '}
              <button
                onClick={() => switchMode(authMode === 'login' ? 'signup' : 'login')}
                className="font-bold text-[#ff6600] hover:text-[#e62e00] transition-colors"
              >
                {authMode === 'login' ? "S'inscrire" : 'Se connecter'}
              </button>
            </p>
          )}
        </div>
      </Card>
    </PageShell>
  );
}

/* ─── Layout primitives ──────────────────────────────────────────────────── */

function PageShell({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-screen bg-gray-50 dark:bg-[#0f0f0f] flex items-center justify-center p-5">
      {/* Subtle ambient glow */}
      <div
        className="pointer-events-none fixed inset-0 opacity-[0.04] dark:opacity-[0.07]"
        style={{
          background:
            'radial-gradient(ellipse 60% 50% at 50% 0%, #ff6600 0%, transparent 70%)',
        }}
        aria-hidden="true"
      />
      {children}
    </div>
  );
}

function Card({ children }: { children: React.ReactNode }) {
  return (
    <div className="relative w-full max-w-[420px] bg-white dark:bg-[#1a1a1a] rounded-3xl border border-gray-200/80 dark:border-gray-800 shadow-xl shadow-gray-900/5 dark:shadow-black/40 p-8 md:p-10">
      {/* Top-edge brand line */}
      <div className="absolute inset-x-0 top-0 h-[3px] rounded-t-3xl bg-gradient-to-r from-[#ff6600] via-[#ff9933] to-[#e62e00]" />
      {children}
    </div>
  );
}

function PrimaryButton({
  onClick,
  children,
}: {
  onClick?: () => void;
  children: React.ReactNode;
}) {
  return (
    <button
      onClick={onClick}
      className="w-full bg-[#ff6600] hover:bg-[#e62e00] text-white font-bold text-[14px] rounded-xl py-3.5 shadow-lg shadow-[#ff6600]/25 transition-all duration-200 active:scale-[0.98]"
    >
      {children}
    </button>
  );
}
