import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import Header from '../components/Header';
import Footer from '../components/Footer';
import ProductGrid from '../components/ProductGrid';
import ProductReviews from '../components/ProductReviews';
import ProductCard from '../components/ProductCard';
import { Store, MapPin, ShieldCheck, MessageCircle, Share2, Info, ShoppingBag, Clock, Heart, Star, Flag, CheckCircle2 } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import SEO from '../components/SEO';
import { useAppContext } from '../context/AppContext';
import { useStore } from '../store/useStore';
import { useToast } from '../context/ToastContext';
import { APP_NAME } from '../lib/constants';
import { friendlyError } from '../lib/utils';
import ReportModal from '../components/ReportModal';
import StoreAreaOfOperation from '../components/StoreAreaOfOperation';

export default function StoreProfilePage() {
  const { storeName } = useParams();
  const [showReport, setShowReport] = useState(false);
  const { user, followedVendors, toggleFollowVendor, openChat } = useAppContext();
  const { isDarkMode } = useStore();
  const { showToast } = useToast();
  const [store, setStore] = useState<any>(null);
  const [featuredProducts, setFeaturedProducts] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [fetchError, setFetchError] = useState<string | null>(null);

  useEffect(() => {
    window.scrollTo(0, 0);
    async function fetchStore() {
      try {
        setLoading(true);
        setFetchError(null);
        
        const rawStoreName = storeName || '';
        const decodedStoreName = decodeURIComponent(rawStoreName).trim().replace(/\+/g, ' ');
        
        console.log(`[StoreProfile] Searching for: "${decodedStoreName}" (raw: "${rawStoreName}")`);
        
        // 1. Exact or case-insensitive match (The standard)
        let { data, error } = await supabase
          .from('stores')
          .select('*')
          .ilike('store_name', decodedStoreName)
          .maybeSingle();
        
        if (error) {
          console.warn("[StoreProfile] Exact match error:", error);
        }

        // 2. Try common URL transformations if not found
        if (!data) {
          const variations = [
            decodedStoreName.replace(/-/g, ' '),     // electro-store -> electro store
            decodedStoreName.replace(/ /g, '-'),     // electro store -> electro-store
            decodedStoreName.replace(/_/g, ' '),     // electro_store -> electro store
          ];
          
          for (const variant of variations) {
            if (variant === decodedStoreName) continue;
            const { data: vData } = await supabase
              .from('stores')
              .select('*')
              .ilike('store_name', variant)
              .maybeSingle();
            
            if (vData) {
              console.log(`[StoreProfile] Found via variant: "${variant}"`);
              data = vData;
              break;
            }
          }
        }

        // 3. Loose match (alphanumeric only)
        if (!data) {
          const cleanName = decodedStoreName.replace(/[^a-zA-Z0-9]/g, '');
          if (cleanName.length > 2) {
             const { data: looseData } = await supabase
                .from('stores')
                .select('*')
                .ilike('store_name', `%${cleanName}%`)
                .limit(1)
                .maybeSingle();
             
             if (looseData) {
                console.log(`[StoreProfile] Found via loose match: "${cleanName}"`);
                data = looseData;
             }
          }
        }

        // 4. UUID / ID check
        if (!data && decodedStoreName.match(/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i)) {
          const { data: idData } = await supabase
            .from('stores')
            .select('*')
            .eq('id', decodedStoreName)
            .maybeSingle();
          if (idData) {
            console.log(`[StoreProfile] Found via ID match`);
            data = idData;
          }
        }
        
        if (!data) {
          throw new Error("Boutique introuvable");
        }
        
        setStore(data);
        
        const { data: featured, error: featuredErr } = await supabase
          .from('products')
          .select('*, store:stores(id, store_name, is_verified_store, avatar_url, reviews_count, rating)')
          .eq('store_id', data.id)
          .eq('is_featured', true)
          .limit(8);

        if (!featuredErr && featured) {
          setFeaturedProducts(featured);
        }
        
      } catch (err: any) {
        console.error("Error fetching store:", err);
        setFetchError(friendlyError(err));
      } finally {
        setLoading(false);
      }
    }
    if (storeName) fetchStore();
  }, [storeName]);

  const isFollowed = store && followedVendors.includes(store.id);

  if (loading) {
    return (
      <div className="min-h-screen flex flex-col bg-gray-50 dark:bg-gray-800">
        <Header />
        <main className="flex-grow flex items-center justify-center">
          <div className="animate-pulse text-gray-900 dark:text-white/50 font-bold uppercase tracking-[0.2em] text-xs">Ouverture de la boutique...</div>
        </main>
        <Footer />
      </div>
    );
  }

  if (fetchError || !store || store.store_status === 'suspended') {
    return (
      <div className="min-h-screen flex flex-col bg-gray-50 dark:bg-gray-800">
        <Header />
        <main className="flex-grow flex flex-col items-center justify-center p-10 text-center">
          <div className="bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-700 shadow-sm p-12 flex flex-col items-center max-w-lg rounded-3xl">
            <div className="w-24 h-24 bg-[#e62e00] border border-gray-200 dark:border-gray-700 flex items-center justify-center mb-6 shadow-sm rounded-2xl">
              <ShieldCheck className="w-10 h-10 text-white" />
            </div>
            <h2 className="text-3xl font-black text-gray-900 dark:text-white mb-4 tracking-tight">{store?.store_status === 'suspended' ? 'Boutique Suspendue' : 'Boutique Introuvable'}</h2>
            <p className="text-gray-500 dark:text-gray-400 font-semibold mb-8 tracking-wide text-[14px]">
              {store?.store_status === 'suspended' 
                ? "Cette boutique a été temporairement suspendue par l'administration du marché. Veuillez revenir plus tard ou explorer d'autres boutiques."
                : (fetchError || `Désolé, nous ne parvenons pas à trouver la boutique "${storeName}". Elle a peut-être changé de nom ou fermé.`)}
            </p>
            <Link to="/" className="inline-block bg-[#ff6600] text-white px-10 py-4 font-bold tracking-widest uppercase text-[13px] hover:bg-[#e62e00] rounded-xl shadow-sm hover:shadow-sm transition-all">Retour à l'accueil</Link>
          </div>
        </main>
      <Footer />
    </div>
  );
}

  return (
    <div className="min-h-screen flex flex-col bg-gray-50 dark:bg-gray-800">
      <SEO 
        title={`${store.store_name} | La Boutique Officielle on ${APP_NAME}`} 
        description={store.description || `Découvrez les produits de ${store.store_name} sur ${APP_NAME} Guinée. Achat en ligne, livraison Conakry.`}
        image={store.avatar_url}
        url={`https://www.fatibara.com/boutique/${encodeURIComponent(store.store_name)}`}
        type="website"
        keywords={`${store.store_name}, boutique Guinée, ${APP_NAME}, achat en ligne Conakry`}
      />
      <Header />
      
      <main className="flex-grow">
        {/* Banner Section */}
        <div className="relative h-32 md:h-[350px] w-full overflow-hidden border-b border-gray-200 dark:border-gray-700">
           {store.banner_url ? (
             <img src={store.banner_url} alt="Banner" className="w-full h-full object-cover" />
           ) : (
             <div className="w-full h-full bg-gray-900" />
           )}
           <div className="absolute inset-0 bg-black/40 mix-blend-multiply pointer-events-none" />
           
           <div className="absolute bottom-4 left-4 md:bottom-12 md:left-12 right-4 md:right-12">
              <div className="max-w-7xl mx-auto flex items-end gap-3 md:gap-6">
                 {/* Avatar */}
                 <div className="w-20 h-20 md:w-32 md:h-32 bg-white dark:bg-gray-900 border-4 border-white shadow-lg rounded-3xl relative overflow-hidden group">
                    {(isDarkMode && store.logo_dark_url) || store.avatar_url ? (
                      <img src={(isDarkMode && store.logo_dark_url) ? store.logo_dark_url : store.avatar_url} alt="Logo" className="w-full h-full object-cover" />
                    ) : (
                      <div className="w-full h-full bg-orange-50 flex items-center justify-center">
                         <Store className="w-8 h-8 md:w-12 md:h-12 text-[#ff6600]" />
                      </div>
                    )}
                 </div>

                 {/* Identity - Compact */}
                 <div className="flex-1 mb-2 md:mb-5 flex flex-wrap items-center gap-3">
                    <div className="bg-white dark:bg-gray-900/90 backdrop-blur-sm px-5 py-2.5 rounded-2xl shadow-sm inline-block w-max">
                       <h1 className="text-xl md:text-3xl font-black text-gray-900 dark:text-white tracking-tight uppercase flex items-center gap-2">
                         {store.store_name}
                         {store.is_verified_store && <ShieldCheck className="w-5 h-5 text-[#16a34a]" />}
                       </h1>
                    </div>
                    
                    <button 
                      onClick={() => toggleFollowVendor(store.id)}
                      className={`px-6 py-2.5 rounded-2xl text-[11px] font-black tracking-widest uppercase transition-all shadow-lg active:scale-95 ${
                        isFollowed 
                          ? 'bg-gray-100 text-gray-600 border border-gray-200' 
                          : 'bg-[#ff6600] text-white hover:bg-[#e62e00] shadow-[#ff6600]/20'
                      }`}
                    >
                      {isFollowed ? 'ABONNÉ' : 'S\'ABONNER'}
                    </button>
                 </div>
              </div>
           </div>
        </div>

        {/* Content Section */}
        <div className="max-w-7xl mx-auto px-4 md:px-10 py-12 md:py-16">
           <div className="grid grid-cols-1 lg:grid-cols-4 gap-12">
              {/* Sidebar Info */}
              <div className="lg:col-span-1 space-y-8">
                 <div className="bg-white dark:bg-gray-900 p-8 border border-gray-200 dark:border-gray-700 shadow-sm relative overflow-hidden group rounded-3xl">
                    <h3 className="text-[15px] font-black uppercase text-gray-900 dark:text-white tracking-wider mb-6 flex items-center gap-2 relative z-10">
                       <Info className="w-5 h-5 text-[#ff6600]" /> À propos
                    </h3>
                    <p className="text-[14px] text-gray-600 font-semibold leading-[1.6] mb-8 relative z-10">
                       {/* Styled description: parse hyphen-prefixed lines into feature items */}
                     {(() => {
                       const desc = store.description || `Bienvenue dans notre boutique officielle sur ${APP_NAME}. Nous nous engageons à vous fournir les meilleurs produits de qualité en Guinée.`;
                       const lines = desc.split('\n').map((l: string) => l.trim()).filter(Boolean);
                       const intro = lines.filter((l: string) => !l.startsWith('-'));
                       const bullets = lines.filter((l: string) => l.startsWith('-')).map((l: string) => l.replace(/^-\s*/, ''));
                       return (
                         <div className="space-y-4">
                           {intro.map((line: string, i: number) => (
                             <p key={i} className="text-[14px] text-gray-600 dark:text-gray-400 font-medium leading-relaxed">{line}</p>
                           ))}
                           {bullets.length > 0 && (
                             <ul className="space-y-2.5">
                               {bullets.map((b: string, i: number) => (
                                 <li key={i} className="flex items-start gap-3">
                                   <div className="w-5 h-5 bg-[#ff6600]/10 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                                     <CheckCircle2 className="w-3 h-3 text-[#ff6600]" />
                                   </div>
                                   <span className="text-[13px] font-semibold text-gray-700 dark:text-gray-300 leading-snug">{b}</span>
                                 </li>
                               ))}
                             </ul>
                           )}
                         </div>
                       );
                     })()}
                    </p>
                    
                    <div className="space-y-4 pt-6 border-t border-gray-200 dark:border-gray-700 border-dashed relative z-10">
                       <div className="flex items-center justify-between">
                          <span className="text-[13px] font-bold text-gray-500 dark:text-gray-400 tracking-wider">Statut</span>
                          <span className={`text-[11px] font-bold tracking-wider px-3 py-1 rounded-md ${store.is_open ? 'bg-green-100 text-[#16a34a]' : 'bg-red-100 text-[#e62e00]'}`}>
                             {store.is_open ? 'Ouvert' : 'Fermé'}
                          </span>
                       </div>
                       <div className="flex items-center justify-between">
                          <span className="text-[13px] font-bold text-gray-500 dark:text-gray-400 tracking-wider">Ancienneté</span>
                          <span className="text-[13px] font-bold text-gray-900 dark:text-white tracking-wider">{new Date(store.created_at).toLocaleDateString('fr-FR', { year: 'numeric', month: 'short' })}</span>
                       </div>
                       {store.rating > 0 && (
                         <div className="flex items-center justify-between">
                            <span className="text-[13px] font-bold text-gray-500 dark:text-gray-400 tracking-wider">Score</span>
                            <span className="flex items-center gap-1 text-[13px] font-bold text-yellow-500 tracking-wider bg-yellow-50 rounded-md px-2 py-0.5">
                               {store.rating.toFixed(1)} <Star className="w-3.5 h-3.5 fill-yellow-500 text-yellow-500" />
                            </span>
                         </div>
                       )}
                    </div>
                 </div>
                 
                  <div className="bg-white dark:bg-gray-900 p-8 border border-gray-200 dark:border-gray-700 shadow-sm relative overflow-hidden rounded-3xl">
                    <StoreAreaOfOperation commune={store.location_commune} />
                  </div>

                 <div className="bg-gray-900 p-8 text-white shadow-xl relative overflow-hidden group rounded-3xl">
                    <div className="absolute top-0 right-0 w-32 h-32 bg-[#ff6600]/20 rounded-full blur-3xl" />
                    <h3 className="text-[18px] font-black mb-4 flex items-center gap-3 relative z-10 tracking-tight">
                       <MessageCircle className="w-6 h-6 text-[#ff6600]" /> Service Client
                    </h3>
                    <p className="text-[13px] font-medium tracking-wide text-gray-300 mb-8 leading-relaxed relative z-10">Une question ? Chattez en direct avec l'équipe de {store.store_name}.</p>
                    <button 
                      onClick={() => {
                        if (!user) {
                          showToast("Veuillez vous connecter pour envoyer un message.", 'warning');
                          return;
                        }
                        openChat(store.id);
                      }}
                      className="w-full bg-[#ff6600] text-white py-4 font-bold tracking-wider uppercase text-[12px] flex items-center justify-center gap-3 rounded-xl hover:bg-[#e62e00] transition-all relative z-10 shadow-lg shadow-[#ff6600]/20 active:scale-95"
                    >
                       Menssagerie <Share2 className="w-4 h-4" />
                    </button>
                    <button
                       onClick={() => setShowReport(true)}
                       className="w-full mt-3 py-2.5 text-[11px] font-bold text-gray-400 hover:text-red-500 flex items-center justify-center gap-1.5 transition-colors relative z-10"
                     >
                       <Flag className="w-3.5 h-3.5" /> Signaler cette boutique
                     </button>
                 </div>
              </div>

              {/* Product Grid - Full span on mobile, 3/4 on desktop */}
              <div className="col-span-1 lg:col-span-3">
                 {!store.is_open && (
                   <div className="mb-10 bg-orange-50 text-orange-900 border border-orange-200 p-8 flex flex-col md:flex-row items-center gap-6 rounded-3xl shadow-sm text-center md:text-left">
                      <Clock className="w-12 h-12 text-[#ff6600] shrink-0 animate-bounce" />
                      <div>
                         <h4 className="font-black tracking-tight text-lg md:text-xl mb-1 text-[#ff6600] uppercase">Actuellement en Pause</h4>
                         <p className="text-[13px] font-medium tracking-wide leading-relaxed">Cette boutique est en mode vacances. Vous pouvez parcourir les articles mais les achats sont temporairement désactivés.</p>
                      </div>
                   </div>
                 )}

                 {featuredProducts.length > 0 && (
                    <div className="mb-16">
                      <div className="flex flex-col md:flex-row items-center justify-between gap-4 mb-8 pb-4 border-b border-gray-200 dark:border-gray-700">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 bg-orange-100 flex items-center justify-center rounded-xl">
                             <Star className="w-5 h-5 text-[#ff6600]" />
                          </div>
                          <h2 className="text-2xl md:text-3xl font-black text-gray-900 dark:text-white tracking-tight uppercase">Produits Phares</h2>
                        </div>
                      </div>
                      <div className="flex gap-4 overflow-x-auto pb-6 scrollbar-hide no-scrollbar -mx-4 px-4 md:mx-0 md:px-0">
                        {featuredProducts.map((product, idx) => (
                          <div key={product.id} className="min-w-[280px] sm:min-w-[320px] shrink-0">
                            <ProductCard 
                              product={product} 
                              index={idx}
                              onShare={() => {}}
                              onQuickView={() => {}}
                            />
                          </div>
                        ))}
                      </div>
                    </div>
                 )}

                 <div className="flex flex-col md:flex-row items-center justify-between gap-4 mb-10 pb-4 border-b border-gray-200 dark:border-gray-700">
                    <h2 className="text-2xl md:text-3xl font-black text-gray-900 dark:text-white tracking-tight uppercase">Collection de Produits</h2>
                    <div className="flex items-center gap-2 bg-green-50 border border-green-200 rounded-lg px-4 py-2">
                       <span className="w-2.5 h-2.5 rounded-full bg-[#16a34a] animate-pulse" />
                       <span className="text-[11px] font-black uppercase tracking-widest text-[#16a34a]">Actualisé</span>
                    </div>
                 </div>
                 
                 <div className="relative">
                   <ProductGrid 
                     filterType="all" 
                     hideHeader={true} 
                     hideCategories={true}
                     shopVendor={store.store_name}
                   />
                 </div>

                 <div className="mt-20">
                   <ProductReviews storeId={store.id} />
                 </div>
              </div>
           </div>
        </div>
      </main>

      <Footer />

      {/* Report store modal */}
      {showReport && store && (
        <ReportModal
          contentType="store"
          contentId={store.id}
          contentLabel={store.store_name}
          onClose={() => setShowReport(false)}
        />
      )}
    </div>
  );
}
