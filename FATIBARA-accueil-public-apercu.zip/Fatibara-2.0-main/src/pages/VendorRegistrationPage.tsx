import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { useNavigate, Link, useSearchParams } from 'react-router-dom';
import Header from '../components/Header';
import Footer from '../components/Footer';
import { Store, User, Mail, Lock, ChevronRight, ChevronLeft, Upload, ShieldCheck, Camera, CheckCircle2, FileText, Loader2, X, AlertCircle, MapPin, Phone, Tag } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { useAppContext } from '../context/AppContext';
import { useToast } from '../context/ToastContext';
import { APP_NAME, CURRENCY } from '../lib/constants';
import FormField from '../components/ui/FormField';
import AppSelect from '../components/ui/AppSelect';

type Step = 'store' | 'identity' | 'account' | 'success';

import { GUINEA_LOCATIONS, ALL_REGIONS } from '../constants/locations';

import { z } from 'zod';
import { vendorRegistrationSchema } from '../lib/validations';
import { logAuditEvent } from '../utils/auditLogger';

export default function VendorRegistrationPage() {
  const { user, refreshProfile } = useAppContext();
  const { showToast } = useToast();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const [inviteToken] = useState<string | null>(searchParams.get('invite'));
  const [inviteValid, setInviteValid] = useState<boolean | null>(null);
  const [currentStep, setCurrentStep] = useState<Step>('store');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [errors, setErrors] = useState<{ [key: string]: string }>({});

  // ── Validate invite token from URL on mount ──────────────────────────────
  useEffect(() => {
    if (!inviteToken) return;
    // Use the SECURITY DEFINER RPC — the direct table query was removed
    // because the old SELECT policy (USING(true)) exposed all invite tokens
    // to any authenticated user.
    supabase
      .rpc('validate_vendor_invitation_token', { p_token: inviteToken })
      .then(({ data }) => {
        setInviteValid(data?.valid === true);
      });
  }, [inviteToken]);
  const [formData, setFormData] = useState({
    storeName: '',
    category: 'Mode & Prêt-à-porter',
    location_commune: 'Ratoma',
    location_region: 'Conakry',
    phone: '',
    idType: 'national_id' as 'national_id' | 'passport',
    idFile: null as File | null,
    email: '',
    password: '',
    agreeToTerms: false
  });

  const availableCommunes = GUINEA_LOCATIONS[formData.location_region as keyof typeof GUINEA_LOCATIONS] || [];

  const handleRegionChange = (region: string) => {
    const communes = GUINEA_LOCATIONS[region as keyof typeof GUINEA_LOCATIONS] || [];
    setFormData({
      ...formData,
      location_region: region,
      location_commune: communes[0] || ''
    });
  };

  const steps: { id: Step; title: string }[] = [
    { id: 'store', title: 'Ma Boutique' },
    { id: 'identity', title: 'Vérification' },
    { id: 'account', title: 'Compte' }
  ];

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 10 * 1024 * 1024) {
        showToast('Le fichier est trop volumineux (Max 10 Mo).', 'error');
        return;
      }

      const allowedTypes = ['image/jpeg', 'image/png', 'application/pdf'];
      if (!allowedTypes.includes(file.type)) {
        showToast('Type de fichier non supporté. Veuillez utiliser JPG, PNG ou PDF.', 'error');
        return;
      }

      setFormData({ ...formData, idFile: file });
      const url = URL.createObjectURL(file);
      setPreviewUrl(url);
    }
  };

  const removeFile = () => {
    setFormData({ ...formData, idFile: null });
    setPreviewUrl(null);
  };

  React.useEffect(() => {
    if (user && formData.email === '') {
      setFormData(prev => ({ ...prev, email: user.email || '' }));

      supabase.from('stores').select('id').eq('owner_id', user.id).maybeSingle().then(({ data }) => {
        if (data) {
          navigate('/vendor/dashboard');
        }
      });
    }
  }, [user]);

  const validateStep = (step: Step) => {
    try {
      const fieldErrors: { [key: string]: string } = {};
      const partialObj: any = { ...formData };
      const parsed = vendorRegistrationSchema.partial().safeParse(partialObj);

      if (!parsed.success) {
        parsed.error.issues.forEach(e => {
          if (e.path[0]) {
            fieldErrors[e.path[0] as string] = e.message;
          }
        });
      }

      if (step === 'store') {
        const stepErrors: any = {};
        if (fieldErrors.storeName) stepErrors.storeName = fieldErrors.storeName;
        if (fieldErrors.category) stepErrors.category = fieldErrors.category;
        if (fieldErrors.location_commune) stepErrors.location_commune = fieldErrors.location_commune;
        if (fieldErrors.location_region) stepErrors.location_region = fieldErrors.location_region;
        if (fieldErrors.phone) stepErrors.phone = fieldErrors.phone;
        
        if (Object.keys(stepErrors).length > 0) {
          setErrors(stepErrors);
          return false;
        }
      } else if (step === 'account') {
        const stepErrors: any = {};
        if (!user) {
          if (fieldErrors.email) stepErrors.email = fieldErrors.email;
          if (fieldErrors.password) stepErrors.password = fieldErrors.password;
        }
        if (fieldErrors.agreeToTerms) stepErrors.agreeToTerms = fieldErrors.agreeToTerms;

        if (Object.keys(stepErrors).length > 0) {
          setErrors(stepErrors);
          return false;
        }
      }
      
      setErrors({});
      return true;
    } catch (e) {
      return false;
    }
  };

  const handleNext = async (e: React.FormEvent) => {
    e.preventDefault();
    if (currentStep === 'store') {
      if (!validateStep('store')) return;
      setCurrentStep('identity');
    }
    else if (currentStep === 'identity') {
      if (!formData.idFile) {
        showToast('Veuillez télécharger un document d\'identité.', 'error');
        return;
      }
      setCurrentStep('account');
    }
    else if (currentStep === 'account') {
      if (!validateStep('account')) return;
      
      setIsSubmitting(true);
      try {
        let authUserId = user?.id;
        
        if (!user) {
          const { data: authData, error: authError } = await supabase.auth.signUp({
            email: formData.email,
            password: formData.password,
            options: {
              data: {
                full_name: formData.storeName,
              }
            }
          });
          if (authError) throw authError;
          if (!authData.user) throw new Error('Impossible de créer le compte');
          authUserId = authData.user.id;
        }

        // Wait briefly for profile to be created by the database trigger
        if (authUserId) {
          let profileFound = false;
          for (let i = 0; i < 5; i++) {
            const { data } = await supabase.from('profiles').select('id').eq('id', authUserId).maybeSingle();
            if (data) {
              profileFound = true;
              break;
            }
            await new Promise(r => setTimeout(r, 1000));
          }
          if (!profileFound) {
             console.warn('Profile not immediately available, continuing anyway...');
          }
        }

        let documentUrl = '';
        if (formData.idFile && authUserId) {
          const fileExt = formData.idFile.name.split('.').pop();
          const fileName = `${authUserId}/${Date.now()}.${fileExt}`;
          
          const { data: uploadData, error: uploadError } = await supabase.storage
            .from('verification-documents')
            .upload(fileName, formData.idFile);
            
          if (!uploadError && uploadData) {
            documentUrl = uploadData.path; 
          } else if (uploadError) {
            console.error("Upload error:", uploadError);
            throw new Error(`Erreur lors du téléchargement du document: ${uploadError.message}`);
          }
        }

        if (authUserId) {
          const { data: { user: currentUser } } = await supabase.auth.getUser();
          if (!currentUser) {
            throw new Error('Session expirée ou invalide. Veuillez vous reconnecter.');
          }

          const storeData: any = {
            owner_id: currentUser.id,
            store_name: formData.storeName,
            description: `Boutique de ${formData.category}`,
            store_category: formData.category,
            location_commune: formData.location_commune,
            location_region: formData.location_region,
            contact_phone: formData.phone,
            verification_document_url: documentUrl,
            is_verified_store: false,
            status: 'pending'
          };
          
          const { error: storeError } = await supabase.from('stores').insert(storeData);
          
          if (storeError) {
             if (storeError.code === '42501') {
               throw new Error(`Accès refusé (RLS). Assurez-vous d'être bien connecté avec le compte: ${formData.email}. Détails: ${storeError.message}`);
             }
             throw new Error(`Erreur lors de la création de la boutique: ${storeError.message}`);
          }

          // ── Lock in vendor role on the profile ──────────────────────────────
          // Without this, the next login's role resolution relies exclusively on
          // the stores query succeeding. If that query 406s (RLS/schema cache),
          // the vendor is wrongly assigned 'standard' and blocked from /vendor/*.
          const { error: profileRoleError } = await supabase
            .from('profiles')
            .update({ profile_type: 'pending_vendor' })
            .eq('id', currentUser.id);
          if (profileRoleError) {
            // Non-fatal: log and continue — the stores presence fallback still works
            console.warn('[VendorReg] Could not persist vendor role to profile:', profileRoleError.message);
          }
        }
        
        // Record audit event safely via backend proxy
        logAuditEvent({
          userId: authUserId,
          action: 'CREATE_STORE_REQUEST',
          entityType: 'store',
          entityId: authUserId,
          data: { storeName: formData.storeName }
        }).catch((auditErr: any) => {
          console.warn('[VendorReg] Audit log warning (non-fatal):', auditErr?.message);
        });
        
        // Consume invite token if provided — upgrades profile to 'vendor'
        if (inviteToken && authUserId) {
          const { data: consumed } = await supabase.rpc('consume_vendor_invitation', {
            p_token: inviteToken,
          });
          if (!consumed) {
            console.warn('Invite token was invalid or already used — registration still succeeded.');
          }
        }


        await refreshProfile();
        
        setCurrentStep('success');
      } catch (error: any) {
        showToast(error.message || 'Une erreur est survenue', 'error');
      } finally {
        setIsSubmitting(false);
      }
    }
  };

  const handleBack = () => {
    if (currentStep === 'identity') setCurrentStep('store');
    else if (currentStep === 'account') setCurrentStep('identity');
  };

  return (
    <div className="min-h-screen flex flex-col bg-brand-surface selection:bg-brand-primary selection:text-white">
      <Header />
      
      <main className="flex-grow flex bg-[radial-gradient(circle_at_top_right,_var(--tw-gradient-stops))] from-brand-primary/5 via-transparent to-transparent">
        <div className="w-full max-w-7xl mx-auto flex flex-col lg:flex-row min-h-[calc(100vh-80px)]">
          {/* Left Panel: Value Proposition (Desktop Only) */}
          <div className="hidden lg:flex lg:w-5/12 flex-col justify-center p-12 pr-20">
            <motion.div 
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.2 }}
            >
              <div className="w-16 h-16 bg-brand-primary rounded-2xl flex items-center justify-center text-white mb-8 shadow-sm">
                <Store className="w-8 h-8" />
              </div>
              <h1 className="text-5xl lg:text-6xl font-bold text-gray-900 dark:text-white tracking-tight leading-tight mb-6">
                Vendez plus vite. <br />
                Vendez <span className="text-brand-primary">mieux.</span>
              </h1>
              <p className="text-lg text-gray-600 font-medium mb-12 leading-relaxed">
                Rejoignez le marché en ligne le plus dynamique de Guinée. Des milliers d'acheteurs attendent vos produits.
              </p>
              
              <div className="space-y-6">
                <div className="flex gap-4 p-5 bg-white dark:bg-gray-900 border border-gray-100 dark:border-gray-800 rounded-2xl shadow-sm">
                  <div className="w-12 h-12 bg-brand-primary/10 rounded-xl flex items-center justify-center text-brand-primary shrink-0">
                    <ShieldCheck className="w-6 h-6" />
                  </div>
                  <div>
                    <h3 className="text-lg font-bold text-gray-900 dark:text-white mb-1">Vendeurs Vérifiés</h3>
                    <p className="text-sm text-gray-500 dark:text-gray-400 font-medium leading-relaxed">Gagnez la confiance de vos clients avec notre badge de vérification exclusif, augmentant vos ventes de 40%.</p>
                  </div>
                </div>
                <div className="flex gap-4 p-5 bg-white dark:bg-gray-900 border border-gray-100 dark:border-gray-800 rounded-2xl shadow-sm">
                  <div className="w-12 h-12 bg-brand-primary/10 rounded-xl flex items-center justify-center text-brand-primary shrink-0">
                    <User className="w-6 h-6" />
                  </div>
                  <div>
                    <h3 className="text-lg font-bold text-gray-900 dark:text-white mb-1">Tableau de Bord Pro</h3>
                    <p className="text-sm text-gray-500 dark:text-gray-400 font-medium leading-relaxed">Gérez vos produits, commandes et analysez vos ventes avec des outils de pointe pensés pour vous.</p>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>

          {/* Right Panel: Registration Form */}
          <div className="w-full lg:w-7/12 flex flex-col justify-center py-12 px-4 md:px-12 lg:pl-20 border-l border-gray-100 dark:border-gray-800 bg-gray-50 dark:bg-gray-800/50">
            <div className="max-w-2xl w-full mx-auto">
              
              {/* Progress Indicator */}
          {currentStep !== 'success' && (
            <div className="mb-12">
              <div className="flex justify-between items-center mb-4 relative z-10">
                {steps.map((s, idx) => (
                  <div key={s.id} className="flex flex-col items-center gap-3 flex-1 relative">
                    <div 
                      className={`w-12 h-12 flex items-center justify-center font-bold text-lg rounded-full transition-all z-10 border ${
                        currentStep === s.id ? 'bg-brand-primary border-brand-primary text-white shadow-md' : 
                        steps.findIndex(step => step.id === currentStep) > idx ? 'bg-brand-primary text-white border-brand-primary' : 'bg-white dark:bg-gray-900 text-gray-400 border-gray-200 dark:border-gray-700'
                      }`}
                    >
                      {steps.findIndex(step => step.id === currentStep) > idx ? <CheckCircle2 className="w-6 h-6" /> : idx + 1}
                    </div>
                    <span className={`text-xs font-bold uppercase tracking-wider ${currentStep === s.id ? 'text-brand-primary' : 'text-gray-500 dark:text-gray-400'}`}>
                      {s.title}
                    </span>
                    {idx < steps.length - 1 && (
                      <div className={`absolute top-6 left-1/2 w-full h-1 -z-10 ${steps.findIndex(step => step.id === currentStep) > idx ? 'bg-brand-primary' : 'bg-gray-200 dark:bg-gray-700'}`} />
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}

          <AnimatePresence mode="wait">
            <motion.div
              key={currentStep}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="bg-white dark:bg-gray-900 p-8 md:p-12 rounded-[2rem] border border-gray-100 dark:border-gray-800 shadow-sm relative"
            >
              <form onSubmit={handleNext} className="space-y-8">
                
                {/* STEP 1: STORE INFO */}
                {currentStep === 'store' && (
                  <div className="space-y-8">
                    <div className="text-center md:text-left">
                      <h2 className="text-3xl font-bold text-gray-900 dark:text-white tracking-tight mb-2">Parlez-nous de vous</h2>
                      <p className="text-gray-500 dark:text-gray-400 font-medium">Commençons par les bases de votre future boutique.</p>
                    </div>

                    <div className="space-y-6">
                      {/* Store Name */}
                      <FormField
                        label="Nom de la boutique"
                        error={errors.storeName}
                        required
                        icon={<Store className="w-4 h-4" />}
                      >
                        <input
                          type="text"
                          placeholder="Ex: Mode Conakry Elite"
                          value={formData.storeName}
                          onChange={(e) => { setFormData({ ...formData, storeName: e.target.value }); if (errors.storeName) setErrors({...errors, storeName: ''}); }}
                          className={`form-input ${errors.storeName ? 'is-error' : ''}`}
                        />
                      </FormField>

                      {/* Category */}
                      <FormField
                        label="Catégorie principale"
                        error={errors.category}
                        required
                        icon={<Tag className="w-4 h-4" />}
                      >
                        <AppSelect
                          value={formData.category}
                          onChange={(v) => { setFormData({ ...formData, category: v }); if (errors.category) setErrors({...errors, category: ''}); }}
                          icon={<Tag className="w-4 h-4" />}
                          isError={!!errors.category}
                          options={[
                            { value: 'Mode & Prêt-à-porter', label: 'Mode & Prêt-à-porter' },
                            { value: 'Beauté & Cosmétiques', label: 'Beauté & Cosmétiques' },
                            { value: 'Électronique', label: 'Électronique' },
                            { value: 'Électroménagers', label: 'Électroménagers' },
                            { value: 'Artisanat Local', label: 'Artisanat Local' },
                            { value: 'Alimentation', label: 'Alimentation' },
                            { value: 'Santé & Bien-être', label: 'Santé & Bien-être' },
                            { value: 'Maison & Déco', label: 'Maison & Déco' },
                          ]}
                        />
                      </FormField>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        {/* Region */}
                        <FormField
                          label="Région"
                          icon={<MapPin className="w-4 h-4" />}
                        >
                          <AppSelect
                            value={formData.location_region}
                            onChange={(v) => handleRegionChange(v)}
                            icon={<MapPin className="w-4 h-4" />}
                            options={ALL_REGIONS.map(r => ({ value: r, label: r }))}
                          />
                        </FormField>

                        {/* Commune */}
                        <FormField
                          label="Commune / Ville"
                          icon={<MapPin className="w-4 h-4" />}
                        >
                          <AppSelect
                            value={formData.location_commune}
                            onChange={(v) => setFormData({ ...formData, location_commune: v })}
                            icon={<MapPin className="w-4 h-4" />}
                            options={availableCommunes.map(c => ({ value: c, label: c }))}
                          />
                        </FormField>

                        {/* Phone */}
                        <FormField
                          label="Téléphone"
                          error={errors.phone}
                          required
                          icon={<Phone className="w-4 h-4" />}
                        >
                          <input
                            type="tel"
                            placeholder="Ex: 620 00 00 00"
                            value={formData.phone}
                            onChange={(e) => { setFormData({ ...formData, phone: e.target.value }); if (errors.phone) setErrors({...errors, phone: ''}); }}
                            className={`form-input ${errors.phone ? 'is-error' : ''}`}
                          />
                        </FormField>
                      </div>
                    </div>
                  </div>
                )}

                {/* STEP 2: IDENTITY VERIFICATION */}
                {currentStep === 'identity' && (
                  <div className="space-y-8">
                    <div>
                      <h2 className="text-3xl font-bold text-gray-900 dark:text-white tracking-tight mb-2 flex items-center gap-3">
                        <ShieldCheck className="w-8 h-8 text-brand-primary" />
                        Vérification
                      </h2>
                      <p className="text-gray-500 dark:text-gray-400 font-medium">Pour garantir la sécurité de nos clients, nous vérifions l'identité de chaque vendeur.</p>
                    </div>

                    <div className="space-y-6">
                      <div className="flex gap-4">
                        <button 
                          type="button"
                          onClick={() => setFormData({...formData, idType: 'national_id'})}
                          className={`flex-1 p-4 border rounded-2xl transition-all flex flex-col items-center gap-3 ${formData.idType === 'national_id' ? 'border-brand-primary bg-brand-primary/10 text-brand-primary shadow-sm' : 'border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-900 text-gray-600 hover:bg-gray-50 dark:bg-gray-800 hover:border-gray-300'}`}
                        >
                          <FileText className="w-8 h-8" />
                          <span className="text-xs font-bold uppercase tracking-wider">ID Biométrique</span>
                        </button>
                        <button 
                          type="button"
                          onClick={() => setFormData({...formData, idType: 'passport'})}
                          className={`flex-1 p-4 border rounded-2xl transition-all flex flex-col items-center gap-3 ${formData.idType === 'passport' ? 'border-brand-primary bg-brand-primary/10 text-brand-primary shadow-sm' : 'border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-900 text-gray-600 hover:bg-gray-50 dark:bg-gray-800 hover:border-gray-300'}`}
                        >
                          <Camera className="w-8 h-8" />
                          <span className="text-xs font-bold uppercase tracking-wider">Passeport</span>
                        </button>
                      </div>

                      <div className="relative group cursor-pointer">
                        {!previewUrl ? (
                          <>
                            <input 
                              type="file" 
                              accept="image/*,.pdf"
                              onChange={handleFileChange}
                              className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10" 
                            />
                            <div className="border border-dashed border-gray-200 dark:border-gray-700 rounded-2xl p-10 flex flex-col items-center gap-4 bg-gray-50 dark:bg-gray-800 group-hover:bg-brand-primary/5 group-hover:border-brand-primary/30 transition-all shadow-sm">
                              <div className="w-16 h-16 bg-white dark:bg-gray-900 rounded-2xl flex items-center justify-center text-gray-400 group-hover:text-brand-primary transition-colors shadow-sm">
                                <Upload className="w-8 h-8" />
                              </div>
                              <div className="text-center">
                                <p className="font-bold text-gray-900 dark:text-white">Téléchargez votre document</p>
                                <p className="text-xs text-gray-500 dark:text-gray-400 font-medium mt-1">PNG, JPG ou PDF (Max 10MB)</p>
                              </div>
                            </div>
                          </>
                        ) : (
                          <div className="relative border border-gray-200 dark:border-gray-700 rounded-2xl p-4 bg-gray-50 dark:bg-gray-800 shadow-sm">
                            <button 
                              type="button"
                              onClick={removeFile}
                              className="absolute top-2 right-2 w-8 h-8 bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-700 text-gray-500 dark:text-gray-400 rounded-lg flex items-center justify-center hover:bg-red-50 hover:text-red-600 hover:border-red-200 transition-colors z-20 shadow-sm"
                            >
                              <X className="w-4 h-4" />
                            </button>
                            <div className="aspect-video rounded-xl border border-gray-200 dark:border-gray-700 overflow-hidden bg-white dark:bg-gray-900 flex items-center justify-center">
                              {formData.idFile?.type.includes('image') ? (
                                <img src={previewUrl} alt="Preview" className="w-full h-full object-contain" />
                              ) : (
                                <div className="flex flex-col items-center gap-3 text-brand-primary">
                                  <FileText className="w-16 h-16" />
                                  <span className="text-xs font-bold uppercase tracking-wider text-gray-700">{formData.idFile?.name}</span>
                                </div>
                              )}
                            </div>
                            <p className="text-center text-xs font-bold uppercase text-green-600 mt-4 tracking-wider flex items-center justify-center gap-2">
                              <CheckCircle2 className="w-5 h-5" />
                              Document sélectionné
                            </p>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                )}

                {/* STEP 3: ACCOUNT SETUP */}
                {currentStep === 'account' && (
                  <div className="space-y-8">
                    <div>
                      <h2 className="text-3xl font-bold text-gray-900 dark:text-white tracking-tight mb-2">Finalisation</h2>
                      <p className="text-gray-500 dark:text-gray-400 font-medium">Dernière étape pour créer votre compte professionnel.</p>
                    </div>

                    <div className="space-y-6">
                      {user ? (
                        <div className="bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-700 rounded-2xl p-6 shadow-sm">
                          <div className="flex items-center gap-4 mb-4">
                            <div className="w-12 h-12 bg-brand-primary rounded-xl flex items-center justify-center text-white font-bold text-xl shadow-sm">
                              {user.email?.charAt(0).toUpperCase()}
                            </div>
                            <div>
                              <p className="text-sm font-bold text-gray-900 dark:text-white tracking-wider mb-0.5">{user.email}</p>
                              <p className="text-xs font-bold text-green-600 tracking-wider flex items-center gap-1"><CheckCircle2 className="w-3 h-3" /> Connecté</p>
                            </div>
                          </div>
                          <p className="text-xs font-medium text-gray-500 dark:text-gray-400 bg-gray-50 dark:bg-gray-800 px-3 py-2 rounded-lg border border-gray-100 dark:border-gray-800">Votre boutique sera associée à ce compte.</p>
                        </div>
                      ) : (
                        <>
                          <div className="group space-y-2">
                            <label className="text-xs font-bold uppercase tracking-wider text-gray-700">Email professionnel</label>
                            <div className="relative">
                              <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400 group-focus-within:text-brand-primary transition-colors" />
                              <input 
                                required
                                type="email" 
                                placeholder={`boutique@${APP_NAME.toLowerCase()}.gn`} 
                                value={formData.email}
                                onChange={(e) => { setFormData({ ...formData, email: e.target.value }); if (errors.email) setErrors({...errors, email: ''}); }}
                                className={`w-full pl-12 p-3.5 bg-gray-50 dark:bg-gray-800 border ${errors.email ? 'border-red-500' : 'border-gray-200 dark:border-gray-700'} rounded-xl outline-none focus:bg-white dark:bg-gray-900 focus:ring-2 focus:ring-brand-primary focus:border-transparent transition-all text-gray-900 dark:text-white font-medium`}
                              />
                            </div>
                            {errors.email && (
                              <div className="flex items-center gap-1.5 text-red-500 text-xs mt-1.5 font-bold uppercase tracking-wider">
                                <AlertCircle className="w-3.5 h-3.5" />
                                <span>{errors.email}</span>
                              </div>
                            )}
                          </div>

                          <div className="group space-y-2">
                            <label className="text-xs font-bold uppercase tracking-wider text-gray-700">Mot de passe</label>
                            <div className="relative">
                              <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400 group-focus-within:text-brand-primary transition-colors" />
                              <input 
                                required
                                type="password" 
                                placeholder="Minimum 8 caractères" 
                                value={formData.password}
                                onChange={(e) => { setFormData({ ...formData, password: e.target.value }); if (errors.password) setErrors({...errors, password: ''}); }}
                                className={`w-full pl-12 p-3.5 bg-gray-50 dark:bg-gray-800 border ${errors.password ? 'border-red-500' : 'border-gray-200 dark:border-gray-700'} rounded-xl outline-none focus:bg-white dark:bg-gray-900 focus:ring-2 focus:ring-brand-primary focus:border-transparent transition-all text-gray-900 dark:text-white font-medium`}
                              />
                            </div>
                            {errors.password && (
                              <div className="flex items-center gap-1.5 text-red-500 text-xs mt-1.5 font-bold uppercase tracking-wider">
                                <AlertCircle className="w-3.5 h-3.5" />
                                <span>{errors.password}</span>
                              </div>
                            )}
                          </div>
                        </>
                      )}

                      <label className="flex items-start gap-3 cursor-pointer group pt-4">
                        <div className="relative flex items-center justify-center mt-0.5">
                          <input 
                            type="checkbox" 
                            required
                            checked={formData.agreeToTerms}
                            onChange={(e) => { setFormData({ ...formData, agreeToTerms: e.target.checked }); if(errors.agreeToTerms) setErrors({...errors, agreeToTerms: ''}); }}
                            className="peer sr-only" 
                          />
                          <div className={`w-5 h-5 border ${errors.agreeToTerms ? 'border-red-500 bg-red-50' : 'border-gray-300 bg-white dark:bg-gray-900'} rounded peer-checked:bg-brand-primary peer-checked:border-brand-primary transition-all flex items-center justify-center shadow-sm`}>
                            <CheckCircle2 className="w-4 h-4 text-white opacity-0 peer-checked:opacity-100 transition-opacity" />
                          </div>
                        </div>
                        <span className="text-sm font-medium text-gray-600 leading-relaxed">
                          J'accepte les <Link to="/terms" className="text-brand-primary hover:brightness-110 hover:underline font-bold">conditions d'utilisation</Link> et la politique de confidentialité de {APP_NAME}.
                        </span>
                      </label>
                      {errors.agreeToTerms && (
                        <div className="flex items-center gap-1.5 text-red-500 text-xs mt-1.5 font-bold uppercase tracking-wider">
                          <AlertCircle className="w-3.5 h-3.5" />
                          <span>{errors.agreeToTerms}</span>
                        </div>
                      )}
                    </div>
                  </div>
                )}

                {/* STEP SUCCESS */}
                {currentStep === 'success' && (
                  <div className="text-center py-10">
                    <motion.div 
                      initial={{ scale: 0 }}
                      animate={{ scale: 1 }}
                      className="w-24 h-24 bg-green-100 rounded-full flex items-center justify-center text-green-600 mx-auto mb-8 shadow-sm"
                    >
                      <CheckCircle2 className="w-12 h-12" />
                    </motion.div>
                    <h2 className="text-3xl font-bold text-gray-900 dark:text-white tracking-tight mb-4">Votre boutique a été créée avec succès!</h2>
                    <p className="text-gray-500 dark:text-gray-400 font-medium mb-10 max-w-sm mx-auto leading-relaxed">
                      Notre équipe va examiner votre dossier sous 24-48h. Vous recevrez une notification par email une fois approuvé.
                    </p>
                    <button 
                      onClick={() => navigate('/vendor/dashboard')}
                      className="inline-flex items-center justify-center gap-3 bg-brand-primary text-white rounded-xl px-8 py-4 font-bold uppercase tracking-wider hover:brightness-110 shadow-sm active:scale-95 transition-all text-sm"
                    >
                      Aller au tableau de bord
                    </button>
                  </div>
                )}

                {/* NAVIGATION BUTTONS */}
                {currentStep !== 'success' && (
                  <div className="flex items-center gap-4 pt-8 border-t border-gray-100 dark:border-gray-800">
                    {currentStep !== 'store' && (
                      <button 
                        type="button"
                        onClick={handleBack}
                        className="flex-1 flex items-center justify-center gap-2 text-gray-600 bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-700 rounded-xl px-6 py-4 text-sm font-bold uppercase tracking-wider hover:bg-gray-50 dark:bg-gray-800 hover:text-brand-primary hover:border-brand-primary/30 transition-all shadow-sm active:scale-95"
                      >
                        <ChevronLeft className="w-5 h-5" />
                        Retour
                      </button>
                    )}
                    <button 
                      type="submit"
                      disabled={isSubmitting}
                      className="flex-[2] flex items-center justify-center gap-3 bg-brand-primary text-white rounded-xl px-8 py-4 text-sm font-bold uppercase tracking-wider shadow-sm hover:shadow-md hover:brightness-110 transition-all disabled:opacity-70 disabled:cursor-not-allowed active:scale-95"
                    >
                      {isSubmitting ? (
                        <>
                          <Loader2 className="w-5 h-5 animate-spin" />
                          Envoi...
                        </>
                      ) : (
                        <>
                          {currentStep === 'account' ? 'Soumettre' : 'Continuer'}
                          <ChevronRight className="w-5 h-5" />
                        </>
                      )}
                    </button>
                  </div>
                )}
              </form>
            </motion.div>
          </AnimatePresence>
          
          {currentStep !== 'success' && (
            <div className="mt-8 flex items-center justify-center gap-8 text-xs font-bold uppercase tracking-wider text-gray-500 dark:text-gray-400">
              <span className="flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-brand-primary" />
                Données Sécurisées
              </span>
              <span className="flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-brand-primary" />
                Vérification Rapide
              </span>
            </div>
          )}
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
