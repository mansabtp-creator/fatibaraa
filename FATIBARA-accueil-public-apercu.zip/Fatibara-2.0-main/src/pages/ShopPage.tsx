import React, { useEffect, useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { motion, AnimatePresence } from 'motion/react';
import { supabase } from '../lib/supabase';
import { useStore } from '../store/useStore';
import Header from '../components/Header';
import Footer from '../components/Footer';
import ProductGrid from '../components/ProductGrid';
import FlashDeals from '../components/FlashDeals';
import SEO from '../components/SEO';
import { Search, X, Store, TrendingUp, Tag, ShieldCheck, ChevronRight, Filter, CheckCircle } from 'lucide-react';
import { PRODUCT_CATEGORIES, APP_NAME } from '../lib/constants';

export default function ShopPage() {
  const location = useLocation();

  const [activeCategory, setActiveCategory] = useState<string>('Toutes');
  const [promoOnly, setPromoOnly] = useState(false);

  useEffect(() => {
    const searchParams = new URLSearchParams(location.search);
    const initialCategory = searchParams.get('category');
    const initialPromo = searchParams.get('promo') === 'true';

    if (initialCategory) setActiveCategory(initialCategory);
    setPromoOnly(initialPromo);
  }, [location.search]);
  const [activeVendor, setActiveVendor] = useState<string | null>(null);
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [searchQuery, setSearchQuery] = useState('');
  const [showPriceFilter, setShowPriceFilter] = useState(true);
  const [recommendedStores, setRecommendedStores] = useState<any[]>([]);
  const { globalSearchQuery, setGlobalSearchQuery } = useStore();

  useEffect(() => {
    async function fetchRecommendedStores() {
      const { data } = await supabase
        .from('stores')
        .select('*')
        .eq('is_verified_store', true)
        .limit(6);
      if (data) setRecommendedStores(data);
    }
    fetchRecommendedStores();
  }, []);

  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  const handleCategoryClick = (cat: string) => {
    setActiveCategory(cat);
    setPromoOnly(false);
    setActiveVendor(null);
  };

  const handlePromoToggle = () => {
    setPromoOnly(!promoOnly);
    if (!promoOnly) setActiveCategory('Toutes');
  };

  const clearFilters = () => {
    setActiveCategory('Toutes');
    setPromoOnly(false);
    setSearchQuery('');
    setGlobalSearchQuery('');
  };

  const categories = ['Toutes', ...PRODUCT_CATEGORIES];

  return (
    <div className="min-h-screen flex flex-col bg-brand-bg transition-colors duration-500">
      <SEO title={`La Boutique | ${APP_NAME}`} description={`Découvrez tous les produits, offres et tendances sur ${APP_NAME}.`} />
      <Header />
      
      <main className="flex-grow pt-20 md:pt-36">
        <div className="max-w-7xl mx-auto px-4 md:px-10">
          <FlashDeals />
          
          {/* Elite Hero Experience */}
          <section className="hidden lg:block relative mb-12 rounded-[3.5rem] overflow-hidden group shadow-2xl bg-[#0B0E11]">
            <div className="flex flex-col lg:flex-row min-h-[450px]">
              <div className="flex-[1.2] p-16 flex flex-col justify-center relative z-10">
                <motion.div 
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  className="flex items-center gap-3 mb-6"
                >
                  <div className="w-10 h-[2px] bg-[#ff6600]" />
                  <span className="text-[12px] font-black uppercase tracking-[0.4em] text-[#ff6600] italic">Édition Limitée 2026</span>
                </motion.div>
                
                <motion.h1 
                  initial={{ opacity: 0, y: 30 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.1 }}
                  className="text-6xl xl:text-7xl font-black text-white leading-[0.9] mb-8 tracking-tighter uppercase italic"
                >
                  L'Excellence<br/>
                  <span className="text-[#ff6600]">À Votre Portée.</span>
                </motion.h1>

                <p className="text-lg text-gray-400 font-bold max-w-md mb-10 leading-snug">
                  Découvrez la sélection {APP_NAME} : des produits audités, des vendeurs certifiés et une logistique nationale imbattable.
                </p>

                <div className="flex flex-wrap gap-5">
                  <button onClick={handlePromoToggle} className="bg-[#ff6600] text-white font-black text-[13px] uppercase tracking-[0.2em] px-10 py-5 rounded-2xl hover:scale-[1.02] shadow-xl shadow-[#ff6600]/20 transition-all active:scale-95">
                    Découvrir les Offres
                  </button>
                  <button className="bg-white/5 border border-white/10 text-white font-black text-[13px] uppercase tracking-[0.2em] px-10 py-5 rounded-2xl hover:bg-white/10 transition-all backdrop-blur-md">
                    Nos Vendeurs Or
                  </button>
                </div>
              </div>

              <div className="flex-1 relative overflow-hidden hidden xl:block">
                <motion.img 
                  initial={{ scale: 1.1, opacity: 0 }}
                  animate={{ scale: 1, opacity: 0.8 }}
                  transition={{ duration: 1.5 }}
                  src="https://images.unsplash.com/photo-1441986300917-64674bd600d8?q=80&w=2070&auto=format&fit=crop" 
                  className="absolute inset-0 w-full h-full object-cover grayscale-[20%] group-hover:scale-105 transition-transform duration-[3s]" 
                  alt="Elite Shopping" 
                />
                <div className="absolute inset-0 bg-gradient-to-r from-[#0B0E11] via-transparent to-transparent" />
                
                {/* Floating Stats Ornaments */}
                <div className="absolute bottom-10 right-10 flex gap-10">
                   <div className="text-center">
                      <p className="text-3xl font-black text-[#ff6600] leading-none mb-1">50K+</p>
                      <p className="text-[9px] font-black text-white/50 uppercase tracking-widest">Utilisateurs</p>
                   </div>
                   <div className="text-center">
                      <p className="text-3xl font-black text-white leading-none mb-1">24H</p>
                      <p className="text-[9px] font-black text-white/50 uppercase tracking-widest">Livraison Max</p>
                   </div>
                </div>
              </div>
            </div>
          </section>

          {/* Sticky Mobile Search & Category Bar */}
          <div className="lg:hidden sticky top-[68px] md:top-[88px] z-30 -mx-4 px-4 bg-white/90 dark:bg-gray-900/90 backdrop-blur-md border-b border-gray-100 dark:border-gray-800 py-3 space-y-3">
             <div className="relative group">
                <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400 dark:text-gray-500 group-focus-within:text-[#ff6600] transition-colors" />
                <input 
                  type="text" 
                  placeholder={`Chercher parmi des centaines d'articles…`}
                  value={globalSearchQuery}
                  onChange={(e) => setGlobalSearchQuery(e.target.value)}
                  className="w-full bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-full py-2.5 pl-10 pr-4 text-[14px] font-medium text-gray-900 dark:text-white outline-none focus:ring-1 focus:ring-[#ff6600] focus:border-[#ff6600] transition-all placeholder:text-gray-400 dark:placeholder:text-gray-500"
                />
             </div>
             <div className="flex gap-2 overflow-x-auto no-scrollbar -mx-4 px-4 pb-1">
                {categories.map((cat) => (
                  <button
                    key={cat}
                    onClick={() => handleCategoryClick(cat)}
                    className={`px-4 py-2 rounded-full text-[13px] font-medium transition-all whitespace-nowrap flex-shrink-0 border ${
                      activeCategory === cat 
                        ? 'bg-[#ff6600] text-white border-[#ff6600] shadow-sm' 
                        : 'bg-white dark:bg-gray-800 text-gray-700 dark:text-gray-300 border-gray-200 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-700'
                    }`}
                  >
                    {cat}
                  </button>
                ))}
                <button
                  onClick={handlePromoToggle}
                  className={`px-4 py-2 rounded-full text-[13px] font-bold transition-all whitespace-nowrap flex items-center gap-1.5 flex-shrink-0 border ${
                    promoOnly 
                      ? 'bg-[#e62e00] text-white border-[#e62e00] shadow-sm' 
                      : 'bg-white dark:bg-gray-800 text-[#e62e00] border-red-100 dark:border-red-900/40 hover:bg-red-50 dark:hover:bg-red-900/20'
                  }`}
                >
                  <Tag className="w-3.5 h-3.5" /> Promos
                </button>
             </div>
          </div>

          {/* ── Mobile Hero Strip (visible only on mobile) ────────────────── */}
          <section className="lg:hidden mt-4 mb-2">
            <motion.div
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.4 }}
              className="relative rounded-3xl overflow-hidden bg-gradient-to-br from-[#0B0E11] via-[#161a1f] to-[#0B0E11] p-6 shadow-2xl border border-white/5"
            >
              {/* Orange glow accent */}
              <div className="absolute top-0 right-0 w-40 h-40 bg-[#ff6600]/15 rounded-full blur-3xl -mr-10 -mt-10 pointer-events-none" />

              <div className="relative z-10">
                <div className="flex items-center gap-2 mb-3">
                  <div className="w-6 h-[2px] bg-[#ff6600]" />
                  <span className="text-[10px] font-black uppercase tracking-[0.35em] text-[#ff6600]">Fatibara · Guinée</span>
                </div>

                <h2 className="text-2xl font-black text-white leading-tight tracking-tight mb-4">
                  L'Excellence<br />
                  <span className="text-[#ff6600]">à votre portée.</span>
                </h2>

                {/* Trust signals */}
                <div className="flex gap-3 flex-wrap mb-5">
                  <div className="flex items-center gap-1.5 bg-white/5 border border-white/10 rounded-full px-3 py-1.5">
                    <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                    <span className="text-[11px] font-bold text-white">Vendeurs certifiés</span>
                  </div>
                  <div className="flex items-center gap-1.5 bg-white/5 border border-white/10 rounded-full px-3 py-1.5">
                    <TrendingUp className="w-3.5 h-3.5 text-[#ff6600]" />
                    <span className="text-[11px] font-bold text-white">Livraison 24h</span>
                  </div>
                  <div className="flex items-center gap-1.5 bg-white/5 border border-white/10 rounded-full px-3 py-1.5">
                    <CheckCircle className="w-3.5 h-3.5 text-blue-400" />
                    <span className="text-[11px] font-bold text-white">Paiement sécurisé</span>
                  </div>
                </div>

                <button
                  onClick={handlePromoToggle}
                  className="w-full bg-[#ff6600] text-white font-black text-[13px] uppercase tracking-[0.15em] py-3 rounded-2xl shadow-lg shadow-[#ff6600]/25 active:scale-95 transition-all"
                >
                  {promoOnly ? 'Voir tous les produits' : '🔥 Voir les offres du moment'}
                </button>
              </div>
            </motion.div>
          </section>

          <div className="flex flex-col lg:flex-row gap-8 lg:gap-12 mt-6">
            {/* Elite Sidebar (Desktop) */}
            <aside className="hidden lg:block w-72 flex-shrink-0">
               <div className="sticky top-[160px] space-y-8">
                  <div className="bg-white dark:bg-[#1A1D21] border border-gray-100 dark:border-white/5 rounded-[2.5rem] p-8 shadow-sm">
                    <h3 className="text-[12px] font-black text-gray-400 dark:text-gray-500 uppercase tracking-[0.2em] mb-6 flex items-center justify-between italic">
                       <span>Filtrage Avancé</span>
                       <Filter className="w-4 h-4 opacity-50" />
                    </h3>
                    <div className="space-y-6">
                       <div>
                        <h4 className="text-[13px] font-black text-gray-900 dark:text-white mb-4 tracking-tight uppercase italic underline decoration-[#ff6600]/30 underline-offset-4">
                          Univers
                        </h4>
                        <ul className="space-y-2">
                          {categories.map((cat) => (
                             <li key={cat}>
                               <button 
                                 onClick={() => handleCategoryClick(cat)}
                                 className={`group flex items-center justify-between w-full text-left px-4 py-2.5 rounded-xl transition-all ${
                                   activeCategory === cat ? 'bg-black dark:bg-white text-white dark:text-black' : 'text-gray-600 dark:text-gray-400 hover:bg-gray-50 dark:hover:bg-white/5'
                                 }`}
                               >
                                 <span className="text-[12px] font-black uppercase tracking-tight">{cat}</span>
                                 {activeCategory === cat && (
                                   <div className={`w-2 h-2 rounded-full ${activeCategory === cat ? 'bg-[#ff6600]' : 'bg-transparent'}`} />
                                 )}
                               </button>
                             </li>
                          ))}
                        </ul>
                      </div>
                      
                      <div className="pt-6 border-t border-gray-100 dark:border-white/5">
                        <h4 className="text-[13px] font-black text-gray-900 dark:text-white mb-4 uppercase italic">Privilèges</h4>
                        <div className="space-y-3">
                           <button 
                             onClick={handlePromoToggle}
                             className={`flex items-center justify-between w-full transition-all px-4 py-3 rounded-xl border ${
                                promoOnly 
                                  ? 'bg-[#e62e00] text-white border-[#e62e00]' 
                                  : 'bg-transparent border-gray-200 dark:border-white/10 text-gray-600 dark:text-gray-400 hover:border-[#ff6600]'
                             }`}
                           >
                             <div className="flex items-center gap-3">
                               <Tag className={`w-4 h-4 ${promoOnly ? 'animate-bounce' : ''}`} />
                               <span className="text-[11px] font-black uppercase tracking-widest">Offres Flash</span>
                             </div>
                           </button>
                           
                           <button 
                             className="flex items-center gap-3 w-full text-left transition-all px-4 py-3 rounded-xl border border-gray-200 dark:border-white/10 text-gray-600 dark:text-gray-400 hover:border-[#ff6600]"
                           >
                             <TrendingUp className="w-4 h-4 text-[#ff6600]" />
                             <span className="text-[11px] font-black uppercase tracking-widest">Nouveautés</span>
                           </button>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="p-8 bg-[#ff6600] rounded-[2.5rem] shadow-xl shadow-[#ff6600]/20 relative overflow-hidden group cursor-pointer">
                     <div className="relative z-10">
                        <ShieldCheck className="w-10 h-10 mb-4 text-white" />
                        <h4 className="text-xl font-black text-white mb-2 italic tracking-tighter uppercase leading-none">Protection<br/>{APP_NAME} PRO</h4>
                        <p className="text-[10px] font-black text-white/70 uppercase tracking-widest leading-relaxed">Paiement audité & logistique sécurisée à 100%.</p>
                     </div>
                     <div className="absolute -bottom-10 -right-10 w-32 h-32 bg-white/10 blur-[40px] group-hover:scale-150 transition-transform duration-700" />
                  </div>
               </div>
            </aside>

            {/* Main Content Area */}
            <div className="flex-1">
              
              {/* Top Vendors (Desktop) */}
              <div className="hidden lg:block mb-8 bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 rounded-xl p-4 shadow-sm">
                 <div className="flex items-center justify-between mb-4 border-b border-gray-100 dark:border-gray-800 pb-2">
                    <h3 className="text-[14px] font-bold text-gray-900 dark:text-white flex items-center gap-2">
                       <Store className="w-4 h-4 text-[#ff6600]"/> Boutiques Recommandées
                    </h3>
                    <Link to="/shop" className="text-[12px] font-bold text-[#ff6600] hover:underline">Voir Tout</Link>
                 </div>
                 
                 <div className="flex gap-4 overflow-x-auto no-scrollbar pb-1">
                    {recommendedStores.length > 0 ? recommendedStores.map((vendor) => (
                        <Link 
                          key={vendor.id} 
                          to={`/boutique/${vendor.store_name}`}
                          className="flex items-center gap-3 min-w-[150px] p-2 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-800 border border-transparent hover:border-gray-200 dark:hover:border-gray-700 transition-all"
                        >
                          <div className="relative">
                            <div className="w-10 h-10 flex items-center justify-center text-xs font-bold bg-[#ff6600]/10 border border-[#ff6600]/20 rounded-full text-[#ff6600] overflow-hidden">
                              {vendor.avatar_url ? <img src={vendor.avatar_url} className="w-full h-full object-cover" alt="" /> : vendor.store_name.substring(0, 2).toUpperCase()}
                            </div>
                            <div className="absolute -bottom-0.5 -right-0.5 w-3.5 h-3.5 bg-[#16a34a] rounded-full ring-2 ring-white dark:ring-gray-900" />
                          </div>
                          <div>
                            <span className="text-[13px] font-bold text-gray-900 dark:text-white block truncate max-w-[90px]">{vendor.store_name}</span>
                            <span className="text-[10px] text-gray-500 dark:text-gray-400 flex items-center gap-0.5"><CheckCircle className="w-2.5 h-2.5 text-[#16a34a]"/> Vérifié</span>
                          </div>
                        </Link>
                    )) : (
                       <div className="flex gap-4">
                         {[1,2,3,4].map(i => (
                           <div key={i} className="min-w-[150px] h-14 bg-gray-100 dark:bg-gray-900 animate-pulse rounded-xl" />
                         ))}
                       </div>
                    )}
                 </div>
              </div>

              {/* Catalog Header & Top Actions */}
              <div className="space-y-6">
                <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 pb-4 border-b border-gray-200 dark:border-gray-800">
                  <div className="flex-1">
                    <h2 className="text-xl md:text-2xl font-bold text-gray-900 dark:text-white mb-2">Catalogue Produits</h2>
                    
                    {/* Active Filter Chips */}
                    <div className="flex flex-wrap items-center gap-2">
                      {(activeCategory !== 'Toutes' || promoOnly || globalSearchQuery) && (
                        <div className="flex flex-wrap items-center gap-2">
                          {activeCategory !== 'Toutes' && (
                            <div className="px-2.5 py-1 bg-orange-50 dark:bg-orange-900/20 text-[#ff6600] border border-orange-100 dark:border-orange-900/40 rounded-full text-[11px] font-bold flex items-center gap-1.5">
                               {activeCategory}
                               <button onClick={() => setActiveCategory('Toutes')}><X className="w-3 h-3 hover:text-[#e62e00] transition-colors" /></button>
                            </div>
                          )}
                          {promoOnly && (
                            <div className="px-2.5 py-1 bg-red-50 dark:bg-red-900/20 text-[#e62e00] border border-red-100 dark:border-red-900/40 rounded-full text-[11px] font-bold flex items-center gap-1.5">
                               Promos Activées
                               <button onClick={() => setPromoOnly(false)}><X className="w-3 h-3 hover:text-red-700 transition-colors" /></button>
                            </div>
                          )}
                          {globalSearchQuery && (
                            <div className="px-2.5 py-1 bg-gray-100 dark:bg-gray-800 text-gray-700 dark:text-gray-300 border border-gray-200 dark:border-gray-700 rounded-full text-[11px] font-bold flex items-center gap-1.5">
                               "{globalSearchQuery}"
                               <button onClick={() => setGlobalSearchQuery('')}><X className="w-3 h-3 hover:text-gray-900 dark:hover:text-white transition-colors" /></button>
                            </div>
                          )}
                          <button onClick={clearFilters} className="text-[11px] font-bold text-gray-400 hover:text-gray-700 dark:hover:text-gray-300 transition-colors ml-1 underline">Effacer Filtres</button>
                        </div>
                      )}
                    </div>
                  </div>

                  <div className="w-full lg:w-auto flex flex-col md:flex-row items-center gap-3">
                     {/* Desktop Search */}
                     <div className="hidden lg:relative lg:block group">
                        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400 group-focus-within:text-[#ff6600] transition-colors" />
                        <input 
                          type="text" 
                          placeholder="Rechercher..."
                          value={globalSearchQuery}
                          onChange={(e) => setGlobalSearchQuery(e.target.value)}
                          className="w-48 xl:w-60 bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-full py-2 pl-9 pr-4 text-[13px] font-medium text-gray-900 dark:text-white outline-none focus:ring-1 focus:ring-[#ff6600] focus:border-[#ff6600] transition-all placeholder:text-gray-400 dark:placeholder:text-gray-500"
                        />
                     </div>
                     <div className="flex items-center bg-gray-100 dark:bg-gray-800 rounded-lg p-0.5">
                       <button 
                        onClick={() => setViewMode('grid')}
                        className={`px-3 py-1.5 rounded-md text-[13px] font-bold transition-all ${viewMode === 'grid' ? 'bg-white dark:bg-gray-700 text-gray-900 dark:text-white shadow-sm' : 'text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300'}`}
                       >
                         Grille
                       </button>
                       <button 
                        onClick={() => setViewMode('list')}
                        className={`px-3 py-1.5 rounded-md text-[13px] font-bold transition-all ${viewMode === 'list' ? 'bg-white dark:bg-gray-700 text-gray-900 dark:text-white shadow-sm' : 'text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300'}`}
                       >
                         Liste
                       </button>
                     </div>
                  </div>
                </div>

                {/* Loading State & Results Section */}
                <div className="min-h-[800px] -mx-4 md:mx-0">
                  <ProductGrid 
                     filterType="all" 
                     hideHeader={true}
                     hideCategories={true}
                     shopCategory={activeCategory === 'Toutes' ? null : activeCategory}
                     shopPromoOnly={promoOnly}
                     shopVendor={activeVendor}
                  />
                </div>
              </div>

            </div>
          </div>
        </div>
      </main>
      
      <div className="md:hidden h-16"></div>
      <Footer />
    </div>
  );
}
