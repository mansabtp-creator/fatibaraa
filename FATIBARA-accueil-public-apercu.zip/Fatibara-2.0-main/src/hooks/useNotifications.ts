import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { useAppContext } from '../context/AppContext';
import { toast } from 'sonner';

export interface Notification {
  id: string;
  type: 'order' | 'promo' | 'system' | string;
  title: string;
  message: string;
  is_read: boolean;
  created_at: string;
}

export function useNotifications() {
  const { user } = useAppContext();
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [unreadCount, setUnreadCount] = useState(0);

  useEffect(() => {
    if (!user) {
      setNotifications([]);
      setUnreadCount(0);
      return;
    }

    const fetchNotifications = async () => {
      const { data, error } = await supabase
        .from('notifications')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false })
        .limit(20);

      if (!error && data) {
        setNotifications(data);
        setUnreadCount(data.filter((n) => !n.is_read).length);
      }
    };

    fetchNotifications();

    let reconnectTimer: ReturnType<typeof setTimeout> | null = null;

    const subscribe = () => {
      // Channel scoped to userId to prevent cross-user event leakage in multi-user
      // or multi-tab sessions. After the RLS fix, INSERT events flow cleanly.
      const channel = supabase.channel(`user-notifications:${user.id}`)
        .on(
          'postgres_changes',
          {
            event: 'INSERT',
            schema: 'public',
            table: 'notifications',
            filter: `user_id=eq.${user.id}`,
          },
          (payload) => {
            // Trigger toast for new notification
            const newNotif = payload.new as Notification;
            toast.info(newNotif.title, {
              description: newNotif.message,
              duration: 4000,
            });
            fetchNotifications();
          }
        )
        .on(
          'postgres_changes',
          {
            event: '*',
            schema: 'public',
            table: 'notifications',
            filter: `user_id=eq.${user.id}`,
          },
          (payload) => {
            if (payload.eventType !== 'INSERT') {
              fetchNotifications();
            }
          }
        )
        .on('system', {}, ({ status }: { status: string }) => {
          // F8 fix: auto-reconnect when the WebSocket closes (common on slow networks)
          if (status === 'CLOSED') {
            reconnectTimer = setTimeout(() => {
              supabase.removeChannel(channel);
              subscribe();
            }, 5000);
          } else if (status === 'SUBSCRIBED' && reconnectTimer) {
            clearTimeout(reconnectTimer);
            reconnectTimer = null;
          }
        })
        .subscribe();

      return channel;
    };

    const channel = subscribe();

    return () => {
      if (reconnectTimer) clearTimeout(reconnectTimer);
      supabase.removeChannel(channel);
    };
  }, [user]);


  const markAllAsRead = async () => {
    if (!user || unreadCount === 0) return;

    // Optimistic UI Update
    setNotifications((prev) => prev.map((n) => ({ ...n, is_read: true })));
    setUnreadCount(0);

    // Backend Sync
    await supabase
      .from('notifications')
      .update({ is_read: true })
      .eq('user_id', user.id)
      .eq('is_read', false);
  };

  const markAsRead = async (id: string) => {
    if (!user) return;
    
    // Optimistic Update
    setNotifications((prev) => 
      prev.map((n) => (n.id === id ? { ...n, is_read: true } : n))
    );
    setUnreadCount((prev) => Math.max(0, prev - 1));

    // Backend Sync
    await supabase
      .from('notifications')
      .update({ is_read: true })
      .eq('id', id);
  };

  return { notifications, unreadCount, markAllAsRead, markAsRead };
}

export function formatTimeAgo(dateString: string) {
  const date = new Date(dateString);
  const now = new Date();
  const diffInSeconds = Math.floor((now.getTime() - date.getTime()) / 1000);
  
  if (diffInSeconds < 60) return 'À l\'instant';
  if (diffInSeconds < 3600) return `Il y a ${Math.floor(diffInSeconds / 60)} min`;
  if (diffInSeconds < 86400) return `Il y a ${Math.floor(diffInSeconds / 3600)}h`;
  return `Il y a ${Math.floor(diffInSeconds / 86400)}j`;
}
