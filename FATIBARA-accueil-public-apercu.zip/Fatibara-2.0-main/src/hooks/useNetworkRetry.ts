/**
 * useNetworkRetry.ts
 *
 * Composable hook for wrapping async operations with:
 *   1. Automatic retry with exponential back-off
 *   2. Offline detection guard (skips retry when navigator.onLine=false)
 *   3. User-facing French toast on transient failures
 *   4. Abort signal for unmount cleanup
 *
 * Design notes:
 *  - Only retries on network-class errors (TypeError: Failed to fetch,
 *    AbortError, and Supabase PGRST* codes).
 *  - Auth/validation errors (4xx) are NOT retried — they propagate immediately.
 *  - Back-off: 800ms → 1.6s → 3.2s (capped at 5s), jittered ±20%.
 *
 * Usage:
 *   const { withRetry } = useNetworkRetry();
 *   const data = await withRetry(() => supabase.from('orders').select('*'));
 */

import { useCallback, useRef } from 'react';
import { useToast } from '../context/ToastContext';

export interface RetryOptions {
  /** Max number of attempts (including the first). Default: 3 */
  maxAttempts?: number;
  /** Initial delay in ms before first retry. Default: 800 ms */
  initialDelayMs?: number;
  /** Show a localized French toast on transient failure. Default: true */
  showToastOnRetry?: boolean;
  /** Custom message shown on retry. Default: 'Connexion instable. Reconnexion en cours...' */
  retryMessage?: string;
}

/** Returns true for errors that warrant a retry (network, timeout, rate-limit). */
function isRetryable(error: unknown): boolean {
  if (!error) return false;
  if (error instanceof TypeError) {
    const msg = (error as TypeError).message.toLowerCase();
    // Covers: "Failed to fetch", "NetworkError", "Load failed"
    if (msg.includes('fetch') || msg.includes('network') || msg.includes('load')) return true;
  }
  if (error instanceof DOMException && error.name === 'AbortError') return true;
  // Supabase / PostgREST network errors surface as objects with `message`
  if (typeof error === 'object' && error !== null) {
    const e = error as Record<string, any>;
    const msg = String(e.message ?? '').toLowerCase();
    const code = String(e.code ?? '');
    // Retry on: connection refused, gateway timeout, rate limits
    if (msg.includes('network') || msg.includes('fetch') || msg.includes('timeout')) return true;
    if (code === 'PGRST' || code === '408' || code === '429' || code === '503') return true;
  }
  return false;
}

/** Jittered exponential back-off delay. */
function backoff(attempt: number, baseMs: number): number {
  const exp = Math.min(baseMs * Math.pow(2, attempt), 5000);
  const jitter = exp * (0.8 + Math.random() * 0.4); // ±20%
  return Math.round(jitter);
}

export function useNetworkRetry() {
  const { showToast } = useToast();
  const abortRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  /**
   * Wrap any async fn with retry logic.
   * Returns the resolved value on success, or re-throws after exhausting attempts.
   */
  const withRetry = useCallback(
    async <T>(
      fn: () => Promise<T>,
      options: RetryOptions = {}
    ): Promise<T> => {
      const {
        maxAttempts     = 3,
        initialDelayMs  = 800,
        showToastOnRetry = true,
        retryMessage    = 'Connexion réseau instable. Reconnexion en cours\u2026',
      } = options;

      let lastError: unknown;

      for (let attempt = 0; attempt < maxAttempts; attempt++) {
        // If browser is offline, bail immediately and show a clear message
        if (!navigator.onLine) {
          if (showToastOnRetry) {
            showToast('Hors ligne — vérifiez votre connexion mobile.', 'warning');
          }
          throw new Error('offline');
        }

        try {
          return await fn();
        } catch (err) {
          lastError = err;

          const isLastAttempt = attempt === maxAttempts - 1;
          if (isLastAttempt || !isRetryable(err)) {
            throw err;
          }

          // Show retry notice on first transient failure only
          if (showToastOnRetry && attempt === 0) {
            showToast(retryMessage, 'warning');
          }

          // Wait before next attempt
          await new Promise<void>((resolve) => {
            abortRef.current = setTimeout(resolve, backoff(attempt, initialDelayMs));
          });
        }
      }

      throw lastError;
    },
    [showToast]
  );

  return { withRetry };
}

/**
 * Standalone (non-hook) retry utility for use outside React components.
 * Same retry/back-off logic, but takes an explicit toast function.
 */
export async function retryAsync<T>(
  fn: () => Promise<T>,
  options: RetryOptions & { onRetry?: (attempt: number) => void } = {}
): Promise<T> {
  const {
    maxAttempts    = 3,
    initialDelayMs = 800,
    onRetry,
  } = options;

  let lastError: unknown;

  for (let attempt = 0; attempt < maxAttempts; attempt++) {
    if (!navigator.onLine) throw new Error('offline');

    try {
      return await fn();
    } catch (err) {
      lastError = err;
      if (attempt === maxAttempts - 1 || !isRetryable(err)) throw err;
      onRetry?.(attempt + 1);
      await new Promise<void>((r) => setTimeout(r, backoff(attempt, initialDelayMs)));
    }
  }

  throw lastError;
}
