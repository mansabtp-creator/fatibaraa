/**
 * usePushNotifications.ts
 *
 * React hook that manages the full Web Push subscription lifecycle:
 *   1. Check/request browser notification permission
 *   2. Subscribe via PushManager (needs VAPID public key from env)
 *   3. POST the PushSubscription to /api/push/subscribe
 *   4. Allow unsubscribe
 *
 * Required env var:
 *   VITE_VAPID_PUBLIC_KEY  – The VAPID public key (same key used server-side)
 *                            Generate with: npx web-push generate-vapid-keys
 *
 * Usage:
 *   const { isSubscribed, isSupported, subscribe, unsubscribe, isLoading } =
 *     usePushNotifications();
 *
 * Call subscribe() when the user clicks "Activer les notifications push".
 * Call unsubscribe() when they toggle it off.
 */
import { useState, useEffect, useCallback } from 'react';
import { supabase } from '../lib/supabase';

// ─── Helpers ─────────────────────────────────────────────────────────────────

function urlBase64ToUint8Array(base64String: string): Uint8Array {
  // Trim whitespace (trailing space/newline in .env causes atob() to throw
  // "The string to be decoded is not correctly encoded" — Bug #2 fix)
  const clean   = base64String.trim();
  const padding = '='.repeat((4 - (clean.length % 4)) % 4);
  const base64  = (clean + padding).replace(/-/g, '+').replace(/_/g, '/');
  try {
    const raw = window.atob(base64);
    return Uint8Array.from([...raw].map(c => c.charCodeAt(0)));
  } catch {
    throw new Error(
      'Clé VAPID invalide (VITE_VAPID_PUBLIC_KEY). ' +
      'Vérifiez que la variable d\'environnement est correctement définie et ne contient pas d\'espaces.'
    );
  }
}

const VAPID_PUBLIC_KEY = import.meta.env.VITE_VAPID_PUBLIC_KEY as string | undefined;
const SUBSCRIBE_URL   = '/api/push/subscribe';

// ─── Hook ─────────────────────────────────────────────────────────────────────

export function usePushNotifications() {
  const [isSupported,  setIsSupported]  = useState(false);
  const [isSubscribed, setIsSubscribed] = useState(false);
  const [isLoading,    setIsLoading]    = useState(false);
  const [error,        setError]        = useState<string | null>(null);

  // ── Detect support & current subscription status ──────────────────────────
  useEffect(() => {
    let isMounted = true;
    const supported =
      'serviceWorker' in navigator &&
      'PushManager'   in window    &&
      'Notification'  in window    &&
      !!VAPID_PUBLIC_KEY;

    if (isMounted) setIsSupported(supported);

    if (!supported) return;

    navigator.serviceWorker.ready
      .then(reg => reg.pushManager.getSubscription())
      .then(sub => {
        if (isMounted) setIsSubscribed(!!sub);
      })
      .catch(() => {});

    return () => {
      isMounted = false;
    };
  }, []);

  // ── Subscribe ─────────────────────────────────────────────────────────────
  const subscribe = useCallback(async (): Promise<boolean> => {
    setError(null);

    if (!isSupported) {
      setError('Web Push non supporté sur ce navigateur.');
      return false;
    }
    if (!VAPID_PUBLIC_KEY) {
      setError('VITE_VAPID_PUBLIC_KEY non configuré.');
      return false;
    }

    setIsLoading(true);
    try {
      // 1. Request permission
      const permission = await Notification.requestPermission();
      if (permission !== 'granted') {
        setError('Permission de notification refusée.');
        return false;
      }

      // 2. Get SW registration
      const reg = await navigator.serviceWorker.ready;

      // 3. Subscribe via PushManager
      const sub = await reg.pushManager.subscribe({
        userVisibleOnly: true,
        applicationServerKey: urlBase64ToUint8Array(VAPID_PUBLIC_KEY),
      });

      const subJson = sub.toJSON() as {
        endpoint: string;
        keys: { p256dh: string; auth: string };
      };

      // 4. Get Supabase session token
      const { data: { session } } = await supabase.auth.getSession();
      if (!session?.access_token) {
        setError('Vous devez être connecté pour activer les notifications push.');
        await sub.unsubscribe();
        return false;
      }

      // 5. Send to server
      const res = await fetch(SUBSCRIBE_URL, {
        method:  'POST',
        headers: {
          'Content-Type':  'application/json',
          'Authorization': `Bearer ${session.access_token}`,
        },
        body: JSON.stringify({
          endpoint:  subJson.endpoint,
          keys:      subJson.keys,
          userAgent: navigator.userAgent,
        }),
      });

      if (!res.ok) {
        throw new Error(`Server error ${res.status}`);
      }

      setIsSubscribed(true);
      return true;
    } catch (err: any) {
      setError(err.message ?? 'Erreur lors de l\'activation des notifications.');
      return false;
    } finally {
      setIsLoading(false);
    }
  }, [isSupported]);

  // ── Unsubscribe ───────────────────────────────────────────────────────────
  const unsubscribe = useCallback(async (): Promise<void> => {
    setIsLoading(true);
    try {
      const reg = await navigator.serviceWorker.ready;
      const sub = await reg.pushManager.getSubscription();
      if (sub) {
        await sub.unsubscribe();
        // Mark as inactive server-side (best effort)
        const { data: { session } } = await supabase.auth.getSession();
        if (session?.access_token) {
          await fetch('/api/push/unsubscribe', {
            method:  'POST',
            headers: {
              'Content-Type':  'application/json',
              'Authorization': `Bearer ${session.access_token}`,
            },
            body: JSON.stringify({ endpoint: sub.endpoint }),
          }).catch(() => {});
        }
      }
      setIsSubscribed(false);
    } catch (err: any) {
      setError(err.message ?? 'Erreur lors de la désactivation.');
    } finally {
      setIsLoading(false);
    }
  }, []);

  return { isSupported, isSubscribed, isLoading, error, subscribe, unsubscribe };
}
