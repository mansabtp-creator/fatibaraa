import { useState, useEffect, useRef, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAppContext } from '../context/AppContext';
import { supabase, validateSessionOrClear } from '../lib/supabase';
import { useToast } from '../context/ToastContext';
import { hapticFeedback } from '../lib/haptics';
import { notifyNewOrder } from '../utils/notifications';

// ── Module-level stale-while-revalidate cache ─────────────────────────────────
// Shared across all hook instances so tab-switches don’t cause loading flickers.
// When a vendor navigates Dashboard → Products → Orders, the new page mounts
// with cached data immediately visible while the background refresh runs.
// Cache is keyed by userId and TTL is 30 s.
const CACHE_TTL_MS = 30_000;
interface VendorCache {
  storeData: any;
  products: any[];
  vendorStats: any;
  aggregatedMetrics: any;
  userRole: 'owner' | 'manager' | 'staff';
  ts: number;
}
const _vendorCache = new Map<string, VendorCache>();
function getCached(userId: string): VendorCache | null {
  const entry = _vendorCache.get(userId);
  if (!entry) return null;
  if (Date.now() - entry.ts > CACHE_TTL_MS) { _vendorCache.delete(userId); return null; }
  return entry;
}

export function useVendorData() {
  const { user, isAuthLoading } = useAppContext();
  const navigate = useNavigate();
  const { showToast } = useToast();

  // Seed state from cache on first render so there’s no blank flash on tab switch
  const cached = user?.id ? getCached(user.id) : null;
  const [loading, setLoading] = useState(!cached);
  const [storeData, setStoreData] = useState<any>(cached?.storeData ?? null);
  const [products, setProducts] = useState<any[]>(cached?.products ?? []);
  const [vendorStats, setVendorStats] = useState<any>(cached?.vendorStats ?? null);
  const [aggregatedMetrics, setAggregatedMetrics] = useState<any>(cached?.aggregatedMetrics ?? null);
  const [userRole, setUserRole] = useState<'owner' | 'manager' | 'staff'>(cached?.userRole ?? 'owner');
  const userIdRef = useRef<string | undefined>(user?.id);
  useEffect(() => { userIdRef.current = user?.id; }, [user?.id]);

  const fetchData = useCallback(async (isMounted: { current: boolean } = { current: true }) => {
    if (isAuthLoading) return;
    if (!user) {
      navigate('/login');
      return;
    }

    try {
      let store;
      let role: 'owner' | 'manager' | 'staff' = 'owner';

      const { data: ownedStore } = await supabase
        .from('stores')
        .select('*')
        .eq('owner_id', user.id)
        .maybeSingle();
      
      if (ownedStore) {
        store = ownedStore;
        role = 'owner';
      } else {
        const { data: staffData } = await supabase
          .from('store_staff')
          .select('role, stores(*)')
          .eq('user_id', user.id)
          .maybeSingle();
        
        if (staffData && staffData.stores) {
          store = staffData.stores;
          role = staffData.role as any;
        }
      }

      if (!store) {
        navigate('/dashboard');
        return;
      }

      if (!isMounted.current) return;
      setStoreData(store);
      setUserRole(role);

      const { data: prods } = await supabase
        .from('products')
        .select('*')
        .eq('store_id', store.id)
        .order('created_at', { ascending: false });

      if (!isMounted.current) return;
      setProducts(prods || []);

      // FAST AGGREGATED METRICS
      // Destructure error so a 400 from production doesn't silently leave
      // `metrics` as undefined and crash components calling .toLocaleString().
      const { data: metrics, error: metricsError } = await supabase.rpc('get_vendor_dashboard_metrics', {
        p_vendor_id: user.id
      });

      if (metricsError) {
        console.warn('[useVendorData] get_vendor_dashboard_metrics RPC error (metrics will use zero defaults):', metricsError);
      }

      // Always run the safe-metrics block — use empty object when RPC failed
      // so every field falls back to its ?? 0 guard below.
      if (metrics || metricsError) {
        // V9: Compute supplemental metrics — include BOTH vendor_id and legacy store_id orders
        // so repeat customer rate is accurate for all stores, including legacy ones.
        const { data: ordersForMetricsA } = await supabase
          .from('orders')
          .select('user_id, created_at')
          .eq('vendor_id', user.id)
          .neq('status', 'cancelled')
          .order('created_at', { ascending: false })
          .limit(200);

        // Also fetch via store_id for legacy orders where vendor_id is null
        const { data: ordersForMetricsB } = await supabase
          .from('orders')
          .select('user_id, created_at')
          .eq('store_id', store.id)
          .neq('status', 'cancelled')
          .order('created_at', { ascending: false })
          .limit(200);

        // Merge + deduplicate by (user_id, created_at) key
        const seenMetricsKeys = new Set<string>();
        const ordersForMetrics: any[] = [];
        for (const o of [...(ordersForMetricsA ?? []), ...(ordersForMetricsB ?? [])]) {
          const k = `${o.user_id}_${o.created_at}`;
          if (!seenMetricsKeys.has(k)) { seenMetricsKeys.add(k); ordersForMetrics.push(o); }
        }

        // Repeat customer rate
        let repeatCustomerRate = 0;
        if (ordersForMetrics && ordersForMetrics.length > 0) {
          const customerCounts: Record<string, number> = {};
          ordersForMetrics.forEach((o: any) => {
            if (o.user_id) customerCounts[o.user_id] = (customerCounts[o.user_id] || 0) + 1;
          });
          const total = Object.keys(customerCounts).length;
          const repeat = Object.values(customerCounts).filter(c => c > 1).length;
          repeatCustomerRate = total > 0 ? Math.round((repeat / total) * 100) : 0;
        }

        // Avg response time — field not available in current schema
        const avgResponseTimeMin: number | null = null;

        const m = metrics ?? {} as Record<string, any>;
        const safeMetrics = {
          total_revenue:       m.total_revenue    ?? 0,
          completed_orders:    m.completed_orders ?? 0,
          pending_orders:      m.pending_orders   ?? 0,
          active_orders:       m.active_orders    ?? 0,
          totalSales:          m.totalSales       ?? m.total_revenue ?? 0,
          totalOrders:         m.totalOrders      ?? (
            (m.completed_orders ?? 0) +
            (m.pending_orders   ?? 0) +
            (m.active_orders    ?? 0)
          ),
          totalViews:          m.totalViews       ?? 0,
          lowStockCount:       m.lowStockCount    ?? 0,
          rating:              m.rating           ?? 0,
          score:               m.score            ?? 0,
          projectedRevenue:    m.projectedRevenue ?? 0,
          commissionRate:      m.commissionRate   ?? 0.05,
          peakHours:           m.peakHours        ?? [],
          last7Days:           m.last7Days        ?? [],
          topProducts:         m.topProducts      ?? [],
          // Sprint 2 additions
          repeatCustomerRate,
          avgResponseTimeMin,
        };
        if (!isMounted.current) return;
        setAggregatedMetrics(safeMetrics);
        setVendorStats({
          total_orders: safeMetrics.totalOrders,
          rating:       safeMetrics.rating,
        });

        // ── Write back to module cache so next mount is instant ───────────────
        if (userIdRef.current) {
          _vendorCache.set(userIdRef.current, {
            storeData: store,
            products: prods || [],
            vendorStats: { total_orders: safeMetrics.totalOrders, rating: safeMetrics.rating },
            aggregatedMetrics: safeMetrics,
            userRole: role,
            ts: Date.now(),
          });
        }
      }

    } catch (err: any) {
      const code = err?.code as string | undefined;
      const msg  = err?.message as string | undefined;

      // ── HTTP 406 Not Acceptable ───────────────────────────────────────────────
      // PostgREST returns 406 when the JWT in the Authorization header is
      // structurally broken or when a schema-cache reload after a migration
      // disrupts content-type negotiation before the query can execute.
      if (code === '406' || msg?.toLowerCase().includes('not acceptable')) {
        console.error(
          '[useVendorData] HTTP 406 on stores query — JWT may be corrupted or ' +
          'PostgREST schema cache is stale after a recent migration.',
          err
        );
        // Probe and optionally clear the corrupted session.
        const freshSession = await validateSessionOrClear();
        if (!freshSession) {
          showToast(
            'Session expirée ou invalide. Veuillez vous reconnecter.',
            'error'
          );
          navigate('/login');
        } else {
          showToast(
            'Erreur serveur (406). Si le problème persiste, reconnectez-vous.',
            'error'
          );
        }
      } else {
        console.error('[useVendorData] Error fetching vendor data:', err);
        showToast(msg || 'Erreur de chargement', 'error');
      }
    } finally {
      if (isMounted.current) setLoading(false);
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user?.id, isAuthLoading]);

  // eslint-disable-next-line react-hooks/exhaustive-deps
  useEffect(() => {
    const mountedRef = { current: true };
    fetchData(mountedRef);
    return () => { mountedRef.current = false; };
  // Use primitive user?.id — the full `user` object changes reference on
  // every auth-state emission and would re-trigger data fetches unnecessarily.
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user?.id, isAuthLoading]);

  useEffect(() => {
    if (!user?.id || !storeData?.id) return;

    const userId  = user.id;
    const storeId = storeData.id as string;

    let reconnectTimer: ReturnType<typeof setTimeout> | null = null;
    let channel: ReturnType<typeof supabase.channel> | null = null;

    const subscribe = () => {
      if (channel) supabase.removeChannel(channel);

      // Channel name is scoped to BOTH userId and storeId so that:
      // - Multiple vendor dashboards open in different tabs don't share a channel.
      // - After the RLS recursion fix, the `orders` filter resolves cleanly.
      channel = supabase
        .channel(`vendor-updates:${userId}:${storeId}`)
        .on('postgres_changes', { 
          event: '*', 
          schema: 'public', 
          table: 'products',
          filter: `store_id=eq.${storeId}`
        }, () => {
          fetchData();
        })
        .on('postgres_changes', {
          // INSERT = new order from customer; UPDATE = courier/admin status change
          event: 'INSERT',
          schema: 'public', 
          table: 'orders',
          filter: `vendor_id=eq.${userId}`
        }, (payload: any) => {
          showToast("Nouvelle commande reçue ! 🚀", "success");
          hapticFeedback('heavy');
          notifyNewOrder(payload.new.id, payload.new.total_amount);
          fetchData();
        })
        .on('system', {}, ({ status }: { status: string }) => {
          if (status === 'CLOSED') {
            // Reconnect on drop (common on slow Guinea networks)
            if (reconnectTimer) return;
            reconnectTimer = setTimeout(() => { reconnectTimer = null; subscribe(); }, 5_000);
          } else if (status === 'SUBSCRIBED') {
            if (reconnectTimer) { clearTimeout(reconnectTimer); reconnectTimer = null; }
            console.info(`[useVendorData] Realtime channel active for vendor ${userId}`);
          } else if (status === 'CHANNEL_ERROR' || status === 'TIMED_OUT') {
            console.debug('[useVendorData] Realtime channel transient reconnection');
          }
        })
        .subscribe();
    };

    subscribe();

    return () => {
      if (reconnectTimer) clearTimeout(reconnectTimer);
      if (channel) supabase.removeChannel(channel);
    };
  // fetchData, showToast, hapticFeedback, notifyNewOrder are excluded — they change
  // reference on every render. The semantic dependencies are user.id and storeData.id.
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user?.id, storeData?.id]);

  return {
    user,
    loading,
    storeData,
    products,
    vendorStats,
    aggregatedMetrics,
    userRole,
    setProducts,
    setStoreData,
    refresh: fetchData
  };
}
