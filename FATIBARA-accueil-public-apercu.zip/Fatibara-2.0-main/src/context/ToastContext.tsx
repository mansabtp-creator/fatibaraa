import React, { createContext, useContext, useEffect, useCallback } from 'react';
import { Toaster, toast } from 'sonner';

// ─── Types ────────────────────────────────────────────────────────────────────
// Added 'warning' to the union so callers can surface amber-tinted warnings
// distinctly from errors.

type ToastType = 'success' | 'error' | 'info' | 'warning';

const ToastContext = createContext<{
  showToast: (message: string, type: ToastType) => void;
} | null>(null);

// ─── Responsive position helper ───────────────────────────────────────────────
// On mobile (< 768 px) toasts appear at the top so they don't overlap the
// 56 px BottomNav bar.  On tablet/desktop they stay at bottom-right where
// they're least intrusive.
function getToastPosition(): 'top-center' | 'bottom-right' {
  if (typeof window === 'undefined') return 'bottom-right';
  return window.innerWidth < 768 ? 'top-center' : 'bottom-right';
}

// ─── Provider ─────────────────────────────────────────────────────────────────

export function ToastProvider({ children }: { children: React.ReactNode }) {
  const [position, setPosition] = React.useState<'top-center' | 'bottom-right'>(getToastPosition);

  // Re-evaluate position when the viewport is resized (e.g. orientation change)
  useEffect(() => {
    const handleResize = () => setPosition(getToastPosition());
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  // Recommendation: wrap showToast in useCallback for a stable reference so
  // consumers don't need eslint-disable in their useEffect dependency arrays.
  const showToast = useCallback((message: string, type: ToastType) => {
    switch (type) {
      case 'success':
        toast.success(message, { duration: 4000 });
        break;
      case 'error':
        toast.error(message, { duration: 5000 }); // errors stay slightly longer
        break;
      case 'warning':
        toast.warning(message, { duration: 4500 });
        break;
      case 'info':
        toast.info(message, { duration: 4000 });
        break;
      default:
        toast(message, { duration: 4000 });
    }
  }, []);

  // Allow other parts of the app to fire info toasts via a DOM event
  // (useful from non-React contexts like service workers).
  useEffect(() => {
    const handleAlert = (event: Event) => {
      const customEvent = event as CustomEvent;
      showToast(customEvent.detail || 'Information', 'info');
    };
    window.addEventListener('app-alert', handleAlert);
    return () => window.removeEventListener('app-alert', handleAlert);
  }, [showToast]);

  return (
    <ToastContext.Provider value={{ showToast }}>
      {children}
      <Toaster
        position={position}
        // 'system' honours the OS/browser dark-mode preference so toasts are
        // always legible regardless of which colour scheme the user has chosen.
        theme="system"
        richColors
        closeButton
        expand={false}
        // On mobile: 16 px from the top edge (below the status bar).
        // On desktop: 80 px from the bottom to clear the BottomNav on any
        // accidental desktop-mobile layout bleed.
        offset={position === 'top-center' ? 16 : 80}
        toastOptions={{
          style: {
            borderRadius: '1rem',
            padding: '0.875rem 1rem',
            fontSize: '0.875rem',
            fontWeight: 600,
            boxShadow:
              '0 20px 25px -5px rgb(0 0 0 / 0.15), 0 8px 10px -6px rgb(0 0 0 / 0.1)',
          },
        }}
      />
    </ToastContext.Provider>
  );
}

// ─── Hook ─────────────────────────────────────────────────────────────────────

export const useToast = () => {
  const context = useContext(ToastContext);
  if (!context) throw new Error('useToast must be used within a ToastProvider');
  return context;
};
