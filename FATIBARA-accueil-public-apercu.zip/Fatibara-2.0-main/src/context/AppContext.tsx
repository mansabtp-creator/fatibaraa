import { createContext, useContext, useState, useEffect, useRef, ReactNode } from 'react';
import { Promotion, promotionService } from '../services/promotionService';
import { supabase, safeSupabaseQuery, validateSessionOrClear, safeSignOut } from '../lib/supabase';
import { User } from '@supabase/supabase-js';
import { useCommerceStore } from '../store/useCommerceStore';
import { useStore } from '../store/useStore';

import { APP_NAME } from '../lib/constants';

type Currency = 'GNF' | 'EUR' | 'USD';

export interface SavedAddress {
  region: string;
  commune: string;
  quartier: string;
  indications: string;
  phone: string;
}

interface AppContextType {
  isOffline: boolean;
  isAuthLoading: boolean;
  /**
   * `true` only after both Supabase auth.getSession() AND the subsequent
   * profiles table fetch have completed (success or failure). Use this —
   * not `isAuthLoading` — to gate route guard decisions so they never fire
   * while the profile/role is still being fetched.
   */
  isProfileReady: boolean;
  user: User | null;
  profileType: string | null;
  activeRole: string;
  allowedRoles: string[];
  switchRole: (role: string) => Promise<void>;
  proMode: boolean;
  setProMode: (val: boolean) => void;
  currency: Currency;
  setCurrency: (c: Currency) => void;
  followedVendors: string[];
  toggleFollowVendor: (vendor: string) => void;
  walletBalance: number;
  setWalletBalance: (balance: number) => void;
  loyaltyPoints: number;
  referralCode: string | null;
  courierStatus: string | null;
  refreshProfile: () => Promise<void>;
  savedAddress: SavedAddress | null;
  setSavedAddress: (address: SavedAddress | null) => void;
  unreadMessagesCount: number;
  isChatOpen: boolean;
  setIsChatOpen: (val: boolean) => void;
  chatStoreId: string | null;
  chatUserId: string | null;
  openChat: (storeId: string, productTitle?: string, userId?: string) => Promise<void>;
  activePromotions: any[];
}

const AppContext = createContext<AppContextType>({
  isOffline: false,
  isAuthLoading: true,
  isProfileReady: false,
  user: null,
  profileType: null,
  activeRole: '',
  allowedRoles: [],
  switchRole: async () => {},
  proMode: false,
  setProMode: () => {},
  currency: 'GNF',
  setCurrency: () => {},
  followedVendors: [],
  toggleFollowVendor: () => {},
  walletBalance: 0,
  setWalletBalance: () => {},
  loyaltyPoints: 0,
  referralCode: null,
  courierStatus: null,
  refreshProfile: async () => {},
  savedAddress: null,
  setSavedAddress: () => {},
  unreadMessagesCount: 0,
  isChatOpen: false,
  setIsChatOpen: () => {},
  chatStoreId: null,
  chatUserId: null,
  openChat: async () => {},
  activePromotions: [],
});

export function AppProvider({ children }: { children: ReactNode }) {
  const [isOffline, setIsOffline] = useState(false);
  const [isAuthLoading, setIsAuthLoading] = useState(true);
  // Becomes true only after fetchProfile() fully settles — use this to gate
  // route guards so they never evaluate while the role/profile is still loading.
  const [isProfileReady, setIsProfileReady] = useState(false);
  const [user, setUser] = useState<User | null>(null);
  const [profileType, setProfileType] = useState<string | null>(null);
  const [activeRole, setActiveRole] = useState<string>('');
  const [allowedRoles, setAllowedRoles] = useState<string[]>([]);
  const [proMode, setProMode] = useState(false);
  const [currency, setCurrency] = useState<Currency>('GNF');
  const [followedVendors, setFollowedVendors] = useState<string[]>([]);
  const [walletBalance, setWalletBalance] = useState(0);
  const [loyaltyPoints, setLoyaltyPoints] = useState(0);
  const [referralCode, setReferralCode] = useState<string | null>(null);
  const [courierStatus, setCourierStatus] = useState<string | null>(null);
  const [savedAddress, setSavedAddress] = useState<SavedAddress | null>(null);
  const [unreadMessagesCount, setUnreadMessagesCount] = useState(0);
  const [isChatOpen, setIsChatOpen] = useState(false);
  const [chatStoreId, setChatStoreId] = useState<string | null>(null);
  const [chatUserId, setChatUserId] = useState<string | null>(null);
  const [activePromotions, setActivePromotions] = useState<any[]>([]);

  // ── In-flight guards ────────────────────────────────────────────────────────
  // useRef preserves the flag across renders without triggering re-renders.
  // A plain object literal `{ current: false }` is recreated on every render
  // so the guard never actually prevents duplicate calls.
  const isFetchingProfileRef = useRef(false);
  const isFetchingUnreadRef  = useRef(false);
  // Holds the live profiles-row subscription so we can tear it down on
  // sign-out or unmount without leaking a Supabase realtime channel.
  const walletChannelRef = useRef<ReturnType<typeof supabase.channel> | null>(null);
  const unreadChannelRef = useRef<ReturnType<typeof supabase.channel> | null>(null);


  useEffect(() => {
    let isMounted = true;
    // Set initial state
    setIsOffline(!navigator.onLine);

    const handleOnline = () => { if (isMounted) setIsOffline(false); };
    const handleOffline = () => { if (isMounted) setIsOffline(true); };

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    // Fetch active promotions
    promotionService.getActivePromotions()
      .then(promos => { if (isMounted) setActivePromotions(promos); })
      .catch(console.error);

    // Auth state with timeout
    const fetchSessionWithTimeout = async () => {
      const timeoutPromise = new Promise((_, reject) => 
        setTimeout(() => reject(new Error('Session fetch timeout')), 3000)
      );

      try {
        const result = await Promise.race([
          supabase.auth.getSession(),
          timeoutPromise
        ]) as { data: { session: any }, error: any };
        
        const { data: { session }, error } = result;

        if (error) {
          console.warn("Session error:", error.message);
          if (error.message.includes('Refresh Token') || error.message.includes('invalid refresh token') || error.message.includes('recursion')) {
            console.log("Invalid session state, clearing session.");
            setUser(null);
            setProfileType(null);
            safeSignOut();
          }
        }
        const activeUser = session?.user ?? null;
        setUser(activeUser);
        if (activeUser) {
          // A user can sign in after the anonymous app has already finished
          // booting. Reset this gate before fetching their profile so LoginPage
          // cannot redirect with the previous empty/default role.
          setIsProfileReady(false);
          fetchProfile(activeUser.id, activeUser.email);
          fetchUnreadMessagesCount(activeUser.id);
          useCommerceStore.getState().syncWithCloud(activeUser.id);

          // Start the live wallet subscription on initial load so returning
          // users (already logged in when they open the app) also get instant
          // balance updates in the Header without a page refresh.
          if (walletChannelRef.current) {
            supabase.removeChannel(walletChannelRef.current);
          }
          walletChannelRef.current = supabase
            .channel(`ctx_wallet_${activeUser.id}`)
            .on('postgres_changes', {
              event: 'UPDATE',
              schema: 'public',
              table: 'profiles',
              filter: `id=eq.${activeUser.id}`,
            }, (payload) => {
              if (payload.new?.wallet_balance !== undefined) {
                setWalletBalance(payload.new.wallet_balance as number);
              }
              if (payload.new?.loyalty_points !== undefined) {
                setLoyaltyPoints(payload.new.loyalty_points as number);
              }
            })
            .subscribe();
        } else {

          setProfileType(null);
          // No user — profile is as ready as it will ever be (empty)
          setIsProfileReady(true);
        }
      } catch (err: any) {
        console.warn("Error fetching session:", err);
        // Fallback to unauthenticated mode
        setUser(null);
        setProfileType(null);
        setIsProfileReady(true);
      } finally {
        setIsAuthLoading(false);
      }
    };

    fetchSessionWithTimeout();

    const { data: { subscription } } = supabase.auth.onAuthStateChange((event, session) => {
      // INITIAL_SESSION fires synchronously on subscribe — fetchSessionWithTimeout()
      // above already handles this exact session object.  Processing it a second
      // time would fire duplicate `stores` queries and hit any remaining RLS
      // recursion guards, producing the triple-406 pattern seen on app mount.
      if (event === 'INITIAL_SESSION') return;

      if (event === 'SIGNED_OUT') {
        setUser(null);
        setProfileType(null);
        setActiveRole('');
        setAllowedRoles([]);
        setFollowedVendors([]);
        setWalletBalance(0);
        setLoyaltyPoints(0);
        setReferralCode(null);
        setCourierStatus(null);
        setProMode(false);
        setUnreadMessagesCount(0);
        setIsAuthLoading(false);
        // An unauthenticated user's profile is settled (empty state)
        // so route guards and RoleRedirect immediately render the public storefront
        setIsProfileReady(true);
        // Tear down the live wallet channel on sign-out
        if (walletChannelRef.current) {
          supabase.removeChannel(walletChannelRef.current);
          walletChannelRef.current = null;
        }
        if (unreadChannelRef.current) {
          supabase.removeChannel(unreadChannelRef.current);
          unreadChannelRef.current = null;
        }
        return;
      }
      
      const activeUser = session?.user ?? null;
      setUser(activeUser);
      if (activeUser) {
        // `SIGNED_IN` can arrive after anonymous boot completed, leaving this
        // true from the previous session. Hold route redirects until the new
        // user's role/profile has been resolved.
        setIsProfileReady(false);
        fetchProfile(activeUser.id, activeUser.email);
        fetchUnreadMessagesCount(activeUser.id);
        useCommerceStore.getState().syncWithCloud(activeUser.id);

        // Live wallet balance — subscribe to the user's profiles row so that
        // any RPC that updates wallet_balance (top-up, refund, loyalty credit)
        // is immediately reflected in the Header and Hero without a page refresh.
        if (walletChannelRef.current) {
          supabase.removeChannel(walletChannelRef.current);
        }
        walletChannelRef.current = supabase
          .channel(`ctx_wallet_${activeUser.id}`)
          .on('postgres_changes', {
            event: 'UPDATE',
            schema: 'public',
            table: 'profiles',
            filter: `id=eq.${activeUser.id}`,
          }, (payload) => {
            if (payload.new?.wallet_balance !== undefined) {
              setWalletBalance(payload.new.wallet_balance as number);
            }
            if (payload.new?.loyalty_points !== undefined) {
              setLoyaltyPoints(payload.new.loyalty_points as number);
            }
          })
          .subscribe();
      } else {
        setProfileType(null);
        setProMode(false);
        setUnreadMessagesCount(0);
      }
    });

    return () => {
      isMounted = false;
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
      subscription.unsubscribe();
      if (walletChannelRef.current) {
        supabase.removeChannel(walletChannelRef.current);
        walletChannelRef.current = null;
      }
      if (unreadChannelRef.current) {
        supabase.removeChannel(unreadChannelRef.current);
        unreadChannelRef.current = null;
      }
    };
  }, []);

  useEffect(() => {
    if (!user?.id) return;
    
    if (unreadChannelRef.current) {
      supabase.removeChannel(unreadChannelRef.current);
    }
    
    unreadChannelRef.current = supabase
      .channel(`unread-count-${user.id}`)
      .on('postgres_changes', {
        event: 'INSERT',
        schema: 'public',
        table: 'chat_messages'
      }, () => {
        fetchUnreadMessagesCount(user.id);
      })
      .subscribe();
      
    return () => {
      if (unreadChannelRef.current) {
        supabase.removeChannel(unreadChannelRef.current);
        unreadChannelRef.current = null;
      }
    };
  }, [user?.id]);


  const fetchUnreadMessagesCount = async (userId: string) => {
    // ── In-flight guard ───────────────────────────────────────────────────────
    if (isFetchingUnreadRef.current) {
      console.debug('[fetchUnreadMessages] Already in-flight — skipping duplicate call.');
      return;
    }
    isFetchingUnreadRef.current = true;

    try {
      // ── Session guard ─────────────────────────────────────────────────────────
      // Validate the JWT *before* hitting the stores table.  A stale or
      // structurally broken token causes PostgREST to return HTTP 406 (content-
      // negotiation failure) which blocks the entire real-time init flow.
      const session = await validateSessionOrClear();
      if (!session) {
        console.warn('[fetchUnreadMessages] No valid session — skipping stores query to prevent HTTP 406.');
        setUnreadMessagesCount(0);
        return;
      }

      // 1. Get owned stores
      const { data: stores, error: storesError } = await supabase
        .from('stores')
        .select('id')
        .eq('owner_id', userId);

      // ── 406 / error guard ─────────────────────────────────────────────────
      // HTTP 406 on the stores table is almost always caused by a recursive
      // RLS policy (a policy that subqueries `stores` itself), NOT by a bad JWT.
      // The permanent fix is to run the flat-policy SQL migration and then:
      //   NOTIFY pgrst, 'reload schema';
      // The session probe below is still useful to rule out token corruption.
      if (storesError) {
        const code = storesError.code as string | undefined;
        const msg  = storesError.message as string | undefined;
        if (code === '406' || msg?.toLowerCase().includes('not acceptable')) {
          console.error(
            '[fetchUnreadMessages] HTTP 406 on stores query. ' +
            'JWT may be corrupted or PostgREST schema cache is stale. ' +
            'Triggering session validation.',
            storesError
          );
          const freshSession = await validateSessionOrClear();
          if (!freshSession) {
            console.warn(
              '[Auth] Session cleared after 406 — user will need to re-authenticate. ' +
              'If this persists, run: NOTIFY pgrst, \'reload schema\' on the database.'
            );
          }
        } else {
          console.error('[fetchUnreadMessages] stores query error:', storesError);
        }
        setUnreadMessagesCount(0);
        return;
      }

      const storeIds = stores?.map(s => s.id) || [];

      // 2. Find channels where user is buyer OR store owner
      const query = supabase.from('chat_channels').select('id');
      
      if (storeIds.length > 0) {
        query.or(`buyer_id.eq.${userId},store_id.in.(${storeIds.join(',')})`);
      } else {
        query.eq('buyer_id', userId);
      }

      const { data: convoData } = await query;
      const convoIds = convoData?.map(c => c.id) || [];
      
      if (convoIds.length === 0) {
        setUnreadMessagesCount(0);
        return;
      }

      const { count } = await supabase
        .from('chat_messages')
        .select('*', { count: 'exact', head: true })
        .in('channel_id', convoIds)
        .eq('is_read', false)
        .neq('sender_id', userId);
      
      setUnreadMessagesCount(count || 0);

    } catch (err) {
      console.error('[fetchUnreadMessages] Unexpected error:', err);
    } finally {
      isFetchingUnreadRef.current = false;
    }
  };

  const fetchProfile = async (userId: string, email?: string) => {
    // ── In-flight guard ───────────────────────────────────────────────────────
    if (isFetchingProfileRef.current) {
      console.debug('[fetchProfile] Already in-flight — skipping duplicate call.');
      return;
    }
    isFetchingProfileRef.current = true;

    try {
      let data = null;
      let error = null;
      
      // Retry loop to handle slow DB trigger on first sign-in
      for (let i = 0; i < 3; i++) {
        const result = await safeSupabaseQuery<{
          is_pro_member: boolean;
          is_admin: boolean;
          profile_type: string | null;
          active_role: string | null;
          roles: string[] | null;
          wallet_balance: number;
          loyalty_points: number;
          referral_code: string;
          courier_status: string | null;
          saved_address: any;
          followed_vendors: string[];
          full_name: string | null;
          avatar_url: string | null;
        }>(
          supabase
            .from('profiles')
            .select('is_pro_member, is_admin, profile_type, active_role, roles, wallet_balance, loyalty_points, referral_code, courier_status, saved_address, followed_vendors, full_name, avatar_url')
            .eq('id', userId)
            .maybeSingle()
        );
        
        if (result.data) {
          data = result.data;
          error = result.error;
          break;
        }
        
        if (i < 2) {
          await new Promise(r => setTimeout(r, 800));
        }
      }
      
      if (!error && data) {
        // Admin status is read from the database only (is_admin column OR profile_type='admin').
        // The is_admin() SQL function now checks both. No email-based fallback needed.
        const isAdmin = data.is_admin || data.profile_type === 'admin';

        if (data.followed_vendors) {
          setFollowedVendors(data.followed_vendors);
        }
        
        const { data: storesData, error: storesDataError } = await supabase
          .from('stores')
          .select('id, is_verified_store')
          .eq('owner_id', userId);
        if (storesDataError) {
          const code = storesDataError.code as string | undefined;
          const msg  = storesDataError.message as string | undefined;
          if (code === '406' || msg?.toLowerCase().includes('not acceptable')) {
            console.error(
              '[fetchProfile] HTTP 406 on stores sub-query — possible JWT corruption or schema-cache mismatch.',
              storesDataError
            );
            validateSessionOrClear();
          } else {
            console.error('[fetchProfile] stores sub-query error:', storesDataError);
          }
        }
        const isVendor = storesData && storesData.length > 0;
        const isVerifiedVendor = isVendor ? storesData[0].is_verified_store : false;

        // ── Role Resolution ─────────────────────────────────────────────────
        // Priority: explicit DB profile_type > vendor store presence > pro flag
        // 'vendor' is checked both via store presence (isVendor) AND via the
        // DB profile_type column so that a 406 on the stores query does not
        // accidentally demote a vendor to 'standard'.
        const dbRole = data.profile_type;
        const pType = isAdmin
          ? 'admin'
          : isVendor || dbRole === 'vendor'
          ? 'vendor'
          : dbRole === 'courier'
          ? 'courier'
          : data.is_pro_member
          ? 'pro'
          : 'standard';
        
        setProfileType(pType);

        // ── Multi-Role Context ───────────────────────────────────────────────
        // active_role: the DB-persisted currently-active context.
        // If not yet backfilled (old rows), fall back to the resolved pType.
        const dbActiveRole = data.active_role ?? pType;
        const dbRoles = data.roles ?? [pType];
        setActiveRole(dbActiveRole);
        setAllowedRoles(dbRoles);

        // Update userProfile in useStore as well (includes display fields so
        // Hero can read full_name / avatar_url without a separate DB query)
        useStore.getState().setUserProfile({
          id: userId,
          is_admin: isAdmin,
          profile_type: pType,
          full_name: (data as any).full_name ?? undefined,
          avatar_url: (data as any).avatar_url ?? undefined,
        });

        if (data.wallet_balance !== undefined) {
          setWalletBalance(data.wallet_balance);
        }
        if (data.loyalty_points !== undefined) {
          setLoyaltyPoints(data.loyalty_points);
        }
        if (data.referral_code) {
          setReferralCode(data.referral_code);
        } else {
          // Generate a real referral code and save it permanently
          const newReferralCode = `ELITE-${userId.substring(0, 5).toUpperCase()}`;
          setReferralCode(newReferralCode);
          supabase.from('profiles').update({ referral_code: newReferralCode }).eq('id', userId);
        }

        setCourierStatus(data.courier_status);

        if (data.saved_address) {
          try {
            setSavedAddress(typeof data.saved_address === 'string' ? JSON.parse(data.saved_address) : data.saved_address);
          } catch (e) {
            console.error("Could not parse saved address", e);
          }
        }
      } else {
        // A valid authenticated session was established, but the profile row is not yet created.
        // Auto-provision initial profile so Google OAuth & new sign-ins do not get trapped in a sign-out loop.
        console.log('[fetchProfile] Profile row missing for authenticated user. Auto-provisioning:', userId);

        const { data: authSession } = await supabase.auth.getSession();
        const authUser = authSession?.session?.user;
        const meta = authUser?.user_metadata || {};
        const newReferralCode = `ELITE-${userId.substring(0, 5).toUpperCase()}`;
        const displayName = meta.full_name || meta.name || email?.split('@')[0] || 'Utilisateur';
        const avatarUrl = meta.avatar_url || meta.picture || null;
        const isUserAdmin = email === 'fatibara.gn@gmail.com' || email === 'elsmartconde@gmail.com';

        const profilePayload = {
          id: userId,
          full_name: displayName,
          avatar_url: avatarUrl,
          referral_code: newReferralCode,
          profile_type: isUserAdmin ? 'admin' : 'client',
          is_admin: isUserAdmin,
          is_pro_member: false,
          wallet_balance: 0,
          loyalty_points: 0,
        };

        try {
          const { error: upsertErr } = await supabase.from('profiles').upsert(profilePayload);
          if (upsertErr) {
            console.warn('[fetchProfile] Profile auto-provision DB warn:', upsertErr.message);
          }
        } catch (provisionErr) {
          console.warn('[fetchProfile] Profile auto-provision exception:', provisionErr);
        }

        const fallbackRole = isUserAdmin ? 'admin' : 'client';
        setProfileType(isUserAdmin ? 'admin' : 'standard');
        setActiveRole(fallbackRole);
        setAllowedRoles([fallbackRole]);
        setReferralCode(newReferralCode);
        setWalletBalance(0);
        setLoyaltyPoints(0);

        useStore.getState().setUserProfile({
          id: userId,
          is_admin: isUserAdmin,
          profile_type: isUserAdmin ? 'admin' : 'standard',
          full_name: displayName,
          avatar_url: avatarUrl || undefined,
        });
      }
    } catch (err) {
      console.error('Error fetching profile:', err);
      setReferralCode(`ELITE-DEMO`);
      setProfileType('pro');
    } finally {
      isFetchingProfileRef.current = false;
      // Mark profile as settled — route guards may now evaluate safely
      setIsProfileReady(true);
    }
  };

  const refreshProfile = async () => {
    let currentUser = user;
    if (!currentUser) {
       const { data } = await supabase.auth.getSession();
       currentUser = data?.session?.user || null;
    }
    if (currentUser) {
      await fetchProfile(currentUser.id, currentUser.email);
    }
  };

  const switchRole = async (targetRole: string) => {
    try {
      const { error } = await supabase.rpc('switch_active_role', { p_target_role: targetRole });
      if (error) throw error;
      setActiveRole(targetRole);
    } catch (err: any) {
      console.error('[switchRole] Failed:', err.message);
      throw err; // Let the UI show a toast
    }
  };

  const toggleFollowVendor = async (vendorId: string) => {
    if (!user) return;
    
    const isCurrentlyFollowed = followedVendors.includes(vendorId);
    const newFollowed = isCurrentlyFollowed 
      ? followedVendors.filter(id => id !== vendorId)
      : [...followedVendors, vendorId];
      
    setFollowedVendors(newFollowed);
    
    try {
      await supabase
        .from('profiles')
        .update({ followed_vendors: newFollowed })
        .eq('id', user.id);
    } catch (err) {
      console.error("Error updating followed vendors", err);
    }
  };

  const openChat = async (storeId: string, productTitle?: string, userId?: string, productId?: string) => {
    if (!user) return;
    if (!storeId) return;

    // Open immediately so the user sees the messenger right away
    setChatStoreId(storeId);
    setChatUserId(userId || null);
    setIsChatOpen(true);

    try {
      const buyerId = userId || user.id;

      // Check if channel already exists
      const { data: existing, error: fetchError } = await supabase
        .from('chat_channels')
        .select('id')
        .eq('store_id', storeId)
        .eq('buyer_id', buyerId)
        .maybeSingle();

      if (fetchError) {
        console.error('openChat: fetch error', fetchError);
        return;
      }

      if (!existing) {
        // Create — ignore 23505 unique conflict (race condition)
        const { error: createError } = await supabase
          .from('chat_channels')
          .insert([{ buyer_id: buyerId, store_id: storeId, product_id: productId || null }]);
        if (createError && createError.code !== '23505') {
          console.error('openChat: channel create error', createError);
        }
      } else if (productId && existing.id) {
        await supabase
          .from('chat_channels')
          .update({ product_id: productId })
          .eq('id', existing.id);
      }
    } catch (err) {
      console.error('openChat: unexpected error', err);
    }
  };

  return (
    <AppContext.Provider value={{ 
      isOffline, isAuthLoading, isProfileReady, user, profileType,
      activeRole, allowedRoles, switchRole,
      proMode, setProMode,
      currency, setCurrency, followedVendors, toggleFollowVendor, 
      walletBalance, setWalletBalance,
      loyaltyPoints, referralCode, courierStatus,
      refreshProfile,
      savedAddress, setSavedAddress,
      unreadMessagesCount,
      isChatOpen, setIsChatOpen,
      chatStoreId, chatUserId, openChat,
      activePromotions
    }}>
      {children}
    </AppContext.Provider>
  );
}

export const useAppContext = () => useContext(AppContext);
