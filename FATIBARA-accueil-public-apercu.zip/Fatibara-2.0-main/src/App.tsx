/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { ToastProvider } from './context/ToastContext';
import { BrowserRouter, Routes, Route, useLocation, Navigate, useNavigate, useParams } from 'react-router-dom';

import { AnimatePresence, motion } from 'motion/react';
// import { useRegisterSW } from 'virtual:pwa-register/react';
import React, { Suspense, lazy, useEffect } from 'react';

// Vercel analytics stubbed for non-Vercel environment
const Analytics = () => null;
const SpeedInsights = () => null;


// Resilient lazy-loader with automatic retry on chunk load failure
function lazyWithRetry<T extends React.ComponentType<any>>(
  componentImport: () => Promise<{ default: T }>
) {
  return lazy(async () => {
    try {
      return await componentImport();
    } catch (error: any) {
      console.warn('[App] Dynamic import failed, retrying once...', error);
      await new Promise(resolve => setTimeout(resolve, 250));
      return await componentImport();
    }
  });
}

// Lazy load components
const HomePage = lazyWithRetry(() => import('./app/page'));
const ProductPage = lazyWithRetry(() => import('./pages/ProductPage'));
const CheckoutPage = lazyWithRetry(() => import('./pages/CheckoutPage'));
const PaymentResultPage = lazyWithRetry(() => import('./pages/PaymentResultPage'));
const CartCheckoutPage = lazyWithRetry(() => import('./pages/CartCheckoutPage'));
const DashboardPage = lazyWithRetry(() => import('./pages/DashboardPage'));
const OrdersPage = lazyWithRetry(() => import('./pages/OrdersPage'));
const VendorDashboard = lazyWithRetry(() => import('./pages/vendor/Dashboard'));
const VendorProducts = lazyWithRetry(() => import('./pages/vendor/Products'));
const VendorOrders = lazyWithRetry(() => import('./pages/vendor/Orders'));
const VendorFinances = lazyWithRetry(() => import('./pages/vendor/Finances'));
const VendorAnalytics = lazyWithRetry(() => import('./pages/vendor/Analytics'));
const VendorInbox = lazyWithRetry(() => import('./pages/vendor/Inbox'));
const VendorMarketing = lazyWithRetry(() => import('./pages/vendor/Marketing'));
const VendorSettings = lazyWithRetry(() => import('./pages/vendor/Settings'));
const VendorRegistrationPage = lazyWithRetry(() => import('./pages/VendorRegistrationPage'));
const LoginPage = lazyWithRetry(() => import('./pages/LoginPage'));
const SearchPage = lazyWithRetry(() => import('./pages/SearchPage'));
const ShopPage = lazyWithRetry(() => import('./pages/ShopPage'));
const HelpPage = lazyWithRetry(() => import('./pages/HelpPage'));
const TermsPage = lazyWithRetry(() => import('./pages/TermsPage'));
const PrivacyPolicyPage = lazyWithRetry(() => import('./pages/PrivacyPolicyPage'));
const StoreProfilePage = lazyWithRetry(() => import('./pages/StoreProfilePage'));
const AdminDashboardPage = lazyWithRetry(() => import('./pages/AdminDashboardPage'));
const CourierDashboardPage = lazyWithRetry(() => import('./pages/CourierDashboardPage'));
const CourierOnboardingPage = lazyWithRetry(() => import('./pages/CourierOnboardingPage'));
const AboutPage = lazyWithRetry(() => import('./pages/AboutPage'));
const NotFoundPage = lazyWithRetry(() => import('./pages/NotFoundPage'));

import { ErrorBoundary } from './components/ErrorBoundary';
import { InlineBoundary } from './components/ErrorBoundary';
import OfflineBanner from './components/OfflineBanner';
import PageTransition from './components/PageTransition';
import TopLoadingBar from './components/TopLoadingBar';
import BottomNav from './components/BottomNav';
import VendorLayout from './components/VendorLayout';
import ChatMessenger from './components/ChatMessenger';
import AIStyleAdvisor from './components/AIStyleAdvisor';
import CategoryBar from './components/CategoryBar';
import ProtectedRoute from './components/ProtectedRoute';
// Non-critical shell components — lazy-loaded so they don’t block the
// initial paint. Both are small but their transitive imports add JS parse time.
const AnnouncementBanner = lazyWithRetry(() => import('./components/AnnouncementBanner'));
const PWAInstallModal    = lazyWithRetry(() => import('./components/PWAInstallModal'));
import { RefreshCw, X, MessageCircle } from 'lucide-react';
import { useAppContext } from './context/AppContext';
import { getHomeRouteForRole, isRouteAllowedForRole } from './utils/routes';

// PwaReloadPrompt was removed — to re-enable, integrate useRegisterSW from
// 'virtual:pwa-register/react' and render a toast/banner on needRefresh.


function StoreRedirect() {
  const { storeName } = useParams();
  return <Navigate to={`/boutique/${storeName}`} replace />;
}

// ─── Role Guard ──────────────────────────────────────────────────────────────
// Enforces strict route-level isolation based on the user's *active* role
// context rather than their profile_type. Waits for isProfileReady to avoid
// premature redirects while the profile/role is still being fetched from DB.
function RoleGuard() {
  const { activeRole, isAuthLoading, isProfileReady } = useAppContext();
  const navigate = useNavigate();
  const location = useLocation();

  useEffect(() => {
    // Wait until both Supabase session check AND profile fetch are complete.
    // isProfileReady is the definitive gate — isAuthLoading alone is insufficient
    // because fetchProfile() is async and runs after isAuthLoading becomes false.
    if (isAuthLoading || !isProfileReady) return;
    // No user / buyer-mode — nothing to enforce beyond public route access
    if (!activeRole) return;

    const { pathname } = location;
    const allowed = isRouteAllowedForRole(pathname, activeRole);

    if (!allowed) {
      navigate(getHomeRouteForRole(activeRole), { replace: true });
    }
  }, [activeRole, isAuthLoading, isProfileReady, location.pathname, navigate]);

  return null;
}

// ─── Role Redirect ────────────────────────────────────────────────────────────
// Wraps the homepage "/" route. While the profile is still loading it shows a
// spinner (prevents a flash of the storefront for courier / vendor / admin users).
// Once isProfileReady is true it immediately redirects operational roles to their
// own dashboard — matching the same logic used by RoleGuard and LoginPage.
function RoleRedirect({ children }: { children: React.ReactNode }) {
  const { activeRole, isAuthLoading, isProfileReady } = useAppContext();

  // Still loading — show a neutral spinner instead of the storefront
  if (isAuthLoading || !isProfileReady) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-white dark:bg-gray-950">
        <div className="w-10 h-10 border border-[#ff6600] border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  // Profile settled — redirect operational roles to their dashboard
  const homeRoute = getHomeRouteForRole(activeRole);
  if (homeRoute !== '/') {
    return <Navigate to={homeRoute} replace />;
  }

  // Buyer / unauthenticated — render the storefront normally
  return <>{children}</>;
}

// Scroll to the top of the page on every route change.
// Placed inside BrowserRouter so useLocation is available.
function ScrollToTop() {
  const { pathname } = useLocation();
  useEffect(() => {
    window.scrollTo({ top: 0, left: 0, behavior: 'instant' });
  }, [pathname]);
  return null;
}

function AnimatedRoutes() {

  const location = useLocation();
  const { isChatOpen, setIsChatOpen, chatStoreId, chatUserId, activeRole, isProfileReady } = useAppContext();
  
  const isVendorRoute = location.pathname.startsWith('/vendor');
  const isAdminRoute = location.pathname.startsWith('/admin');
  const isCourierRoute = location.pathname.startsWith('/courier-dashboard') || location.pathname.startsWith('/livreur');
  const isCheckoutRoute = location.pathname.startsWith('/checkout');
  const isDashboardRoute = isAdminRoute || isCourierRoute || isCheckoutRoute;

  // Suppress storefront chrome for operational roles
  const isCustomerMode = isProfileReady && (activeRole === 'customer' || activeRole === '');

  return (
    <>
      {/* Global role guard — enforces route isolation per active role */}
      <RoleGuard />
      <AnimatePresence mode="wait">
        <Suspense fallback={
          <div className="min-h-screen flex items-center justify-center bg-white dark:bg-gray-950">
            <div className="w-10 h-10 border border-[#ff6600] border-t-transparent rounded-full animate-spin"></div>
          </div>
        }>
          {/* Routes uses location for AnimatePresence transitions — no key prop
              so React does NOT remount the full tree on every navigation. */}
          <Routes location={location}>
            <Route path="/" element={
              <RoleRedirect>
                <PageTransition><HomePage /></PageTransition>
              </RoleRedirect>
            } />
            <Route path="/product/:id" element={<PageTransition><ProductPage /></PageTransition>} />
            <Route path="/checkout/cart" element={<PageTransition><CartCheckoutPage /></PageTransition>} />
            <Route path="/checkout/:id" element={<PageTransition><CheckoutPage /></PageTransition>} />
            <Route path="/checkout/success/:id" element={<PageTransition><PaymentResultPage /></PageTransition>} />
            <Route path="/checkout/failure/:id" element={<PageTransition><PaymentResultPage /></PageTransition>} />

            {/* ── Client dashboard — any authenticated user ── */}
            <Route path="/dashboard" element={
              <ProtectedRoute>
                <PageTransition><DashboardPage /></PageTransition>
              </ProtectedRoute>
            } />
            <Route path="/orders" element={
              <ProtectedRoute>
                <PageTransition><OrdersPage /></PageTransition>
              </ProtectedRoute>
            } />
            <Route path="/orders/:id" element={
              <ProtectedRoute>
                <PageTransition><OrdersPage /></PageTransition>
              </ProtectedRoute>
            } />
            
            {/* ── Vendor dashboard routes — vendor + admin only ── */}
            <Route path="/vendor-dashboard" element={<Navigate to="/vendor/dashboard" replace />} />
            <Route path="/vendor/*" element={
              <ProtectedRoute allowedRoles={['vendor', 'admin']}>
                <VendorLayout>
                  <Routes>
                    <Route path="dashboard" element={<VendorDashboard />} />
                    <Route path="products" element={<VendorProducts />} />
                    <Route path="orders" element={<VendorOrders />} />
                    <Route path="analytics" element={<VendorAnalytics />} />
                    <Route path="marketing" element={<VendorMarketing />} />
                    <Route path="wallet" element={<VendorFinances />} />
                    <Route path="inbox" element={<VendorInbox />} />
                    <Route path="settings" element={<VendorSettings />} />
                    <Route path="*" element={<Navigate to="dashboard" replace />} />
                  </Routes>
                </VendorLayout>
              </ProtectedRoute>
            } />

            {/* ── Admin dashboard — admin only ── */}
            <Route path="/admin" element={<Navigate to="/admin/dashboard" replace />} />
            <Route path="/admin/dashboard" element={
              <ProtectedRoute allowedRoles={['admin']}>
                <PageTransition><AdminDashboardPage /></PageTransition>
              </ProtectedRoute>
            } />

            {/* ── Livreur / courier dashboard — courier + livreur + admin ── */}
            {/* Legacy redirect: /courier-dashboard → /livreur/dashboard */}
            <Route path="/courier-dashboard" element={<Navigate to="/livreur/dashboard" replace />} />
            <Route path="/livreur/dashboard" element={
              <ProtectedRoute allowedRoles={['courier', 'livreur', 'admin']}>
                <PageTransition><CourierDashboardPage /></PageTransition>
              </ProtectedRoute>
            } />
            <Route path="/courier-onboarding" element={
              <PageTransition><CourierOnboardingPage /></PageTransition>
            } />

            {/* ── Public routes ── */}
            <Route path="/vendor-registration" element={<PageTransition><VendorRegistrationPage /></PageTransition>} />
            <Route path="/login" element={<PageTransition><LoginPage /></PageTransition>} />
            <Route path="/search" element={<PageTransition><SearchPage /></PageTransition>} />
            <Route path="/shop" element={<PageTransition><ShopPage /></PageTransition>} />
            <Route path="/boutiques" element={<Navigate to="/shop" replace />} />
            <Route path="/store/:storeName" element={<StoreRedirect />} />
            <Route path="/boutique/:storeName" element={<PageTransition><StoreProfilePage /></PageTransition>} />
            <Route path="/join" element={<PageTransition><VendorRegistrationPage /></PageTransition>} />
            <Route path="/help" element={<PageTransition><HelpPage /></PageTransition>} />
            <Route path="/terms" element={<PageTransition><TermsPage /></PageTransition>} />
            <Route path="/privacy" element={<PageTransition><PrivacyPolicyPage /></PageTransition>} />
            <Route path="/about" element={<PageTransition><AboutPage /></PageTransition>} />
            {/* ── Account aliases — /account/* → /orders or /dashboard with appropriate tab ── */}
            <Route path="/account/orders" element={<Navigate to="/orders" replace />} />
            <Route path="/account/profile" element={<Navigate to="/dashboard?tab=profile" replace />} />
            <Route path="/account/settings" element={<Navigate to="/dashboard?tab=profile" replace />} />
            <Route path="/account/addresses" element={<Navigate to="/dashboard?tab=addresses" replace />} />
            <Route path="/account" element={<Navigate to="/dashboard" replace />} />
            {/* ── Wallet aliases — redirect legacy/explicit URLs to the wallet tab ── */}
            <Route path="/wallet" element={<Navigate to="/dashboard?tab=wallet" replace />} />
            <Route path="/account/wallet" element={<Navigate to="/dashboard?tab=wallet" replace />} />

            <Route path="*" element={<PageTransition><NotFoundPage /></PageTransition>} />
          </Routes>
        </Suspense>
      </AnimatePresence>
      
      {!isVendorRoute && !isDashboardRoute && isCustomerMode && <BottomNav />}
      

      {!isVendorRoute && !isDashboardRoute && isCustomerMode && (
        <InlineBoundary label="Chat — erreur de connexion">
          <ChatMessenger
            isOpen={isChatOpen}
            onClose={() => setIsChatOpen(false)}
            initialStoreId={chatStoreId || undefined}
            initialUserId={chatUserId || undefined}
          />
        </InlineBoundary>
      )}
      {!isVendorRoute && !isDashboardRoute && isCustomerMode && (
        <ErrorBoundary fallback={null}>
          <AIStyleAdvisor />
        </ErrorBoundary>
      )}
    </>
  );
}

export default function App() {
  return (
    <BrowserRouter>
      <ToastProvider>
        <ErrorBoundary>
          {/* Suspense required for lazy-loaded non-critical components.
              null fallback = renders nothing while the chunk loads, which is fine
              because these are decorative / install-prompt overlays. */}
          <Suspense fallback={null}><AnnouncementBanner /></Suspense>
          <TopLoadingBar />
          <OfflineBanner />
          {/* <PwaReloadPrompt /> */}

          <Suspense fallback={null}><PWAInstallModal /></Suspense>
          <ScrollToTop />
          <AnimatedRoutes />

          {/* ── Analytics & Performance Monitoring ────────────────────────── */}
          {/* Guard: /_vercel/insights/script.js only exists on Vercel infra.
               Running a local preview build (npm run preview) also has PROD=true
               but the scripts don't exist on localhost → HTML 404 → SyntaxError */}
          {import.meta.env.PROD &&
            typeof window !== 'undefined' &&
            !['localhost', '127.0.0.1', '0.0.0.0'].includes(window.location.hostname) && (
              <>
                <Analytics />
                <SpeedInsights />
              </>
            )}

        </ErrorBoundary>
      </ToastProvider>
    </BrowserRouter>
  );
}
