/**
 * contentSafety.ts
 *
 * Lightweight client-side safety filter for AI-generated text.
 *
 * This is a defence-in-depth layer — Gemini already applies safety filters
 * server-side (HARM_CATEGORY_*), but Gemini-Flash can occasionally produce
 * outputs that are promotional spam, contain prompt injections in the input,
 * or include language inappropriate for a family marketplace in Guinea.
 *
 * Two main checks:
 *   1. sanitizeAIOutput()  — clean and validate AI-generated descriptions
 *   2. sanitizeUserInput() — clean vendor-supplied text before sending to AI
 *
 * Both are pure functions with no external dependencies.
 */

// ─── Blocked keyword lists ────────────────────────────────────────────────────
// Keep short — Gemini filters most heavy content. This targets marketplace-
// specific risks: counterfeit claims, explicit content, illegal goods, spam.

const BLOCKED_PATTERNS: RegExp[] = [
  // Counterfeit / illegal
  /\b(contrefait|fake|replica|counterfeit|pirat[eé]|vol[eé])\b/i,
  // Explicit / adult
  /\b(xxx|porn|sexe|adulte|érotique|nude|nue)\b/i,
  // Drug references (Guinée context)
  /\b(cannabis|cocaïne|héroïne|drogue|stupéfiant)\b/i,
  // Prompt injection keywords (protect from jailbreak via product titles)
  /\bignore (previous|all|the above)\b/i,
  /\bforget (your|all|previous) instructions?\b/i,
  /\bsystem (prompt|instruction)\b/i,
  /\bact as (an? )?(un)restricted\b/i,
  // Arms / weapons
  /\b(kalash|arme à feu|fusil|pistolet|munition|explosif)\b/i,
  // Gambling
  /\b(casino|paris sportifs|bet[0-9]|1xbet|parieur)\b/i,
];

// Phrases that signal a low-quality or off-topic AI output
const QUALITY_CHECKS: RegExp[] = [
  /ignore previous instructions/i,
  /as an ai language model/i,
  /i cannot fulfill/i,
  /je ne peux pas/i,        // AI refusal in French
  /désolé, je suis/i,       // AI apology
  /\[PLACEHOLDER\]/i,
  /lorem ipsum/i,
];

// ─── Types ────────────────────────────────────────────────────────────────────

export interface SafetyResult {
  safe: boolean;
  text: string;
  reason?: string;
}

// ─── Main exports ─────────────────────────────────────────────────────────────

/**
 * Validates and sanitises AI-generated output before saving to the database.
 *
 * @param text   - The raw AI output string
 * @param maxLen - Maximum allowed length (default 800 for product descriptions)
 * @returns SafetyResult with cleaned text or flagged status
 */
export function sanitizeAIOutput(text: string, maxLen = 800): SafetyResult {
  if (!text || text.trim().length === 0) {
    return { safe: false, text: '', reason: 'empty_output' };
  }

  const trimmed = text.trim();

  // 1. Quality checks — detect AI refusals or off-topic outputs
  for (const pattern of QUALITY_CHECKS) {
    if (pattern.test(trimmed)) {
      return { safe: false, text: '', reason: 'ai_refusal_or_low_quality' };
    }
  }

  // 2. Block harmful content
  for (const pattern of BLOCKED_PATTERNS) {
    if (pattern.test(trimmed)) {
      return { safe: false, text: '', reason: 'blocked_content' };
    }
  }

  // 3. Length guard
  const clipped = trimmed.length > maxLen ? trimmed.slice(0, maxLen) + '…' : trimmed;

  // 4. Strip any residual markdown fences Gemini sometimes adds
  const clean = clipped
    .replace(/^```[\w]*\n?/gm, '')   // opening code fences
    .replace(/```\s*$/gm, '')         // closing code fences
    .replace(/^\*{1,2}|\*{1,2}$/gm, '') // stray bold markers at line start/end
    .trim();

  return { safe: true, text: clean };
}

/**
 * Sanitises user-supplied input (product title, category) BEFORE sending to
 * the AI. Strips potential prompt injection attempts.
 *
 * @param input - Raw user text
 * @param maxLen - Max characters to pass to AI (prevents token bloat)
 * @returns Cleaned input string
 */
export function sanitizeUserInput(input: string, maxLen = 200): string {
  if (!input) return '';

  let clean = input.trim();

  // Remove prompt injection attempts
  for (const pattern of BLOCKED_PATTERNS) {
    clean = clean.replace(pattern, '[FILTRÉ]');
  }

  // Strip control characters
  clean = clean.replace(/[\x00-\x1F\x7F]/g, '');

  // Truncate to max to avoid token stuffing
  return clean.slice(0, maxLen);
}

/**
 * Shorthand: run sanitizeAIOutput and return the cleaned text or a fallback.
 * Use this in service functions to keep one-liners clean.
 *
 * @param text     - Raw AI output
 * @param fallback - Value to return if content fails safety check
 */
export function safeAIText(text: string | undefined | null, fallback = ''): string {
  if (!text) return fallback;
  const result = sanitizeAIOutput(text);
  return result.safe ? result.text : fallback;
}
