/**
 * imageUtils.ts
 *
 * Supabase Storage image transform utilities.
 *
 * Supabase Storage supports on-the-fly image resizing via its render API:
 *   /storage/v1/render/image/public/<bucket>/<path>?width=W&quality=Q
 *
 * This is critical for Guinea's bandwidth-constrained mobile users:
 *   - ProductCard thumbnails: 400 px wide, 80% quality  (~15–30 kB vs 200–400 kB)
 *   - InventoryList thumbnails: 120 px wide, 70% quality (~5–10 kB)
 *   - ProductPage hero images: 800 px wide, 85% quality
 *
 * Non-Supabase URLs (Unsplash, picsum, etc.) are returned unchanged.
 *
 * Reference: https://supabase.com/docs/guides/storage/serving/image-transformations
 */

const STORAGE_OBJECT_PATH = '/storage/v1/object/public/';
const STORAGE_RENDER_PATH = '/storage/v1/render/image/public/';

export type ImageSize = 'thumb' | 'card' | 'hero' | 'full';

const SIZE_MAP: Record<ImageSize, { width: number; quality: number }> = {
  thumb: { width: 120, quality: 70 },  // Inventory list, avatar
  card:  { width: 400, quality: 80 },  // ProductCard grid
  hero:  { width: 800, quality: 85 },  // ProductPage main image
  full:  { width: 1200, quality: 90 }, // ProductPage zoom / lightbox
};

/**
 * Returns an optimised Supabase Storage image URL.
 *
 * @param url   - The original image URL (may be any source)
 * @param size  - Preset size key (thumb | card | hero | full)
 * @returns The transformed URL for Supabase Storage, or the original URL unchanged.
 */
export function getOptimisedImageUrl(
  url: string | undefined | null,
  size: ImageSize = 'card'
): string {
  if (!url) return '';

  // Supabase Image Transformation (/render/image/public/) requires a paid add-on.
  // Until that is activated on this project, serve the original CDN URL directly.
  // The /storage/v1/object/public/ URLs are already served via Cloudflare CDN and
  // are fast enough for Guinea's mobile network without server-side transforms.
  //
  // TO RE-ENABLE TRANSFORMS: uncomment the block below after activating the add-on
  // in Supabase Dashboard → Storage → Image Transformations.
  //
  // if (url.includes(STORAGE_OBJECT_PATH)) {
  //   const { width, quality } = SIZE_MAP[size];
  //   const transformedBase = url.replace(STORAGE_OBJECT_PATH, STORAGE_RENDER_PATH);
  //   const [baseUrl] = transformedBase.split('?');
  //   return `${baseUrl}?width=${width}&quality=${quality}&resize=contain`;
  // }

  return url;
}

/**
 * Convenience wrappers for common use-cases.
 */
export const thumbUrl = (url?: string | null) => getOptimisedImageUrl(url, 'thumb');
export const cardUrl  = (url?: string | null) => getOptimisedImageUrl(url, 'card');
export const heroUrl  = (url?: string | null) => getOptimisedImageUrl(url, 'hero');
export const fullUrl  = (url?: string | null) => getOptimisedImageUrl(url, 'full');
