// ALPHA NOTIFICATION ENGINE (PWA Support)
import { supabase } from '../lib/supabase';

/**
 * Fire-and-forget notification insert.
 * Silences 409 Conflict errors (FK violation when vendor user_id is not in profiles,
 * or rare duplicate inserts triggered by concurrent event listeners).
 */
export async function safeNotify(payload: {
  user_id: string;
  type: string;
  title: string;
  message: string;
}) {
  const { error } = await supabase.from('notifications').insert(payload);
  if (error && error.code !== '23505' && error.status !== 409) {
    // Only log truly unexpected errors; swallow FK/unique constraint violations
    console.warn('[safeNotify] notification insert failed:', error.message, error.code);
  }
}


export async function requestNotificationPermission() {
  if (!("Notification" in window)) {
    console.error("This browser does not support desktop notification");
    return false;
  }

  if (Notification.permission === "granted") return true;

  if (Notification.permission !== "denied") {
    const permission = await Notification.requestPermission();
    return permission === "granted";
  }

  return false;
}

export function sendLocalNotification(title: string, options?: any) {
  if (Notification.permission === "granted") {
    const defaultOptions = {
      icon: '/icons/icon-192x192.png',
      badge: '/icons/icon-96x96.png',
      vibrate: [200, 100, 200],
      ...options
    };
    
    // Check if we are in a service worker or window
    if ('serviceWorker' in navigator && navigator.serviceWorker.controller) {
      navigator.serviceWorker.ready.then(registration => {
        registration.showNotification(title, defaultOptions as any);
      });
    } else {
      new Notification(title, defaultOptions);
    }
  }
}

export function playCashRegisterSound() {
  try {
    const AudioContext = window.AudioContext || (window as any).webkitAudioContext;
    if (!AudioContext) return;
    
    const ctx = new AudioContext();
    const osc1 = ctx.createOscillator();
    const osc2 = ctx.createOscillator();
    const gainNode = ctx.createGain();
    
    osc1.connect(gainNode);
    osc2.connect(gainNode);
    gainNode.connect(ctx.destination);
    
    // "Cha" sound (mechanical hit)
    osc1.type = 'square';
    osc1.frequency.setValueAtTime(400, ctx.currentTime);
    osc1.frequency.exponentialRampToValueAtTime(100, ctx.currentTime + 0.1);
    
    // "Ching" sound (bell ring)
    osc2.type = 'sine';
    osc2.frequency.setValueAtTime(1200, ctx.currentTime + 0.1);
    osc2.frequency.exponentialRampToValueAtTime(3000, ctx.currentTime + 0.2);
    
    // Volume envelope
    gainNode.gain.setValueAtTime(0, ctx.currentTime);
    gainNode.gain.linearRampToValueAtTime(0.5, ctx.currentTime + 0.05); // Cha
    gainNode.gain.linearRampToValueAtTime(0.1, ctx.currentTime + 0.1);
    gainNode.gain.linearRampToValueAtTime(1, ctx.currentTime + 0.15); // Ching
    gainNode.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.8);
    
    osc1.start(ctx.currentTime);
    osc1.stop(ctx.currentTime + 0.1);
    
    osc2.start(ctx.currentTime + 0.1);
    osc2.stop(ctx.currentTime + 0.8);
  } catch (e) {
    console.warn("AudioContext not supported or blocked", e);
  }
}

// Logic to notify vendor of a new order
export function notifyNewOrder(orderId: string, amount: number) {
  playCashRegisterSound();
  
  sendLocalNotification("Nouvelle Commande ! 🚀", {
    body: `Commande #${orderId.slice(0,8)} - ${amount.toLocaleString()} GNF`,
    tag: 'new-order',
    renotify: true
  });
}

// Logic to notify user of order status change
export function notifyOrderStatusChange(orderId: string, status: string) {
  const statusLabels: Record<string, string> = {
    paid: 'Payée',
    preparing: 'En préparation',
    shipped: 'Expédiée',
    delivered: 'Livrée ✅',
    cancelled: 'Annulée ❌'
  };

  sendLocalNotification(`Mise à jour Commande #${orderId.slice(0,8)}`, {
    body: `Votre commande est maintenant : ${statusLabels[status] || status}`,
    tag: `order-${orderId}`
  });
}
