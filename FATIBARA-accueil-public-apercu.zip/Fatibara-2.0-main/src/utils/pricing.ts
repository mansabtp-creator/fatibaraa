import { Product } from '../components/ProductCard';

export interface PriceCalculation {
  basePrice: number;
  finalPrice: number;
  discountAmount: number;
  discountPercent: number;
  isProPrice: boolean;
  isVolumeDiscount: boolean;
  isGlobalSale: boolean;
}

/**
 * Calculates the price for a product based on user status, quantity, and store settings.
 */
export function calculateProductPrice(
  product: any, 
  quantity: number = 1, 
  isPro: boolean = false,
  selectedVariations?: Record<string, string>
): PriceCalculation {
  if (!product) {
    return {
      basePrice: 0,
      finalPrice: 0,
      discountAmount: 0,
      discountPercent: 0,
      isProPrice: false,
      isVolumeDiscount: false,
      isGlobalSale: false
    };
  }

  let basePrice = product.price_gnf || 0;

  // Add variation price overrides if applicable
  if (selectedVariations && product.variants && product.variants.length > 0) {
    const matchingVariant = product.variants.find((v: any) => {
      const sizeMatch = !v.size || selectedVariations.size === v.size;
      const colorMatch = !v.color || selectedVariations.color === v.color;
      return sizeMatch && colorMatch;
    });

    if (matchingVariant && matchingVariant.price_override) {
      basePrice += matchingVariant.price_override;
    }
  }

  const originalPrice = basePrice;
  let currentPrice = originalPrice;
  let isProPrice = false;
  let isVolumeDiscount = false;
  let isGlobalSale = false;

  // 1. Pro Member Pricing
  if (isPro) {
    if (product.wholesale_price_gnf) {
      currentPrice = product.wholesale_price_gnf;
    } else {
      currentPrice = originalPrice * 0.8; // default 20% off for pro
    }
    isProPrice = true;
  }

  // 2. Global Sale (if active on store)
  const store = product.stores || {};
  if (store.global_sale_active && store.global_sale_percent) {
    currentPrice = currentPrice * (1 - store.global_sale_percent / 100);
    isGlobalSale = true;
  }

  // 3. Volume Discount (if quantity thresh reached)
  if (product.volume_discount_qty && product.volume_discount_percent && quantity >= product.volume_discount_qty) {
    currentPrice = currentPrice * (1 - product.volume_discount_percent / 100);
    isVolumeDiscount = true;
  }

  const finalPrice = Math.round(currentPrice);
  const discountAmount = originalPrice - finalPrice;
  const discountPercent = originalPrice > 0 ? Math.round((discountAmount / originalPrice) * 100) : 0;

  return {
    basePrice: originalPrice,
    finalPrice,
    discountAmount: Math.max(0, discountAmount),
    discountPercent: Math.max(0, discountPercent),
    isProPrice,
    isVolumeDiscount,
    isGlobalSale
  };
}
