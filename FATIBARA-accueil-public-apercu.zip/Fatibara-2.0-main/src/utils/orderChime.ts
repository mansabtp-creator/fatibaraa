/**
 * orderChime.ts
 * ─────────────────────────────────────────────────────────────────────────────
 * Synthesises an electronic "beep-beep" alert pattern via the Web Audio API.
 * No audio files, no CDN, no external dependencies.
 *
 * Autoplay policy compliance:
 *   Browsers block AudioContext.start() until a user gesture (click/touch) has
 *   occurred on the page.  This module handles that gracefully:
 *
 *   1. The AudioContext is created in 'suspended' state (the browser default).
 *   2. A one-time gesture listener is attached to `window` on the first
 *      `startChime()` call.  On the first user interaction it calls `.resume()`
 *      and removes itself — no more console warnings after that point.
 *   3. `_playBeepLoop()` checks `ctx.state` before scheduling notes.  If the
 *      context is still suspended it silently skips and logs a single debug
 *      line instead of spamming the console with browser errors.
 *
 * Usage:
 *   startChime()   — begins looping the chime pattern
 *   stopChime()    — immediately silences and destroys the audio context
 *   isChimeActive() — returns true while the chime is running
 */

// ── Module-level singletons ────────────────────────────────────────────────

let _ctx: AudioContext | null = null;
let _intervalId: ReturnType<typeof setInterval> | null = null;
let _isRunning = false;
let _gestureListenerAttached = false;

// ── Gesture unlock ─────────────────────────────────────────────────────────

/**
 * Attaches a one-time click/touchstart listener to `window`.
 * On the first user interaction it resumes the AudioContext (if it exists and
 * is suspended) then removes itself — fully compliant with browser autoplay
 * policy without ever spamming the console.
 */
function _attachGestureUnlocker(): void {
  if (_gestureListenerAttached) return;
  _gestureListenerAttached = true;

  const unlock = () => {
    if (_ctx && _ctx.state === 'suspended') {
      _ctx.resume().then(() => {
        console.debug('[Chime] AudioContext unlocked after user gesture.');
      }).catch(() => { /* ignore — context may have been closed already */ });
    }
    // Self-removing: one-time only
    window.removeEventListener('click',      unlock, { capture: true });
    window.removeEventListener('touchstart', unlock, { capture: true });
    _gestureListenerAttached = false;
  };

  window.addEventListener('click',      unlock, { capture: true, once: true });
  window.addEventListener('touchstart', unlock, { capture: true, once: true });
}

// ── Audio synthesis ────────────────────────────────────────────────────────

/**
 * Play a single "beep-beep" pair if the AudioContext is ready.
 * Silently skips (with a debug log) if the context is still suspended.
 */
function _playBeepLoop(): void {
  if (!_ctx) return;

  // ── Autoplay guard ─────────────────────────────────────────────────────
  if (_ctx.state === 'suspended') {
    console.debug('[Chime] AudioContext suspended — awaiting user interaction…');
    return;
  }
  if (_ctx.state === 'closed') return;

  const ctx = _ctx;
  const now = ctx.currentTime;
  // Two pulses 140 ms apart
  [0, 0.14].forEach((offset) => {
    const osc  = ctx.createOscillator();
    const gain = ctx.createGain();

    osc.connect(gain);
    gain.connect(ctx.destination);

    osc.type = 'square';
    osc.frequency.setValueAtTime(880, now + offset);

    // Attack → sustain → quick release envelope
    gain.gain.setValueAtTime(0,    now + offset);
    gain.gain.linearRampToValueAtTime(0.18, now + offset + 0.01);
    gain.gain.setValueAtTime(0.18, now + offset + 0.08);
    gain.gain.linearRampToValueAtTime(0,   now + offset + 0.12);

    osc.start(now + offset);
    osc.stop(now  + offset + 0.13);

    osc.onended = () => {
      try { osc.disconnect(); gain.disconnect(); } catch { /* already gone */ }
    };
  });
}

// ── Public API ─────────────────────────────────────────────────────────────

/**
 * Begin looping the alert chime. Idempotent — safe to call multiple times.
 *
 * If the browser has not yet received a user gesture the AudioContext will
 * start in 'suspended' state.  The gesture unlocker listener handles resuming
 * it automatically on the next tap or click; no console errors are emitted.
 */
export function startChime(): void {
  if (_isRunning) return;

  try {
    // Re-use the existing context if it is still open.
    if (!_ctx || _ctx.state === 'closed') {
      // AudioContext starts suspended by default — that is correct and expected.
      _ctx = new AudioContext();
    }

    // Register the one-time gesture listener so the context can be unlocked
    // as soon as the user interacts with the page.
    _attachGestureUnlocker();

    _isRunning = true;

    // Attempt an immediate beep (will silently skip if still suspended).
    _playBeepLoop();

    // Loop every 3.5 seconds.
    _intervalId = setInterval(_playBeepLoop, 3500);
  } catch (err) {
    // Web Audio API unavailable (very old browser / jest / SSR) — fail silently.
    console.warn('[Chime] Web Audio API unavailable:', err);
  }
}

/**
 * Stop the chime and release all audio resources. Idempotent.
 */
export function stopChime(): void {
  if (!_isRunning) return;
  _isRunning = false;

  if (_intervalId !== null) {
    clearInterval(_intervalId);
    _intervalId = null;
  }

  if (_ctx) {
    try {
      _ctx.close().catch(() => { /* ignore */ });
    } catch { /* already closed */ }
    _ctx = null;
  }
}

/** Returns true if the chime loop is currently active. */
export function isChimeActive(): boolean {
  return _isRunning;
}
