export interface ShippingLocation {
  region: string;
  commune: string;
}

export interface DeliveryOptions {
  isExpress?: boolean;
  weightClass?: 'light' | 'medium' | 'heavy';
}

export const FREE_DELIVERY_THRESHOLD = 500000;

export const COMMUNES = [
  { name: 'Kaloum', price: 15000, time: '2-4 heures' },
  { name: 'Dixinn', price: 20000, time: '3-5 heures' },
  { name: 'Matam', price: 20000, time: '3-5 heures' },
  { name: 'Ratoma', price: 25000, time: '4-8 heures' },
  { name: 'Matoto', price: 25000, time: '4-8 heures' },
  { name: 'Lambanyi', price: 25000, time: '4-8 heures' },
  { name: 'Sonfonia', price: 25000, time: '4-8 heures' },
  { name: 'Foula Madina', price: 25000, time: '4-8 heures' },
  { name: 'Gbessia', price: 20000, time: '3-5 heures' },
  { name: 'Tombolia', price: 25000, time: '4-8 heures' },
  { name: 'Kassa', price: 30000, time: '24 heures' },
  { name: 'Sanoyah', price: 30000, time: '8-12 heures' },
  { name: 'Maneah', price: 35000, time: '8-12 heures' },
  { name: 'Kagbelen', price: 30000, time: '8-12 heures' },
  { name: 'Coyah', price: 45000, time: '24 heures' },
  { name: 'Dubréka', price: 45000, time: '24 heures' },
];

export function calculateDeliveryFee(
  from: ShippingLocation,
  to: ShippingLocation,
  options?: DeliveryOptions
): { fee: number; distance: number | null } {
  let baseFee = 35000;

  const isSameCommune = from.commune && to.commune && from.commune.toLowerCase() === to.commune.toLowerCase();
  
  const conakryCommunes = ['kaloum', 'dixinn', 'matam', 'ratoma', 'matoto', 'lambanyi', 'sonfonia', 'foula madina', 'gbessia', 'tombolia', 'kassa'];
  const isConakry = (to.region && to.region.toLowerCase() === 'conakry') || 
                    (to.commune && conakryCommunes.includes(to.commune.toLowerCase()));

  if (isConakry || isSameCommune) {
    baseFee = 15000;
  } else {
    const destination = to.commune ? COMMUNES.find(c => c.name.toLowerCase() === to.commune.toLowerCase()) : null;
    if (destination) {
      baseFee = destination.price;
    }
  }

  // Weight surcharges
  let weightSurcharge = 0;
  if (options?.weightClass === 'medium') {
    weightSurcharge = 5000;
  } else if (options?.weightClass === 'heavy') {
    weightSurcharge = 15000;
  }

  // Express surcharge
  const expressSurcharge = options?.isExpress ? 10000 : 0;

  return { fee: baseFee + weightSurcharge + expressSurcharge, distance: null };
}

export function adjustDeliveryTime(timeStr: string, isExpress: boolean): string {
  if (!isExpress) return timeStr;
  return timeStr.replace(/(\d+)(?:\s*-\s*(\d+))?\s*(heures?)/gi, (match, p1, p2, unit) => {
    const minH = Math.max(1, Math.round(parseInt(p1, 10) / 2));
    if (p2) {
      const maxH = Math.max(minH + 1, Math.round(parseInt(p2, 10) / 2));
      return `${minH}-${maxH} ${unit}`;
    }
    return `${minH} ${unit}`;
  });
}
