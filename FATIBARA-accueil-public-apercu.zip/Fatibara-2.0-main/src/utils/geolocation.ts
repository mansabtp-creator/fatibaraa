/**
 * Safe Geolocation Utility for Fatibara
 *
 * Handles browser permission policy restrictions, iframe sandboxing (AI Studio preview,
 * mobile webviews), and unsupported environments gracefully without throwing uncaught
 * violations or logging noisy browser console warnings.
 */

export interface GeoCoordinates {
  latitude: number;
  longitude: number;
  accuracy?: number;
}

export const CONAKRY_CENTER = {
  lat: 9.5092,
  lng: -13.7122,
} as const;

/**
 * Checks whether the current document is embedded in an iframe.
 */
export function isEmbeddedInIframe(): boolean {
  try {
    return typeof window !== 'undefined' && window.self !== window.top;
  } catch {
    return true;
  }
}

/**
 * Checks if geolocation is supported and permitted by the active Permissions-Policy.
 */
export function isGeolocationPermitted(): boolean {
  if (typeof window === 'undefined' || typeof navigator === 'undefined' || !('geolocation' in navigator)) {
    return false;
  }

  // Modern Permissions-Policy API
  const doc = document as any;
  if (typeof doc.permissionsPolicy?.allowsFeature === 'function') {
    if (!doc.permissionsPolicy.allowsFeature('geolocation')) {
      return false;
    }
  }

  // Legacy Feature-Policy API
  if (typeof doc.featurePolicy?.allowsFeature === 'function') {
    if (!doc.featurePolicy.allowsFeature('geolocation')) {
      return false;
    }
  }

  // When running inside an iframe, check if permission was delegated.
  // If the browser doesn't expose permissionsPolicy, assume iframe blocks it
  // unless we're in top-level window.
  if (isEmbeddedInIframe()) {
    if (typeof doc.permissionsPolicy?.allowsFeature !== 'function') {
      // In unknown iframe environments, avoid triggering browser violation logs
      return false;
    }
  }

  return true;
}

/**
 * Safely calls getCurrentPosition with automatic protection against Permissions Policy violations.
 */
export function safeGetCurrentPosition(
  onSuccess: (coords: GeoCoordinates) => void,
  onError?: (error: { message: string; isPolicyRestricted: boolean }) => void,
  options?: PositionOptions
): void {
  if (!isGeolocationPermitted()) {
    if (onError) {
      onError({
        message: 'La géolocalisation est restreinte par la politique du navigateur ou le cadre iframe.',
        isPolicyRestricted: true,
      });
    }
    return;
  }

  try {
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        onSuccess({
          latitude: pos.coords.latitude,
          longitude: pos.coords.longitude,
          accuracy: pos.coords.accuracy,
        });
      },
      (err) => {
        const isRestricted = err.code === 1 || err.message?.toLowerCase().includes('permissions policy');
        if (onError) {
          onError({
            message: err.message || 'Position non disponible',
            isPolicyRestricted: isRestricted,
          });
        }
      },
      options || { enableHighAccuracy: true, timeout: 15000, maximumAge: 60000 }
    );
  } catch (err: any) {
    if (onError) {
      onError({
        message: err?.message || 'Erreur lors de l’accès au GPS',
        isPolicyRestricted: true,
      });
    }
  }
}

/**
 * Safely starts watching position or returns null if not permitted.
 */
export function safeWatchPosition(
  onSuccess: (coords: GeoCoordinates) => void,
  onError?: (error: { message: string; isPolicyRestricted: boolean }) => void,
  options?: PositionOptions
): number | null {
  if (!isGeolocationPermitted()) {
    if (onError) {
      onError({
        message: 'La géolocalisation est restreinte par la politique du navigateur.',
        isPolicyRestricted: true,
      });
    }
    return null;
  }

  try {
    return navigator.geolocation.watchPosition(
      (pos) => {
        onSuccess({
          latitude: pos.coords.latitude,
          longitude: pos.coords.longitude,
          accuracy: pos.coords.accuracy,
        });
      },
      (err) => {
        const isRestricted = err.code === 1 || err.message?.toLowerCase().includes('permissions policy');
        if (onError) {
          onError({
            message: err.message || 'Position non disponible',
            isPolicyRestricted: isRestricted,
          });
        }
      },
      options || { enableHighAccuracy: true, timeout: 20000, maximumAge: 30000 }
    );
  } catch (err: any) {
    if (onError) {
      onError({
        message: err?.message || 'Erreur lors de l’observation GPS',
        isPolicyRestricted: true,
      });
    }
    return null;
  }
}
