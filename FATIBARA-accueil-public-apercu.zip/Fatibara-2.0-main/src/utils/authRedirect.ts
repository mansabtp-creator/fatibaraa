/**
 * authRedirect.ts — Legacy async DB-based redirect path resolver.
 *
 * Used by LoginPage as a fallback when the in-context `activeRole` is not yet
 * settled after a fresh signInWithPassword. Queries the DB directly.
 *
 * Prefer `getRedirectPathForRole(activeRole)` from `lib/auth-redirect.ts`
 * whenever the AppContext profile is already ready (i.e. `isProfileReady === true`).
 */
import { supabase } from '../lib/supabase';
import { getHomeRouteForRole } from './routes';
import { getRedirectPathForRole } from '../lib/auth-redirect';

export async function getRedirectPath(userId: string): Promise<string> {
  try {
    // NOTE: The profiles table uses `profile_type` — NOT `role`.
    const { data: profile, error: profileError } = await supabase
      .from('profiles')
      .select('is_admin, courier_status, profile_type, active_role')
      .eq('id', userId)
      .maybeSingle();

    if (profileError) {
      console.error('[authRedirect] Error fetching profile for redirect:', profileError);
    }

    // Admin check: explicit DB flag or profile_type === 'admin'
    if (profile?.is_admin || profile?.profile_type === 'admin') {
      return getHomeRouteForRole('admin');
    }

    // Use the DB-persisted active_role first, then fall back to profile_type
    const resolvedRole = profile?.active_role || profile?.profile_type;

    if (resolvedRole === 'courier' || resolvedRole === 'livreur') {
      return getHomeRouteForRole('courier');
    }

    if (resolvedRole === 'vendor') {
      return getHomeRouteForRole('vendor');
    }

    // Fallback: check vendor presence via stores table (handles legacy/pre-role rows)
    // ── 406 guard ────────────────────────────────────────────────────────────
    // HTTP 406 here means the stores RLS policy is recursive. Treat as
    // "no store found" and fall through rather than crashing the login redirect flow.
    const { data: stores, error: storesError } = await supabase
      .from('stores')
      .select('id')
      .eq('owner_id', userId)
      .limit(1);

    if (storesError) {
      const code = storesError.code as string | undefined;
      const msg  = storesError.message as string | undefined;
      if (code === '406' || msg?.toLowerCase().includes('not acceptable')) {
        console.error(
          '[authRedirect] HTTP 406 on stores query — RLS policy recursion detected. ' +
          'Apply the flat-policy SQL migration and run: NOTIFY pgrst, \'reload schema\'',
          storesError
        );
        // Do NOT crash — fall through to courier/default check
      } else {
        console.error('[authRedirect] Error fetching stores for redirect:', storesError);
      }
    }

    if (stores && stores.length > 0) {
      return getHomeRouteForRole('vendor');
    }

    // Courier status fallback (for legacy rows without an active_role)
    if (profile?.courier_status === 'verified' || profile?.courier_status === 'active') {
      return getRedirectPathForRole('livreur');
    }

    // Default: buyer / customer → shop homepage (/)
    return getRedirectPathForRole('client');
  } catch (err) {
    console.error('[authRedirect] Error determining redirect path:', err);
    return '/';
  }
}
