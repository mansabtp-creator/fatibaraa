import { supabase } from '../lib/supabase';

export interface AuditLogOptions {
  userId?: string | null;
  action: string;
  entityType?: string;
  entityId?: string | number | null;
  storeId?: string | null;
  data?: any;
}

const UUID_REGEX = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

/**
 * Robustly records an audit log event.
 * Dispatches via the backend `/api/admin/audit-log` endpoint (bypassing client RLS
 * and preventing schema 400 Bad Request / 401 Unauthorized errors in browser network tab),
 * with graceful fallback to Supabase service or silent recovery.
 */
export async function logAuditEvent(options: AuditLogOptions): Promise<boolean> {
  const { userId, action, entityType = 'system', entityId, storeId, data } = options;

  try {
    const response = await fetch('/api/admin/audit-log', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        userId: userId || null,
        action,
        entityType,
        entityId: entityId ? String(entityId) : null,
        storeId: storeId || null,
        data: data || null,
      }),
    });

    if (response.ok) {
      const resJson = await response.json().catch(() => null);
      if (resJson?.success) {
        return true;
      }
    }
  } catch {
    // Network or server temporarily unreachable, try client fallback with safe payload
  }

  // Graceful fallback: Insert directly if authenticated, ensuring 'action' is never sent
  // as a root column (which causes 400 Bad Request 'Could not find action column in schema cache')
  try {
    const cleanUserId = typeof userId === 'string' && UUID_REGEX.test(userId.trim()) ? userId.trim() : null;
    const cleanStoreId = typeof storeId === 'string' && UUID_REGEX.test(storeId.trim()) ? storeId.trim() : null;

    const payload = {
      action: action || 'ACTION',
      ...(typeof data === 'object' && data !== null ? data : { payload: data }),
    };

    const { error } = await supabase.from('audit_logs').insert({
      user_id: cleanUserId,
      entity_type: entityType,
      entity_id: entityId ? String(entityId) : null,
      store_id: cleanStoreId,
      new_data: payload,
    });

    if (!error) return true;
  } catch {
    // Non-fatal: do not block caller
  }

  return false;
}
