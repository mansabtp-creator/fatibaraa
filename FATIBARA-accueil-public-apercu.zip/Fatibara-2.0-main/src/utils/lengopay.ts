/**
 * LengoPay / Guinean Mobile Money utilities
 *
 * Carrier detection is based on the Guinean national numbering plan:
 *   Orange Guinea  : 610-619, 620-629
 *   MTN Guinea     : 650-659, 660-669
 *
 * All functions are pure / side-effect-free.
 */

export type Carrier = 'ORANGE' | 'MTN' | null;

/**
 * Detect which Guinean mobile carrier owns a phone number.
 * Accepts any of these formats:
 *   "620 12 34 56"  — spaced
 *   "+224620123456" — with country code + prefix
 *   "224620123456"  — country code, no +
 *   "620123456"     — bare 9-digit local number
 */
export const detectCarrier = (phone: string): Carrier => {
  const clean = phone.replace(/\D/g, '');

  // Strip optional 224 country code prefix, leaving 9-digit local number
  const local = clean.replace(/^224/, '');

  // Must be exactly 9 digits
  if (!/^\d{9}$/.test(local)) return null;

  const prefix3 = parseInt(local.slice(0, 3), 10);

  // Orange Guinea: 610-619, 620-629 (incl. 613)
  if (prefix3 >= 610 && prefix3 <= 619) return 'ORANGE';
  if (prefix3 >= 620 && prefix3 <= 629) return 'ORANGE';

  // MTN Guinea: 650-659 (incl. 654-657), 660-669 (incl. 669)
  if (prefix3 >= 650 && prefix3 <= 659) return 'MTN';
  if (prefix3 >= 660 && prefix3 <= 669) return 'MTN';

  return null;
};

/**
 * Format a raw phone string into the pretty "+224 6xx xx xx xx" display format.
 * Falls back to the original input if it cannot be parsed.
 */
export const formatGuineanPhone = (phone: string): string => {
  const clean = phone.replace(/\D/g, '');

  // Take the last 9 digits (local number), handling raw / country-prefixed inputs
  const local = clean.replace(/^224/, '').slice(-9);

  if (local.length !== 9) return phone;

  // "+224 620 12 34 56"
  return `+224 ${local.slice(0, 3)} ${local.slice(3, 5)} ${local.slice(5, 7)} ${local.slice(7, 9)}`;
};

/**
 * Return true if a raw phone string is a valid 9-digit Guinean mobile number.
 */
export const isValidGuineanPhone = (phone: string): boolean => {
  const clean = phone.replace(/\D/g, '').replace(/^224/, '');
  return /^\d{9}$/.test(clean);
};
