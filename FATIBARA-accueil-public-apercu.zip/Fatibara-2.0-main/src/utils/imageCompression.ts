/**
 * imageCompression.ts
 * Client-side image compression using HTML5 Canvas.
 *
 * Compresses images to a maximum file size before uploading to Supabase
 * Storage. Designed for low-bandwidth mobile connections (3G/4G in Guinea).
 *
 * Features:
 *  - Canvas-based JPEG/WebP compression with configurable quality
 *  - Max dimension capping (prevents uploading 4K phone photos at full res)
 *  - Iterative quality reduction to meet a target byte ceiling
 *  - Accepts File or Blob; returns a Blob ready for supabase.storage.upload()
 *  - Pure browser API — no external dependencies
 *
 * Usage:
 *   const compressed = await compressImage(file, { maxSizeKB: 500 });
 *   await supabase.storage.from('avatars').upload(path, compressed);
 */

export interface CompressionOptions {
  /** Target maximum file size in kilobytes. Default: 500 KB */
  maxSizeKB?: number;
  /** Maximum width or height in pixels. Default: 1200 px */
  maxDimension?: number;
  /** Starting JPEG quality (0–1). Default: 0.85 */
  initialQuality?: number;
  /** Output MIME type. Default: 'image/jpeg' */
  outputType?: 'image/jpeg' | 'image/webp';
}

/**
 * Compress an image File/Blob using Canvas.
 * Returns a compressed Blob; falls back to the original File on non-fatal errors.
 */
export async function compressImage(
  file: File | Blob,
  options: CompressionOptions = {}
): Promise<Blob> {
  const {
    maxSizeKB     = 500,
    maxDimension  = 1200,
    initialQuality = 0.85,
    outputType    = 'image/jpeg',
  } = options;

  const maxBytes = maxSizeKB * 1024;

  // If already under the limit and dimensions unknown, try quick path first
  if (file.size <= maxBytes) {
    // Still resize if we don't know the original dimensions
    const resized = await resizeToMaxDimension(file, maxDimension, outputType, initialQuality);
    if (resized.size <= maxBytes) return resized;
  }

  // Iterative quality reduction: start at initialQuality, drop by 0.1 each pass
  let quality = initialQuality;
  let result: Blob = file;

  while (quality > 0.2) {
    const blob = await resizeToMaxDimension(file, maxDimension, outputType, quality);
    result = blob;
    if (blob.size <= maxBytes) break;
    quality -= 0.1;
  }

  // Last resort: if still over limit at q=0.2, accept it rather than destroying quality
  return result;
}

/**
 * Draw the image on a Canvas and export at the given quality.
 * Caps both width and height to maxDimension, preserving aspect ratio.
 */
function resizeToMaxDimension(
  file: File | Blob,
  maxDimension: number,
  outputType: string,
  quality: number
): Promise<Blob> {
  return new Promise((resolve, reject) => {
    const url = URL.createObjectURL(file);
    const img = new Image();

    img.onload = () => {
      URL.revokeObjectURL(url);

      let { width, height } = img;

      if (width > maxDimension || height > maxDimension) {
        if (width >= height) {
          height = Math.round((height / width) * maxDimension);
          width  = maxDimension;
        } else {
          width  = Math.round((width / height) * maxDimension);
          height = maxDimension;
        }
      }

      const canvas = document.createElement('canvas');
      canvas.width  = width;
      canvas.height = height;

      const ctx = canvas.getContext('2d');
      if (!ctx) {
        // Canvas not supported — return original
        resolve(file);
        return;
      }

      ctx.drawImage(img, 0, 0, width, height);

      canvas.toBlob(
        (blob) => {
          if (blob) {
            resolve(blob);
          } else {
            // toBlob returned null (device memory pressure etc.) — keep original
            resolve(file);
          }
        },
        outputType,
        quality
      );
    };

    img.onerror = () => {
      URL.revokeObjectURL(url);
      // Could not load image (corrupt file etc.) — return as-is
      resolve(file);
    };

    img.src = url;
  });
}

/**
 * Validate an image file before compression.
 * Returns a user-facing French error string, or null if valid.
 */
export function validateImageFile(
  file: File,
  maxOriginalSizeMB: number = 10
): string | null {
  const ALLOWED_TYPES = ['image/jpeg', 'image/png', 'image/webp', 'image/gif', 'image/heic'];

  if (!ALLOWED_TYPES.includes(file.type.toLowerCase())) {
    return `Format non supporté : ${file.type || 'inconnu'}. Utilisez JPEG, PNG ou WebP.`;
  }

  if (file.size > maxOriginalSizeMB * 1024 * 1024) {
    return `Image trop lourde (${(file.size / 1024 / 1024).toFixed(1)} Mo). Maximum : ${maxOriginalSizeMB} Mo.`;
  }

  return null; // Valid
}

/**
 * Format bytes into a human-readable string (French locale).
 * Used for displaying original vs compressed sizes in upload UI.
 */
export function formatBytes(bytes: number): string {
  if (bytes < 1024) return `${bytes} o`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(0)} Ko`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} Mo`;
}
