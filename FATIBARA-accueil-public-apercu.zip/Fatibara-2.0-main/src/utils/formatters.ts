/**
 * Formats a number as GNF currency with French locale.
 * Always use this instead of raw .toLocaleString() to guarantee
 * correct grouping separators on all devices (incl. Android mid-range).
 *
 * @example formatGNF(1500000) → "1 500 000 GNF"
 */
export function formatGNF(amount: number | null | undefined): string {
  if (amount == null || isNaN(amount)) return '0 GNF';
  // GNF has no sub-unit — always floor to nearest whole franc.
  return `${Math.floor(amount).toLocaleString('fr-FR')} GNF`;
}

/**
 * Human-readable order status labels in French.
 * Use getStatusLabel(order.status) wherever order statuses are displayed.
 */
export const ORDER_STATUS_LABELS: Record<string, { label: string; emoji: string; color: string }> = {
  pending:           { label: 'En attente',            emoji: '⏳', color: 'text-amber-600 dark:text-amber-400'    },
  accepted:          { label: 'Accepté par la boutique',emoji: '👍', color: 'text-blue-600 dark:text-blue-400'     },
  confirmed:         { label: 'Confirmé',               emoji: '✅', color: 'text-blue-600 dark:text-blue-400'     },
  paid:              { label: 'Payé',                   emoji: '💳', color: 'text-emerald-600 dark:text-emerald-400'},
  preparing:         { label: 'En préparation',         emoji: '📦', color: 'text-indigo-600 dark:text-indigo-400' },
  processing:        { label: 'En préparation',         emoji: '📦', color: 'text-indigo-600 dark:text-indigo-400' },
  ready_for_pickup:  { label: 'Prêt à expédier',        emoji: '🏪', color: 'text-purple-600 dark:text-purple-400' },
  in_transit:        { label: 'En livraison',           emoji: '🚚', color: 'text-orange-600 dark:text-orange-400' },
  out_for_delivery:  { label: 'En cours de livraison',  emoji: '🛵', color: 'text-orange-600 dark:text-orange-400' },
  delivered:         { label: 'Livré',                  emoji: '🎉', color: 'text-emerald-600 dark:text-emerald-400'},
  cancelled:         { label: 'Annulé',                 emoji: '❌', color: 'text-red-600 dark:text-red-400'       },
  canceled:          { label: 'Annulé',                 emoji: '❌', color: 'text-red-600 dark:text-red-400'       },
  refunded:          { label: 'Remboursé',              emoji: '↩️', color: 'text-gray-600 dark:text-gray-400'    },
  disputed:          { label: 'En litige',              emoji: '⚠️', color: 'text-red-600 dark:text-red-400'      },
};

export function getStatusLabel(status: string | null | undefined): { label: string; emoji: string; color: string } {
  if (!status) return { label: 'Inconnu', emoji: '❓', color: 'text-gray-500' };
  return ORDER_STATUS_LABELS[status] ?? { label: status, emoji: '•', color: 'text-gray-500' };
}

/**
 * Financial status labels
 */
export const FINANCIAL_STATUS_LABELS: Record<string, string> = {
  pending:    'En attente',
  processing: 'En traitement',
  processed:  'Traité',
  failed:     'Échoué',
};

/**
 * French relative-time formatter.
 * Returns strings like "Il y a 5 min", "Il y a 2h", "Hier", "Il y a 3 jours".
 * @example timeAgo("2026-08-20T09:00:00Z") → "Il y a 10 min"
 */
export function timeAgo(dateString: string | null | undefined): string {
  if (!dateString) return '—';
  const diffMs = Date.now() - new Date(dateString).getTime();
  const diffMin = Math.floor(diffMs / 60_000);
  if (diffMin < 1) return "À l'instant";
  if (diffMin < 60) return `Il y a ${diffMin} min`;
  const diffH = Math.floor(diffMin / 60);
  if (diffH < 24) return `Il y a ${diffH}h`;
  const diffD = Math.floor(diffH / 24);
  if (diffD === 1) return 'Hier';
  if (diffD < 7) return `Il y a ${diffD} jours`;
  return new Date(dateString).toLocaleDateString('fr-FR', { day: 'numeric', month: 'short' });
}
