/**
 * routes.ts — Centralized Role-to-Route Resolver
 *
 * Single source of truth for role-based default routes.
 * Import `getHomeRouteForRole` and `ROLE_DEFAULT_ROUTES` everywhere
 * role → path resolution is needed. Never hardcode these strings elsewhere.
 *
 * The canonical role→route map lives in `lib/auth-redirect.ts`.
 * Re-exported here for backward compatibility with existing consumers.
 */

// Re-export the canonical map & helper from the authoritative module
export { ROLE_ROUTES, getRedirectPathForRole, normalizeToCanonicalRole } from '../lib/auth-redirect';
export type { UserRole as CanonicalUserRole } from '../lib/auth-redirect';

// Extended UserRole type that includes all DB variants (wider than CanonicalUserRole)
export type UserRole =
  | 'vendor'
  | 'courier'
  | 'livreur'
  | 'admin'
  | 'buyer'
  | 'customer'
  | 'standard'
  | 'pro'
  | string;

/**
 * Maps each recognized role to its canonical home dashboard route.
 * Vendor maps to /vendor/dashboard — the live nested route in App.tsx.
 * Both 'courier' and 'livreur' map to /livreur/dashboard.
 * Admin maps to /admin/dashboard.
 */
export const ROLE_DEFAULT_ROUTES: Record<string, string> = {
  admin:    '/admin/dashboard',
  vendor:   '/vendor/dashboard',
  courier:  '/livreur/dashboard',
  livreur:  '/livreur/dashboard',
  buyer:    '/',
  customer: '/',
  standard: '/',
  pro:      '/',
};

/**
 * Returns the canonical home route for a given role.
 * Falls back to '/' for any unknown or falsy role.
 *
 * @param role - The user's active role string (case-insensitive).
 * @returns The route path string.
 *
 * @example
 * getHomeRouteForRole('vendor')  // '/vendor/dashboard'
 * getHomeRouteForRole('ADMIN')   // '/admin/dashboard'
 * getHomeRouteForRole(null)      // '/'
 */
export function getHomeRouteForRole(role?: UserRole | null): string {
  if (!role) return '/';
  return ROLE_DEFAULT_ROUTES[role.toLowerCase()] ?? '/';
}

/**
 * Returns true if the given pathname is within the allowed set for that role.
 * Used by RoleGuard to determine if a redirect is required.
 */
export function isRouteAllowedForRole(pathname: string, role: UserRole): boolean {
  switch (role.toLowerCase()) {
    case 'admin':
      // Admins may access all protected areas
      return (
        pathname.startsWith('/admin') ||
        pathname.startsWith('/vendor') ||
        pathname.startsWith('/livreur') ||
        pathname.startsWith('/courier-dashboard') ||
        pathname === '/orders' ||
        pathname.startsWith('/orders/') ||
        pathname === '/dashboard' ||
        pathname === '/login'
      );
    case 'vendor':
      return (
        pathname.startsWith('/vendor') ||
        pathname === '/vendor-registration' ||
        pathname === '/orders' ||
        pathname.startsWith('/orders/') ||
        pathname === '/dashboard' ||
        pathname === '/login'
      );
    case 'courier':
    case 'livreur':
      return (
        pathname.startsWith('/livreur') ||
        pathname.startsWith('/courier-dashboard') ||
        pathname.startsWith('/courier-onboarding') ||
        pathname === '/orders' ||
        pathname.startsWith('/orders/') ||
        pathname === '/dashboard' ||
        pathname === '/login'
      );
    default:
      // Buyer / customer / standard / pro — cannot access operational dashboards
      return (
        !pathname.startsWith('/admin') &&
        !pathname.startsWith('/livreur') &&
        !pathname.startsWith('/courier-dashboard') &&
        !pathname.startsWith('/vendor/')
      );
  }
}
