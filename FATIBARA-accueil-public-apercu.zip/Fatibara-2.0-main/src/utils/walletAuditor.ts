import { supabase } from '../lib/supabase';

export interface AuditReport {
  timestamp: string;
  targetType: 'vendor' | 'courier' | 'user';
  targetId: string;
  storedDbBalance: number;
  calculatedLedgerBalance: number;
  pendingWithdrawalsTotal: number;
  discrepancy: number;
  isMatch: boolean;
  transactionsCount: number;
  withdrawalsCount: number;
  transactions: any[];
  withdrawals: any[];
}

/**
 * Console-based validation script that fetches transaction history, withdrawal records,
 * and current wallet balance for the user, then recalculates the balance by summing all
 * transactions to identify if any discrepancy exists between UI state, ledger records,
 * and database balance columns.
 */
export async function auditWallet(
  targetType: 'vendor' | 'courier' | 'user' = 'vendor',
  targetId?: string
): Promise<AuditReport | null> {
  console.group(`🔍 [Wallet Auditor] Starting Balance Audit (${targetType.toUpperCase()})`);

  try {
    const { data: { session }, error: authErr } = await supabase.auth.getSession();
    if (authErr || !session) {
      console.error('❌ User not authenticated. Please log in first.');
      console.groupEnd();
      return null;
    }

    const userId = session.user.id;
    let entityId = targetId;
    let storedDbBalance = 0;
    let storeData: any = null;
    let profileData: any = null;

    if (targetType === 'vendor') {
      if (!entityId) {
        // Fetch primary store owned by user
        const { data: stores } = await supabase
          .from('stores')
          .select('id, name, balance, owner_id')
          .eq('owner_id', userId)
          .limit(1);

        if (stores && stores.length > 0) {
          storeData = stores[0];
          entityId = storeData.id;
        }
      } else {
        const { data: store } = await supabase
          .from('stores')
          .select('id, name, balance, owner_id')
          .eq('id', entityId)
          .maybeSingle();
        storeData = store;
      }

      if (!entityId || !storeData) {
        console.error('❌ No vendor store found for this account.');
        console.groupEnd();
        return null;
      }

      storedDbBalance = Number(storeData.balance || 0);
      console.log(`📌 Vendor Store: "${storeData.name}" (ID: ${entityId})`);
      console.log(`💵 DB Stored Balance (stores.balance): ${storedDbBalance.toLocaleString('fr-FR')} GNF`);

    } else {
      entityId = userId;
      const { data: profile } = await supabase
        .from('profiles')
        .select('id, full_name, wallet_balance, role')
        .eq('id', userId)
        .maybeSingle();

      profileData = profile;
      storedDbBalance = Number(profileData?.wallet_balance || 0);
      console.log(`📌 User Profile: "${profileData?.full_name || userId}" (Role: ${profileData?.role})`);
      console.log(`💵 DB Stored Balance (profiles.wallet_balance): ${storedDbBalance.toLocaleString('fr-FR')} GNF`);
    }

    // Fetch Transaction History
    let txQuery = supabase.from('wallet_transactions').select('*');
    if (targetType === 'vendor' && entityId) {
      txQuery = txQuery.eq('store_id', entityId);
    } else {
      txQuery = txQuery.eq('profile_id', userId);
    }
    const { data: txList, error: txErr } = await txQuery.order('created_at', { ascending: true });

    if (txErr) {
      console.warn('⚠️ Could not fetch wallet_transactions (or RLS restricted):', txErr.message);
    }

    const transactions = txList || [];

    // Fetch Withdrawal History
    let wdQuery = supabase.from('withdrawals').select('*');
    if (targetType === 'vendor' && entityId) {
      wdQuery = wdQuery.eq('store_id', entityId);
    } else {
      wdQuery = wdQuery.eq('profile_id', userId);
    }
    const { data: wdList, error: wdErr } = await wdQuery.order('created_at', { ascending: true });

    if (wdErr) {
      console.warn('⚠️ Could not fetch withdrawals:', wdErr.message);
    }

    const withdrawals = wdList || [];

    // Recalculate ledger balance from transactions
    let calculatedLedgerBalance = 0;
    const itemizedLedger: any[] = [];

    transactions.forEach((tx, idx) => {
      const amt = Number(tx.amount || 0);
      calculatedLedgerBalance += amt;
      itemizedLedger.push({
        '#': idx + 1,
        Date: new Date(tx.created_at).toLocaleString('fr-FR'),
        Type: tx.type,
        Description: tx.description || '–',
        Amount: `${amt >= 0 ? '+' : ''}${amt.toLocaleString('fr-FR')} GNF`,
        'Running Balance': `${calculatedLedgerBalance.toLocaleString('fr-FR')} GNF`,
        Status: tx.status || 'completed'
      });
    });

    // Calculate pending withdrawals
    const pendingWds = withdrawals.filter((w: any) => w.status === 'pending');
    const pendingWithdrawalsTotal = pendingWds.reduce((sum: number, w: any) => sum + Number(w.amount || 0), 0);

    const itemizedWithdrawals = withdrawals.map((w: any, idx: number) => ({
      '#': idx + 1,
      Date: new Date(w.created_at || w.requested_at).toLocaleString('fr-FR'),
      Amount: `${Number(w.amount).toLocaleString('fr-FR')} GNF`,
      Method: w.method || w.payout_method || 'orange_money',
      Phone: w.phone || w.phone_number || '–',
      Status: w.status,
      ID: w.id
    }));

    const discrepancy = storedDbBalance - calculatedLedgerBalance;
    const isMatch = Math.abs(discrepancy) < 1;

    console.log('\n==================================================');
    console.log('📊 AUDIT SUMMARY BREAKDOWN');
    console.log('==================================================');
    console.log(`• Stored DB Balance:            ${storedDbBalance.toLocaleString('fr-FR')} GNF`);
    console.log(`• Calculated Ledger Balance:    ${calculatedLedgerBalance.toLocaleString('fr-FR')} GNF`);
    console.log(`• Pending Locked Withdrawals:   ${pendingWithdrawalsTotal.toLocaleString('fr-FR')} GNF`);
    console.log(`• Discrepancy Amount:           ${discrepancy.toLocaleString('fr-FR')} GNF`);
    console.log(`• Audit Result:                 ${isMatch ? '✅ PERFECT MATCH' : '⚠️ DISCREPANCY DETECTED'}`);
    console.log('==================================================\n');

    if (itemizedLedger.length > 0) {
      console.log('📜 TRANSACTION HISTORY LEDGER:');
      console.table(itemizedLedger);
    } else {
      console.log('ℹ️ No recorded rows in wallet_transactions for this entity.');
    }

    if (itemizedWithdrawals.length > 0) {
      console.log('\n💸 WITHDRAWALS HISTORY:');
      console.table(itemizedWithdrawals);
    } else {
      console.log('ℹ️ No recorded rows in withdrawals table for this entity.');
    }

    const report: AuditReport = {
      timestamp: new Date().toISOString(),
      targetType,
      targetId: entityId,
      storedDbBalance,
      calculatedLedgerBalance,
      pendingWithdrawalsTotal,
      discrepancy,
      isMatch,
      transactionsCount: transactions.length,
      withdrawalsCount: withdrawals.length,
      transactions,
      withdrawals
    };

    console.groupEnd();
    return report;

  } catch (err: any) {
    console.error('❌ Audit execution error:', err?.message || err);
    console.groupEnd();
    return null;
  }
}

// Attach auditor function and balance updater to window for instant access in Browser Developer Console (F12)
export async function setWalletBalance(amount: number = 1000000, targetUserId?: string) {
  try {
    let userId = targetUserId;
    if (!userId) {
      const { data: { session } } = await supabase.auth.getSession();
      userId = session?.user?.id;
    }

    if (!userId) {
      console.error('❌ No active session or target user ID provided.');
      return false;
    }

    // Update store balance in Supabase
    const { data: stores } = await supabase.from('stores').select('id, name').eq('owner_id', userId);
    if (stores && stores.length > 0) {
      for (const store of stores) {
        await supabase.from('stores').update({ balance: amount }).eq('id', store.id);
        console.log(`✅ Store "${store.name}" balance updated to ${amount.toLocaleString('fr-FR')} GNF in Supabase database.`);
      }
    }

    // Update profile wallet_balance in Supabase
    await supabase.from('profiles').update({ wallet_balance: amount }).eq('id', userId);
    console.log(`✅ User profile balance updated to ${amount.toLocaleString('fr-FR')} GNF in Supabase database.`);

    // Refresh page to sync all active UI components
    if (typeof window !== 'undefined' && window.location) {
      window.location.reload();
    }
    return true;
  } catch (err: any) {
    console.error('❌ Failed to set wallet balance:', err);
    return false;
  }
}

if (typeof window !== 'undefined') {
  (window as any).auditWallet = auditWallet;
  (window as any).setWalletBalance = setWalletBalance;
}
