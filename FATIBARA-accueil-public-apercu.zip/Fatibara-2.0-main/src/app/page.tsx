"use client";

import { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { Truck, ShieldCheck, Award, Headset, MessageCircle, ArrowRight } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { useNavigate } from 'react-router-dom';
import Header from '../components/Header';
import Hero from '../components/Hero';
import SearchBar from '../components/SearchBar';
import CategoryBar from '../components/CategoryBar';
import TrendingFeed from '../components/TrendingFeed';
import ProductGrid from '../components/ProductGrid';
import MobilePromoBanner from '../components/MobilePromoBanner';
import HomeReputationSection from '../components/HomeReputationSection';
import QuickLinks from '../components/QuickLinks';
import RecentlyViewedBar from '../components/RecentlyViewedBar';
import LivePulse from '../components/LivePulse';
import FlashDealsBanner from '../components/FlashDealsBanner';
import FATIBARAIntroAd from '../components/FATIBARAIntroAd';
import Footer from '../components/Footer';
import SEO from '../components/SEO';
import { APP_NAME } from '../lib/constants';

const TRUST_BADGES = [
  { icon: Truck, text: 'Livraison en 24h' },
  { icon: ShieldCheck, text: 'Paiement Sécurisé' },
  { icon: Award, text: 'Vendeurs Vérifiés' },
  { icon: Headset, text: 'Support 24/7' },
];

export default function HomePage() {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState<'all' | 'followed' | 'nearby'>('all');
  const [trustedStores, setTrustedStores] = useState<any[]>([]);

  useEffect(() => {
    let isMounted = true;
    supabase
      .from('stores')
      .select('id, store_name, avatar_url, location_commune, rating, is_verified_store')
      .eq('is_verified_store', true)
      .limit(8)
      .then(({ data }) => {
        if (isMounted && data) {
          setTrustedStores(data);
        }
      })
      .catch((err) => {
        console.error('Failed to fetch trusted stores:', err);
      });

    return () => {
      isMounted = false;
    };
  }, []);

  return (
    <div className="min-h-screen flex flex-col bg-gray-50 dark:bg-gray-950 transition-colors duration-500 selection:bg-[#ff6600] selection:text-white">
      <SEO />
      <FATIBARAIntroAd />
      <Header />
      <CategoryBar />
      
      <main className="flex-grow">
        <Hero />

        {/* Public promotional banner inspired by the FATIBARA concept preview. */}
        <section className="mx-auto mt-4 w-full max-w-[1400px] px-3 sm:px-5 md:mt-6 md:px-10" aria-label="Présentation FATIBARA">
          <div className="relative overflow-hidden rounded-[1.5rem] bg-gradient-to-r from-[#b94100] via-[#ff6600] to-[#ff9138] px-5 py-6 text-white shadow-lg sm:px-8 sm:py-8">
            <div aria-hidden="true" className="pointer-events-none absolute inset-0 opacity-15" style={{ backgroundImage: 'linear-gradient(rgba(255,255,255,.2) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,.2) 1px, transparent 1px)', backgroundSize: '32px 32px' }} />
            <div className="relative z-10 flex flex-col items-start justify-between gap-5 sm:flex-row sm:items-center">
              <div className="max-w-2xl">
                <span className="inline-flex rounded-full border border-white/30 bg-white/15 px-3 py-1 text-[10px] font-extrabold uppercase tracking-[.18em]">Le commerce en ligne, version Guinée</span>
                <h2 className="mt-3 text-2xl font-black leading-tight tracking-tight sm:text-3xl md:text-4xl">Vos envies. Vos boutiques. FATIBARA.</h2>
                <p className="mt-2 max-w-xl text-sm leading-relaxed text-white/90 sm:text-base">Explorez les produits disponibles, comparez les offres et découvrez les vendeurs de la communauté.</p>
              </div>
              <button onClick={() => navigate('/shop')} className="inline-flex shrink-0 items-center gap-2 rounded-full bg-white px-5 py-3 text-sm font-extrabold text-[#d94e00] shadow-md transition hover:-translate-y-0.5 hover:shadow-xl active:translate-y-0">Explorer les produits <ArrowRight className="h-4 w-4" /></button>
            </div>
            <div aria-hidden="true" className="absolute -bottom-16 -right-8 h-40 w-40 rounded-full border-[20px] border-white/10 sm:h-56 sm:w-56" />
          </div>
        </section>
        <FlashDealsBanner />
        
        {/* Trust & Security Banner */}
        <div className="hidden md:block bg-white dark:bg-gray-900 border-b border-gray-100 dark:border-gray-800/50">
          <div className="max-w-[1400px] mx-auto px-6 py-6">
             <div className="grid grid-cols-4 gap-6">
               {TRUST_BADGES.map((badge, idx) => (
                 <div key={idx} className="flex flex-col xl:flex-row items-center xl:items-start justify-center gap-4 bg-gray-50/50 dark:bg-gray-800/20 p-5 rounded-2xl group transition-all duration-300 hover:shadow-sm hover:bg-white dark:hover:bg-gray-800/40 border border-transparent hover:border-gray-100 dark:hover:border-gray-700/50">
                   <div className="text-gray-400 group-hover:text-[#ff6600] transition-all transform group-hover:scale-110 duration-500 bg-white dark:bg-gray-800 p-3 rounded-xl shadow-sm">
                     <badge.icon strokeWidth={2} className="w-6 h-6" />
                   </div>
                   <div className="text-center xl:text-left mt-2 xl:mt-1">
                     <span className="text-[14px] font-bold text-gray-900 dark:text-white tracking-wide block leading-none mb-1.5">{badge.text}</span>
                     <span className="text-[11px] font-medium text-gray-500 dark:text-gray-400">Garantie {APP_NAME}</span>
                   </div>
                 </div>
               ))}
             </div>
          </div>
        </div>

        {/* Trusted Vendors */}
        {trustedStores.length > 0 && (
          <div className="px-4 md:px-10 mt-10 mb-16">
             <div className="max-w-[1400px] mx-auto">
               <div className="flex items-end justify-between mb-8 px-2 md:px-4">
                  <div>
                    <h2 className="text-2xl md:text-3xl font-black text-gray-900 dark:text-white tracking-tight">
                      Boutiques Recommandées
                    </h2>
                  </div>
                  <button 
                    onClick={() => navigate('/shop')}
                    className="group flex items-center gap-2 text-[#ff6600] text-[13px] font-bold hover:underline transition-all"
                  >
                    Voir tout <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                  </button>
               </div>
                              <div className="flex gap-6 overflow-x-auto no-scrollbar pb-8 -mx-4 px-4 md:mx-0 md:px-0 scroll-smooth snap-x snap-mandatory">
                  {trustedStores.map((shop, i) => (
                    <motion.div 
                      key={shop.id}
                      initial={{ opacity: 0, y: 20 }}
                      whileInView={{ opacity: 1, y: 0 }}
                      transition={{ delay: i * 0.05, duration: 0.4, ease: "easeOut" }}
                      viewport={{ once: true, margin: "-50px" }}
                      className="flex-shrink-0 w-[260px] md:w-[320px] bg-white dark:bg-gray-900 rounded-3xl border border-gray-100 dark:border-gray-800/60 group cursor-pointer hover:border-[#ff6600]/30 hover:shadow-xl hover:shadow-[#ff6600]/5 transition-all duration-500 overflow-hidden snap-start relative"
                      onClick={() => navigate(`/boutique/${shop.store_name}`)}
                    >
                       <div className="h-40 md:h-48 bg-gray-100 dark:bg-gray-800 relative overflow-hidden group/img">
                          <div className="absolute inset-0 bg-gradient-to-tr from-gray-200 to-gray-100 dark:from-gray-800 dark:to-gray-700 animate-pulse" />
                          <img 
                            src={shop.avatar_url || `https://picsum.photos/seed/${shop.id}/600/400?blur=1`} 
                            alt={shop.store_name} 
                            className="w-full h-full object-cover relative z-10 group-hover/img:scale-110 transition-transform duration-700 ease-out" 
                            loading="lazy"
                          />
                          <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-black/10 to-transparent z-10" />
                          <div className="absolute top-3 left-3 flex items-center gap-1.5 px-2.5 py-1.5 bg-white/95 backdrop-blur-md rounded-xl text-[11px] font-black text-gray-900 shadow-sm z-20">
                            <Award className="w-3.5 h-3.5 text-[#ff6600]" /> TOP VENDEUR
                          </div>
                          
                          {/* Store Avatar Overlay */}
                          <div className="absolute -bottom-6 right-4 z-20">
                             <div className="w-14 h-14 bg-white dark:bg-gray-900 p-1 rounded-full shadow-lg">
                                <div className="w-full h-full bg-gray-100 dark:bg-gray-800 rounded-full overflow-hidden flex items-center justify-center text-xl">
                                  {shop.avatar_url ? (
                                     <img src={shop.avatar_url} alt="Logo" className="w-full h-full object-cover" />
                                  ) : (
                                     <span className="font-bold text-gray-400">{shop.store_name.charAt(0)}</span>
                                  )}
                                </div>
                             </div>
                          </div>
                       </div>
                       <div className="p-5 pt-8">
                          <div className="flex flex-col gap-1.5">
                            <h4 className="text-lg md:text-xl font-bold text-gray-900 dark:text-white truncate group-hover:text-[#ff6600] transition-colors">
                              {shop.store_name}
                            </h4>
                            <div className="flex items-center justify-between mt-1 text-gray-500 dark:text-gray-400">
                               <p className="text-[13px] font-medium truncate flex items-center gap-1">
                                 <svg className="w-3.5 h-3.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path strokeLinecap="round" strokeLinejoin="round" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" /><path strokeLinecap="round" strokeLinejoin="round" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" /></svg>
                                 {shop.location_commune || 'Conakry'}
                               </p>
                               <span className="text-[12px] font-bold text-white bg-gray-900 dark:bg-gray-700 px-2 py-0.5 rounded-lg flex items-center gap-1 shadow-sm">
                                  <svg className="w-3 h-3 text-yellow-400 fill-yellow-400" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M11.049 2.927c.3-.921 1.603-.921 1.902 0l1.519 4.674a1 1 0 00.95.69h4.915c.969 0 1.371 1.24.588 1.81l-3.976 2.888a1 1 0 00-.363 1.118l1.518 4.674c.3.922-.755 1.688-1.538 1.118l-3.976-2.888a1 1 0 00-1.176 0l-3.976 2.888c-.783.57-1.838-.197-1.538-1.118l1.518-4.674a1 1 0 00-.363-1.118l-3.976-2.888c-.784-.57-.38-1.81.588-1.81h4.914a1 1 0 00.951-.69l1.519-4.674z" /></svg>
                                  {shop.rating || '5.0'}
                               </span>
                            </div>
                          </div>
                       </div>
                    </motion.div>
                  ))}
               </div>
             </div>
          </div>
        )}

        <TrendingFeed />

        {/* Feed Tabs - Modern Pill Version */}
        <div className="sticky top-[110px] lg:top-[76px] z-[40] bg-white/80 dark:bg-gray-950/80 backdrop-blur-xl px-4 md:px-10 mt-6 md:mt-12 py-4 border-y border-gray-200/50 dark:border-gray-800/50 flex justify-center">
          <div className="inline-flex bg-gray-100/80 dark:bg-gray-900/80 p-1 rounded-full border border-gray-200/50 dark:border-gray-800/50 shadow-inner">
             {[
               { id: 'all', label: 'Pour Vous' },
               { id: 'nearby', label: 'Autour de moi' },
               { id: 'followed', label: 'Abonnements' }
             ].map((tab) => (
               <button 
                 key={tab.id}
                 onClick={() => setActiveTab(tab.id as any)}
                 className={`relative px-6 py-2.5 text-[14px] font-bold transition-colors rounded-full whitespace-nowrap ${
                   activeTab === tab.id 
                     ? 'text-white' 
                     : 'text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white'
                 }`}
               >
                 {activeTab === tab.id && (
                   <motion.div 
                     layoutId="activeTabPill" 
                     className="absolute inset-0 bg-gradient-to-r from-[#ff6600] to-orange-500 rounded-full shadow-md"
                     style={{ zIndex: -1 }}
                   />
                 )}
                 <span className="relative z-10">{tab.label}</span>
               </button>
             ))}
          </div>
        </div>

        <div className="py-10 bg-gray-50 dark:bg-gray-950">
           <ProductGrid filterType={activeTab} />
        </div>
        
        <div className="hidden md:block">
          <HomeReputationSection />
        </div>
        
        <div className="md:hidden">
          <QuickLinks />
        </div>

        <RecentlyViewedBar />
      </main>


      <LivePulse />
      <Footer />
    </div>
  );
}
