import { Coins, Zap, TreePalm, Sparkles, Tag } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

export default function QuickLinks() {
  const navigate = useNavigate();
  const links = [
    { icon: <Coins className="w-6 h-6 text-orange-500" />, label: 'Jetons', path: '/rewards?type=tokens' },
    { icon: <Zap className="w-6 h-6 text-red-500" />, label: 'Super offres', path: '/shop?promo=true' },
    { icon: <TreePalm className="w-6 h-6 text-green-500" />, label: 'Récompenses', path: '/loyalty' },
    { icon: <Sparkles className="w-6 h-6 text-purple-500" />, label: 'Nouveautés', path: '/search?sort=newest' },
    { icon: <Tag className="w-6 h-6 text-[#ff6600]" />, label: 'Coupons', path: '/coupons' },
  ];

  return (
    <div className="flex justify-between items-start px-4 py-8 md:hidden overflow-x-auto no-scrollbar gap-4 bg-white dark:bg-gray-950">
      {links.map((link, idx) => (
        <button 
          key={idx} 
          onClick={() => navigate(link.path)}
          className="flex flex-col items-center gap-2 group min-w-[64px]"
        >
          <div className="w-14 h-14 rounded-2xl bg-white dark:bg-gray-900 shadow-sm border border-brand-border/30 dark:border-white/10 flex items-center justify-center group-active:scale-95 transition-transform">
            {link.icon}
          </div>
          <span className="text-[10px] font-bold text-center max-w-[64px] leading-tight tracking-wider text-gray-900 dark:text-gray-200 uppercase">{link.label}</span>
        </button>
      ))}
    </div>
  );
}
