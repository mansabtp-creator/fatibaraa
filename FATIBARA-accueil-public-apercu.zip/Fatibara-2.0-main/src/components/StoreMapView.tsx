import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { MapPin, Navigation, Store as StoreIcon, X, ArrowRight, Star } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { useNavigate } from 'react-router-dom';

const CONAKRY_COORDINATES: { [key: string]: { x: number, y: number } } = {
  'Kaloum': { x: 10, y: 85 },
  'Dixinn': { x: 25, y: 70 },
  'Matam': { x: 40, y: 65 },
  'Gbessia': { x: 50, y: 60 },
  'Matoto': { x: 65, y: 50 },
  'Tombolia': { x: 75, y: 45 },
  'Sanoyah': { x: 85, y: 40 },
  'Maneah': { x: 92, y: 38 },
  'Ratoma': { x: 55, y: 40 },
  'Lambanyi': { x: 45, y: 35 },
  'Sonfonia': { x: 60, y: 32 },
  'Kagbelen': { x: 80, y: 30 },
  'Kassa': { x: 5, y: 95 }
};

export default function StoreMapView({ isOpen, onClose }: { isOpen: boolean; onClose: () => void }) {
  const [stores, setStores] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedStore, setSelectedStore] = useState<any>(null);
  const navigate = useNavigate();

  useEffect(() => {
    if (isOpen) {
      fetchStores();
    }
  }, [isOpen]);

  const fetchStores = async () => {
    const { data, error } = await supabase
      .from('stores')
      .select('*, profiles(full_name, avatar_url)')
      .eq('is_open', true);
    
    if (!error && data) {
      setStores(data);
    }
    setLoading(false);
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/80 backdrop-blur-md z-[150]"
          />
          <motion.div
            initial={{ scale: 0.9, opacity: 0, y: 20 }}
            animate={{ scale: 1, opacity: 1, y: 0 }}
            exit={{ scale: 0.9, opacity: 0, y: 20 }}
            className="fixed inset-4 md:inset-10 lg:inset-20 bg-gray-50 dark:bg-gray-800 dark:bg-gray-950 rounded-[3rem] shadow-2xl z-[151] overflow-hidden flex flex-col md:flex-row border border-white dark:border-white/5"
          >
            {/* Map Section */}
            <div className="flex-1 bg-gray-900 relative overflow-hidden flex items-center justify-center p-8">
              
              <button 
                onClick={onClose}
                className="absolute top-8 right-8 z-10 w-12 h-12 bg-white/10 hover:bg-white/20 backdrop-blur-md rounded-full flex items-center justify-center text-white transition-all"
              >
                <X className="w-6 h-6" />
              </button>

              {/* Stylized SVG Conakry Map */}
              <div className="relative w-full max-w-4xl aspect-[2/1] opacity-90">
                 {/* Simplified Conakry Peninsula Outline */}
                 <svg viewBox="0 0 100 100" className="w-full h-full drop-shadow-sm">
                    <path 
                      d="M 5 95 Q 15 90 20 80 Q 25 70 35 65 Q 45 60 55 40 Q 65 30 80 30 Q 95 30 95 40 L 95 50 Q 80 55 70 65 Q 60 75 45 85 Q 35 95 15 100 L 5 95" 
                      fill="rgba(255,255,255,0.05)" 
                      stroke="rgba(255,255,255,0.1)" 
                      strokeWidth="0.5" 
                    />
                    
                    {/* Communes Labels */}
                    {Object.entries(CONAKRY_COORDINATES).map(([name, pos]) => (
                      <text 
                        key={name}
                        x={pos.x} 
                        y={pos.y + 10} 
                        className="text-[3px] font-bold fill-white/20 tracking-wider select-none"
                      >
                        {name}
                      </text>
                    ))}
                 </svg>

                 {/* Merchant Pins */}
                 {stores.map((store) => {
                   const pos = CONAKRY_COORDINATES[store.location_commune] || { x: 50, y: 50 };
                   // Add small offset for multiple stores in same commune
                   const offset = (store.id.charCodeAt(0) % 10) - 5;
                   
                   return (
                     <motion.button
                       key={store.id}
                       initial={{ scale: 0 }}
                       animate={{ scale: 1 }}
                       whileHover={{ scale: 1.2, zIndex: 10 }}
                       onClick={() => setSelectedStore(store)}
                       className="absolute flex flex-col items-center group cursor-pointer"
                       style={{ left: `${pos.x + offset}%`, top: `${pos.y + offset}%` }}
                     >
                        <div className={`p-2 rounded-full shadow-lg transition-all ${selectedStore?.id === store.id ? 'bg-[#ff6600] scale-125' : 'bg-white dark:bg-gray-900 dark:bg-gray-800 group-hover:bg-[#ff6600]'}`}>
                           <StoreIcon className={`w-4 h-4 ${selectedStore?.id === store.id ? 'text-white' : 'text-gray-900 text-gray-900 dark:text-white group-hover:text-white'}`} />
                        </div>
                        <div className="absolute top-full mt-2 bg-gray-900 border border-white/20 px-3 py-1 rounded-full whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity">
                           <span className="text-[9px] font-bold text-white tracking-wider">{store.store_name}</span>
                        </div>
                     </motion.button>
                   );
                 })}
              </div>

              {/* Stats Overlay */}
              <div className="absolute bottom-8 left-8 flex gap-6 hidden">
                 <div className="flex flex-col">
                    <span className="text-[#ff6600] text-2xl font-bold">{stores.length}</span>
                    <span className="text-white/40 text-[9px] font-bold tracking-wider">Marchands Actifs</span>
                 </div>
                 <div className="flex flex-col border-l border-white/10 pl-6">
                    <span className="text-green-500 text-2xl font-bold">LIVE</span>
                    <span className="text-white/40 text-[9px] font-bold tracking-wider">Connectivité</span>
                 </div>
              </div>
            </div>

            {/* Sidebar / Store View */}
            <div className="w-full md:w-[400px] bg-white bg-white dark:bg-gray-900 border-l border-brand-border/30 dark:border-white/5 p-8 flex flex-col overflow-y-auto">
               <AnimatePresence mode="wait">
                  {selectedStore ? (
                    <motion.div
                      key={selectedStore.id}
                      initial={{ opacity: 0, x: 20 }}
                      animate={{ opacity: 1, x: 0 }}
                      exit={{ opacity: 0, x: -20 }}
                      className="flex-1 flex flex-col"
                    >
                       <div className="relative aspect-video rounded-[2rem] overflow-hidden mb-6 border border-brand-border/30 dark:border-white/5">
                          <img 
                            src={selectedStore.banner_url || "https://picsum.photos/seed/banner/800/400"} 
                            className="w-full h-full object-cover" 
                          />
                          <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent" />
                          <div className="absolute bottom-4 left-6">
                             <h3 className="text-xl font-bold text-white tracking-tighter uppercase">{selectedStore.store_name}</h3>
                             <p className="text-[#ff6600] dark:text-orange-400 text-[10px] font-bold tracking-wider">{selectedStore.location_commune}, Conakry</p>
                          </div>
                       </div>

                       <div className="flex-1 space-y-8">
                          <div className="flex items-center justify-between">
                             <div className="flex items-center gap-3">
                                <div className="w-12 h-12 rounded-2xl bg-gray-50 bg-gray-50 dark:bg-gray-800 border border-brand-border/30 dark:border-white/5 overflow-hidden">
                                   <img src={selectedStore.avatar_url || "https://picsum.photos/seed/avatar/200/200"} className="w-full h-full object-cover" />
                                </div>
                                <div>
                                   <p className="text-[10px] font-bold text-brand-text-dim dark:text-gray-500 dark:text-gray-400 tracking-wider">Gérant</p>
                                   <p className="text-[14px] font-bold text-gray-900 text-gray-900 dark:text-white">{selectedStore.profiles?.full_name || 'Particulier'}</p>
                                </div>
                             </div>
                             <div className="flex flex-col items-end">
                                <div className="flex items-center gap-1 text-yellow-500">
                                   <Star className="w-4 h-4 fill-current" />
                                   <span className="text-[14px] font-bold">4.9</span>
                                </div>
                                <span className="text-[10px] font-bold text-brand-text-dim dark:text-gray-500 dark:text-gray-400">120 avis</span>
                             </div>
                          </div>

                          <div className="space-y-4">
                             <p className="text-[13px] text-brand-text-muted dark:text-gray-400 font-medium leading-relaxed">
                                {selectedStore.description || "Spécialiste de la mode et de l'électronique de qualité à Conakry. Livraison rapide assurée par nos propres agents."}
                             </p>
                             
                             <div className="p-4 bg-[#ff6600]/5 dark:bg-[#ff6600]/10 border border-[#ff6600]/10 dark:border-[#ff6600]/20 rounded-2xl flex items-center gap-3">
                                <div className="w-10 h-10 bg-[#ff6600] text-white rounded-xl flex items-center justify-center">
                                   <Navigation className="w-5 h-5 animate-pulse" />
                                </div>
                                <div>
                                   <p className="text-[11px] font-bold text-gray-900 text-gray-900 dark:text-white uppercase tracking-tighter leading-none mb-1">Livraison Predict</p>
                                   <p className="text-[10px] font-bold text-brand-text-muted dark:text-gray-400">D'ici 2-3 heures vers votre zone</p>
                                </div>
                             </div>
                          </div>
                       </div>

                       <div className="pt-8 mt-auto flex gap-3">
                          <button 
                            onClick={() => {
                              onClose();
                              navigate(`/boutique/${selectedStore.store_name}`);
                            }}
                            className="flex-1 bg-gray-900 dark:bg-[#ff6600] text-white py-4 rounded-2xl text-[11px] font-bold tracking-wider hover:bg-black dark:hover:bg-[#ff6600] transition-all flex items-center justify-center gap-2"
                          >
                             Visiter Boutique <ArrowRight className="w-3 h-3" />
                          </button>
                          <button className="w-14 h-14 bg-gray-50 bg-gray-50 dark:bg-gray-800 border border-brand-border/30 dark:border-white/5 rounded-2xl flex items-center justify-center hover:bg-[#ff6600] dark:hover:bg-[#ff6600] hover:text-white transition-all text-gray-900 text-gray-900 dark:text-white">
                             <Navigation className="w-6 h-6" />
                          </button>
                       </div>
                    </motion.div>
                  ) : (
                    <div className="flex-1 flex flex-col items-center justify-center text-center space-y-6">
                       <div className="w-20 h-20 bg-gray-50 bg-gray-50 dark:bg-gray-800 rounded-full flex items-center justify-center">
                          <MapPin className="w-10 h-10 text-brand-text-dim/30 dark:text-gray-600 animate-bounce" />
                       </div>
                       <div>
                          <h3 className="text-xl font-bold text-gray-900 text-gray-900 dark:text-white">Choisissez un Marchand</h3>
                          <p className="text-sm font-medium text-brand-text-muted dark:text-gray-400 px-8">Touchez les points sur la carte pour découvrir les pépites autour de vous.</p>
                       </div>
                    </div>
                  )}
               </AnimatePresence>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
