import React from 'react';
import { Star } from 'lucide-react';

interface RatingProps {
  rating: number; // 0 to 5
  maxRating?: number;
  size?: number;
  className?: string;
  showText?: boolean;
}

export default function Rating({ rating, maxRating = 5, size = 16, className = '', showText = false }: RatingProps) {
  return (
    <div className={`flex items-center gap-1 ${className}`}>
      <div className="flex">
        {[...Array(maxRating)].map((_, i) => (
          <Star
            key={i}
            size={size}
            className={`${
              i < Math.round(rating)
                ? 'fill-[#ff6600] text-[#ff6600] dark:fill-orange-400 dark:text-orange-400'
                : 'fill-brand-surface-light dark:fill-gray-800 text-brand-text-dim dark:text-gray-600'
            }`}
          />
        ))}
      </div>
      {showText && (
        <span className="text-[12px] font-bold text-gray-900 text-gray-900 dark:text-white ml-1">
          {rating.toFixed(1)}
        </span>
      )}
    </div>
  );
}
