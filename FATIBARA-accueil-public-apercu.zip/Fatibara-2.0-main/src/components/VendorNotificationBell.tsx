import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Bell, ShoppingBag, AlertTriangle, ChevronRight, X } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { supabase, validateSessionOrClear } from '../lib/supabase';

interface Notification {
  id: string;
  type: 'order' | 'stock' | 'system';
  title: string;
  message: string;
  time: string;
  read: boolean;
}

export default function VendorNotificationBell({ vendorId }: { vendorId: string }) {
  const navigate = useNavigate();
  const buttonRef = useRef<HTMLButtonElement>(null);
  const [isOpen, setIsOpen] = useState(false);
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [unreadCount, setUnreadCount] = useState(0);
  // Fixed panel position, calculated from the button's screen rect
  const [panelStyle, setPanelStyle] = useState<React.CSSProperties>({});

  const markAllAsRead = () => {
    setNotifications(prev => prev.map(n => ({ ...n, read: true })));
    setUnreadCount(0);
  };

  const handleNotificationClick = (n: Notification) => {
    setNotifications(prev =>
      prev.map(item => (item.id === n.id ? { ...item, read: true } : item))
    );
    setUnreadCount(c => Math.max(0, c - (n.read ? 0 : 1)));
    if (n.type === 'order') navigate('/vendor/orders');
    else if (n.type === 'stock') navigate('/vendor/products');
    setIsOpen(false);
  };

  const togglePanel = () => {
    if (!isOpen && buttonRef.current) {
      const rect = buttonRef.current.getBoundingClientRect();
      const MARGIN = 16;
      const panelMaxWidth = Math.min(window.innerWidth - MARGIN * 2, 400);

      // Prefer to anchor left edge to the bell's left, shift left only if it would
      // overflow the right edge of the viewport.
      let leftPos = rect.left;
      if (leftPos + panelMaxWidth > window.innerWidth - MARGIN) {
        leftPos = window.innerWidth - panelMaxWidth - MARGIN;
      }
      // Never overflow left edge
      if (leftPos < MARGIN) leftPos = MARGIN;

      setPanelStyle({
        position: 'fixed',
        top: rect.bottom + 10,
        left: leftPos,
        width: panelMaxWidth,
        zIndex: 9999,
      });
    }
    setIsOpen(prev => !prev);
  };

  useEffect(() => {
    async function fetchNotifications() {
      if (!vendorId) return;
      try {
        const session = await validateSessionOrClear();
        if (!session) {
          console.warn('[VendorNotificationBell] No active session — skipping.');
          return;
        }

        const { data: orders } = await supabase
          .from('orders')
          .select('id, created_at, customer_name, total_amount')
          .eq('vendor_id', vendorId)
          .order('created_at', { ascending: false })
          .limit(5);

        const { data: store, error: storeError } = await supabase
          .from('stores')
          .select('id')
          .eq('owner_id', vendorId)
          .maybeSingle();

        if (storeError) {
          const code = storeError.code as string | undefined;
          const msg  = storeError.message as string | undefined;
          if (code === '406' || msg?.toLowerCase().includes('not acceptable')) {
            await validateSessionOrClear();
          } else {
            console.error('[VendorNotificationBell] stores error:', storeError);
          }
        }

        let lowStockAlerts: any[] = [];
        if (store) {
          const { data: prods } = await supabase
            .from('products')
            .select('id, title, stock_quantity')
            .eq('store_id', store.id)
            .lte('stock_quantity', 5)
            .limit(3);
          lowStockAlerts = prods || [];
        }

        const news: Notification[] = [
          ...(orders || []).map(o => ({
            id: `order-${o.id}`,
            type: 'order' as const,
            title: 'Nouvelle Commande',
            message: `De ${o.customer_name} pour ${o.total_amount.toLocaleString()} GNF`,
            time: o.created_at,
            read: false,
          })),
          ...(lowStockAlerts || []).map(p => ({
            id: `stock-${p.id}`,
            type: 'stock' as const,
            title: 'Stock Critique',
            message: `"${p.title}" est presque épuisé (${p.stock_quantity} restants)`,
            time: new Date().toISOString(),
            read: false,
          })),
        ].sort((a, b) => new Date(b.time).getTime() - new Date(a.time).getTime());

        setNotifications(news);
        setUnreadCount(news.length);
      } catch (err) {
        console.error('[VendorNotificationBell] Error:', err);
      }
    }

    fetchNotifications();

    const channel = supabase
      .channel(`vendor-notifications:${vendorId}`)
      .on(
        'postgres_changes',
        { event: 'INSERT', schema: 'public', table: 'orders', filter: `vendor_id=eq.${vendorId}` },
        (payload) => {
          const o = payload.new as any;
          setNotifications(prev => [
            {
              id: `order-${o.id}`,
              type: 'order',
              title: 'Nouvelle Commande',
              message: `Nouveau client pour ${o.total_amount.toLocaleString()} GNF`,
              time: o.created_at,
              read: false,
            },
            ...prev,
          ]);
          setUnreadCount(c => c + 1);
        }
      )
      .subscribe((status, err) => {
        if (status === 'CHANNEL_ERROR' || status === 'TIMED_OUT') {
          const errMsg = err?.message || String(err || '');
          if (errMsg.toLowerCase().includes('heartbeat') || errMsg.toLowerCase().includes('timeout')) {
            // Heartbeat/timeout renegotiations are handled automatically by the Supabase client
            console.debug('[VendorNotificationBell] Realtime connection transient heartbeat timeout — auto-reconnecting');
          } else {
            console.warn('[VendorNotificationBell] Realtime subscription notice:', status, err);
          }
        }
      });

    return () => { supabase.removeChannel(channel); };
  }, [vendorId]);

  return (
    <>
      {/* Bell trigger button */}
      <button
        ref={buttonRef}
        onClick={togglePanel}
        className="w-12 h-12 md:w-14 md:h-14 bg-white dark:bg-[#1A1D21] rounded-2xl border border-brand-border/30 dark:border-white/10 flex items-center justify-center relative hover:border-[#ff6600]/50 transition-all active:scale-95 group shadow-sm hover:shadow-md"
      >
        <Bell
          className={`w-5 h-5 md:w-6 md:h-6 transition-colors ${
            unreadCount > 0
              ? 'text-[#ff6600]'
              : 'text-gray-400 group-hover:text-gray-900 dark:group-hover:text-white'
          }`}
        />
        {unreadCount > 0 && (
          <span className="absolute -top-1 -right-1 w-5 h-5 bg-[#ff6600] text-white text-[9px] font-bold rounded-full border border-white dark:border-[#1A1D21] flex items-center justify-center">
            {unreadCount}
          </span>
        )}
      </button>

      <AnimatePresence>
        {isOpen && (
          <>
            {/* Invisible full-screen backdrop to close on outside click */}
            <div className="fixed inset-0 z-[9998]" onClick={() => setIsOpen(false)} />

            {/* Panel — rendered at fixed screen coords, immune to overflow:hidden */}
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 8 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 6 }}
              transition={{ type: 'spring', stiffness: 300, damping: 26 }}
              style={panelStyle}
              className="bg-white/95 dark:bg-[#1A1D21]/95 backdrop-blur-md border border-gray-200/50 dark:border-white/10 rounded-[2rem] shadow-2xl overflow-hidden"
            >
              {/* Header */}
              <div className="p-5 md:p-6 bg-gray-50/50 dark:bg-gray-800/40 border-b border-gray-100 dark:border-white/5 flex items-center justify-between">
                <h3 className="text-xs font-black text-gray-900 dark:text-white tracking-widest uppercase">
                  Notifications
                </h3>
                <div className="flex items-center gap-3">
                  <button
                    onClick={markAllAsRead}
                    className="text-[10px] font-black tracking-widest text-[#ff6600] hover:opacity-70 transition-opacity uppercase"
                  >
                    Tout lu
                  </button>
                  <button
                    onClick={() => setIsOpen(false)}
                    className="text-gray-400 hover:text-gray-700 dark:hover:text-gray-200 transition-colors"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {/* Notification list */}
              <div className="max-h-[360px] overflow-y-auto">
                {notifications.length === 0 ? (
                  <div className="py-14 flex flex-col items-center justify-center text-center opacity-40">
                    <Bell className="w-10 h-10 mb-3 text-gray-300 dark:text-gray-600" />
                    <p className="text-[11px] font-bold text-gray-400 dark:text-gray-500 uppercase tracking-widest">
                      Aucune alerte
                    </p>
                  </div>
                ) : (
                  notifications.map(n => (
                    <div
                      key={n.id}
                      onClick={() => handleNotificationClick(n)}
                      className={`p-5 flex gap-4 cursor-pointer transition-colors hover:bg-gray-50 dark:hover:bg-white/5 border-b border-gray-50 dark:border-white/5 last:border-b-0 ${
                        !n.read
                          ? 'bg-[#ff6600]/5 dark:bg-[#ff6600]/10 border-l-[3px] border-l-[#ff6600]'
                          : ''
                      }`}
                    >
                      <div
                        className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${
                          n.type === 'order'
                            ? 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400'
                            : 'bg-orange-500/10 text-orange-600 dark:text-orange-400'
                        }`}
                      >
                        {n.type === 'order' ? (
                          <ShoppingBag className="w-5 h-5" />
                        ) : (
                          <AlertTriangle className="w-5 h-5" />
                        )}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex justify-between items-start mb-1 gap-2">
                          <span className="text-[12px] font-black text-gray-900 dark:text-white tracking-tight uppercase leading-none">
                            {n.title}
                          </span>
                          <span className="text-[8px] font-bold text-gray-400 dark:text-gray-500 uppercase tracking-tighter whitespace-nowrap">
                            {new Date(n.time).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                          </span>
                        </div>
                        <p className="text-[11px] font-bold text-gray-500 dark:text-gray-400 truncate uppercase tracking-tight">
                          {n.message}
                        </p>
                      </div>
                      <ChevronRight className="w-4 h-4 text-gray-300 dark:text-gray-600 self-center shrink-0" />
                    </div>
                  ))
                )}
              </div>

              {/* Footer CTA */}
              <div className="p-5 border-t border-gray-100 dark:border-white/5 bg-gray-50/50 dark:bg-gray-800/40">
                <button
                  onClick={() => { navigate('/vendor/orders'); setIsOpen(false); }}
                  className="w-full py-3.5 rounded-2xl text-[10px] font-black tracking-widest text-gray-900 dark:text-white hover:bg-gray-900 dark:hover:bg-[#ff6600] hover:text-white border border-gray-200 dark:border-white/10 transition-all uppercase"
                >
                  Voir toutes les commandes
                </button>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </>
  );
}
