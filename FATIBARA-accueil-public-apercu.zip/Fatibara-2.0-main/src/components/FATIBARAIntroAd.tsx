import { useEffect, useState } from 'react';
import { ArrowRight, ShoppingBag, X } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

/** Introductory brand advert for the public storefront only.
 * It is presentation-only: it does not alter accounts, checkout, payments, or orders.
 */
export default function FATIBARAIntroAd() {
  const [open, setOpen] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    try {
      if (sessionStorage.getItem('fatibara-intro-ad-seen') !== '1') {
        setOpen(true);
        sessionStorage.setItem('fatibara-intro-ad-seen', '1');
      }
    } catch {
      // If browser storage is unavailable, keep the storefront usable without the overlay.
    }
  }, []);

  useEffect(() => {
    if (!open) return;
    const timer = window.setTimeout(() => setOpen(false), 5400);
    return () => window.clearTimeout(timer);
  }, [open]);

  if (!open) return null;

  const explore = () => {
    setOpen(false);
    navigate('/shop');
  };

  return (
    <div className="fixed inset-0 z-[300] flex items-center justify-center bg-[#17120f]/90 p-4 backdrop-blur-md" role="dialog" aria-modal="true" aria-label="Présentation de FATIBARA">
      <div className="relative w-full max-w-xl overflow-hidden rounded-[2rem] border border-white/15 bg-gradient-to-br from-[#a83b00] via-[#ff6600] to-[#ff9b42] px-6 py-10 text-white shadow-2xl sm:px-10 sm:py-12">
        <div aria-hidden="true" className="pointer-events-none absolute inset-0 opacity-20" style={{ backgroundImage: 'linear-gradient(rgba(255,255,255,.22) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,.22) 1px, transparent 1px)', backgroundSize: '34px 34px', maskImage: 'linear-gradient(120deg, transparent 5%, black 100%)' }} />
        <button onClick={() => setOpen(false)} className="absolute right-4 top-4 z-10 rounded-full bg-black/15 p-2 text-white/90 transition hover:bg-black/30" aria-label="Fermer la publicité"><X className="h-5 w-5" /></button>
        <div className="relative z-10 mx-auto flex max-w-md flex-col items-center text-center">
          <div className="mb-5 flex h-16 w-16 items-center justify-center rounded-2xl border border-white/30 bg-white/15 shadow-lg backdrop-blur">
            <ShoppingBag className="h-8 w-8" strokeWidth={2.2} />
          </div>
          <p className="text-xs font-black uppercase tracking-[.28em] text-white/80">Bienvenue sur</p>
          <h2 className="mt-2 text-4xl font-black tracking-tight sm:text-6xl">FATIBARA<span className="text-[#ffe6b7]">.</span></h2>
          <p className="mt-4 max-w-sm text-base leading-relaxed text-white/90 sm:text-lg">Découvrez des produits, explorez les boutiques et trouvez vos prochains coups de cœur en Guinée.</p>
          <button onClick={explore} className="mt-7 inline-flex items-center gap-2 rounded-full bg-white px-6 py-3.5 text-sm font-extrabold text-[#d94e00] shadow-xl transition hover:-translate-y-0.5 hover:shadow-2xl active:translate-y-0">
            Découvrir la boutique <ArrowRight className="h-4 w-4" />
          </button>
          <button onClick={() => setOpen(false)} className="mt-4 text-xs font-semibold text-white/75 underline underline-offset-4 hover:text-white">Passer la présentation</button>
        </div>
        <div className="absolute -bottom-16 -right-12 h-48 w-48 rounded-full border-[24px] border-white/10" aria-hidden="true" />
        <div className="absolute -left-16 -top-16 h-48 w-48 rounded-full border-[24px] border-white/10" aria-hidden="true" />
      </div>
    </div>
  );
}
