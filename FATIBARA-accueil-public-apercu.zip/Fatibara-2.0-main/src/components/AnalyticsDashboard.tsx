import React, { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell, AreaChart, Area } from 'recharts';
import { Users, TrendingUp, Eye, ShoppingCart, ShoppingBag, Loader2, ArrowUpRight, ArrowDownRight, Target, Zap, MousePointer2 } from 'lucide-react';
import { motion } from 'motion/react';
import { APP_NAME } from '../lib/constants';

interface AnalyticsDashboardProps {
  storeId: string;
  vendorId: string;
}

export function AnalyticsDashboard({ storeId, vendorId }: AnalyticsDashboardProps) {
  const [liveVisitors, setLiveVisitors] = useState(0);
  const [funnelData, setFunnelData] = useState<any[]>([]);
  const [productInsights, setProductInsights] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchAnalytics();
    const cleanupRealtime = setupRealtime();
    
    // Refresh analytics every 2 minutes
    const interval = setInterval(fetchAnalytics, 120000);
    return () => {
      clearInterval(interval);
      if (cleanupRealtime) cleanupRealtime();
    };
  }, [storeId]);

  const fetchAnalytics = async () => {
    try {
      setLoading(true);

      // Fetch products belonging to this store first to avoid PostgREST embedding relationship errors
      const { data: storeProducts } = await supabase
        .from('products')
        .select('id, title, image_url')
        .eq('store_id', storeId);

      const productsMap = new Map<string, { title: string; image?: string }>();
      (storeProducts || []).forEach(p => {
        productsMap.set(p.id, { title: p.title || 'Produit inconnu', image: p.image_url });
      });

      const productIds = Array.from(productsMap.keys());

      // 1. Fetch Funnel Totals
      const [viewsRes, cartRes, ordersRes] = await Promise.all([
        productIds.length > 0
          ? supabase.from('product_views').select('*', { count: 'exact', head: true }).in('product_id', productIds)
          : Promise.resolve({ count: 0, data: null, error: null }),
        supabase.from('cart_events').select('*', { count: 'exact', head: true }).eq('store_id', storeId),
        supabase.from('orders').select('*', { count: 'exact', head: true }).eq('vendor_id', vendorId).in('status', ['paid', 'confirmed', 'shipped', 'delivered', 'completed'])
      ]);

      const data = [
        { name: 'Vues', value: viewsRes.count || 0, color: '#94a3b8' },
        { name: 'Paniers', value: cartRes.count || 0, color: '#f59e0b' },
        { name: 'Achats', value: ordersRes.count || 0, color: '#10b981' }
      ];
      setFunnelData(data);

      // 2. Fetch Product Level Insights
      if (productIds.length > 0) {
        const { data: viewsByProduct } = await supabase
          .from('product_views')
          .select('product_id')
          .in('product_id', productIds);

        const insightsMap: Record<string, { id: string; title: string; image?: string; views: number; sales: number }> = {};

        viewsByProduct?.forEach((v: any) => {
          const id = v.product_id;
          if (!insightsMap[id]) {
            const pInfo = productsMap.get(id);
            insightsMap[id] = { 
              id, 
              title: pInfo?.title || 'Produit inconnu', 
              image: pInfo?.image,
              views: 0, 
              sales: 0 
            };
          }
          insightsMap[id].views++;
        });

        const activeProductIds = Object.keys(insightsMap);
        if (activeProductIds.length > 0) {
          const { data: orderItems } = await supabase
            .from('order_items')
            .select('product_id, quantity')
            .in('product_id', activeProductIds);

          orderItems?.forEach((item: any) => {
            if (insightsMap[item.product_id]) {
              insightsMap[item.product_id].sales += item.quantity || 0;
            }
          });
        }

        const insightsArray = Object.values(insightsMap)
          .sort((a, b) => b.views - a.views)
          .slice(0, 5)
          .map((p) => ({
            ...p,
            conversion: p.views > 0 ? ((p.sales / p.views) * 100).toFixed(1) : '0'
          }));

        setProductInsights(insightsArray);
      } else {
        setProductInsights([]);
      }

    } catch (error) {
      console.error('Error fetching analytics:', error);
    } finally {
      setLoading(false);
    }
  };

  const setupRealtime = () => {
    const channelName = `presence-${storeId}-${Math.random().toString(36).substring(2, 7)}`;
    const channel = supabase.channel(channelName, {
      config: {
        presence: {
          key: storeId,
        },
      },
    });

    channel
      .on('presence', { event: 'sync' }, () => {
        const state = channel.presenceState();
        // Flatten presence states and count unique user sessions
        const count = Object.values(state).reduce((acc: number, userPresences: any) => acc + (userPresences?.length || 0), 0);
        setLiveVisitors(count);
      })
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center p-20">
        <Loader2 className="w-8 h-8 animate-spin text-[#ff6600]" />
      </div>
    );
  }

  return (
    <div className="space-y-8">
      {/* Live Badge & Overview */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <motion.div 
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white dark:bg-gray-900 border border-brand-border/30 rounded-[2rem] p-6 flex items-center justify-between"
        >
          <div className="space-y-1">
            <p className="text-[10px] font-bold tracking-wider text-brand-text-dim">Visiteurs en direct</p>
            <div className="flex items-center gap-2">
              <span className="text-3xl font-bold text-gray-900 dark:text-white">{liveVisitors}</span>
              <div className="flex h-3 w-3 relative">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-3 w-3 bg-green-500"></span>
              </div>
            </div>
          </div>
          <div className="w-12 h-12 rounded-2xl bg-green-500/10 flex items-center justify-center text-green-500">
            <Users className="w-6 h-6" />
          </div>
        </motion.div>

        {funnelData.map((stat, idx) => (
          <motion.div 
            key={stat.name}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: idx * 0.1 }}
            className="bg-white dark:bg-gray-900 border border-brand-border/30 rounded-[2rem] p-6 flex items-center justify-between"
          >
            <div className="space-y-1">
              <p className="text-[10px] font-bold tracking-wider text-brand-text-dim">{stat.name}</p>
              <p className="text-3xl font-bold text-gray-900 dark:text-white">{stat.value.toLocaleString()}</p>
            </div>
            <div className="w-12 h-12 rounded-2xl flex items-center justify-center" style={{ backgroundColor: `${stat.color}15`, color: stat.color }}>
              {stat.name === 'Vues' ? <Eye className="w-6 h-6" /> : stat.name === 'Paniers' ? <ShoppingCart className="w-6 h-6" /> : <ShoppingBag className="w-6 h-6" />}
            </div>
          </motion.div>
        ))}
      </div>

      {/* funnel Chart */}
      <div className="bg-white dark:bg-[#1A1D21] border border-gray-100 dark:border-white/5 rounded-[2.5rem] p-8 shadow-sm">
        <div className="flex items-center justify-between mb-10 pb-6 border-b border-gray-100 dark:border-white/5">
          <div>
            <h2 className="text-xl font-black text-gray-900 dark:text-white uppercase tracking-tight italic decoration-[#ff6600] decoration-2 underline-offset-4">Entonnoir de Conversion</h2>
            <p className="text-[10px] font-black text-gray-400 uppercase tracking-[0.2em] mt-1.5">Algorithmes d'acquisition client</p>
          </div>
          <div className="px-5 py-2.5 bg-[#ff6600]/10 border border-[#ff6600]/20 rounded-xl flex items-center gap-3">
            <div className="w-2 h-2 rounded-full bg-[#ff6600] animate-pulse" />
            <span className="text-[11px] font-black uppercase tracking-widest text-[#ff6600]">Live Analytics</span>
          </div>
        </div>

        <div className="h-[320px] w-full">
          <ResponsiveContainer width="100%" height="100%" minWidth={0} minHeight={0}>
            <BarChart data={funnelData} layout="vertical" margin={{ left: 0, right: 30 }}>
              <XAxis type="number" hide />
              <YAxis 
                type="category" 
                dataKey="name" 
                width={100} 
                tick={{ fontSize: 11, fontWeight: 900, fill: '#94a3b8' }}
                axisLine={false}
                tickLine={false}
              />
              <Tooltip 
                cursor={{ fill: 'rgba(255,102,0,0.03)' }}
                contentStyle={{ 
                  borderRadius: '1.25rem', 
                  border: 'none', 
                  boxShadow: '0 20px 25px -5px rgb(0 0 0 / 0.1)',
                  fontWeight: 900,
                  fontSize: '11px',
                  textTransform: 'uppercase',
                  padding: '12px 16px'
                }}
              />
              <Bar dataKey="value" radius={[0, 12, 12, 0]} barSize={44}>
                {funnelData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-10">
          {[
            { label: 'Taux de Mise au Panier', val: funnelData[0].value > 0 ? ((funnelData[1].value / funnelData[0].value) * 100).toFixed(1) : 0, color: 'text-orange-500' },
            { label: 'Taux de Conversion', val: funnelData[1].value > 0 ? ((funnelData[2].value / funnelData[1].value) * 100).toFixed(1) : 0, color: 'text-[#ff6600]' },
            { label: 'Indice de Performance', val: funnelData[0].value > 0 ? ((funnelData[2].value / funnelData[0].value) * 100).toFixed(1) : 0, color: 'text-emerald-500' }
          ].map((item, i) => (
            <div key={i} className="flex flex-col items-center justify-center p-6 bg-gray-50/50 dark:bg-white/5 rounded-2xl border border-gray-100 dark:border-white/5 group hover:border-[#ff6600]/30 transition-all">
              <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-2">{item.label}</p>
              <p className={`text-4xl font-black tabular-nums transition-transform group-hover:scale-110 ${item.color}`}>
                {item.val}%
              </p>
            </div>
          ))}
        </div>
      </div>

      {/* Product Insights Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="bg-white dark:bg-[#1A1D21] border border-gray-100 dark:border-white/5 rounded-[2.5rem] p-8 shadow-sm">
          <div className="flex items-center justify-between mb-8">
            <div>
              <h3 className="text-lg font-black text-gray-900 dark:text-white uppercase tracking-tight italic">Audit de Performance</h3>
              <p className="text-[10px] font-black text-gray-400 uppercase tracking-[0.2em] mt-1">Classification par taux de transformation</p>
            </div>
            <div className="w-10 h-10 bg-[#ff6600]/10 rounded-xl flex items-center justify-center">
               <Target className="w-5 h-5 text-[#ff6600]" />
            </div>
          </div>

          <div className="space-y-4">
            {productInsights.length > 0 ? productInsights.map((item, idx) => (
              <div key={item.id} className="flex items-center justify-between p-5 bg-gray-50/30 dark:bg-white/5 rounded-[1.5rem] border border-gray-100 dark:border-white/5 group hover:bg-white dark:hover:bg-white/10 hover:border-[#ff6600]/30 transition-all cursor-crosshair">
                <div className="flex items-center gap-5">
                  <div className="w-14 h-14 rounded-2xl bg-white dark:bg-[#1A1D21] overflow-hidden border border-gray-100 dark:border-white/10 shadow-sm transition-transform group-hover:scale-110">
                    {item.image ? (
                      <img src={item.image} alt="" className="w-full h-full object-cover" />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center text-[#ff6600]">
                        <Zap className="w-6 h-6" />
                      </div>
                    )}
                  </div>
                  <div>
                    <p className="text-[14px] font-black text-gray-900 dark:text-white uppercase tracking-tight line-clamp-1 truncate italic">{item.title}</p>
                    <div className="flex items-center gap-4 mt-2">
                      <span className="flex items-center gap-1.5 text-[10px] text-gray-400 font-black uppercase">
                        <Eye className="w-3.5 h-3.5" /> {item.views} <span className="opacity-40">Views</span>
                      </span>
                      <span className="flex items-center gap-1.5 text-[10px] text-[#ff6600] font-black uppercase">
                        <ShoppingBag className="w-3.5 h-3.5" /> {item.sales} <span className="opacity-40">Sold</span>
                      </span>
                    </div>
                  </div>
                </div>
                <div className="text-right">
                  <p className={`text-2xl font-black tabular-nums tracking-tighter ${parseFloat(item.conversion) > 5 ? 'text-emerald-500' : 'text-[#ff6600]'}`}>
                    {item.conversion}%
                  </p>
                  <p className="text-[9px] font-black text-gray-400 uppercase tracking-widest mt-1">Efficiency</p>
                </div>
              </div>
            )) : (
              <div className="py-20 text-center flex flex-col items-center opacity-20">
                <MousePointer2 className="w-16 h-16 mb-4" />
                <p className="text-[11px] font-black uppercase tracking-[0.4em]">Data Aggregation Ongoing</p>
              </div>
            )}
          </div>
        </div>

        <div className="bg-[#ff6600] rounded-[2.5rem] p-10 text-white relative overflow-hidden flex flex-col shadow-2xl shadow-[#ff6600]/20">
          <div className="relative z-10 flex-1">
            <div className="flex items-center gap-3 mb-4">
               <div className="w-3 h-3 rounded-full bg-white animate-ping" />
               <h3 className="text-2xl font-black uppercase italic tracking-tighter">Diagnostic Elite IA</h3>
            </div>
            
            <div className="bg-black/20 backdrop-blur-xl rounded-[2rem] p-8 mt-6 border border-white/10 shadow-inner">
              {productInsights.length > 0 && parseFloat(productInsights[0].conversion) < 2 ? (
                <p className="text-lg font-bold leading-tight italic">
                  "ALERTE : Votre article phare (<span className="underline decoration-white/40">{productInsights[0].title}</span>) génère du trafic mais ne convertit pas. 
                  Optimisez l'appel à l'action ou révisez la tarification de 7% pour briser la résistance psychologique du prospect."
                </p>
              ) : productInsights.length > 0 ? (
                <p className="text-lg font-bold leading-tight italic">
                   "Vitesse de vente critique sur <span className="underline decoration-white/40">{productInsights[0].title}</span>. 
                   L'engagement dépasse la prévision de 12%. Réapprovisionnez avant rupture de stock pour maintenir le momentum algorithmique."
                </p>
              ) : (
                <p className="text-lg font-bold leading-tight italic">
                  "Initialisation du module prédictif. Dès que le seuil de 100 sessions uniques sera franchi, l'IA {APP_NAME} générera votre première stratégie de mise à l'échelle commerciale."
                </p>
              )}
            </div>
            
            <div className="grid grid-cols-2 gap-6 mt-10">
              <div className="bg-white/10 backdrop-blur-md rounded-2xl p-5 border border-white/10 group hover:bg-white/20 transition-all">
                <p className="text-[10px] font-black opacity-60 uppercase tracking-[0.2em] mb-2">Momentum Hebd.</p>
                <div className="flex items-center gap-3">
                  <TrendingUp className="w-6 h-6 text-emerald-300" />
                  <span className="text-2xl font-black tabular-nums">+18.5%</span>
                </div>
              </div>
              <div className="bg-white/10 backdrop-blur-md rounded-2xl p-5 border border-white/10 group hover:bg-white/20 transition-all">
                <p className="text-[10px] font-black opacity-60 uppercase tracking-[0.2em] mb-2">Score Vitesse</p>
                <div className="flex items-center gap-3">
                  <Zap className="w-6 h-6 text-yellow-300 fill-current" />
                  <span className="text-2xl font-black uppercase italic">Elite</span>
                </div>
              </div>
            </div>
          </div>
          
          <div className="absolute top-[-30%] right-[-10%] w-96 h-96 bg-white/10 rounded-full blur-[100px]"></div>
          <div className="absolute bottom-[-30%] left-[-10%] w-96 h-96 bg-black/10 rounded-full blur-[100px]"></div>
        </div>
      </div>
    </div>
  );
}
