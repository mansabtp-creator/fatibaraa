import { WifiOff, RefreshCw } from 'lucide-react';
import { useStore } from '../store/useStore';
import { useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';

export default function OfflineBanner() {
  const { isOffline, setIsOffline, modeEconomie } = useStore();

  useEffect(() => {
    const handleOnline  = () => setIsOffline(false);
    const handleOffline = () => setIsOffline(true);
    const handleAppOffline = () => setIsOffline(true);

    window.addEventListener('online',  handleOnline);
    window.addEventListener('offline', handleOffline);
    window.addEventListener('app:network-offline', handleAppOffline);

    // Sync initial state with the browser's current connectivity report
    setIsOffline(!navigator.onLine);

    return () => {
      window.removeEventListener('online',  handleOnline);
      window.removeEventListener('offline', handleOffline);
      window.removeEventListener('app:network-offline', handleAppOffline);
    };
  }, [setIsOffline]);

  const handleRetry = () => {
    // Dispatch a custom event so ProductGrid (and other listeners) can
    // re-trigger their fetch without a full page reload.
    window.dispatchEvent(new Event('online'));
  };

  return (
    <AnimatePresence>
      {isOffline && (
        <motion.div
          initial={{ opacity: modeEconomie ? 1 : 0, y: modeEconomie ? 0 : 60 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: modeEconomie ? 1 : 0, y: modeEconomie ? 0 : 60 }}
          transition={{ duration: modeEconomie ? 0 : 0.3, ease: 'easeOut' }}
          // Position: above BottomNav (bottom-[72px]) on mobile, top-center on md+
          className="fixed bottom-[72px] left-4 right-4 md:top-6 md:bottom-auto md:left-1/2 md:-translate-x-1/2 md:w-auto md:max-w-sm z-[110]"
          role="alert"
          aria-live="assertive"
        >
          <div className="bg-gray-900/95 dark:bg-gray-950/95 backdrop-blur-md text-white px-5 py-3.5 rounded-2xl flex items-center justify-between gap-4 shadow-2xl border border-white/10">
            <div className="flex items-center gap-3">
              {/* Pulsing red dot */}
              <span className="relative flex h-2.5 w-2.5 shrink-0">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75" />
                <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-red-500" />
              </span>
              <div>
                <p className="text-[12px] font-black uppercase tracking-widest leading-none">
                  Mode Hors-Ligne
                </p>
                <p className="text-[10px] text-white/60 font-medium mt-0.5">
                  Vérifiez votre connexion
                </p>
              </div>
            </div>

            {/* Retry button — 44×44 px minimum touch target */}
            <button
              onClick={handleRetry}
              aria-label="Réessayer la connexion"
              className="min-w-[44px] min-h-[44px] flex items-center gap-1.5 bg-[#ff6600] text-white text-[11px] font-black uppercase tracking-wider px-4 py-2 rounded-xl transition-all hover:bg-[#e62e00] active:scale-95 shadow-lg shadow-[#ff6600]/30"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              Réessayer
            </button>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
