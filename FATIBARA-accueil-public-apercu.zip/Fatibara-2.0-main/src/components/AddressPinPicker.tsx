import { useState, useEffect, useCallback, useMemo } from 'react';
import { MapPin, Search, Compass, LocateFixed } from 'lucide-react';
import { MapContainer, TileLayer, Marker, useMapEvents, useMap } from 'react-leaflet';
import L from 'leaflet';
import { safeGetCurrentPosition, isGeolocationPermitted, CONAKRY_CENTER } from '../utils/geolocation';

// Fix for default Leaflet icon not appearing in Vite/React
import icon from 'leaflet/dist/images/marker-icon.png';
import iconShadow from 'leaflet/dist/images/marker-shadow.png';

const DefaultIcon = L.icon({
    iconUrl: icon,
    shadowUrl: iconShadow,
    iconSize: [25, 41],
    iconAnchor: [12, 41]
});

L.Marker.prototype.options.icon = DefaultIcon;

// ── Guinea-wide neighborhood/landmark data keyed by region ────────────────────
// Coords are [lat, lng]. The first entry doubles as the region's map center.
const GUINEA_NEIGHBORHOODS: Record<string, { name: string; coords: [number, number] }[]> = {
  Conakry: [
    { name: 'Kaloum, Almamya',       coords: [9.5092, -13.7122] },
    { name: 'Kaloum, Sandervalia',   coords: [9.5110, -13.7080] },
    { name: 'Kaloum, Tombo',         coords: [9.5050, -13.7200] },
    { name: 'Dixinn, Camayenne',     coords: [9.5333, -13.6833] },
    { name: 'Dixinn, Belle Vue',     coords: [9.5445, -13.6740] },
    { name: 'Matam, Coleah',         coords: [9.5290, -13.6850] },
    { name: 'Matam, Madina',         coords: [9.5380, -13.6650] },
    { name: 'Ratoma, Kipé',          coords: [9.6050, -13.6150] },
    { name: 'Ratoma, Nongo',         coords: [9.6140, -13.6060] },
    { name: 'Ratoma, Lambanyi',      coords: [9.6300, -13.5850] },
    { name: 'Ratoma, Sonfonia',      coords: [9.6500, -13.5650] },
    { name: 'Matoto, Gbessia',       coords: [9.5650, -13.6150] },
    { name: 'Matoto, Sangoyah',      coords: [9.6000, -13.5500] },
    { name: 'Matoto, Enta',          coords: [9.6100, -13.5200] },
    { name: 'Coyah, Km36',           coords: [9.6700, -13.4400] },
  ],
  Kindia: [
    { name: 'Kindia Centre',         coords: [10.0577, -12.8659] },
    { name: 'Kindia, Mambia',        coords: [10.0700, -12.8500] },
    { name: 'Kindia, Gbérékorè',     coords: [10.0450, -12.8750] },
    { name: 'Coyah Centre',          coords: [9.7047,  -13.3800] },
    { name: 'Dubréka Centre',        coords: [9.7895,  -13.5140] },
    { name: 'Forécariah Centre',     coords: [9.4317,  -13.0875] },
    { name: 'Télimélé Centre',       coords: [10.9073, -13.0295] },
  ],
  Boké: [
    { name: 'Boké Centre',           coords: [10.9319, -14.2960] },
    { name: 'Boké, Kamsar',          coords: [10.6550, -14.6080] },
    { name: 'Boffa Centre',          coords: [10.1794, -14.0386] },
    { name: 'Fria Centre',           coords: [10.3679, -13.5486] },
    { name: 'Gaoual Centre',         coords: [11.7510, -13.2060] },
    { name: 'Koundara Centre',       coords: [12.4840, -13.3030] },
  ],
  Mamou: [
    { name: 'Mamou Centre',          coords: [10.3764, -12.0862] },
    { name: 'Mamou, Marché Central', coords: [10.3800, -12.0900] },
    { name: 'Mamou, Saré Kaly',      coords: [10.3700, -12.0820] },
    { name: 'Dalaba Centre',         coords: [10.6886, -12.2491] },
    { name: 'Pita Centre',           coords: [11.0700, -12.3970] },
  ],
  Labé: [
    { name: 'Labé Centre',           coords: [11.3181, -12.2868] },
    { name: 'Labé, Tata',            coords: [11.3250, -12.2800] },
    { name: 'Labé, Diari',           coords: [11.3100, -12.2950] },
    { name: 'Labé, Marché',          coords: [11.3200, -12.2900] },
    { name: 'Koubia Centre',         coords: [11.5842, -11.9033] },
    { name: 'Lélouma, Popodara',     coords: [11.1430, -12.5000] },
    { name: 'Tougué Centre',         coords: [11.4430, -11.6700] },
  ],
  Faranah: [
    { name: 'Faranah Centre',        coords: [10.0395, -10.7448] },
    { name: 'Faranah, Bentimodia',   coords: [10.0500, -10.7350] },
    { name: 'Faranah, Niandankoro',  coords: [10.0300, -10.7600] },
    { name: 'Dabola Centre',         coords: [10.7491, -11.1120] },
    { name: 'Dinguiraye Centre',     coords: [11.3000, -10.7167] },
    { name: 'Kissidougou Centre',    coords: [9.1855,  -10.1074] },
  ],
  Kankan: [
    { name: 'Kankan Centre',         coords: [10.3836, -9.3060] },
    { name: 'Kankan, Kabada',        coords: [10.3900, -9.2950] },
    { name: 'Kankan, Kouroubanta',   coords: [10.3750, -9.3150] },
    { name: 'Kankan, Marché',        coords: [10.3850, -9.3050] },
    { name: 'Kérouané Centre',       coords: [9.2620,  -9.0150] },
    { name: 'Kouroussa Centre',      coords: [10.6508, -9.8855] },
    { name: 'Siguiri Centre',        coords: [11.4148, -9.1668] },
    { name: 'Mandiana Centre',       coords: [10.6186, -8.6936] },
  ],
  Nzérékoré: [
    { name: 'Nzérékoré Centre',      coords: [7.7562, -8.8179] },
    { name: 'Nzérékoré, Kaporo',     coords: [7.7600, -8.8100] },
    { name: 'Nzérékoré, Bouliwali',  coords: [7.7500, -8.8250] },
    { name: 'Nzérékoré, Marché',     coords: [7.7550, -8.8200] },
    { name: 'Beyla Centre',          coords: [8.6880, -8.6560] },
    { name: 'Guéckédou Centre',      coords: [8.5590, -10.1296] },
    { name: 'Lola Centre',           coords: [7.8200, -8.5200] },
    { name: 'Macenta Centre',        coords: [8.5500, -9.4700] },
  ],
};

// Default map center per region
const REGION_CENTERS: Record<string, [number, number]> = {
  Conakry:   [9.5092,  -13.7122],
  Kindia:    [10.0577, -12.8659],
  Boké:      [10.9319, -14.2960],
  Mamou:     [10.3764, -12.0862],
  Labé:      [11.3181, -12.2868],
  Faranah:   [10.0395, -10.7448],
  Kankan:    [10.3836, -9.3060],
  Nzérékoré: [7.7562,  -8.8179],
};

function LocationMarker({
  position,
  setPosition,
}: {
  position: [number, number];
  setPosition: (pos: [number, number]) => void;
}) {
  useMapEvents({
    click(e) { setPosition([e.latlng.lat, e.latlng.lng]); },
    locationfound(e) { setPosition([e.latlng.lat, e.latlng.lng]); },
  });
  return position ? (
    <Marker
      position={position}
      draggable={true}
      eventHandlers={{
        dragend: (e) => {
          const pos = e.target.getLatLng();
          setPosition([pos.lat, pos.lng]);
        },
      }}
    />
  ) : null;
}

function ChangeView({ center, zoom }: { center: [number, number]; zoom: number }) {
  const map = useMap();
  useEffect(() => {
    map.flyTo(center, zoom, { duration: 1.5, easeLinearity: 0.25 });
  }, [center, zoom, map]);
  return null;
}

interface AddressPinPickerProps {
  onSelect: (address: string) => void;
  /** The region currently selected in the checkout form. Drives map center + suggestions. */
  region?: string;
}

export default function AddressPinPicker({ onSelect, region = 'Conakry' }: AddressPinPickerProps) {
  const regionCenter = REGION_CENTERS[region] ?? REGION_CENTERS['Conakry'];
  const neighborhoods = GUINEA_NEIGHBORHOODS[region] ?? GUINEA_NEIGHBORHOODS['Conakry'];

  const [query, setQuery] = useState('');
  const [position, setPosition] = useState<[number, number]>(regionCenter);
  const [mapZoom, setMapZoom] = useState(12);
  const [isLocating, setIsLocating] = useState(false);
  const [showDropdown, setShowDropdown] = useState(false);

  // When the region changes from the parent, fly the map to the new city center
  // and reset the search query.
  useEffect(() => {
    const center = REGION_CENTERS[region] ?? REGION_CENTERS['Conakry'];
    setPosition(center);
    setMapZoom(12);
    setQuery('');
    // Notify parent so the quartier field resets too
    onSelect('');
  }, [region]); // eslint-disable-line react-hooks/exhaustive-deps

  const filteredNeighborhoods = useMemo(() => {
    if (!query) return [];
    return neighborhoods.filter(n =>
      n.name.toLowerCase().includes(query.toLowerCase())
    );
  }, [query, neighborhoods]);

  const handleLocate = useCallback(() => {
    setIsLocating(true);
    if (!isGeolocationPermitted()) {
      const coords: [number, number] = [CONAKRY_CENTER.lat, CONAKRY_CENTER.lng];
      setPosition(coords);
      setMapZoom(15);
      setIsLocating(false);
      onSelect(`GPS: ${coords[0].toFixed(6)}, ${coords[1].toFixed(6)}`);
      return;
    }
    safeGetCurrentPosition(
      (pos) => {
        const coords: [number, number] = [pos.latitude, pos.longitude];
        setPosition(coords);
        setMapZoom(16);
        setIsLocating(false);
        onSelect(`GPS: ${coords[0].toFixed(6)}, ${coords[1].toFixed(6)}`);
      },
      () => {
        setIsLocating(false);
      }
    );
  }, [onSelect]);

  // Emit GPS string whenever user drags/clicks the map
  useEffect(() => {
    onSelect(`GPS: ${position[0].toFixed(6)}, ${position[1].toFixed(6)}`);
  }, [position]); // eslint-disable-line react-hooks/exhaustive-deps

  return (
    <div className="space-y-4">
      {/* Neighborhood search */}
      <div className="relative group z-50">
        <div className="absolute inset-y-0 left-4 flex items-center pointer-events-none">
          <Search className="w-5 h-5 text-gray-400 group-focus-within:text-[#ff6600] transition-colors" />
        </div>
        <input
          type="text"
          value={query}
          onChange={(e) => { setQuery(e.target.value); setShowDropdown(true); }}
          onFocus={() => setShowDropdown(true)}
          placeholder={`Chercher un quartier à ${region} (ex: Centre, Marché…)`}
          className="w-full bg-gray-50/50 dark:bg-gray-900 border border-gray-200 dark:border-white/10 rounded-[1.5rem] py-4 pl-12 pr-4 text-sm font-bold text-gray-900 dark:text-white focus:outline-none focus:border-[#ff6600] transition-all placeholder:text-gray-400 shadow-sm"
        />
        {showDropdown && filteredNeighborhoods.length > 0 && (
          <div className="absolute top-full left-0 right-0 mt-2 bg-white dark:bg-gray-900 border border-gray-100 dark:border-gray-800 rounded-2xl shadow-xl overflow-hidden py-2 z-50">
            {filteredNeighborhoods.map((n, i) => (
              <button
                key={i}
                type="button"
                onClick={() => {
                  setQuery(n.name);
                  setPosition(n.coords);
                  setMapZoom(16);
                  setShowDropdown(false);
                  onSelect(n.name);
                }}
                className="w-full text-left px-5 py-3 hover:bg-orange-50 dark:hover:bg-gray-800 text-sm font-bold text-gray-900 dark:text-white transition-colors flex items-center gap-3"
              >
                <MapPin className="w-4 h-4 text-gray-400 shrink-0" />
                {n.name}
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Real Map View */}
      <div className="relative h-64 md:h-80 bg-slate-100 dark:bg-gray-800 rounded-[2.5rem] border border-gray-200 dark:border-white/10 overflow-hidden shadow-inner">
        <MapContainer
          center={position}
          zoom={mapZoom}
          scrollWheelZoom={false}
          className="w-full h-full z-0 dark:invert-[0.9] dark:hue-rotate-[180deg]"
        >
          <TileLayer
            attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
            url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
          />
          <LocationMarker position={position} setPosition={setPosition} />
          <ChangeView center={position} zoom={mapZoom} />
        </MapContainer>

        {/* Locate me button */}
        <div className="absolute top-4 right-4 z-10">
          <button
            onClick={handleLocate}
            disabled={isLocating}
            className="w-12 h-12 bg-white dark:bg-gray-900 rounded-2xl shadow-xl flex items-center justify-center text-[#ff6600] border border-gray-200 dark:border-white/10 hover:bg-[#ff6600] hover:text-white transition-all active:scale-90"
          >
            <LocateFixed className={`w-6 h-6 ${isLocating ? 'animate-spin' : ''}`} />
          </button>
        </div>

        {/* GPS readout */}
        <div className="absolute bottom-4 left-4 z-10 flex items-center gap-2 bg-white/90 dark:bg-gray-950/90 backdrop-blur px-4 py-2 rounded-2xl text-[10px] font-bold text-gray-900 dark:text-white shadow-2xl border border-[#ff6600]/20">
          <Compass className="w-4 h-4 text-[#ff6600]" />
          <div className="flex flex-col">
            <span className="tracking-wider text-[8px] opacity-70">Point de Livraison Exact</span>
            <span>GPS: {position[0].toFixed(5)}, {position[1].toFixed(5)}</span>
          </div>
        </div>
      </div>

      <p className="text-[11px] font-bold text-gray-500 tracking-wider px-2 leading-relaxed">
        <MapPin className="w-3 h-3 inline-block -mt-1 mr-1 text-[#ff6600]" />
        Déplacez le marqueur ou cliquez sur la carte pour définir votre position exacte de livraison.
      </p>
    </div>
  );
}
