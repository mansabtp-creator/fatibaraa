import React from 'react';
import { motion } from 'motion/react';
import { Smartphone, Shirt, Home, Zap, Flame, LayoutGrid, Monitor, ShoppingBag, Utensils, Car, Trophy, Globe } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { PRODUCT_CATEGORIES } from '../lib/constants';

const categoryIcons: Record<string, any> = {
  'Flash Deals': Flame,
  'Téléphones & Tablettes': Smartphone,
  'Mode Femme': Shirt,
  'Mode Homme': ShoppingBag,
  'Électronique & Vidéo': Monitor,
  'Beauté & Santé': Zap,
  'Maison & Bureau': Home,
  'Épicerie & Supermarché': Utensils,
  'Auto & Moto': Car,
  'Sports & Loisirs': Trophy,
  'Autres': Globe,
  'Default': LayoutGrid
};

export default function CategoryBar() {
  const navigate = useNavigate();

  // Combine Flash Deals with dynamic categories
  const displayCategories = [
    { id: 'deal', name: 'Flash Deals', path: '/shop?promo=true', icon: Flame },
    ...PRODUCT_CATEGORIES.slice(0, 6).map(name => ({
      id: name.toLowerCase().replace(/\s+/g, '-'),
      name: name.split(' & ')[0], // Shorten name for mobile
      path: `/shop?category=${encodeURIComponent(name)}`,
      icon: categoryIcons[name] || categoryIcons['Default']
    }))
  ];

  return (
    <div className="w-full bg-white dark:bg-gray-900 border-b border-gray-100 dark:border-white/5 shadow-sm md:hidden pb-4 pt-2">
      <div className="flex px-4 gap-6 overflow-x-auto no-scrollbar justify-start snap-x py-2">
        {displayCategories.map((cat) => (
          <motion.button
            key={cat.id}
            whileTap={{ scale: 0.9 }}
            onClick={() => navigate(cat.path)}
            className="flex flex-col items-center gap-2 min-w-[64px] snap-center"
          >
            <div className={`w-12 h-12 rounded-2xl flex items-center justify-center bg-gray-50 dark:bg-gray-800 shadow-sm border border-gray-100 dark:border-white/5 relative transition-all shrink-0`}>
              <cat.icon className={`w-5 h-5 text-[#ff6600]`} />
              {cat.id === 'deal' && (
                <div className="absolute -top-1 -right-1 bg-[#ff6600] text-white text-[7px] font-black px-1.5 py-0.5 rounded-full shadow-md border-2 border-white dark:border-gray-900 z-10 animate-pulse">
                  HOT
                </div>
              )}
            </div>
            <span className="text-[10px] font-bold text-gray-600 dark:text-gray-400 text-center whitespace-nowrap">{cat.name}</span>
          </motion.button>
        ))}
      </div>
    </div>
  );
}
