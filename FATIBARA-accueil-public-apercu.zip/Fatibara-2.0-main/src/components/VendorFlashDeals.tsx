import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Zap, Plus, Trash2, Clock, Calendar, TrendingDown, 
  AlertTriangle, CheckCircle, Info, ArrowRight, Loader2
} from 'lucide-react';
import { supabase } from '../lib/supabase';
import { useToast } from '../context/ToastContext';

interface VendorFlashDealsProps {
  storeId: string;
  products: any[];
}

export default function VendorFlashDeals({ storeId, products }: VendorFlashDealsProps) {
  const { showToast } = useToast();
  const [loading, setLoading] = useState(true);
  const [flashDeals, setFlashDeals] = useState<any[]>([]);
  const [showModal, setShowModal] = useState(false);
  const [editingDeal, setEditingDeal] = useState<any>(null);
  const [confirmConfig, setConfirmConfig] = useState<{
    isOpen: boolean;
    resolve: (value: boolean) => void;
  } | null>(null);

  const askConfirm = (): Promise<boolean> => {
    return new Promise((resolve) => {
      setConfirmConfig({ isOpen: true, resolve });
    });
  };

  // Form state
  const [selectedProduct, setSelectedProduct] = useState('');
  const [discountPrice, setDiscountPrice] = useState('');
  const [startTime, setStartTime] = useState('');
  const [endTime, setEndTime] = useState('');
  const [stockLimit, setStockLimit] = useState('10');

  useEffect(() => {
    fetchFlashDeals();
  }, [storeId]);

  const fetchFlashDeals = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('flash_deals')
      .select('*, product:product_id(title, image_urls, price_gnf)')
        .eq('store_id', storeId)
        .order('created_at', { ascending: false });
      
      if (error) throw error;
      setFlashDeals(data || []);
    } catch (err: any) {
      showToast(err.message, "error");
    } finally {
      setLoading(false);
    }
  };

  const handleSaveDeal = async () => {
    if (!selectedProduct || !discountPrice || !startTime || !endTime) {
      showToast("Veuillez remplir tous les champs", "warning");
      return;
    }

    try {
      const dealData = {
        store_id: storeId,
        product_id: selectedProduct,
        discount_price: parseFloat(discountPrice),
        start_time: new Date(startTime).toISOString(),
        end_time: new Date(endTime).toISOString(),
        stock_limit: parseInt(stockLimit),
        is_active: true
      };

      if (editingDeal) {
        const { error } = await supabase
          .from('flash_deals')
          .update(dealData)
          .eq('id', editingDeal.id);
        if (error) throw error;
        showToast("Flash Deal mis à jour ! ⚡", "success");
      } else {
        const { error } = await supabase
          .from('flash_deals')
          .insert([dealData]);
        if (error) throw error;
        showToast("Flash Deal créé avec succès ! ⚡", "success");
      }

      setShowModal(false);
      resetForm();
      fetchFlashDeals();
    } catch (err: any) {
      showToast(err.message, "error");
    }
  };

  const handleDeleteDeal = async (id: string) => {
    const confirmed = await askConfirm();
    if (!confirmed) return;
    try {
      const { error } = await supabase.from('flash_deals').delete().eq('id', id);
      if (error) throw error;
      showToast("Flash Deal supprimé", "success");
      fetchFlashDeals();
    } catch (err: any) {
      showToast(err.message, "error");
    }
  };

  const resetForm = () => {
    setSelectedProduct('');
    setDiscountPrice('');
    setStartTime('');
    setEndTime('');
    setStockLimit('10');
    setEditingDeal(null);
  };

  const getStatus = (deal: any) => {
    const now = new Date();
    const start = new Date(deal.start_time);
    const end = new Date(deal.end_time);

    if (now < start) return { label: 'À venir', color: 'text-amber-500', bg: 'bg-amber-500/10' };
    if (now > end) return { label: 'Terminé', color: 'text-gray-500 dark:text-gray-400', bg: 'bg-gray-50 dark:bg-gray-8000/10' };
    return { label: 'En cours', color: 'text-emerald-500', bg: 'bg-emerald-500/10' };
  };

  return (
    <div className="space-y-8">
      {/* Header Section */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 bg-white bg-white dark:bg-gray-900 border border-brand-border/40 dark:border-white/10 p-8 rounded-[3rem] shadow-sm">
        <div>
          <h2 className="text-2xl font-bold text-gray-900 text-gray-900 dark:text-white tracking-tighter uppercase flex items-center gap-3">
             <Zap className="w-8 h-8 text-black dark:text-white" /> Flash Deals Engine
          </h2>
          <p className="text-[10px] font-bold text-brand-text-dim dark:text-gray-400 tracking-wider mt-1">Boostez vos ventes avec des offres limitées dans le temps</p>
        </div>
        <button 
          onClick={() => { resetForm(); setShowModal(true); }}
          className="flex items-center gap-2 px-8 py-4 bg-black text-white text-[11px] font-bold tracking-wider rounded-2xl hover:scale-105 active:scale-95 transition-all shadow-xl shadow-black/20"
        >
          <Plus className="w-4 h-4" /> Nouvelle Offre Flash
        </button>
      </div>

      {loading ? (
        <div className="flex flex-col items-center justify-center py-24 gap-4">
          <Loader2 className="w-12 h-12 text-black dark:text-white animate-spin" />
          <p className="text-[10px] font-bold tracking-wider text-brand-text-dim dark:text-gray-500 dark:text-gray-400 animate-pulse">Initialisation du moteur...</p>
        </div>
      ) : flashDeals.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
           {flashDeals.map((deal) => {
             const status = getStatus(deal);
             return (
               <motion.div 
                 key={deal.id}
                 layoutId={deal.id}
                 className="bg-white bg-white dark:bg-gray-900 border border-brand-border/40 dark:border-white/10 rounded-[2.5rem] overflow-hidden group hover:border-black/40 transition-all flex flex-col"
               >
                 <div className="relative aspect-[16/9] overflow-hidden">
                    <img src={deal.product?.image_urls?.[0]} alt="" className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-1000" />
                    <div className="absolute top-4 left-4">
                       <span className={`px-4 py-2 rounded-xl text-[9px] font-bold tracking-wider backdrop-blur-xl border border-white/20 shadow-xl ${status.bg} ${status.color}`}>
                          {status.label}
                       </span>
                    </div>
                    <div className="absolute bottom-0 left-0 w-full p-4 bg-gradient-to-t from-black/80 to-transparent">
                       <p className="text-white text-sm font-bold truncate">{deal.product?.title}</p>
                    </div>
                 </div>

                 <div className="p-8 flex-grow space-y-6">
                    <div className="flex items-center justify-between">
                       <div>
                          <p className="text-[9px] font-bold text-brand-text-dim dark:text-gray-400 tracking-wider mb-1">Prix Flash</p>
                          <p className="text-2xl font-bold text-black dark:text-white">{deal.discount_price.toLocaleString()} <span className="text-[10px] opacity-60">GNF</span></p>
                       </div>
                       <div className="text-right">
                          <p className="text-[9px] font-bold text-brand-text-dim dark:text-gray-400 tracking-wider mb-1">Ancien Prix</p>
                          <p className="text-sm font-bold text-gray-900/40 dark:text-white/20 line-through">{deal.product?.price_gnf?.toLocaleString()} GNF</p>
                       </div>
                    </div>

                    <div className="space-y-3">
                       <div className="flex items-center gap-2 text-[10px] font-bold text-gray-900 text-gray-900 dark:text-white uppercase tracking-tight">
                          <Clock className="w-4 h-4 text-[#ff6600] dark:text-orange-400" /> {new Date(deal.start_time).toLocaleString()} - {new Date(deal.end_time).toLocaleTimeString()}
                       </div>
                       <div className="w-full bg-gray-50 bg-gray-50 dark:bg-gray-800 h-2.5 rounded-full overflow-hidden border border-brand-border/20 dark:border-white/5">
                          <motion.div 
                            initial={{ width: 0 }}
                            animate={{ width: `${(deal.sold_count / deal.stock_limit) * 100}%` }}
                            className="h-full bg-[#ff6600] dark:bg-[#ff6600]"
                          />
                       </div>
                       <div className="flex justify-between text-[9px] font-bold tracking-wider text-brand-text-dim dark:text-gray-400">
                          <span>Progressions Ventes</span>
                          <span className="text-gray-900 text-gray-900 dark:text-white">{deal.sold_count} / {deal.stock_limit} vendus</span>
                       </div>
                    </div>

                    <div className="pt-6 border-t border-brand-border/20 dark:border-white/5 flex gap-2">
                       <button 
                         onClick={() => { setEditingDeal(deal); setShowModal(true); }}
                         className="flex-1 py-3 bg-gray-50 bg-gray-50 dark:bg-gray-800 border border-brand-border/30 dark:border-white/10 rounded-xl text-[9px] font-bold tracking-wider text-gray-900 dark:text-white dark:text-gray-300 hover:border-black transition-all"
                       >
                         Modifier
                       </button>
                       <button 
                         onClick={() => handleDeleteDeal(deal.id)}
                         className="px-4 py-3 bg-red-500/5 text-red-500 border border-red-500/20 rounded-xl hover:bg-red-500 hover:text-white transition-all"
                       >
                         <Trash2 className="w-4 h-4" />
                       </button>
                    </div>
                 </div>
               </motion.div>
             );
           })}
        </div>
      ) : (
        <div className="py-32 text-center bg-white bg-white dark:bg-gray-900 border border-dashed border-brand-border/40 dark:border-white/10 rounded-[3rem]">
           <Zap className="w-16 h-16 text-brand-text-dim/20 dark:text-gray-700 mx-auto mb-6" />
           <p className="text-[12px] font-bold tracking-wider text-brand-text-dim dark:text-gray-500 dark:text-gray-400">Aucun Flash Deal Actif</p>
           <button 
             onClick={() => setShowModal(true)}
             className="mt-6 text-black dark:text-white text-[10px] font-bold tracking-wider hover:underline"
           >
             Créez votre première offre limitée &rarr;
           </button>
        </div>
      )}

      {/* Modal Tool */}
      <AnimatePresence>
        {showModal && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
             <motion.div 
               initial={{ opacity: 0 }}
               animate={{ opacity: 1 }}
               exit={{ opacity: 0 }}
               onClick={() => setShowModal(false)}
               className="absolute inset-0 bg-gray-900/90 backdrop-blur-md"
             />
             <motion.div 
               initial={{ opacity: 0, scale: 0.9, y: 20 }}
               animate={{ opacity: 1, scale: 1, y: 0 }}
               exit={{ opacity: 0, scale: 0.9, y: 20 }}
               className="relative w-full max-w-xl bg-gray-50 dark:bg-gray-800 dark:bg-gray-900 rounded-[3rem] p-10 lg:p-12 shadow-2xl border border-brand-border/20 dark:border-white/10 overflow-y-auto max-h-[90vh] no-scrollbar"
             >
                <div className="mb-10">
                   <h3 className="text-3xl font-bold text-gray-900 text-gray-900 dark:text-white tracking-tighter uppercase mb-2">Configurez l'Éclair ⚡</h3>
                   <p className="text-[10px] font-bold text-brand-text-dim dark:text-gray-400 tracking-wider">Paramétrage du Flash Deal Engine Alpha</p>
                </div>

                <div className="space-y-8">
                   <div className="space-y-3">
                      <label className="text-[10px] font-bold tracking-wider text-brand-text-dim dark:text-gray-400">Produit Alpha</label>
                      <select
                        value={selectedProduct}
                        onChange={(e) => {
                          setSelectedProduct(e.target.value);
                          const p = products.find(prod => prod.id === e.target.value);
                          if (p) setDiscountPrice((p.price * 0.8).toString());
                        }}
                        className="form-select"
                      >
                         <option value="">Sélectionnez un produit...</option>
                         {products.map(p => (
                           <option key={p.id} value={p.id}>{p.title} ({p.price.toLocaleString()} GNF)</option>
                         ))}
                      </select>
                   </div>

                   <div className="grid grid-cols-2 gap-6">
                      <div className="space-y-3">
                         <label className="text-[10px] font-bold tracking-wider text-brand-text-dim dark:text-gray-400">Prix Flash (GNF)</label>
                         <input 
                           type="number"
                           min="0"
                           value={discountPrice}
                           onChange={(e) => setDiscountPrice(e.target.value)}
                           className="w-full bg-white dark:bg-gray-900 dark:bg-gray-800 border border-brand-border/30 dark:border-white/10 rounded-2xl p-5 text-sm font-bold text-gray-900 text-gray-900 dark:text-white focus:border-[#ff6600] outline-none transition-all"
                           placeholder="Ex: 50000"
                         />
                      </div>
                      <div className="space-y-3">
                         <label className="text-[10px] font-bold tracking-wider text-brand-text-dim dark:text-gray-400">Limite de Stock</label>
                         <input 
                           type="number"
                           min="0"
                           value={stockLimit}
                           onChange={(e) => setStockLimit(e.target.value)}
                           className="w-full bg-white dark:bg-gray-900 dark:bg-gray-800 border border-brand-border/30 dark:border-white/10 rounded-2xl p-5 text-sm font-bold text-gray-900 text-gray-900 dark:text-white focus:border-[#ff6600] outline-none transition-all"
                         />
                      </div>
                   </div>

                   <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="space-y-3">
                         <label className="text-[10px] font-bold tracking-wider text-brand-text-dim dark:text-gray-400">Date de Début</label>
                         <input 
                           type="datetime-local"
                           value={startTime}
                           onChange={(e) => setStartTime(e.target.value)}
                           className="w-full bg-white dark:bg-gray-900 dark:bg-gray-800 border border-brand-border/30 dark:border-white/10 rounded-2xl p-5 text-sm font-bold text-gray-900 text-gray-900 dark:text-white focus:border-[#ff6600] outline-none transition-all"
                         />
                      </div>
                      <div className="space-y-3">
                         <label className="text-[10px] font-bold tracking-wider text-brand-text-dim dark:text-gray-400">Date de Fin</label>
                         <input 
                           type="datetime-local"
                           value={endTime}
                           onChange={(e) => setEndTime(e.target.value)}
                           className="w-full bg-white dark:bg-gray-900 dark:bg-gray-800 border border-brand-border/30 dark:border-white/10 rounded-2xl p-5 text-sm font-bold text-gray-900 text-gray-900 dark:text-white focus:border-[#ff6600] outline-none transition-all"
                         />
                      </div>
                   </div>

                   <div className="pt-10 flex gap-4">
                      <button 
                        onClick={() => setShowModal(false)}
                        className="flex-1 py-5 border border-brand-border/30 dark:border-white/10 rounded-[1.5rem] text-[11px] font-bold tracking-wider text-gray-900 dark:text-white dark:text-gray-400 hover:bg-white dark:bg-gray-900 dark:hover:bg-gray-800 transition-all"
                      >
                        Annuler
                      </button>
                      <button 
                        onClick={handleSaveDeal}
                        className="flex-[2] py-5 bg-black text-white rounded-[1.5rem] text-[11px] font-bold tracking-wider hover:scale-105 transition-all shadow-xl shadow-black/20"
                      >
                        Activer le Flash Deal ⚡
                      </button>
                   </div>
                </div>
             </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Custom Confirm Modal */}
      <AnimatePresence>
        {confirmConfig?.isOpen && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[110] flex items-center justify-center p-4 bg-gray-900/90 backdrop-blur-md"
            onClick={() => {
              confirmConfig.resolve(false);
              setConfirmConfig(null);
            }}
          >
            <motion.div 
              initial={{ scale: 0.9, opacity: 0, y: 20 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.9, opacity: 0, y: 20 }}
              onClick={(e) => e.stopPropagation()}
              className="bg-white dark:bg-gray-900 dark:bg-gray-800 p-8 lg:p-10 rounded-[3rem] w-full max-w-sm shadow-2xl border border-brand-border/20 dark:border-white/10 text-center"
            >
              <div className="w-16 h-16 bg-red-500/10 border border-red-500/20 rounded-full flex items-center justify-center mx-auto mb-6 text-red-500">
                <Trash2 className="w-8 h-8" />
              </div>
              <h3 className="text-2xl font-bold text-gray-900 text-gray-900 dark:text-white uppercase tracking-tighter mb-2">Supprimer l'offre ?</h3>
              <p className="text-[10px] font-bold text-brand-text-dim dark:text-gray-400 tracking-wider mb-8">Cette action est irréversible et retirera le produit de la section Flash Deals.</p>
              
              <div className="flex gap-4">
                <button
                  onClick={() => {
                    confirmConfig.resolve(false);
                    setConfirmConfig(null);
                  }}
                  className="flex-1 py-4 border border-brand-border/30 dark:border-white/10 rounded-2xl text-[10px] font-bold tracking-wider text-gray-900 dark:text-white dark:text-gray-400 hover:bg-gray-50 dark:bg-gray-800 dark:hover:bg-gray-700 transition"
                >
                  ANNULER
                </button>
                <button
                  onClick={() => {
                    confirmConfig.resolve(true);
                    setConfirmConfig(null);
                  }}
                  className="flex-1 py-4 bg-red-600 text-white rounded-2xl text-[10px] font-bold tracking-wider hover:bg-red-700 transition shadow-xl shadow-red-600/20"
                >
                  SUPPRIMER
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
