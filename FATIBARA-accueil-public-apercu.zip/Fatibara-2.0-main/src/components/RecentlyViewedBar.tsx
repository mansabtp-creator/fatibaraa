import { useEffect, useState } from 'react';
import { useStore } from '../store/useStore';
import { supabase } from '../lib/supabase';
import { motion } from 'motion/react';
import { Eye, Clock } from 'lucide-react';
import { Link } from 'react-router-dom';

export default function RecentlyViewedBar() {
  const { recentlyViewed, modeEconomie } = useStore();
  const [products, setProducts] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let isMounted = true;

    async function fetchRecentlyViewed() {
      if (recentlyViewed.length === 0) {
        if (isMounted) setLoading(false);
        return;
      }

      try {
        // Filter out non-UUID strings to avoid Supabase error 22P02
        const uuidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
        const validIds = recentlyViewed.filter(id => uuidRegex.test(id));

        if (validIds.length === 0) {
          if (isMounted) setLoading(false);
          return;
        }

        const { data, error } = await supabase
          .from('products')
          .select('id, title, price_gnf, image_urls')
          .in('id', validIds);

        if (error) throw error;
        
        if (!isMounted) return;

        // Sort according to recentlyViewed order
        const sorted = recentlyViewed
          .map(id => data?.find(p => p.id === id))
          .filter(Boolean);
          
        setProducts(sorted);
      } catch (err) {
        if (isMounted) {
          console.error('Error fetching recently viewed:', err);
        }
      } finally {
        if (isMounted) setLoading(false);
      }
    }

    fetchRecentlyViewed();

    return () => {
      isMounted = false;
    };
  }, [recentlyViewed]);

  if (loading || products.length === 0) return null;

  return (
    <section className="px-4 md:px-10 py-12 md:py-20 bg-white dark:bg-gray-900 dark:bg-gray-950 border-t border-brand-border/30 dark:border-white/5 overflow-hidden">
      <div className="max-w-7xl mx-auto">
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-2">
            <Clock className="w-6 h-6 text-[#ff6600]" />
            <h2 className="text-2xl md:text-3xl font-bold text-gray-900 text-gray-900 dark:text-white tracking-tighter uppercase">Vu récemment</h2>
          </div>
          <button 
             onClick={() => useStore.getState().clearRecentlyViewed()}
             className="text-[11px] uppercase font-bold tracking-[2px] text-brand-text-dim dark:text-gray-500 dark:text-gray-400 hover:text-gray-900 dark:text-white dark:hover:text-white border border-brand-border/10 dark:border-white/5 px-5 py-2.5 rounded-full transition-all min-h-[44px]"
          >
             Effacer l'historique
          </button>
        </div>
        
        <div className="flex md:grid md:grid-cols-4 lg:grid-cols-5 gap-4 md:gap-6 overflow-x-auto no-scrollbar pb-4 md:pb-0 -mx-4 px-4 md:mx-0 md:px-0 snap-x snap-mandatory">
          {products.map((product, idx) => {
            const imageUrl = product.image_urls?.[0] || 'https://picsum.photos/seed/view/200/200';
            return (
              <Link 
                key={product.id} 
                to={`/product/${product.id}`}
                className="group flex-shrink-0 w-[160px] md:w-auto snap-start outline-none"
              >
                <motion.div
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: idx * 0.1 }}
                  className="flex flex-col gap-3"
                >
                  <div className="relative aspect-square rounded-[2rem] overflow-hidden bg-gray-50 dark:bg-gray-800 dark:bg-gray-900 border border-brand-border/30 dark:border-white/5 shadow-sm group-hover:shadow-lg transition-all">
                    <img 
                      src={modeEconomie ? `${imageUrl}?blur=2&q=40` : imageUrl} 
                      alt={product.title}
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700 ease-out"
                      referrerPolicy="no-referrer"
                    />
                    <div className="absolute inset-0 bg-gray-900/0 group-hover:bg-gray-900/20 transition-colors flex items-center justify-center">
                      <Eye className="text-brand-inverse opacity-0 group-hover:opacity-100 transition-opacity w-8 h-8" />
                    </div>
                  </div>
                  <div className="flex flex-col gap-1 px-1">
                    <h3 className="text-[14px] font-bold text-gray-900 text-gray-900 dark:text-white truncate group-hover:text-[#ff6600] transition-colors uppercase tracking-tight">{product.title}</h3>
                    <span className="text-[14px] font-bold text-gray-900 dark:text-white dark:text-orange-400 tracking-tighter">{(product.price_gnf || 0).toLocaleString()} GNF</span>
                  </div>
                </motion.div>
              </Link>
            );
          })}
        </div>
      </div>
    </section>
  );
}
