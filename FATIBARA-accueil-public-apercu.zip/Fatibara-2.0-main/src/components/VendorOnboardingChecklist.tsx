/**
 * VendorOnboardingChecklist.tsx
 *
 * A dismissible onboarding progress card shown to new vendors on their
 * dashboard until all five milestones are completed. Once all steps are
 * done the card fades out automatically. If the vendor dismisses it early
 * the preference is persisted in localStorage.
 *
 * Milestones (derived from data already loaded by useVendorData):
 *   1. Boutique créée          – always true if the component renders
 *   2. Photo de profil         – storeData.avatar_url is non-empty
 *   3. Description renseignée  – storeData.description is non-empty
 *   4. Premier produit publié  – products.length > 0
 *   5. Première vente réalisée – aggregatedMetrics.total_orders > 0
 */
import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { CheckCircle2, Circle, ChevronRight, X, Sparkles } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

// ─── Types ────────────────────────────────────────────────────────────────────

interface ChecklistStep {
  id: string;
  label: string;
  hint: string;
  done: boolean;
  path?: string; // Vendor portal route to navigate to on click
}

interface VendorOnboardingChecklistProps {
  storeData: any;
  products: any[];
  aggregatedMetrics: any;
}

// ─── Constants ────────────────────────────────────────────────────────────────

const DISMISS_KEY = 'fatibara_vendor_checklist_dismissed';

// ─── Component ────────────────────────────────────────────────────────────────

export default function VendorOnboardingChecklist({
  storeData,
  products,
  aggregatedMetrics,
}: VendorOnboardingChecklistProps) {
  const navigate = useNavigate();
  const [dismissed, setDismissed] = useState<boolean>(() =>
    localStorage.getItem(DISMISS_KEY) === 'true'
  );

  const steps: ChecklistStep[] = [
    {
      id: 'store_created',
      label: 'Boutique créée',
      hint: 'Votre espace vendeur est actif.',
      done: true, // Always true — component won't render without storeData
    },
    {
      id: 'avatar',
      label: 'Photo de profil ajoutée',
      hint: 'Une photo rassure vos acheteurs.',
      done: Boolean(storeData?.avatar_url),
      path: '/vendor/settings',
    },
    {
      id: 'description',
      label: 'Description de la boutique',
      hint: 'Racontez votre histoire en quelques mots.',
      done: Boolean(storeData?.description?.trim()),
      path: '/vendor/settings',
    },
    {
      id: 'first_product',
      label: 'Premier produit publié',
      hint: 'Ajoutez au moins un article pour démarrer.',
      done: (products?.length ?? 0) > 0,
      path: '/vendor/products',
    },
    {
      id: 'first_sale',
      label: 'Première vente réalisée',
      hint: 'Vos premiers clients vous attendent !',
      done: (aggregatedMetrics?.total_orders ?? 0) > 0,
      path: '/vendor/orders',
    },
  ];

  const completedCount = steps.filter(s => s.done).length;
  const allDone = completedCount === steps.length;
  const progress = Math.round((completedCount / steps.length) * 100);

  // Auto-dismiss once all steps are complete
  useEffect(() => {
    if (allDone) {
      const timer = setTimeout(() => setDismissed(true), 3000);
      return () => clearTimeout(timer);
    }
  }, [allDone]);

  const handleDismiss = () => {
    setDismissed(true);
    localStorage.setItem(DISMISS_KEY, 'true');
  };

  const handleStepClick = (step: ChecklistStep) => {
    if (!step.done && step.path) {
      navigate(step.path);
    }
  };

  if (dismissed) return null;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0, y: -12 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: -12, height: 0 }}
        transition={{ duration: 0.35, ease: 'easeOut' }}
        className="bg-white dark:bg-gray-900 border border-gray-100 dark:border-white/5 rounded-[2rem] p-6 md:p-8 shadow-sm relative overflow-hidden"
      >
        {/* Background decoration */}
        <div className="absolute inset-0 bg-gradient-to-br from-orange-50/50 to-transparent dark:from-orange-900/10 pointer-events-none" />

        {/* Dismiss button */}
        {!allDone && (
          <button
            onClick={handleDismiss}
            aria-label="Masquer le guide"
            className="absolute top-4 right-4 w-8 h-8 rounded-full bg-gray-100 dark:bg-gray-800 flex items-center justify-center hover:bg-gray-200 dark:hover:bg-gray-700 transition-colors z-10"
          >
            <X className="w-3.5 h-3.5 text-gray-500" />
          </button>
        )}

        {/* Header */}
        <div className="flex items-start gap-4 mb-6 relative">
          <div className="w-12 h-12 bg-[#ff6600]/10 rounded-2xl flex items-center justify-center shrink-0">
            <Sparkles className="w-6 h-6 text-[#ff6600]" />
          </div>
          <div className="flex-1">
            <div className="flex items-center gap-2 flex-wrap">
              <h2 className="text-[15px] font-black text-gray-900 dark:text-white uppercase tracking-tighter italic">
                {allDone ? '🎉 Boutique prête au décollage !' : 'Guide de démarrage'}
              </h2>
              <span className="text-[10px] font-black text-[#ff6600] bg-[#ff6600]/10 px-2.5 py-0.5 rounded-full uppercase tracking-wider">
                {completedCount}/{steps.length}
              </span>
            </div>
            <p className="text-[11px] text-gray-500 dark:text-gray-400 font-bold tracking-wide mt-0.5">
              {allDone
                ? 'Tous les paramètres sont configurés. Votre boutique est opérationnelle !'
                : 'Complétez les étapes ci-dessous pour maximiser vos ventes.'}
            </p>
          </div>
        </div>

        {/* Progress bar */}
        <div className="mb-6 relative">
          <div className="h-1.5 bg-gray-100 dark:bg-gray-800 rounded-full overflow-hidden">
            <motion.div
              initial={{ width: 0 }}
              animate={{ width: `${progress}%` }}
              transition={{ duration: 0.7, ease: 'easeOut' }}
              className="h-full bg-gradient-to-r from-[#ff6600] to-amber-500 rounded-full"
            />
          </div>
          <div className="flex justify-between mt-1.5">
            <span className="text-[10px] font-black text-gray-400 uppercase tracking-wider">Progression</span>
            <span className="text-[10px] font-black text-[#ff6600] uppercase tracking-wider">{progress}%</span>
          </div>
        </div>

        {/* Steps */}
        <div className="space-y-2 relative">
          {steps.map((step, i) => (
            <motion.button
              key={step.id}
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: i * 0.06, duration: 0.25 }}
              onClick={() => handleStepClick(step)}
              disabled={step.done || !step.path}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all text-left group ${
                step.done
                  ? 'bg-emerald-500/8 dark:bg-emerald-500/10 border border-emerald-500/15 dark:border-emerald-500/25 cursor-default'
                  : step.path
                  ? 'bg-gray-50 dark:bg-gray-800/50 border border-gray-100 dark:border-white/5 hover:border-[#ff6600]/30 hover:bg-orange-50/50 dark:hover:bg-orange-900/10 cursor-pointer'
                  : 'bg-gray-50 dark:bg-gray-800/50 border border-gray-100 dark:border-white/5 cursor-default opacity-60'
              }`}
            >
              {/* Icon */}
              <div className="shrink-0">
                {step.done ? (
                  <CheckCircle2 className="w-5 h-5 text-emerald-500 dark:text-emerald-400" />
                ) : (
                  <Circle className="w-5 h-5 text-gray-300 dark:text-gray-600" />
                )}
              </div>

              {/* Text */}
              <div className="flex-1 min-w-0">
                <p className={`text-[12px] font-black uppercase tracking-tight leading-none ${
                  step.done
                    ? 'text-emerald-700 dark:text-emerald-300 opacity-85'
                    : 'text-gray-900 dark:text-white'
                }`}>
                  {step.label}
                </p>
                {!step.done && (
                  <p className="text-[10px] text-gray-400 font-bold tracking-wide mt-0.5 leading-tight">
                    {step.hint}
                  </p>
                )}
              </div>

              {/* Arrow for actionable steps */}
              {!step.done && step.path && (
                <ChevronRight className="w-4 h-4 text-gray-300 dark:text-gray-600 group-hover:text-[#ff6600] group-hover:translate-x-0.5 transition-all shrink-0" />
              )}
            </motion.button>
          ))}
        </div>
      </motion.div>
    </AnimatePresence>
  );
}
