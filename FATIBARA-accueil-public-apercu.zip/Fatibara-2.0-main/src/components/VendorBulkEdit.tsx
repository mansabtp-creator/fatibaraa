import React, { useState } from 'react';
import { Save, AlertCircle, CheckCircle2, Loader2, Package, CloudOff } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { motion, AnimatePresence } from 'motion/react';
import { useOfflineStore } from '../store/useOfflineStore';
import { useToast } from '../context/ToastContext';

interface Product {
  id: string;
  title: string;
  price_gnf: number;
  stock_quantity: number;
  image_urls: string[];
}

interface VendorBulkEditProps {
  initialProducts: Product[];
  onRefresh: () => Promise<void>;
  /** Used to scope updates to this vendor's store only — prevents cross-store edits */
  storeId?: string;
}

export default function VendorBulkEdit({ initialProducts, onRefresh, storeId }: VendorBulkEditProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const { pendingEdits, addEdit, removeEdit, clearPersisted } = useOfflineStore();
  const { showToast } = useToast();
  const [saving, setSaving] = useState(false);
  const [saveStatus, setSaveStatus] = useState<'idle' | 'success' | 'error'>('idle');

  const filteredProducts = initialProducts.filter(p => 
    p.title.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleUpdate = (id: string, field: keyof Product, value: any) => {
    addEdit(id, { [field]: value });
    setSaveStatus('idle');
  };

  const handleBulkSave = async () => {
    const updates = Object.keys(pendingEdits).map(id => ({
      id,
      ...pendingEdits[id]
    }));

    if (updates.length === 0) return;

    setSaving(true);
    setSaveStatus('idle');

    try {
      for (const update of updates) {
        let query = supabase
          .from('products')
          .update(update)
          .eq('id', update.id);
        // Guard: only update products belonging to this store to prevent
        // cross-store edits if pendingEdits ever contains a foreign product ID.
        if (storeId) query = query.eq('store_id', storeId);
        const { error } = await query;
        if (error) throw error;
      }
      
      setSaveStatus('success');
      clearPersisted();
      showToast("Toutes les modifications ont été synchronisées", 'success');
      await onRefresh();
      
      setTimeout(() => setSaveStatus('idle'), 3000);
    } catch (err) {
      console.error(err);
      setSaveStatus('error');
      showToast("Erreur lors de la synchronisation. Vos modifications sont sauvegardées localement.", 'error');
    } finally {
      setSaving(false);
    }
  };

  const stagedCount = Object.keys(pendingEdits).length;
  const hasChanges = stagedCount > 0;

  return (
    <div className="bg-white dark:bg-gray-900 rounded-[3rem] border border-brand-border/30 overflow-hidden shadow-sm">
      <div className="p-8 border-b border-brand-border/30 bg-gray-50/10 flex flex-col md:flex-row justify-between items-center gap-6">
        <div>
           <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-1">Édition en Masse</h3>
           <div className="flex items-center gap-2">
             <p className="text-[12px] text-brand-text-muted font-bold uppercase tracking-wider">Mettez à jour vos stocks et prix en quelques clics</p>
             {hasChanges && (
                <span className="flex items-center gap-1 bg-yellow-100 text-yellow-700 px-2 py-0.5 rounded-full text-[9px] font-bold tracking-wider">
                  <CloudOff className="w-3 h-3" /> Drafts locaux
                </span>
             )}
           </div>
        </div>
        
        <div className="flex items-center gap-4">
          <AnimatePresence>
            {hasChanges && (
               <motion.button
                 initial={{ opacity: 0 }}
                 animate={{ opacity: 1 }}
                 exit={{ opacity: 0 }}
                 onClick={clearPersisted}
                 className="text-[10px] font-bold tracking-wider text-brand-text-dim hover:text-red-500 transition-colors mr-2"
               >
                 Annuler tout
               </motion.button>
            )}
            {saveStatus === 'success' && (
              <motion.div 
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0 }}
                className="flex items-center gap-2 text-green-600 font-bold text-[11px] tracking-wider"
              >
                <CheckCircle2 className="w-4 h-4" /> Synchronisé
              </motion.div>
            )}
            {saveStatus === 'error' && (
              <motion.div 
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0 }}
                className="flex items-center gap-2 text-red-600 font-bold text-[11px] tracking-wider"
              >
                <AlertCircle className="w-4 h-4" /> Erreur Serveur
              </motion.div>
            )}
          </AnimatePresence>

          <button 
            onClick={handleBulkSave}
            disabled={!hasChanges || saving}
            className={`flex items-center gap-3 px-8 py-4 rounded-full text-[12px] font-bold tracking-wider transition-all shadow-xl ${
              !hasChanges ? 'bg-gray-50 dark:bg-gray-800 text-brand-text-dim cursor-not-allowed border-brand-border' : 'bg-[#ff6600] text-brand-inverse hover:bg-black shadow-[#ff6600]/20'
            }`}
          >
            {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
            {saving ? 'Synchronisation...' : `Sauvegarder tout (${stagedCount})`}
          </button>
        </div>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full text-left">
          <thead className="bg-white dark:bg-gray-900 text-[10px] font-bold tracking-wider text-brand-text-dim border-b border-brand-border/30">
            <tr>
              <th className="px-8 py-6">Produit</th>
              <th className="px-8 py-6">Prix (GNF)</th>
              <th className="px-8 py-6">Stock Unités</th>
              <th className="px-8 py-6">Aperçu Impact</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-brand-border/20">
            {filteredProducts.map(p => {
               const staged = pendingEdits[p.id] || {};
               const price = staged.price_gnf !== undefined ? staged.price_gnf : p.price_gnf;
               const stock = staged.stock_quantity !== undefined ? staged.stock_quantity : p.stock_quantity;

               return (
                <tr key={p.id} className={`transition-colors ${hasChanges && pendingEdits[p.id] ? 'bg-yellow-50/30' : 'hover:bg-gray-50/10'}`}>
                  <td className="px-8 py-6">
                    <div className="flex items-center gap-4">
                        <div className="w-12 h-12 rounded-xl border border-brand-border overflow-hidden bg-gray-50 dark:bg-gray-800 shrink-0">
                          <img src={p.image_urls[0]} alt="" className="w-full h-full object-cover" />
                        </div>
                        <span className="font-bold text-gray-900 dark:text-white truncate max-w-[200px]">{p.title}</span>
                    </div>
                  </td>
                  <td className="px-8 py-6">
                    <input 
                      type="number"
                      min="0"
                      value={price}
                      onChange={(e) => handleUpdate(p.id, 'price_gnf', parseInt(e.target.value))}
                      className="w-40 bg-gray-50/30 border border-brand-border/40 rounded-xl p-3 text-[14px] font-bold text-gray-900 dark:text-white focus:border-[#ff6600] outline-none transition-all"
                    />
                  </td>
                  <td className="px-8 py-6">
                    <input 
                      type="number"
                      min="0"
                      value={stock}
                      onChange={(e) => handleUpdate(p.id, 'stock_quantity', parseInt(e.target.value))}
                      className="w-32 bg-gray-50/30 border border-brand-border/40 rounded-xl p-3 text-[14px] font-bold text-gray-900 dark:text-white focus:border-[#ff6600] outline-none transition-all"
                    />
                  </td>
                  <td className="px-8 py-6">
                    <div className="flex flex-col gap-1">
                        <div className="flex items-center justify-between w-full">
                          <span className="text-[9px] font-bold text-brand-text-muted uppercase tracking-wider">Valeur Stock</span>
                          <span className="text-[12px] font-bold text-gray-900 dark:text-white">
                              {(price * stock).toLocaleString()} GNF
                          </span>
                        </div>
                        <div className="h-1 bg-gray-50 dark:bg-gray-800 rounded-full overflow-hidden">
                          <div className={`h-full ${hasChanges && pendingEdits[p.id] ? 'bg-yellow-500' : 'bg-[#ff6600]'} w-[30%]`}/>
                        </div>
                    </div>
                  </td>
                </tr>
              )
            })}
          </tbody>
        </table>
      </div>
      
      {initialProducts.length === 0 && (
        <div className="p-20 text-center flex flex-col items-center">
           <Package className="w-12 h-12 text-brand-text-dim mb-4" />
           <p className="font-bold text-brand-text-muted tracking-wider text-[11px]">Aucun produit à modifier</p>
        </div>
      )}
    </div>
  );
}
