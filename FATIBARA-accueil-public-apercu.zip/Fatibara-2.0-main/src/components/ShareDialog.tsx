import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, MessageCircle, Facebook, Link as LinkIcon, Check, Share2 } from 'lucide-react';
import { APP_NAME } from '../lib/constants';

import { shareProduct } from '../lib/share';
import { useToast } from '../context/ToastContext';

interface ShareDialogProps {
  isOpen: boolean;
  onClose: () => void;
  productTitle: string;
  productId: string;
}

export default function ShareDialog({ isOpen, onClose, productTitle, productId }: ShareDialogProps) {
  const [copied, setCopied] = useState(false);
  const { showToast } = useToast();
  const shareUrl = `${window.location.origin}/product/${productId}`;
  const shareText = `Regardez ce produit sur ${APP_NAME} : ${productTitle}`;

  const handleNativeShare = async () => {
    await shareProduct(productTitle, shareUrl, showToast);
  };

  const shareOptions = [
    {
      name: 'WhatsApp',
      icon: MessageCircle,
      color: 'bg-[#25D366]',
      action: () => window.open(`https://wa.me/?text=${encodeURIComponent(shareText + ' ' + shareUrl)}`, '_blank')
    },
    {
      name: 'Facebook',
      icon: Facebook,
      color: 'bg-[#1877F2]',
      action: () => window.open(`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(shareUrl)}`, '_blank')
    }
  ];

  const handleCopyLink = () => {
    navigator.clipboard.writeText(shareUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/40 backdrop-blur-sm z-[100]"
          />
          
          {/* Dialog */}
          <motion.div
            initial={{ opacity: 0, scale: 0.9, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9, y: 20 }}
            className="fixed left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-[90%] max-w-sm bg-white dark:bg-gray-900 rounded-[2.5rem] shadow-2xl z-[101] overflow-hidden border border-gray-100 dark:border-white/5"
          >
            <div className="p-8">
              <div className="flex justify-between items-center mb-6">
                <h3 className="text-xl font-bold text-gray-900 dark:text-white tracking-tighter uppercase">Partager ce produit</h3>
                <button onClick={onClose} className="p-2 hover:bg-gray-50 dark:hover:bg-gray-800 rounded-full transition-colors text-gray-500 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white">
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="grid grid-cols-3 gap-4 mb-8">
                <button
                  onClick={handleNativeShare}
                  className="flex flex-col items-center gap-3 p-4 rounded-3xl hover:bg-gray-50 dark:hover:bg-gray-800 transition-all group"
                >
                  <div className="bg-[#ff6600] text-white p-4 rounded-[1.5rem] group-hover:scale-110 transition-transform shadow-lg">
                    <Share2 className="w-6 h-6" />
                  </div>
                  <span className="text-[11px] font-bold text-gray-900 dark:text-white tracking-wider">Plus</span>
                </button>
                {shareOptions.map((option) => (
                  <button
                    key={option.name}
                    onClick={option.action}
                    className="flex flex-col items-center gap-3 p-4 rounded-3xl hover:bg-gray-50 dark:hover:bg-gray-800 transition-all group"
                  >
                    <div className={`${option.color} text-white p-4 rounded-[1.5rem] group-hover:scale-110 transition-transform shadow-lg`}>
                      <option.icon className="w-6 h-6" />
                    </div>
                    <span className="text-[11px] font-bold text-gray-900 dark:text-white tracking-wider">{option.name}</span>
                  </button>
                ))}
              </div>

              <div className="space-y-4">
                <label className="text-[10px] font-bold text-gray-500 dark:text-gray-400 tracking-wider ml-4 opacity-70">Lien direct</label>
                <div className="flex items-center gap-2 bg-gray-50 dark:bg-black/20 p-2.5 rounded-[1.5rem] border border-gray-200 dark:border-white/10">
                  <input
                    type="text"
                    readOnly
                    value={shareUrl}
                    className="flex-1 bg-transparent text-[12px] px-3 font-bold text-brand-text-dim dark:text-gray-400 outline-none truncate"
                  />
                  <button
                    onClick={handleCopyLink}
                    className={`flex items-center gap-2 px-5 py-2.5 rounded-xl text-[10px] font-bold tracking-wider transition-all ${
                      copied ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-600/20' : 'bg-gray-900 dark:bg-[#ff6600] text-brand-inverse hover:bg-[#ff6600] dark:hover:bg-[#ff6600] shadow-lg shadow-gray-900/10 dark:shadow-orange-900/10'
                    }`}
                  >
                    {copied ? <Check className="w-3.5 h-3.5" /> : <LinkIcon className="w-3.5 h-3.5" />}
                    {copied ? 'Copié' : 'Copier'}
                  </button>
                </div>
              </div>
            </div>
            
            <div className="bg-gray-50 dark:bg-gray-800 dark:bg-black/40 p-8 text-center border-t border-brand-border/20 dark:border-white/5">
              <p className="text-[11px] text-brand-text-dim dark:text-gray-500 dark:text-gray-400 font-bold uppercase tracking-tight leading-relaxed opacity-60">
                Partagez avec vos amis et votre famille sur les réseaux sociaux.
              </p>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
