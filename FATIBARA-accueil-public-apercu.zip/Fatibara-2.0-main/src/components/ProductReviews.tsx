import React, { useEffect, useState } from 'react';
import { Star, User, MessageCircle, Truck, ShieldCheck, ThumbsUp, MapPin, CheckCircle2 } from 'lucide-react';
import { motion } from 'motion/react';
import { supabase } from '../lib/supabase';

interface Review {
  id: string;
  user_name?: string;
  avatar_url?: string;
  rating: number;
  comment: string;
  location?: string;
  shop_response?: string;
  created_at: string;
  review_photos?: { photo_url: string }[];
}

export default function ProductReviews({ productId, storeId }: { productId?: string; storeId?: string }) {
  const [reviews, setReviews] = useState<Review[]>([]);
  const [loading, setLoading] = useState(true);
  const [fetchError, setFetchError] = useState<string | null>(null);

  useEffect(() => {
    async function fetchReviews() {
      if (!productId && !storeId) {
        setLoading(false);
        return;
      }
      try {
        let query = supabase
          .from('reviews')
          .select('*')
          .order('created_at', { ascending: false });
        
        if (productId) {
          query = query.eq('product_id', productId);
        } else if (storeId) {
          query = query.eq('store_id', storeId);
        }

        const { data, error } = await query;

        if (error) throw error;

        if (data) setReviews(data);
        
      } catch (err) {
        console.error('Failed to fetch reviews', err);
        setFetchError("Impossible de récupérer les avis pour le moment.");
      } finally {
        setLoading(false);
      }
    }
    fetchReviews();
  }, [productId, storeId]);

  if (loading) {
    return (
      <div className="mt-16 space-y-4 animate-pulse">
        <div className="h-32 bg-white dark:bg-gray-900 dark:bg-gray-800 rounded-[3rem] border border-brand-border/40 dark:border-white/10 w-full" />
        {[1, 2].map(i => (
          <div key={i} className="h-48 bg-white dark:bg-gray-900 dark:bg-gray-800 rounded-[3rem] border border-brand-border/40 dark:border-white/10 w-full" />
        ))}
      </div>
    );
  }

  if (fetchError) {
    return (
      <div className="mt-16 bg-red-500/5 dark:bg-red-950/20 rounded-[3rem] border border-red-500/20 dark:border-red-900/30 overflow-hidden p-12 text-center text-red-500">
        <h2 className="text-xl font-bold tracking-tight mb-2 uppercase">Erreur de Connexion</h2>
        <p className="text-[14px] font-medium leading-relaxed">{fetchError}</p>
      </div>
    );
  }

  if (reviews.length === 0) {
    return (
      <div className="mt-16 bg-white bg-white dark:bg-gray-900 rounded-[3rem] border border-brand-border/40 dark:border-white/10 overflow-hidden shadow-sm p-12 text-center text-gray-900 text-gray-900 dark:text-white">
        <h2 className="text-3xl font-bold tracking-tight mb-4 uppercase">Aucun avis pour le moment</h2>
        <p className="text-[14px] text-gray-900/70 dark:text-gray-400 font-bold tracking-wider leading-relaxed">Soyez le premier à partager votre expérience avec ce produit !</p>
      </div>
    );
  }

  const avgRating = (reviews.reduce((acc, r) => acc + r.rating, 0) / reviews.length).toFixed(1);

  return (
    <div className="mt-16 bg-white bg-white dark:bg-gray-900 rounded-[3rem] border border-brand-border/40 dark:border-white/10 overflow-hidden shadow-sm">
      <div className="p-8 md:p-12 border-b border-brand-border/30 dark:border-white/10 bg-gray-50 dark:bg-gray-800 dark:bg-gray-950/50">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-10">
            <div>
              <div className="flex items-center gap-4 mb-2">
                <div className="w-12 h-12 bg-pink-100 dark:bg-pink-900/20 rounded-xl flex items-center justify-center text-[#ff6600] dark:text-orange-400 shadow-sm border border-[#ff6600]/10 dark:border-[#ff6600]/20">
                  <Star className="w-6 h-6 fill-current" />
                </div>
                <h2 className="text-3xl font-bold text-gray-900 text-gray-900 dark:text-white tracking-tighter uppercase">Social Pulse</h2>
              </div>
              <p className="text-[12px] text-gray-900/60 dark:text-gray-400 font-bold tracking-wider mt-2 italic">
                Analysé via {reviews.length} achat{reviews.length > 1 ? 's' : ''} vérifié{reviews.length > 1 ? 's' : ''}
              </p>
            </div>

          <div className="flex items-center gap-10 bg-white dark:bg-gray-900 dark:bg-gray-800 p-6 rounded-[2rem] border border-brand-border/10 dark:border-white/5 shadow-inner">
            <div className="text-center px-4">
              <div className="text-5xl font-bold text-gray-900 text-gray-900 dark:text-white leading-none tracking-tighter">{avgRating}</div>
              <div className="flex gap-1 mt-3 justify-center">
                {[1, 2, 3, 4, 5].map(i => (
                  <Star key={i} className={`w-4 h-4 ${i <= Math.round(Number(avgRating)) ? 'fill-[#ff6600] text-[#ff6600]' : 'text-brand-border/30 dark:text-gray-600'}`} />
                ))}
              </div>
            </div>
            <div className="h-12 w-[2px] bg-brand-border/20 dark:bg-gray-700 rounded-full" />
            <div className="text-left">
              <div className="text-[10px] font-bold tracking-wider text-gray-900 text-gray-900 dark:text-white mb-1">Score Communauté</div>
              <div className="text-[11px] font-bold tracking-wider text-emerald-700 dark:text-emerald-400">Excellent 100%</div>
            </div>
          </div>
        </div>
      </div>

      <div className="divide-y divide-brand-border/30 dark:divide-white/5">
        {reviews.map((review, idx) => (
          <motion.div 
            key={review.id}
            initial={{ opacity: 0, scale: 0.98 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            transition={{ delay: idx * 0.1 }}
            className="p-8 md:p-12 group transition-all hover:bg-gray-50/30 dark:hover:bg-white/5"
          >
            <div className="flex flex-col md:flex-row items-start justify-between gap-6 mb-8">
              <div className="flex items-center gap-5">
                <div className="w-16 h-16 rounded-[1.5rem] overflow-hidden border border-brand-border dark:border-white/10 shadow-sm group-hover:border-[#ff6600] transition-all group-hover:scale-105">
                  <img src={review.avatar_url || `https://api.dicebear.com/7.x/initials/svg?seed=${review.user_name || 'U'}`} alt={review.user_name || 'User'} className="w-full h-full object-cover" />
                </div>
                <div>
                  <div className="flex items-center gap-3 mb-1.5">
                    <span className="text-[18px] font-bold text-gray-900 text-gray-900 dark:text-white tracking-tight uppercase">{review.user_name || 'Client Anonyme'}</span>
                    <div className="flex items-center gap-1.5 bg-emerald-50 dark:bg-emerald-500/10 text-emerald-700 dark:text-emerald-400 text-[9px] px-3 py-1 rounded-full font-bold tracking-wider border border-emerald-100 dark:border-emerald-500/20 shadow-sm">
                       <CheckCircle2 className="w-3.5 h-3.5" /> Vérifié
                    </div>
                  </div>
                  <div className="flex items-center gap-3 text-[11px] font-bold text-brand-text-dim dark:text-gray-400 tracking-wider">
                     {review.location && <span className="flex items-center gap-1.5 text-gray-900 text-gray-900 dark:text-white"><MapPin className="w-4 h-4 text-[#ff6600]" /> {review.location}</span>}
                     {review.location && <span className="text-brand-border/50 dark:text-white/20">•</span>}
                     <span>{new Date(review.created_at).toLocaleDateString()}</span>
                  </div>
                </div>
              </div>
              <div className="flex gap-1.5 bg-gray-50 bg-gray-50 dark:bg-gray-800 p-3 rounded-2xl border border-brand-border/30 dark:border-white/5 shadow-sm">
                {[1, 2, 3, 4, 5].map(i => (
                  <Star key={i} className={`w-5 h-5 transition-transform group-hover:scale-110 ${i <= review.rating ? 'fill-[#ff6600] text-[#ff6600]' : 'text-brand-border/30 dark:text-gray-700'}`} />
                ))}
              </div>
            </div>

            <div className="pl-0 md:pl-20">
               <p className="text-[17px] md:text-[19px] text-gray-900 text-gray-900 dark:text-white leading-relaxed font-bold uppercase tracking-tight mb-6">
                 "{review.comment}"
               </p>

               {review.review_photos && review.review_photos.length > 0 && (
                 <div className="flex gap-4 mb-10 overflow-x-auto no-scrollbar">
                   {review.review_photos.map((photo, pIdx) => (
                     <div key={pIdx} className="w-24 h-24 md:w-32 md:h-32 flex-shrink-0 border border-gray-200 dark:border-gray-700 dark:border-white/10 rounded-2xl overflow-hidden shadow-sm group/photo">
                       <img src={photo.photo_url} alt="" className="w-full h-full object-cover group-hover/photo:scale-110 transition-transform duration-500" />
                     </div>
                   ))}
                 </div>
               )}

               {review.shop_response && (
                 <div className="mb-10 p-8 bg-gray-50 dark:bg-gray-800 dark:bg-white/5 rounded-[2.5rem] border border-[#ff6600]/20 relative shadow-sm">
                    <div className="absolute -top-4 left-8 bg-[#ff6600] text-brand-inverse text-[10px] font-bold tracking-wider px-4 py-1.5 rounded-full shadow-lg shadow-[#ff6600]/20">
                       Boutique Officielle
                    </div>
                    <p className="text-[15px] font-bold text-gray-900 dark:text-white dark:text-gray-300 leading-relaxed uppercase tracking-tight italic">
                       "{review.shop_response}"
                    </p>
                 </div>
               )}

               <div className="flex items-center gap-5">
                  <button className="flex items-center gap-2 text-[11px] font-bold min-h-[48px] min-w-[56px] px-6 bg-gray-50 bg-gray-50 dark:bg-gray-800 border border-brand-border/40 dark:border-white/10 rounded-full text-brand-text-dim dark:text-gray-400 hover:text-[#ff6600] dark:hover:text-orange-400 hover:border-[#ff6600] transition-all group/btn tracking-wider shadow-sm">
                    <ThumbsUp className="w-4 h-4 group-hover/btn:-translate-y-1 transition-transform" /> 
                    Utile
                  </button>
                  <button className="flex items-center gap-2 text-[11px] font-bold min-h-[48px] min-w-[56px] px-6 text-brand-text-dim dark:text-gray-400 hover:text-gray-900 text-gray-900 dark:text-white transition-all tracking-wider hover:underline underline-offset-4">
                    <MessageCircle className="w-4 h-4" /> Signaler
                  </button>
               </div>
            </div>
          </motion.div>
        ))}
      </div>
      
      {reviews.length > 5 && (
        <button className="w-full p-12 bg-gray-900 dark:bg-[#ff6600] text-center group cursor-pointer border-none outline-none block hover:bg-black dark:hover:bg-[#e62e00] transition-all">
          <span className="text-brand-inverse text-[14px] font-bold uppercase tracking-[5px] group-hover:tracking-[10px] transition-all inline-block">
            Accéder à l'historique complet
          </span>
        </button>
      )}
    </div>

  );
}
