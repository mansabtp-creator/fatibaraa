import React from 'react';
import { motion } from 'motion/react';
import { AlertTriangle, Package, TrendingDown, ArrowRight } from 'lucide-react';

interface Product {
  id: string;
  title: string;
  stock_quantity: number;
  low_stock_threshold?: number;
  price_gnf: number;
}

export const InventoryHeatmap = ({ products }: { products: Product[] }) => {
  const lowStockProducts = products
    .filter(p => p.stock_quantity <= (p.low_stock_threshold || 5))
    .sort((a, b) => a.stock_quantity - b.stock_quantity);

  if (lowStockProducts.length === 0) return null;

  return (
    <div className="bg-white dark:bg-[#1A1D21] rounded-[2.5rem] p-8 border border-gray-100 dark:border-white/5 shadow-sm">
      <div className="flex items-center justify-between mb-8">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-amber-500/10 rounded-xl flex items-center justify-center">
            <AlertTriangle className="w-5 h-5 text-amber-500" />
          </div>
          <div>
            <h3 className="text-lg font-black text-gray-900 dark:text-white tracking-tighter uppercase italic">Alertes Rupture</h3>
            <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest italic">Priorité logistique immédiate</p>
          </div>
        </div>
        <div className="px-3 py-1 bg-amber-500/10 rounded-full border border-amber-500/20">
          <span className="text-[9px] font-black text-amber-500 uppercase tracking-widest">{lowStockProducts.length} ARTICLES</span>
        </div>
      </div>

      <div className="space-y-4">
        {lowStockProducts.slice(0, 5).map((product, idx) => {
          const percentage = Math.max(0, Math.min((product.stock_quantity / (product.low_stock_threshold || 5)) * 100, 100));
          return (
            <motion.div 
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: idx * 0.1 }}
              key={product.id} 
              className="group cursor-pointer"
            >
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-lg bg-gray-50 dark:bg-black/20 flex items-center justify-center border border-gray-100 dark:border-white/5 group-hover:border-amber-500/30 transition-all">
                    <Package className="w-4 h-4 text-gray-400 group-hover:text-amber-500" />
                  </div>
                  <div className="flex flex-col">
                    <span className="text-[12px] font-black text-gray-700 dark:text-gray-300 uppercase tracking-tight truncate max-w-[120px]">
                      {product.title}
                    </span>
                    <span className="text-[8px] font-bold text-gray-400 dark:text-gray-500 uppercase tracking-widest italic">
                      Potentiel: {(product.price_gnf * 10).toLocaleString()} GNF
                    </span>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                   <div className="text-right">
                      <div className="flex items-center gap-1">
                        <TrendingDown className="w-3 h-3 text-red-500" />
                        <span className="text-[12px] font-black text-red-500 tabular-nums">{product.stock_quantity}</span>
                      </div>
                      <p className="text-[8px] font-black text-gray-400 uppercase tracking-tighter">Stock Restant</p>
                   </div>
                   <button className="w-8 h-8 rounded-full bg-[#ff6600]/10 text-[#ff6600] flex items-center justify-center opacity-0 group-hover:opacity-100 transition-all hover:bg-[#ff6600] hover:text-white">
                      <ArrowRight className="w-4 h-4" />
                   </button>
                </div>
              </div>
              <div className="h-1.5 w-full bg-gray-50 dark:bg-white/5 rounded-full overflow-hidden relative">
                <motion.div 
                  initial={{ width: 0 }}
                  animate={{ width: `${percentage}%` }}
                  className={`h-full relative z-10 ${percentage < 30 ? 'bg-red-500' : 'bg-amber-500'}`} 
                />
                <div className="absolute inset-0 bg-red-500/10 dark:bg-red-500/5" />
              </div>
            </motion.div>
          );
        })}
      </div>

      <div className="mt-8 space-y-3">
        <button className="w-full py-4 bg-black dark:bg-white text-white dark:text-black rounded-2xl text-[10px] font-black text-gray-400 uppercase tracking-widest hover:scale-[1.02] active:scale-[0.98] transition-all shadow-xl">
           Générer ordre de réapprovisionnement
        </button>
        <button className="w-full py-4 border border-dashed border-gray-200 dark:border-white/10 rounded-2xl text-[10px] font-black text-gray-400 uppercase tracking-widest hover:border-amber-500 hover:text-amber-500 transition-all active:scale-[0.98]">
           Auto-ajustement IA (Logistique)
        </button>
      </div>
    </div>
  );
};
