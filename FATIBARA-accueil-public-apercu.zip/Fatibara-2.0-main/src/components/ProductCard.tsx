import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Link, useNavigate } from 'react-router-dom';
import { ShoppingCart, Store, Share2, Eye, Heart, Zap, MessageCircle, ShieldCheck, Star, Flame, Clock, Truck } from 'lucide-react';
import { useAppContext } from '../context/AppContext';
import { useStore } from '../store/useStore';
import { useCommerceStore } from '../store/useCommerceStore';
import { useToast } from '../context/ToastContext';

import { Promotion, promotionService } from '../services/promotionService';
import confetti from 'canvas-confetti';
import MagneticButton from './MagneticButton';
import { hapticFeedback } from '../lib/haptics';
import { calculateProductPrice } from '../utils/pricing';
import { cardUrl } from '../utils/imageUtils';
import { APP_NAME } from '../lib/constants';
import { formatGNF } from '../utils/formatters';

export interface VariationOption {
  label: string;
  value: string;
}

export interface Variation {
  id: string;
  type: string;
  options: VariationOption[];
}

export interface Product {
  id: string;
  title: string;
  price_gnf: number;
  wholesale_price_gnf?: number;
  image_urls: string[];
  description: string;
  stores?: {
    id: string;
    store_name: string;
    avatar_url?: string;
    is_open?: boolean;
    is_verified_store?: boolean;
    store_status?: string;
  };
  created_at?: string;
  relevance?: number;
  category?: string;
  variations?: Variation[];
  stock_count?: number;
  stock_quantity?: number;
  max_stock?: number;
  /** true when the store has an active PROPULSE campaign */
  is_propulsed?: boolean;
}

interface ProductCardProps {
  product: Product;
  index: number;
  onShare: (product: Product) => void;
  onQuickView: (product: Product) => void;
  isLarge?: boolean;
}

export const ProductCard: React.FC<ProductCardProps> = React.memo(({ product, index, onShare, onQuickView, isLarge = false }) => {
  const { proMode, user, activePromotions } = useAppContext();
  const { modeEconomie } = useStore();
  const { wishlist, toggleWishlist, addToCart, cart } = useCommerceStore();
  const { showToast } = useToast();
  const navigate = useNavigate();
  
  const [isBlooming, setIsBlooming] = useState(false);
  
  const isInWishlist = wishlist?.includes(product.id);
  
  // Track selected variations
  const [selectedVariations, setSelectedVariations] = useState<Record<string, string>>({});

  const baseImageUrl = cardUrl(product.image_urls?.[0]) || 'https://picsum.photos/seed/fallback/400/400';
  const imageUrl = modeEconomie ? `${baseImageUrl}&blur=2&q=50` : baseImageUrl;
  
  const isProMember = user?.profile_type === 'pro';
  const priceInfo = calculateProductPrice(product, 1, isProMember);
  
  const displayPrice = priceInfo.finalPrice;
  const hasPromoDiscount = priceInfo.discountAmount > 0;
  const appliedPromoPercent = priceInfo.discountPercent;

  // Stock progress bar logic
  const stock = product.stock_quantity ?? 100;
  const maxStock = product.max_stock ?? 100;
  const stockPercentage = Math.min(100, (stock / maxStock) * 100);
  
  const getStockColor = () => {
    if (stock === 0) return 'bg-red-500';
    if (stock <= 50) return 'bg-orange-500';
    return 'bg-emerald-500';
  };

  const handleVariationSelect = (variationId: string, option: string) => {
    setSelectedVariations(prev => ({
      ...prev,
      [variationId]: option
    }));
  };

  const handleWishlist = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    
    const currentlyInWishlist = wishlist?.includes(product.id);
    toggleWishlist(product.id, user?.id);
    
    // Haptic Feedback
    hapticFeedback(currentlyInWishlist ? 'light' : 'success');
    
    // Trigger confetti if adding to wishlist
    if (!currentlyInWishlist) {
      confetti({
        particleCount: 100,
        spread: 70,
        origin: { y: 0.6 },
        colors: ['#e91e63', '#fdf2f8', '#ffffff'] // Brand colors
      });
    }
  };

  const handleAddToCart = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();

    if (product.stores?.is_open === false) {
      hapticFeedback('error');
      showToast("Cette boutique est actuellement fermée.", 'warning');
      return;
    }
    
    // Check if all variations are selected
    const allSelected = product.variations?.every(v => selectedVariations[v.id]) ?? true;
    
    if (!allSelected) {
      hapticFeedback('error');
      showToast("Veuillez sélectionner toutes les options.", 'warning');
      return;
    }

    const currentCartItem = cart.find(item => item.product_id === product.id && JSON.stringify(item.selected_variations || {}) === JSON.stringify(selectedVariations || {}));
    const currentQty = currentCartItem ? currentCartItem.quantity : 0;
    
    if (currentQty + 1 > stock) {
      hapticFeedback('error');
      showToast("Stock maximum atteint pour ce produit.", "warning");
      return;
    }
    
    hapticFeedback('reward');
    addToCart(product.id, 1, selectedVariations, user?.id);
    setIsBlooming(true);
    setTimeout(() => setIsBlooming(false), 800);
    showToast(`${product.title} ajouté !`, 'success');
    
    // Luxury Confetti Burst
    const duration = 2 * 1000;
    const animationEnd = Date.now() + duration;
    const defaults = { startVelocity: 30, spread: 360, ticks: 60, zIndex: 0 };

    const randomInRange = (min: number, max: number) => Math.random() * (max - min) + min;

    const interval: any = setInterval(function() {
      const timeLeft = animationEnd - Date.now();

      if (timeLeft <= 0) {
        return clearInterval(interval);
      }

      const particleCount = 50 * (timeLeft / duration);
      confetti({ ...defaults, particleCount, origin: { x: randomInRange(0.1, 0.3), y: Math.random() - 0.2 } });
      confetti({ ...defaults, particleCount, origin: { x: randomInRange(0.7, 0.9), y: Math.random() - 0.2 } });
    }, 250);
  };

  const isNew = product.created_at && new Date(product.created_at).getTime() > Date.now() - 7 * 24 * 60 * 60 * 1000;
  
  // Simulated social proof
  const viewersCount = Math.floor(Math.random() * 15) + 3;

  return (
    <motion.div 
      initial={{ opacity: 0, y: 10 }}
      whileInView={{ opacity: 1, y: 0 }}
      transition={{ 
        duration: modeEconomie ? 0 : 0.4, 
        delay: modeEconomie ? 0 : (index % 4) * 0.05
      }}
      viewport={{ once: true, margin: "-50px" }}
      onClick={() => navigate(`/product/${product.id}`)}
      onKeyDown={(e) => e.key === 'Enter' && navigate(`/product/${product.id}`)}
      role="button"
      tabIndex={0}
      className={`group h-full cursor-pointer outline-none ${isLarge ? 'md:col-span-2' : ''}`}
    >
      <div 
        className={`flex flex-col h-full bg-white dark:bg-[#0F1115] rounded-3xl overflow-hidden transition-all duration-700 relative border border-gray-100 dark:border-white/5 hover:shadow-[0_32px_64px_-12px_rgba(255,102,0,0.15)] hover:-translate-y-2 hover:border-[#ff6600]/30 group-hover:ring-1 group-hover:ring-[#ff6600]/20`}
      >
        {/* Badges */}
        <div className="absolute top-3 left-3 flex flex-col gap-1.5 z-20 pointer-events-none">
          {/* PROPULSE badge — shown when the store has an active boost campaign */}
          {product.is_propulsed && (
            <div className="flex items-center gap-1 bg-[#ff6600] text-white px-3 py-1 rounded-lg text-[9px] font-black uppercase tracking-widest shadow-xl border border-white/20 animate-pulse">
              🚀 PROPULSÉ
            </div>
          )}
          {product.stores?.is_open === false && (
            <div className="bg-black/80 backdrop-blur-md text-white px-3 py-1 rounded-lg text-[9px] font-black uppercase tracking-widest shadow-xl">
              Fermé
            </div>
          )}
          {isNew && (
            <div className="bg-[#16a34a] text-white px-3 py-1 rounded-lg text-[9px] font-black uppercase tracking-widest shadow-xl border border-white/20">
              Nouveau
            </div>
          )}
          {hasPromoDiscount && (
            <div className="bg-[#ff6600] text-white px-3 py-1 rounded-lg text-[9px] font-black uppercase tracking-widest shadow-xl border border-white/20">
              -{appliedPromoPercent}%
            </div>
          )}
          {isProMember && (
            <div className="bg-emerald-600 text-white px-3 py-1 rounded-lg text-[9px] font-black uppercase tracking-widest shadow-xl flex items-center gap-1 border border-white/20">
              <Zap className="w-3 h-3 fill-current" /> MEMBRE ELITE
            </div>
          )}
        </div>

        {/* Image Section */}
        <div className="relative aspect-[4/5] bg-gray-50 dark:bg-black/40 flex items-center justify-center overflow-hidden group/img p-4">
          <img
            src={imageUrl}
            alt={product.title}
            className={`max-w-[85%] max-h-[85%] object-contain transition-all duration-1000 ease-[cubic-bezier(0.23,1,0.32,1)] group-hover/img:scale-115 group-hover/img:rotate-2 mix-blend-multiply dark:mix-blend-normal drop-shadow-2xl`}
            referrerPolicy="no-referrer"
            loading="lazy"
          />
          
          <div className="absolute inset-x-0 bottom-0 h-1/2 bg-gradient-to-t from-black/20 to-transparent opacity-0 group-hover/img:opacity-100 transition-opacity duration-500" />

          {/* {APP_NAME} Elite Verification Ribbon */}
          <div className="absolute bottom-4 left-0 right-0 p-2 flex justify-center translate-y-10 group-hover/img:translate-y-0 transition-all duration-500 ease-out">
             <div className="flex items-center gap-2 px-4 py-1.5 bg-black/80 backdrop-blur-xl rounded-full border border-white/20 shadow-2xl">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                <span className="text-[9px] font-black uppercase tracking-[0.2em] text-white">Certifié {APP_NAME}</span>
             </div>
          </div>
          
          <div className="absolute top-2 right-2 flex flex-col gap-2 z-10 translate-x-10 opacity-0 group-hover:translate-x-0 group-hover:opacity-100 transition-all duration-300">
             <button
              onClick={handleWishlist}
              aria-label={isInWishlist ? `Retirer ${product.title} des favoris` : `Ajouter ${product.title} aux favoris`}
              className={`w-8 h-8 flex items-center justify-center rounded-full shadow-md transition-colors bg-white dark:bg-gray-900 dark:bg-gray-700 hover:bg-gray-50 dark:bg-gray-800 dark:hover:bg-gray-600 text-gray-400 dark:text-gray-300 hover:text-[#e62e00] dark:hover:text-[#e62e00] ${
                isInWishlist ? 'text-[#e62e00] dark:text-[#e62e00]' : ''
              }`}
            >
              <Heart className={`w-4 h-4 ${isInWishlist ? 'fill-current' : ''}`} />
            </button>
            <button
              onClick={(e) => {
                e.preventDefault();
                e.stopPropagation();
                onShare(product);
              }}
              aria-label={`Partager ${product.title}`}
              className="w-8 h-8 flex items-center justify-center rounded-full shadow-md transition-colors bg-white dark:bg-gray-800 hover:bg-gray-50 dark:hover:bg-gray-700 text-gray-400 dark:text-gray-300 hover:text-blue-500"
            >
              <Share2 className="w-4 h-4" />
            </button>
            <button
              onClick={(e) => {
                e.preventDefault();
                e.stopPropagation();
                onQuickView(product);
              }}
              aria-label={`Aperçu rapide de ${product.title}`}
              className="w-8 h-8 flex items-center justify-center rounded-full shadow-md transition-colors bg-white dark:bg-gray-800 hover:bg-gray-50 dark:hover:bg-gray-700 text-gray-400 dark:text-gray-300 hover:text-[#ff6600]"
            >
              <Eye className="w-4 h-4" />
            </button>
          </div>
        </div>

        <div className="p-4 flex flex-col flex-1 gap-3 bg-white dark:bg-[#1A1D21]">
          <div className="flex-1">
             <div className="text-[10px] font-black text-gray-400 dark:text-gray-500 uppercase tracking-[0.2em] mb-2 flex items-center justify-between italic">
                <span>{product.category || 'Général'}</span>
                <span className="text-[#16a34a] flex items-center gap-1 bg-[#16a34a]/10 px-2 py-0.5 rounded-full"><Star className="w-3 h-3 fill-current" /> 5.0</span>
             </div>
             
             <h3 className="text-[14px] font-bold text-gray-900 dark:text-white leading-snug line-clamp-2 group-hover:text-[#ff6600] transition-colors min-h-[40px] tracking-tight">
               {product.title}
             </h3>
             
             <Link 
              to={`/boutique/${product.stores?.store_name || product.sellerName}`} 
              onClick={(e) => e.stopPropagation()}
              className="flex items-center gap-2 mt-3 text-gray-500 dark:text-gray-400 hover:text-[#ff6600] transition-all group/store w-fit bg-gray-50 dark:bg-black/20 px-3 py-1.5 rounded-xl border border-gray-100 dark:border-white/5"
            >
              <Store className="w-3.5 h-3.5 group-hover/store:rotate-12 transition-transform" />
              <span className="text-[10px] font-black uppercase tracking-widest truncate max-w-[120px]">
                {product.stores?.store_name || APP_NAME}
              </span>
            </Link>
          </div>

          <div className="flex items-end justify-between mt-1">
            <div className="flex flex-col">
              {hasPromoDiscount && (
                <span className="text-[10px] text-gray-400 dark:text-gray-500 dark:text-gray-400 line-through font-medium mt-0.5">
                  {formatGNF(priceInfo.basePrice)}
                </span>
              )}
              <div className="flex items-baseline gap-1">
                <span className={`text-base md:text-xl font-bold ${hasPromoDiscount ? 'text-[#e62e00]' : 'text-gray-900 dark:text-white'} tracking-tight`}>
                  {formatGNF(displayPrice)}
                </span>
              </div>
              {/* Trust badges — delivery promise + low stock urgency */}
              <div className="flex items-center gap-2 mt-1.5 flex-wrap">
                <span className="flex items-center gap-1 text-[9px] font-bold text-emerald-600 dark:text-emerald-400">
                  <Truck className="w-3 h-3" />Livraison 24h
                </span>
                {stock > 0 && stock <= 10 && (
                  <span className="flex items-center gap-1 text-[9px] font-bold text-amber-600 dark:text-amber-400">
                    <Flame className="w-3 h-3" />{stock} restants
                  </span>
                )}
              </div>
            </div>

            <button
              onClick={stock <= 0 ? (e) => { e.preventDefault(); e.stopPropagation(); } : handleAddToCart}
              disabled={stock <= 0}
              aria-label={stock <= 0 ? `${product.title} — rupture de stock` : `Ajouter ${product.title} au panier`}
              className={`w-8 h-8 flex flex-shrink-0 items-center justify-center rounded-full transition-colors ${stock <= 0 ? 'bg-gray-100 dark:bg-gray-800 text-gray-300 dark:text-gray-600 cursor-not-allowed border border-gray-200 dark:border-gray-700' : 'bg-gray-100 dark:bg-gray-800 text-gray-900 dark:text-white hover:bg-[#ff6600] border border-gray-200 dark:border-gray-700 hover:border-[#ff6600] dark:hover:bg-[#ff6600] hover:text-white active:scale-90'}`}
            >
              <ShoppingCart className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </motion.div>
  );
});

export default ProductCard;
