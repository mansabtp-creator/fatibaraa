import { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { ArrowRight, Loader2 } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { supabase, safeSupabaseQuery } from '../lib/supabase';

interface PromoProduct {
  id: string;
  img: string;
  price: string;
}

export default function MobilePromoBanner() {
  const [timeLeft, setTimeLeft] = useState(71700); // ~19h 55m
  const [products, setProducts] = useState<PromoProduct[]>([]);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft((prev) => (prev > 0 ? prev - 1 : 0));
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  useEffect(() => {
    async function fetchProducts() {
      const { data, error } = await safeSupabaseQuery(
        supabase
          .from('products')
          .select('id, price_gnf, image_urls')
          .limit(4)
      );

      if (!error && data) {
        setProducts(data.map((p: any) => ({
          id: p.id,
          img: p.image_urls?.[0] || 'https://picsum.photos/seed/promo/100/100',
          price: p.price_gnf.toLocaleString()
        })));
      } else {
        // Fallback to static data if error
        setProducts([
          { id: '1', img: 'https://picsum.photos/seed/promo1/100/100', price: '59,739' },
          { id: '2', img: 'https://picsum.photos/seed/promo2/100/100', price: '73,905' },
          { id: '3', img: 'https://picsum.photos/seed/promo3/100/100', price: '101,455' },
          { id: '4', img: 'https://picsum.photos/seed/promo4/100/100', price: '151,538' },
        ]);
      }
      setLoading(false);
    }
    fetchProducts();
  }, []);

  const formatTime = (seconds: number) => {
    const h = Math.floor(seconds / 3600);
    const m = Math.floor((seconds % 3600) / 60);
    const s = seconds % 60;
    return { h, m, s };
  };

  const { h, m, s } = formatTime(timeLeft);

  return (
    <div className="md:hidden px-4 mb-2">
      {/* Top Ad Banner */}
      <div className="rounded-2xl overflow-hidden shadow-sm mb-4 bg-gradient-to-r from-[#1E88E5] to-[#00ACC1] relative">
         <img src="https://images.unsplash.com/photo-1607082348824-0a96f2a4b9da?w=500" alt="Promo Background" className="absolute inset-0 w-full h-full object-cover opacity-20 mix-blend-overlay" />
         <div className="relative z-10 p-4 flex flex-col h-full justify-between">
           <div className="text-white text-[12px] font-bold mb-1">Fin de la promo : <span className="font-mono bg-black/20 px-1 rounded">2J 14h</span></div>
           <div className="flex items-end justify-between">
             <div>
               <div className="text-white text-sm font-semibold">JUSQU'À</div>
               <div className="text-yellow-300 text-5xl font-bold italic leading-none drop-shadow-md">-60%</div>
             </div>
             <button onClick={() => navigate('/shop')} className="bg-white dark:bg-gray-900 text-blue-600 rounded-full w-10 h-10 flex items-center justify-center shadow-lg hover:scale-105 transition-transform active:scale-95">
               <ArrowRight className="w-5 h-5" />
             </button>
           </div>
         </div>
      </div>

      <div className="bg-[#1c1c1c] rounded-2xl p-4 text-white relative overflow-hidden shadow-md">
        <div className="relative z-10">
          <div className="flex items-center justify-between mb-3">
             <div className="flex items-center gap-2">
               <h2 className="text-lg font-bold italic tracking-tight flex items-center gap-1.5">
                 Deal du Jour
               </h2>
               <div className="bg-red-500 text-white text-[10px] font-bold px-1.5 py-0.5 rounded leading-none">
                 -80%
               </div>
             </div>
             
             <div className="flex gap-1 items-center bg-white/10 px-2 py-1 rounded-full">
                <span className="font-mono text-xs">{h.toString().padStart(2, '0')}</span>
                <span className="text-gray-400 text-[10px]">:</span>
                <span className="font-mono text-xs">{m.toString().padStart(2, '0')}</span>
                <span className="text-gray-400 text-[10px]">:</span>
                <span className="font-mono text-xs text-red-400">{s.toString().padStart(2, '0')}</span>
             </div>
          </div>

          <div className="flex gap-3 overflow-x-auto pb-1 scrollbar-hide no-scrollbar -mx-1 px-1">
            {loading ? (
              <div className="flex gap-3 w-full">
                {[1, 2, 3].map(i => (
                  <div key={i} className="bg-white/5 rounded-xl p-2 min-w-[110px] aspect-[4/5] animate-pulse" />
                ))}
              </div>
            ) : (
              products.map((item) => (
                <motion.div 
                  key={item.id} 
                  whileTap={{ scale: 0.95 }}
                  onClick={() => navigate(`/product/${item.id}`)}
                  className="bg-[#2a2a2a] rounded-xl overflow-hidden min-w-[120px] flex flex-col shadow-sm cursor-pointer transition-transform relative"
                >
                  <img src={item.img} className="w-full aspect-[4/3] object-cover" referrerPolicy="no-referrer" />
                  <div className="p-2 pb-3">
                    <div className="text-[14px] font-bold text-white leading-tight">GNF {item.price}</div>
                    <div className="text-[10px] text-gray-400 line-through mt-0.5 relative w-fit">
                      {(parseInt(item.price.replace(/,/g, '')) * 1.5).toLocaleString()}
                      <div className="absolute right-[-32px] top-0 bg-red-500/20 text-red-400 text-[8px] font-bold px-1 rounded-sm">
                        -33%
                      </div>
                    </div>
                  </div>
                </motion.div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
