/**
 * ReportModal.tsx
 *
 * A lightweight modal that lets authenticated users flag a product or store
 * for admin review. Inserts into the `content_reports` table.
 *
 * Usage:
 *   <ReportModal
 *     contentType="product"   // or "store"
 *     contentId={product.id}
 *     contentLabel={product.title}
 *     onClose={() => setShowReport(false)}
 *   />
 *
 * The flag icon trigger lives in the parent page; this modal handles only
 * the reason selection, optional details, and submission.
 */
import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Flag, X, Loader2, CheckCircle2 } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { useAppContext } from '../context/AppContext';
import { useToast } from '../context/ToastContext';

// ─── Types ────────────────────────────────────────────────────────────────────

type ContentType = 'product' | 'store';

type ReportReason =
  | 'fake_product'
  | 'wrong_price'
  | 'inappropriate_content'
  | 'spam'
  | 'counterfeit'
  | 'other';

interface ReportModalProps {
  contentType: ContentType;
  contentId: string;
  contentLabel: string;
  onClose: () => void;
}

// ─── Reason labels ────────────────────────────────────────────────────────────

const REASON_OPTIONS: { value: ReportReason; label: string; emoji: string }[] = [
  { value: 'fake_product',           label: 'Produit contrefait / faux',        emoji: '🚫' },
  { value: 'wrong_price',            label: 'Prix incorrect ou trompeur',        emoji: '💸' },
  { value: 'inappropriate_content',  label: 'Contenu inapproprié / offensant',   emoji: '⚠️' },
  { value: 'spam',                   label: 'Spam ou doublon',                   emoji: '🔁' },
  { value: 'counterfeit',            label: 'Marque / logo contrefait',          emoji: '®️' },
  { value: 'other',                  label: 'Autre raison',                      emoji: '📝' },
];

// ─── Component ────────────────────────────────────────────────────────────────

export default function ReportModal({
  contentType,
  contentId,
  contentLabel,
  onClose,
}: ReportModalProps) {
  const { user } = useAppContext();
  const { showToast } = useToast();

  const [reason, setReason] = useState<ReportReason | ''>('');
  const [details, setDetails] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = async () => {
    if (!reason) {
      showToast('Veuillez choisir une raison.', 'warning');
      return;
    }
    if (!user) {
      showToast('Connectez-vous pour signaler du contenu.', 'warning');
      return;
    }

    setSubmitting(true);
    try {
      const { error } = await supabase.from('content_reports').insert([{
        reporter_id:  user.id,
        content_type: contentType,
        content_id:   contentId,
        reason,
        details:      details.trim() || null,
        status:       'pending',
      }]);

      if (error) throw error;

      setSubmitted(true);
    } catch (err: any) {
      showToast('Erreur lors du signalement. Réessayez.', 'error');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div
      className="fixed inset-0 z-[400] flex items-end sm:items-center justify-center p-0 sm:p-4"
      onClick={e => { if (e.target === e.currentTarget) onClose(); }}
    >
      {/* Backdrop */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="absolute inset-0 bg-black/50 backdrop-blur-sm"
        onClick={onClose}
      />

      {/* Sheet */}
      <motion.div
        initial={{ y: '100%', opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        exit={{ y: '100%', opacity: 0 }}
        transition={{ type: 'spring', stiffness: 400, damping: 40 }}
        className="relative w-full sm:max-w-md bg-white dark:bg-gray-900 rounded-t-3xl sm:rounded-3xl shadow-2xl overflow-hidden z-10"
        onClick={e => e.stopPropagation()}
      >
        {/* Handle */}
        <div className="w-10 h-1 bg-gray-200 dark:bg-gray-700 rounded-full mx-auto mt-3 sm:hidden" />

        {/* Header */}
        <div className="flex items-center justify-between px-6 pt-5 pb-4 border-b border-gray-100 dark:border-white/5">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 bg-red-50 dark:bg-red-900/20 rounded-xl flex items-center justify-center">
              <Flag className="w-4 h-4 text-red-500" />
            </div>
            <div>
              <h2 className="text-[14px] font-black text-gray-900 dark:text-white uppercase tracking-tighter">
                Signaler
              </h2>
              <p className="text-[10px] text-gray-400 font-bold truncate max-w-[200px]">{contentLabel}</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-gray-100 dark:bg-gray-800 flex items-center justify-center hover:bg-gray-200 dark:hover:bg-gray-700 transition-colors"
          >
            <X className="w-4 h-4 text-gray-500" />
          </button>
        </div>

        {/* Body */}
        <div className="px-6 py-5">
          <AnimatePresence mode="wait">

            {submitted ? (
              /* Success */
              <motion.div
                key="success"
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                className="flex flex-col items-center text-center py-8 gap-4"
              >
                <motion.div
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ type: 'spring', delay: 0.1, stiffness: 300 }}
                  className="w-16 h-16 bg-green-50 dark:bg-green-900/20 rounded-2xl flex items-center justify-center"
                >
                  <CheckCircle2 className="w-8 h-8 text-green-500" />
                </motion.div>
                <div>
                  <h3 className="text-[16px] font-black text-gray-900 dark:text-white mb-1">Signalement reçu</h3>
                  <p className="text-[12px] text-gray-500 font-medium">
                    Notre équipe de modération examinera ce contenu dans les 24 h. Merci de contribuer à la sécurité de la communauté.
                  </p>
                </div>
                <button
                  onClick={onClose}
                  className="mt-2 bg-gray-900 dark:bg-white text-white dark:text-gray-900 px-8 py-2.5 rounded-xl text-[12px] font-black uppercase tracking-wide"
                >
                  Fermer
                </button>
              </motion.div>
            ) : (
              /* Form */
              <motion.div key="form" className="space-y-4">
                <p className="text-[12px] text-gray-500 font-bold">
                  Pourquoi signalez-vous ce{contentType === 'product' ? ' produit' : 'tte boutique'} ?
                </p>

                {/* Reason grid */}
                <div className="grid grid-cols-1 gap-2">
                  {REASON_OPTIONS.map(opt => (
                    <button
                      key={opt.value}
                      onClick={() => setReason(opt.value)}
                      className={`flex items-center gap-3 px-4 py-3 rounded-xl border-2 text-left transition-all ${
                        reason === opt.value
                          ? 'border-red-400 bg-red-50 dark:bg-red-900/10 text-red-700 dark:text-red-400'
                          : 'border-gray-100 dark:border-white/5 hover:border-gray-300 dark:hover:border-white/10'
                      }`}
                    >
                      <span className="text-[16px]">{opt.emoji}</span>
                      <span className="text-[12px] font-bold text-gray-900 dark:text-white">{opt.label}</span>
                    </button>
                  ))}
                </div>

                {/* Optional details */}
                <div>
                  <label className="text-[10px] font-black text-gray-400 uppercase tracking-wider block mb-1.5">
                    Détails supplémentaires <span className="font-normal normal-case">(optionnel)</span>
                  </label>
                  <textarea
                    value={details}
                    onChange={e => setDetails(e.target.value)}
                    placeholder="Décrivez le problème en quelques mots..."
                    rows={2}
                    maxLength={300}
                    className="w-full px-4 py-2.5 rounded-xl border border-gray-200 dark:border-gray-700 text-[12px] font-medium text-gray-900 dark:text-white bg-white dark:bg-gray-800 placeholder:text-gray-300 focus:outline-none focus:border-red-400 focus:ring-2 focus:ring-red-400/20 resize-none transition-all"
                  />
                </div>

                {/* Submit */}
                <button
                  onClick={handleSubmit}
                  disabled={!reason || submitting}
                  className="w-full flex items-center justify-center gap-2 bg-red-500 text-white py-3 rounded-xl text-[13px] font-black uppercase tracking-wide hover:bg-red-600 disabled:opacity-40 disabled:cursor-not-allowed transition-all"
                >
                  {submitting ? (
                    <Loader2 className="w-4 h-4 animate-spin" />
                  ) : (
                    <><Flag className="w-4 h-4" /> Envoyer le signalement</>
                  )}
                </button>
              </motion.div>
            )}

          </AnimatePresence>
        </div>
      </motion.div>
    </div>
  );
}
