import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Share2, Download, CheckCircle2, ShoppingBag, MapPin, Phone, MessageCircle } from 'lucide-react';
import { APP_NAME } from '../lib/constants';

interface OrderInvoiceModalProps {
  isOpen: boolean;
  onClose: () => void;
  order: {
    id: string;
    created_at: string;
    customer_name: string;
    customer_phone?: string;
    customer_address?: string;
    total_amount: number;
    status: string;
    vendor_name?: string;
    items?: Array<{
      title: string;
      quantity: number;
      price: number;
    }>;
  };
}

export default function OrderInvoiceModal({ isOpen, onClose, order }: OrderInvoiceModalProps) {
  if (!order) return null;

  const whatsappMessage = encodeURIComponent(
    `📄 *REÇU NUMÉRIQUE : ${order.vendor_name || 'Ma Boutique'}*\n` +
    `--------------------------\n` +
    `🔢 Commande: #${order.id?.slice(0, 8) || 'N/A'}\n` +
    `📅 Date: ${order.created_at ? new Date(order.created_at).toLocaleDateString() : 'N/A'}\n` +
    `👤 Client: ${order.customer_name || 'Client'}\n` +
    `--------------------------\n` +
    `💰 *TOTAL: ${(order.total_amount || 0).toLocaleString()} GNF*\n` +
    `✅ Status: ${(order.status || 'pending').toUpperCase()}\n` +
    `--------------------------\n` +
    `Merci pour votre confiance sur ${APP_NAME} !`
  );

  const shareReceipt = () => {
    window.open(`https://wa.me/${order.customer_phone || ''}?text=${whatsappMessage}`, '_blank');
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="absolute inset-0 bg-gray-900/60 backdrop-blur-md"
            onClick={onClose}
          />
          
          <motion.div
            initial={{ scale: 0.9, opacity: 0, y: 20 }}
            animate={{ scale: 1, opacity: 1, y: 0 }}
            exit={{ scale: 0.9, opacity: 0, y: 20 }}
            className="relative w-full max-w-lg bg-white dark:bg-gray-900 rounded-[2.5rem] shadow-2xl overflow-hidden"
          >
            {/* Header / Brand Overlay */}
            <div className="bg-gray-900 p-8 md:p-10 text-brand-inverse relative">
               <div className="absolute top-0 right-0 w-32 h-32 bg-[#ff6600]/10 rounded-full -mr-10 -mt-10 blur-3xl" />
               <div className="flex justify-between items-start relative z-10">
                  <div>
                     <div className="flex items-center gap-2 text-[#ff6600] mb-2">
                        <ShoppingBag className="w-5 h-5 fill-current" />
                        <span className="text-[10px] font-bold tracking-wider">Recu Numérique</span>
                     </div>
                     <h2 className="text-3xl font-bold tracking-tighter">Facture #{order.id.slice(0, 6)}</h2>
                  </div>
                  <button 
                    onClick={onClose}
                    className="p-2 bg-white/10 rounded-full hover:bg-white/20 transition-colors"
                  >
                    <X className="w-5 h-5" />
                  </button>
               </div>
            </div>

            {/* Content Body */}
            <div className="p-8 md:p-10 space-y-8">
               {/* Client Info */}
               <div className="grid grid-cols-2 gap-4">
                  <div>
                     <p className="text-[10px] font-bold uppercase text-brand-text-dim tracking-wider mb-2">Client</p>
                     <p className="font-bold text-gray-900 dark:text-white">{order.customer_name || 'Client'}</p>
                     {order.customer_phone && <p className="text-xs text-brand-text-muted mt-1 flex items-center gap-2"><Phone className="w-3 h-3" /> {order.customer_phone}</p>}
                  </div>
                  <div className="text-right">
                     <p className="text-[10px] font-bold uppercase text-brand-text-dim tracking-wider mb-2">Date</p>
                     <p className="font-bold text-gray-900 dark:text-white">{order.created_at ? new Date(order.created_at).toLocaleDateString() : 'N/A'}</p>
                  </div>
               </div>

               {/* Table Placeholder (or Items if available) */}
               <div className="border-y-2 border-brand-border/30 py-6 space-y-4">
                  <div className="flex justify-between text-[11px] font-bold uppercase text-brand-text-dim tracking-wider px-1">
                     <span>Détails</span>
                     <span>Total</span>
                  </div>
                  
                  {order.items ? order.items.map((item, i) => (
                    <div key={i} className="flex justify-between items-center group">
                       <div className="flex flex-col">
                          <span className="text-sm font-bold text-gray-900 dark:text-white line-clamp-1">{item.title}</span>
                          <span className="text-[11px] text-brand-text-muted">Qté: {item.quantity} × {item.price.toLocaleString()}</span>
                       </div>
                       <span className="text-sm font-bold text-gray-900 dark:text-white">{(item.quantity * item.price).toLocaleString()}</span>
                    </div>
                  )) : (
                    <div className="flex justify-between items-center bg-gray-50/30 p-4 rounded-2xl">
                       <div className="flex items-center gap-3">
                          <CheckCircle2 className="w-5 h-5 text-green-500" />
                          <span className="text-sm font-bold text-gray-900 dark:text-white">Commande Groupée</span>
                       </div>
                       <span className="text-sm font-bold text-gray-900 dark:text-white">{order.total_amount.toLocaleString()} GNF</span>
                    </div>
                  )}
               </div>

               {/* Grand Total */}
               <div className="flex justify-between items-center bg-gray-900 p-6 rounded-[2rem] text-brand-inverse shadow-xl shadow-brand-foreground/20">
                  <span className="text-xs font-bold tracking-wider opacity-70">Total Net</span>
                  <span className="text-2xl font-bold tracking-tight">{order.total_amount.toLocaleString()} GNF</span>
               </div>

               {/* Actions */}
               <div className="flex gap-4">
                  <button 
                    onClick={shareReceipt}
                    className="flex-grow bg-[#ff6600] text-white py-5 rounded-[1.5rem] font-bold tracking-wider text-[11px] flex items-center justify-center gap-3 hover:bg-pink-600 transition-all active:scale-95 shadow-lg shadow-[#ff6600]/20"
                  >
                     <MessageCircle className="w-5 h-5" /> Partager via WhatsApp
                  </button>
                  <button 
                    onClick={() => window.print()}
                    className="bg-gray-50 dark:bg-gray-800 text-gray-900 dark:text-white px-6 rounded-[1.5rem] hover:bg-gray-100 dark:hover:bg-gray-700 transition-all border border-gray-100 dark:border-gray-800"
                    title="Imprimer la facture"
                  >
                     <Download className="w-5 h-5" />
                  </button>
               </div>

               <style dangerouslySetInnerHTML={{ __html: `
                 @media print {
                   body * { visibility: hidden; }
                   .fixed.inset-0, .fixed.inset-0 * { visibility: visible; }
                   .fixed.inset-0 { position: absolute; left: 0; top: 0; width: 100%; height: auto; }
                   button, .share-receipt { display: none !important; }
                   .dark { background: white !important; color: black !important; }
                   .shadow-2xl, .shadow-xl { shadow: none !important; }
                 }
               `}} />
            </div>
            
            {/* Footer Notice */}
            <div className="bg-gray-50 dark:bg-gray-800 p-4 text-center">
               <p className="text-[9px] font-bold tracking-wider text-brand-text-dim">Généré par {APP_NAME} Marketplace • Conakry, Guinée</p>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}
