import React from 'react';
import { motion } from 'motion/react';
import { TrendingUp, Award, Zap, BarChart3, Star, Calendar } from 'lucide-react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar, Cell } from 'recharts';
import { useStore } from '../store/useStore';
import Rating from './Rating';

export default function VendorEliteAnalytics({ metrics }: { metrics: any }) {
  const { isDarkMode } = useStore();

  if (!metrics) return null;

  const data = metrics.peakHours || [];
  const weeklyData = metrics.last7Days || [];
  const rating = metrics.rating || 0;
  const projectedRevenue = metrics.projectedRevenue || 0;
  const topProducts = metrics.topProducts || [];



  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
           <div className="lg:col-span-2 bg-white dark:bg-gray-900 rounded-2xl p-6 md:p-8 border border-gray-100 dark:border-gray-800 dark:border-white/10 shadow-sm relative overflow-hidden">
             <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between mb-8 pb-4 border-b border-gray-100 dark:border-gray-800 dark:border-white/5 gap-4 relative z-10">
                <div>
                   <h3 className="text-xl font-bold text-gray-900 dark:text-white tracking-tight flex items-center gap-2">
                      <Zap className="w-5 h-5 text-[#ff6600]" /> Heures de Pointe
                   </h3>
                   <p className="text-sm font-medium text-gray-500 dark:text-gray-400 mt-1">Activité des clients sur 24h</p>
                </div>
                <div className="flex items-center gap-2 bg-emerald-50 dark:bg-emerald-950 px-3 py-1.5 rounded-full border border-emerald-100 dark:border-emerald-500/20">
                   <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                   <span className="text-[11px] font-bold uppercase tracking-wider text-emerald-700 dark:text-emerald-400">Live Data</span>
                </div>
             </div>
             
             <div className="w-full h-[300px] overflow-hidden">
                {data.length > 0 ? (
                  <ResponsiveContainer width="100%" height="100%" minWidth={0} minHeight={0}>
                    <BarChart data={data} margin={{ top: 20, right: 30, left: 0, bottom: 0 }}>
                      <CartesianGrid strokeDasharray="3 3" vertical={false} stroke={isDarkMode ? 'rgba(255,255,255,0.05)' : '#f1f5f9'} />
                      <XAxis dataKey="hour" axisLine={false} tickLine={false} tick={{ fontSize: 10, fill: isDarkMode ? '#94a3b8' : '#64748b' }} dy={10} />
                      <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 10, fill: isDarkMode ? '#94a3b8' : '#64748b' }} allowDecimals={false} />
                      <Tooltip 
                        cursor={{ fill: isDarkMode ? 'rgba(255,255,255,0.05)' : 'rgba(0,0,0,0.02)' }}
                        contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgba(0,0,0,0.1)', backgroundColor: isDarkMode ? '#1e293b' : '#fff', color: isDarkMode ? '#f8fafc' : '#0f172a' }}
                        formatter={(value: number) => [value, 'Commandes']}
                        labelStyle={{ color: isDarkMode ? '#94a3b8' : '#64748b', marginBottom: '4px' }}
                      />
                      <Bar dataKey="value" radius={[4, 4, 0, 0]}>
                        {data.map((entry: any, index: number) => {
                          const maxVal = Math.max(...data.map((d: any) => d.value));
                          const isPeak = entry.value > 0 && entry.value >= maxVal * 0.8;
                          return (
                            <Cell key={`cell-${index}`} fill={isPeak ? '#ff6600' : (isDarkMode ? '#334155' : '#e2e8f0')} />
                          );
                        })}
                      </Bar>
                    </BarChart>
                  </ResponsiveContainer>
                ) : (
                  <div className="w-full h-full flex items-center justify-center text-gray-400 dark:text-gray-500 font-medium bg-gray-50/50 dark:bg-gray-800/20 rounded-xl border border-gray-200 dark:border-gray-700 dark:border-white/10 border-dashed">
                    Collecte des données...
                  </div>
                )}
             </div>
             
             <div className="absolute -bottom-10 -right-10 opacity-[0.02] pointer-events-none">
                <BarChart3 className="w-64 h-64 text-gray-900 text-gray-900 dark:text-white" />
             </div>
          </div>

          <div className="flex flex-col gap-6">
             <motion.div 
               whileHover={{ y: -2 }}
               className="bg-gray-900 dark:bg-gray-950 p-6 md:p-8 rounded-2xl text-white shadow-lg shadow-gray-900/20 transition-all flex flex-col justify-between relative overflow-hidden"
             >
                {/* Decorative blob */}
                <div className="absolute top-0 right-0 w-32 h-32 bg-[#ff6600]/20 rounded-full blur-2xl -translate-y-1/2 translate-x-1/3" />
                
                <div className="relative z-10">
                   <div className="w-12 h-12 bg-white/10 rounded-xl flex items-center justify-center mb-6 border border-white/10 backdrop-blur-sm">
                      <Star className="w-6 h-6 text-yellow-400" />
                   </div>
                   <h4 className="text-[13px] font-medium text-gray-400 uppercase tracking-wide mb-1">Note Moyenne</h4>
                   <div className="text-4xl font-bold mb-4 tracking-tight">
                     {rating > 0 ? rating.toFixed(1) : '0.0'} 
                     <span className="text-xl font-medium text-gray-500 dark:text-gray-400 ml-1">/ 5.0</span>
                   </div>
                   <Rating rating={rating} size={18} className="mb-6 drop-shadow-sm" />
                   <div className="text-[12px] text-gray-300 font-medium flex items-center gap-1.5">
                      Vous êtes dans le <span className="bg-[#ff6600] text-white font-bold px-2 py-0.5 rounded-md text-[10px] uppercase tracking-wider">TOP 5%</span>
                   </div>
                </div>
                <button className="mt-8 text-[13px] font-semibold text-orange-400 hover:text-orange-300 flex items-center gap-2 group transition-colors relative z-10 w-max">
                   Détails <TrendingUp className="w-4 h-4 group-hover:translate-x-0.5 transition-transform" />
                </button>
             </motion.div>

             <div className="bg-white bg-white dark:bg-gray-900 border border-gray-100 dark:border-gray-800 dark:border-white/10 rounded-2xl p-6 shadow-sm">
                <h4 className="text-[13px] font-bold text-gray-900 dark:text-white mb-4 pb-3 border-b border-gray-100 dark:border-gray-800 dark:border-white/5 flex items-center gap-2">
                    <TrendingUp className="w-4 h-4 text-emerald-500" /> Prévisions Prochain Mois
                 </h4>
                 <div className="space-y-4">
                    <div className="p-4 bg-emerald-50/30 dark:bg-emerald-950/20 rounded-2xl border border-emerald-500/10">
                       <p className="text-[10px] font-bold text-emerald-600 dark:text-emerald-400 uppercase tracking-widest mb-1">Revenu Estimé</p>
                       <p className="text-2xl font-bold text-gray-900 dark:text-white tabular-nums">
                          {Math.round(projectedRevenue).toLocaleString()} <span className="text-xs font-semibold text-gray-500">GNF</span>
                       </p>
                       <div className="mt-3 h-1.5 bg-emerald-200/30 dark:bg-emerald-800/30 rounded-full overflow-hidden">
                          <motion.div 
                            initial={{ width: 0 }}
                            animate={{ width: '65%' }}
                            className="h-full bg-emerald-500"
                          />
                       </div>
                    </div>
                    <p className="text-[11px] font-medium text-gray-500 dark:text-gray-400 leading-relaxed italic">
                       *Basé sur votre croissance actuelle de 15% et les tendances saisonnières à Conakry.
                    </p>
                 </div>
              </div>

              <div className="bg-white dark:bg-gray-900 border border-gray-100 dark:border-gray-800 dark:border-white/10 rounded-2xl p-6 shadow-sm">
                 <h4 className="text-[13px] font-bold text-gray-900 dark:text-white mb-4 pb-3 border-b border-gray-100 dark:border-gray-800 dark:border-white/5">Produits Tops</h4>
                <div className="space-y-1">
                   {topProducts.length > 0 ? topProducts.map((item, i) => (
                     <div key={i} className="flex items-center justify-between p-3 rounded-xl hover:bg-gray-50 dark:bg-gray-800 dark:hover:bg-gray-800 transition-colors group">
                        <div className="flex-1 min-w-0 pr-4">
                           <p className="text-sm font-semibold text-gray-900 dark:text-white mb-0.5 truncate">{item.title}</p>
                           <p className="text-[11px] font-medium text-emerald-600 dark:text-emerald-400">Engagement Haut</p>
                        </div>
                        <div className="text-[12px] font-bold text-gray-700 dark:text-gray-300 bg-gray-100 dark:bg-gray-800 px-2.5 py-1 rounded-lg tabular-nums">{item.views} vues</div>
                     </div>
                   )) : (
                     <div className="text-[13px] font-medium text-gray-500 dark:text-gray-400 italic py-4 text-center">Collecte en cours...</div>
                   )}
                </div>
             </div>

             <div className="bg-white bg-white dark:bg-gray-900 border border-gray-100 dark:border-gray-800 dark:border-white/10 rounded-2xl p-6 shadow-sm">
                <h4 className="text-[13px] font-bold text-gray-900 text-gray-900 dark:text-white mb-4 pb-3 border-b border-gray-100 dark:border-gray-800 dark:border-white/5 flex items-center gap-2">
                   <Calendar className="w-4 h-4 text-gray-500 dark:text-gray-400" /> 7 Derniers Jours
                </h4>
                <div className="h-[200px] w-full min-w-0">
                   <ResponsiveContainer width="100%" height="100%" minWidth={0} minHeight={0}>
                      <AreaChart data={weeklyData}>
                         <defs>
                            <linearGradient id="colorAmount" x1="0" y1="0" x2="0" y2="1">
                               <stop offset="5%" stopColor="#8b5cf6" stopOpacity={0.3}/>
                               <stop offset="95%" stopColor="#8b5cf6" stopOpacity={0}/>
                            </linearGradient>
                         </defs>
                         <CartesianGrid strokeDasharray="3 3" vertical={false} stroke={isDarkMode ? 'rgba(255,255,255,0.05)' : '#f1f5f9'} />
                         <XAxis 
                           dataKey="date" 
                           axisLine={false} 
                           tickLine={false} 
                           fontSize={11} 
                           tick={{ fill: isDarkMode ? '#94a3b8' : '#64748b' }}
                           dy={10}
                           tickFormatter={(val) => {
                              try {
                                 return new Date(val).toLocaleDateString('fr-FR', { weekday: 'short' }).replace('.', '');
                              } catch {
                                 return val;
                              }
                           }}
                         />
                         <YAxis hide />
                         <Tooltip 
                           contentStyle={{ 
                             borderRadius: '12px', 
                             border: isDarkMode ? '1px solid rgba(255,255,255,0.1)' : '1px solid #f1f5f9', 
                             boxShadow: '0 10px 15px -3px rgba(0, 0, 0, 0.1)',
                             fontSize: '12px',
                             backgroundColor: isDarkMode ? '#1e293b' : '#ffffff',
                             color: isDarkMode ? '#f8fafc' : '#0f172a',
                           }}
                           formatter={(value: number) => [`${value.toLocaleString()} GNF`, 'Revenu']}
                         />
                         <Area 
                           type="monotone" 
                           dataKey="sales" 
                           stroke="#8b5cf6" 
                           strokeWidth={3}
                           fillOpacity={1} 
                           fill="url(#colorAmount)" 
                           activeDot={{ r: 6, fill: '#8b5cf6', stroke: isDarkMode ? '#1e293b' : '#fff', strokeWidth: 2 }}
                         />
                      </AreaChart>
                   </ResponsiveContainer>
                </div>
             </div>
          </div>
      </div>
    </div>
  );
}
