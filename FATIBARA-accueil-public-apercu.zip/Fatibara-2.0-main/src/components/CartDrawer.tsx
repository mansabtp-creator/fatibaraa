import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ShoppingBag, X, Trash2, Plus, Minus, ArrowRight, Store, Truck } from 'lucide-react';
import { useCommerceStore } from '../store/useCommerceStore';
import { useStore } from '../store/useStore';
import { useNavigate } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { hapticFeedback } from '../lib/haptics';
import { APP_NAME } from '../lib/constants';
import { calculateProductPrice } from '../utils/pricing';
import { useAppContext } from '../context/AppContext';
import { FREE_DELIVERY_THRESHOLD } from '../utils/delivery';

export default function CartDrawer({ isOpen, onClose }: { isOpen: boolean; onClose: () => void }) {
  const { cart, removeFromCart, updateCartQuantity } = useCommerceStore();
  const { modeEconomie } = useStore();
  const { user } = useAppContext();
  const [products, setProducts] = React.useState<any[]>([]);
  const [loading, setLoading] = React.useState(false);
  const navigate = useNavigate();

  React.useEffect(() => {
    if (isOpen && cart.length > 0) {
      fetchProductDetails();
    }
  }, [isOpen, cart.length]);

  const fetchProductDetails = async () => {
    setLoading(true);
    const productIds = cart.map((item) => item.product_id);
    const { data, error } = await supabase
      .from('products')
      .select('*, stores(store_name, id, location_commune)')
      .in('id', productIds);

    if (!error && data) {
      setProducts(data);
    }
    setLoading(false);
  };

  const cartItemsWithDetails = cart.map((item) => {
    const details = products.find((p) => p.id === item.product_id);
    return { ...item, details };
  });

  // Group by vendor
  const groupedItems: { [storeId: string]: any[] } = {};
  if (!loading) {
    cartItemsWithDetails.forEach((item) => {
      const storeId = item.details?.stores?.id || 'unknown';
      if (!groupedItems[storeId]) groupedItems[storeId] = [];
      groupedItems[storeId].push(item);
    });
  }

  const subtotal = cartItemsWithDetails.reduce((acc, item) => {
    if (!item.details) return acc;
    const priceInfo = calculateProductPrice(item.details, item.quantity, user?.profile_type === 'pro', item.selected_variations);
    return acc + priceInfo.finalPrice * item.quantity;
  }, 0);

  const deliveryProgress = Math.min((subtotal / FREE_DELIVERY_THRESHOLD) * 100, 100);

  const handleCheckout = () => {
    hapticFeedback('reward');
    onClose();
    navigate('/checkout/cart');
  };

  const CartItemSkeleton = () => (
    <div className="flex gap-5 animate-pulse">
      <div className="w-20 h-20 bg-gray-50 dark:bg-gray-800 rounded-2xl shrink-0" />
      <div className="flex-1 space-y-3 py-1">
        <div className="h-4 bg-gray-50 dark:bg-gray-800 rounded-full w-3/4" />
        <div className="h-6 bg-gray-50 dark:bg-gray-800 rounded-full w-1/2" />
        <div className="h-8 bg-gray-50 dark:bg-gray-800 rounded-2xl w-full mt-4" />
      </div>
    </div>
  );

  const containerVariants = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, x: 20 },
    show: { opacity: 1, x: 0 }
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/60 backdrop-blur-md z-[100]"
            aria-hidden="true"
          />
          <motion.div
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ type: 'spring', damping: 25, stiffness: 200, mass: 0.8 }}
            className="fixed top-0 right-0 h-full w-full max-w-md bg-white dark:bg-gray-900 dark:bg-gray-950 shadow-2xl z-[10000] flex flex-col border-l-2 border-brand-border dark:border-white/10"
          >
            <div className="p-8 border-b border-brand-border dark:border-white/5 flex items-center justify-between bg-white dark:bg-gray-900 sticky top-0 z-10">
              <div className="flex items-center gap-5">
                <div className="w-16 h-16 bg-gray-900 dark:bg-brand-primary text-white rounded-[2rem] flex items-center justify-center shadow-2xl relative group overflow-hidden border-2 border-white dark:border-gray-800">
                  <div className="absolute inset-0 bg-brand-primary opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
                  <ShoppingBag className="w-8 h-8 relative z-10" />
                  <AnimatePresence>
                    {cart.length > 0 && (
                      <motion.span 
                        initial={{ scale: 0 }}
                        animate={{ scale: 1 }}
                        className="absolute -top-1 -right-1 w-8 h-8 bg-[#ff6600] text-white border-2 border-white dark:border-gray-900 text-[11px] font-black rounded-full flex items-center justify-center shadow-lg z-20"
                      >
                        {cart.length}
                      </motion.span>
                    )}
                  </AnimatePresence>
                </div>
                <div>
                  <h2 className="text-2xl font-black text-gray-900 dark:text-white uppercase tracking-tighter leading-none mb-1">FatiConcierge</h2>
                  <p className="text-[10px] font-black tracking-[0.2em] text-[#ff6600] uppercase">Votre Panier Privé</p>
                </div>
              </div>
              {/* Close button — min 44×44 px touch target (WCAG 2.5.5) */}
              <button
                onClick={onClose}
                aria-label="Fermer le panier"
                className="min-w-[44px] min-h-[44px] w-12 h-12 flex items-center justify-center bg-gray-50 dark:bg-gray-800 rounded-2xl transition-all text-gray-900 dark:text-white hover:bg-black hover:text-white hover:rotate-90 shadow-sm active:scale-90"
              >
                <X className="w-6 h-6" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto p-6 md:p-8 space-y-10 scrollbar-hide">
              {cart.length > 0 && (
                <div className="p-6 bg-gray-50 dark:bg-white/5 rounded-3xl border border-gray-100 dark:border-white/5 relative overflow-hidden group">
                  <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity">
                    <Truck className="w-12 h-12" />
                  </div>
                  <div className="flex justify-between items-end mb-3">
                    <div>
                      <span className="text-[10px] font-black tracking-[3px] text-[#ff6600] cursor-default uppercase">Livraison Gratuite</span>
                      <p className="text-[12px] font-bold text-gray-900 dark:text-white mt-1">
                        {subtotal >= FREE_DELIVERY_THRESHOLD ? 'Félicitations ! Livraison Offerte' : `${(FREE_DELIVERY_THRESHOLD - subtotal).toLocaleString()} GNF requis`}
                      </p>
                    </div>
                    <span className="text-[14px] font-black text-[#ff6600] tabular-nums">{Math.round(deliveryProgress)}%</span>
                  </div>
                  <div className="h-2.5 bg-white dark:bg-gray-900 rounded-full overflow-hidden border border-gray-100 dark:border-white/5">
                    <motion.div 
                      initial={{ width: 0 }}
                      animate={{ width: `${deliveryProgress}%` }}
                      className="h-full bg-gradient-to-r from-[#ff6600] to-[#e62e00] relative"
                    >
                      <div className="absolute inset-0 bg-[linear-gradient(90deg,transparent_0%,rgba(255,255,255,0.4)_50%,transparent_100%)] animate-[shimmer_1.5s_infinite]" />
                    </motion.div>
                  </div>
                </div>
              )}

              {cart.length === 0 ? (
                <div className="h-full flex flex-col items-center justify-center text-center space-y-8 animate-in fade-in zoom-in duration-500">
                   <div className="w-32 h-32 bg-gray-50 dark:bg-gray-800 dark:bg-gray-900 rounded-[3rem] flex items-center justify-center text-black/50 border border-brand-border dark:border-white/10 shadow-inner relative group">
                      <ShoppingBag className="w-16 h-16 group-hover:scale-110 transition-transform duration-500" />
                      <div className="absolute inset-0 rounded-[3rem] bg-black/5 scale-0 group-hover:scale-125 transition-transform duration-700 opacity-0 group-hover:opacity-100" />
                   </div>
                   <div className="max-w-[280px]">
                      <h3 className="text-2xl font-bold text-gray-900 text-gray-900 dark:text-white mb-4 uppercase tracking-tighter">Votre panier est vide</h3>
                      <p className="text-[12px] font-bold tracking-wider text-brand-text-dim dark:text-gray-400 leading-relaxed">Explorez nos offres exclusives et trouvez votre prochaine pépite {APP_NAME} !</p>
                   </div>
                   <button 
                     onClick={onClose}
                     className="bg-gray-900 dark:bg-black text-brand-inverse px-12 py-5 rounded-full text-[12px] font-bold tracking-wider shadow-2xl shadow-brand-foreground/20 hover:bg-black dark:hover:bg-gray-800 transition-all min-h-[56px] active:scale-95 group"
                   >
                     Commencer le Shopping <ArrowRight className="inline ml-2 w-4 h-4 group-hover:translate-x-1 transition-transform" />
                   </button>
                </div>
              ) : loading ? (
                <div className="space-y-10">
                  {[1, 2, 3].map(i => <CartItemSkeleton key={i} />)}
                </div>
              ) : (
                <motion.div 
                  variants={containerVariants}
                  initial="hidden"
                  animate="show"
                  className="space-y-10"
                >
                  {Object.entries(groupedItems).map(([storeId, items]) => {
                    const storeName = items[0].details?.stores?.store_name || `Boutique ${APP_NAME}`;
                    return (
                      <div key={storeId} className="space-y-4">
                        <div className="flex items-center gap-3 px-2">
                          <div className="w-8 h-8 bg-black/5 dark:bg-white/10 rounded-lg flex items-center justify-center border border-black/10">
                            <Store className="w-4 h-4 text-black dark:text-white" />
                          </div>
                          <h3 className="text-[11px] font-bold tracking-[4px] uppercase text-brand-text-dim dark:text-gray-400">{storeName}</h3>
                        </div>
                        
                        <div className="space-y-4">
                          {items.map((item) => {
                            if (!item.details) return null;
                            return (
                              <motion.div 
                                variants={itemVariants}
                                layout
                                key={`${item.product_id}-${JSON.stringify(item.selected_variations)}`} 
                                className="bg-white dark:bg-gray-900 border border-brand-border dark:border-white/5 rounded-[2rem] p-4 hover:border-black/30 dark:hover:border-white/50 hover:shadow-xl transition-all duration-300 group relative overflow-hidden"
                              >
                                <div className="flex gap-5">
                                  <div className="w-28 h-28 bg-gray-50 dark:bg-gray-800 rounded-[1.5rem] overflow-hidden shrink-0 border-r border-brand-border dark:border-white/5 shadow-sm relative">
                                    <img 
                                      src={item.details?.image_urls?.[0]} 
                                      alt={item.details?.title} 
                                      className={`w-full h-full object-cover transition-transform duration-700 group-hover:scale-110 ${modeEconomie ? 'blur-md grayscale' : ''}`}
                                    />
                                    <div className="absolute inset-0 bg-black/5 group-hover:bg-transparent transition-colors" />
                                    {item.quantity > 1 && (
                                      <div className="absolute -top-1 -right-1 bg-gray-900 dark:bg-black text-brand-inverse text-[11px] font-bold w-8 h-8 flex items-center justify-center rounded-full shadow-lg border border-brand-surface dark:border-gray-900 z-10 animate-in zoom-in slide-in-from-top-2">
                                        {item.quantity}
                                      </div>
                                    )}
                                  </div>
  
                                {/* Item Details */}
                                <div className="flex-1 min-w-0 flex flex-col justify-between">
                                  <div>
                                    <h4 className="text-[13px] font-bold text-gray-900 dark:text-white leading-tight line-clamp-1 truncate">{item.details?.title}</h4>
                                    
                                    {item.selected_variations && Object.keys(item.selected_variations).length > 0 && (
                                      <p className="text-[10px] font-bold text-gray-400 uppercase mt-1">
                                        {Object.entries(item.selected_variations).map(([k, v]) => `${k}: ${v}`).join(' | ')}
                                      </p>
                                    )}

                                    <div className="flex items-baseline gap-1.5 mt-1">
                                      {(() => {
                                        const priceInfo = calculateProductPrice(item.details, item.quantity, user?.profile_type === 'pro', item.selected_variations);
                                        return (
                                          <>
                                            <span className={`text-[18px] font-bold ${priceInfo.discountAmount > 0 ? 'text-[#e62e00]' : 'text-black dark:text-white'} tracking-tighter`}>
                                              {priceInfo.finalPrice.toLocaleString()}
                                            </span>
                                            {priceInfo.discountAmount > 0 && (
                                              <span className="text-[10px] text-gray-400 line-through font-medium">
                                                {priceInfo.basePrice.toLocaleString()}
                                              </span>
                                            )}
                                          </>
                                        );
                                      })()}
                                      <span className="text-[9px] font-bold text-brand-text-dim dark:text-gray-500 tracking-wider leading-none">GNF</span>
                                    </div>
                                  </div>
                                  
                                  <div className="flex items-center justify-between mt-3">
                                    {/* Quantity Controls — 44×44 px touch targets */}
                                    <div className="flex items-center bg-white dark:bg-gray-800 border border-brand-border dark:border-white/10 rounded-xl p-0.5 shadow-sm">
                                      <button 
                                        onClick={() => { hapticFeedback('light'); updateCartQuantity(item.product_id, item.quantity - 1, item.selected_variations, user?.id); }}
                                        aria-label="Diminuer la quantité"
                                        className="min-w-[44px] min-h-[44px] w-9 h-9 flex items-center justify-center hover:bg-gray-50 dark:hover:bg-gray-700 rounded-lg text-gray-900 dark:text-white transition-all active:scale-90"
                                      >
                                        <Minus className="w-3.5 h-3.5" />
                                      </button>
                                      <span className="w-7 text-center text-[12px] font-bold text-gray-900 dark:text-white">{item.quantity}</span>
                                      <button 
                                        onClick={() => { hapticFeedback('light'); updateCartQuantity(item.product_id, item.quantity + 1, item.selected_variations, user?.id); }}
                                        disabled={item.quantity >= (item.details?.stock_quantity ?? 100)}
                                        aria-label="Augmenter la quantité"
                                        className="min-w-[44px] min-h-[44px] w-9 h-9 flex items-center justify-center hover:bg-gray-50 dark:hover:bg-gray-700 rounded-lg text-gray-900 dark:text-white transition-all disabled:opacity-30 disabled:cursor-not-allowed disabled:hover:bg-transparent active:scale-90"
                                      >
                                        <Plus className="w-3.5 h-3.5" />
                                      </button>
                                    </div>
  
                                    <button 
                                      onClick={() => { hapticFeedback('warning'); removeFromCart(item.product_id, item.selected_variations, user?.id); }}
                                      className="p-2 text-brand-text-dim dark:text-gray-500 hover:text-red-500 hover:bg-red-500/10 rounded-xl transition-all"
                                    >
                                      <Trash2 className="w-4.5 h-4.5" />
                                    </button>
                                  </div>
                                </div>
                              </div>
                              </motion.div>
                            );
                          })}
                        </div>
                      </div>
                    );
                  })}
                </motion.div>
            )}
          </div>

            {cart.length > 0 && (
              <div className="p-8 pb-10 bg-white/80 dark:bg-gray-950/80 backdrop-blur-3xl border-t border-gray-100 dark:border-white/5 space-y-6 shadow-[0_-20px_50px_rgba(0,0,0,0.1)]">
                <div className="flex justify-between items-end px-2">
                  <div className="flex flex-col">
                    <span className="text-[10px] font-black tracking-[4px] text-[#ff6600] mb-2 uppercase">Total Estimé</span>
                    <span className="text-5xl font-black tracking-tighter leading-none text-gray-950 dark:text-white tabular-nums">
                      {subtotal.toLocaleString()} 
                      <span className="text-[11px] font-black ml-2 align-top text-gray-400">GNF</span>
                    </span>
                  </div>
                </div>
                <button
                  onClick={handleCheckout}
                  className="w-full bg-[#ff6600] text-white py-7 rounded-[2rem] text-[15px] font-black uppercase tracking-[5px] flex items-center justify-center gap-4 hover:bg-[#e62e00] transition-all duration-500 shadow-2xl shadow-orange-500/30 active:scale-[0.98] group/btn min-h-[72px] relative overflow-hidden"
                >
                  <div className="absolute inset-0 bg-white/20 -translate-x-full group-hover/btn:translate-x-full transition-transform duration-1000 skew-x-12" />
                  <span className="relative z-10">Confirmer la Sélection</span>
                  <ArrowRight className="w-6 h-6 relative z-10 group-hover/btn:translate-x-2 transition-transform" />
                </button>
              </div>
            )}
          </motion.div>

        </>
      )}
    </AnimatePresence>
  );
}
