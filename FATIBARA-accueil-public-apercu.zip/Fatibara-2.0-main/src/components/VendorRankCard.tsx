import React from 'react';
import { motion } from 'motion/react';
import { Award, Target, Trophy, TrendingUp, Star, Zap } from 'lucide-react';

export default function VendorRankCard({ stats }: { stats: any }) {
  const score = stats?.rating || 0;
  const totalSales = stats?.total_orders || 0;
  
  // Calculate Rank Logic
  let rank = "Novice";
  let color = "bg-brand-text-dim";
  let textColor = "text-brand-text-dim";
  let nextRank = "Confirmé";
  let progress = Math.min((totalSales / 5) * 100, 100);

  if (totalSales >= 20 || (totalSales >= 5 && score >= 4.5)) {
    rank = "Élite";
    color = "bg-[#ff6600]";
    textColor = "text-[#ff6600]";
    nextRank = "Légende";
    progress = 100;
  } else if (totalSales >= 5) {
    rank = "Confirmé";
    color = "bg-blue-600";
    textColor = "text-blue-600";
    nextRank = "Élite";
    progress = Math.min(((totalSales - 5) / 15) * 100, 100);
  }

  return (
    <div className="bg-white bg-white dark:bg-gray-900 border border-brand-border/30 dark:border-white/10 rounded-[2.5rem] p-8 shadow-sm relative overflow-hidden group font-sans">
      {/* Background Icon */}
      <div className="absolute top-0 right-0 p-8 opacity-[0.03] group-hover:opacity-[0.05] transition-opacity dark:text-white">
        <Trophy className="w-48 h-48" />
      </div>

      <div className="relative z-10">
        <div className="flex items-center gap-4 mb-8">
           <div className={`w-14 h-14 ${color}/10 rounded-2xl flex items-center justify-center ${textColor}`}>
              <Award className="w-8 h-8" />
           </div>
           <div>
              <h3 className="text-[12px] font-bold tracking-wider text-brand-text-dim dark:text-gray-400 mb-1">Votre Statut Vendeur</h3>
              <div className={`text-2xl font-bold ${textColor} tracking-tight uppercase`}>{rank}</div>
           </div>
        </div>

        <div className="space-y-6">
           <div className="flex justify-between items-end">
              <div>
                 <p className="text-[10px] font-bold text-brand-text-dim dark:text-gray-500 dark:text-gray-400 tracking-wider mb-2 opacity-60">Objectif: {nextRank}</p>
                 <p className="text-[16px] font-bold text-gray-900 text-gray-900 dark:text-white tracking-tighter uppercase">Plus que {Math.max(20 - totalSales, 0)} ventes</p>
              </div>
              <span className="text-[14px] font-bold text-gray-900 text-gray-900 dark:text-white tracking-tighter">{Math.round(progress)}%</span>
           </div>

           <div className="h-3.5 w-full bg-gray-50 bg-gray-50 dark:bg-gray-800 rounded-full overflow-hidden border border-brand-border/20 dark:border-white/5 shadow-inner">
              <motion.div 
                initial={{ width: 0 }}
                animate={{ width: `${progress}%` }}
                transition={{ duration: 1.5, ease: "easeOut" }}
                className={`h-full ${color} shadow-sm relative`}
              >
                <div className="absolute inset-0 bg-white/20 animate-pulse" />
              </motion.div>
           </div>

           <div className="grid grid-cols-2 gap-4 mt-8">
              <div className="bg-gray-50 bg-gray-50 dark:bg-gray-800/50 p-4 rounded-2xl border border-brand-border/30 dark:border-white/10">
                 <div className="flex items-center gap-2 mb-2 text-[#ff6600] dark:text-orange-400">
                    <Star className="w-4 h-4 fill-current" />
                    <span className="text-[10px] font-bold tracking-wider">Missions</span>
                 </div>
                 <p className="text-[11px] font-bold text-gray-900 text-gray-900 dark:text-white uppercase tracking-tight leading-relaxed">Livrez 3 commandes pour un bonus de visibilité.</p>
              </div>
              <div className="bg-gray-50 bg-gray-50 dark:bg-gray-800/50 p-4 rounded-2xl border border-brand-border/30 dark:border-white/10">
                 <div className="flex items-center gap-2 mb-2 text-amber-600 dark:text-amber-400">
                    <Zap className="w-4 h-4 fill-current" />
                    <span className="text-[10px] font-bold tracking-wider">Privilège</span>
                 </div>
                 <p className="text-[11px] font-bold text-gray-900 text-gray-900 dark:text-white uppercase tracking-tight leading-relaxed">Accès prioritaire au support WhatsApp PRO.</p>
              </div>
           </div>
        </div>

        <button className="w-full mt-10 bg-gray-900 dark:bg-[#ff6600] text-brand-inverse py-5 rounded-2xl text-[11px] font-bold tracking-wider hover:bg-[#e62e00] transition-all shadow-xl shadow-brand-foreground/20 active:scale-95 flex items-center justify-center gap-2">
           Voir tous les badges <TrendingUp className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
}
