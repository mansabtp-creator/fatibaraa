import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Image as ImageIcon, Layout, Palette, Save, Upload, X, Check, Eye, Store } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { useToast } from '../context/ToastContext';
import { hapticFeedback } from '../lib/haptics';

interface Props {
  store: any;
  onUpdate: (data: any) => void;
}

export default function VendorAppearanceEditor({ store, onUpdate }: Props) {
  const [settings, setSettings] = useState({
    theme_color: store.theme_color || '#ff6600',
    banner_url: store.banner_url || '',
    store_motto: store.store_motto || '',
    layout_style: store.layout_style || 'grid' // grid, list, masonry
  });
  const [isSaving, setIsSaving] = useState(false);
  const [uploading, setUploading] = useState<string | null>(null);
  const { showToast } = useToast();

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>, field: string) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setUploading(field);
    try {
      const fileExt = file.name.split('.').pop();
      const fileName = `${store.id}_${field}_${Date.now()}.${fileExt}`;
      const filePath = `store-appearance/${fileName}`;

      const { error: uploadError } = await supabase.storage
        .from('product-images')
        .upload(filePath, file);

      if (uploadError) throw uploadError;

      const { data: { publicUrl } } = supabase.storage
        .from('product-images')
        .getPublicUrl(filePath);

      setSettings(prev => ({ ...prev, [field === 'banner' ? 'banner_url' : 'avatar_url']: publicUrl }));
      showToast('Image téléchargée !', 'success');
    } catch (err: any) {
      showToast(err.message, 'error');
    } finally {
      setUploading(null);
    }
  };

  const handleSave = async () => {
    setIsSaving(true);
    try {
      const { error } = await supabase
        .from('stores')
        .update(settings)
        .eq('id', store.id);

      if (error) throw error;
      onUpdate(settings);
      showToast('Apparence mise à jour !', 'success');
      hapticFeedback('success');
    } catch (err: any) {
      showToast(err.message, 'error');
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="space-y-8 pb-24">
      <div className="bg-white dark:bg-gray-900 rounded-[2.5rem] border border-gray-100 dark:border-gray-800 p-8 md:p-10 shadow-sm relative overflow-hidden">
        <div className="relative z-10">
          <h2 className="text-2xl font-bold text-gray-900 dark:text-white tracking-tight mb-2">Design de votre Boutique</h2>
          <p className="text-[13px] font-medium text-gray-500 uppercase tracking-wider">Personnalisez l'expérience client dans votre magasin virtuel</p>
        </div>
        <div className="absolute top-0 right-0 w-64 h-64 bg-[#ff6600]/5 rounded-full blur-3xl -mr-32 -mt-32" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Editor Controls */}
        <div className="space-y-6">
          <section className="bg-white dark:bg-gray-900 rounded-3xl border border-gray-100 dark:border-gray-800 p-6 shadow-sm">
            <h3 className="text-sm font-bold text-gray-900 dark:text-white uppercase tracking-widest mb-6 flex items-center gap-2">
               <Palette className="w-4 h-4 text-[#ff6600]" /> Identité Visuelle
            </h3>
            
            <div className="space-y-6">
               <div>
                  <label className="text-[11px] font-bold text-gray-500 uppercase tracking-widest mb-2 block">Couleur de la marque</label>
                  <div className="flex flex-wrap gap-3">
                     {['#ff6600', '#000000', '#2563eb', '#10b981', '#8b5cf6', '#ef4444'].map(color => (
                        <button
                          key={color}
                          onClick={() => setSettings(prev => ({ ...prev, theme_color: color }))}
                          className={`w-10 h-10 rounded-full border-4 transition-all ${settings.theme_color === color ? 'border-gray-900 dark:border-white scale-110' : 'border-transparent'}`}
                          style={{ backgroundColor: color }}
                        />
                     ))}
                     <input 
                       type="color" 
                       value={settings.theme_color} 
                       onChange={(e) => setSettings(prev => ({ ...prev, theme_color: e.target.value }))}
                       className="w-10 h-10 rounded-full border-none cursor-pointer overflow-hidden p-0"
                     />
                  </div>
               </div>

               <div>
                  <label className="text-[11px] font-bold text-gray-500 uppercase tracking-widest mb-2 block">Devise / Slogan de la boutique</label>
                  <input 
                    type="text"
                    value={settings.store_motto}
                    onChange={(e) => setSettings(prev => ({ ...prev, store_motto: e.target.value }))}
                    placeholder="Ex: La qualité au meilleur prix"
                    className="w-full bg-gray-50 dark:bg-gray-800 border border-gray-100 dark:border-gray-800 rounded-xl p-4 text-sm font-semibold outline-none focus:ring-2 focus:ring-[#ff6600] transition-all"
                  />
               </div>
            </div>
          </section>

          <section className="bg-white dark:bg-gray-900 rounded-3xl border border-gray-100 dark:border-gray-800 p-6 shadow-sm">
            <h3 className="text-sm font-bold text-gray-900 dark:text-white uppercase tracking-widest mb-6 flex items-center gap-2">
               <ImageIcon className="w-4 h-4 text-[#ff6600]" /> Bannière Hero
            </h3>
            
            <div className="space-y-4">
               {settings.banner_url ? (
                 <div className="relative aspect-[3/1] rounded-2xl overflow-hidden border border-gray-100 dark:border-gray-800 group">
                    <img src={settings.banner_url} className="w-full h-full object-cover" alt="Bannière" />
                    <button 
                      onClick={() => setSettings(prev => ({ ...prev, banner_url: '' }))}
                      className="absolute top-2 right-2 p-2 bg-red-500 text-white rounded-lg opacity-0 group-hover:opacity-100 transition-opacity"
                    >
                      <X className="w-4 h-4" />
                    </button>
                 </div>
               ) : (
                 <label className="aspect-[3/1] rounded-2xl border-2 border-dashed border-gray-100 dark:border-gray-800 flex flex-col items-center justify-center gap-2 cursor-pointer hover:bg-gray-50 dark:hover:bg-gray-800 transition-all">
                    <Upload className="w-6 h-6 text-gray-400" />
                    <span className="text-[10px] font-bold text-gray-500 uppercase tracking-widest">Choisir une bannière</span>
                    <input type="file" className="hidden" accept="image/*" onChange={(e) => handleFileUpload(e, 'banner')} />
                 </label>
               )}
               <p className="text-[10px] font-medium text-gray-400 italic">Format recommandé: 1200x400px (3:1)</p>
            </div>
          </section>

          <section className="bg-white dark:bg-gray-900 rounded-3xl border border-gray-100 dark:border-gray-800 p-6 shadow-sm">
            <h3 className="text-sm font-bold text-gray-900 dark:text-white uppercase tracking-widest mb-6 flex items-center gap-2">
               <Layout className="w-4 h-4 text-[#ff6600]" /> Mise en Page
            </h3>
            
            <div className="grid grid-cols-3 gap-3">
               {['grid', 'list', 'masonry'].map(style => (
                  <button 
                    key={style}
                    onClick={() => setSettings(prev => ({ ...prev, layout_style: style }))}
                    className={`p-4 rounded-2xl border-2 font-bold text-[10px] uppercase tracking-widest transition-all ${settings.layout_style === style ? 'border-[#ff6600] bg-[#ff6600]/5 text-[#ff6600]' : 'border-gray-100 dark:border-gray-800 text-gray-400 grayscale'}`}
                  >
                     <div className="aspect-square bg-gray-100 dark:bg-gray-800 rounded-lg mb-2 mb-2 flex items-center justify-center">
                        {style === 'grid' ? <div className="grid grid-cols-2 gap-1"><div className="w-2 h-2 bg-gray-300 rounded-sm"/><div className="w-2 h-2 bg-gray-300 rounded-sm"/><div className="w-2 h-2 bg-gray-300 rounded-sm"/><div className="w-2 h-2 bg-gray-300 rounded-sm"/></div> : 
                         style === 'list' ? <div className="space-y-1"><div className="w-6 h-1.5 bg-gray-300 rounded-sm"/><div className="w-6 h-1.5 bg-gray-300 rounded-sm"/><div className="w-6 h-1.5 bg-gray-300 rounded-sm"/></div> :
                        <div className="flex gap-1 items-start"><div className="w-2.5 h-6 bg-gray-300 rounded-sm"/><div className="w-2.5 h-4 bg-gray-300 rounded-sm"/></div>}
                     </div>
                     {style}
                  </button>
               ))}
            </div>
          </section>

          <button 
            onClick={handleSave}
            disabled={isSaving}
            className="w-full bg-black dark:bg-[#ff6600] text-white py-5 rounded-2xl font-black uppercase tracking-widest shadow-xl shadow-brand-foreground/20 hover:scale-[1.02] active:scale-[0.98] transition-all disabled:opacity-50 flex items-center justify-center gap-3"
          >
            {isSaving ? <Check className="w-5 h-5 animate-pulse" /> : <Save className="w-5 h-5" />}
            Enregistrer les Modifications
          </button>
        </div>

        {/* Live Preview */}
        <div className="lg:sticky lg:top-8 h-fit">
          <div className="bg-gray-100 dark:bg-gray-800 rounded-[2.5rem] p-4 p-4 border border-gray-200 dark:border-gray-700 shadow-inner">
             <div className="bg-white dark:bg-gray-900 rounded-[2rem] overflow-hidden shadow-2xl border border-gray-100 dark:border-gray-800 min-h-[600px] flex flex-col">
                {/* Simulated Public Store Header */}
                <div className="h-40 bg-gray-50 dark:bg-gray-800 relative">
                   {settings.banner_url ? (
                     <img src={settings.banner_url} className="w-full h-full object-cover" alt="" />
                   ) : (
                     <div className="w-full h-full bg-gradient-to-br from-[#ff6600]/10 to-orange-50 dark:to-orange-950" />
                   )}
                   <div className="absolute -bottom-10 left-8 flex items-end gap-5">
                      <div className="w-24 h-24 bg-white dark:bg-gray-900 rounded-[2rem] p-1 shadow-lg border border-gray-100 dark:border-gray-800">
                         {store.avatar_url ? (
                           <img src={store.avatar_url} className="w-full h-full object-cover rounded-[1.75rem]" alt="" />
                         ) : (
                            <div className="w-full h-full bg-gray-50 dark:bg-gray-800 rounded-[1.75rem] flex items-center justify-center">
                               <Store className="w-10 h-10 text-gray-300" />
                            </div>
                         )}
                      </div>
                      <div className="pb-2">
                         <h4 className="text-xl font-bold dark:text-white" style={{ color: settings.theme_color }}>{store.store_name}</h4>
                         <p className="text-[10px] font-bold text-gray-500 uppercase tracking-widest">{settings.store_motto || 'Vision de marque'}</p>
                      </div>
                   </div>
                </div>

                <div className="mt-16 px-8 flex-1 space-y-6">
                   <div className="flex items-center justify-between">
                      <div className="h-6 w-32 bg-gray-50 dark:bg-gray-800 rounded-full" />
                      <div className="flex gap-2">
                         <div className="w-8 h-8 rounded-lg bg-gray-50 dark:bg-gray-800" />
                         <div className="w-8 h-8 rounded-lg bg-gray-50 dark:bg-gray-800" />
                      </div>
                   </div>

                   <div className={settings.layout_style === 'grid' ? "grid grid-cols-2 gap-4" : settings.layout_style === 'list' ? "space-y-4" : "columns-2 gap-4 space-y-4"}>
                      {[1, 2, 3, 4].map(i => (
                        <div key={i} className="bg-gray-50 dark:bg-gray-800 rounded-2xl aspect-[4/5] p-3 flex flex-col justify-end">
                           <div className="h-3 w-3/4 bg-gray-200 dark:bg-gray-700 rounded-full mb-2" />
                           <div className="h-4 w-1/2 bg-gray-300 dark:bg-gray-600 rounded-full" />
                        </div>
                      ))}
                   </div>
                </div>

                <div className="p-4 flex items-center justify-center border-t border-gray-50 dark:border-gray-800">
                   <span className="text-[10px] font-bold text-gray-400 uppercase tracking-widest flex items-center gap-2">
                      Aperçu de la page publique <Eye className="w-3 h-3" />
                   </span>
                </div>
             </div>
          </div>
        </div>
      </div>
    </div>
  );
}
