import React, { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { History, User, Package, Clock } from 'lucide-react';

export function AuditLogView({ storeId }: { storeId: string }) {
  const [logs, setLogs] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchLogs();
  }, [storeId]);

  const fetchLogs = async () => {
    try {
      const { data, error } = await supabase
        .from('audit_logs')
        .select('*')
        .eq('store_id', storeId)
        .order('created_at', { ascending: false })
        .limit(20);

      if (error) throw error;
      setLogs(data);
    } catch (error) {
      console.error('Error fetching audit logs:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-white dark:bg-[#1A1D21] rounded-[2.5rem] border border-gray-100 dark:border-white/5 overflow-hidden shadow-sm">
      <div className="px-8 py-6 border-b border-gray-100 dark:border-white/5 bg-gray-50/50 dark:bg-white/5 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-[#ff6600]/10 rounded-xl flex items-center justify-center">
            <History className="w-5 h-5 text-[#ff6600]" />
          </div>
          <div>
            <h3 className="text-sm font-black text-gray-900 dark:text-white tracking-tight uppercase italic decoration-[#ff6600] decoration-2 underline-offset-4">Journal de Sécurité</h3>
            <p className="text-[10px] font-bold text-gray-400 tracking-widest uppercase mt-0.5">Flux d'activité logistique en temps réel</p>
          </div>
        </div>
        <button 
          onClick={fetchLogs} 
          className="px-4 py-2 bg-white dark:bg-white/5 border border-gray-200 dark:border-white/10 rounded-xl text-[10px] font-black uppercase tracking-widest text-gray-500 hover:text-[#ff6600] transition-colors"
        >
          Actualiser
        </button>
      </div>

      <div className="overflow-x-auto custom-scrollbar">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="bg-gray-50/20 dark:bg-white/5">
              <th className="px-8 py-5 text-[10px] font-black uppercase tracking-[0.2em] text-gray-400 border-b border-gray-100 dark:border-white/5">Horodatage</th>
              <th className="px-8 py-5 text-[10px] font-black uppercase tracking-[0.2em] text-gray-400 border-b border-gray-100 dark:border-white/5">Agent</th>
              <th className="px-8 py-5 text-[10px] font-black uppercase tracking-[0.2em] text-gray-400 border-b border-gray-100 dark:border-white/5">Directive</th>
              <th className="px-8 py-5 text-[10px] font-black uppercase tracking-[0.2em] text-gray-400 border-b border-gray-100 dark:border-white/5">Modifications</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-50 dark:divide-white/5">
            {logs.map((log) => (
              <tr key={log.id} className="hover:bg-gray-50 dark:hover:bg-white/5 transition-colors group">
                <td className="px-8 py-5 text-[11px] font-bold text-gray-500 tabular-nums lowercase italic">
                   {new Date(log.created_at).toLocaleString('fr-FR', { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' })}
                </td>
                <td className="px-8 py-5">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 bg-gray-100 dark:bg-white/10 rounded-lg flex items-center justify-center shrink-0 border border-gray-200 dark:border-white/5 group-hover:border-[#ff6600]/30 transition-colors">
                      <User className="w-4 h-4 text-gray-400 group-hover:text-[#ff6600]" />
                    </div>
                    <span className="text-[11px] font-black text-gray-900 dark:text-white uppercase tracking-tight">
                      #{log.user_id ? log.user_id.substring(0, 8) : 'SYSTEM'}
                    </span>
                  </div>
                </td>
                <td className="px-8 py-5">
                  <div className="flex items-center gap-2">
                    {(() => {
                      const act = String(log.action || log.new_data?.action || 'ACTION');
                      const actLower = act.toLowerCase();
                      return (
                        <span className={`text-[9px] font-black px-3 py-1 rounded-full tracking-[0.1em] uppercase border ${
                          actLower.includes('update') ? 'bg-blue-500/10 border-blue-500/20 text-blue-500' : 
                          actLower.includes('delete') ? 'bg-red-500/10 border-red-500/20 text-red-500' : 
                          'bg-emerald-500/10 border-emerald-500/20 text-emerald-500'
                        }`}>
                          {act}
                        </span>
                      );
                    })()}
                  </div>
                </td>
                <td className="px-8 py-5">
                  <div className="text-[11px] font-bold text-gray-900 dark:text-gray-300">
                    {log.entity_type === 'product' && (
                      <div className="flex items-center gap-2">
                        <Package className="w-3.5 h-3.5 text-gray-400" /> 
                        <span className="truncate max-w-[200px]">{log.new_data?.title}</span>
                        {(log.new_data?.price_gnf !== log.old_data?.price_gnf || log.new_data?.stock_quantity !== log.old_data?.stock_quantity) && (
                          <div className="flex gap-2">
                            {log.new_data?.price_gnf !== log.old_data?.price_gnf && (
                              <span className="text-[#ff6600] bg-[#ff6600]/5 px-2 py-0.5 rounded-md border border-[#ff6600]/10 tracking-tight">
                                {log.old_data?.price_gnf?.toLocaleString()} → {log.new_data?.price_gnf?.toLocaleString()}
                              </span>
                            )}
                          </div>
                        )}
                      </div>
                    )}
                    {log.entity_type !== 'product' && (
                      <span className="opacity-50 italic">Données structurelles modifiées</span>
                    )}
                  </div>
                </td>
              </tr>
            ))}
            {logs.length === 0 && !loading && (
              <tr>
                <td colSpan={4} className="px-8 py-20 text-center">
                  <div className="flex flex-col items-center opacity-20">
                    <Clock className="w-12 h-12 mb-4" />
                    <p className="text-xs font-black uppercase tracking-[0.3em]">Aucune activité détectée</p>
                  </div>
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
