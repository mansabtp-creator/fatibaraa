import { 
  ShoppingCart, User, Menu, X, ChevronDown, Globe, Sun, Moon, Bell, 
  Store, ArrowRight, Plus, ShieldCheck, Zap, Star,
  Download, LayoutDashboard, ShieldAlert, LogOut, Layers
} from 'lucide-react';
import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { useAppContext } from '../context/AppContext';
import { useStore } from '../store/useStore';
import { useCommerceStore } from '../store/useCommerceStore';
import AuthModal from './AuthModal';
import { showInstallModal } from './PWAInstallModal';
import CartDrawer from './CartDrawer';
import { useNotifications, formatTimeAgo } from '../hooks/useNotifications';
import AISearchBar from './SearchBar';
import { supabase } from '../lib/supabase';
import { APP_NAME, CURRENCY, PRODUCT_CATEGORIES } from '../lib/constants';

export default function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const { 
    isOffline, profileType, proMode, setProMode, currency, setCurrency, 
    walletBalance, user, loyaltyPoints, unreadMessagesCount, 
    isChatOpen, setIsChatOpen,
    activeRole, allowedRoles, switchRole
  } = useAppContext();
  const { modeEconomie, setModeEconomie, userProfile, selectedRegion, setSelectedRegion, isDarkMode, setIsDarkMode } = useStore();
  const { cartPulse, setCartPulse, wishlist, cart } = useCommerceStore();
  const [showAuth, setShowAuth] = useState(false);
  const [showMegaMenu, setShowMegaMenu] = useState(false);
  const [showNotifications, setShowNotifications] = useState(false);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const navigate = useNavigate();
  const location = useLocation();
  const [isLogoutModalOpen, setIsLogoutModalOpen] = useState(false);
  const [showUserDropdown, setShowUserDropdown] = useState(false);
  const [canInstall, setCanInstall] = useState(false);
  const [isInstalled, setIsInstalled] = useState(false);
  const [logoError, setLogoError] = useState(false);
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);

  useEffect(() => {
    if (
      window.matchMedia('(display-mode: standalone)').matches ||
      (navigator as any).standalone === true
    ) {
      setIsInstalled(true);
      return;
    }

    const handleBeforeInstallPrompt = (e: any) => {
      e.preventDefault();
      setDeferredPrompt(e);
      setCanInstall(true);
    };

    const handleAppInstalled = () => {
      setIsInstalled(true);
      setDeferredPrompt(null);
      setCanInstall(false);
    };

    window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
    window.addEventListener('appinstalled', handleAppInstalled);

    return () => {
      window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
      window.removeEventListener('appinstalled', handleAppInstalled);
    };
  }, []);

  const handleInstallClick = async () => {
    if (deferredPrompt) {
      try {
        await deferredPrompt.prompt();
        const { outcome } = await deferredPrompt.userChoice;
        if (outcome === 'accepted') {
          setDeferredPrompt(null);
          setCanInstall(false);
        }
      } catch (err) {
        console.error('PWA: Error during prompt:', err);
      }
    } else {
      showInstallModal();
    }
  };

  const handleLoginClick = () => {
    navigate('/login');
  };

  const handleLogout = async () => {
    try {
      const { error } = await supabase.auth.signOut();
      if (error) throw error;
      navigate('/');
    } catch (error) {
      console.error('Error logging out:', error);
    }
  };

  const { notifications, unreadCount, markAllAsRead, markAsRead } = useNotifications();

  const isActive = (path: string) => location.pathname === path || (path !== '/' && location.pathname.startsWith(path));

  useEffect(() => {
    if (isDarkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [isDarkMode]);

  useEffect(() => {
    if (isMenuOpen || showNotifications || showMegaMenu) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    return () => { document.body.style.overflow = ''; };
  }, [isMenuOpen, showNotifications, showMegaMenu]);

  useEffect(() => {
    if (cartPulse) {
      const timer = setTimeout(() => setCartPulse(false), 800);
      return () => clearTimeout(timer);
    }
  }, [cartPulse]);

  useEffect(() => {
    let ticking = false;
    const handleScroll = () => {
      if (!ticking) {
        requestAnimationFrame(() => {
          setScrolled(window.scrollY > 20);
          ticking = false;
        });
        ticking = true;
      }
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const toggleCurrency = () => {
    if (currency === 'GNF') setCurrency('EUR');
    else if (currency === 'EUR') setCurrency('USD');
    else setCurrency('GNF');
  };

  const avatarUrl = userProfile?.avatar_url 
    ? (modeEconomie ? `${userProfile.avatar_url}?blur=2&q=50` : userProfile.avatar_url)
    : null;

  const isVendor = userProfile?.profile_type === 'vendor';
  const isAdmin = !!userProfile?.is_admin;

  return (
    <>
      <header 
        className={`sticky top-0 z-[100] flex flex-col transition-all duration-500 ${scrolled ? 'bg-white/80 dark:bg-gray-950/80 backdrop-blur-xl shadow-lg border-b border-gray-200 dark:border-white/5' : 'bg-white dark:bg-gray-900 border-b border-gray-200 dark:border-gray-800'}`}
      >
        {/* Mobile App Banner */}
        <div className="lg:hidden w-full bg-black text-white px-4 py-2 flex items-center justify-between">
           <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded bg-brand-primary flex items-center justify-center text-[10px] font-bold text-white">{APP_NAME.substring(0, 2)}</div>
              <div className="flex flex-col">
                  <span className="text-[12px] font-bold">Appli {APP_NAME}.</span>
                  <span className="text-[10px] text-[#ff6600] font-medium">Coupons exclusifs de 50 000 {CURRENCY}</span>
              </div>
           </div>
           <button onClick={handleInstallClick} className="bg-[#ff6600] text-white px-4 py-1.5 rounded-full text-[12px] font-bold uppercase tracking-wide">Ouvrir</button>
        </div>

        {/* Mobile Top Row */}
        <div className="lg:hidden w-full px-4 pt-3 pb-2 flex justify-between items-center relative z-50">
          <div className="flex items-center gap-3">
             <button 
               onClick={() => setIsMenuOpen(!isMenuOpen)}
               className={`p-1 flex items-center justify-center text-gray-700 dark:text-gray-200 transition-all active:scale-95`}
               aria-label="Menu"
             >
               {isMenuOpen ? <X className="h-7 w-7" /> : <Menu className="h-7 w-7" />}
             </button>
             <div className="w-[20px] h-[14px] overflow-hidden rounded-[2px] shadow-sm ml-1">
                <img src="https://flagcdn.com/gn.svg" alt="GN" className="w-full h-full object-cover" />
             </div>
          </div>
          
          <Link to="/" className="flex items-center mx-auto absolute left-1/2 -translate-x-1/2">
            {logoError ? (
              <span className="text-lg font-black tracking-tight text-gray-900 dark:text-white flex items-center gap-1.5">
                <span className="w-7 h-7 rounded-lg bg-[#ff6600] flex items-center justify-center text-white text-xs font-black shadow-sm">F</span>
                <span className="text-gray-900 dark:text-white font-extrabold">{APP_NAME}</span>
              </span>
            ) : (
              <img 
                src="https://miizhdzuxidilrzwdivk.supabase.co/storage/v1/object/public/assets/fatibara_logo-removebg-preview.png" 
                alt={APP_NAME} 
                className="h-8 w-auto object-contain dark:brightness-0 dark:invert max-w-[140px]"
                loading="eager"
                onError={() => setLogoError(true)}
              />
            )}
          </Link>

          <div className="flex items-center gap-4">
            <button 
              onClick={() => user ? navigate('/dashboard') : navigate('/login')}
              className="text-gray-700 dark:text-gray-200 active:scale-90 transition-transform"
            >
              <User className="w-6 h-6 stroke-[1.5]" />
            </button>
             <button 
              onClick={() => setIsCartOpen(true)}
              className="relative text-gray-700 dark:text-gray-200 active:scale-90 transition-transform"
            >
              <ShoppingCart className="w-6 h-6 stroke-[1.5]" />
              {cart?.length > 0 && (
                <div className="absolute -top-1.5 -right-1.5 min-w-[18px] h-[18px] px-1 bg-[#e62e00] text-white text-[10px] font-bold rounded-full flex items-center justify-center border-2 border-white dark:border-gray-900">
                  {cart.length > 9 ? '9+' : cart.length}
                </div>
              )}
            </button>
          </div>
        </div>

        {/* Mobile Search */}
        <div className="lg:hidden w-full px-4 pb-3 relative z-40">
          <AISearchBar className="lg:mx-0" placeholder="Rechercher des articles..." />
        </div>

        {/* Notifications Panel */}
        <AnimatePresence>
          {showNotifications && (
            <>
              <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                onClick={() => setShowNotifications(false)}
                className="fixed inset-0 z-[90] lg:hidden bg-black/20 backdrop-blur-sm"
              />
                <motion.div
                  initial={{ opacity: 0, y: -20, scale: 0.95 }}
                  animate={{ opacity: 1, y: 0, scale: 1 }}
                  exit={{ opacity: 0, y: -20, scale: 0.95 }}
                  transition={{ duration: 0.2 }}
                  className="absolute top-16 right-4 left-4 lg:left-auto lg:top-20 lg:right-32 w-auto lg:w-[400px] bg-white dark:bg-gray-900 border border-brand-border/40 dark:border-white/10 rounded-[2rem] shadow-2xl z-[110] overflow-hidden flex flex-col max-h-[80vh] md:max-h-[600px]"
                >
                  <div className="p-5 border-b border-brand-border/30 dark:border-white/5 flex items-center justify-between bg-gray-50 dark:bg-gray-800 flex-shrink-0">
                    <h3 className="text-[15px] font-bold text-gray-900 dark:text-white flex items-center gap-2">
                      <Bell className="w-4 h-4 text-black" /> Notifications
                    </h3>
                    <div className="flex items-center gap-3">
                      {unreadCount > 0 && (
                        <span className="text-[10px] font-bold tracking-wider text-black bg-black/10 px-2 py-1 rounded-full">
                          {unreadCount} Nouvelle(s)
                        </span>
                      )}
                      <button onClick={() => setShowNotifications(false)} className="lg:hidden text-gray-900 dark:text-white p-1 bg-white dark:bg-gray-800 rounded-full border border-brand-border/50 dark:border-white/10 min-h-[44px] min-w-[44px] flex items-center justify-center">
                        <X className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                  <div className="overflow-y-auto flex-1 dark:bg-gray-900">
                    {notifications.length === 0 ? (
                      <div className="p-8 text-center">
                        <Bell className="w-10 h-10 text-brand-border dark:text-gray-700 mx-auto mb-3" />
                        <p className="text-sm font-medium text-brand-text-muted dark:text-gray-400">Tout est calme ici pour l'instant.</p>
                        <p className="text-xs text-gray-400 dark:text-gray-600 mt-1">Vos alertes commandes et promos apparaîtront ici.</p>
                      </div>
                    ) : (
                      <div className="divide-y divide-brand-border/30 dark:divide-white/5">
                        {notifications.map((notif) => (
                          <div key={notif.id} className={`p-5 hover:bg-gray-50 dark:bg-gray-800 dark:hover:bg-gray-800 transition-all cursor-pointer border-b border-brand-border/10 dark:border-white/5 ${!notif.is_read ? 'bg-black/5 dark:bg-black/10' : ''}`}>
                              <div className="flex items-start gap-4">
                                <div className={`w-10 h-10 rounded-2xl flex items-center justify-center flex-shrink-0 shadow-sm ${notif.type === 'order' ? 'bg-green-100 dark:bg-green-900/30 text-green-700 dark:text-green-400' : notif.type === 'promo' ? 'bg-black/10 text-black' : 'bg-blue-100 dark:bg-blue-900/30 text-blue-700 dark:text-blue-400'}`}>
                                  {notif.type === 'order' ? <ShoppingCart className="w-5 h-5" /> : notif.type === 'promo' ? <Zap className="w-5 h-5" /> : <Bell className="w-5 h-5" />}
                                </div>
                                <div className="flex-1 min-w-0">
                                  <div className="flex items-center justify-between mb-1.5">
                                    <h4 className="text-[13px] font-bold text-gray-900 dark:text-white truncate uppercase tracking-tight">{notif.title}</h4>
                                    <span className="text-[10px] font-bold text-brand-text-dim dark:text-gray-400 flex-shrink-0 ml-2 uppercase tracking-tighter">{formatTimeAgo(notif.created_at)}</span>
                                  </div>
                                  <p className="text-[12px] font-bold text-brand-text-dim dark:text-gray-400 leading-snug uppercase tracking-tight opacity-70">{notif.message}</p>
                                </div>
                              </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                  <div className="p-4 border-t border-brand-border/30 dark:border-white/5 bg-white dark:bg-gray-800 flex-shrink-0">
                    <button className="w-full text-center text-[11px] font-bold tracking-wider text-gray-900 dark:text-white hover:text-black dark:hover:text-gray-400 transition-colors min-h-[44px]">
                      Voir tout l'historique
                    </button>
                  </div>
              </motion.div>
            </>
          )}
        </AnimatePresence>

        {/* ─── DESKTOP ─────────────────────────────────────────────────────────── */}

        {/* 1. UTILITY BAR */}
        <div className="hidden lg:flex w-full bg-gray-900 dark:bg-gray-950 border-b border-gray-800 dark:border-black/20 text-xs font-medium tracking-wide py-1.5">
          <div className="max-w-[1400px] w-full mx-auto px-6 flex justify-between items-center text-gray-300 dark:text-gray-300">
            {/* Left cluster */}
            <div className="flex items-center gap-5">
              {canInstall && !isInstalled && (
                <button 
                  onClick={handleInstallClick}
                  className="flex items-center gap-1.5 hover:text-[#ff6600] cursor-pointer transition-colors text-inherit bg-transparent border-0 p-0 text-[11px] font-bold uppercase tracking-wider outline-none"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Installer l'application</span>
                </button>
              )}
              <span className="flex items-center gap-1.5 hover:text-[#ff6600] cursor-pointer transition-colors">
                <ShieldCheck className="w-3.5 h-3.5 text-[#16a34a]" /> Protection Acheteur
              </span>
              <span className="flex items-center gap-1.5 hover:text-[#ff6600] cursor-pointer transition-colors">
                Aide &amp; Support
              </span>
              <span className="flex items-center gap-1.5 hover:text-[#ff6600] cursor-pointer transition-colors text-[#e62e00]">
                <Zap className="w-3.5 h-3.5" /> Achat en Gros B2B
              </span>
            </div>
            {/* Right cluster */}
            <div className="flex items-center gap-6">
              {/* Hide "Devenir Vendeur" if already vendor or admin */}
              {!isVendor && !isAdmin && (
                <Link to="/vendor-registration" className="hover:text-[#ff6600] cursor-pointer transition-colors flex items-center gap-1">
                  <Store className="w-3.5 h-3.5" /> Devenir Vendeur
                </Link>
              )}
              <span className="hover:text-[#ff6600] cursor-pointer transition-colors flex items-center gap-1">
                <Globe className="w-3.5 h-3.5" /> FR / GN
              </span>
            </div>
          </div>
        </div>

        {/* 2. MAIN BAR */}
        <div className={`hidden lg:block w-full transition-all duration-500 ${scrolled ? 'py-1' : 'py-0'}`}>
          <div className="w-full max-w-[1400px] mx-auto px-6 py-4 flex items-center justify-between gap-10">
            {/* Logo */}
            <Link to="/" className="flex-shrink-0 active:scale-95 transition-transform flex items-center">
              {logoError ? (
                <span className="text-2xl font-black tracking-tight text-gray-900 dark:text-white flex items-center gap-2">
                  <span className="w-8 h-8 rounded-xl bg-[#ff6600] flex items-center justify-center text-white text-sm font-black shadow-sm">F</span>
                  <span className="text-gray-900 dark:text-white font-black">{APP_NAME}</span>
                </span>
              ) : (
                <img 
                  src="https://miizhdzuxidilrzwdivk.supabase.co/storage/v1/object/public/assets/fatibara_logo-removebg-preview.png" 
                  alt={APP_NAME} 
                  className="h-10 w-auto object-contain dark:brightness-0 dark:invert max-w-[180px]"
                  loading="eager"
                  onError={() => setLogoError(true)}
                />
              )}
            </Link>

            {/* Search */}
            <div className="flex-1 max-w-[800px] px-4 lg:px-6 xl:px-8">
              <AISearchBar className="lg:max-w-none lg:mx-0" placeholder="Rechercher des produits, marques, ou boutiques..." />
            </div>

            {/* Action Cluster: Bell · Account · Cart */}
            <div className="flex-shrink-0 flex items-center gap-4">

              {/* Bell — logged-in only */}
              {user && (
                <button 
                  onClick={() => { setShowNotifications(!showNotifications); if (!showNotifications && unreadCount > 0) markAllAsRead(); }}
                  className="p-2 hover:bg-orange-50 dark:hover:bg-gray-800 rounded-full transition-colors text-gray-700 dark:text-gray-300 hover:text-[#ff6600] relative"
                  title="Notifications"
                >
                  <Bell className="w-5 h-5" />
                  {unreadCount > 0 && (
                    <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-[#e62e00] rounded-full border border-white dark:border-gray-900" />
                  )}
                </button>
              )}

              {/* ── Account Dropdown ── */}
              <div className="relative border-l border-gray-200 dark:border-gray-700 pl-4">
                <div 
                  onClick={() => {
                    if (user) setShowUserDropdown(!showUserDropdown);
                    else navigate('/login');
                  }}
                  className="flex items-center gap-2 cursor-pointer group"
                >
                  <div className="p-1 rounded-full group-hover:bg-orange-50 dark:group-hover:bg-gray-800 transition-colors">
                    {avatarUrl ? (
                       <div className="w-8 h-8 rounded-full border border-gray-200 dark:border-white/10 overflow-hidden shadow-sm">
                          <img src={avatarUrl} alt="User" className="w-full h-full object-cover" />
                       </div>
                    ) : (
                       <User className="w-8 h-8 text-gray-700 dark:text-gray-300 stroke-[1.5] group-hover:text-[#ff6600]" />
                    )}
                  </div>
                  <div className="flex flex-col">
                     <span className="text-[11px] text-gray-600 dark:text-gray-400 font-medium leading-tight group-hover:text-[#ff6600]">
                       {user ? 'Bon retour !' : 'Bienvenue'}
                     </span>
                     <span className="text-[12px] font-bold text-gray-900 dark:text-white leading-tight mt-0.5 group-hover:text-[#ff6600] flex items-center gap-1">
                        {userProfile?.full_name?.split(' ')[0] || (user ? 'Mon Compte' : 'Se connecter')}
                        {user && <ChevronDown className={`w-3 h-3 transition-transform ${showUserDropdown ? 'rotate-180 text-[#ff6600]' : ''}`} />}
                     </span>
                     {user && loyaltyPoints > 0 && (
                       <span className="hidden xl:flex items-center gap-0.5 mt-0.5">
                         <Star className="w-2.5 h-2.5 text-amber-500 fill-amber-500" />
                         <span className="text-[10px] font-black text-amber-600 dark:text-amber-400 tracking-tight">
                           {loyaltyPoints.toLocaleString()} pts
                         </span>
                       </span>
                     )}
                  </div>
                </div>

                <AnimatePresence>
                  {showUserDropdown && user && (
                    <>
                      <div className="fixed inset-0 z-40" onClick={() => setShowUserDropdown(false)} />
                      <motion.div
                        initial={{ opacity: 0, y: 10, scale: 0.95 }}
                        animate={{ opacity: 1, y: 0, scale: 1 }}
                        exit={{ opacity: 0, y: 10, scale: 0.95 }}
                        className="absolute top-full right-0 mt-3 w-72 bg-white dark:bg-gray-900 border border-gray-100 dark:border-white/5 rounded-2xl shadow-2xl z-50 overflow-hidden"
                      >
                        {/* Identity header */}
                        <div className="p-4 border-b border-gray-100 dark:border-white/5 bg-gray-50/50 dark:bg-gray-800/50">
                          <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1 italic">Compte {APP_NAME}</p>
                          <p className="text-[14px] font-black text-gray-900 dark:text-white truncate">{userProfile?.full_name}</p>
                          <p className="text-[11px] font-bold text-gray-500 dark:text-gray-400 truncate opacity-70">{user?.email}</p>
                          {/* Loyalty points pill */}
                          {loyaltyPoints > 0 && (
                            <button
                              onClick={() => { setShowUserDropdown(false); navigate('/dashboard'); }}
                              className="mt-2 w-full flex items-center justify-between px-3 py-2 bg-amber-50 dark:bg-amber-500/10 border border-amber-200 dark:border-amber-500/20 rounded-xl hover:bg-amber-100 dark:hover:bg-amber-500/20 transition-colors group/lp"
                            >
                              <div className="flex items-center gap-1.5">
                                <Star className="w-3.5 h-3.5 text-amber-500 fill-amber-500" />
                                <span className="text-[11px] font-black text-amber-700 dark:text-amber-400 uppercase tracking-tight">Points Fidélité</span>
                              </div>
                              <span className="text-[13px] font-black text-amber-600 dark:text-amber-300 group-hover/lp:text-amber-700">
                                {loyaltyPoints.toLocaleString()}
                              </span>
                            </button>
                          )}
                        </div>

                        <div className="p-2">
                          {/* ── Role-gated workspace links ── */}
                          {isAdmin && (
                            <button 
                              onClick={() => { setShowUserDropdown(false); navigate('/admin'); }}
                              className="w-full flex items-center gap-3 p-3 rounded-xl hover:bg-red-50 dark:hover:bg-red-900/10 transition-colors text-[13px] font-bold text-red-600 dark:text-red-400"
                            >
                              <ShieldAlert className="w-4 h-4" /> Administration
                            </button>
                          )}
                          {isVendor && (
                            <button 
                              onClick={() => { setShowUserDropdown(false); navigate('/vendor/dashboard'); }}
                              className="w-full flex items-center gap-3 p-3 rounded-xl hover:bg-emerald-50 dark:hover:bg-emerald-900/10 transition-colors text-[13px] font-bold text-emerald-600 dark:text-emerald-400"
                            >
                              <LayoutDashboard className="w-4 h-4" /> Espace Vendeur
                            </button>
                          )}

                          {/* ── Buyer links (for all roles) ── */}
                          <button 
                            onClick={() => { setShowUserDropdown(false); navigate('/dashboard'); }}
                            className="w-full flex items-center gap-3 p-3 rounded-xl hover:bg-orange-50 dark:hover:bg-gray-800 transition-colors text-[13px] font-bold text-gray-700 dark:text-gray-300 hover:text-[#ff6600]"
                          >
                            <User className="w-4 h-4" /> Mon Tableau de bord
                          </button>
                          <button 
                            onClick={() => { setShowUserDropdown(false); navigate('/orders'); }}
                            className="w-full flex items-center gap-3 p-3 rounded-xl hover:bg-orange-50 dark:hover:bg-gray-800 transition-colors text-[13px] font-bold text-gray-700 dark:text-gray-300 hover:text-[#ff6600]"
                          >
                            <ShoppingCart className="w-4 h-4" /> Mes Commandes
                          </button>
                          <button 
                            onClick={() => { setShowUserDropdown(false); navigate('/account/wallet'); }}
                            className="w-full flex items-center gap-3 p-3 rounded-xl hover:bg-orange-50 dark:hover:bg-gray-800 transition-colors text-[13px] font-bold text-gray-700 dark:text-gray-300 hover:text-[#ff6600]"
                          >
                            <Star className="w-4 h-4" /> Mon Portefeuille (GNF)
                          </button>

                          {/* ── Settings row ── */}
                          <div className="mt-1 mx-1 mb-1 p-2 bg-gray-50 dark:bg-gray-800 rounded-xl flex items-center justify-around gap-1">
                            <button 
                              onClick={() => setIsDarkMode(!isDarkMode)} 
                              title="Thème"
                              className={`flex-1 flex flex-col items-center justify-center gap-1 py-2.5 rounded-lg transition-all text-[9px] font-bold uppercase tracking-wider ${isDarkMode ? 'bg-[#ff6600] text-white shadow-md' : 'text-gray-600 dark:text-gray-300 hover:bg-white dark:hover:bg-gray-700'}`}
                            >
                              {isDarkMode ? <Moon className="w-4 h-4" /> : <Sun className="w-4 h-4" />}
                              Thème
                            </button>
                            <button 
                              onClick={() => setModeEconomie(!modeEconomie)} 
                              title="Mode Économie"
                              className={`flex-1 flex flex-col items-center justify-center gap-1 py-2.5 rounded-lg transition-all text-[9px] font-bold uppercase tracking-wider ${modeEconomie ? 'bg-[#16a34a] text-white shadow-md' : 'text-gray-600 dark:text-gray-300 hover:bg-white dark:hover:bg-gray-700'}`}
                            >
                              <Zap className="w-4 h-4" />
                              Éco
                            </button>
                            <button 
                              onClick={toggleCurrency} 
                              title="Devise"
                              className="flex-1 flex flex-col items-center justify-center gap-1 py-2.5 rounded-lg transition-all text-[9px] font-bold uppercase tracking-wider text-gray-600 dark:text-gray-300 hover:bg-white dark:hover:bg-gray-700"
                            >
                              <Globe className="w-4 h-4" />
                              {currency}
                            </button>
                          </div>

                          {/* ── Role Switcher (only for multi-role accounts) ── */}
                          {allowedRoles.length > 1 && (
                            <div className="mt-1 mb-1">
                              <p className="px-3 pt-2 pb-1 text-[9px] font-black text-gray-400 dark:text-gray-500 uppercase tracking-[0.18em] flex items-center gap-1.5">
                                <Layers className="w-3 h-3" /> Changer de mode
                              </p>
                              <div className="space-y-0.5">
                                {([
                                  { role: 'customer', label: 'Mode Client',  icon: '🛒', path: '/' },
                                  { role: 'vendor',   label: 'Mode Vendeur', icon: '🏪', path: '/vendor/dashboard' },
                                  { role: 'courier',  label: 'Mode Livreur', icon: '🚚', path: '/courier-dashboard' },
                                  { role: 'admin',    label: 'Mode Admin',   icon: '🛡️', path: '/admin' },
                                ] as const).filter(opt => allowedRoles.includes(opt.role)).map(opt => (
                                  <button
                                    key={opt.role}
                                    onClick={async () => {
                                      setShowUserDropdown(false);
                                      try {
                                        await switchRole(opt.role);
                                        navigate(opt.path);
                                      } catch {
                                        // switchRole throws on RPC error — toast shown by caller
                                      }
                                    }}
                                    className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-[12px] font-bold transition-all ${
                                      activeRole === opt.role
                                        ? 'bg-[#ff6600]/10 text-[#ff6600] ring-1 ring-[#ff6600]/30'
                                        : 'text-gray-600 dark:text-gray-300 hover:bg-orange-50 dark:hover:bg-gray-800 hover:text-[#ff6600]'
                                    }`}
                                  >
                                    <span className="text-base leading-none">{opt.icon}</span>
                                    <span className="flex-1 text-left">{opt.label}</span>
                                    {activeRole === opt.role && (
                                      <span className="text-[9px] font-black bg-[#ff6600] text-white px-1.5 py-0.5 rounded-full tracking-wider uppercase">Actif</span>
                                    )}
                                  </button>
                                ))}
                              </div>
                            </div>
                          )}

                          {/* ── Logout ── */}
                          <div className="border-t border-gray-100 dark:border-white/5 mt-1 pt-1">
                            <button 
                              onClick={() => { setShowUserDropdown(false); setIsLogoutModalOpen(true); }}
                              className="w-full flex items-center gap-3 p-3 rounded-xl hover:bg-rose-50 dark:hover:bg-rose-900/10 transition-colors text-[13px] font-bold text-rose-600 dark:text-rose-400"
                            >
                              <LogOut className="w-4 h-4" /> Déconnexion
                            </button>
                          </div>
                        </div>
                      </motion.div>
                    </>
                  )}
                </AnimatePresence>
              </div>

              {/* Cart */}
              <div 
                 onClick={() => setIsCartOpen(true)}
                 className="flex items-center gap-2 cursor-pointer group ml-1 relative"
              >
                <div className="relative">
                  <ShoppingCart className="w-8 h-8 text-gray-700 dark:text-gray-300 stroke-[1.5] group-hover:scale-110 group-hover:text-[#ff6600] transition-transform" />
                  <span className="absolute -top-1 -right-1 bg-[#ff6600] text-white min-w-[20px] h-[20px] rounded-full text-[11px] font-bold flex items-center justify-center border-2 border-white dark:border-gray-950 px-1 shadow-sm">
                     {cart?.length > 9 ? '9+' : (cart?.length || 0)}
                  </span>
                </div>
                <span className="text-[14px] font-bold text-gray-900 dark:text-white hidden 2xl:block group-hover:text-[#ff6600] transition-colors">Panier</span>
              </div>
            </div>
          </div>

          {/* 3. CATEGORY NAV BAR */}
          <div className="w-full max-w-[1400px] mx-auto px-6 pb-3 pt-1 flex items-center gap-8 text-sm">
            {/* Categories mega-menu trigger */}
            <div 
               onMouseEnter={() => window.matchMedia('(hover: hover)').matches && setShowMegaMenu(true)}
               onMouseLeave={() => window.matchMedia('(hover: hover)').matches && setShowMegaMenu(false)}
               onClick={() => setShowMegaMenu(!showMegaMenu)}
               className="relative"
            >
              <button className={`flex items-center gap-2 px-5 py-2 rounded-full font-bold transition-all ${showMegaMenu ? 'bg-[#ff6600] text-white shadow-md' : 'bg-gray-100 hover:bg-gray-200 dark:bg-gray-800 dark:hover:bg-gray-700 text-gray-900 dark:text-white'}`}>
                 <Menu className="w-5 h-5" />
                 Toutes les catégories
              </button>

              <AnimatePresence>
                {showMegaMenu && (
                  <motion.div
                    initial={{ opacity: 0, scale: 0.95, y: 10 }}
                    animate={{ opacity: 1, scale: 1, y: 0 }}
                    exit={{ opacity: 0, scale: 0.95, y: 10 }}
                    className="absolute top-full left-0 mt-4 w-[800px] bg-white dark:bg-gray-900 border border-gray-100 dark:border-gray-800 rounded-2xl shadow-xl p-8 z-[60] grid grid-cols-3 gap-10"
                  >
                    <div className="space-y-6">
                       <h4 className="text-[12px] font-black tracking-wider text-[#ff6600] mb-4 uppercase">Populaire</h4>
                       {PRODUCT_CATEGORIES.slice(0, 4).map(cat => (
                         <Link key={cat} to={`/shop?category=${encodeURIComponent(cat)}`} className="block text-[15px] font-bold text-gray-600 dark:text-gray-400 hover:text-[#ff6600] dark:hover:text-[#ff6600] transition-all flex items-center justify-between group">
                            {cat}
                            <ArrowRight className="w-4 h-4 opacity-0 -translate-x-2 group-hover:opacity-100 group-hover:translate-x-0 transition-all text-[#ff6600]" />
                         </Link>
                       ))}
                    </div>
                    <div className="space-y-6">
                       <h4 className="text-[12px] font-black tracking-wider text-[#16a34a] mb-4 uppercase">Exploration</h4>
                       {PRODUCT_CATEGORIES.slice(4, 8).map(cat => (
                         <Link key={cat} to={`/shop?category=${encodeURIComponent(cat)}`} className="block text-[15px] font-bold text-gray-600 dark:text-gray-400 hover:text-[#16a34a] transition-all flex items-center justify-between group">
                            {cat}
                            <ArrowRight className="w-4 h-4 opacity-0 -translate-x-2 group-hover:opacity-100 group-hover:translate-x-0 transition-all text-[#16a34a]" />
                         </Link>
                       ))}
                    </div>
                    <div className="bg-orange-50 dark:bg-orange-900/10 rounded-2xl p-8 flex flex-col justify-center text-center">
                       <Store className="w-10 h-10 text-[#ff6600] mx-auto mb-4" />
                       <h4 className="text-[14px] font-bold text-gray-900 dark:text-white mb-2">Boutiques à {selectedRegion}</h4>
                       <p className="text-[12px] text-gray-500 dark:text-gray-400 mb-6">Découvrez les artisans locaux près de chez vous.</p>
                       <button onClick={() => navigate('/shop')} className="bg-[#ff6600] text-white py-2.5 rounded-full text-[13px] font-bold hover:bg-[#e62e00] transition-colors shadow-md">Explorer la ville</button>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>

            {/* Main nav links */}
            <nav className="flex items-center gap-6 font-semibold text-[15px]">
              <Link to="/shop?promo=true" className="text-[#e62e00] hover:text-red-700 hover:underline text-sm font-black italic tracking-tight">Ventes Flash</Link>
              <Link to="/shop" className="text-gray-900 dark:text-white hover:text-[#ff6600] hover:underline transition-colors uppercase text-[12px] tracking-widest">{APP_NAME} Business</Link>
              <Link to="/shop?category=Épicerie%20%26%20Supermarché" className="text-gray-900 dark:text-white hover:text-[#16a34a] hover:underline transition-colors uppercase text-[12px] tracking-widest">Super Marché</Link>
              <Link to="/shop?category=Mode%20Femme" className="text-gray-900 dark:text-white hover:text-[#ff6600] hover:underline transition-colors uppercase text-[12px] tracking-widest">Mode</Link>
              <Link to="/search" className="text-gray-900 dark:text-white hover:text-[#ff6600] hover:underline transition-colors flex items-center gap-1 uppercase text-[12px] tracking-widest">
                Plus <ChevronDown className="w-4 h-4 opacity-50" />
              </Link>
            </nav>
            {/* RIGHT SIDE INTENTIONALLY EMPTY — role links live in the account dropdown */}
          </div>
        </div>

        {/* ─── MOBILE SIDEBAR ──────────────────────────────────────────────────── */}
        <AnimatePresence>
          {isMenuOpen && (
            <>
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.2 }}
                onClick={() => setIsMenuOpen(false)}
                className="lg:hidden fixed inset-0 z-[120] bg-black/60 backdrop-blur-sm"
              />
              
              <motion.div
                initial={{ x: '-100%' }}
                animate={{ x: 0 }}
                exit={{ x: '-100%' }}
                transition={{ type: "spring", bounce: 0, duration: 0.4 }}
                className="lg:hidden fixed inset-y-0 left-0 w-[85%] max-w-[320px] bg-white dark:bg-gray-900 z-[130] shadow-2xl flex flex-col"
              >
                {/* Drawer header */}
                <div className="bg-[#ff6600] text-white p-5 flex items-center justify-between pb-6">
                  <div className="flex items-center gap-3">
                     {avatarUrl ? (
                        <div className="w-12 h-12 rounded-full border-2 border-white/30 overflow-hidden shrink-0 shadow-inner">
                          <img src={avatarUrl} alt="Profile" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                        </div>
                      ) : (
                        <div className="w-12 h-12 rounded-full bg-white/20 flex items-center justify-center shrink-0">
                          <User className="w-7 h-7" />
                        </div>
                      )}
                     
                     <div 
                       className="flex-1 min-w-0" 
                       onClick={() => {
                         setIsMenuOpen(false);
                         if (user) navigate('/dashboard'); else navigate('/login');
                       }}
                     >
                       <span className="block text-[16px] font-black leading-none mb-1 shadow-sm uppercase tracking-tight truncate cursor-pointer hover:underline">
                         {userProfile?.full_name || (user ? 'Mon Compte' : 'Se Connecter')}
                       </span>
                       <span className="block text-[11px] font-bold text-white/80 uppercase tracking-wider cursor-pointer">
                         {user ? 'Voir le Profil >' : 'Identifiez-vous'}
                       </span>
                     </div>
                  </div>
                </div>

                <div className="flex-1 overflow-y-auto pb-safe custom-scrollbar p-4 space-y-5">
                  
                  {/* Role shortcuts in mobile drawer */}
                  {isAdmin && (
                    <button 
                      onClick={() => { setIsMenuOpen(false); navigate('/admin'); }}
                      className="w-full flex items-center gap-3 p-3 bg-red-50 dark:bg-red-900/20 rounded-2xl border border-red-100 dark:border-red-500/30"
                    >
                      <div className="w-8 h-8 rounded-full bg-red-600 flex items-center justify-center text-white shadow-md">
                        <ShieldAlert className="w-4 h-4" />
                      </div>
                      <div className="flex flex-col items-start text-left flex-1">
                        <span className="text-[13px] font-bold text-red-700 dark:text-red-400 uppercase tracking-tight">Tableau de bord Admin</span>
                      </div>
                    </button>
                  )}

                  {isVendor && (
                    <button 
                      onClick={() => { setIsMenuOpen(false); navigate('/vendor/dashboard'); }}
                      className="w-full flex items-center gap-3 p-3 bg-emerald-50 dark:bg-emerald-900/20 rounded-2xl border border-emerald-100 dark:border-emerald-500/30"
                    >
                      <div className="w-8 h-8 rounded-full bg-emerald-600 flex items-center justify-center text-white shadow-md">
                        <LayoutDashboard className="w-4 h-4" />
                      </div>
                      <div className="flex flex-col items-start text-left flex-1">
                        <span className="text-[13px] font-bold text-emerald-700 dark:text-emerald-400 uppercase tracking-tight">Espace Vendeur</span>
                      </div>
                    </button>
                  )}

                  {/* Preferences */}
                  <div className="grid grid-cols-3 gap-2 bg-gray-50 dark:bg-gray-800 rounded-2xl p-2 relative -mt-8 shadow-md">
                    <button 
                      onClick={() => setIsDarkMode(!isDarkMode)} 
                      className={`flex flex-col items-center justify-center gap-1.5 py-3 rounded-xl transition-all ${isDarkMode ? 'bg-[#ff6600] text-white shadow-md' : 'bg-transparent text-gray-700 dark:text-gray-300'}`}
                    >
                      {isDarkMode ? <Moon className="w-4 h-4" /> : <Sun className="w-4 h-4" />}
                      <span className="text-[9px] font-bold uppercase tracking-wider">Thème</span>
                    </button>

                    <button 
                      onClick={() => setModeEconomie(!modeEconomie)} 
                      className={`flex flex-col items-center justify-center gap-1.5 py-3 rounded-xl transition-all ${modeEconomie ? 'bg-[#16a34a] text-white shadow-md' : 'bg-transparent text-gray-700 dark:text-gray-300'}`}
                    >
                      <Zap className="w-4 h-4" />
                      <span className="text-[9px] font-bold uppercase tracking-wider">Éco</span>
                    </button>

                    <button 
                      onClick={toggleCurrency}
                      className="flex flex-col items-center justify-center gap-1.5 py-3 rounded-xl transition-all bg-transparent text-gray-700 dark:text-gray-300"
                    >
                      <Globe className="w-4 h-4" />
                      <span className="text-[9px] font-bold uppercase tracking-wider">{currency}</span>
                    </button>
                  </div>

                  {/* Categories */}
                  <div className="bg-white dark:bg-gray-900 rounded-2xl">
                     <h3 className="text-[13px] font-black text-gray-900 dark:text-white uppercase tracking-wider mb-3 px-1">Top Catégories</h3>
                     <div className="space-y-1">
                        {PRODUCT_CATEGORIES.slice(0, 6).map((cat, i) => (
                           <Link key={i} to={`/shop?category=${encodeURIComponent(cat)}`} onClick={() => setIsMenuOpen(false)} className="flex items-center justify-between p-3 rounded-xl hover:bg-orange-50 dark:hover:bg-gray-800 transition-colors">
                              <span className="text-[14px] font-bold text-gray-700 dark:text-gray-300">{cat}</span>
                              <ChevronDown className="w-4 h-4 -rotate-90 text-gray-400" />
                           </Link>
                        ))}
                     </div>
                  </div>

                  {/* Actions */}
                  <div className="space-y-2">
                    <Link to="/shop" onClick={() => setIsMenuOpen(false)} className="flex items-center gap-3 p-3 bg-gray-50 dark:bg-gray-800/50 rounded-2xl hover:bg-[#ff6600]/10 transition-colors border border-transparent hover:border-[#ff6600]/20">
                      <div className="w-8 h-8 rounded-full bg-white dark:bg-gray-700 flex items-center justify-center text-[#ff6600] shadow-sm">
                        <Store className="w-4 h-4" />
                      </div>
                      <span className="text-[14px] font-bold text-gray-900 dark:text-white flex-1">Boutiques {APP_NAME}</span>
                      <ArrowRight className="w-4 h-4 text-gray-400" />
                    </Link>

                    {/* "Ouvrir une boutique" — hidden if already vendor or admin */}
                    {!isVendor && !isAdmin && (
                      <button 
                        onClick={() => { setIsMenuOpen(false); navigate('/vendor-registration'); }}
                        className="w-full flex items-center gap-3 p-3 bg-orange-50 dark:bg-orange-900/10 rounded-2xl border border-orange-100 dark:border-orange-500/20"
                      >
                        <div className="w-8 h-8 rounded-full bg-[#ff6600] flex items-center justify-center text-white shadow-md">
                          <Plus className="w-4 h-4" />
                        </div>
                        <div className="flex flex-col items-start text-left flex-1">
                          <span className="text-[13px] font-bold text-[#e62e00] uppercase tracking-tight">Ouvrir une Boutique</span>
                          <span className="text-[10px] font-medium text-gray-600 dark:text-gray-400">Totalement gratuit</span>
                        </div>
                      </button>
                    )}
                  </div>
                </div>
              </motion.div>
            </>
          )}
        </AnimatePresence>
      </header>

      <CartDrawer isOpen={isCartOpen} onClose={() => setIsCartOpen(false)} />
      <AuthModal isOpen={showAuth} onClose={() => setShowAuth(false)} />

      {/* Logout Confirmation Modal */}
      <AnimatePresence>
        {isLogoutModalOpen && (
          <div className="fixed inset-0 z-[200] flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsLogoutModalOpen(false)}
              className="absolute inset-0 bg-black/60 backdrop-blur-md"
            />
            <motion.div
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              className="relative w-full max-w-[400px] bg-white dark:bg-gray-900 rounded-[2.5rem] shadow-2xl overflow-hidden border border-white/10"
            >
              <div className="p-10 text-center">
                <div className="w-20 h-20 bg-rose-50 dark:bg-rose-900/20 rounded-full flex items-center justify-center mx-auto mb-6">
                  <X className="w-10 h-10 text-rose-500" />
                </div>
                <h3 className="text-2xl font-black text-gray-900 dark:text-white mb-3 italic tracking-tight">Déconnexion ?</h3>
                <p className="text-gray-500 dark:text-gray-400 font-bold mb-8 uppercase text-[12px] tracking-widest leading-relaxed">
                  Êtes-vous sûr de vouloir quitter votre session Elite {APP_NAME} ? Vos données sont en sécurité.
                </p>
                <div className="flex flex-col gap-3">
                  <button
                    onClick={() => {
                      handleLogout();
                      setIsLogoutModalOpen(false);
                    }}
                    className="w-full bg-rose-600 hover:bg-rose-700 text-white font-black py-4 rounded-2xl transition-all shadow-lg hover:shadow-rose-500/20 active:scale-95 uppercase tracking-widest"
                  >
                    Oui, Se Déconnecter
                  </button>
                  <button
                    onClick={() => setIsLogoutModalOpen(false)}
                    className="w-full bg-gray-100 dark:bg-gray-800 hover:bg-gray-200 dark:hover:bg-gray-700 text-gray-900 dark:text-white font-black py-4 rounded-2xl transition-all active:scale-95 uppercase tracking-widest"
                  >
                    Rester Connecté
                  </button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </>
  );
}
