import { motion } from 'motion/react';
import { useEffect, useState } from 'react';
import {
  ArrowRight, Percent, Rocket, Store, Tag, ShieldCheck,
  ShoppingBag, Wallet, PackageCheck, ChevronRight, Truck,
} from 'lucide-react';
import { useStore } from '../store/useStore';
import { useAppContext } from '../context/AppContext';
import { supabase } from '../lib/supabase';
import { Link, useNavigate } from 'react-router-dom';
import { PRODUCT_CATEGORIES, APP_NAME, APP_DESCRIPTION, CURRENCY } from '../lib/constants';

// ─── helpers ──────────────────────────────────────────────────────────────────
function formatGNF(n: number) {
  return n.toLocaleString('fr-FR') + ' ' + CURRENCY;
}

// Returns first name only
function firstName(fullName?: string | null) {
  if (!fullName) return null;
  return fullName.split(' ')[0];
}

// ─── Main component ────────────────────────────────────────────────────────────
export default function Hero() {
  const { modeEconomie } = useStore();
  const { activePromotions, user, walletBalance } = useAppContext();
  const navigate = useNavigate();

  const [heroProduct, setHeroProduct] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const { userProfile } = useStore();
  const [pendingOrders, setPendingOrders] = useState(0);

  const categoryMenu = [
    { label: PRODUCT_CATEGORIES[0],  icon: '📱' },
    { label: PRODUCT_CATEGORIES[1],  icon: '💻' },
    { label: PRODUCT_CATEGORIES[4],  icon: '👗' },
    { label: PRODUCT_CATEGORIES[5],  icon: '💄' },
    { label: PRODUCT_CATEGORIES[6],  icon: '🏡' },
    { label: PRODUCT_CATEGORIES[7],  icon: '🛍️' },
    { label: PRODUCT_CATEGORIES[8],  icon: '🚗' },
    { label: PRODUCT_CATEGORIES[10], icon: '⚽' },
    { label: 'B2B & Matériaux Pro',  icon: '🏗️' },
    { label: 'Ventes en Gros',       icon: '📦' },
  ];

  useEffect(() => {
    async function fetchData() {
      try {
        const heroRes = await supabase
          .from('products')
          .select('id, title, price_gnf, image_urls, description, category, is_hero')
          .eq('is_hero', true)
          .maybeSingle();
        if (heroRes.data) setHeroProduct(heroRes.data);
      } catch (err) {
        console.warn('Hero fetch failed:', err);
      } finally {
        setLoading(false);
      }
    }
    fetchData();
  }, []);

  // Fetch only the pending order count when user is logged in.
  // Profile display data (full_name, avatar_url) is read from useStore
  // which is already populated by AppContext.fetchProfile — no extra query needed.
  useEffect(() => {
    if (!user?.id) return;
    (async () => {
      const ordersRes = await supabase
        .from('orders')
        .select('id', { count: 'exact', head: true })
        .eq('user_id', user.id)
        .not('status', 'in', '(delivered,cancelled)');
      setPendingOrders(ordersRes.count ?? 0);
    })();
  }, [user?.id]);

  return (
    <section className="bg-gray-100 dark:bg-gray-950 transition-colors py-2 md:py-6">
      <div className="max-w-[1400px] mx-auto px-2 md:px-6">
        {loading ? (
          <div className="bg-white dark:bg-gray-900 p-8 flex items-center justify-center rounded-2xl md:rounded-3xl border border-gray-100 dark:border-white/5 shadow-sm min-h-[300px]">
            <div className="w-8 h-8 border-2 border-[#ff6600] border-t-transparent rounded-full animate-spin" />
          </div>
        ) : (
          <div className="flex flex-col md:flex-row gap-4">

            {/* ── Left Sidebar Categories ─────────────────────────────────── */}
            <div className="hidden lg:flex flex-col w-[260px] bg-white dark:bg-gray-900 rounded-xl shadow-sm border border-gray-200 dark:border-gray-800 shrink-0 overflow-hidden divide-y divide-gray-100 dark:divide-gray-800">
              <div className="py-2">
                {categoryMenu.map((cat, i) => (
                  <Link
                    key={i}
                    to={`/shop?category=${encodeURIComponent(cat.label)}`}
                    className="flex items-center gap-3 px-4 py-2 hover:bg-orange-50 dark:hover:bg-gray-800 text-sm font-medium text-gray-700 dark:text-gray-200 hover:text-[#ff6600] dark:hover:text-[#ff6600] transition-colors duration-150 group"
                  >
                    <span className="opacity-80 group-hover:opacity-100">{cat.icon}</span>
                    <span>{cat.label}</span>
                  </Link>
                ))}
              </div>
            </div>

            {/* ── Main Hero Banner ─────────────────────────────────────────── */}
            <div className="relative flex-1 bg-gradient-to-br from-[#ff6600] to-orange-600 rounded-3xl overflow-hidden shadow-xl shadow-[#ff6600]/10 flex items-center min-h-[260px] md:min-h-[440px] border border-orange-500/20">
              {/* Pattern overlay */}
              <div className="absolute inset-0 bg-[url('/cubes.png')] opacity-10 pointer-events-none mix-blend-overlay" />
              <div className="absolute top-0 right-0 w-[150%] md:w-[100%] h-full bg-gradient-to-l from-black/40 via-black/5 to-transparent pointer-events-none" />

              <div className="relative z-10 w-full p-6 md:p-12 flex flex-col items-start justify-center h-full text-white">

                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="inline-flex max-w-full items-center gap-2 bg-yellow-400 text-red-700 px-4 py-1.5 rounded-full text-[11px] md:text-[12px] font-bold uppercase tracking-wider mb-4 shadow-sm"
                >
                  {activePromotions && activePromotions.length > 0 ? (
                    <>
                      <Percent className="w-3.5 h-3.5 shrink-0" />
                      <span className="truncate">{activePromotions[0].title} : -{activePromotions[0].discount_value}%</span>
                    </>
                  ) : (
                    <>
                      <Tag className="w-3.5 h-3.5 shrink-0" />
                      <span className="truncate">Nouveau membre : jusqu'à 90% de réduction</span>
                    </>
                  )}
                </motion.div>

                <motion.h1
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.1 }}
                  className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-extrabold leading-tight tracking-tight mb-3 w-full max-w-[70%] drop-shadow-sm"
                >
                  {heroProduct
                    ? heroProduct.title
                    : `Le marché de Guinée, à portée de main`}
                </motion.h1>

                <motion.p
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.2 }}
                  className="text-base text-orange-100 max-w-[60%] leading-relaxed mb-6 font-medium hidden md:block drop-shadow-sm"
                >
                  {heroProduct?.description?.substring(0, 120) || APP_DESCRIPTION}
                </motion.p>

                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.3 }}
                >
                  <Link
                    to={heroProduct ? `/product/${heroProduct.id}` : '/shop'}
                    className="group inline-flex items-center justify-center gap-2 bg-white text-[#ff6600] px-6 py-3 rounded-full text-[14px] font-bold hover:scale-105 hover:bg-gray-50 transition-all shadow-lg active:scale-95"
                  >
                    {heroProduct ? 'Voir le produit' : 'Découvrir les boutiques'}
                    <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                  </Link>
                </motion.div>
              </div>

              {/* Hero product image */}
              {heroProduct?.image_urls?.[0] && (
                <motion.div
                  initial={{ opacity: 0, scale: 0.9, x: 20 }}
                  animate={{ opacity: 1, scale: 1, x: 0 }}
                  transition={{ duration: 0.6, ease: 'easeOut' }}
                  className="absolute -right-6 bottom-0 w-[60%] md:w-[50%] h-[90%] flex items-end justify-center pb-2 md:pb-6"
                >
                  <img
                    src={heroProduct.image_urls[0]}
                    alt={heroProduct.title}
                    className="max-h-full object-contain drop-shadow-[0_20px_20px_rgba(0,0,0,0.3)] hover:scale-105 transition-transform duration-700"
                    referrerPolicy="no-referrer"
                  />
                  {heroProduct.price_gnf && (
                    <motion.div
                      initial={{ opacity: 0, scale: 0 }}
                      animate={{ opacity: 1, scale: 1 }}
                      transition={{ delay: 0.5, type: 'spring' }}
                      className="absolute top-10 lg:top-1/4 -left-10 z-20 bg-yellow-400 text-red-700 font-extrabold px-5 py-3 rounded-xl shadow-2xl transform -rotate-6 border-4 border-white text-[15px] md:text-xl uppercase whitespace-nowrap"
                    >
                      {heroProduct.price_gnf.toLocaleString()} {CURRENCY}
                    </motion.div>
                  )}
                </motion.div>
              )}
            </div>

            {/* ── Right Panel ──────────────────────────────────────────────── */}
            <div className="hidden xl:flex flex-col gap-4 w-[280px]">

              {/* ── LOGGED IN: Personalized panel ── */}
              {user ? (
                <LoggedInPanel
                  name={firstName(userProfile?.full_name)}
                  avatarUrl={userProfile?.avatar_url}
                  walletBalance={walletBalance}
                  pendingOrders={pendingOrders}
                  onNavigate={navigate}
                />
              ) : (
                /* ── GUEST: Sign-up CTA panel ── */
                <GuestPanel />
              )}

              {/* ── Buyer Protection Box (always visible) ── */}
              <BuyerProtectionBox />
            </div>

          </div>
        )}
      </div>
    </section>
  );
}

// ─── Logged-in panel ──────────────────────────────────────────────────────────
function LoggedInPanel({
  name, avatarUrl, walletBalance, pendingOrders, onNavigate,
}: {
  name: string | null;
  avatarUrl?: string;
  walletBalance: number;
  pendingOrders: number;
  onNavigate: (path: string) => void;
}) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 6 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-white dark:bg-gray-900 rounded-3xl shadow-sm hover:shadow-md p-5 border border-gray-100 dark:border-gray-800 flex flex-col relative overflow-hidden transition-all duration-300 group"
    >
      {/* Ambient glow */}
      <div className="absolute top-0 right-0 w-32 h-32 bg-orange-100 dark:bg-orange-900/20 rounded-full blur-3xl -mr-10 -mt-10 group-hover:scale-150 transition-transform duration-700 pointer-events-none" />

      {/* Greeting row */}
      <div className="flex items-center gap-3 mb-4 relative z-10">
        <div className="w-11 h-11 rounded-full bg-orange-50 dark:bg-orange-900/30 border-2 border-orange-100 dark:border-orange-500/20 overflow-hidden shrink-0 flex items-center justify-center">
          {avatarUrl ? (
            <img src={avatarUrl} alt="Avatar" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
          ) : (
            <span className="text-xl">😊</span>
          )}
        </div>
        <div className="min-w-0">
          <p className="text-[11px] font-bold text-gray-400 dark:text-gray-500 uppercase tracking-widest leading-none mb-1">
            Bon retour !
          </p>
          <p className="text-[15px] font-black text-gray-900 dark:text-white leading-none truncate">
            {name ?? 'Mon espace'}
          </p>
        </div>
      </div>

      {/* Wallet balance chip */}
      <button
        onClick={() => onNavigate('/account/wallet')}
        className="relative z-10 w-full flex items-center justify-between bg-gradient-to-r from-orange-50 to-amber-50 dark:from-orange-900/20 dark:to-amber-900/20 border border-orange-100 dark:border-orange-500/20 rounded-2xl px-4 py-3 mb-3 hover:border-orange-300 dark:hover:border-orange-500/40 transition-all group/wallet"
      >
        <div className="flex items-center gap-2.5">
          <Wallet className="w-4 h-4 text-[#ff6600]" />
          <span className="text-[12px] font-bold text-gray-500 dark:text-gray-400">Portefeuille</span>
        </div>
        <div className="flex items-center gap-1">
          <span className="text-[14px] font-black text-gray-900 dark:text-white tabular-nums">
            {(walletBalance ?? 0).toLocaleString('fr-FR')}
          </span>
          <span className="text-[10px] font-bold text-[#ff6600]">{CURRENCY}</span>
          <ChevronRight className="w-3.5 h-3.5 text-gray-400 group-hover/wallet:text-[#ff6600] group-hover/wallet:translate-x-0.5 transition-all ml-0.5" />
        </div>
      </button>

      {/* Quick actions */}
      <div className="relative z-10 grid grid-cols-2 gap-2">
        <button
          onClick={() => onNavigate('/account/orders')}
          className="flex flex-col items-start gap-1.5 p-3 bg-gray-50 dark:bg-gray-800 rounded-2xl border border-gray-100 dark:border-gray-700 hover:border-[#ff6600]/30 hover:bg-orange-50 dark:hover:bg-orange-900/10 transition-all group/btn"
        >
          <div className="w-7 h-7 rounded-xl bg-white dark:bg-gray-700 shadow-sm flex items-center justify-center">
            <ShoppingBag className="w-3.5 h-3.5 text-[#ff6600]" />
          </div>
          <span className="text-[11px] font-bold text-gray-700 dark:text-gray-300 leading-tight">
            Mes commandes
          </span>
          {pendingOrders > 0 && (
            <span className="text-[10px] font-black text-[#ff6600]">
              {pendingOrders} en cours
            </span>
          )}
        </button>

        <button
          onClick={() => onNavigate('/shop')}
          className="flex flex-col items-start gap-1.5 p-3 bg-gray-50 dark:bg-gray-800 rounded-2xl border border-gray-100 dark:border-gray-700 hover:border-[#ff6600]/30 hover:bg-orange-50 dark:hover:bg-orange-900/10 transition-all group/btn"
        >
          <div className="w-7 h-7 rounded-xl bg-white dark:bg-gray-700 shadow-sm flex items-center justify-center">
            <Store className="w-3.5 h-3.5 text-[#ff6600]" />
          </div>
          <span className="text-[11px] font-bold text-gray-700 dark:text-gray-300 leading-tight">
            Boutiques
          </span>
          <span className="text-[10px] font-bold text-emerald-500">En ligne</span>
        </button>
      </div>
    </motion.div>
  );
}

// ─── Guest / unauthenticated panel ────────────────────────────────────────────
function GuestPanel() {
  return (
    <motion.div
      initial={{ opacity: 0, y: 6 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-white dark:bg-gray-900 rounded-3xl shadow-sm hover:shadow-md p-6 border border-gray-100 dark:border-gray-800 flex flex-col items-center relative overflow-hidden transition-all duration-300 group"
    >
      <div className="absolute top-0 right-0 w-24 h-24 bg-orange-100 dark:bg-orange-900/20 rounded-full blur-2xl -mr-10 -mt-10 group-hover:scale-150 transition-transform duration-700 pointer-events-none" />

      <div className="w-14 h-14 rounded-2xl bg-orange-50 dark:bg-orange-900/20 border border-orange-100 dark:border-orange-500/20 flex items-center justify-center mb-3 text-2xl shadow-inner relative z-10">
        👋
      </div>

      <h3 className="text-[15px] font-black text-gray-900 dark:text-white mb-1 relative z-10">
        Bienvenue sur {APP_NAME}
      </h3>
      <p className="text-[12px] text-gray-500 dark:text-gray-400 mb-5 text-center font-medium leading-snug relative z-10">
        Connectez-vous pour accéder à vos commandes, votre portefeuille et des offres exclusives.
      </p>

      <div className="w-full flex flex-col gap-2.5 relative z-10">
        <Link
          to="/login?mode=signup"
          className="w-full bg-[#ff6600] text-white px-5 py-2.5 rounded-full text-[13px] font-bold hover:bg-[#e62e00] transition-all text-center shadow-md hover:shadow-lg hover:shadow-[#ff6600]/25 active:scale-95"
        >
          Créer un compte gratuit
        </Link>
        <Link
          to="/login"
          className="w-full bg-transparent text-gray-700 dark:text-gray-300 border border-gray-200 dark:border-gray-700 px-5 py-2.5 rounded-full text-[13px] font-semibold hover:border-gray-400 dark:hover:border-gray-500 hover:text-gray-900 dark:hover:text-white transition-all text-center"
        >
          Se connecter
        </Link>
      </div>
    </motion.div>
  );
}

// ─── Buyer Protection Box ─────────────────────────────────────────────────────
function BuyerProtectionBox() {
  const features = [
    {
      icon: <PackageCheck className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />,
      bg: 'bg-emerald-50 dark:bg-emerald-900/20',
      title: 'Produits vérifiés',
      sub: 'Chaque article est contrôlé avant expédition.',
    },
    {
      icon: <Rocket className="w-4 h-4 text-blue-500" />,
      bg: 'bg-blue-50 dark:bg-blue-900/20',
      title: 'Retour sous 7 jours',
      sub: 'Remboursement garanti, sans discussion.',
    },
    {
      icon: <Truck className="w-4 h-4 text-[#ff6600]" />,
      bg: 'bg-orange-50 dark:bg-orange-900/20',
      title: 'Livraison rapide',
      sub: 'Conakry et grandes villes en 24h.',
    },
  ];

  return (
    <div className="flex-1 bg-white dark:bg-gray-900 rounded-3xl shadow-sm hover:shadow-md p-5 border border-gray-100 dark:border-gray-800 flex flex-col transition-all duration-300">
      <h4 className="text-[12px] font-black text-gray-900 dark:text-white mb-4 border-b border-gray-100 dark:border-gray-800 pb-3 flex items-center gap-2 uppercase tracking-wider">
        <ShieldCheck className="w-4 h-4 text-emerald-600" />
        Protection Acheteur
      </h4>
      <div className="space-y-3.5">
        {features.map((f, i) => (
          <div key={i} className="flex items-start gap-3 group">
            <div className={`${f.bg} p-2 rounded-xl group-hover:scale-110 transition-transform shrink-0`}>
              {f.icon}
            </div>
            <div className="flex flex-col leading-tight pt-0.5">
              <span className="text-[13px] font-bold text-gray-800 dark:text-gray-200">{f.title}</span>
              <span className="text-[11px] text-gray-400 dark:text-gray-500 mt-0.5 leading-snug">{f.sub}</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
