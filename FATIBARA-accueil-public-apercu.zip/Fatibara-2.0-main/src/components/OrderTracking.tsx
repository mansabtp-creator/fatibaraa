import React, { useEffect, useState } from 'react';
import { supabase } from '../lib/supabase';
import { Delivery } from '../types';
import { Truck, MapPin, Loader2 } from 'lucide-react';
import { orderService } from '../services/orderService';

interface Props {
  orderId: string;
}

export default function OrderTracking({ orderId }: Props) {
  const [delivery, setDelivery] = useState<Delivery | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchDelivery();
    
    // P-WARN-1 FIX: Use a unique channel name scoped to this orderId.
    // The generic 'delivery_updates' name caused all mounted instances to
    // share one channel — duplicate subscriptions + cross-user event leakage.
    const channel = supabase
      .channel(`delivery_updates_${orderId}`)
      .on('postgres_changes', {
        event: 'UPDATE',
        schema: 'public',
        table: 'deliveries',
        filter: `order_id=eq.${orderId}`,
      }, (payload) => {
        setDelivery(payload.new as Delivery);
      })
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [orderId]);

  const fetchDelivery = async () => {
    const res = await orderService.getDeliveryForOrder(orderId);
    if (res.data) setDelivery(res.data);
    setLoading(false);
  };

  if (loading) return <div className="p-4 flex items-center justify-center"><Loader2 className="animate-spin text-orange-500" /></div>;
  if (!delivery) return <div className="p-4 text-sm text-gray-500">Pas d'information de livraison.</div>;

  return (
    <div className="bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-700 rounded-2xl p-6 shadow-sm">
      <h3 className="text-lg font-bold flex items-center gap-2 mb-4">
        <Truck className="text-orange-500" /> Suivi Live
      </h3>
      
      <div className="flex items-center justify-between mb-4">
        <span className="text-sm font-semibold text-gray-600">Statut:</span>
        <span className="px-3 py-1 bg-orange-100 text-orange-700 rounded-full text-xs font-bold uppercase">{delivery.status}</span>
      </div>

      <div className="flex items-center gap-3 text-sm text-gray-700">
        <MapPin className="text-gray-400" />
        <span>Coordonnées: {delivery.current_location.lat}, {delivery.current_location.lng}</span>
      </div>
    </div>
  );
}
