import React, { useState, useEffect, useRef } from 'react';
import { supabase } from '../lib/supabase';
import { APP_NAME } from '../lib/constants';
import { X, AlertCircle, CheckCircle2, Eye, EyeOff } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { useToast } from '../context/ToastContext';
import { useNavigate } from 'react-router-dom';
import { loginSchema, registerSchema, forgotPasswordSchema } from '../lib/validations';
import { z } from 'zod';
import { useAppContext } from '../context/AppContext';
import { getRedirectPathForRole } from '../lib/auth-redirect';

type AuthMode = 'login' | 'signup' | 'forgot_password' | 'success_signup' | 'success_reset';

export default function AuthModal({ isOpen, onClose }: { isOpen: boolean, onClose: () => void }) {
  const { user, isProfileReady, activeRole } = useAppContext();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [fullName, setFullName] = useState('');
  const [authMode, setAuthMode] = useState<AuthMode>('login');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [errors, setErrors] = useState<{ email?: string, password?: string, confirmPassword?: string, full_name?: string }>({});
  const { showToast } = useToast();
  const navigate = useNavigate();
  // Flag set when login completes — tells the useEffect below to redirect
  // once fetchProfile() has settled and activeRole is the resolved role.
  const pendingRedirect = useRef(false);

  const validateForm = () => {
    try {
      if (authMode === 'login') {
        loginSchema.parse({ email, password });
      } else if (authMode === 'signup') {
        registerSchema.parse({ email, password, full_name: fullName, confirmPassword });
      } else if (authMode === 'forgot_password') {
        forgotPasswordSchema.parse({ email });
      }
      setErrors({});
      return true;
    } catch (err) {
      if (err instanceof z.ZodError) {
        const fieldErrors: { [key: string]: string } = {};
        err.issues.forEach(e => {
          if (e.path[0]) {
            fieldErrors[e.path[0] as string] = e.message;
          }
        });
        setErrors(fieldErrors);
      }
      return false;
    }
  };

  const mapSupabaseError = (error: any) => {
    const msg = error.message?.toLowerCase() || '';
    if (msg.includes('invalid login credentials')) return "Email ou mot de passe incorrect.";
    if (msg.includes('user already registered')) return "Cet email est déjà utilisé.";
    if (msg.includes('rate limit')) return "Trop de tentatives. Veuillez réessayer plus tard.";
    return error.message || "Une erreur est survenue.";
  };

  // ── Post-login redirect (context-driven) ─────────────────────────────────
  // Mirrors the pattern in LoginPage.tsx. After signInWithPassword we set
  // pendingRedirect=true and let this effect fire once fetchProfile() settles.
  // This guarantees the redirect uses the fully-resolved activeRole from context
  // instead of racing a raw DB call against AppContext's own profile fetch.
  useEffect(() => {
    if (!pendingRedirect.current) return;
    if (!isProfileReady || !user) return;
    pendingRedirect.current = false;
    const destination = getRedirectPathForRole(activeRole);
    onClose();
    navigate(destination);
  }, [isProfileReady, activeRole, user, navigate, onClose]);

  const handleAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validateForm()) return;
    
    setLoading(true);
    try {
      if (authMode === 'login') {
        const { data: { user }, error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) throw error;

        // Signal the useEffect above to redirect once isProfileReady settles.
        // Do NOT navigate here — fetchProfile() may not have run yet and
        // activeRole could still be stale from a previous session.
        pendingRedirect.current = true;
        showToast("Connexion réussie !", 'success');
      } else if (authMode === 'signup') {
        const { error } = await supabase.auth.signUp({ 
          email, 
          password,
          options: {
            data: { full_name: fullName }
          }
        });
        if (error) throw error;
        setAuthMode('success_signup');
      } else if (authMode === 'forgot_password') {
        const { error } = await supabase.auth.resetPasswordForEmail(email, {
          redirectTo: window.location.origin + '/reset-password',
        });
        if (error) throw error;
        setAuthMode('success_reset');
      }
    } catch (error: any) {
      if (error instanceof TypeError && error.message === 'Failed to fetch') {
        showToast("Erreur réseau : Impossible de contacter le serveur.", 'error');
      } else {
        showToast(mapSupabaseError(error), 'error');
      }
    } finally {
      setLoading(false);
    }
  };

  const handleGoogle = async () => {
    try {
      setLoading(true);
      const { error } = await supabase.auth.signInWithOAuth({ 
        provider: 'google',
        options: {
          redirectTo: window.location.origin + window.location.pathname
        }
      });
      if (error) throw error;
    } catch (error: any) {
      console.error('Google OAuth error:', error);
      showToast(error.message || 'Échec de la connexion avec Google.', 'error');
    } finally {
      setLoading(false);
    }
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-[10001] flex items-end lg:items-center justify-center">
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="absolute inset-0 bg-gray-900/40 backdrop-blur-md"
          />
          
          <motion.div 
            initial={{ y: "100%", opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: "100%", opacity: 0 }}
            transition={{ type: "spring", damping: 25, stiffness: 200 }}
            className="bg-brand-surface p-8 lg:p-12 w-full lg:max-w-md relative shadow-2xl rounded-t-[3rem] lg:rounded-[3rem] z-10 border border-brand-border"
          >
            <div className="lg:hidden w-16 h-1.5 bg-brand-border rounded-full mx-auto mb-8 opacity-50" />
            
            <button 
              onClick={onClose} 
              className="absolute top-6 right-6 text-brand-foreground bg-brand-bg p-2 rounded-full hover:bg-brand-surface border border-brand-border shadow-sm hidden lg:flex items-center justify-center transition-all"
            >
              <X className="w-5 h-5" />
            </button>
            
            {(authMode === 'success_signup' || authMode === 'success_reset') ? (
              <div className="text-center py-6">
                <div className="w-16 h-16 bg-brand-primary/10 rounded-full flex items-center justify-center mx-auto mb-6">
                  <CheckCircle2 className="w-8 h-8 text-brand-primary" />
                </div>
                <h2 className="text-2xl font-bold text-brand-foreground tracking-tight mb-3">
                  {authMode === 'success_signup' ? 'Vérifiez votre email' : 'Email envoyé'}
                </h2>
                <p className="text-brand-text-dim text-sm font-medium mb-8 leading-relaxed">
                  {authMode === 'success_signup' 
                    ? "Nous vous avons envoyé un lien de confirmation. Veuillez cliquer dessus pour activer votre compte." 
                    : "Un lien pour réinitialiser votre mot de passe vous a été envoyé par email."}
                </p>
                <button 
                  onClick={() => { setAuthMode('login'); onClose(); }}
                  className="w-full bg-brand-primary text-brand-inverse rounded-xl py-4 font-semibold text-[15px] hover:brightness-110 transition-all"
                >
                  Fermer
                </button>
              </div>
            ) : (
              <>
                <h2 className="text-3xl font-bold mb-8 text-brand-foreground tracking-tighter uppercase text-center lg:text-left">
                  {authMode === 'login' ? 'Bon retour !' : authMode === 'signup' ? `Rejoindre ${APP_NAME}` : 'Mot de passe oublié'}
                </h2>
                
                <form onSubmit={handleAuth} className="space-y-5">
                  {authMode === 'signup' && (
                    <div className="space-y-1.5">
                      <span className="text-[10px] font-bold tracking-wider text-brand-text-dim ml-4">NOM COMPLET</span>
                      <input 
                        type="text" 
                        placeholder="Jean Dupont" 
                        value={fullName} 
                        disabled={loading}
                        onChange={e => { setFullName(e.target.value); if (errors.full_name) setErrors({...errors, full_name: undefined}); }} 
                        className={`w-full bg-brand-bg border ${errors.full_name ? 'border-red-500' : 'border-brand-border'} rounded-[1.5rem] p-4 text-[14px] font-bold tracking-tight text-brand-foreground focus:outline-none focus:border-brand-primary shadow-inner transition-all disabled:opacity-50`} 
                        required 
                      />
                      {errors.full_name && (
                        <div className="flex items-center gap-1.5 text-red-500 text-xs mt-1 ml-4 font-bold uppercase tracking-wider">
                          <AlertCircle className="w-3.5 h-3.5" />
                          <span>{errors.full_name}</span>
                        </div>
                      )}
                    </div>
                  )}

                  <div className="space-y-1.5">
                    <span className="text-[10px] font-bold tracking-wider text-brand-text-dim ml-4">VOTRE EMAIL</span>
                    <input 
                      type="email" 
                      placeholder="votre@email.com" 
                      value={email} 
                      disabled={loading}
                      onChange={e => { setEmail(e.target.value); if (errors.email) setErrors({...errors, email: undefined}); }} 
                      className={`w-full bg-brand-bg border ${errors.email ? 'border-red-500' : 'border-brand-border'} rounded-[1.5rem] p-4 text-[14px] font-bold uppercase tracking-tight text-brand-foreground focus:outline-none focus:border-brand-primary shadow-inner transition-all disabled:opacity-50`} 
                      required 
                    />
                    {errors.email && (
                      <div className="flex items-center gap-1.5 text-red-500 text-xs mt-1 ml-4 font-bold uppercase tracking-wider">
                        <AlertCircle className="w-3.5 h-3.5" />
                        <span>{errors.email}</span>
                      </div>
                    )}
                  </div>

                  {authMode !== 'forgot_password' && (
                    <div className="space-y-1.5">
                      <div className="flex items-center justify-between">
                        <span className="text-[10px] font-bold tracking-wider text-brand-text-dim ml-4">MOT DE PASSE</span>
                        {authMode === 'login' && (
                          <button 
                            type="button"
                            onClick={() => { setAuthMode('forgot_password'); setErrors({}); }}
                            className="text-[10px] font-bold text-brand-primary hover:underline uppercase tracking-wider mr-4"
                          >
                            Oublié ?
                          </button>
                        )}
                      </div>
                      <div className="relative">
                        <input 
                          type={showPassword ? "text" : "password"} 
                          placeholder="••••••••" 
                          value={password} 
                          disabled={loading}
                          onChange={e => { setPassword(e.target.value); if (errors.password) setErrors({...errors, password: undefined}); }} 
                          className={`w-full bg-brand-bg border ${errors.password ? 'border-red-500' : 'border-brand-border'} rounded-[1.5rem] p-4 pr-12 text-[14px] font-bold uppercase tracking-tight text-brand-foreground focus:outline-none focus:border-brand-primary shadow-inner transition-all disabled:opacity-50`} 
                          required 
                        />
                        <button
                          type="button"
                          onClick={() => setShowPassword(!showPassword)}
                          className="absolute right-4 top-1/2 -translate-y-1/2 text-brand-text-dim hover:text-brand-foreground transition-colors focus:outline-none flex items-center justify-center"
                        >
                          {showPassword ? (
                            <EyeOff className="w-5 h-5" />
                          ) : (
                            <Eye className="w-5 h-5" />
                          )}
                        </button>
                      </div>
                      {errors.password && (
                        <div className="flex items-center gap-1.5 text-red-500 text-xs mt-1 ml-4 font-bold uppercase tracking-wider">
                          <AlertCircle className="w-3.5 h-3.5" />
                          <span>{errors.password}</span>
                        </div>
                      )}
                    </div>
                  )}

                  {authMode === 'signup' && (
                    <div className="space-y-1.5">
                      <span className="text-[10px] font-bold tracking-wider text-brand-text-dim ml-4">CONFIRMER LE MOT DE PASSE</span>
                      <div className="relative">
                        <input 
                          type={showPassword ? "text" : "password"} 
                          placeholder="••••••••" 
                          value={confirmPassword} 
                          disabled={loading}
                          onChange={e => { setConfirmPassword(e.target.value); if (errors.confirmPassword) setErrors({...errors, confirmPassword: undefined}); }} 
                          className={`w-full bg-brand-bg border ${errors.confirmPassword ? 'border-red-500' : 'border-brand-border'} rounded-[1.5rem] p-4 pr-12 text-[14px] font-bold uppercase tracking-tight text-brand-foreground focus:outline-none focus:border-brand-primary shadow-inner transition-all disabled:opacity-50`} 
                          required 
                        />
                        <button
                          type="button"
                          onClick={() => setShowPassword(!showPassword)}
                          className="absolute right-4 top-1/2 -translate-y-1/2 text-brand-text-dim hover:text-brand-foreground transition-colors focus:outline-none flex items-center justify-center"
                        >
                          {showPassword ? (
                            <EyeOff className="w-5 h-5" />
                          ) : (
                            <Eye className="w-5 h-5" />
                          )}
                        </button>
                      </div>
                      {errors.confirmPassword && (
                        <div className="flex items-center gap-1.5 text-red-500 text-xs mt-1 ml-4 font-bold uppercase tracking-wider">
                          <AlertCircle className="w-3.5 h-3.5" />
                          <span>{errors.confirmPassword}</span>
                        </div>
                      )}
                    </div>
                  )}

                  <button 
                    type="submit" 
                    disabled={loading} 
                    className="w-full bg-brand-primary text-brand-inverse py-5 rounded-[1.5rem] text-[13px] font-bold tracking-wider shadow-xl shadow-brand-primary/20 hover:brightness-110 transition-all mt-4 flex items-center justify-center gap-3 disabled:opacity-50"
                  >
                    {loading ? (
                      <div className="w-5 h-5 border-2 border-brand-inverse/30 border-t-brand-inverse rounded-full animate-spin" />
                    ) : (
                      <span>
                        {authMode === 'login' ? 'Connexion' : authMode === 'signup' ? "S'inscrire" : 'Envoyer le lien'}
                      </span>
                    )}
                  </button>
                </form>
                
                {authMode !== 'forgot_password' && (
                  <>
                    <div className="mt-8 flex items-center justify-between">
                      <div className="h-[2px] bg-brand-border flex-1"></div>
                      <span className="px-4 text-[10px] tracking-wider text-brand-text-dim font-bold">ALTERNATIVE</span>
                      <div className="h-[2px] bg-brand-border flex-1"></div>
                    </div>

                    <div className="mt-6">
                      <button 
                        onClick={handleGoogle} 
                        disabled={loading}
                        className="w-full border border-brand-border py-4 rounded-[1.5rem] text-[12px] font-bold tracking-wider text-brand-foreground hover:bg-brand-bg transition-all flex items-center justify-center gap-4 bg-brand-surface shadow-sm disabled:opacity-50"
                      >
                        <svg className="w-5 h-5" viewBox="0 0 24 24">
                          <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
                          <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
                          <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" />
                          <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" />
                        </svg>
                        Google
                      </button>
                    </div>
                  </>
                )}
                
                <p className="mt-8 text-[11px] text-center text-brand-text-dim font-bold tracking-wider">
                  {authMode === 'forgot_password' ? (
                    <span 
                      onClick={() => { setAuthMode('login'); setErrors({}); }}
                      className="text-brand-primary cursor-pointer hover:underline p-2 inline-block uppercase"
                    >
                      Retour à la connexion
                    </span>
                  ) : (
                    <>
                      {authMode === 'login' ? `Nouveau sur ${APP_NAME} ? ` : "Déjà membre ? "}
                      <span 
                        onClick={() => { setAuthMode(authMode === 'login' ? 'signup' : 'login'); setErrors({}); }}
                        className="text-brand-primary cursor-pointer hover:underline p-2 inline-block"
                      >
                        {authMode === 'login' ? "Créer un compte" : "Se connecter"}
                      </span>
                    </>
                  )}
                </p>
              </>
            )}
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}
