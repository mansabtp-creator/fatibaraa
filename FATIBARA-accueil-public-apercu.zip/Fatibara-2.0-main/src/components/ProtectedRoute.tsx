/**
 * ProtectedRoute.tsx — Role-Enforced Route Guard Component
 *
 * Wraps any route element to enforce authentication and optional role-based
 * access control. Designed to be race-condition-free by waiting for both
 * `isAuthLoading` AND `isProfileReady` before making any redirect decisions.
 *
 * Usage:
 *   <ProtectedRoute>                        // auth-only, any role
 *     <SomePage />
 *   </ProtectedRoute>
 *
 *   <ProtectedRoute allowedRoles={['admin', 'vendor']}>
 *     <AdminPanel />
 *   </ProtectedRoute>
 */

import React, { ReactNode } from 'react';
import { Navigate, useLocation } from 'react-router-dom';
import { useAppContext } from '../context/AppContext';
import { UserRole, getHomeRouteForRole } from '../utils/routes';
import { normalizeToCanonicalRole } from '../lib/auth-redirect';

interface ProtectedRouteProps {
  /** The route content to render when access is granted. */
  children: ReactNode;
  /**
   * Optional whitelist of roles that may access this route.
   * If omitted, any authenticated user is allowed.
   * Compared case-insensitively against `activeRole`.
   */
  allowedRoles?: UserRole[];
}

/**
 * Full-page spinner shown while auth / profile is loading.
 * Intentionally minimal to avoid layout shift.
 */
function AuthLoadingScreen() {
  return (
    <div
      className="min-h-screen flex items-center justify-center bg-white dark:bg-gray-950"
      role="status"
      aria-label="Chargement en cours…"
    >
      <div className="flex flex-col items-center gap-4">
        <div className="w-10 h-10 border-2 border-[#ff6600]/30 border-t-[#ff6600] rounded-full animate-spin" />
        <p className="text-[13px] font-medium text-gray-400 dark:text-gray-500 tracking-wide">
          Chargement…
        </p>
      </div>
    </div>
  );
}

export default function ProtectedRoute({ children, allowedRoles }: ProtectedRouteProps) {
  const { isAuthLoading, isProfileReady, user, activeRole } = useAppContext();
  const location = useLocation();

  // ── Phase 1: Loading ───────────────────────────────────────────────────────
  // Hold rendering until BOTH the Supabase session check AND the profile
  // fetch are complete. This prevents:
  //  - Premature redirect to /login before the session is confirmed
  //  - Premature redirect to a dashboard before the role is known
  if (isAuthLoading || !isProfileReady) {
    return <AuthLoadingScreen />;
  }

  // ── Phase 2: Authentication check ─────────────────────────────────────────
  // Not logged in → send to /login, preserving the intended destination so
  // the login page can redirect back after authentication.
  if (!user) {
    return (
      <Navigate
        to="/login"
        state={{ from: location }}
        replace
      />
    );
  }

  // ── Phase 3: Role-based access control ──────────────────────────────────────────
  // If allowedRoles is specified, verify the user's active role is in the list.
  // On mismatch: redirect to the user's OWN home route (not to /login) so they
  // land somewhere valid rather than being locked out.
  //
  // normalizeToCanonicalRole() ensures 'courier' and 'livreur' are treated as
  // the same canonical role, regardless of which variant is stored in the DB.
  if (allowedRoles && allowedRoles.length > 0) {
    const normalizedActive = normalizeToCanonicalRole(activeRole.toLowerCase());
    const isAllowed = allowedRoles.some(
      r => normalizeToCanonicalRole(r.toLowerCase()) === normalizedActive
    );

    if (!isAllowed) {
      const homeRoute = getHomeRouteForRole(activeRole);
      return <Navigate to={homeRoute} replace />;
    }
  }

  // ── Phase 4: Render ───────────────────────────────────────────────────────
  return <>{children}</>;
}
