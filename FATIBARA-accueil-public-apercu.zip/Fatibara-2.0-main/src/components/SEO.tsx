import React from 'react';
import { Helmet } from 'react-helmet-async';
import { APP_NAME, APP_DESCRIPTION } from '../lib/constants';

interface SEOProps {
  title?: string;
  description?: string;
  image?: string;
  url?: string;
  type?: string;
  keywords?: string;
  /** Optional: price string for product pages (e.g. "50 000 GNF") */
  price?: string;
}

const SITE_URL = 'https://fatibara.com';
const DEFAULT_OG_IMAGE = `${SITE_URL}/og-default.jpg`;

const SEO: React.FC<SEOProps> = ({
  title,
  description,
  image,
  url,
  type = 'website',
  keywords,
  price,
}) => {
  const fullTitle = title
    ? `${title} | ${APP_NAME}`
    : `${APP_NAME} | Le Marché Local de Guinée`;
  const metaDescription = description || APP_DESCRIPTION;
  const metaKeywords = keywords || `${APP_NAME}, Guinée, Conakry, marketplace, shopping`;
  const metaImage = image || DEFAULT_OG_IMAGE;
  const metaUrl = url || SITE_URL;

  return (
    <Helmet>
      {/* ── Standard ──────────────────────────────────────────────────── */}
      <title>{fullTitle}</title>
      <meta name="description" content={metaDescription} />
      <meta name="keywords" content={metaKeywords} />
      <link rel="canonical" href={metaUrl} />

      {/* ── Open Graph (WhatsApp, Facebook, Telegram, iMessage) ────────── */}
      <meta property="og:site_name" content={APP_NAME} />
      <meta property="og:type" content={type} />
      <meta property="og:title" content={fullTitle} />
      <meta property="og:description" content={metaDescription} />
      <meta property="og:image" content={metaImage} />
      <meta property="og:image:secure_url" content={metaImage} />
      <meta property="og:image:width" content="1200" />
      <meta property="og:image:height" content="630" />
      <meta property="og:image:alt" content={fullTitle} />
      <meta property="og:url" content={metaUrl} />
      <meta property="og:locale" content="fr_GN" />

      {/* ── Product-specific OG (when type="product") ─────────────────── */}
      {type === 'product' && price && (
        <meta property="product:price.amount" content={price} />
      )}
      {type === 'product' && (
        <meta property="product:price.currency" content="GNF" />
      )}

      {/* ── Twitter / X Card ──────────────────────────────────────────── */}
      <meta name="twitter:card" content="summary_large_image" />
      <meta name="twitter:site" content={`@${APP_NAME.toLowerCase()}`} />
      <meta name="twitter:creator" content={`@${APP_NAME.toLowerCase()}`} />
      <meta name="twitter:title" content={fullTitle} />
      <meta name="twitter:description" content={metaDescription} />
      <meta name="twitter:image" content={metaImage} />
      <meta name="twitter:image:alt" content={fullTitle} />
    </Helmet>
  );
};

export default SEO;
