import React, { Component, ErrorInfo, ReactNode } from 'react';
import { AlertCircle, RefreshCw } from 'lucide-react';

// ─── Props / State ────────────────────────────────────────────────────────────

interface Props {
  children: ReactNode;
  /**
   * Optional custom fallback UI.
   *
   * - Omit (default): renders the full-page error screen (top-level app boundary).
   * - Pass a ReactNode: renders it inline (component-level boundaries, e.g. VendorInbox).
   * - Pass `null`: silently swallows the error — renders nothing (non-critical
   *   floating widgets like AIStyleAdvisor).
   */
  fallback?: ReactNode | null;
  /**
   * Called after the boundary catches an error (hook for Sentry / analytics).
   */
  onError?: (error: Error, errorInfo: ErrorInfo) => void;
}

interface State {
  hasError: boolean;
  error: Error | null;
}

// ─── ErrorBoundary ────────────────────────────────────────────────────────────

export class ErrorBoundary extends Component<Props, State> {
  // Explicit field declarations required by tsconfig `useDefineForClassFields: false`
  props: Readonly<Props>;
  state: State = { hasError: false, error: null };

  constructor(props: Props) {
    super(props);
    this.props = props;
  }

  static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error };
  }

  componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error('[ErrorBoundary] Caught error:', error, errorInfo);

    // Auto-reload once on Vite chunk fetch failures (network hiccup on deploy).
    // Uses href reassignment (not .reload()) to force a clean load from CDN edge,
    // while keeping a session-storage guard to prevent an infinite reload loop.
    if (
      error.message.includes('Failed to fetch') ||
      error.message.includes('dynamically imported module') ||
      error.message.includes('Importing a module script failed')
    ) {
      const reloadKey = 'vite_chunk_failed_reload';
      if (!sessionStorage.getItem(reloadKey)) {
        sessionStorage.setItem(reloadKey, 'true');
        // Navigate to same URL instead of hard reload — keeps browser history intact
        // and avoids Playwright context closure during testing
        const currentPath = window.location.pathname + window.location.search;
        window.location.replace(currentPath);
      }
    }

    // Forward to external error reporter (Sentry etc.) if wired up
    this.props.onError?.(error, errorInfo);
  }

  render() {
    if (!this.state.hasError) {
      return this.props.children;
    }

    // ── null fallback: silent mode — widget disappears without crashing page ──
    if (this.props.fallback === null) {
      return null;
    }

    // ── Custom ReactNode fallback provided ────────────────────────────────────
    if (this.props.fallback !== undefined) {
      return <>{this.props.fallback}</>;
    }

    // ── Default: full-page error screen (top-level app boundary) ─────────────
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50 dark:bg-gray-800 p-8">
        <div className="bg-white dark:bg-gray-900 p-12 rounded-[3rem] border border-brand-border/30 shadow-2xl text-center max-w-lg">
          <div className="w-20 h-20 bg-red-50 rounded-full flex items-center justify-center mx-auto mb-8">
            <AlertCircle className="w-10 h-10 text-red-500" />
          </div>
          <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">
            Une erreur inattendue est survenue
          </h2>
          <p className="text-brand-text-muted mb-8 font-medium">
            Nos équipes ont été notifiées. Veuillez rafraîchir la page ou retourner au tableau de bord.
          </p>
          <button
            onClick={() => (window.location.href = '/dashboard')}
            className="bg-gray-900 text-brand-inverse px-8 py-4 rounded-full font-bold tracking-wider text-[12px] hover:bg-black transition-all"
          >
            Retour au tableau de bord
          </button>
        </div>
      </div>
    );
  }
}

// ─── InlineErrorFallback ──────────────────────────────────────────────────────

/**
 * Standard inline error panel for use inside vendor layout sections.
 * Includes a "Réessayer" button that triggers a boundary reset via remount.
 */
export function InlineErrorFallback({
  label = 'Ce module a rencontré une erreur',
  onRetry,
}: {
  label?: string;
  onRetry?: () => void;
}) {
  return (
    <div className="flex flex-col items-center justify-center h-full min-h-[240px] gap-4 p-8 text-center">
      <div className="w-14 h-14 bg-red-50 dark:bg-red-500/10 rounded-2xl flex items-center justify-center">
        <AlertCircle className="w-7 h-7 text-red-500" />
      </div>
      <div>
        <p className="text-[13px] font-black text-gray-900 dark:text-white uppercase tracking-tight">
          {label}
        </p>
        <p className="text-[11px] text-gray-400 font-bold tracking-wider mt-1">
          Une erreur de connexion est survenue. Vérifiez votre réseau.
        </p>
      </div>
      {onRetry && (
        <button
          onClick={onRetry}
          className="flex items-center gap-2 px-5 py-2.5 bg-[#ff6600] text-white rounded-xl text-[11px] font-black tracking-widest uppercase hover:bg-[#e65c00] transition-colors"
        >
          <RefreshCw className="w-3.5 h-3.5" />
          Réessayer
        </button>
      )}
    </div>
  );
}

// ─── InlineBoundary ───────────────────────────────────────────────────────────

/**
 * Convenience wrapper that renders `InlineErrorFallback` on crash, with a
 * "Réessayer" button that resets the boundary via key-based remount.
 *
 * Usage:
 *   <InlineBoundary label="Messagerie — erreur de connexion">
 *     <VendorInbox storeId={...} currentUserId={...} />
 *   </InlineBoundary>
 */
export function InlineBoundary({
  children,
  label,
  onError,
}: {
  children: ReactNode;
  label?: string;
  onError?: (error: Error, errorInfo: ErrorInfo) => void;
}) {
  const [retryKey, setRetryKey] = React.useState(0);

  // Wrapping in React.Fragment with a changing key causes React to unmount and
  // remount the entire subtree (including the ErrorBoundary) on retry, which
  // resets all boundary state cleanly without needing an internal reset method.
  return (
    <React.Fragment key={retryKey}>
      <ErrorBoundary
        fallback={
          <InlineErrorFallback
            label={label}
            onRetry={() => setRetryKey(k => k + 1)}
          />
        }
        onError={onError}
      >
        {children}
      </ErrorBoundary>
    </React.Fragment>
  );
}
