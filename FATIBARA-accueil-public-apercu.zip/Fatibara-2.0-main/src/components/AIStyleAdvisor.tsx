import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Send, Loader2 } from 'lucide-react';
import { APP_NAME, PARENT_BRAND } from '../lib/constants';
import { getShoppingAdvice } from '../services/geminiService';

export default function AIStyleAdvisor() {
  const [isOpen, setIsOpen] = useState(false);
  const [isModalOpen, setIsModalOpen] = useState(false); // true when another modal/sheet is active
  const [messages, setMessages] = useState<{ role: 'user' | 'model'; text: string }[]>([
    { role: 'model', text: `Salut! Je suis Aissata, votre assistante virtuelle ${APP_NAME}. Comment puis-je vous aider aujourd'hui ?` }
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Watch for data-modal-open attribute on <body> set by wallet / modals
  useEffect(() => {
    const read = () =>
      setIsModalOpen(document.body.getAttribute('data-modal-open') === 'true');
    read(); // initial read
    const obs = new MutationObserver(read);
    obs.observe(document.body, { attributes: true, attributeFilter: ['data-modal-open'] });
    return () => obs.disconnect();
  }, []);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isLoading]);

  const handleSend = async () => {
    if (!input.trim() || isLoading) return;

    const userMessage = input.trim();
    setInput('');
    setMessages(prev => [...prev, { role: 'user', text: userMessage }]);
    setIsLoading(true);

    const advice = await getShoppingAdvice(userMessage, messages);
    
    setMessages(prev => [...prev, { role: 'model', text: advice }]);
    setIsLoading(false);
  };

  return (
    <>
      {/* Floating Button — hidden when any modal/sheet is active */}
      <AnimatePresence>
        {!isModalOpen && (
          <motion.button
            key="ai-fab"
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.8 }}
            transition={{ duration: 0.18 }}
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.9 }}
            onClick={() => setIsOpen(true)}
            className="fixed bottom-[100px] right-6 md:bottom-12 md:right-12 w-14 h-14 bg-gray-900 dark:bg-[#ff6600] text-brand-inverse rounded-full flex items-center justify-center shadow-lg z-[9000] border border-[#ff6600]/20 overflow-hidden group"
          >
            <img
              src="https://miizhdzuxidilrzwdivk.supabase.co/storage/v1/object/public/assets/assiata.png"
              alt="Aissata"
              className="w-full h-full object-cover rounded-full"
              referrerPolicy="no-referrer"
            />
          </motion.button>
        )}
      </AnimatePresence>

      {/* Chat Window */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 100, scale: 0.8 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 100, scale: 0.8 }}
            className="fixed bottom-24 right-4 md:bottom-32 md:right-12 w-[calc(100vw-2rem)] sm:w-[450px] md:w-[480px] h-[75vh] max-h-[800px] min-h-[450px] bg-white dark:bg-gray-900 border border-brand-border/40 dark:border-white/10 rounded-[2rem] shadow-2xl z-[10005] flex flex-col overflow-hidden"
          >
            {/* Header */}
            <div className="bg-gray-900 dark:bg-gray-950 text-brand-inverse p-5 md:p-6 flex justify-between items-center shrink-0 border-b border-white/5">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 md:w-12 md:h-12 bg-orange-500 rounded-full overflow-hidden shadow-lg border-2 border-white/10">
                  <img 
                    src="https://miizhdzuxidilrzwdivk.supabase.co/storage/v1/object/public/assets/assiata.png" 
                    alt="Aissata"
                    className="w-full h-full object-cover"
                    referrerPolicy="no-referrer"
                  />
                </div>
                <div>
                  <h3 className="font-bold text-sm md:text-base tracking-wide">Aissata</h3>
                  <div className="flex items-center gap-1.5 mt-0.5">
                    <div className="w-2 h-2 rounded-full bg-green-500 shadow-[0_0_8px_rgba(34,197,94,0.6)] animate-pulse" />
                    <span className="text-[11px] font-medium text-white/70 tracking-wider uppercase">En ligne</span>
                  </div>
                </div>
              </div>
              <button onClick={() => setIsOpen(false)} className="p-2 hover:bg-white/10 rounded-full transition-colors text-white/80 hover:text-white">
                <X className="w-6 h-6" />
              </button>
            </div>

            {/* Messages */}
            <div className="flex-1 min-h-[0] overflow-y-auto p-4 md:p-6 space-y-6 bg-gray-50 dark:bg-[#0a0a0a] scrollbar-thin scrollbar-thumb-gray-300 dark:scrollbar-thumb-gray-800 scrollbar-track-transparent">
              {messages.map((m, i) => (
                <motion.div 
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  key={i} 
                  className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}
                >
                  <div className={`max-w-[85%] sm:max-w-[80%] p-4 rounded-2xl text-[14px] leading-relaxed shadow-sm ${
                    m.role === 'user' 
                      ? 'bg-orange-500 text-white rounded-br-sm' 
                      : 'bg-white dark:bg-gray-900 border border-gray-200 dark:border-white/5 text-gray-800 dark:text-gray-200 rounded-bl-sm'
                  }`}>
                    {m.text}
                  </div>
                </motion.div>
              ))}
              {isLoading && (
                <motion.div 
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="flex justify-start"
                >
                  <div className="bg-white dark:bg-gray-900 p-4 rounded-2xl rounded-bl-sm border border-gray-200 dark:border-white/5 flex items-center gap-3 shadow-sm flex-row">
                    <Loader2 className="w-5 h-5 animate-spin text-orange-500" />
                    <span className="text-xs font-semibold tracking-wide text-gray-500 dark:text-gray-400">Aissata réfléchit...</span>
                  </div>
                </motion.div>
              )}
              <div ref={messagesEndRef} className="h-px w-full" />
            </div>

            {/* Input */}
            <div className="p-4 md:p-6 bg-white dark:bg-gray-950 border-t border-gray-200 dark:border-white/5 shrink-0 z-10">
              <div className="relative flex items-center">
                <input
                  type="text"
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  onKeyPress={(e) => e.key === 'Enter' && handleSend()}
                  placeholder="Posez votre question..."
                  className="w-full bg-gray-100 dark:bg-gray-900 border border-transparent focus:border-orange-500 dark:focus:border-orange-500 rounded-xl py-4 pl-5 pr-16 text-[14px] md:text-[15px] font-medium outline-none text-gray-900 dark:text-white transition-all shadow-inner placeholder-gray-400 dark:placeholder-gray-600"
                />
                <button
                  onClick={handleSend}
                  disabled={!input.trim() || isLoading}
                  className="absolute right-2 w-10 h-10 md:w-11 md:h-11 bg-orange-500 text-white rounded-lg flex items-center justify-center hover:bg-orange-600 transition-all disabled:opacity-40 disabled:hover:bg-orange-500 shadow-md"
                >
                  <Send className="w-5 h-5 ml-1" />
                </button>
              </div>
              <p className="text-[10px] text-center text-gray-400 dark:text-gray-600 mt-3 font-semibold tracking-widest uppercase">powered by {PARENT_BRAND}</p>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
