import React from 'react';
import { motion } from 'motion/react';
import { Package, Truck, MapPin, CheckCircle, Clock, ShieldCheck, Box, ChevronRight } from 'lucide-react';

import { APP_NAME } from '../lib/constants';

interface LogisticsStep {
  status: string;
  label: string;
  description: string;
  time?: string;
  isCompleted: boolean;
  isCurrent: boolean;
  icon: any;
}

interface LogisticsTrackerProps {
  orderId: string;
  currentStatus: string;
}

export default function LogisticsTracker({ orderId, currentStatus }: LogisticsTrackerProps) {
  const steps: LogisticsStep[] = [
    { 
      status: 'pending', 
      label: 'Commande Confirmée', 
      description: `Audit de sécurité ${APP_NAME} validé`, 
      time: '12:45',
      isCompleted: ['pending', 'processing', 'shipped', 'delivered'].includes(currentStatus),
      isCurrent: currentStatus === 'pending',
      icon: CheckCircle
    },
    { 
      status: 'processing', 
      label: 'Préparation FATIBARA', 
      description: 'Le vendeur emballe vos articles avec soin', 
      time: '14:20',
      isCompleted: ['processing', 'shipped', 'delivered'].includes(currentStatus),
      isCurrent: currentStatus === 'processing',
      icon: Box
    },
    { 
      status: 'shipped', 
      label: 'Transit National', 
      description: 'En route vers votre centre de distribution local', 
      time: 'En cours',
      isCompleted: ['shipped', 'delivered'].includes(currentStatus),
      isCurrent: currentStatus === 'shipped',
      icon: Truck
    },
    { 
      status: 'delivered', 
      label: 'Livrable', 
      description: 'Prêt pour remise en main propre', 
      isCompleted: currentStatus === 'delivered',
      isCurrent: currentStatus === 'delivered',
      icon: Package
    }
  ];

  return (
    <div className="bg-white dark:bg-[#1A1D21] rounded-[3rem] p-10 border border-gray-100 dark:border-white/5 shadow-sm">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6 mb-12">
        <div>
          <div className="flex items-center gap-3 mb-2">
            <span className="text-[10px] font-black text-[#ff6600] uppercase tracking-[0.3em] italic">Tracking ID FATIBARA</span>
            <div className="px-3 py-1 bg-[#ff6600]/10 text-[#ff6600] rounded-full text-[10px] font-black border border-[#ff6600]/20">
               #{orderId.slice(0, 12).toUpperCase()}
            </div>
          </div>
          <h2 className="text-3xl font-black text-gray-900 dark:text-white uppercase italic tracking-tighter">Status de Livraison</h2>
        </div>
        <div className="bg-gray-50 dark:bg-black/20 p-4 rounded-2xl border border-gray-100 dark:border-white/5 flex items-center gap-4">
           <MapPin className="w-8 h-8 text-blue-500" />
           <div>
              <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest leading-none mb-1">Destination Finale</p>
              <p className="text-[13px] font-black text-gray-900 dark:text-white uppercase italic">Conakry - Kaloum Hub</p>
           </div>
        </div>
      </div>

      <div className="relative">
        {/* Connection Line */}
        <div className="absolute left-[23px] top-6 bottom-6 w-1 bg-gray-100 dark:bg-white/5 md:hidden" />
        <div className="hidden md:block absolute left-6 right-6 top-[23px] h-1 bg-gray-100 dark:bg-white/5" />

        <div className="flex flex-col md:flex-row justify-between gap-10">
          {steps.map((step, i) => (
            <div key={i} className="relative z-10 flex flex-row md:flex-col items-start md:items-center gap-6 md:text-center group">
               {/* Icon Circle */}
               <motion.div 
                 initial={{ scale: 0.8, opacity: 0 }}
                 animate={{ scale: 1, opacity: 1 }}
                 transition={{ delay: i * 0.1 }}
                 className={`w-12 h-12 rounded-2xl flex items-center justify-center border-4 border-white dark:border-[#1A1D21] transition-all duration-500 ${
                   step.isCompleted 
                     ? 'bg-[#ff6600] text-white shadow-lg shadow-[#ff6600]/20' 
                     : step.isCurrent 
                       ? 'bg-white dark:bg-gray-800 text-[#ff6600] border-[#ff6600] animate-pulse'
                       : 'bg-gray-50 dark:bg-black/40 text-gray-400 grayscale'
                 }`}
               >
                 <step.icon className="w-5 h-5" />
               </motion.div>

               <div className="flex flex-col md:items-center">
                  <h4 className={`text-[12px] font-black uppercase tracking-tight mb-1 ${step.isCompleted || step.isCurrent ? 'text-gray-900 dark:text-white' : 'text-gray-400'}`}>
                    {step.label}
                  </h4>
                  <p className="text-[10px] font-bold text-gray-400 dark:text-gray-500 max-w-[150px] leading-tight">
                    {step.description}
                  </p>
                  {step.time && (
                    <span className="mt-2 text-[9px] font-black text-[#ff6600] bg-[#ff6600]/10 px-2.5 py-1 rounded-md uppercase">
                      {step.time}
                    </span>
                  )}
               </div>
            </div>
          ))}
        </div>
      </div>

      <div className="mt-16 p-8 bg-blue-500/5 border border-blue-500/10 rounded-[2rem] flex flex-col md:flex-row items-center justify-between gap-6">
         <div className="flex items-center gap-5">
            <div className="w-14 h-14 bg-blue-500 rounded-2xl flex items-center justify-center text-white shadow-xl shadow-blue-500/20">
               <ShieldCheck className="w-8 h-8" />
            </div>
            <div>
               <h4 className="text-[13px] font-black text-gray-900 dark:text-white uppercase italic tracking-tighter">Audit de Transport {APP_NAME}</h4>
               <p className="text-[11px] font-bold text-gray-400 uppercase tracking-widest mt-0.5">Assurance FATIBARA active sur ce colis</p>
            </div>
         </div>
         <button className="px-8 py-4 bg-white dark:bg-gray-800 text-gray-900 dark:text-white rounded-2xl text-[10px] font-black uppercase tracking-[0.2em] shadow-sm hover:scale-[1.02] active:scale-[0.98] transition-all flex items-center gap-2">
            Contacter le livreur <ChevronRight className="w-4 h-4" />
         </button>
      </div>
    </div>
  );
}
