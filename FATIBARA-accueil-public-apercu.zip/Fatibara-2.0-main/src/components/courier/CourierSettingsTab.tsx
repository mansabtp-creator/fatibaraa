/**
 * CourierSettingsTab — S-1 Component Extraction
 * All state lives in CourierDashboardPage, passed as props.
 */
import React, { useRef } from 'react';
import { motion } from 'framer-motion';
import { Settings2, Camera, CheckCircle, ShieldCheck, LogOut, AlertCircle, Loader2 } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import PushNotificationToggle from '../PushNotificationToggle';
import { supabase } from '../../lib/supabase';

const CONAKRY_COMMUNES = [
  'Ratoma','Matoto','Matam','Kaloum','Dixinn',
  'Lambanyi','Kissosso','Bambeto','Wanindara','Cosa',
  'Sonfonia','Koloma','Nongo',
];

interface SecurityProfile {
  phone_number: string;
  license_plate_number: string;
  vehicle_type: string;
}

export interface CourierSettingsTabProps {
  userId: string;
  avatarUrl: string;
  uploadingAvatar: boolean;
  onAvatarUpload: (file: File) => void;
  courierZone: string;
  setCourierZone: (z: string) => void;
  zoneDirty: boolean;
  setZoneDirty: (d: boolean) => void;
  savingZone: boolean;
  setSavingZone: (s: boolean) => void;
  onZoneSaved: () => void;
  securityProfile: SecurityProfile;
  setSecurityProfile: React.Dispatch<React.SetStateAction<SecurityProfile>>;
  securityProfileDirty: boolean;
  setSecurityProfileDirty: (d: boolean) => void;
  savingSecurityProfile: boolean;
  setSavingSecurityProfile: (s: boolean) => void;
  isOnline: boolean;
  togglingOnline: boolean;
  toggleOnline: () => void;
  chimeEnabled: boolean;
  setChimeEnabled: (e: boolean) => void;
  stopChime: () => void;
  showToast: (msg: string, type: 'success' | 'error' | 'info') => void;
  hapticFeedback: (type: 'success' | 'error' | 'light') => void;
}

export default function CourierSettingsTab({
  userId, avatarUrl, uploadingAvatar, onAvatarUpload,
  courierZone, setCourierZone, zoneDirty, setZoneDirty, savingZone, setSavingZone, onZoneSaved,
  securityProfile, setSecurityProfile, securityProfileDirty, setSecurityProfileDirty,
  savingSecurityProfile, setSavingSecurityProfile,
  isOnline, togglingOnline, toggleOnline,
  chimeEnabled, setChimeEnabled, stopChime,
  showToast, hapticFeedback,
}: CourierSettingsTabProps) {
  const navigate = useNavigate();
  const avatarFileRef = useRef<HTMLInputElement>(null);

  const handleSaveZone = async () => {
    setSavingZone(true);
    const { error } = await supabase.from('profiles')
      .update({ courier_zone: courierZone || null })
      .eq('id', userId);
    setSavingZone(false);
    if (!error) {
      onZoneSaved();
      showToast(courierZone ? `Zone "${courierZone}" enregistrée ✓` : 'Zone réinitialisée ✓', 'success');
    }
  };

  const handleSaveSecurityProfile = async () => {
    setSavingSecurityProfile(true);
    const { error } = await supabase.from('profiles').update({
      phone_number: securityProfile.phone_number || null,
      license_plate_number: securityProfile.license_plate_number || null,
      vehicle_type: securityProfile.vehicle_type,
    }).eq('id', userId);
    setSavingSecurityProfile(false);
    if (!error) {
      setSecurityProfileDirty(false);
      showToast('Profil de sécurité mis à jour ✓', 'success');
      hapticFeedback('success');
    } else {
      showToast(error.message, 'error');
    }
  };

  return (
    <motion.div key="settings" initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} className="space-y-6">
      <h2 className="text-lg font-black text-white uppercase tracking-widest flex items-center gap-2">
        <Settings2 className="w-5 h-5 text-[#ff6600]" /> Préférences Livreur
      </h2>

      {/* Avatar */}
      <input ref={avatarFileRef} type="file" accept="image/*" className="hidden"
        onChange={e => { const f = e.target.files?.[0]; if (f) onAvatarUpload(f); e.target.value = ''; }} />
      <div className="bg-white/[0.03] border border-white/8 rounded-[2rem] p-6 flex items-center gap-5">
        <div className="relative shrink-0">
          <div className="w-20 h-20 rounded-2xl overflow-hidden border border-white/10">
            <img src={avatarUrl || `https://api.dicebear.com/7.x/avataaars/svg?seed=${userId}`} alt="Photo de profil" className="w-full h-full object-cover" />
          </div>
          {uploadingAvatar && (
            <div className="absolute inset-0 bg-black/60 rounded-2xl flex items-center justify-center">
              <Loader2 className="w-6 h-6 text-white animate-spin" />
            </div>
          )}
        </div>
        <div className="flex-1 space-y-2">
          <p className="text-[11px] font-black text-white/70 uppercase tracking-widest">Photo de Profil</p>
          <p className="text-[10px] text-white/30 font-medium">Visible par les clients lors de vos livraisons.</p>
          <button onClick={() => avatarFileRef.current?.click()} disabled={uploadingAvatar}
            className="flex items-center gap-2 px-4 py-2 bg-[#ff6600] hover:bg-[#e65500] disabled:opacity-50 text-white text-[10px] font-black tracking-wider rounded-xl transition-all">
            {uploadingAvatar ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Camera className="w-3.5 h-3.5" />}
            Uploader une photo
          </button>
        </div>
      </div>

      {/* Zone */}
      <div className="bg-white/[0.03] border border-white/8 rounded-[2rem] p-6 space-y-5">
        <div>
          <p className="text-[11px] font-black text-white/60 uppercase tracking-widest mb-1">Zone de livraison préférée</p>
          <p className="text-[10px] text-white/30 font-medium">Les commandes de cette zone seront prioritaires dans votre pool.</p>
        </div>
        <div className="flex flex-wrap gap-2">
          <button onClick={() => { setCourierZone(''); setZoneDirty(true); }}
            className={`px-4 py-2 rounded-xl text-[10px] font-black tracking-wider transition-all border ${courierZone === '' ? 'bg-[#ff6600] text-white border-[#ff6600]' : 'bg-white/5 text-white/40 border-white/10 hover:border-white/20 hover:text-white/70'}`}>
            Toutes les zones
          </button>
          {CONAKRY_COMMUNES.map(commune => (
            <button key={commune} onClick={() => { setCourierZone(commune); setZoneDirty(true); }}
              className={`px-4 py-2 rounded-xl text-[10px] font-black tracking-wider transition-all border ${courierZone === commune ? 'bg-[#ff6600] text-white border-[#ff6600]' : 'bg-white/5 text-white/40 border-white/10 hover:border-white/20 hover:text-white/70'}`}>
              {commune}
            </button>
          ))}
        </div>
        <button disabled={savingZone || !zoneDirty} onClick={handleSaveZone}
          className="w-full py-4 rounded-2xl bg-[#ff6600] hover:bg-[#e62e00] text-white text-[11px] font-black tracking-widest uppercase transition-all disabled:opacity-40 flex items-center justify-center gap-2 shadow-lg shadow-[#ff6600]/20">
          {savingZone ? <Loader2 className="w-4 h-4 animate-spin" /> : <CheckCircle className="w-4 h-4" />}
          {zoneDirty ? 'Enregistrer la zone' : 'Zone enregistrée ✓'}
        </button>
      </div>

      {/* Security Profile */}
      <div className="bg-white/[0.03] border border-white/8 rounded-[2rem] p-6 space-y-5">
        <div className="flex items-center gap-3 mb-2">
          <div className="w-8 h-8 bg-rose-500/10 rounded-xl flex items-center justify-center shrink-0">
            <ShieldCheck className="w-4 h-4 text-rose-400" />
          </div>
          <div>
            <p className="text-[11px] font-black text-white/70 uppercase tracking-widest">Sécurité Livreur</p>
            <p className="text-[10px] text-white/30 font-medium">Requis pour activer le statut En Service</p>
          </div>
        </div>
        {!securityProfile.license_plate_number && (
          <div className="flex items-center gap-2 px-4 py-3 bg-rose-500/10 border border-rose-500/20 rounded-xl">
            <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
            <p className="text-[10px] font-bold text-rose-400 tracking-wide">Plaque manquante — vous ne pouvez pas passer En Service sans ce champ.</p>
          </div>
        )}
        <div className="space-y-4">
          <div className="space-y-2">
            <label className="text-[10px] font-black tracking-widest text-white/40 uppercase">Numéro de Téléphone Professionnel</label>
            <input id="courier-phone-number" type="tel" value={securityProfile.phone_number}
              onChange={e => { setSecurityProfile(p => ({ ...p, phone_number: e.target.value })); setSecurityProfileDirty(true); }}
              placeholder="Ex: 6xx xxx xxx"
              className="w-full bg-white/5 border border-white/10 rounded-xl p-3.5 text-[13px] font-bold text-white focus:border-[#ff6600] outline-none transition-all" />
          </div>
          <div className="space-y-2">
            <label className="text-[10px] font-black tracking-widest text-white/40 uppercase">Plaque d'Immatriculation <span className="text-rose-400">*</span></label>
            <input id="courier-license-plate" type="text" value={securityProfile.license_plate_number}
              onChange={e => { setSecurityProfile(p => ({ ...p, license_plate_number: e.target.value.toUpperCase() })); setSecurityProfileDirty(true); }}
              placeholder="Ex: AB-1234-CD"
              className="w-full bg-white/5 border border-white/10 rounded-xl p-3.5 text-[13px] font-black text-white focus:border-emerald-500 outline-none transition-all tracking-widest" />
            <p className="text-[10px] text-slate-400 font-medium">Obligatoire — requis pour activer le statut En Service</p>
          </div>
          <div className="space-y-2">
            <label className="text-[10px] font-black tracking-widest text-white/40 uppercase">Type de Véhicule</label>
            <div className="grid grid-cols-2 gap-2">
              {(['motorcycle','car','bicycle','foot'] as const).map(type => (
                <button key={type}
                  onClick={() => { setSecurityProfile(p => ({ ...p, vehicle_type: type })); setSecurityProfileDirty(true); }}
                  className={`px-3 py-2.5 rounded-xl text-[10px] font-black tracking-wider transition-all border ${securityProfile.vehicle_type === type ? 'bg-[#ff6600] text-white border-[#ff6600]' : 'bg-white/5 text-white/40 border-white/10 hover:border-white/20 hover:text-white/70'}`}>
                  {type === 'motorcycle' ? '🏍️ Moto' : type === 'car' ? '🚗 Voiture' : type === 'bicycle' ? '🚲 Vélo' : '🚶 À Pied'}
                </button>
              ))}
            </div>
          </div>
          <button id="save-security-profile" disabled={savingSecurityProfile || !securityProfileDirty} onClick={handleSaveSecurityProfile}
            className={`w-full py-3.5 rounded-2xl text-[11px] font-black tracking-widest uppercase transition-all flex items-center justify-center gap-2 ${securityProfileDirty ? 'bg-emerald-500 hover:bg-emerald-400 text-white shadow-lg shadow-emerald-500/20' : 'bg-white/5 text-slate-500 cursor-not-allowed'}`}>
            {savingSecurityProfile ? <Loader2 className="w-4 h-4 animate-spin" /> : <ShieldCheck className="w-4 h-4" />}
            Enregistrer le profil de sécurité
          </button>
        </div>
      </div>

      {/* Sound Toggle */}
      <div className="bg-white/[0.03] border border-white/8 rounded-[2rem] p-6 flex items-center justify-between">
        <div>
          <p className="text-[11px] font-black text-white/60 uppercase tracking-widest mb-1">Son de notification</p>
          <p className="text-[10px] text-white/30 font-medium">Alerte sonore lors d'une nouvelle course disponible.</p>
        </div>
        <button onClick={() => { const next = !chimeEnabled; setChimeEnabled(next); localStorage.setItem('courier_chime', String(next)); if (!next) stopChime(); }}
          className={`relative w-14 h-7 rounded-full transition-all ${chimeEnabled ? 'bg-[#ff6600]' : 'bg-white/10'}`}>
          <span className={`absolute top-0.5 w-6 h-6 bg-white rounded-full shadow-md transition-all ${chimeEnabled ? 'left-7' : 'left-0.5'}`} />
        </button>
      </div>

      {/* Online Status */}
      <div className="bg-white/[0.03] border border-white/8 rounded-[2rem] p-6 flex items-center justify-between">
        <div>
          <p className="text-[11px] font-black text-white/60 uppercase tracking-widest mb-1">Statut de service</p>
          <p className="text-[10px] text-white/30 font-medium">{isOnline ? 'Vous êtes en ligne — visible dans le pool' : 'Vous êtes hors ligne — non visible'}</p>
          {!securityProfile.license_plate_number && !isOnline && (
            <p className="text-[9px] text-rose-400 font-bold mt-1">⚠ Plaque requise pour activer</p>
          )}
        </div>
        <button onClick={toggleOnline} disabled={togglingOnline}
          className={`relative w-14 h-7 rounded-full transition-all ${isOnline ? 'bg-emerald-500' : 'bg-white/10'}`}>
          <span className={`absolute top-0.5 w-6 h-6 bg-white rounded-full shadow-md transition-all ${isOnline ? 'left-7' : 'left-0.5'}`} />
        </button>
      </div>

      {/* Push Notifications */}
      <div className="bg-white/[0.03] border border-white/8 rounded-[2rem] p-6">
        <p className="text-[11px] font-black text-white/60 uppercase tracking-widest mb-4">Notifications Push</p>
        <PushNotificationToggle />
      </div>

      {/* Logout */}
      <button
        onClick={async () => { try { await supabase.auth.signOut(); } catch (err) { console.error('Courier logout error:', err); } navigate('/'); }}
        className="w-full flex items-center justify-center gap-3 py-4 rounded-2xl bg-rose-500/10 border border-rose-500/20 text-rose-400 hover:bg-rose-500/20 hover:border-rose-500/30 text-[11px] font-black tracking-widest uppercase transition-all">
        <LogOut className="w-4 h-4" />
        Se déconnecter
      </button>
    </motion.div>
  );
}
