import { motion, AnimatePresence } from 'motion/react';
import { ReactNode, useEffect } from 'react';
import { useStore } from '../store/useStore';

interface PageTransitionProps {
  children: ReactNode;
}

export default function PageTransition({ children }: PageTransitionProps) {
  const { modeEconomie, setIsNavigating } = useStore();

  useEffect(() => {
    setIsNavigating(false);
    return () => setIsNavigating(true);
  }, [setIsNavigating]);

  return (
    <motion.div
      initial={{ opacity: modeEconomie ? 1 : 0, scale: modeEconomie ? 1 : 0.98, y: modeEconomie ? 0 : 4 }}
      animate={{ opacity: 1, scale: 1, y: 0 }}
      exit={{ opacity: modeEconomie ? 1 : 0, scale: modeEconomie ? 1 : 1.02, y: modeEconomie ? 0 : -4 }}
      transition={{ 
        duration: modeEconomie ? 0 : 0.4, 
        ease: [0.16, 1, 0.3, 1] 
      }}
      className="w-full h-full"
    >
      {children}
    </motion.div>
  );
}
