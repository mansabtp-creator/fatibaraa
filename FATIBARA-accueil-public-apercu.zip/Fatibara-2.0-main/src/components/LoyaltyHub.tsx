import React, { useState } from 'react';
import { Award, Gift, Share2, Copy, Check, Users, Star, ArrowRight } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { APP_NAME } from '../lib/constants';
import { useToast } from '../context/ToastContext';

import { shareProduct } from '../lib/share';

interface LoyaltyHubProps {
  points: number;
  referralCode: string | null;
}

export default function LoyaltyHub({ points, referralCode }: LoyaltyHubProps) {
  const [copied, setCopied] = useState(false);
  const { showToast } = useToast();

  const handleShare = async () => {
    if (!referralCode) return;
    const shareUrl = `${window.location.origin}/login?ref=${referralCode}`;
    const shareTitle = `Rejoignez-moi sur ${APP_NAME}`;
    
    await shareProduct(shareTitle, shareUrl, showToast);
    
    // Check if it was copied (fallback)
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleCopy = () => {
    if (!referralCode) return;
    const shareUrl = `${window.location.origin}/login?ref=${referralCode}`;
    navigator.clipboard.writeText(shareUrl);
    setCopied(true);
    showToast("Lien de parrainage copié !", "success");
    setTimeout(() => setCopied(false), 2000);
  };

  const nextTierPoints = 2500;
  const progress = (points / nextTierPoints) * 100;

  return (
    <div className="space-y-6">
      {/* VIP Card */}
      <div className="relative bg-gradient-to-br from-brand-foreground to-[#0f172a] p-8 rounded-[3rem] overflow-hidden shadow-2xl border border-white/5">
        {/* Abstract shapes */}
        <div className="absolute top-0 right-0 w-80 h-80 bg-[#ff6600] opacity-20 rounded-full blur-[100px] -mr-40 -mt-40" />
        <div className="absolute bottom-0 left-0 w-64 h-64 bg-[#ff6600] opacity-5 rounded-full blur-[80px] -ml-32 -mb-32" />
        
        <div className="relative z-10 flex flex-col h-full justify-between">
          <div className="flex justify-between items-start mb-8">
            <div>
              <div className="flex items-center gap-2 mb-1">
                <Star className="w-4 h-4 text-[#ff6600] fill-[#ff6600]" />
                <span className="text-[10px] font-bold tracking-wider text-[#ff6600]">Membre Privilège</span>
              </div>
              <h2 className="text-2xl font-bold text-white tracking-tight">{APP_NAME} Club</h2>
            </div>
            <div className="w-12 h-12 bg-white/10 rounded-2xl flex items-center justify-center backdrop-blur-md border border-white/20">
              <Award className="w-6 h-6 text-[#ff6600]" />
            </div>
          </div>

          <div className="mb-8">
            <div className="flex justify-between items-end mb-2">
              <div>
                <div className="text-4xl font-bold text-white leading-none mb-1">{points.toLocaleString()}</div>
                <div className="text-[10px] font-bold tracking-wider text-white/50">Points Accumulés</div>
              </div>
              <div className="text-right">
                <div className="text-[11px] font-bold text-white/40 mb-1 leading-none uppercase">Palier: SILVER</div>
                <div className="text-[11px] font-bold text-[#ff6600] uppercase tracking-wider">{nextTierPoints - points} pts restants</div>
              </div>
            </div>
            <div className="h-2 w-full bg-white/10 rounded-full overflow-hidden border border-white/5">
              <motion.div 
                initial={{ width: 0 }}
                animate={{ width: `${progress}%` }}
                className="h-full bg-gradient-to-r from-[#ff6600] to-brand-secondary"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <button 
              onClick={() => {
                showToast("Catalogue: 500 pts = -5,000 GNF, 1500=Livraison Gratuite", "info");
              }}
              className="p-4 bg-brand-inverse/5 rounded-2xl border border-white/10 backdrop-blur-sm text-left group hover:bg-[#ff6600]/10 transition-all"
            >
              <Gift className="w-4 h-4 text-white mb-2" />
              <div className="text-[10px] font-bold text-brand-inverse uppercase tracking-wider group-hover:text-[#ff6600] transition-colors">Récompenses</div>
              <div className="text-[12px] font-medium text-brand-inverse/70 flex items-center gap-2">
                Voir le catalogue <ArrowRight className="w-3 h-3" />
              </div>
            </button>
            <div className="p-4 bg-brand-inverse/5 rounded-2xl border border-white/10 backdrop-blur-sm">
              <Users className="w-4 h-4 text-white mb-2" />
              <div className="text-[10px] font-bold text-brand-inverse uppercase tracking-wider">Parrainages</div>
              <div className="text-[12px] font-medium text-brand-inverse/70">12 amis invités</div>
            </div>
          </div>
        </div>
      </div>

      {/* Referral Hub */}
      <div className="bg-white bg-white dark:bg-gray-900 border border-brand-border/30 dark:border-white/5 rounded-[2.5rem] p-6 shadow-sm relative overflow-hidden">
        <div className="flex items-center gap-4 mb-6 relative z-10">
          <div className="w-12 h-12 bg-[#ff6600]/10 rounded-2xl flex items-center justify-center text-[#ff6600]">
            <Share2 className="w-6 h-6" />
          </div>
          <div>
            <h3 className="text-lg font-bold text-gray-900 text-gray-900 dark:text-white tracking-tight uppercase">Ambassadeur</h3>
            <p className="text-[11px] font-bold uppercase tracking-tight text-brand-text-dim dark:text-gray-400 opacity-70">Gagnez 5,000 Pts par ami parrainé.</p>
          </div>
        </div>

        <div className="bg-gray-50 dark:bg-gray-800 dark:bg-black/20 border border-brand-border/40 dark:border-white/10 rounded-2xl p-5 flex flex-col items-start justify-between gap-4 relative z-10">
          <div className="flex flex-col flex-1 min-w-0 w-full">
            <span className="text-[10px] font-bold tracking-wider text-brand-text-dim dark:text-gray-500 dark:text-gray-400 mb-1 opacity-60">Votre Code Unique</span>
            <span className="text-xl font-bold text-gray-900 text-gray-900 dark:text-white tracking-[4px] truncate uppercase">{referralCode || '...'}</span>
          </div>
          <button 
            onClick={handleShare}
            className={`w-full flex items-center justify-center gap-3 px-6 py-3.5 rounded-xl font-bold uppercase text-[10px] tracking-[2px] transition-all transform ${copied ? 'bg-emerald-600 text-white' : 'bg-gray-900 dark:bg-[#ff6600] text-brand-inverse hover:bg-[#ff6600] shadow-lg shadow-brand-foreground/10 dark:shadow-orange-900/10'}`}
          >
            {copied ? (
              <>
                <Check className="w-4 h-4" /> Copié
              </>
            ) : (
              <>
                <Copy className="w-4 h-4" /> Partager
              </>
            )}
          </button>
        </div>

        <div className="mt-8 flex items-center justify-between p-5 bg-emerald-500/5 dark:bg-emerald-500/10 rounded-2xl border border-emerald-500/10 dark:border-emerald-500/20 relative z-10">
          <div className="flex items-center gap-4">
             <div className="w-9 h-9 rounded-xl bg-emerald-500 flex items-center justify-center text-white text-[12px] font-bold shadow-lg shadow-emerald-500/20">!</div>
             <p className="text-[12px] font-bold uppercase tracking-tight text-gray-900 text-gray-900 dark:text-white">Recevez 5% de cashback sur leur premier achat.</p>
          </div>
          <button className="text-[10px] font-bold text-[#ff6600] dark:text-orange-400 tracking-wider flex items-center gap-2 hover:translate-x-1 transition-transform">
            Règlement <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </div>
  );
}
