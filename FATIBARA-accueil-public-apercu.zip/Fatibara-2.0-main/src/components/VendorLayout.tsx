import React, { useState, useEffect } from 'react';
import { ErrorBoundary } from './ErrorBoundary';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { 
  LayoutDashboard, 
  Package, 
  ShoppingBag, 
  BarChart3, 
  Settings, 
  MessageSquare, 
  MessageCircle,
  Wallet, 
  Zap, 
  Menu, 
  X, 
  LogOut, 
  Store,
  ChevronRight,
  User,
  Palette,
  Truck,
  Info,
  ShieldCheck,
  AlertTriangle
} from 'lucide-react';
import { useAppContext } from '../context/AppContext';
import { motion, AnimatePresence } from 'motion/react';
import { supabase } from '../lib/supabase';

import { APP_NAME } from '../lib/constants';

interface VendorLayoutProps {
  children: React.ReactNode;
}

export default function VendorLayout({ children }: VendorLayoutProps) {
  const { user, isAuthLoading, activeRole } = useAppContext();
  const location = useLocation();
  const navigate = useNavigate();
  const [isSidebarOpen, setIsSidebarOpen] = useState(() => {
    try { return localStorage.getItem('vendor_sidebar_open') !== 'false'; } catch { return true; }
  });
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [store, setStore] = useState<any>(null);
  // Live badge counters
  const [pendingOrdersCount, setPendingOrdersCount] = useState(0);
  const [unreadMessagesCount, setUnreadMessagesCount] = useState(0);

  React.useEffect(() => {
    async function fetchStore() {
      if (!user) return;
      const { data } = await supabase
        .from('stores')
        .select('store_name, avatar_url, is_verified_store, is_open')
        .eq('owner_id', user.id)
        .maybeSingle();
      if (data) setStore(data);
    }
    fetchStore();
  }, [user]);

  // ── Live badge counts ─────────────────────────────────────────────────────
  useEffect(() => {
    if (!user?.id) return;

    const fetchBadges = async () => {
      // Run the order count and store lookup in parallel — no sequential dependency
      const [
        { count: oCount },
        { data: storeRow }
      ] = await Promise.all([
        supabase
          .from('orders')
          .select('id', { count: 'exact', head: true })
          .eq('vendor_id', user.id)
          .in('status', ['pending', 'confirmed', 'paid']),
        supabase
          .from('stores')
          .select('id')
          .eq('owner_id', user.id)
          .maybeSingle()
      ]);

      setPendingOrdersCount(oCount ?? 0);

      if (storeRow?.id) {
        // Get all channel IDs for this store then count unread messages
        const { data: channels } = await supabase
          .from('chat_channels')
          .select('id')
          .eq('store_id', storeRow.id);

        if (channels && channels.length > 0) {
          const channelIds = channels.map((c: any) => c.id);
          const { count: mCount } = await supabase
            .from('chat_messages')
            .select('id', { count: 'exact', head: true })
            .in('channel_id', channelIds)
            .neq('sender_id', user.id)
            .eq('is_read', false);
          setUnreadMessagesCount(mCount ?? 0);
        } else {
          setUnreadMessagesCount(0);
        }
      }
    };

    fetchBadges();

    // Realtime refresh on order/message changes
    const channel = supabase
      .channel(`vendor-layout-badges-${user.id}`)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'orders', filter: `vendor_id=eq.${user.id}` }, fetchBadges)
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'chat_messages' }, fetchBadges)
      .subscribe();

    return () => { supabase.removeChannel(channel); };

  }, [user?.id]);

  // Persist sidebar state
  const toggleSidebar = () => {
    const next = !isSidebarOpen;
    setIsSidebarOpen(next);
    try { localStorage.setItem('vendor_sidebar_open', String(next)); } catch { /* noop */ }
  };

  const menuItems = [
    { id: 'dashboard', path: '/vendor/dashboard', icon: LayoutDashboard, label: 'Tableau de bord', tourKey: '', badge: 0 },
    { id: 'orders', path: '/vendor/orders', icon: ShoppingBag, label: 'Commandes', tourKey: 'vendor-orders-link', badge: pendingOrdersCount },
    { id: 'products', path: '/vendor/products', icon: Package, label: 'Catalogue', tourKey: 'vendor-products-link', badge: 0 },
    { id: 'marketing', path: '/vendor/marketing', icon: Zap, label: 'Marketing Elite', tourKey: 'vendor-marketing-link', badge: 0 },
    { id: 'wallet', path: '/vendor/wallet', icon: Wallet, label: 'Finances', tourKey: '', badge: 0 },
    { id: 'analytics', path: '/vendor/analytics', icon: BarChart3, label: 'Analytiques', tourKey: '', badge: 0 },
    { id: 'inbox', path: '/vendor/inbox', icon: MessageSquare, label: 'Messages', tourKey: 'vendor-inbox-link', badge: unreadMessagesCount },
    { id: 'settings', path: '/vendor/settings', icon: Settings, label: 'Paramètres', tourKey: '', badge: 0 },
  ];

  const [isLogoutModalOpen, setIsLogoutModalOpen] = useState(false);

  const handleSignOut = async () => {
    setIsLogoutModalOpen(true);
  };

  const confirmSignOut = async () => {
    await supabase.auth.signOut();
    navigate('/');
  };

  return (
    <div className="min-h-screen bg-[#F8F9FA] dark:bg-[#0B0E11] flex overflow-hidden font-sans">
      {/* Sidebar - Desktop */}
      <aside 
        className={`${
          isSidebarOpen ? 'w-[260px]' : 'w-[80px]'
        } hidden md:flex flex-col bg-[#1A1D21] dark:bg-[#1A1D21] text-white transition-all duration-300 ease-in-out z-30 border-r border-white/5 shadow-2xl`}
      >
        <div className="h-20 flex items-center px-6 gap-3 mb-4">
          <div className="w-10 h-10 bg-[#ff6600] rounded-xl flex items-center justify-center shrink-0 shadow-lg shadow-[#ff6600]/20">
            <Store className="w-6 h-6 text-white" />
          </div>
          {isSidebarOpen && (
            <div className="flex flex-col">
              <span className="font-black text-xl tracking-tighter leading-none">FATIBARA</span>
              <span className="text-[10px] font-bold text-[#ff6600] tracking-[0.2em] transform scale-90 -translate-x-1 translate-y-1">CONSOLE PRO</span>
            </div>
          )}
        </div>

        <div className="flex-1 px-3 space-y-1 overflow-y-auto custom-scrollbar">
          <div className={`px-4 py-2 mb-2 ${!isSidebarOpen && 'invisible h-0'}`}>
            <span className="text-[10px] font-black text-gray-400 uppercase tracking-[0.25em]">Management</span>
          </div>
          
          {menuItems.map((item) => {
            const isActive = location.pathname === item.path;
            return (
            <Link
                key={item.id}
                to={item.path}
                {...(item.tourKey ? { 'data-tour': item.tourKey } : {})}
                className={`flex items-center gap-3 px-4 py-3 rounded-xl transition-all group relative ${
                  isActive 
                    ? 'border-l-[3px] border-[#ff6600] bg-[#ff6600]/10 text-white pl-[13px]' 
                    : 'text-gray-400 hover:bg-white/5 hover:text-white'
                }`}
              >
                <item.icon className={`w-5 h-5 shrink-0 ${isActive ? 'text-[#ff6600]' : 'text-gray-500 group-hover:text-gray-300'}`} />
                {isSidebarOpen && (
                  <span className="font-bold text-[14px] leading-none flex-1">{item.label}</span>
                )}
                {/* Badge — always visible even when sidebar is collapsed */}
                {item.badge > 0 && (
                  <span className={`min-w-[18px] h-[18px] px-1 rounded-full text-[10px] font-black flex items-center justify-center ${
                    isActive ? 'bg-white text-[#ff6600]' : 'bg-[#ff6600] text-white'
                  }`}>
                    {item.badge > 99 ? '99+' : item.badge}
                  </span>
                )}
                {!isSidebarOpen && isActive && (
                  <div className="absolute right-0 top-1/2 -translate-y-1/2 w-1 h-6 bg-[#ff6600] rounded-l-full" />
                )}
              </Link>
            );
          })}

          <div className={`mt-8 px-4 py-2 mb-2 ${!isSidebarOpen && 'invisible h-0'}`}>
            <span className="text-[10px] font-black text-gray-400 uppercase tracking-[0.25em]">Assistance</span>
          </div>
        </div>

        <div className="p-4 border-t border-white/5">
          <Link
            to="/help"
            className="w-full flex items-center gap-3 px-4 py-3 mb-2 text-gray-400 hover:bg-white/5 hover:text-white rounded-xl transition-all group"
          >
            <MessageCircle className="w-5 h-5 text-gray-500 group-hover:text-gray-300 shrink-0" />
            {isSidebarOpen && <span className="font-bold text-[14px]">Support Marchand</span>}
          </Link>
          <button 
            onClick={toggleSidebar}
            className="w-full flex items-center justify-center p-2 text-gray-500 hover:text-white transition-colors"
          >
            {isSidebarOpen ? <ChevronRight className="w-5 h-5 rotate-180" /> : <ChevronRight className="w-5 h-5" />}
          </button>
          
          <button 
            onClick={handleSignOut}
            className="w-full flex items-center gap-3 px-4 py-3 mt-2 text-gray-400 hover:bg-red-500/10 hover:text-red-500 rounded-xl transition-all group"
          >
            <LogOut className="w-5 h-5 text-gray-500 group-hover:text-red-500" />
            {isSidebarOpen && <span className="font-bold text-[14px]">Déconnexion</span>}
          </button>
        </div>
      </aside>

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Top Header */}
        <header className="h-20 bg-white dark:bg-[#1A1D21] border-b border-gray-200 dark:border-white/5 flex items-center justify-between px-6 md:px-10 shrink-0 z-20 shadow-sm">
          <div className="flex items-center gap-6">
            <button 
              onClick={() => setIsMobileMenuOpen(true)}
              className="md:hidden p-2 text-gray-500 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-lg"
            >
              <Menu className="w-6 h-6" />
            </button>
            <div className="hidden lg:flex items-center gap-2">
              <h1 className="text-lg font-black tracking-tight text-gray-900 dark:text-white cursor-default">
                {menuItems.find(i => i.path === location.pathname)?.label || 'Console Management'}
              </h1>
            </div>

          </div>

          <div className="flex items-center gap-4 md:gap-6">
            <div className="hidden sm:flex items-center gap-3">
              {store !== null && (
                store?.is_open ? (
                  <div className="flex items-center gap-2 px-4 py-2 bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 rounded-xl border border-emerald-500/20 text-[11px] font-bold uppercase tracking-wider select-none">
                    <span className="relative flex h-1.5 w-1.5">
                      <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" />
                      <span className="relative inline-flex rounded-full h-1.5 w-1.5 bg-emerald-500" />
                    </span>
                    Boutique Ouverte
                  </div>
                ) : (
                  <div className="flex items-center gap-2 px-4 py-2 bg-red-500/10 text-red-500 rounded-xl border border-red-500/20 text-[11px] font-bold uppercase tracking-wider select-none">
                    <span className="w-1.5 h-1.5 bg-red-500 rounded-full" />
                    Boutique Suspendue
                  </div>
                )
              )}
            </div>


            <div className="h-8 w-px bg-gray-100 dark:bg-white/10 hidden md:block" />
            
            <div className="flex items-center gap-4 group cursor-pointer" onClick={() => navigate('/vendor/settings')}>
              <div className="text-right hidden sm:block">
                <p className="text-[13px] font-black text-gray-900 dark:text-white leading-none mb-1 group-hover:text-[#ff6600] transition-colors">
                  {store?.store_name || user?.email?.split('@')[0]}
                </p>
                <div className="flex items-center justify-end gap-1.5">
                   {store?.is_verified_store && <ShieldCheck className="w-3 h-3 text-[#ff6600]" />}
                   <p className="text-[10px] text-gray-500 dark:text-gray-400 font-black uppercase tracking-widest whitespace-nowrap">
                     ID: #{user?.id?.slice(0, 5) ?? '—'}
                   </p>
                </div>
              </div>
              <div className="w-11 h-11 bg-orange-50 dark:bg-[#ff6600]/10 rounded-2xl flex items-center justify-center border-2 border-orange-100 dark:border-[#ff6600]/20 group-hover:border-[#ff6600] transition-all overflow-hidden">
                {store?.avatar_url ? (
                  <img src={store.avatar_url} alt="Profile" className="w-full h-full object-cover" />
                ) : (
                  <User className="w-6 h-6 text-[#ff6600]" />
                )}
              </div>
            </div>
          </div>
        </header>

        {/* Content Viewport */}
        <main className="flex-1 overflow-y-auto bg-[#F8F9FA] dark:bg-[#0B0E11] relative">
          {/* Dashboard Mesh Background (Only for Pro feel) */}
          <div className="absolute inset-0 pointer-events-none opacity-[0.03] dark:opacity-[0.05]">
            <div className="absolute top-0 left-0 w-full h-full bg-[radial-gradient(#ff6600_1px,transparent_1px)] [background-size:32px_32px]" />
          </div>
          
          <div className="p-6 md:p-10 max-w-[1700px] mx-auto relative z-10 w-full">
            {isAuthLoading ? (
              <div className="flex items-center justify-center min-h-[50vh]">
                <div className="w-8 h-8 border-2 border-[#ff6600] border-t-transparent rounded-full animate-spin" />
              </div>
            ) : !user ? (
              <div className="flex flex-col items-center justify-center min-h-[50vh] gap-6 text-center">
                <div className="w-16 h-16 bg-red-500/10 border border-red-500/20 rounded-2xl flex items-center justify-center">
                  <AlertTriangle className="w-8 h-8 text-red-400" />
                </div>
                <div>
                  <h2 className="text-lg font-black text-gray-900 dark:text-white uppercase tracking-tighter mb-2">
                    Accès restreint
                  </h2>
                  <p className="text-[11px] text-gray-400 font-bold tracking-wider">
                    Connectez-vous pour accéder à votre console marchande.
                  </p>
                </div>
                <button
                  id="vendor-login-redirect-btn"
                  onClick={() => navigate('/login')}
                  className="px-8 py-3 bg-[#ff6600] text-white rounded-xl text-[11px] font-black tracking-widest uppercase hover:bg-[#e65c00] transition-colors"
                >
                  Se connecter
                </button>
              </div>
            ) : (
              <ErrorBoundary>{children}</ErrorBoundary>
            )}
          </div>
        </main>
      </div>

      {/* Mobile Menu Overlay */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <>
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsMobileMenuOpen(false)}
              className="fixed inset-0 bg-black/60 backdrop-blur-sm z-40 md:hidden"
            />
            <motion.div 
              initial={{ x: '-100%' }}
              animate={{ x: 0 }}
              exit={{ x: '-100%' }}
              transition={{ type: 'spring', damping: 30, stiffness: 300 }}
              drag="x"
              dragConstraints={{ left: 0, right: 0 }}
              dragElastic={{ left: 0.4, right: 0 }}
              onDragEnd={(_e, info) => {
                // Close if the user swipes left more than 80px or fast enough
                if (info.offset.x < -80 || info.velocity.x < -400) {
                  setIsMobileMenuOpen(false);
                }
              }}
              className="fixed inset-y-0 left-0 w-[280px] bg-[#1A1D21] z-50 md:hidden flex flex-col p-6 shadow-2xl touch-pan-y"
            >
              <div className="flex items-center justify-between mb-10">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-[#ff6600] rounded-xl flex items-center justify-center shadow-lg">
                    <Store className="w-6 h-6 text-white" />
                  </div>
                  <div className="flex flex-col">
                    <span className="font-black text-xl text-white tracking-tighter italic">FATIBARA</span>
                    <span className="text-[10px] font-black text-[#ff6600] tracking-widest leading-none">CONSOLE</span>
                  </div>
                </div>
                <button 
                  onClick={() => setIsMobileMenuOpen(false)}
                  className="p-2 text-gray-500 hover:text-white"
                >
                  <X className="w-6 h-6" />
                </button>
              </div>

              <div className="flex-1 space-y-1">
                {menuItems.map((item) => {
                   const isActive = location.pathname === item.path;
                   return (
                    <Link
                      key={item.id}
                      to={item.path}
                      onClick={() => setIsMobileMenuOpen(false)}
                      className={`flex items-center gap-4 px-5 py-4 rounded-2xl font-bold transition-all ${
                        isActive 
                          ? 'bg-[#ff6600] text-white shadow-lg' 
                          : 'text-gray-400 hover:bg-white/5 hover:text-white'
                      }`}
                    >
                      <item.icon className={`w-5 h-5 ${isActive ? 'text-white' : 'text-gray-500'}`} />
                      <span className="text-[15px] flex-1">{item.label}</span>
                      {item.badge > 0 && (
                        <span className={`min-w-[20px] h-[20px] px-1.5 rounded-full text-[10px] font-black flex items-center justify-center ${
                          isActive ? 'bg-white text-[#ff6600]' : 'bg-[#ff6600] text-white'
                        }`}>
                          {item.badge > 99 ? '99+' : item.badge}
                        </span>
                      )}
                    </Link>
                  );
                })}
              </div>

              <div className="pt-6 border-t border-white/5">
                <button 
                  onClick={handleSignOut}
                  className="w-full flex items-center gap-4 px-5 py-4 text-red-500 bg-red-500/5 rounded-2xl font-black uppercase tracking-widest text-[11px]"
                >
                  <LogOut className="w-5 h-5" />
                  Déconnexion
                </button>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
      {/* Logout Confirmation Modal */}
      <AnimatePresence>
        {isLogoutModalOpen && (
          <div className="fixed inset-0 z-[200] flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsLogoutModalOpen(false)}
              className="absolute inset-0 bg-black/60 backdrop-blur-md"
            />
            <motion.div
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              className="relative w-full max-w-[400px] bg-white dark:bg-gray-900 rounded-[2.5rem] shadow-2xl overflow-hidden border border-white/10"
            >
              <div className="p-10 text-center">
                <div className="w-20 h-20 bg-rose-50 dark:bg-rose-900/20 rounded-full flex items-center justify-center mx-auto mb-6 text-rose-500">
                  <LogOut className="w-10 h-10" />
                </div>
                <h3 className="text-2xl font-black text-gray-900 dark:text-white mb-3 italic tracking-tight">Déconnexion ?</h3>
                <p className="text-gray-500 dark:text-gray-400 font-bold mb-8 uppercase text-[12px] tracking-widest leading-relaxed">
                  Êtes-vous sûr de vouloir quitter la Console Management ?
                </p>
                <div className="flex flex-col gap-3">
                  <button
                    onClick={confirmSignOut}
                    className="w-full bg-rose-600 hover:bg-rose-700 text-white font-black py-4 rounded-2xl transition-all shadow-lg hover:shadow-rose-500/20 active:scale-95 uppercase tracking-widest"
                  >
                    Oui, Se Déconnecter
                  </button>
                  <button
                    onClick={() => setIsLogoutModalOpen(false)}
                    className="w-full bg-gray-100 dark:bg-gray-800 hover:bg-gray-200 dark:hover:bg-gray-700 text-gray-900 dark:text-white font-black py-4 rounded-2xl transition-all active:scale-95 uppercase tracking-widest"
                  >
                    Rester Connecté
                  </button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
