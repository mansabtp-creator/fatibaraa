import React from 'react';

interface SEOTrackerProps {
  title: string;
  description: string;
}

export function SEOTracker({ title, description }: SEOTrackerProps) {
  // Title: Poor < 30, OK < 50, Good 50-60, Over > 60
  const getTitleStatus = () => {
    const len = title.length;
    if (len === 0) return { color: 'bg-brand-border', text: 'Vide', progress: 0 };
    if (len < 30) return { color: 'bg-red-500', text: 'Trop court', progress: 25 };
    if (len < 50) return { color: 'bg-yellow-500', text: 'Presque', progress: 60 };
    if (len <= 60) return { color: 'bg-green-500', text: 'Optimal', progress: 100 };
    return { color: 'bg-red-500', text: 'Trop long', progress: 100 };
  };

  // Desc: Poor < 80, OK < 120, Good 120-160, Over > 160
  const getDescStatus = () => {
    const len = description.length;
    if (len === 0) return { color: 'bg-brand-border', text: 'Vide', progress: 0 };
    if (len < 80) return { color: 'bg-red-500', text: 'Trop court', progress: 25 };
    if (len < 120) return { color: 'bg-yellow-500', text: 'Presque', progress: 60 };
    if (len <= 160) return { color: 'bg-green-500', text: 'Optimal', progress: 100 };
    return { color: 'bg-red-500', text: 'Trop long', progress: 100 };
  };

  const titleStatus = getTitleStatus();
  const descStatus = getDescStatus();

  return (
    <div className="bg-white dark:bg-gray-900 border border-brand-border rounded-[1.5rem] p-5 space-y-4 shadow-sm relative overflow-hidden">
      <div className="flex items-center justify-between mb-2">
        <h4 className="text-[12px] font-bold tracking-wider text-gray-900 dark:text-white">Score SEO Temps Réel</h4>
      </div>

      {/* Title SEO */}
      <div className="space-y-1.5">
        <div className="flex justify-between items-center text-[10px] font-bold uppercase tracking-wider text-brand-text-dim">
          <span>Titre ({title.length}/60)</span>
          <span className={titleStatus.color.replace('bg-', 'text-')}>{titleStatus.text}</span>
        </div>
        <div className="h-2 w-full bg-gray-50 dark:bg-gray-800 rounded-full overflow-hidden">
          <div 
            className={`h-full opacity-90 transition-all duration-300 ${titleStatus.color}`} 
            style={{ width: `${titleStatus.progress}%` }} 
          />
        </div>
      </div>

      {/* Description SEO */}
      <div className="space-y-1.5">
        <div className="flex justify-between items-center text-[10px] font-bold uppercase tracking-wider text-brand-text-dim">
          <span>Description ({description.length}/160)</span>
          <span className={descStatus.color.replace('bg-', 'text-')}>{descStatus.text}</span>
        </div>
        <div className="h-2 w-full bg-gray-50 dark:bg-gray-800 rounded-full overflow-hidden">
          <div 
            className={`h-full opacity-90 transition-all duration-300 ${descStatus.color}`} 
            style={{ width: `${descStatus.progress}%` }} 
          />
        </div>
      </div>
    </div>
  );
}
