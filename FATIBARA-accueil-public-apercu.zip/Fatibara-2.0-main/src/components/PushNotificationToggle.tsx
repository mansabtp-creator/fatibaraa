/**
 * PushNotificationToggle.tsx
 *
 * Reusable toggle card for enabling/disabling Web Push notifications.
 * Uses the usePushNotifications hook to manage subscription state.
 *
 * Shows:
 *   - "Not supported" message if browser doesn't support Web Push
 *   - Current permission status (denied/granted/default)
 *   - Enable/Disable button with loading state
 *   - Error message if subscription fails
 *
 * Usage:
 *   <PushNotificationToggle />
 *
 * Used in: VendorSettings, buyer DashboardPage notification section
 */
import React from 'react';
import { Bell, BellOff, Loader2, Smartphone } from 'lucide-react';
import { usePushNotifications } from '../hooks/usePushNotifications';

export default function PushNotificationToggle() {
  const { isSupported, isSubscribed, isLoading, error, subscribe, unsubscribe } =
    usePushNotifications();

  const permissionStatus =
    typeof Notification !== 'undefined' ? Notification.permission : 'default';

  if (!isSupported) {
    return (
      <div className="flex items-start gap-4 p-5 rounded-2xl bg-gray-50 dark:bg-white/5 border border-gray-200 dark:border-white/10">
        <div className="w-10 h-10 rounded-xl bg-gray-100 dark:bg-white/10 flex items-center justify-center shrink-0">
          <BellOff className="w-5 h-5 text-gray-400" />
        </div>
        <div>
          <p className="text-[13px] font-bold text-gray-700 dark:text-white">
            Notifications push
          </p>
          <p className="text-[11px] text-gray-400 dark:text-gray-500 mt-0.5">
            Non supporté sur ce navigateur. Utilisez Chrome ou Firefox sur Android/desktop.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="flex items-start gap-4 p-5 rounded-2xl bg-white dark:bg-white/5 border border-gray-200 dark:border-white/10">
      {/* Icon */}
      <div className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 transition-colors ${
        isSubscribed
          ? 'bg-[#ff6600]/10 border border-[#ff6600]/20'
          : 'bg-gray-100 dark:bg-white/10'
      }`}>
        {isSubscribed
          ? <Bell className="w-5 h-5 text-[#ff6600]" />
          : <BellOff className="w-5 h-5 text-gray-400" />}
      </div>

      {/* Text */}
      <div className="flex-1 min-w-0">
        <p className="text-[13px] font-bold text-gray-900 dark:text-white">
          Notifications push
        </p>
        <p className="text-[11px] text-gray-400 dark:text-gray-500 mt-0.5 leading-relaxed">
          {isSubscribed
            ? 'Activées — vous recevrez des alertes même lorsque l\'application est fermée.'
            : 'Désactivées — activez pour recevoir commandes, livraisons et alertes en temps réel.'}
        </p>
        {permissionStatus === 'denied' && (
          <p className="text-[10px] font-bold text-red-500 mt-1.5 flex items-center gap-1">
            ⚠️ Permission bloquée — autorisez les notifications dans les paramètres du navigateur.
          </p>
        )}
        {error && (
          <p className="text-[10px] font-bold text-red-500 mt-1.5">{error}</p>
        )}
      </div>

      {/* Toggle button */}
      <button
        onClick={() => isSubscribed ? unsubscribe() : subscribe()}
        disabled={isLoading || permissionStatus === 'denied'}
        className={`shrink-0 flex items-center gap-1.5 px-4 py-2 rounded-xl text-[11px] font-black uppercase tracking-wide transition-all active:scale-95 disabled:opacity-40 ${
          isSubscribed
            ? 'bg-gray-100 dark:bg-white/10 text-gray-600 dark:text-gray-300 hover:bg-red-50 dark:hover:bg-red-900/20 hover:text-red-500'
            : 'bg-[#ff6600] text-white hover:bg-[#e65c00] shadow-lg shadow-[#ff6600]/20'
        }`}
      >
        {isLoading
          ? <Loader2 className="w-3.5 h-3.5 animate-spin" />
          : isSubscribed
            ? <><BellOff className="w-3.5 h-3.5" /> Désactiver</>
            : <><Bell className="w-3.5 h-3.5" /> Activer</>}
      </button>
    </div>
  );
}

/**
 * Compact device info strip — shows count of subscribed devices.
 * Optionally include below the toggle when user has multiple devices.
 */
export function PushDeviceInfo({ deviceCount }: { deviceCount: number }) {
  if (deviceCount === 0) return null;
  return (
    <p className="text-[10px] font-bold text-gray-400 dark:text-gray-500 flex items-center gap-1 mt-2 px-1">
      <Smartphone className="w-3 h-3" />
      {deviceCount} appareil{deviceCount > 1 ? 's' : ''} abonné{deviceCount > 1 ? 's' : ''}
    </p>
  );
}
