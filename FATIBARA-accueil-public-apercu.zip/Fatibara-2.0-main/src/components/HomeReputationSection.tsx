import React, { useEffect, useState } from 'react';
import { motion } from 'motion/react';
import { useStore } from '../store/useStore';
import { Star, ShieldCheck, ArrowRight, TrendingUp } from 'lucide-react';
import { BadgeShelf } from './SellerBadges';
import { supabase } from '../lib/supabase';
import { Skeleton } from './ui/Skeleton';

interface DbStore {
  id: string;
  store_name: string;
  avatar_url: string;
  location_commune: string;
  reputation_score?: number;
}

export default function HomeReputationSection() {
  const { selectedRegion } = useStore();
  const [topSellers, setTopSellers] = useState<DbStore[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function fetchSellers() {
      try {
        const { data, error } = await supabase
          .from('stores')
          .select('*')
          .order('created_at', { ascending: false })
          .limit(3);

        if (!error && data && data.length > 0) {
          setTopSellers(data);
        }
      } catch (err) {
        console.error("Sellers fetch error:", err);
      } finally {
        setLoading(false);
      }
    }
    fetchSellers();
  }, []);

  const citySellers = topSellers.filter(s => 
    selectedRegion === 'Toute la Guinée' || 
    (s.location_commune && s.location_commune.includes(selectedRegion))
  );

  if (loading) {
    return (
      <section className="px-10 py-20 bg-gray-50 dark:bg-gray-800 dark:bg-gray-950 border-y border-brand-border/30 dark:border-white/5">
        <div className="max-w-7xl mx-auto flex justify-center gap-6">
          <Skeleton className="w-[300px] h-[200px]" />
          <Skeleton className="w-[300px] h-[200px]" />
          <Skeleton className="w-[300px] h-[200px]" />
        </div>
      </section>
    );
  }

  if (citySellers.length === 0) return null;

  return (
    <section className="px-4 md:px-10 py-16 md:py-24 bg-gray-50 dark:bg-gray-800 dark:bg-gray-950/50 border-y border-gray-100 dark:border-gray-800 dark:border-white/5 relative overflow-hidden">
        <div className="max-w-7xl mx-auto relative z-10">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-end mb-10 gap-6">
            <div>
              <div className="flex items-center gap-3 mb-3">
                <span className="bg-black/10 dark:bg-white/10 text-black dark:text-white text-[10px] font-bold px-2 py-1 rounded uppercase tracking-[1px] flex items-center gap-1"><ShieldCheck className="w-3 h-3" /> Boutique Élite</span>
                <span className="text-gray-500 text-gray-500 dark:text-gray-400 font-semibold text-[11px] uppercase tracking-wide">Vendeurs Excellence</span>
              </div>
              <h2 className="text-2xl md:text-3xl font-bold text-gray-900 dark:text-white tracking-tight leading-tight">
                Les Incontournables de <br />
                <span className="text-black dark:text-white">
                  {selectedRegion === 'Toute la Guinée' ? 'la Guinée' : selectedRegion}
                </span>
              </h2>
            </div>
            <button className="flex items-center gap-1 text-sm font-semibold text-amber-500 hover:text-amber-400 transition-colors">
              Voir tout <ArrowRight className="w-4 h-4" />
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
            {citySellers.map((seller, idx) => {
              const displayRep = seller.reputation_score || 95;
              const displayReviews = Math.floor(Math.random() * 200) + 10; // Dynamic fill
              const badges = ['verified', 'fast_shipper', 'premium'];

              return (
                <motion.div 
                  key={seller.id}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ delay: idx * 0.1 }}
                  viewport={{ once: true }}
                  className="bg-white bg-white dark:bg-gray-900 p-6 rounded-2xl border border-gray-100 dark:border-gray-800 dark:border-white/10 shadow-sm hover:shadow-md transition-all group"
                >
                  <div className="flex items-center gap-4 mb-6">
                     <div className="w-16 h-16 rounded-full overflow-hidden border border-gray-100 dark:border-gray-800 dark:border-white/10 bg-gray-50 bg-gray-50 dark:bg-gray-800 shrink-0">
                        <img src={seller.avatar_url || `https://api.dicebear.com/7.x/initials/svg?seed=${seller.store_name}`} alt={seller.store_name} className="w-full h-full object-cover" />
                     </div>
                     <div>
                        <h3 className="font-bold text-lg text-gray-900 text-gray-900 dark:text-white tracking-tight line-clamp-1">{seller.store_name}</h3>
                        <div className="flex items-center gap-1.5 mt-0.5">
                           <Star className="w-3.5 h-3.5 text-yellow-400 fill-yellow-400" />
                           <span className="text-[12px] font-bold text-gray-700 dark:text-gray-300">{(displayRep / 20).toFixed(1)}/5</span>
                           <span className="text-gray-400 text-[11px] font-medium">({displayReviews} avis)</span>
                        </div>
                     </div>
                  </div>

                  <div className="mb-6">
                     <p className="text-[10px] font-semibold uppercase tracking-wide text-gray-400 mb-1.5">Localisation</p>
                     <span className="bg-gray-50 bg-gray-50 dark:bg-gray-800 text-gray-700 dark:text-gray-300 text-sm font-medium px-4 py-2 rounded-lg inline-block w-full">
                       {seller.location_commune || 'Boutique Multi-Catégories'}
                     </span>
                  </div>
                
                <BadgeShelf badges={badges as ('verified'|'guarantee'|'top_rated'|'fast_shipper'|'premium')[]} />
              </motion.div>
            )})}
          </div>
        </div>
    </section>
  );
}
