import React from 'react';
import { motion } from 'motion/react';
import { useAppContext } from '../context/AppContext';
import { Zap, Clock, ArrowRight, Tag } from 'lucide-react';
import { Link } from 'react-router-dom';

export default function FlashDeals() {
  const { activePromotions } = useAppContext();

  if (!activePromotions || activePromotions.length === 0) return null;

  return (
    <div className="mb-16 md:mb-24">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h2 className="text-3xl md:text-5xl font-bold text-gray-900 text-gray-900 dark:text-white tracking-tighter uppercase mb-2 flex items-center gap-4">
             <Zap className="w-8 h-8 md:w-10 md:h-10 text-black fill-black dark:text-white dark:fill-white animate-pulse" /> Offres Flash
          </h2>
          <p className="text-[10px] md:text-[11px] font-bold text-brand-text-dim dark:text-gray-400 tracking-wider">Promotions limitées dans le temps</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {activePromotions.map((promo, idx) => (
          <motion.div
            key={promo.id}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: idx * 0.1 }}
            className="group relative bg-gray-900 text-white rounded-[2.5rem] p-8 md:p-10 overflow-hidden shadow-2xl"
          >
            {/* Visual Decoration */}
            <div className="absolute top-0 right-0 w-32 h-32 bg-black dark:bg-white dark:bg-gray-900 rotate-45 translate-x-16 -translate-y-16 group-hover:scale-125 transition-transform duration-700"></div>
            
            <div className="relative z-10">
              <div className="inline-flex items-center gap-2 bg-white/10 border border-brand-surface/20 px-4 py-1.5 rounded-full text-[10px] font-bold tracking-wider mb-8">
                <Clock className="w-3.5 h-3.5 text-black dark:text-white" /> Expire bientôt
              </div>

              <h3 className="text-3xl md:text-4xl font-bold mb-2 tracking-tighter uppercase leading-[0.9]">
                {promo.title}
              </h3>
              <p className="text-white/60 font-medium mb-10 text-sm tracking-tight leading-relaxed">
                Profitez de remises exceptionnelles sur une sélection de produits certifiés.
              </p>

              <div className="flex items-end justify-between">
                <div>
                  <p className="text-[11px] font-bold text-black dark:text-gray-300 tracking-wider mb-1">Remise immédiate</p>
                  <p className="text-5xl font-bold italic tracking-tighter">-{promo.discount_value}%</p>
                </div>
                <Link 
                  to="/shop" 
                  className="w-14 h-14 bg-black dark:bg-white dark:bg-gray-900 rounded-2xl flex items-center justify-center group-hover:translate-x-2 transition-transform shadow-xl shadow-black/20"
                >
                  <ArrowRight className="w-6 h-6 text-white dark:text-gray-900 dark:text-white" />
                </Link>
              </div>
            </div>

            {/* Background elements */}
            <Tag className="absolute -bottom-10 -right-10 w-40 h-40 text-white/5 -rotate-12" />
          </motion.div>
        ))}
      </div>
    </div>
  );
}
