import { useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { useOfflineStore } from '../store/useOfflineStore';
import { useToast } from '../context/ToastContext';
import { hapticFeedback } from '../lib/haptics';

export function SyncManager() {
  const { pendingEdits, pendingCreations, removeEdit, removeCreation } = useOfflineStore();
  const { showToast } = useToast();

  useEffect(() => {
    const handleOnline = async () => {
      syncPendingData();
    };

    const syncPendingData = async () => {
      const editKeys = Object.keys(pendingEdits);
      const creationKeys = Object.keys(pendingCreations || {});
      
      if (editKeys.length === 0 && creationKeys.length === 0) return;

      showToast("Connexion rétablie. Synchronisation des données...", 'success');
      let hasError = false;

      // Sync Creations
      for (const id of creationKeys) {
        try {
          const creation = { ...pendingCreations[id] };
          delete (creation as any).__offline_id; 
          
          const { error } = await supabase.from('products').insert([creation]);
          if (error) throw error;
          removeCreation(id);
        } catch (err) {
          console.error("Sync creation error:", err);
          hasError = true;
        }
      }

      // Sync Edits
      for (const id of editKeys) {
        try {
          const edit = pendingEdits[id];
          const { error } = await supabase.from('products').update(edit).eq('id', id);
          if (error) throw error;
          removeEdit(id);
        } catch (err) {
          console.error("Sync edit error:", err);
          hasError = true;
        }
      }

      if (hasError) {
        showToast("Échec partiel de synchronisation. Réessai automatique...", 'info');
      } else {
        showToast("Catalogue synchronisé avec succès !", 'success');
        hapticFeedback('success');
      }
    };

    // Check periodically if offline data exists but we missed the 'online' event
    const interval = setInterval(() => {
      if (navigator.onLine && (Object.keys(pendingEdits).length > 0 || Object.keys(pendingCreations || {}).length > 0)) {
        syncPendingData();
      }
    }, 30000); // 30 seconds check

    window.addEventListener('online', handleOnline);
    return () => {
      window.removeEventListener('online', handleOnline);
      clearInterval(interval);
    };
  }, [pendingEdits, pendingCreations, removeEdit, removeCreation, showToast]);

  return null;
}
