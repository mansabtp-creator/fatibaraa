import React, { useEffect, useState } from 'react';
import { TrendingUp, TrendingDown, Info, BarChart3, AlertCircle, Loader2 } from 'lucide-react';
import { motion } from 'motion/react';
import { aiClient as ai } from "../lib/ai-client";

interface VendorSmartPricingProps {
  title: string;
  currentPrice: number;
}

export default function VendorSmartPricing({ title, currentPrice }: VendorSmartPricingProps) {
  const [context, setContext] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function analyzePrice() {
      if (!title || !currentPrice) return;
      setLoading(true);
      try {
        const prompt = `En tant qu'expert du marché de Madina et du commerce en Guinée, analyse ce produit : "${title}". 
        Le prix actuel du vendeur est de ${currentPrice} GNF.
        Renvoie UNIQUEMENT un objet JSON avec les champs suivants :
        - avg: prix moyen estimé en GNF
        - low: prix minimum raisonnable en GNF
        - high: prix maximum raisonnable en GNF
        - sentiment: "optimal", "high", or "low"
        - advice: un conseil court en français pour le vendeur.`;

        const response = await ai.models.generateContent({
          model: "gemini-3.8-flash",
          contents: [{ role: "user", parts: [{ text: prompt }] }],
          config: {
            responseMimeType: "application/json"
          }
        });

        const result = JSON.parse(response.text || '{}');
        setContext(result);
      } catch (err: any) {
        console.error("AI Price analysis failed:", err);
        const errorMessage = err?.message || "";
        const isAuthError = errorMessage.includes('403') || errorMessage.includes('suspended');
        
        // Fallback
        setContext({
           avg: currentPrice,
           low: currentPrice * 0.8,
           high: currentPrice * 1.2,
           sentiment: 'optimal',
           advice: isAuthError 
             ? "L'assistant IA est temporairement indisponible (Vérifiez la clé API en Paramètres > Secrets)." 
             : 'Continuez ainsi, votre prix semble correct pour le marché local.'
        });
      } finally {
        setLoading(false);
      }
    }

    analyzePrice();
  }, [title, currentPrice]);

  if (!title || !currentPrice) return null;
  if (loading) return (
    <div className="p-8 bg-gray-900 text-brand-inverse rounded-[2.5rem] border border-white/10 flex items-center justify-center gap-4 shadow-xl">
      <Loader2 className="w-6 h-6 animate-spin text-[#ff6600]" />
      <span className="text-[12px] font-bold tracking-wider">Analyse du marché...</span>
    </div>
  );

  if (!context) return null;

  const isHigh = context.sentiment === 'high' || currentPrice > context.high;
  const isLow = context.sentiment === 'low' || currentPrice < context.low;

  return (
    <motion.div 
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      className="p-8 bg-gray-900 text-brand-inverse rounded-[3rem] border border-white/10 shadow-2xl relative overflow-hidden group"
    >
      <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:rotate-12 transition-transform duration-500">
         <BarChart3 className="w-24 h-24" />
      </div>
      
      <div className="relative z-10">
        <div className="flex items-center gap-3 mb-6">
           <div className="w-10 h-10 bg-[#ff6600] rounded-xl flex items-center justify-center shadow-lg shadow-[#ff6600]/20">
              <TrendingUp className="w-5 h-5" />
           </div>
           <h4 className="text-[13px] font-bold tracking-wider text-brand-inverse/80">Assistant Intelligent (IA)</h4>
        </div>

        <div className="space-y-8">
           <div className="flex justify-between items-end">
              <div>
                 <p className="text-[10px] font-bold text-brand-inverse/50 tracking-wider mb-1">Moyenne Marché Estimée</p>
                 <div className="text-3xl font-bold tracking-tighter">{(context.avg || 0).toLocaleString()} GNF</div>
              </div>
              <div className={`px-4 py-2 rounded-full text-[10px] font-bold tracking-wider flex items-center gap-2 border ${isHigh ? 'bg-red-500/20 text-red-400 border-red-500/20' : isLow ? 'bg-emerald-500/20 text-emerald-400 border-emerald-500/20' : 'bg-blue-500/20 text-blue-400 border-blue-500/20'}`}>
                 {isHigh ? <TrendingUp className="w-3.5 h-3.5" /> : isLow ? <TrendingDown className="w-3.5 h-3.5" /> : <Info className="w-3.5 h-3.5" />}
                 {isHigh ? 'Cher' : isLow ? 'Compétitif' : 'Optimal'}
              </div>
           </div>

           <div className="grid grid-cols-2 gap-4">
              <div className="p-5 bg-brand-inverse/5 rounded-2xl border border-white/5 backdrop-blur-sm">
                 <p className="text-[9px] font-bold text-brand-inverse/40 tracking-wider mb-1">Prix Plafond</p>
                 <div className="text-[15px] font-bold tracking-tight">{(context.high || 0).toLocaleString()}</div>
              </div>
              <div className="p-5 bg-brand-inverse/5 rounded-2xl border border-white/5 backdrop-blur-sm">
                 <p className="text-[9px] font-bold text-brand-inverse/40 tracking-wider mb-1">Prix Minimum</p>
                 <div className="text-[15px] font-bold tracking-tight">{(context.low || 0).toLocaleString()}</div>
              </div>
           </div>

           <div className="flex items-center gap-4 p-4 bg-brand-inverse/5 border border-white/10 rounded-2xl">
             <AlertCircle className={`w-5 h-5 shrink-0 ${isHigh ? 'text-red-400' : 'text-blue-400'}`} />
             <p className="text-[12px] font-bold uppercase tracking-tight text-brand-inverse/90 leading-tight">{context.advice}</p>
           </div>
        </div>
      </div>
    </motion.div>
  );
}
