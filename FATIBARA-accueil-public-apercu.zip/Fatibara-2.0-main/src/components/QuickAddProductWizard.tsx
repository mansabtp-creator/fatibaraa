/**
 * QuickAddProductWizard.tsx
 *
 * A simplified 3-step product creation wizard for non-technical vendors,
 * designed to minimise friction on the first product upload.
 *
 * Step 1 — Photo       : Upload or skip (drag-drop / file picker)
 * Step 2 — Infos       : Title, Category (select), Price GNF
 * Step 3 — Stock       : Quantity, Condition, optional short description
 *
 * On submit, inserts directly into `products` using the same minimal payload
 * as the full ProductForm. Uses existing Supabase Storage bucket `product-images`.
 *
 * Usage:
 *   <QuickAddProductWizard
 *     storeId={storeData.id}
 *     onSuccess={(product) => setProducts([product, ...products])}
 *     onClose={() => setShowWizard(false)}
 *   />
 */
import React, { useState, useRef, useCallback } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  X, Camera, ChevronRight, ChevronLeft, Check, Loader2,
  Package, Tag, ImageIcon, AlertCircle
} from 'lucide-react';
import { supabase } from '../lib/supabase';
import { useToast } from '../context/ToastContext';
import { PRODUCT_CATEGORIES } from '../lib/constants';

// ─── Types ────────────────────────────────────────────────────────────────────

interface QuickAddProductWizardProps {
  storeId: string;
  onSuccess: (product: any) => void;
  onClose: () => void;
}

type WizardStep = 'photo' | 'info' | 'stock' | 'success';

// ─── Fallback placeholder image ───────────────────────────────────────────────
const PLACEHOLDER_IMAGE =
  'https://images.unsplash.com/photo-1560393464-5c69a73c5770?q=80&w=800&auto=format&fit=crop';

// ─── Component ────────────────────────────────────────────────────────────────

export default function QuickAddProductWizard({
  storeId,
  onSuccess,
  onClose,
}: QuickAddProductWizardProps) {
  const { showToast } = useToast();

  // ── Step state ──────────────────────────────────────────────────────────────
  const [step, setStep] = useState<WizardStep>('photo');

  // ── Photo step ──────────────────────────────────────────────────────────────
  const [imageUrl, setImageUrl] = useState<string>('');
  const [uploading, setUploading] = useState(false);
  const [uploadError, setUploadError] = useState('');
  const fileInputRef = useRef<HTMLInputElement>(null);
  const dropRef = useRef<HTMLDivElement>(null);
  const [dragging, setDragging] = useState(false);

  // ── Info step ───────────────────────────────────────────────────────────────
  const [title, setTitle] = useState('');
  const [category, setCategory] = useState(
    Array.isArray(PRODUCT_CATEGORIES) ? PRODUCT_CATEGORIES[0] : 'Autres'
  );
  const [price, setPrice] = useState('');
  const [infoErrors, setInfoErrors] = useState<{ title?: string; price?: string }>({});

  // ── Stock step ──────────────────────────────────────────────────────────────
  const [quantity, setQuantity] = useState('1');
  const [condition, setCondition] = useState<'new' | 'used'>('new');
  const [description, setDescription] = useState('');
  const [saving, setSaving] = useState(false);

  // ── Saved product ───────────────────────────────────────────────────────────
  const [savedProduct, setSavedProduct] = useState<any>(null);

  // ─── Image upload ───────────────────────────────────────────────────────────

  const uploadFile = useCallback(async (file: File) => {
    if (!file.type.startsWith('image/')) {
      setUploadError('Le fichier doit être une image (JPEG, PNG, WebP).');
      return;
    }
    if (file.size > 5 * 1024 * 1024) {
      setUploadError('Image trop lourde. Maximum 5 Mo.');
      return;
    }

    setUploading(true);
    setUploadError('');
    try {
      const ext = file.name.split('.').pop() ?? 'jpg';
      const path = `${storeId}/${Date.now()}.${ext}`;
      const { error: upErr } = await supabase.storage
        .from('product-images')
        .upload(path, file, { upsert: true });
      if (upErr) throw upErr;

      const { data } = supabase.storage.from('product-images').getPublicUrl(path);
      setImageUrl(data.publicUrl);
    } catch (err: any) {
      setUploadError('Erreur lors du téléversement. Réessayez.');
    } finally {
      setUploading(false);
    }
  }, [storeId]);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) uploadFile(file);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setDragging(false);
    const file = e.dataTransfer.files?.[0];
    if (file) uploadFile(file);
  };

  // ─── Step navigation ────────────────────────────────────────────────────────

  const goNext = () => {
    if (step === 'photo') { setStep('info'); return; }
    if (step === 'info') {
      const errors: { title?: string; price?: string } = {};
      if (!title.trim()) errors.title = 'Le nom du produit est requis.';
      const p = parseFloat(price.replace(/\s/g, ''));
      if (!price || isNaN(p) || p <= 0) errors.price = 'Entrez un prix valide en GNF.';
      setInfoErrors(errors);
      if (Object.keys(errors).length > 0) return;
      setStep('stock');
      return;
    }
    if (step === 'stock') { handleSubmit(); }
  };

  const goBack = () => {
    if (step === 'info') { setStep('photo'); return; }
    if (step === 'stock') { setStep('info'); return; }
  };

  // ─── Submit ─────────────────────────────────────────────────────────────────

  const handleSubmit = async () => {
    setSaving(true);
    try {
      const productData = {
        store_id: storeId,
        title: title.trim(),
        description: description.trim() || `${title.trim()} — ${condition === 'new' ? 'Neuf' : 'Occasion'}`,
        category,
        price_gnf: parseFloat(price.replace(/\s/g, '')),
        stock_quantity: parseInt(quantity) || 1,
        image_urls: imageUrl ? [imageUrl] : [PLACEHOLDER_IMAGE],
        // New products start as pending — admin reviews before going live
        moderation_status: 'pending',
        is_active: false,
        is_hero: false,
        created_at: new Date().toISOString(),
      };

      const { data, error } = await supabase
        .from('products')
        .insert([productData])
        .select()
        .single();

      if (error) throw error;

      setSavedProduct(data);
      setStep('success');
      onSuccess(data);
      showToast('✅ Produit soumis — en attente de validation par notre équipe.', 'success');
    } catch (err: any) {
      showToast('Erreur lors de la publication. Réessayez.', 'error');
    } finally {
      setSaving(false);
    }
  };

  // ─── Step labels ────────────────────────────────────────────────────────────

  const steps: { key: WizardStep; label: string }[] = [
    { key: 'photo', label: 'Photo' },
    { key: 'info', label: 'Infos' },
    { key: 'stock', label: 'Stock' },
  ];

  const currentIdx = steps.findIndex(s => s.key === step);

  // ─── Render ─────────────────────────────────────────────────────────────────

  return (
    <div
      className="fixed inset-0 z-[300] flex items-end sm:items-center justify-center p-0 sm:p-4"
      onClick={e => { if (e.target === e.currentTarget) onClose(); }}
    >
      {/* Backdrop */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="absolute inset-0 bg-black/60 backdrop-blur-sm"
        onClick={onClose}
      />

      {/* Sheet */}
      <motion.div
        initial={{ y: '100%', opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        exit={{ y: '100%', opacity: 0 }}
        transition={{ type: 'spring', stiffness: 380, damping: 38 }}
        className="relative w-full sm:max-w-lg bg-white dark:bg-gray-900 rounded-t-3xl sm:rounded-3xl shadow-2xl overflow-hidden z-10"
      >
        {/* Handle (mobile) */}
        <div className="w-10 h-1 bg-gray-200 dark:bg-gray-700 rounded-full mx-auto mt-3 mb-1 sm:hidden" />

        {/* Header */}
        <div className="flex items-center justify-between px-6 pt-4 pb-4 border-b border-gray-100 dark:border-white/5">
          <div>
            <h2 className="text-[16px] font-black text-gray-900 dark:text-white uppercase tracking-tighter italic">
              {step === 'success' ? '🎉 Produit publié !' : 'Mon premier article'}
            </h2>
            {step !== 'success' && (
              <p className="text-[11px] text-gray-400 font-bold uppercase tracking-wider">
                Étape {currentIdx + 1} sur {steps.length} — {steps[currentIdx]?.label}
              </p>
            )}
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-gray-100 dark:bg-gray-800 flex items-center justify-center hover:bg-gray-200 dark:hover:bg-gray-700 transition-colors"
          >
            <X className="w-4 h-4 text-gray-500" />
          </button>
        </div>

        {/* Progress bar */}
        {step !== 'success' && (
          <div className="px-6 pt-3">
            <div className="h-1 bg-gray-100 dark:bg-gray-800 rounded-full overflow-hidden">
              <motion.div
                animate={{ width: `${((currentIdx + 1) / steps.length) * 100}%` }}
                transition={{ duration: 0.4, ease: 'easeOut' }}
                className="h-full bg-gradient-to-r from-[#ff6600] to-amber-500 rounded-full"
              />
            </div>
          </div>
        )}

        {/* Body */}
        <div className="px-6 py-6 min-h-[320px]">
          <AnimatePresence mode="wait">

            {/* ── Step 1: Photo ─────────────────────────────────────────── */}
            {step === 'photo' && (
              <motion.div
                key="photo"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                transition={{ duration: 0.2 }}
              >
                <p className="text-[13px] font-bold text-gray-500 dark:text-gray-400 mb-4">
                  Une bonne photo augmente vos ventes de 3×. Vous pouvez aussi passer cette étape.
                </p>

                {imageUrl ? (
                  <div className="relative w-full aspect-video rounded-2xl overflow-hidden border border-gray-200 dark:border-white/10 mb-4">
                    <img src={imageUrl} alt="Aperçu" className="w-full h-full object-cover" />
                    <button
                      onClick={() => setImageUrl('')}
                      className="absolute top-2 right-2 w-7 h-7 bg-black/60 rounded-full flex items-center justify-center"
                    >
                      <X className="w-3.5 h-3.5 text-white" />
                    </button>
                    <div className="absolute bottom-2 left-2 bg-green-500 text-white text-[10px] font-black px-2 py-0.5 rounded-full uppercase tracking-wider flex items-center gap-1">
                      <Check className="w-3 h-3" /> Photo ajoutée
                    </div>
                  </div>
                ) : (
                  <div
                    ref={dropRef}
                    onDragOver={e => { e.preventDefault(); setDragging(true); }}
                    onDragLeave={() => setDragging(false)}
                    onDrop={handleDrop}
                    onClick={() => fileInputRef.current?.click()}
                    className={`w-full aspect-video rounded-2xl border-2 border-dashed flex flex-col items-center justify-center gap-3 cursor-pointer transition-all ${
                      dragging
                        ? 'border-[#ff6600] bg-orange-50 dark:bg-orange-900/10'
                        : 'border-gray-200 dark:border-gray-700 hover:border-[#ff6600]/50 hover:bg-orange-50/30 dark:hover:bg-orange-900/5'
                    }`}
                  >
                    {uploading ? (
                      <Loader2 className="w-8 h-8 text-[#ff6600] animate-spin" />
                    ) : (
                      <>
                        <div className="w-14 h-14 bg-gray-50 dark:bg-gray-800 rounded-2xl flex items-center justify-center">
                          <Camera className="w-7 h-7 text-gray-400" />
                        </div>
                        <div className="text-center">
                          <p className="text-[13px] font-black text-gray-900 dark:text-white">
                            Glissez une photo ici
                          </p>
                          <p className="text-[11px] text-gray-400 font-bold">ou cliquez pour choisir</p>
                        </div>
                        <div className="flex items-center gap-1.5 bg-[#ff6600]/10 px-3 py-1.5 rounded-full">
                          <ImageIcon className="w-3 h-3 text-[#ff6600]" />
                          <span className="text-[10px] font-black text-[#ff6600] uppercase tracking-wider">JPEG · PNG · WebP · max 5 Mo</span>
                        </div>
                      </>
                    )}
                  </div>
                )}

                {uploadError && (
                  <p className="flex items-center gap-1.5 text-[11px] text-rose-600 font-bold mt-2">
                    <AlertCircle className="w-3.5 h-3.5" /> {uploadError}
                  </p>
                )}

                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*"
                  className="hidden"
                  onChange={handleFileChange}
                />
              </motion.div>
            )}

            {/* ── Step 2: Infos ─────────────────────────────────────────── */}
            {step === 'info' && (
              <motion.div
                key="info"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                transition={{ duration: 0.2 }}
                className="space-y-4"
              >
                {/* Title */}
                <div>
                  <label className="text-[11px] font-black text-gray-500 dark:text-gray-400 uppercase tracking-wider block mb-1.5">
                    Nom du produit *
                  </label>
                  <input
                    type="text"
                    value={title}
                    onChange={e => { setTitle(e.target.value); setInfoErrors(p => ({ ...p, title: undefined })); }}
                    placeholder="Ex: iPhone 13 Pro Max 256 Go"
                    maxLength={100}
                    className={`w-full px-4 py-3 rounded-xl border text-[14px] font-bold text-gray-900 dark:text-white bg-white dark:bg-gray-800 placeholder:text-gray-300 dark:placeholder:text-gray-600 focus:outline-none focus:ring-2 focus:ring-[#ff6600]/30 transition-all ${
                      infoErrors.title
                        ? 'border-rose-400 dark:border-rose-500'
                        : 'border-gray-200 dark:border-gray-700 focus:border-[#ff6600]'
                    }`}
                  />
                  {infoErrors.title && (
                    <p className="text-[11px] text-rose-600 font-bold mt-1">{infoErrors.title}</p>
                  )}
                </div>

                {/* Category */}
                <div className="form-field">
                  <label className="form-label">Catégorie</label>
                  <select
                    value={category}
                    onChange={e => setCategory(e.target.value)}
                    className="form-select"
                  >
                    {(Array.isArray(PRODUCT_CATEGORIES) ? PRODUCT_CATEGORIES : []).map((cat: string) => (
                      <option key={cat} value={cat}>{cat}</option>
                    ))}
                  </select>
                </div>

                {/* Price */}
                <div>
                  <label className="text-[11px] font-black text-gray-500 dark:text-gray-400 uppercase tracking-wider block mb-1.5">
                    Prix de vente (GNF) *
                  </label>
                  <div className="relative">
                    <input
                      type="number"
                      value={price}
                      onChange={e => { setPrice(e.target.value); setInfoErrors(p => ({ ...p, price: undefined })); }}
                      placeholder="Ex: 250 000"
                      min={0}
                      className={`w-full px-4 py-3 pr-16 rounded-xl border text-[14px] font-bold text-gray-900 dark:text-white bg-white dark:bg-gray-800 placeholder:text-gray-300 dark:placeholder:text-gray-600 focus:outline-none focus:ring-2 focus:ring-[#ff6600]/30 transition-all ${
                        infoErrors.price
                          ? 'border-rose-400 dark:border-rose-500'
                          : 'border-gray-200 dark:border-gray-700 focus:border-[#ff6600]'
                      }`}
                    />
                    <span className="absolute right-4 top-1/2 -translate-y-1/2 text-[11px] font-black text-gray-400 uppercase">GNF</span>
                  </div>
                  {infoErrors.price && (
                    <p className="text-[11px] text-rose-600 font-bold mt-1">{infoErrors.price}</p>
                  )}
                  {price && !isNaN(parseFloat(price)) && (
                    <p className="text-[10px] font-black text-[#ff6600] mt-1">
                      ≈ {(parseFloat(price) / 10000).toFixed(0)} 000 GNF
                    </p>
                  )}
                </div>
              </motion.div>
            )}

            {/* ── Step 3: Stock ─────────────────────────────────────────── */}
            {step === 'stock' && (
              <motion.div
                key="stock"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                transition={{ duration: 0.2 }}
                className="space-y-4"
              >
                {/* Quantity */}
                <div>
                  <label className="text-[11px] font-black text-gray-500 dark:text-gray-400 uppercase tracking-wider block mb-1.5">
                    Quantité disponible
                  </label>
                  <div className="flex items-center gap-3">
                    <button
                      onClick={() => setQuantity(q => String(Math.max(1, parseInt(q) - 1)))}
                      className="w-10 h-10 rounded-xl border border-gray-200 dark:border-gray-700 flex items-center justify-center text-lg font-bold text-gray-900 dark:text-white hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors"
                    >
                      –
                    </button>
                    <input
                      type="number"
                      value={quantity}
                      onChange={e => setQuantity(String(Math.max(1, parseInt(e.target.value) || 1)))}
                      min={1}
                      className="flex-1 px-4 py-2.5 rounded-xl border border-gray-200 dark:border-gray-700 text-[16px] font-black text-center text-gray-900 dark:text-white bg-white dark:bg-gray-800 focus:outline-none focus:border-[#ff6600]"
                    />
                    <button
                      onClick={() => setQuantity(q => String(parseInt(q) + 1))}
                      className="w-10 h-10 rounded-xl border border-gray-200 dark:border-gray-700 flex items-center justify-center text-lg font-bold text-gray-900 dark:text-white hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors"
                    >
                      +
                    </button>
                  </div>
                </div>

                {/* Condition */}
                <div>
                  <label className="text-[11px] font-black text-gray-500 dark:text-gray-400 uppercase tracking-wider block mb-2">
                    État du produit
                  </label>
                  <div className="grid grid-cols-2 gap-3">
                    {(['new', 'used'] as const).map(c => (
                      <button
                        key={c}
                        onClick={() => setCondition(c)}
                        className={`py-3 rounded-xl border-2 text-[12px] font-black uppercase tracking-wide transition-all ${
                          condition === c
                            ? 'border-[#ff6600] bg-[#ff6600]/5 text-[#ff6600]'
                            : 'border-gray-200 dark:border-gray-700 text-gray-500 hover:border-gray-300'
                        }`}
                      >
                        {c === 'new' ? '✨ Neuf' : '📦 Occasion'}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Description (optional) */}
                <div>
                  <label className="text-[11px] font-black text-gray-500 dark:text-gray-400 uppercase tracking-wider block mb-1.5">
                    Description courte <span className="font-normal normal-case">(optionnel)</span>
                  </label>
                  <textarea
                    value={description}
                    onChange={e => setDescription(e.target.value)}
                    placeholder="Décrivez votre article en quelques mots..."
                    rows={3}
                    maxLength={300}
                    className="w-full px-4 py-3 rounded-xl border border-gray-200 dark:border-gray-700 text-[13px] font-medium text-gray-900 dark:text-white bg-white dark:bg-gray-800 placeholder:text-gray-300 dark:placeholder:text-gray-600 focus:outline-none focus:ring-2 focus:ring-[#ff6600]/30 focus:border-[#ff6600] resize-none transition-all"
                  />
                  <p className="text-[10px] text-gray-400 font-bold text-right mt-0.5">{description.length}/300</p>
                </div>
              </motion.div>
            )}

            {/* ── Success ───────────────────────────────────────────────── */}
            {step === 'success' && (
              <motion.div
                key="success"
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.3 }}
                className="flex flex-col items-center justify-center text-center py-8 gap-5"
              >
                <motion.div
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ type: 'spring', delay: 0.1, stiffness: 300, damping: 20 }}
                  className="w-20 h-20 bg-green-50 dark:bg-green-900/20 rounded-[2rem] flex items-center justify-center"
                >
                  <Check className="w-10 h-10 text-green-500" />
                </motion.div>
                <div>
                  <h3 className="text-[20px] font-black text-gray-900 dark:text-white tracking-tighter italic mb-1">
                    Soumis avec succès !
                  </h3>
                  <p className="text-[13px] text-gray-500 font-medium">
                    <strong className="text-gray-900 dark:text-white">{title}</strong> est en attente de validation.
                    Notre équipe l'examinera sous 24 h avant de le rendre visible sur FATIBARA.
                  </p>
                </div>
                <div className="flex flex-col sm:flex-row gap-3 w-full">
                  <button
                    onClick={onClose}
                    className="flex-1 py-3 rounded-xl border border-gray-200 dark:border-gray-700 text-[13px] font-bold text-gray-600 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors"
                  >
                    Retour au tableau de bord
                  </button>
                  <button
                    onClick={() => {
                      // Reset and start again for second product
                      setStep('photo'); setTitle(''); setPrice(''); setQuantity('1');
                      setDescription(''); setImageUrl(''); setCondition('new');
                    }}
                    className="flex-1 py-3 rounded-xl bg-[#ff6600] text-white text-[13px] font-black hover:bg-[#e65c00] transition-colors flex items-center justify-center gap-2"
                  >
                    <Package className="w-4 h-4" /> Ajouter un autre
                  </button>
                </div>
              </motion.div>
            )}

          </AnimatePresence>
        </div>

        {/* Footer nav */}
        {step !== 'success' && (
          <div className="px-6 pb-6 flex items-center justify-between gap-3">
            <button
              onClick={step === 'photo' ? onClose : goBack}
              className="flex items-center gap-1.5 text-[12px] font-bold text-gray-400 hover:text-gray-600 dark:hover:text-gray-300 transition-colors"
            >
              {step !== 'photo' && <ChevronLeft className="w-4 h-4" />}
              {step === 'photo' ? (
                <span className="text-[11px] uppercase tracking-wide">Passer cette étape →</span>
              ) : (
                'Retour'
              )}
            </button>

            <button
              onClick={goNext}
              disabled={uploading || saving}
              className="flex items-center gap-2 bg-[#ff6600] text-white px-6 py-3 rounded-xl text-[13px] font-black uppercase tracking-wide hover:bg-[#e65c00] disabled:opacity-50 disabled:cursor-not-allowed transition-all shadow-lg shadow-[#ff6600]/20 active:scale-[0.98]"
            >
              {saving ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : step === 'stock' ? (
                <>
                  <Tag className="w-4 h-4" /> Publier l'article
                </>
              ) : (
                <>
                  Suivant <ChevronRight className="w-4 h-4" />
                </>
              )}
            </button>
          </div>
        )}
      </motion.div>
    </div>
  );
}
