import React from 'react';
import { motion } from 'motion/react';
import { Package, Truck, MapPin, CheckCircle, Clock, ShieldCheck, Box, ChevronRight, Phone, MessageSquare } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { APP_NAME } from '../lib/constants';

interface LogisticsStep {
  status: string;
  label: string;
  description: string;
  time?: string;
  isCompleted: boolean;
  isCurrent: boolean;
  icon: any;
}

export default function OrderTimeline({ currentStatus = 'pending', orderId }: { currentStatus: string; orderId?: string }) {
  const [orderData, setOrderData] = React.useState<any>(null);
  const [liveStatus, setLiveStatus] = React.useState<string>(currentStatus);

  // ── Initial fetch ───────────────────────────────────────────────────────────
  React.useEffect(() => {
    if (!orderId) return;
    let isMounted = true;
    supabase
      .from('orders')
      .select('*')
      .eq('id', orderId)
      .single()
      .then(({ data }) => {
        if (isMounted && data) {
          setOrderData(data);
          setLiveStatus(data.status ?? currentStatus);
        }
      });
    return () => {
      isMounted = false;
    };
  }, [orderId]);

  // ── Realtime subscription — live status updates for the buyer ───────────────
  // Fires whenever the vendor or courier updates the order row, so the buyer
  // sees status transitions without needing to refresh the page.
  React.useEffect(() => {
    if (!orderId) return;
    const channel = supabase
      .channel(`order-timeline-${orderId}`)
      .on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'orders',
          filter: `id=eq.${orderId}`,
        },
        (payload: any) => {
          if (payload.new) {
            setOrderData((prev: any) => ({ ...prev, ...payload.new }));
            if (payload.new.status) setLiveStatus(payload.new.status);
          }
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [orderId]);

  // Derive the displayed status: prefer the live Realtime state, fall back to
  // the prop (which the parent may keep stale until it also re-fetches).
  const displayStatus = liveStatus || currentStatus;

  // ── Status step definitions (aligned to actual DB order.status values) ─────
  // Real lifecycle: pending → accepted → preparing → ready_for_pickup
  //                 → in_transit → out_for_delivery → delivered
  // NOTE: 'processing' is NOT a real order.status value — it only appears on
  // financial_status. Using it in isCurrent meant step 2 never highlighted.
  const PREPARING_STATES  = ['accepted', 'preparing', 'confirmed'];
  const IN_TRANSIT_STATES = ['ready_for_pickup', 'in_transit', 'out_for_delivery'];
  const DONE_STATES       = ['delivered'];

  const steps: LogisticsStep[] = [
    {
      status: 'pending',
      label: 'Confirmation',
      description: `Audit de sécurité ${APP_NAME} validé`,
      isCompleted: [...PREPARING_STATES, ...IN_TRANSIT_STATES, ...DONE_STATES].includes(displayStatus),
      isCurrent:   displayStatus === 'pending',
      icon: CheckCircle,
    },
    {
      status: 'preparing',
      label: 'Préparation',
      description: 'Le vendeur emballe vos articles',
      isCompleted: [...IN_TRANSIT_STATES, ...DONE_STATES].includes(displayStatus),
      isCurrent:   PREPARING_STATES.includes(displayStatus),
      icon: Box,
    },
    {
      status: 'in_transit',
      label: 'Transit',
      description: 'En route vers votre adresse',
      isCompleted: DONE_STATES.includes(displayStatus),
      isCurrent:   IN_TRANSIT_STATES.includes(displayStatus),
      icon: Truck,
    },
    {
      status: 'delivered',
      label: 'Livré',
      description: 'Colis remis avec succès',
      isCompleted: displayStatus === 'delivered',
      isCurrent:   displayStatus === 'delivered',
      icon: Package,
    },
  ];

  return (
    <div className="bg-white dark:bg-[#1A1D21] rounded-[3rem] p-6 md:p-10 border border-gray-100 dark:border-white/5 shadow-sm">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6 mb-12">
        <div>
          <div className="flex items-center gap-3 mb-2">
            <span className="text-[10px] font-black text-[#ff6600] uppercase tracking-[0.3em] italic">Tracking ID FATIBARA</span>
            <div className="px-3 py-1 bg-[#ff6600]/10 text-[#ff6600] rounded-full text-[10px] font-black border border-[#ff6600]/20">
               #{orderId?.slice(0, 12).toUpperCase()}
            </div>
          </div>
          <h2 className="text-2xl md:text-3xl font-black text-gray-900 dark:text-white uppercase italic tracking-tighter">Status Logistique</h2>
        </div>
        <div className="bg-gray-50 dark:bg-black/20 p-4 rounded-2xl border border-gray-100 dark:border-white/5 flex items-center gap-4">
           <MapPin className="w-8 h-8 text-blue-500" />
           <div>
              <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest leading-none mb-1">Hub Destination</p>
              <p className="text-[13px] font-black text-gray-900 dark:text-white uppercase italic">Centre National {APP_NAME}</p>
           </div>
        </div>
      </div>

      <div className="relative">
        <div className="absolute left-[23px] top-6 bottom-6 w-1 bg-gray-100 dark:bg-white/5 md:hidden" />
        <div className="hidden md:block absolute left-6 right-6 top-[23px] h-1 bg-gray-100 dark:bg-white/5" />

        <div className="flex flex-col md:flex-row justify-between gap-10">
          {steps.map((step, i) => (
            <div key={i} className="relative z-10 flex flex-row md:flex-col items-start md:items-center gap-6 md:text-center group">
               <motion.div 
                 initial={{ scale: 0.8, opacity: 0 }}
                 animate={{ scale: 1, opacity: 1 }}
                 transition={{ delay: i * 0.1 }}
                 className={`w-12 h-12 rounded-2xl flex items-center justify-center border-4 border-white dark:border-[#1A1D21] transition-all duration-500 ${
                   step.isCompleted 
                     ? 'bg-[#ff6600] text-white shadow-lg shadow-[#ff6600]/20' 
                     : step.isCurrent 
                       ? 'bg-white dark:bg-gray-800 text-[#ff6600] border-[#ff6600] animate-pulse'
                       : 'bg-gray-50 dark:bg-black/40 text-gray-400 grayscale'
                 }`}
               >
                 <step.icon className="w-5 h-5" />
               </motion.div>

               <div className="flex flex-col md:items-center">
                  <h4 className={`text-[12px] font-black uppercase tracking-tight mb-1 ${step.isCompleted || step.isCurrent ? 'text-gray-900 dark:text-white' : 'text-gray-400'}`}>
                    {step.label}
                  </h4>
                  <p className="text-[10px] font-bold text-gray-400 dark:text-gray-500 max-w-[150px] leading-tight">
                    {step.description}
                  </p>
               </div>
            </div>
          ))}
        </div>
      </div>

      {orderData?.delivery_otp && currentStatus !== 'delivered' && (
        <div className="mt-12 p-8 bg-gray-900 dark:bg-black rounded-[2rem] text-center relative overflow-hidden">
           <div className="absolute top-0 right-0 w-32 h-32 bg-[#ff6600] opacity-20 blur-[60px]" />
           <p className="text-[10px] font-black tracking-[0.3em] text-[#ff6600] mb-4 uppercase italic">Code de Validation</p>
           <p className="text-5xl font-black tracking-[0.2em] text-white tabular-nums drop-shadow-lg">{orderData.delivery_otp}</p>
           <p className="text-[9px] font-black tracking-widest text-white/40 mt-6 uppercase max-w-xs mx-auto">
             Donnez ce code au livreur UNIQUEMENT après réception et vérification du colis.
           </p>
        </div>
      )}

      {orderData?.courier_id && (
        <div className="mt-12 p-8 bg-blue-500/5 border border-blue-500/10 rounded-[2.5rem] flex flex-col sm:flex-row items-center justify-between gap-6">
           <div className="flex items-center gap-5">
              <div className="w-14 h-14 bg-blue-500 rounded-2xl flex items-center justify-center text-white">
                 <ShieldCheck className="w-8 h-8" />
              </div>
              <div>
                 <h4 className="text-[13px] font-black text-gray-900 dark:text-white uppercase italic tracking-tighter">Livreur Assigné</h4>
                 <p className="text-[11px] font-bold text-gray-400 uppercase tracking-widest">Protection {APP_NAME} Active</p>
              </div>
           </div>
           
           <div className="flex gap-3 w-full sm:w-auto">
             <a 
               href={`tel:${orderData.courier_phone || ''}`}
               className="flex-1 sm:px-6 py-4 bg-white dark:bg-gray-800 text-gray-900 dark:text-white rounded-2xl text-[10px] font-black uppercase tracking-[0.2em] border border-gray-100 dark:border-white/5 shadow-sm text-center"
             >
                Appeler
             </a>
             <a 
                href={`https://wa.me/${orderData.courier_phone?.replace(/\+/g, '') || ''}?text=Bonjour, je suis le client pour la commande #${orderId?.slice(0, 8)}`}
                target="_blank"
                rel="noopener noreferrer"
                className="flex-1 sm:px-6 py-4 bg-[#25D366] text-white rounded-2xl text-[10px] font-black uppercase tracking-[0.2em] shadow-lg shadow-green-500/20 text-center"
             >
                WhatsApp
             </a>
           </div>
        </div>
      )}
    </div>
  );
}
