import { Home, Search, Store, User } from 'lucide-react';
import { Link, useLocation } from 'react-router-dom';
import { motion, AnimatePresence } from 'motion/react';
import { hapticFeedback } from '../lib/haptics';
import { useAppContext } from '../context/AppContext';

const NAV_ITEMS = [
  { path: '/', label: 'Accueil', icon: Home },
  { path: '/search', label: 'Recherche', icon: Search },
  { path: '/shop', label: 'Boutique', icon: Store },
  { path: '/dashboard', label: 'Compte', icon: User }
];

export default function BottomNav() {
  const location = useLocation();
  const { unreadMessagesCount } = useAppContext();

  return (
    <nav className="fixed bottom-0 left-0 w-full bg-white/80 dark:bg-gray-950/80 backdrop-blur-xl border-t border-gray-200 dark:border-white/5 pb-safe pb-2 pt-2 px-1 flex justify-between items-center z-50 md:hidden shadow-[0_-8px_24px_rgba(0,0,0,0.1)]">
      {NAV_ITEMS.map((item) => {
        const isActive = location.pathname === item.path;
        const Icon = item.icon;
        const showBadge = item.path === '/dashboard' && unreadMessagesCount > 0;

        return (
          <Link
            key={item.path}
            to={item.path}
            onClick={() => hapticFeedback(isActive ? 'light' : 'selection')}
            // min h-[56px] ensures the 44×44 px minimum touch target (WCAG 2.5.5)
            // active:scale-95 gives tactile press feedback on mobile devices
            className="relative flex flex-col items-center justify-center w-full min-h-[56px] h-[56px] gap-1 transition-all active:scale-95 duration-150 group"
          >
            <div className={`relative flex items-center justify-center transition-all duration-300 ${isActive ? '-translate-y-1' : 'group-active:scale-95'}`}>
              <Icon 
                className={`transition-all duration-300 ${isActive ? 'w-6 h-6 stroke-[2.5] text-[#ff6600]' : 'w-6 h-6 stroke-2 text-gray-400 group-hover:text-gray-900 dark:group-hover:text-white'}`} 
              />
              {isActive && (
                <motion.div 
                  layoutId="nav-pill-indicator"
                  className="absolute -top-1 -right-1 w-2 h-2 bg-[#ff6600] rounded-full border-2 border-white dark:border-gray-950 shadow-sm"
                  transition={{ type: "spring", bounce: 0.15, duration: 0.5 }}
                />
              )}
              {/* Unread messages badge */}
              <AnimatePresence>
                {showBadge && (
                  <motion.span
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    exit={{ scale: 0 }}
                    className="absolute -top-1.5 -right-2 min-w-[16px] h-4 bg-[#ff6600] text-white text-[9px] font-black rounded-full flex items-center justify-center px-1 border border-white dark:border-gray-950 shadow-sm"
                  >
                    {unreadMessagesCount > 9 ? '9+' : unreadMessagesCount}
                  </motion.span>
                )}
              </AnimatePresence>
            </div>
            
            <span className={`text-[9px] font-black uppercase tracking-widest transition-all ${isActive ? 'text-[#ff6600] opacity-100' : 'text-gray-400 opacity-75'}`}>
              {item.label}
            </span>
          </Link>
        );
      })}
    </nav>
  );
}

