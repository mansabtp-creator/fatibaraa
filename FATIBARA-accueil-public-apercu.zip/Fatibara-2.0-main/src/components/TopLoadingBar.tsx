import { motion, AnimatePresence } from 'motion/react';
import { useStore } from '../store/useStore';

export default function TopLoadingBar() {
  const { isNavigating } = useStore();

  return (
    <AnimatePresence>
      {isNavigating && (
        <motion.div
          initial={{ width: '0%', opacity: 1 }}
          animate={{ width: '70%', opacity: 1 }}
          exit={{ width: '100%', opacity: 0 }}
          transition={{ 
            duration: 0.8, 
            ease: "easeInOut",
            opacity: { delay: 0.2 }
          }}
          className="fixed top-0 left-0 h-1 bg-[#ff6600] z-[9999] shadow-sm"
        />
      )}
    </AnimatePresence>
  );
}
