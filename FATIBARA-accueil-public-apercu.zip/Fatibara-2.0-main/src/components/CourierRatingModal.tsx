import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Star, X, Truck, Loader2, Send } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { useAppContext } from '../context/AppContext';
import { useToast } from '../context/ToastContext';
import { APP_NAME } from '../lib/constants';

interface CourierRatingModalProps {
  isOpen: boolean;
  onClose: () => void;
  orderId: string;
  courierId: string;
  onSuccess: () => void;
}

export default function CourierRatingModal({ isOpen, onClose, orderId, courierId, onSuccess }: CourierRatingModalProps) {
  const { user } = useAppContext();
  const { showToast } = useToast();
  const [rating, setRating] = useState(0);
  const [hoverRating, setHoverRating] = useState(0);
  const [feedback, setFeedback] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;
    if (rating === 0) {
      showToast("Veuillez sélectionner une note", "warning");
      return;
    }

    setSubmitting(true);
    try {
      const { error } = await supabase
        .from('courier_ratings')
        .insert([{
          order_id: orderId,
          courier_id: courierId,
          user_id: user.id,
          rating,
          feedback
        }]);

      if (error) throw error;

      // Reward user with loyalty points for feedback
      try {
        await supabase.rpc('increment_loyalty_points', { 
          user_id: user.id, 
          points: 15 
        });
      } catch (lErr) {
        console.error("Failed to reward points", lErr);
      }

      showToast("Merci d'avoir noté votre livreur ! +15 pts.", 'success');
      onSuccess();
      onClose();
    } catch (err: any) {
      if (err.code === '23505') {
        showToast("Vous avez déjà noté cette livraison.", 'info');
        onClose();
      } else {
        showToast("Une erreur est survenue.", 'error');
      }
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="absolute inset-0 bg-gray-900/20 backdrop-blur-md"
          />
          
          <motion.div
            initial={{ opacity: 0, scale: 0.9, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9, y: 20 }}
            className="bg-white dark:bg-gray-900 w-full max-w-lg rounded-3xl shadow-xl overflow-hidden relative z-10 border border-gray-100 dark:border-white/5"
          >
            <div className="p-8 md:p-10">
              <div className="flex justify-between items-center mb-6">
                <div className="w-12 h-12 bg-orange-50 dark:bg-orange-900/20 border border-orange-100 dark:border-orange-800/30 rounded-2xl shadow-sm flex items-center justify-center text-[#ff6600] dark:text-orange-400">
                  <Truck className="w-6 h-6" />
                </div>
                <button 
                  onClick={onClose} 
                  className="p-2.5 bg-gray-50 bg-gray-50 dark:bg-gray-800 text-gray-500 text-gray-500 dark:text-gray-400 rounded-xl border border-gray-200 dark:border-gray-700 dark:border-white/5 hover:bg-gray-100 dark:hover:bg-gray-700 transition-all active:scale-95"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <h2 className="text-2xl font-bold text-gray-900 text-gray-900 dark:text-white tracking-tight mb-2">Livreur Adoré ?</h2>
              <p className="text-gray-500 text-gray-500 dark:text-gray-400 font-medium text-sm mb-8 leading-relaxed">Notez la rapidité et la courtoisie de votre coursier {APP_NAME}.</p>

              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="space-y-3">
                  <div className="flex justify-between items-center">
                    <label className="text-[11px] font-bold tracking-wider text-gray-400 dark:text-gray-500 dark:text-gray-400 ml-1">Note globale</label>
                    {rating === 0 && <span className="text-[10px] font-bold tracking-wider text-[#ff6600]">Obligatoire</span>}
                  </div>
                  <div className="flex gap-3">
                    {[1, 2, 3, 4, 5].map((i) => (
                      <button
                        key={i}
                        type="button"
                        onMouseEnter={() => setHoverRating(i)}
                        onMouseLeave={() => setHoverRating(0)}
                        onClick={() => setRating(i)}
                        className="transition-transform active:scale-90"
                      >
                        <Star 
                          className={`w-10 h-10 transition-all duration-300 ${
                            i <= (hoverRating || rating) 
                              ? 'fill-[#ff6600] text-[#ff6600] dark:fill-orange-400 dark:text-orange-400 drop-shadow-md' 
                              : 'text-gray-200 dark:text-gray-700 fill-gray-50 dark:fill-gray-800'
                          }`} 
                        />
                      </button>
                    ))}
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-[11px] font-bold tracking-wider text-gray-400 dark:text-gray-500 dark:text-gray-400 ml-1">Commentaire (Optionnel)</label>
                  <textarea
                    value={feedback}
                    onChange={(e) => setFeedback(e.target.value)}
                    placeholder="Rapide, poli, professionnel..."
                    className="w-full bg-white dark:bg-gray-900 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 dark:border-white/5 rounded-xl p-4 text-sm font-medium text-gray-900 text-gray-900 dark:text-white focus:outline-none focus:border-[#ff6600] dark:focus:border-orange-400 focus:ring-4 focus:ring-[#ff6600]/10 dark:focus:ring-orange-400/10 transition-all min-h-[120px] resize-none shadow-sm"
                  />
                </div>

                <button
                  type="submit"
                  disabled={submitting}
                  className="w-full bg-gray-900 dark:bg-[#ff6600] text-white rounded-xl py-4 font-semibold shadow-sm hover:bg-gray-800 dark:hover:bg-[#ff6600] active:scale-[0.98] disabled:opacity-50 flex items-center justify-center gap-3 transition-all"
                >
                  {submitting ? <Loader2 className="w-5 h-5 animate-spin" /> : <Send className="w-5 h-5" />}
                  <span>{submitting ? 'ENVOI...' : 'NOTER LE LIVREUR'}</span>
                </button>
              </form>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}
