import { useState, useRef, useEffect } from 'react';
import { MapPin, ChevronDown, Search, Check, Navigation, Truck } from 'lucide-react';
import { GUINEA_LOCATIONS } from '../constants/locations';

// ─── Zone groupings for the combobox quick-select chips ───────────────────────
const CONAKRY_ZONES = GUINEA_LOCATIONS['Conakry'];

const ZONE_GROUPS = [
  {
    label: 'Centre-Ville',
    color: 'text-blue-600 dark:text-blue-400',
    bg: 'bg-blue-50 dark:bg-blue-900/20 border-blue-200 dark:border-blue-500/30',
    communes: ['Kaloum', 'Dixinn', 'Matam'],
  },
  {
    label: 'Sonfonia / Foula Madina',
    color: 'text-orange-600 dark:text-orange-400',
    bg: 'bg-orange-50 dark:bg-orange-900/20 border-orange-200 dark:border-orange-500/30',
    communes: ['Sonfonia', 'Foula Madina', 'Gbessia', 'Tombolia'],
  },
  {
    label: 'Ratoma / Lambanyi',
    color: 'text-emerald-600 dark:text-emerald-400',
    bg: 'bg-emerald-50 dark:bg-emerald-900/20 border-emerald-200 dark:border-emerald-500/30',
    communes: ['Ratoma', 'Lambanyi', 'Matoto'],
  },
  {
    label: 'Périphérie',
    color: 'text-purple-600 dark:text-purple-400',
    bg: 'bg-purple-50 dark:bg-purple-900/20 border-purple-200 dark:border-purple-500/30',
    communes: ['Kassa', 'Sanoyah', 'Maneah', 'Kagbelen'],
  },
];

// ─── Delivery time lookup ─────────────────────────────────────────────────────
const DELIVERY_TIMES: Record<string, string> = {
  Kaloum: '2-4h', Dixinn: '3-5h', Matam: '3-5h',
  Ratoma: '4-8h', Matoto: '4-8h', Lambanyi: '4-8h',
  Sonfonia: '4-8h', 'Foula Madina': '4-8h', Gbessia: '3-5h',
  Tombolia: '4-8h', Kassa: '24h', Sanoyah: '8-12h',
  Maneah: '8-12h', Kagbelen: '8-12h',
};

// ─── Props ────────────────────────────────────────────────────────────────────
interface StoreAreaOfOperationProps {
  /** View-only mode: pass the store's location_commune value */
  commune?: string | null;
  /** Edit mode: controlled value */
  value?: string;
  /** Edit mode: onChange callback */
  onChange?: (commune: string) => void;
  /** Set to true to render in editable combobox mode */
  editable?: boolean;
  className?: string;
}

// ─── VIEW MODE ────────────────────────────────────────────────────────────────
function AreaBadge({ commune }: { commune: string }) {
  const deliveryTime = DELIVERY_TIMES[commune];
  const group = ZONE_GROUPS.find((g) => g.communes.includes(commune));

  return (
    <div className="flex flex-col gap-3">
      {/* Primary commune badge */}
      <div className="flex items-center gap-3 p-4 bg-gradient-to-r from-[#ff6600]/10 to-orange-50 dark:from-[#ff6600]/10 dark:to-orange-900/10 border border-[#ff6600]/30 rounded-2xl">
        <div className="w-10 h-10 bg-[#ff6600] rounded-xl flex items-center justify-center flex-shrink-0 shadow-md shadow-[#ff6600]/30">
          <MapPin className="w-5 h-5 text-white" />
        </div>
        <div className="flex-1 min-w-0">
          <p className="text-[10px] font-black text-[#ff6600] uppercase tracking-widest leading-none mb-1">
            Commune Centrale
          </p>
          <p className="text-[16px] font-black text-gray-900 dark:text-white tracking-tight">
            {commune}
          </p>
        </div>
        {deliveryTime && (
          <div className="flex flex-col items-end text-right flex-shrink-0">
            <Truck className="w-3.5 h-3.5 text-gray-400 mb-1" />
            <span className="text-[10px] font-bold text-gray-500 dark:text-gray-400 leading-none">
              {deliveryTime}
            </span>
          </div>
        )}
      </div>

      {/* Zone group pill */}
      {group && (
        <div className={`inline-flex items-center gap-2 self-start px-3 py-1.5 rounded-full border text-[11px] font-bold tracking-wide ${group.bg} ${group.color}`}>
          <Navigation className="w-3 h-3" />
          {group.label}
        </div>
      )}

      {/* Sibling zone chips */}
      {group && group.communes.filter((c) => c !== commune).length > 0 && (
        <div className="space-y-1.5">
          <p className="text-[9px] font-black text-gray-400 uppercase tracking-widest">
            Zones couvertes à proximité
          </p>
          <div className="flex flex-wrap gap-2">
            {group.communes
              .filter((c) => c !== commune)
              .map((z) => (
                <span
                  key={z}
                  className="flex items-center gap-1.5 px-3 py-1.5 bg-gray-100 dark:bg-white/5 rounded-full text-[11px] font-bold text-gray-600 dark:text-gray-300 border border-gray-200 dark:border-white/10"
                >
                  <MapPin className="w-2.5 h-2.5 text-[#ff6600]" />
                  {z}
                </span>
              ))}
          </div>
        </div>
      )}
    </div>
  );
}

// ─── EDIT MODE — searchable combobox ─────────────────────────────────────────
function AreaCombobox({
  value,
  onChange,
}: {
  value: string;
  onChange: (v: string) => void;
}) {
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState('');
  const containerRef = useRef<HTMLDivElement>(null);

  const filtered = CONAKRY_ZONES.filter((c) =>
    c.toLowerCase().includes(query.toLowerCase())
  );

  // Close on outside click
  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setOpen(false);
        setQuery('');
      }
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, []);

  const group = ZONE_GROUPS.find((g) => g.communes.includes(value));

  return (
    <div ref={containerRef} className="relative">
      {/* Trigger button */}
      <button
        type="button"
        onClick={() => setOpen(!open)}
        className="w-full flex items-center gap-4 bg-gray-50 dark:bg-black/20 border border-gray-200 dark:border-white/10 rounded-2xl p-5 text-left hover:border-[#ff6600]/50 focus:border-[#ff6600] focus:outline-none transition-all group"
      >
        <div className="w-9 h-9 bg-[#ff6600]/10 rounded-xl flex items-center justify-center flex-shrink-0">
          <MapPin className="w-4 h-4 text-[#ff6600]" />
        </div>
        <div className="flex-1 min-w-0">
          <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest leading-none mb-0.5">
            Commune sélectionnée
          </p>
          <p className="text-[15px] font-bold text-gray-900 dark:text-white">
            {value || 'Choisir une commune...'}
          </p>
          {group && (
            <p className={`text-[10px] font-bold mt-0.5 ${group.color}`}>
              {group.label}
            </p>
          )}
        </div>
        <ChevronDown
          className={`w-5 h-5 text-gray-400 group-hover:text-[#ff6600] transition-all ${open ? 'rotate-180 text-[#ff6600]' : ''}`}
        />
      </button>

      {/* Dropdown panel */}
      {open && (
        <div className="absolute top-full left-0 right-0 mt-2 bg-white dark:bg-gray-900 border border-gray-200 dark:border-white/10 rounded-2xl shadow-2xl z-50 overflow-hidden">
          {/* Search input */}
          <div className="p-3 border-b border-gray-100 dark:border-white/5">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
              <input
                type="text"
                autoFocus
                placeholder="Rechercher une commune..."
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                className="w-full pl-9 pr-4 py-2.5 bg-gray-50 dark:bg-black/20 rounded-xl text-[13px] font-medium text-gray-900 dark:text-white placeholder-gray-400 border border-gray-100 dark:border-white/5 focus:border-[#ff6600] focus:outline-none transition-all"
              />
            </div>
          </div>

          <div className="max-h-72 overflow-y-auto">
            {/* Quick-select group chips */}
            {!query && (
              <div className="p-3 space-y-3">
                {ZONE_GROUPS.map((grp) => (
                  <div key={grp.label}>
                    <p className={`text-[9px] font-black uppercase tracking-widest mb-2 px-1 ${grp.color}`}>
                      {grp.label}
                    </p>
                    <div className="flex flex-wrap gap-1.5">
                      {grp.communes.map((c) => (
                        <button
                          key={c}
                          type="button"
                          onClick={() => { onChange(c); setOpen(false); setQuery(''); }}
                          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-[12px] font-bold border transition-all ${
                            value === c
                              ? 'bg-[#ff6600] text-white border-[#ff6600] shadow-md'
                              : `${grp.bg} ${grp.color} hover:border-current`
                          }`}
                        >
                          {value === c && <Check className="w-3 h-3" />}
                          {c}
                          {DELIVERY_TIMES[c] && (
                            <span className={`text-[9px] font-medium opacity-70`}>
                              {DELIVERY_TIMES[c]}
                            </span>
                          )}
                        </button>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            )}

            {/* Filtered search results */}
            {query && (
              <div className="p-2">
                {filtered.length === 0 ? (
                  <p className="text-center text-[12px] text-gray-400 py-6 font-medium">
                    Aucun résultat pour "{query}"
                  </p>
                ) : (
                  filtered.map((c) => (
                    <button
                      key={c}
                      type="button"
                      onClick={() => { onChange(c); setOpen(false); setQuery(''); }}
                      className={`w-full flex items-center justify-between gap-3 px-4 py-3 rounded-xl text-[13px] font-bold transition-all ${
                        value === c
                          ? 'bg-[#ff6600]/10 text-[#ff6600]'
                          : 'text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-white/5'
                      }`}
                    >
                      <span className="flex items-center gap-2">
                        <MapPin className="w-3.5 h-3.5 text-[#ff6600]" />
                        {c}
                      </span>
                      <span className="flex items-center gap-2">
                        {DELIVERY_TIMES[c] && (
                          <span className="text-[10px] font-medium text-gray-400">
                            {DELIVERY_TIMES[c]}
                          </span>
                        )}
                        {value === c && <Check className="w-4 h-4" />}
                      </span>
                    </button>
                  ))
                )}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

// ─── MAIN EXPORT ──────────────────────────────────────────────────────────────
export default function StoreAreaOfOperation({
  commune,
  value,
  onChange,
  editable = false,
  className = '',
}: StoreAreaOfOperationProps) {
  const displayCommune = editable ? value : commune;

  return (
    <div className={`space-y-4 ${className}`}>
      {/* Section header */}
      <div className="flex items-center gap-3">
        <div className="w-9 h-9 bg-[#ff6600]/10 rounded-xl flex items-center justify-center">
          <MapPin className="w-4 h-4 text-[#ff6600]" />
        </div>
        <h3 className={`font-black tracking-tight ${editable ? 'text-xl text-gray-900 dark:text-white' : 'text-[15px] uppercase text-gray-900 dark:text-white tracking-wider'}`}>
          {editable ? "Zone d'Opération" : 'Area of Operation'}
        </h3>
      </div>

      {editable && onChange ? (
        <AreaCombobox value={value || ''} onChange={onChange} />
      ) : displayCommune ? (
        <AreaBadge commune={displayCommune} />
      ) : (
        <div className="flex items-center gap-3 p-4 bg-gray-50 dark:bg-white/5 rounded-2xl border border-dashed border-gray-200 dark:border-white/10">
          <MapPin className="w-4 h-4 text-gray-300 dark:text-gray-600" />
          <span className="text-[13px] text-gray-400 font-medium">Zone non définie</span>
        </div>
      )}
    </div>
  );
}
