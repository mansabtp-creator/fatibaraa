import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'motion/react';
import type { LucideIcon } from 'lucide-react';

// ─── Types ────────────────────────────────────────────────────────────────────

type IconColor = 'orange' | 'green' | 'blue' | 'red' | 'gray' | 'amber';

interface EmptyStateAction {
  /** Button / link label */
  label: string;
  /** If provided, renders a <Link>. Otherwise renders a <button> and calls onClick. */
  href?: string;
  onClick?: () => void;
  /** Secondary variant renders a ghost button instead of filled. Default: false */
  secondary?: boolean;
}

interface EmptyStateProps {
  /** Lucide icon component to display in the halo ring */
  icon: LucideIcon;
  /** Halo / icon tint color */
  iconColor?: IconColor;
  /** Primary heading */
  title: string;
  /** Descriptive helper text */
  description?: string;
  /** Primary CTA — or pass a second item as a secondary action */
  actions?: EmptyStateAction[];
  /** Reduces vertical padding — useful inside cards / modals */
  compact?: boolean;
  /** Override for custom class on the root wrapper */
  className?: string;
}

// ─── Color map ────────────────────────────────────────────────────────────────

const COLOR_MAP: Record<IconColor, { halo: string; icon: string; btnBg: string }> = {
  orange: {
    halo: 'bg-orange-50 dark:bg-orange-900/20 ring-orange-100 dark:ring-orange-800/30',
    icon: 'text-[#ff6600]',
    btnBg: 'bg-[#ff6600] hover:bg-[#e62e00] shadow-[#ff6600]/25',
  },
  green: {
    halo: 'bg-green-50 dark:bg-green-900/20 ring-green-100 dark:ring-green-800/30',
    icon: 'text-green-600 dark:text-green-400',
    btnBg: 'bg-green-600 hover:bg-green-700 shadow-green-600/25',
  },
  blue: {
    halo: 'bg-blue-50 dark:bg-blue-900/20 ring-blue-100 dark:ring-blue-800/30',
    icon: 'text-blue-600 dark:text-blue-400',
    btnBg: 'bg-blue-600 hover:bg-blue-700 shadow-blue-600/25',
  },
  red: {
    halo: 'bg-red-50 dark:bg-red-900/20 ring-red-100 dark:ring-red-800/30',
    icon: 'text-red-500 dark:text-red-400',
    btnBg: 'bg-red-600 hover:bg-red-700 shadow-red-600/25',
  },
  amber: {
    halo: 'bg-amber-50 dark:bg-amber-900/20 ring-amber-100 dark:ring-amber-800/30',
    icon: 'text-amber-600 dark:text-amber-400',
    btnBg: 'bg-amber-500 hover:bg-amber-600 shadow-amber-500/25',
  },
  gray: {
    halo: 'bg-gray-50 dark:bg-gray-800/60 ring-gray-100 dark:ring-gray-700/30',
    icon: 'text-gray-400 dark:text-gray-500',
    btnBg: 'bg-gray-700 hover:bg-gray-800 shadow-gray-700/20 dark:bg-gray-600 dark:hover:bg-gray-500',
  },
};

// ─── Component ────────────────────────────────────────────────────────────────

export function EmptyState({
  icon: Icon,
  iconColor = 'orange',
  title,
  description,
  actions = [],
  compact = false,
  className = '',
}: EmptyStateProps) {
  const colors = COLOR_MAP[iconColor];

  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.35, ease: 'easeOut' }}
      className={`flex flex-col items-center justify-center text-center ${compact ? 'py-8 px-4' : 'py-16 px-6'} ${className}`}
    >
      {/* Halo ring + icon */}
      <motion.div
        animate={{ y: [0, -6, 0] }}
        transition={{ duration: 3.5, repeat: Infinity, ease: 'easeInOut' }}
        className={`w-20 h-20 rounded-full ring-8 flex items-center justify-center mb-6 ${colors.halo}`}
      >
        <Icon className={`w-9 h-9 ${colors.icon}`} strokeWidth={1.75} />
      </motion.div>

      {/* Text */}
      <h3 className="text-xl font-bold text-gray-900 dark:text-white tracking-tight mb-2">
        {title}
      </h3>
      {description && (
        <p className="text-sm text-gray-500 dark:text-slate-400 leading-relaxed max-w-xs">
          {description}
        </p>
      )}

      {/* Actions */}
      {actions.length > 0 && (
        <div className={`flex flex-col sm:flex-row gap-3 ${compact ? 'mt-5' : 'mt-8'} w-full max-w-xs`}>
          {actions.map((action, i) => {
            const isPrimary = !action.secondary;
            const baseClass =
              `min-h-[44px] w-full flex items-center justify-center gap-2 px-6 py-3 rounded-full text-[13px] font-bold tracking-wide transition-all active:scale-95 duration-150 shadow-lg`;

            const colorClass = isPrimary
              ? `${colors.btnBg} text-white`
              : 'bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 text-gray-700 dark:text-gray-300 hover:border-gray-300 dark:hover:border-gray-600';

            if (action.href) {
              return (
                <Link
                  key={i}
                  to={action.href}
                  className={`${baseClass} ${colorClass}`}
                >
                  {action.label}
                </Link>
              );
            }
            return (
              <button
                key={i}
                onClick={action.onClick}
                className={`${baseClass} ${colorClass}`}
              >
                {action.label}
              </button>
            );
          })}
        </div>
      )}
    </motion.div>
  );
}

export default EmptyState;
