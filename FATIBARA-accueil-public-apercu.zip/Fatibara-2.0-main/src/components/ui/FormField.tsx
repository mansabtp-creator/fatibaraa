/**
 * src/components/ui/FormField.tsx
 *
 * Reusable form field wrapper — label + control slot + error/success message.
 *
 * Usage:
 *   <FormField label="Région" error={errors.region} icon={<MapPin className="w-4 h-4" />}>
 *     <select className="form-select">...</select>
 *   </FormField>
 *
 *   <FormField label="Téléphone" success="Numéro valide">
 *     <input type="tel" className="form-input" />
 *   </FormField>
 */

import React from 'react';
import { AlertCircle, CheckCircle2 } from 'lucide-react';

export interface FormFieldProps {
  /** Label text — rendered with .form-label */
  label?: string;
  /** Error message — renders a rose error row with AlertCircle icon */
  error?: string;
  /** Success message — renders an emerald success row with CheckCircle2 icon */
  success?: string;
  /** Hint / helper text below the control */
  hint?: string;
  /**
   * Optional leading icon rendered inside the input wrapper.
   * When provided, the wrapper gets `form-input-icon-wrapper` and the
   * icon receives `form-icon`. The child input/select automatically gets
   * `pl-11` via the CSS descendant selector in index.css.
   */
  icon?: React.ReactNode;
  /** Required flag — appends a rose asterisk to the label */
  required?: boolean;
  /** Additional CSS classes for the outermost wrapper */
  className?: string;
  children: React.ReactNode;
}

export default function FormField({
  label,
  error,
  success,
  hint,
  icon,
  required,
  className = '',
  children,
}: FormFieldProps) {
  return (
    <div className={`form-field ${className}`}>
      {label && (
        <label className="form-label">
          {label}
          {required && <span className="text-rose-500 ml-1">*</span>}
        </label>
      )}

      {icon ? (
        <div className="form-input-icon-wrapper">
          <span className="form-icon" aria-hidden="true">
            {icon}
          </span>
          {children}
        </div>
      ) : (
        children
      )}

      {error && (
        <div className="form-error" role="alert">
          <AlertCircle className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
          <span>{error}</span>
        </div>
      )}

      {!error && success && (
        <div className="form-success">
          <CheckCircle2 className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
          <span>{success}</span>
        </div>
      )}

      {!error && !success && hint && (
        <p className="form-hint">{hint}</p>
      )}
    </div>
  );
}
