/**
 * src/components/ui/AppSelect.tsx
 *
 * Fully custom, dark-mode-safe dropdown replacement for native <select>.
 *
 * Unlike native <select> elements, this component renders its own popup
 * using a <div>/<ul>, so the dropdown panel background is ALWAYS controlled
 * by CSS — no OS white-flash in dark mode on any browser.
 *
 * Features:
 *   - Full keyboard navigation (ArrowUp/Down, Enter, Escape, Tab)
 *   - ARIA: role="listbox", aria-selected, aria-expanded, aria-activedescendant
 *   - Optional leading icon per option
 *   - Optional leading icon on the trigger button (via `icon` prop)
 *   - Animated dropdown via motion/react
 *   - Error state styling via `isError` prop
 *   - Disabled state
 *
 * Usage:
 *   <AppSelect
 *     value={region}
 *     onChange={setRegion}
 *     options={ALL_REGIONS.map(r => ({ value: r, label: r }))}
 *     placeholder="Sélectionner une région"
 *     icon={<MapPin className="w-4 h-4" />}
 *   />
 */

import React, { useState, useRef, useEffect, useId, useCallback } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ChevronDown, Check } from 'lucide-react';

export interface AppSelectOption {
  value: string;
  label: string;
  /** Optional icon rendered to the left of the label in the dropdown */
  icon?: React.ReactNode;
  disabled?: boolean;
}

export interface AppSelectProps {
  value: string;
  onChange: (value: string) => void;
  options: AppSelectOption[];
  placeholder?: string;
  /** Leading icon on the trigger button */
  icon?: React.ReactNode;
  disabled?: boolean;
  isError?: boolean;
  isValid?: boolean;
  id?: string;
  className?: string;
  /** Max height of the dropdown list in pixels (default: 240) */
  maxHeight?: number;
}

export default function AppSelect({
  value,
  onChange,
  options,
  placeholder = 'Sélectionner...',
  icon,
  disabled = false,
  isError = false,
  isValid = false,
  id,
  className = '',
  maxHeight = 240,
}: AppSelectProps) {
  const [open, setOpen] = useState(false);
  const [focusedIdx, setFocusedIdx] = useState<number>(-1);
  const triggerRef = useRef<HTMLButtonElement>(null);
  const listRef = useRef<HTMLUListElement>(null);
  const uid = useId();
  const listId = `appselect-list-${uid}`;
  const triggerId = id ?? `appselect-trigger-${uid}`;

  const selectedOption = options.find(o => o.value === value);
  const selectedIdx = options.findIndex(o => o.value === value);

  // Close on outside click
  useEffect(() => {
    if (!open) return;
    const handler = (e: MouseEvent) => {
      if (
        triggerRef.current &&
        !triggerRef.current.closest('[data-appselect]')?.contains(e.target as Node)
      ) {
        setOpen(false);
      }
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, [open]);

  // Scroll focused option into view
  useEffect(() => {
    if (!open || focusedIdx < 0) return;
    const li = listRef.current?.children[focusedIdx] as HTMLElement | undefined;
    li?.scrollIntoView({ block: 'nearest' });
  }, [focusedIdx, open]);

  // When opened, focus the currently selected item
  useEffect(() => {
    if (open) {
      setFocusedIdx(selectedIdx >= 0 ? selectedIdx : 0);
    }
  }, [open, selectedIdx]);

  const handleKeyDown = useCallback(
    (e: React.KeyboardEvent) => {
      if (disabled) return;
      const enabledOptions = options.filter(o => !o.disabled);

      switch (e.key) {
        case 'Enter':
        case ' ':
          e.preventDefault();
          if (!open) {
            setOpen(true);
          } else if (focusedIdx >= 0 && !options[focusedIdx]?.disabled) {
            onChange(options[focusedIdx].value);
            setOpen(false);
            triggerRef.current?.focus();
          }
          break;

        case 'ArrowDown':
          e.preventDefault();
          if (!open) {
            setOpen(true);
          } else {
            setFocusedIdx(prev => {
              let next = prev + 1;
              while (next < options.length && options[next].disabled) next++;
              return next < options.length ? next : prev;
            });
          }
          break;

        case 'ArrowUp':
          e.preventDefault();
          if (!open) {
            setOpen(true);
          } else {
            setFocusedIdx(prev => {
              let next = prev - 1;
              while (next >= 0 && options[next].disabled) next--;
              return next >= 0 ? next : prev;
            });
          }
          break;

        case 'Escape':
          e.preventDefault();
          setOpen(false);
          triggerRef.current?.focus();
          break;

        case 'Tab':
          setOpen(false);
          break;

        default:
          // Jump to first option starting with typed letter
          if (e.key.length === 1) {
            const char = e.key.toLowerCase();
            const idx = options.findIndex(
              (o, i) => i > focusedIdx && o.label.toLowerCase().startsWith(char) && !o.disabled
            );
            if (idx >= 0) setFocusedIdx(idx);
          }
      }
    },
    [disabled, open, focusedIdx, options, onChange]
  );

  const borderClass = isError
    ? 'border-rose-500 focus:border-rose-500'
    : isValid
    ? 'border-emerald-500'
    : 'border-gray-200 dark:border-white/10 focus:border-brand-primary';

  return (
    <div className={`relative ${className}`} data-appselect>
      {/* Trigger */}
      <button
        ref={triggerRef}
        id={triggerId}
        type="button"
        role="combobox"
        aria-haspopup="listbox"
        aria-expanded={open}
        aria-controls={listId}
        aria-activedescendant={focusedIdx >= 0 ? `${listId}-opt-${focusedIdx}` : undefined}
        disabled={disabled}
        onClick={() => !disabled && setOpen(o => !o)}
        onKeyDown={handleKeyDown}
        className={`
          w-full flex items-center gap-3 p-4 pr-10 text-left
          bg-white dark:bg-[#1a1a1a]
          border ${borderClass}
          rounded-xl text-[14px] font-medium
          text-gray-900 dark:text-white
          transition-all duration-200
          focus:outline-none focus:ring-1 focus:ring-brand-primary
          disabled:opacity-50 disabled:cursor-not-allowed
          select-none
        `}
      >
        {/* Leading icon */}
        {icon && (
          <span className="shrink-0 text-brand-primary dark:text-orange-400" aria-hidden="true">
            {icon}
          </span>
        )}

        {/* Selected label */}
        <span className={`flex-1 truncate ${!selectedOption ? 'text-gray-400 dark:text-white/25' : ''}`}>
          {selectedOption ? selectedOption.label : placeholder}
        </span>

        {/* Chevron */}
        <ChevronDown
          className={`absolute right-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400 dark:text-white/30 transition-transform duration-200 pointer-events-none ${open ? 'rotate-180' : ''}`}
          aria-hidden="true"
        />
      </button>

      {/* Dropdown */}
      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, y: -6, scale: 0.97 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -6, scale: 0.97 }}
            transition={{ duration: 0.15, ease: 'easeOut' }}
            className="absolute z-[200] mt-1.5 w-full"
          >
            <ul
              ref={listRef}
              id={listId}
              role="listbox"
              aria-label="Options"
              tabIndex={-1}
              className="
                overflow-y-auto py-1
                bg-white dark:bg-[#1a1a1a]
                border border-gray-200 dark:border-white/10
                rounded-xl shadow-2xl shadow-black/20
              "
              style={{ maxHeight }}
            >
              {options.map((opt, idx) => {
                const isSelected = opt.value === value;
                const isFocused = idx === focusedIdx;

                return (
                  <li
                    key={opt.value}
                    id={`${listId}-opt-${idx}`}
                    role="option"
                    aria-selected={isSelected}
                    aria-disabled={opt.disabled}
                    onMouseEnter={() => !opt.disabled && setFocusedIdx(idx)}
                    onMouseDown={e => {
                      e.preventDefault(); // prevent trigger blur
                      if (!opt.disabled) {
                        onChange(opt.value);
                        setOpen(false);
                        triggerRef.current?.focus();
                      }
                    }}
                    className={`
                      flex items-center gap-3 px-4 py-3
                      text-[13px] font-medium cursor-pointer
                      transition-colors duration-100
                      ${opt.disabled ? 'opacity-40 cursor-not-allowed' : ''}
                      ${isFocused && !opt.disabled
                        ? 'bg-brand-primary/8 dark:bg-brand-primary/12 text-brand-primary dark:text-orange-400'
                        : isSelected
                        ? 'text-brand-primary dark:text-orange-400'
                        : 'text-gray-700 dark:text-white/80 hover:bg-gray-50 dark:hover:bg-white/5'
                      }
                    `}
                  >
                    {/* Option icon */}
                    {opt.icon && (
                      <span className="shrink-0 w-4 h-4" aria-hidden="true">
                        {opt.icon}
                      </span>
                    )}

                    <span className="flex-1 truncate">{opt.label}</span>

                    {/* Check for selected */}
                    {isSelected && (
                      <Check className="w-3.5 h-3.5 shrink-0 text-brand-primary dark:text-orange-400" aria-hidden="true" />
                    )}
                  </li>
                );
              })}
            </ul>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
