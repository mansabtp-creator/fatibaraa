import { motion } from 'motion/react';
import React from 'react';

// ─── Base Skeleton Primitive ──────────────────────────────────────────────────
// The shimmer uses a responsive gradient so it's visible in both light and dark
// mode. `via-white/30` is perceptible on light surfaces; `dark:via-white/8`
// gives a subtle glimmer on near-black backgrounds without washing them out.

export function Skeleton({ className, ...props }: React.HTMLAttributes<HTMLDivElement>) {
  return (
    <div
      className={`relative overflow-hidden bg-gray-100 dark:bg-gray-800/60 rounded-2xl ${className ?? ''}`}
      {...props}
    >
      <motion.div
        aria-hidden="true"
        animate={{ x: ['-100%', '100%'] }}
        transition={{ duration: 1.6, repeat: Infinity, ease: 'linear' }}
        className="absolute inset-0 bg-gradient-to-r from-transparent via-white/30 dark:via-white/[0.06] to-transparent"
      />
    </div>
  );
}

// ─── Product Card Skeleton ────────────────────────────────────────────────────
// Matches the exact visual footprint of <ProductCard> so the layout doesn't
// jump when real data arrives.

export function ProductCardSkeleton() {
  return (
    <div className="flex flex-col bg-white dark:bg-gray-900 rounded-2xl overflow-hidden border border-gray-100 dark:border-gray-800">
      {/* Image area — aspect-[4/5] matches ProductCard */}
      <Skeleton className="w-full aspect-[4/5] rounded-none rounded-t-2xl" />
      <div className="p-3 flex flex-col gap-2 relative">
        {/* Store avatar floating badge */}
        <Skeleton className="absolute -top-5 right-3 w-9 h-9 rounded-full border-2 border-white dark:border-gray-900" />
        {/* Store name */}
        <Skeleton className="w-20 h-3 rounded-full mt-3" />
        {/* Product title */}
        <Skeleton className="w-full h-4 rounded-full" />
        <Skeleton className="w-3/4 h-4 rounded-full" />
        {/* Price + add-to-cart row */}
        <div className="flex items-center justify-between mt-2 pt-2 border-t border-gray-50 dark:border-gray-800">
          <Skeleton className="w-20 h-5 rounded-full" />
          <Skeleton className="w-8 h-8 rounded-xl" />
        </div>
      </div>
    </div>
  );
}

// ─── Metric Card Skeleton ─────────────────────────────────────────────────────
// Used in Vendor / Courier / Admin dashboards where a KPI card is loading.

export function MetricCardSkeleton() {
  return (
    <div className="flex flex-col gap-3 bg-white dark:bg-gray-900 border border-gray-100 dark:border-gray-800 rounded-2xl p-5">
      <div className="flex items-center justify-between">
        <Skeleton className="w-10 h-10 rounded-xl" />
        <Skeleton className="w-12 h-4 rounded-full" />
      </div>
      <Skeleton className="w-24 h-7 rounded-xl" />
      <Skeleton className="w-32 h-3 rounded-full" />
    </div>
  );
}

// ─── Order Row Skeleton ───────────────────────────────────────────────────────
// Matches the layout of a single order list-item row.

export function OrderRowSkeleton() {
  return (
    <div className="flex items-center gap-4 p-4 bg-white dark:bg-gray-900 border border-gray-100 dark:border-gray-800 rounded-2xl">
      <Skeleton className="w-14 h-14 rounded-xl shrink-0" />
      <div className="flex-1 space-y-2">
        <Skeleton className="w-3/4 h-4 rounded-full" />
        <Skeleton className="w-1/2 h-3 rounded-full" />
      </div>
      <Skeleton className="w-20 h-7 rounded-full shrink-0" />
    </div>
  );
}

// ─── Dashboard Skeleton ───────────────────────────────────────────────────────
// Full-page placeholder for Vendor/Courier dashboard initial load.
// Renders 4 metric cards + 3 order rows.

export function DashboardSkeleton() {
  return (
    <div className="space-y-6 p-4 md:p-6">
      {/* Metric cards grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {[...Array(4)].map((_, i) => <MetricCardSkeleton key={i} />)}
      </div>
      {/* Section header */}
      <div className="flex items-center justify-between">
        <Skeleton className="w-36 h-5 rounded-full" />
        <Skeleton className="w-20 h-5 rounded-full" />
      </div>
      {/* Order rows */}
      <div className="space-y-3">
        {[...Array(3)].map((_, i) => <OrderRowSkeleton key={i} />)}
      </div>
    </div>
  );
}

// ─── Product Grid Skeleton ────────────────────────────────────────────────────
// Full-grid placeholder — 8 cards matching the ProductGrid layout.

export function ProductGridSkeleton({ count = 8 }: { count?: number }) {
  return (
    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-3 md:gap-4">
      {[...Array(count)].map((_, i) => <ProductCardSkeleton key={i} />)}
    </div>
  );
}
