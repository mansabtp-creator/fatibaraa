import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Star, X, CheckCircle, Loader2, MessageSquare, Plus } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { useAppContext } from '../context/AppContext';
import { useToast } from '../context/ToastContext';
import { APP_NAME } from '../lib/constants';

interface ReviewModalProps {
  isOpen: boolean;
  onClose: () => void;
  productId: string;
  orderId: string;
  onSuccess: () => void;
}

export default function ReviewModal({ isOpen, onClose, productId, orderId, onSuccess }: ReviewModalProps) {
  const { user } = useAppContext();
  const { showToast } = useToast();
  const [rating, setRating] = useState(0);
  const [hoverRating, setHoverRating] = useState(0);
  const [comment, setComment] = useState('');
  const [photos, setPhotos] = useState<string[]>([]);
  const [submitting, setSubmitting] = useState(false);

  const handlePhotoUpload = () => {
    // Simulation of photo upload for the demo
    const mockPhotos = [
      'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=500&auto=format&fit=crop&q=60',
      'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=500&auto=format&fit=crop&q=60'
    ];
    setPhotos(prev => [...prev, mockPhotos[prev.length % mockPhotos.length]]);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;
    if (rating === 0) {
      showToast("Veuillez sélectionner une note", "warning");
      return;
    }

    setSubmitting(true);
    try {
      // Fetch profile and product info in parallel
      const [profileRes, productRes] = await Promise.all([
        supabase.from('profiles').select('full_name, avatar_url, saved_address').eq('id', user.id).single(),
        supabase.from('products').select('store_id').eq('id', productId).single(),
      ]);

      const profile = profileRes.data;
      const product = productRes.data;

      // CU-BUG-2 FIX: Use the submit_review RPC instead of a raw insert.
      // The RPC atomically:
      //  1. Validates the order belongs to this user AND is 'delivered'
      //  2. Inserts the review (unique constraint on order_id+user_id prevents duplicates)
      //  3. Awards +50 loyalty points only on the first review
      // If the user already reviewed this order, Postgres raises SQLSTATE 23505
      // which we catch below and show a friendly message.
      const { error } = await supabase.rpc('submit_review', {
        p_product_id: productId,
        p_store_id:   product?.store_id ?? null,
        p_user_id:    user.id,
        p_order_id:   orderId,
        p_user_name:  profile?.full_name || (user.user_metadata?.full_name as string | undefined) || `Client ${APP_NAME}`,
        p_rating:     rating as unknown as number,
        p_comment:    comment,
        p_location:   profile?.saved_address?.commune || 'Guinée',
        p_avatar_url: profile?.avatar_url ?? null,
      });

      if (error) {
        // 23505 = unique_violation: user already reviewed this order
        if (error.code === '23505') {
          showToast("Vous avez déjà évalué cette commande.", "info");
          onClose();
          return;
        }
        throw error;
      }

      showToast("Merci ! Votre avis a été publié. +50 pts de fidélité !", 'success');
      onSuccess();
      onClose();
    } catch (err: any) {
      showToast("Une erreur est survenue lors de la publication.", 'error');
      console.error(err);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="absolute inset-0 bg-gray-900/20 backdrop-blur-md"
          />
          
          <motion.div
            initial={{ opacity: 0, scale: 0.9, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9, y: 20 }}
            className="bg-white dark:bg-gray-900 dark:bg-gray-950 w-full max-w-lg rounded-[3rem] shadow-2xl overflow-hidden relative z-10 border border-brand-border/30 dark:border-white/10"
          >
            <div className="p-8 md:p-12">
              <div className="flex justify-between items-center mb-10">
                <div className="w-14 h-14 bg-[#ff6600] rounded-2xl flex items-center justify-center text-brand-inverse shadow-lg shadow-[#ff6600]/20">
                  <Star className="w-7 h-7 fill-brand-inverse" />
                </div>
                <button 
                  onClick={onClose} 
                  className="p-4 hover:bg-gray-50 dark:bg-gray-800 dark:hover:bg-gray-800 rounded-full transition-all text-gray-900 text-gray-900 dark:text-white border border-brand-border/10 dark:border-white/10 shadow-sm min-h-[44px] min-w-[44px] flex items-center justify-center"
                >
                  <X className="w-6 h-6" />
                </button>
              </div>

              <h2 className="text-3xl font-bold text-gray-900 text-gray-900 dark:text-white tracking-tighter mb-2 uppercase">Social Pulse</h2>
              <p className="text-brand-text-dim dark:text-gray-400 font-bold uppercase text-[12px] tracking-wider mb-10 leading-relaxed">Votre avis aide les autres acheteurs de la communauté.</p>

              <form onSubmit={handleSubmit} className="space-y-10">
                <div className="space-y-5">
                  <div className="flex items-center justify-between">
                    <label className="text-[10px] font-bold tracking-wider text-brand-text-dim dark:text-gray-500 dark:text-gray-400 ml-1">Quelle est votre note ?</label>
                    {rating === 0 && <span className="text-[10px] font-bold tracking-wider text-[#ff6600]">Obligatoire</span>}
                  </div>
                  <div className="flex gap-4">
                    {[1, 2, 3, 4, 5].map((i) => (
                      <button
                        key={i}
                        type="button"
                        onMouseEnter={() => setHoverRating(i)}
                        onMouseLeave={() => setHoverRating(0)}
                        onClick={() => setRating(i)}
                        className="transition-transform active:scale-90 min-h-[48px] min-w-[48px] flex items-center justify-center"
                      >
                        <Star 
                          className={`w-12 h-12 transition-all duration-300 ${
                            i <= (hoverRating || rating) 
                              ? 'fill-[#ff6600] text-[#ff6600] scale-110' 
                              : 'text-brand-border/40 dark:text-gray-700 hover:text-[#ff6600]/50'
                          }`} 
                        />
                      </button>
                    ))}
                  </div>
                </div>

                <div className="space-y-3">
                  <label className="text-[10px] font-bold tracking-wider text-brand-text-dim dark:text-gray-500 dark:text-gray-400 ml-1">Votre expérience</label>
                  <textarea
                    required
                    value={comment}
                    onChange={(e) => setComment(e.target.value)}
                    placeholder="Qu'avez-vous pensé de la qualité, de la livraison ?"
                    className="w-full bg-gray-50 dark:bg-gray-800 dark:bg-gray-900 border border-brand-border/40 dark:border-white/10 rounded-[2rem] p-6 text-[15px] font-bold uppercase tracking-tight text-gray-900 text-gray-900 dark:text-white focus:outline-none focus:border-[#ff6600] transition-all min-h-[160px] resize-none shadow-inner"
                  />
                </div>

                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <label className="text-[10px] font-bold tracking-wider text-brand-text-dim dark:text-gray-500 dark:text-gray-400 ml-1">Ajouter des photos</label>
                    <span className="text-[9px] font-bold uppercase text-[#ff6600] dark:text-orange-400">{photos.length}/4</span>
                  </div>
                  <div className="flex gap-4">
                    {photos.map((p, i) => (
                      <div key={i} className="relative w-20 h-20 rounded-2xl border border-brand-border/20 dark:border-white/5 overflow-hidden shadow-sm group">
                        <img src={p} alt="" className="w-full h-full object-cover" />
                        <button 
                          type="button"
                          onClick={() => setPhotos(prev => prev.filter((_, idx) => idx !== i))}
                          className="absolute top-1 right-1 bg-gray-900 dark:bg-gray-800 text-brand-inverse rounded-full p-1 opacity-0 group-hover:opacity-100 transition-opacity"
                        >
                          <X className="w-3 h-3" />
                        </button>
                      </div>
                    ))}
                    {photos.length < 4 && (
                      <button 
                        type="button" 
                        onClick={handlePhotoUpload}
                        className="w-20 h-20 rounded-2xl border border-dashed border-brand-border/40 dark:border-white/10 flex items-center justify-center text-brand-text-dim dark:text-gray-500 dark:text-gray-400 hover:border-[#ff6600] hover:text-[#ff6600] transition-all group"
                      >
                         <Plus className="w-8 h-8 group-hover:scale-110 transition-transform" />
                      </button>
                    )}
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={submitting}
                  className="w-full bg-gray-900 dark:bg-[#ff6600] text-brand-inverse py-6 rounded-full text-[13px] font-bold tracking-wider shadow-2xl shadow-brand-foreground/20 active:scale-[0.98] disabled:opacity-50 flex items-center justify-center gap-3 transition-all hover:bg-black dark:hover:bg-[#ff6600]"
                >
                  {submitting ? <Loader2 className="w-6 h-6 animate-spin" /> : <MessageSquare className="w-6 h-6" />}
                  <span>{submitting ? 'COMMUNICATION...' : 'PUBLIER MON AVIS'}</span>
                </button>
              </form>
            </div>

            <div className="bg-gray-50 dark:bg-gray-800 dark:bg-gray-900 p-8 flex items-center gap-4 border-t border-brand-border/20 dark:border-white/5">
               <div className="w-12 h-12 bg-green-50 dark:bg-green-900/20 rounded-full flex items-center justify-center text-green-600 dark:text-green-400 border border-green-100 dark:border-green-900/30 shadow-sm">
                  <CheckCircle className="w-6 h-6" />
               </div>
               <p className="text-[11px] font-bold text-brand-text-dim dark:text-gray-400 tracking-wider">Achat vérifié 100% sécurisé</p>
            </div>
          </motion.div>

        </div>
      )}
    </AnimatePresence>
  );
}
