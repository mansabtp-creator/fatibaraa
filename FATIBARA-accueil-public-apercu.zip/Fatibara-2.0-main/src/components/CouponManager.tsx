import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { supabase } from '../lib/supabase';
import { useToast } from '../context/ToastContext';
import { Tag, Plus, Trash2, Calendar, Percent, AlertCircle, Loader2 } from 'lucide-react';

export function CouponManager({ storeId }: { storeId: string }) {
  const [coupons, setCoupons] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [deletingId, setDeletingId] = useState<string | null>(null);
  const { showToast } = useToast();

  const [code, setCode] = useState('');
  const [discountPercent, setDiscountPercent] = useState('');
  const [usageLimit, setUsageLimit] = useState('');
  const [minOrderValue, setMinOrderValue] = useState('');
  const [expiresAt, setExpiresAt] = useState('');

  useEffect(() => {
    fetchCoupons();
  }, [storeId]);

  const fetchCoupons = async () => {
    setLoading(true);
    const { data, error } = await supabase.from('coupons').select('*').eq('store_id', storeId).order('created_at', { ascending: false });
    if (!error && data) setCoupons(data);
    setLoading(false);
  };

  const handleAddCoupon = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!code || !discountPercent) return;

    setIsSubmitting(true);
    try {
      const { data, error } = await supabase.from('coupons').insert([{
        store_id: storeId,
        code: code.toUpperCase(),
        discount_percentage: parseFloat(discountPercent),
        usage_limit: usageLimit ? parseInt(usageLimit) : null,
        min_order_value: minOrderValue ? parseFloat(minOrderValue) : null,
        expires_at: expiresAt ? new Date(expiresAt).toISOString() : null,
      }]).select().single();

      if (error) throw error;

      setCoupons([data, ...coupons]);
      setCode('');
      setDiscountPercent('');
      setUsageLimit('');
      setMinOrderValue('');
      setExpiresAt('');
      showToast("Coupon créé avec succès", "success");
    } catch (err: any) {
      showToast(err.message || 'Erreur lors de la création du coupon.', "error");
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDelete = async (id: string) => {
    setDeletingId(id);
    try {
      const { error } = await supabase.from('coupons').delete().eq('id', id);
      if (error) throw error;
      setCoupons(coupons.filter(c => c.id !== id));
      showToast("Coupon supprimé", "success");
    } catch (err: any) {
      showToast(err.message || "Erreur lors de la suppression.", "error");
    } finally {
      setDeletingId(null);
    }
  };

  return (
    <div className="bg-white bg-white dark:bg-gray-900 border border-brand-border/30 dark:border-white/10 rounded-[2rem] p-6 space-y-6">
      <div className="flex items-center gap-3 mb-4">
        <div className="w-10 h-10 rounded-xl bg-orange-500/10 flex items-center justify-center text-orange-500">
          <Tag className="w-5 h-5" />
        </div>
        <div>
          <h2 className="text-xl font-bold text-gray-900 text-gray-900 dark:text-white">Coupons de Réduction</h2>
          <p className="text-[11px] font-bold text-brand-text-dim dark:text-gray-400">Générez des codes promo pour vos clients</p>
        </div>
      </div>

      {/* Quick template chips */}
      <div className="flex flex-wrap gap-2 mb-4">
        <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest w-full mb-1">Modèles rapides :</p>
        {[
          { label: '🎉 Bienvenue -10%', code: 'BIENVENUE10', discount: '10' },
          { label: '🔥 Weekend -15%', code: 'WEEKEND15', discount: '15' },
          { label: '❤️ Fidélité -20%', code: 'FIDELITE20', discount: '20' },
        ].map((tpl) => (
          <button
            key={tpl.code}
            type="button"
            onClick={() => { setCode(tpl.code); setDiscountPercent(tpl.discount); }}
            className="px-3 py-1.5 bg-white dark:bg-white/5 border border-gray-200 dark:border-white/10 text-gray-600 dark:text-gray-300 text-[10px] font-black rounded-xl hover:border-[#ff6600] hover:text-[#ff6600] transition-all"
          >
            {tpl.label}
          </button>
        ))}
      </div>

      <form onSubmit={handleAddCoupon} className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4 items-end bg-gray-50 dark:bg-gray-800 dark:bg-white/5 p-4 rounded-[1.5rem] border border-brand-border/30 dark:border-white/5">
        <div className="flex flex-col">
          <label className="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1">Code</label>
          <input type="text" placeholder="CODE (ex: PROMO20)" value={code} onChange={e => setCode(e.target.value.toUpperCase())} className="w-full bg-white dark:bg-gray-900 dark:bg-gray-800 rounded-xl p-3 text-[12px] font-bold uppercase tracking-wider border border-brand-border/50 dark:border-white/10 focus:border-black dark:focus:border-white outline-none text-gray-900 text-gray-900 dark:text-white" required />
        </div>
        <div className="flex flex-col">
          <label className="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1">Réduction</label>
          <div className="relative">
            <input type="number" placeholder="Réduction" value={discountPercent} onChange={e => setDiscountPercent(e.target.value)} className="w-full bg-white dark:bg-gray-900 dark:bg-gray-800 rounded-xl p-3 text-[12px] font-bold border border-brand-border/50 dark:border-white/10 focus:border-black dark:focus:border-white outline-none text-gray-900 text-gray-900 dark:text-white" required min="1" max="100" />
            <Percent className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-brand-text-dim dark:text-gray-400" />
          </div>
        </div>
        <div className="flex flex-col">
          <label className="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1">Limite</label>
          <input type="number" placeholder="Limite d'usage" value={usageLimit} onChange={e => setUsageLimit(e.target.value)} className="w-full bg-white dark:bg-gray-900 dark:bg-gray-800 rounded-xl p-3 text-[12px] font-bold border border-brand-border/50 dark:border-white/10 focus:border-black dark:focus:border-white outline-none text-gray-900 text-gray-900 dark:text-white" min="1" />
        </div>
        <div className="flex flex-col">
          <label className="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1">Expiration</label>
          <input type="date" value={expiresAt} onChange={e => setExpiresAt(e.target.value)} className="w-full bg-white dark:bg-gray-900 dark:bg-gray-800 rounded-xl p-3 text-[12px] font-bold border border-brand-border/50 dark:border-white/10 focus:border-black dark:focus:border-white outline-none text-gray-900 text-gray-900 dark:text-white" />
        </div>
        <button type="submit" disabled={isSubmitting} className="bg-black text-white rounded-xl font-bold text-[12px] tracking-wider hover:bg-gray-800 transition-all flex items-center justify-center gap-1 min-h-[44px]">
          {isSubmitting ? <><Loader2 className="w-4 h-4 animate-spin" /> Création...</> : <><Plus className="w-4 h-4" /> Créer</>}
        </button>
      </form>

      <div className="space-y-3">
        <AnimatePresence>
          {coupons.map((coupon) => (
            <motion.div
              key={coupon.id}
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 10 }}
              className="flex flex-col sm:flex-row sm:items-center justify-between p-4 bg-gray-50/30 dark:bg-white/5 rounded-xl border border-brand-border/50 dark:border-white/10 gap-4"
            >
              <div>
                <div className="flex items-center gap-2">
                  <span className="font-bold text-[14px] text-orange-600 bg-orange-500/10 px-2 py-0.5 rounded tracking-wider">{coupon.code}</span>
                  <span className="font-bold text-gray-900 text-gray-900 dark:text-white text-[14px]">-{coupon.discount_percentage}%</span>
                </div>
                <div className="text-[10px] font-bold text-brand-text-dim dark:text-gray-400 flex gap-3 mt-2 uppercase tracking-wide">
                  <span>Usages: {coupon.usage_count} / {coupon.usage_limit || '∞'}</span>
                  {coupon.expires_at && <span>Expire: {new Date(coupon.expires_at).toLocaleDateString()}</span>}
                </div>
              </div>
              <button onClick={() => handleDelete(coupon.id)} disabled={deletingId === coupon.id} aria-label="Supprimer ce coupon" className="p-2.5 rounded-xl bg-white dark:bg-gray-900 dark:bg-gray-800 border border-brand-border/50 dark:border-white/10 text-brand-text-dim dark:text-gray-400 hover:text-red-500 hover:border-red-500/50 transition-all">
                {deletingId === coupon.id ? <Loader2 className="w-4 h-4 animate-spin" /> : <Trash2 className="w-4 h-4" />}
              </button>
            </motion.div>
          ))}
        </AnimatePresence>
        {coupons.length === 0 && !loading && (
          <div className="flex flex-col items-center justify-center py-12 gap-4">
            <div className="w-16 h-16 bg-orange-500/10 rounded-2xl flex items-center justify-center">
              <Tag className="w-8 h-8 text-orange-400 opacity-60" />
            </div>
            <div className="text-center">
              <p className="text-sm font-black text-gray-900 dark:text-white mb-1">Aucun coupon actif</p>
              <p className="text-[11px] text-gray-400 font-medium">Créez votre premier code promo pour fidéliser vos clients</p>
            </div>
            <button
              type="button"
              onClick={() => { setCode('PROMO10'); setDiscountPercent('10'); }}
              className="flex items-center gap-2 px-4 py-2 bg-[#ff6600] text-white text-[11px] font-black rounded-xl hover:opacity-90 transition-all"
            >
              <Plus className="w-4 h-4" /> Créer mon premier coupon
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
