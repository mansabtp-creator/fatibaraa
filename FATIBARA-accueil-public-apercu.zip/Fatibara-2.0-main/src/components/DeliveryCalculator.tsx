import { useState, useEffect } from 'react';
import { MapPin, Truck, Info, CheckCircle2, Zap } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { useStore } from '../store/useStore';

import { COMMUNES, calculateDeliveryFee, adjustDeliveryTime } from '../utils/delivery';

export default function DeliveryCalculator() {
  const { selectedRegion } = useStore();
  const [selectedCommune, setSelectedCommune] = useState(COMMUNES[0]);
  const [isOpen, setIsOpen] = useState(false);
  const [isExpress, setIsExpress] = useState(false);
  const [weightClass, setWeightClass] = useState<'light' | 'medium' | 'heavy'>('light');

  useEffect(() => {
    const matching = selectedRegion ? COMMUNES.find(c => c.name.toLowerCase() === selectedRegion.toLowerCase()) : null;
    if (matching) setSelectedCommune(matching);
  }, [selectedRegion]);

  const { fee: calculatedPrice } = calculateDeliveryFee(
    { region: 'Conakry', commune: 'Kaloum' },
    { region: 'Conakry', commune: selectedCommune.name },
    { isExpress, weightClass }
  );

  const estimatedTime = adjustDeliveryTime(selectedCommune.time, isExpress);

  // Log calculation payload to verify request payload and parameters
  useEffect(() => {
    console.log('[DeliveryCalculator] Delivery request parameters and calculated fee:', {
      origin: { region: 'Conakry', commune: 'Kaloum' },
      destination: { region: 'Conakry', commune: selectedCommune.name },
      options: { isExpress, weightClass },
      calculatedPrice,
      estimatedTime,
      timestamp: new Date().toISOString()
    });
  }, [selectedCommune, isExpress, weightClass, calculatedPrice, estimatedTime]);

  return (
    <div className="bg-white dark:bg-gray-900 rounded-2xl border border-gray-100 dark:border-gray-800 p-6 md:p-8 shadow-sm">
      <div className="flex items-center justify-between mb-6 pb-6 border-b border-gray-100 dark:border-gray-800">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 bg-orange-50 dark:bg-orange-500/10 rounded-xl flex items-center justify-center text-[#ff6600]">
            <Truck className="w-6 h-6" />
          </div>
          <div>
            <h3 className="text-base font-bold text-gray-900 dark:text-white tracking-tight leading-none mb-1">Estimation Livraison</h3>
            <p className="text-[11px] text-gray-500 dark:text-gray-400 font-medium tracking-wider leading-none">Conakry & Zone Spéciale</p>
          </div>
        </div>
        <button 
          onClick={() => setIsOpen(!isOpen)}
          className="bg-gray-50 dark:bg-gray-800 text-gray-700 dark:text-gray-300 px-4 py-2 border border-gray-200 dark:border-gray-700 rounded-lg text-xs font-semibold hover:bg-gray-100 dark:hover:bg-gray-700 hover:border-gray-300 transition-all active:scale-[0.98]"
        >
          {isOpen ? 'Fermer' : 'Changer'}
        </button>
      </div>

      <div className="space-y-6">
        <div className="flex items-center justify-between p-5 bg-gray-50 dark:bg-gray-800 rounded-xl border border-gray-100 dark:border-gray-800">
          <div className="flex items-center gap-3">
            <MapPin className="w-5 h-5 text-[#ff6600]" />
            <span className="text-base font-semibold text-gray-900 dark:text-white tracking-tight">{selectedCommune.name}</span>
          </div>
          <div className="text-right">
            <div className="text-lg font-bold text-gray-900 dark:text-white tabular-nums leading-none mb-1">{calculatedPrice.toLocaleString()} <span className="text-xs text-gray-500 dark:text-gray-400 font-medium">GNF</span></div>
            <div className="text-[10px] text-gray-400 font-medium tracking-wider pl-2">TARIF DYNAMIQUE</div>
          </div>
        </div>

        <AnimatePresence>
          {isOpen && (
            <motion.div 
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: 'auto', opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              className="overflow-hidden"
            >
              <div className="grid grid-cols-2 gap-3 pb-6">
                {COMMUNES.map((commune) => (
                  <button
                    key={commune.name}
                    onClick={() => {
                      setSelectedCommune(commune);
                      setIsOpen(false);
                    }}
                    className={`p-3.5 rounded-xl border text-xs font-semibold transition-all ${
                      selectedCommune.name === commune.name
                        ? 'bg-[#ff6600] text-white border-[#ff6600] shadow-sm'
                        : 'bg-white dark:bg-gray-900 text-gray-600 dark:text-gray-300 border-gray-200 dark:border-gray-700 hover:border-orange-200 hover:bg-orange-50 dark:hover:bg-gray-800'
                    }`}
                  >
                    {commune.name}
                  </button>
                ))}
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Speed Option */}
        <div className="space-y-2.5">
          <label className="text-[10px] font-black tracking-widest text-gray-400 dark:text-gray-500 uppercase ml-1">Vitesse de livraison</label>
          <div className="grid grid-cols-2 gap-3">
            <button
              onClick={() => setIsExpress(false)}
              className={`p-3.5 rounded-xl border text-xs font-bold transition-all flex items-center justify-center gap-2 ${
                !isExpress
                  ? 'bg-gray-900 text-white dark:bg-white dark:text-black border-transparent shadow-sm'
                  : 'bg-white dark:bg-gray-900 text-gray-600 dark:text-gray-300 border-gray-200 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-800'
              }`}
            >
              <Truck className="w-4 h-4" />
              Standard
            </button>
            <button
              onClick={() => setIsExpress(true)}
              className={`p-3.5 rounded-xl border text-xs font-bold transition-all flex items-center justify-center gap-2 ${
                isExpress
                  ? 'bg-[#ff6600] text-white border-transparent shadow-sm'
                  : 'bg-white dark:bg-gray-900 text-gray-600 dark:text-gray-300 border-gray-200 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-800'
              }`}
            >
              <Zap className="w-4 h-4" />
              Express (+10k GNF)
            </button>
          </div>
        </div>

        {/* Weight Option */}
        <div className="space-y-2.5">
          <label className="text-[10px] font-black tracking-widest text-gray-400 dark:text-gray-500 uppercase ml-1">Poids / Volume du colis</label>
          <div className="grid grid-cols-3 gap-2.5">
            <button
              onClick={() => setWeightClass('light')}
              className={`p-2.5 rounded-xl border text-[11px] font-bold transition-all ${
                weightClass === 'light'
                  ? 'bg-[#ff6600] text-white border-transparent'
                  : 'bg-white dark:bg-gray-900 text-gray-600 dark:text-gray-300 border-gray-200 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-800'
              }`}
            >
              Léger (0 GNF)
            </button>
            <button
              onClick={() => setWeightClass('medium')}
              className={`p-2.5 rounded-xl border text-[11px] font-bold transition-all ${
                weightClass === 'medium'
                  ? 'bg-[#ff6600] text-white border-transparent'
                  : 'bg-white dark:bg-gray-900 text-gray-600 dark:text-gray-300 border-gray-200 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-800'
              }`}
            >
              Moyen (+5k)
            </button>
            <button
              onClick={() => setWeightClass('heavy')}
              className={`p-2.5 rounded-xl border text-[11px] font-bold transition-all ${
                weightClass === 'heavy'
                  ? 'bg-[#ff6600] text-white border-transparent'
                  : 'bg-white dark:bg-gray-900 text-gray-600 dark:text-gray-300 border-gray-200 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-800'
              }`}
            >
              Lourd (+15k)
            </button>
          </div>
        </div>

        <div className="flex items-start gap-3 bg-orange-50/50 dark:bg-orange-500/5 rounded-xl p-5 border border-orange-100/50 dark:border-orange-500/10">
          <Info className="w-5 h-5 text-[#ff6600] mt-0.5 flex-shrink-0" />
          <div className="flex-1">
            <p className="text-sm text-gray-700 dark:text-gray-300 leading-tight font-medium mb-1.5 font-bold">
              Arrivée prévue : <span className="text-[#ff6600]">{estimatedTime}</span>
            </p>
            <p className="text-[11px] text-gray-500 dark:text-gray-400 font-medium">Confirmation par téléphone requise</p>
          </div>
        </div>

        <div className="flex items-center gap-2.5 px-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-500" />
          <span className="text-sm font-medium text-gray-600 dark:text-gray-400">Paiement à la livraison accepté</span>
        </div>
      </div>
    </div>
  );
}
