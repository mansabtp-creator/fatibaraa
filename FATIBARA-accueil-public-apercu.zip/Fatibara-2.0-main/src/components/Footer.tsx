import { ShieldCheck, Truck, MessageCircle, Heart, ExternalLink } from 'lucide-react';
import { Link } from 'react-router-dom';
import { APP_NAME, APP_DESCRIPTION, LOCATION_DEFAULT, COUNTRY_FLAG } from '../lib/constants';

export default function Footer() {
  return (
    <footer className="bg-white dark:bg-gray-900 dark:bg-gray-950 mt-16 relative overflow-hidden">
      <div className="absolute top-0 left-0 w-full h-1.5 bg-gradient-to-r from-[#ff6600] via-[#e62e00] to-[#ff6600] opacity-90" />
      
      {/* Trust Banner Area */}
      <div className="bg-gray-50 dark:bg-gray-800 px-4 md:px-10 py-16 border-b border-gray-200 dark:border-gray-700">
        <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-3 gap-10">
           <div className="flex gap-5 items-center group bg-white dark:bg-gray-900 rounded-3xl p-6 shadow-sm border border-gray-100 dark:border-gray-800 min-h-[140px]">
              <div className="w-16 h-16 bg-orange-50 dark:bg-orange-900/20 rounded-2xl flex items-center justify-center shrink-0 border border-orange-100 dark:border-orange-900/50 group-hover:-translate-y-1 transition-transform">
                 <ShieldCheck className="w-8 h-8 text-[#ff6600]" />
              </div>
              <div className="flex flex-col justify-center">
                 <h4 className="font-black text-gray-900 dark:text-white tracking-tight text-[15px] mb-1.5 uppercase leading-none">Protection</h4>
                 <p className="text-[12px] text-gray-500 dark:text-gray-400 font-semibold tracking-wide leading-snug">Paiement 100% sécurisé et garanti.</p>
              </div>
           </div>
           <div className="flex gap-5 items-center group bg-white dark:bg-gray-900 rounded-3xl p-6 shadow-sm border border-gray-100 dark:border-gray-800 min-h-[140px]">
              <div className="w-16 h-16 bg-green-50 dark:bg-green-900/20 rounded-2xl flex items-center justify-center shrink-0 border border-green-100 dark:border-green-900/50 group-hover:-translate-y-1 transition-transform">
                 <Truck className="w-8 h-8 text-[#16a34a]" />
              </div>
              <div className="flex flex-col justify-center">
                 <h4 className="font-black text-gray-900 dark:text-white tracking-tight text-[15px] mb-1.5 uppercase leading-none">Logistique</h4>
                 <p className="text-[12px] text-gray-500 dark:text-gray-400 font-semibold tracking-wide leading-snug">Livraison rapide sur tout le territoire.</p>
              </div>
           </div>
           <div className="flex gap-5 items-center group bg-white dark:bg-gray-900 rounded-3xl p-6 shadow-sm border border-gray-100 dark:border-gray-800 min-h-[140px]">
              <div className="w-16 h-16 bg-red-50 dark:bg-red-900/20 rounded-2xl flex items-center justify-center shrink-0 border border-red-100 dark:border-red-900/50 group-hover:-translate-y-1 transition-transform">
                 <MessageCircle className="w-8 h-8 text-[#e62e00]" />
              </div>
              <div className="flex flex-col justify-center">
                 <h4 className="font-black text-gray-900 dark:text-white tracking-tight text-[15px] mb-1.5 uppercase leading-none">Support</h4>
                 <p className="text-[12px] text-gray-500 dark:text-gray-400 font-semibold tracking-wide leading-snug">Conseillers disponibles par WhatsApp.</p>
              </div>
           </div>
        </div>
      </div>

      <div className="px-4 md:px-10 py-20 bg-white dark:bg-gray-900 dark:bg-gray-950">
        <div className="max-w-7xl mx-auto">
           <div className="grid grid-cols-1 md:grid-cols-4 gap-16 mb-20">
              <div className="col-span-1 md:col-span-1">
                 <div className="text-3xl font-black tracking-tighter text-gray-900 dark:text-white flex items-center gap-3 mb-6">
                    <div className="w-10 h-10 bg-gradient-to-br from-[#ff6600] to-[#e62e00] rounded-xl flex items-center justify-center text-white font-black text-2xl shadow-lg shadow-orange-500/20">
                      {APP_NAME.charAt(0)}
                    </div>
                    {APP_NAME}
                 </div>
                 <p className="text-[14px] text-gray-500 dark:text-gray-400 font-semibold leading-relaxed mb-8">
                    {APP_DESCRIPTION}
                 </p>
                 <div className="flex items-center gap-3">
                    {['fb', 'ig', 'tw', 'wa'].map(s => (
                       <div key={s} className="w-10 h-10 bg-gray-50 dark:bg-gray-800 rounded-full flex items-center justify-center text-gray-500 dark:text-gray-400 hover:bg-[#ff6600] border border-transparent dark:border-gray-700 dark:hover:bg-[#ff6600] dark:hover:text-white hover:text-white transition-all cursor-pointer shadow-sm active:scale-90">
                          <span className="text-[11px] font-black uppercase tracking-wider">{s}</span>
                       </div>
                    ))}
                 </div>
              </div>

              <div>
                 <h5 className="font-black tracking-widest text-gray-900 dark:text-white uppercase text-[13px] mb-8">Navigation</h5>
                 <div className="flex flex-col gap-4">
                    <Link to="/shop" className="text-[14px] font-semibold text-gray-600 dark:text-gray-400 hover:text-[#ff6600] dark:hover:text-[#ff6600] transition-colors flex items-center gap-2 group">
                       <span className="w-0 group-hover:w-4 h-[2px] bg-[#ff6600] transition-all rounded-full" />
                       DEALS EXCLUSIFS
                    </Link>
                    <Link to="/search?sort=newest" className="text-[14px] font-semibold text-gray-600 dark:text-gray-400 hover:text-[#ff6600] dark:hover:text-[#ff6600] transition-colors flex items-center gap-2 group">
                       <span className="w-0 group-hover:w-4 h-[2px] bg-[#ff6600] transition-all rounded-full" />
                       NOUVEAUTÉS
                    </Link>
                    <Link to="/search" className="text-[14px] font-semibold text-gray-600 dark:text-gray-400 hover:text-[#ff6600] dark:hover:text-[#ff6600] transition-colors flex items-center gap-2 group">
                       <span className="w-0 group-hover:w-4 h-[2px] bg-[#ff6600] transition-all rounded-full" />
                       TOP BOUTIQUES
                    </Link>
                 </div>
              </div>

              <div>
                 <h5 className="font-black tracking-widest text-gray-900 dark:text-white uppercase text-[13px] mb-8">Opportunités</h5>
                 <div className="flex flex-col gap-4">
                    <Link to="/vendor-registration" className="text-[14px] font-semibold text-gray-600 dark:text-gray-400 hover:text-[#ff6600] dark:hover:text-[#ff6600] transition-colors flex items-center gap-2">
                       Devenir Vendeur <ExternalLink className="w-3.5 h-3.5 opacity-50" />
                    </Link>
                    <Link to="/dashboard" className="text-[14px] font-semibold text-gray-600 dark:text-gray-400 hover:text-[#ff6600] dark:hover:text-[#ff6600] transition-colors">L'Espace Grossiste</Link>
                    <Link to="/courier-onboarding" className="text-[14px] font-semibold text-gray-600 dark:text-gray-400 hover:text-[#ff6600] dark:hover:text-[#ff6600] transition-colors">Devenir Livreur</Link>
                 </div>
              </div>

              <div>
                 <h5 className="font-black tracking-widest text-gray-900 dark:text-white uppercase text-[13px] mb-8">Assistance</h5>
                 <div className="flex flex-col gap-4">
                    <Link to="/help" className="text-[14px] font-semibold text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:text-white transition-colors">FAQs et Aide</Link>
                    <Link to="/terms" className="text-[14px] font-semibold text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:text-white transition-colors">Conditions Générales</Link>
                    <Link to="/privacy" className="text-[14px] font-semibold text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:text-white transition-colors">Politique de Confidentialité</Link>
                    <Link to="/about" className="text-[14px] font-semibold text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:text-white transition-colors">À Propos</Link>
                 </div>
              </div>
           </div>

           <div className="pt-10 border-t border-gray-100 dark:border-gray-800 flex flex-col md:flex-row justify-between items-center gap-8">
              <div className="flex items-center gap-2 text-[12px] font-bold text-gray-500 dark:text-gray-400 tracking-wider">
                 CONÇU À <span className="text-gray-900 dark:text-white font-black px-2.5 py-1 bg-gray-50 dark:bg-gray-800 rounded-md border border-gray-200 dark:border-gray-700">{LOCATION_DEFAULT}</span> {COUNTRY_FLAG}
              </div>
              <div className="flex items-center gap-2 text-[12px] font-bold text-gray-500 dark:text-gray-400 tracking-wider">
                 © 2026. <span className="flex items-center gap-1.5 font-black text-gray-900 dark:text-white">{APP_NAME} <Heart className="w-4 h-4 text-[#ff6600] fill-[#ff6600] animate-pulse" /></span>
              </div>
           </div>
        </div>
      </div>
    </footer>
  );
}
