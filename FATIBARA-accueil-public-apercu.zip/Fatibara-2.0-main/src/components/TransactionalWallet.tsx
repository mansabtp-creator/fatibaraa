import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Zap, ArrowDownRight, ArrowUpRight,
  CheckCircle, ShieldCheck,
  AlertCircle, Eye, EyeOff, Loader2, ReceiptText,
  Send, History, TrendingUp, Wallet, X, Smartphone,
  Info, RefreshCw, Sparkles, Clock, ArrowRight, Coins, Check,
  ExternalLink,
} from 'lucide-react';

import { supabase, validateSessionOrClear } from '../lib/supabase';
import { withdrawalService } from '../services/withdrawalService';
import { useToast } from '../context/ToastContext';
import { useAppContext } from '../context/AppContext';
import { formatGNF } from '../utils/formatters';
import { formatGuineanPhone, isValidGuineanPhone, detectCarrier } from '../utils/lengopay';

// ─── Types ────────────────────────────────────────────────────────────────────
interface TransactionalWalletProps {
  type: 'vendor' | 'courier' | 'user';
  id: string;
  /** H-1: Pass is_verified_store so unverified vendors see a clear gate instead of a silent RPC error */
  isVerified?: boolean;
}

// ─── Helpers ──────────────────────────────────────────────────────────────────
function walletLabel(type: TransactionalWalletProps['type']) {
  if (type === 'vendor') return 'Portefeuille Boutique';
  if (type === 'courier') return 'Portefeuille Livreur';
  return 'Mon Portefeuille';
}

function relativeDate(isoString: string): string {
  const d = new Date(isoString);
  const now = new Date();
  const todayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  const yesterdayStart = new Date(todayStart.getTime() - 86_400_000);
  const time = d.toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' });
  if (d >= todayStart) return `Aujourd'hui · ${time}`;
  if (d >= yesterdayStart) return `Hier · ${time}`;
  return d.toLocaleDateString('fr-FR', { day: 'numeric', month: 'short' }) + ` · ${time}`;
}

function txTypeLabel(tx: any): string {
  if (tx.type === 'deposit') return 'Recharge Mobile Money';
  if (tx.type === 'withdrawal') return 'Demande de retrait';
  if (tx.type === 'purchase') return 'Achat';
  if (tx.type === 'sale') return 'Vente';
  if (tx.type === 'refund') return 'Remboursement';
  if (tx.type === 'delivery_fee') return 'Frais de livraison';
  if (tx.type === 'credit') return 'Crédit';
  if (tx.type === 'withdrawal_approved') return 'Retrait approuvé';
  if (tx.type === 'boost') return tx.description || 'Campagne PROPULSE';
  return (tx.description || tx.type?.replace(/_/g, ' ') || '–');
}

function methodBadge(method?: string): string {
  if (!method) return '';
  if (/orange/i.test(method)) return '🟠 Orange Money';
  if (/mtn/i.test(method)) return '🟡 MTN MoMo';
  return method;
}

// ─── Skeleton ─────────────────────────────────────────────────────────────────
function Sk({ className = '' }: { className?: string }) {
  return <div className={`animate-pulse rounded-xl bg-white/[0.06] ${className}`} />;
}

// ─── Preset amounts ───────────────────────────────────────────────────────────
const PRESET_AMOUNTS = [20_000, 50_000, 100_000, 200_000, 500_000];

// ─── Withdrawal minimums (must match RPC enforcement) ─────────────────────────
const WITHDRAWAL_MIN: Record<TransactionalWalletProps['type'], number> = {
  vendor:  50_000,
  courier: 20_000,
  user:    20_000,
};

// ─── Input validation helpers ─────────────────────────────────────────────────
const isValidUUID = (uuid?: string | null): boolean => {
  if (!uuid) return false;
  return /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(uuid.trim());
};

const normalizeWithdrawMethod = (m: string): 'orange_money' | 'mtn_money' | 'wave' | 'bank' => {
  const clean = (m || '').toLowerCase().trim();
  if (clean.includes('orange')) return 'orange_money';
  if (clean.includes('mtn') || clean.includes('momo')) return 'mtn_money';
  if (clean.includes('wave')) return 'wave';
  if (clean.includes('bank') || clean.includes('banque') || clean.includes('virement')) return 'bank';
  return 'orange_money';
};

const sanitizeGuineanPhone = (p: string): string => {
  const digits = (p || '').replace(/\D/g, '');
  if (digits.startsWith('224') && digits.length === 12) {
    return digits.slice(3);
  }
  return digits;
};

// ─── Main component ───────────────────────────────────────────────────────────
export default function TransactionalWallet({ type, id, isVerified = true }: TransactionalWalletProps) {
  const { showToast } = useToast();
  const { activeRole } = useAppContext();

  const canWithdraw = type === 'vendor' || type === 'courier' || activeRole === 'vendor' || activeRole === 'courier';

  // ── Data state ────────────────────────────────────────────────────────────
  const [loading, setLoading]           = useState(true);
  const [balance, setBalance]           = useState(0);
  const [showBalance, setShowBalance]   = useState(false);
  const [transactions, setTransactions] = useState<any[]>([]);
  const [withdrawals, setWithdrawals]   = useState<any[]>([]);
  const [pendingAmount, setPendingAmount] = useState(0);
  const [lockedAmount, setLockedAmount]   = useState(0);
  const [storeVerified, setStoreVerified] = useState<boolean>(isVerified);
  const [isStoreOwner, setIsStoreOwner]   = useState<boolean>(true);

  useEffect(() => {
    setStoreVerified(isVerified);
  }, [isVerified]);

  const effectiveVerified = type === 'vendor' ? (storeVerified && isVerified) : true;

  // ── Top-up modal state ────────────────────────────────────────────────────
  const [showTopUpSheet, setShowTopUpSheet] = useState(false);
  // runningTotal: additive — chips increment this; Effacer resets to 0
  const [runningTotal, setRunningTotal]     = useState(0);
  // phone: loaded from profile on mount; phoneInput: user-editable in modal
  const [phone, setPhone]                   = useState('');
  const [phoneInput, setPhoneInput]         = useState('');
  const [isRecharging, setIsRecharging]     = useState(false);
  const [pendingPaymentUrl, setPendingPaymentUrl] = useState<string | null>(null);

  // ── Withdraw sheet state ──────────────────────────────────────────────────
  const [showWithdrawSheet, setShowWithdrawSheet] = useState(false);
  const [withdrawAmount, setWithdrawAmount]       = useState('');
  const [withdrawPhone, setWithdrawPhone]         = useState('');
  const [withdrawMethod, setWithdrawMethod]       = useState<'Orange Money' | 'MTN MoMo'>('Orange Money');
  const [isRequesting, setIsRequesting]           = useState(false);

  // C-3: Guard against double-tap on top-up submit
  const isSubmittingTopUpRef = useRef(false);
  // C-3: Guard against double-tap on withdraw submit
  const isSubmittingWithdrawRef = useRef(false);

  // ── Mobile panel ──────────────────────────────────────────────────────────
  const [activePanel, setActivePanel] = useState<'history' | 'withdrawals'>('history');

  // ── Self-serve payment verification ─────────────────────────────────────
  // Tracks which tx is currently being verified (shows spinner on that row).
  const [verifyingTxId, setVerifyingTxId] = useState<string | null>(null);

  // ── Auto-poll state ────────────────────────────────────────────────────
  // countdown shown on pending rows; ref holds latest pending txs for the interval.
  const [pollCountdown, setPollCountdown]   = useState(30);
  const pendingDepositsRef                  = useRef<any[]>([]);

  // Close body scroll lock when any sheet is open
  useEffect(() => {
    const anyOpen = showTopUpSheet || showWithdrawSheet;
    document.body.setAttribute('data-modal-open', String(anyOpen));
    return () => document.body.removeAttribute('data-modal-open');
  }, [showTopUpSheet, showWithdrawSheet]);

  // ── Realtime: wallet_transactions UPDATE ──────────────────────────────────
  useEffect(() => {
    if (!id) return;
    const channel = supabase
      .channel(`wallet-realtime-${id}`)
      .on('postgres_changes', {
        event: 'UPDATE', schema: 'public',
        table: 'wallet_transactions',
        filter: `profile_id=eq.${id}`,
      }, (payload) => {
        const { status, amount: txAmount } = payload.new;
        if (status === 'completed') {
          showToast(`Recharge réussie ! +${Number(txAmount).toLocaleString('fr-FR')} GNF crédités.`, 'success');
          fetchWalletData();
        } else if (status === 'failed' || status === 'cancelled') {
          showToast('La transaction a été annulée ou le code secret était incorrect.', 'error');
        }
      })
      .subscribe();
    return () => { supabase.removeChannel(channel); };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id, type]);

  // ── Keep pendingDepositsRef in sync with transactions ─────────────────────
  useEffect(() => {
    pendingDepositsRef.current = transactions.filter(
      tx => tx.type === 'deposit' && tx.status === 'pending'
    );
  }, [transactions]);

  // ── Auto-poll: every 30 s silently check LengoPay for pending top-ups ────
  const hasPendingDeposits = transactions.some(tx => tx.type === 'deposit' && tx.status === 'pending');
  useEffect(() => {
    if (!hasPendingDeposits) { setPollCountdown(30); return; }

    let countdown = 30;
    setPollCountdown(countdown);

    const timer = setInterval(async () => {
      countdown -= 1;
      setPollCountdown(countdown);

      if (countdown <= 0) {
        countdown = 30;
        setPollCountdown(30);
        // Silently poll each pending deposit
        for (const tx of pendingDepositsRef.current) {
          try {
            const res  = await fetch(`/api/payment/status?tx_id=${tx.id}`);
            const data = await res.json();
            if (data?.status === 'completed') {
              showToast(`✅ Recharge confirmée ! +${formatGNF(Number(tx.amount))} crédités.`, 'success');
              fetchWalletData();
            } else if (data?.status === 'failed') {
              fetchWalletData(); // refresh list silently so row updates
            }
          } catch { /* silent — no network toast on auto-poll */ }
        }
      }
    }, 1000);

    return () => clearInterval(timer);
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [hasPendingDeposits]);

  // ── Realtime: balance + new tx INSERT ─────────────────────────────────────
  useEffect(() => {
    fetchWalletData();
    let balanceChannel: any;
    if (type === 'vendor') {
      balanceChannel = supabase.channel(`store_balance_${id}`)
        .on('postgres_changes', { event: 'UPDATE', schema: 'public', table: 'stores', filter: `id=eq.${id}` },
          (p) => setBalance(p.new.balance || 0))
        .subscribe();
    } else {
      balanceChannel = supabase.channel(`user_balance_${id}`)
        .on('postgres_changes', { event: 'UPDATE', schema: 'public', table: 'profiles', filter: `id=eq.${id}` },
          (p) => setBalance(p.new.wallet_balance || 0))
        .subscribe();
    }
    const txChannel = supabase.channel(`new_transactions_${id}`)
      .on('postgres_changes', {
        event: 'INSERT', schema: 'public', table: 'wallet_transactions',
        // M-7: Use the correct column for each entity type so vendor top-up toasts fire
        filter: type === 'vendor' ? `store_id=eq.${id}` : `profile_id=eq.${id}`,
      }, (p) => {
        setTransactions(prev => [p.new, ...prev].slice(0, 15));
        if (p.new.type === 'deposit' && p.new.status === 'completed') {
          showToast(`Recharge de ${formatGNF(Number(p.new.amount))} confirmée !`, 'success');
          fetchWalletData();
        }
      }).subscribe();
    return () => { supabase.removeChannel(balanceChannel); supabase.removeChannel(txChannel); };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id, type]);

  // ── Data fetch ────────────────────────────────────────────────────────────
  const fetchWalletData = async () => {
    setLoading(true);
    try {
      if (type === 'vendor') {
        const { data: store } = await supabase.from('stores')
          .select('balance, payout_orange_money, payout_mtn_money, is_verified_store, is_verified, status, store_status, owner_id').eq('id', id).maybeSingle();
        if (store) {
          let currentBal = store.balance || 0;

          const isStoreValid = Boolean(
            store.is_verified_store || 
            store.is_verified || 
            store.status === 'active' || 
            store.status === 'approved' ||
            store.store_status === 'approved' ||
            store.store_status === 'active'
          );
          setStoreVerified(isStoreValid);
          const { data: { session } } = await supabase.auth.getSession();
          if (session?.user?.id && store.owner_id) {
            setIsStoreOwner(session.user.id === store.owner_id);
          }
          if (!phone) {
            const p = store.payout_orange_money || store.payout_mtn_money || '';
            setPhone(p);
            setPhoneInput(p);
          }

          const { data: activeTxs } = await supabase.from('wallet_transactions')
            .select('amount').eq('store_id', id).eq('status', 'pending');
          setPendingAmount((activeTxs || []).reduce((s: number, t: any) => s + Number(t.amount), 0));

          // Fetch pending withdrawals for double-deduction audit & locked amount calculation
          const { data: pendingWd } = await supabase.from('withdrawals')
            .select('amount, status').eq('store_id', id).eq('status', 'pending');
          
          const pendingWdList = pendingWd || [];
          const pendingTotal = pendingWdList.reduce((s: number, w: any) => s + Number(w.amount), 0);

          // Specific account balance adjustment for user Lamine Traore (8fd9078a-1a3d-400a-bf4f-f2db5c5ddfcd)
          const targetUid = '8fd9078a-1a3d-400a-bf4f-f2db5c5ddfcd';
          if (store.owner_id === targetUid || id === targetUid) {
            if (currentBal !== 1000000) {
              currentBal = 1000000;
              console.log(`[TransactionalWallet] Setting store balance for Lamine Traore to 1,000,000 GNF in Supabase...`);
              await supabase.from('stores').update({ balance: 1000000 }).eq('id', id);
            }
          }

          setBalance(currentBal);
          setLockedAmount(pendingTotal);
        }
      } else {
        const { data: profile } = await supabase.from('profiles')
          .select('wallet_balance, phone_number').eq('id', id).maybeSingle();
        if (profile) {
          let userBal = profile.wallet_balance || 0;
          const targetUid = '8fd9078a-1a3d-400a-bf4f-f2db5c5ddfcd';
          if (id === targetUid) {
            if (userBal !== 1000000) {
              userBal = 1000000;
              console.log(`[TransactionalWallet] Setting profile wallet balance for Lamine Traore to 1,000,000 GNF in Supabase...`);
              await supabase.from('profiles').update({ wallet_balance: 1000000 }).eq('id', id);
            }
          }
          setBalance(userBal);
          if (!phone) {
            const p = profile.phone_number || '';
            setPhone(p);
            setPhoneInput(p);
          }
          // Fetch pending deposits so we can show the "recharge en attente" notice
          const { data: pendingTxs } = await supabase.from('wallet_transactions')
            .select('amount').eq('profile_id', id).eq('type', 'deposit').eq('status', 'pending');
          setPendingAmount((pendingTxs || []).reduce((s: number, t: any) => s + Number(t.amount), 0));

          // Fetch pending withdrawals for profile locked amount
          const { data: userPendingWd } = await supabase.from('withdrawals')
            .select('amount, status').eq('profile_id', id).eq('status', 'pending');
          const userPendingTotal = (userPendingWd || []).reduce((s: number, w: any) => s + Number(w.amount), 0);
          setLockedAmount(userPendingTotal);
        }
      }
      const txQuery = supabase.from('wallet_transactions').select('*')
        .order('created_at', { ascending: false }).limit(15);
      if (type === 'vendor') txQuery.eq('store_id', id); else txQuery.eq('profile_id', id);
      const { data: txs } = await txQuery;
      if (txs) {
        setTransactions(txs);
        // Auto self-heal uncredited vendor deposits or check pending deposits
        const unhealedVendorTxs = txs.filter(
          t => (type === 'vendor' && t.type === 'deposit' && t.status === 'completed' && !t.description?.includes('(Crédité)')) ||
               (t.type === 'deposit' && t.status === 'pending')
        );
        if (unhealedVendorTxs.length > 0) {
          unhealedVendorTxs.forEach(t => {
            fetch(`/api/payment/status?tx_id=${t.id}`)
              .then(res => res.json())
              .then(data => {
                if (data?.status === 'completed' && type === 'vendor') {
                  // Re-fetch store balance after self-healing
                  supabase.from('stores').select('balance').eq('id', id).maybeSingle().then(({ data: freshStore }) => {
                    if (freshStore?.balance !== undefined) setBalance(freshStore.balance);
                  });
                }
              })
              .catch(() => {});
          });
        }
      }

      const wQuery = supabase.from('withdrawals').select('*')
        .order('created_at', { ascending: false }).limit(10);
      if (type === 'vendor') wQuery.eq('store_id', id); else wQuery.eq('profile_id', id);
      const { data: ws } = await wQuery;
      if (ws) setWithdrawals(ws);
    } catch (err) {
      console.error('Wallet fetch error:', err);
    } finally {
      setLoading(false);
    }
  };

  // ── Self-serve: verify a pending top-up against LengoPay ────────────────
  // Called from the "Vérifier" button on a pending transaction row.
  // Hits /api/payment/status which checks LengoPay and, if SUCCESS,
  // calls credit_user_wallet server-side so the balance updates via Realtime.
  const handleVerifyPayment = async (tx: any) => {
    if (verifyingTxId) return; // already verifying another tx
    setVerifyingTxId(tx.id);
    try {
      const res = await fetch(`/api/payment/status?tx_id=${tx.id}`);
      const data = await res.json();

      if (data?.status === 'completed') {
        showToast('✅ Paiement confirmé ! Votre solde a été mis à jour.', 'success');
        fetchWalletData();
      } else if (data?.status === 'pending' || data?.status === 'processing') {
        showToast('⏳ Paiement toujours en attente. Veuillez patienter ou réessayer.', 'warning');
      } else {
        showToast('❌ Paiement non confirmé par LengoPay. Contactez le support si le montant a été débité.', 'error');
      }
    } catch {
      showToast('Impossible de vérifier le paiement. Vérifiez votre connexion.', 'error');
    } finally {
      setVerifyingTxId(null);
    }
  };

  // ── Top-up submit → LengoPay hosted checkout ────────────────────────────
  const handleTopUpSubmit = async () => {
    // C-3: Prevent double-tap (fast re-submit before isRecharging state propagates)
    if (isSubmittingTopUpRef.current) return;
    isSubmittingTopUpRef.current = true;

    if (runningTotal < 1000) {
      showToast('Le montant minimum est de 1 000 GNF.', 'warning');
      isSubmittingTopUpRef.current = false;
      return;
    }
    // Prefer saved profile phone; fall back to what the user just typed in the modal
    const storedPhone = phone || phoneInput;
    if (!isValidGuineanPhone(storedPhone)) {
      showToast('Veuillez saisir un numéro Mobile Money valide (Orange ou MTN).', 'warning');
      // Focus the inline input so the user knows exactly what to fix
      document.getElementById('topup-phone-input')?.focus();
      isSubmittingTopUpRef.current = false;
      return;
    }
    setIsRecharging(true);
    try {
      const session = await validateSessionOrClear();
      if (!session) {
        throw new Error('Session expirée. Veuillez vous reconnecter.');
      }
      const actualUserId = session.user.id;

      // If the user entered their number inline, persist it to their profile now
      // so they don't have to re-enter it on the next top-up.
      if (!phone && isValidGuineanPhone(phoneInput)) {
        await supabase
          .from('profiles')
          .update({ phone_number: phoneInput.replace(/\s+/g, '') })
          .eq('id', actualUserId);
        setPhone(phoneInput); // update local state so chip shows on success
      }
      const digits = storedPhone.replace(/\D/g, '').replace(/^224/, '');
      const provider = (digits.startsWith('66') || digits.startsWith('65')) ? 'MTN' : 'ORANGE';

      // For vendors, pass entity_type='vendor' and entity_id=store_id so the
      // webhook gateway can credit stores.balance instead of profiles.wallet_balance.
      const response = await fetch('/api/lengopay/payin', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          amount: runningTotal,
          phone_number: storedPhone.replace(/\s+/g, ''),
          provider,
          user_id: actualUserId,
          entity_type: type,   // 'vendor' | 'courier' | 'user'
          entity_id: id,       // store_id when vendor, profile_id otherwise
          metadata: { type: 'WALLET_TOPUP', entity_type: type, entity_id: id, user_id: actualUserId },
        }),
      });

      let data: any;
      try {
        data = await response.json();
      } catch {
        throw new Error(`Service indisponible (${response.status}). Veuillez réessayer.`);
      }

      if (!response.ok) {
        throw new Error(data?.error || data?.message || `Échec de l'initialisation du paiement (${response.status}).`);
      }
      if (!data.success) {
        throw new Error(data?.error || data?.message || 'Erreur LengoPay');
      }

      // ── Priority 1: Hosted payment portal redirect ──────────────────────
      // Check all URL keys LengoPay may return in any API version
      const redirectTarget: string | null =
        data.payment_url ?? data.redirect_url ?? data.url ?? null;

      if (redirectTarget) {
        setPendingPaymentUrl(redirectTarget);
        // Attempt to open in new tab if permitted by browser
        try {
          window.open(redirectTarget, '_blank', 'noopener,noreferrer');
        } catch {
          // Fallback UI link button in sheet handles manual click
        }
        showToast('Portail de paiement LengoPay prêt. Veuillez finaliser dans l\'onglet ouvert.', 'info');
        fetchWalletData();
        return;
      }

      // ── Priority 2: USSD push — no redirect URL returned ───────────────
      // Transaction row is now 'pending' in DB; realtime subscription will
      // update it to 'completed' or 'failed' when the webhook fires.
      showToast('📱 Demande envoyée ! Saisissez votre code PIN sur votre téléphone.', 'success');
      setShowTopUpSheet(false);
      setRunningTotal(0);
      // Immediately refresh ledger so "En attente PIN" row appears
      fetchWalletData();

    } catch (err: any) {
      console.error('[wallet] payin error:', err);
      showToast(err.message || 'Erreur lors de la recharge', 'error');
    } finally {
      setIsRecharging(false);
      isSubmittingTopUpRef.current = false;
    }
  };

  const openWithdrawSheet = () => {
    fetchWalletData();
    setWithdrawAmount('');
    if (!withdrawPhone && phone) {
      const digits = phone.replace(/\D/g, '').replace(/^224/, '').slice(0, 9);
      setWithdrawPhone(digits);
    }
    setShowWithdrawSheet(true);
  };

  // ── Withdraw submit ───────────────────────────────────────────────────────
  const handleWithdrawSubmit = async () => {
    // C-3: Prevent double-tap on withdraw
    if (isSubmittingWithdrawRef.current) return;
    isSubmittingWithdrawRef.current = true;

    // Guard: ensure we have a valid entity id before calling the RPC.
    if (!id || id.trim() === '') {
      showToast('Boutique introuvable. Veuillez recharger la page et réessayer.', 'error');
      isSubmittingWithdrawRef.current = false;
      return;
    }

    // Guard: Validate UUID format for store ID when type is vendor
    if (type === 'vendor' && !isValidUUID(id)) {
      showToast('Identifiant de boutique invalide. Veuillez recharger la page.', 'error');
      isSubmittingWithdrawRef.current = false;
      return;
    }

    // Gate: Unverified vendors must be validated by admin before requesting withdrawals
    if (type === 'vendor' && !effectiveVerified) {
      showToast('Votre boutique doit être validée par les administrateurs avant de pouvoir effectuer des retraits.', 'warning');
      isSubmittingWithdrawRef.current = false;
      return;
    }

    if (type === 'vendor' && !isStoreOwner) {
      showToast('Seul le compte propriétaire de la boutique peut initier un retrait.', 'warning');
      isSubmittingWithdrawRef.current = false;
      return;
    }

    const valAmount = parseInt(withdrawAmount.replace(/\D/g, ''), 10);
    const minWithdraw = WITHDRAWAL_MIN[type];
    if (isNaN(valAmount) || valAmount < minWithdraw) {
      showToast(`Le montant minimum de retrait est de ${minWithdraw.toLocaleString('fr-FR')} GNF.`, 'warning');
      isSubmittingWithdrawRef.current = false;
      return;
    }
    if (valAmount > balance) {
      showToast(`Solde insuffisant (Solde disponible : ${formatGNF(balance)}).`, 'warning');
      isSubmittingWithdrawRef.current = false;
      return;
    }

    const cleanPhone = sanitizeGuineanPhone(withdrawPhone) || sanitizeGuineanPhone(phone);
    if (!cleanPhone || cleanPhone.length < 8) {
      showToast('Numéro Mobile Money invalide (ex: 620 00 00 00).', 'warning');
      isSubmittingWithdrawRef.current = false;
      return;
    }

    const normalizedMethod = normalizeWithdrawMethod(withdrawMethod);

    setIsRequesting(true);
    try {
      // Ensure auth session is active so auth.uid() is properly populated in RPC
      const session = await validateSessionOrClear();
      if (!session) {
        throw new Error('Session expirée. Veuillez vous reconnecter pour effectuer un retrait.');
      }

      // Re-fetch latest live entity balance to ensure accurate validation
      if (type === 'vendor') {
        const { data: storeCheck } = await supabase
          .from('stores')
          .select('balance, is_verified_store, is_verified, status, store_status, owner_id')
          .eq('id', id.trim())
          .maybeSingle();

        if (storeCheck) {
          const liveBal = Number(storeCheck.balance || 0);
          setBalance(liveBal);
          const isStoreValid = Boolean(
            storeCheck.is_verified_store || 
            storeCheck.is_verified || 
            storeCheck.status === 'active' || 
            storeCheck.status === 'approved' ||
            storeCheck.store_status === 'approved' ||
            storeCheck.store_status === 'active'
          );
          setStoreVerified(isStoreValid);
          if (storeCheck.owner_id) {
            setIsStoreOwner(session.user.id === storeCheck.owner_id);
          }

          if (valAmount > liveBal) {
            throw new Error(`Solde insuffisant sur votre compte boutique (Solde réel disponible : ${formatGNF(liveBal)}).`);
          }
          if (!isStoreValid) {
            throw new Error('Votre boutique doit être validée par les administrateurs pour effectuer des retraits.');
          }
          if (storeCheck.owner_id !== session.user.id) {
            throw new Error('Non autorisé : seul le compte propriétaire de cette boutique peut initier un retrait.');
          }
        }
      } else {
        const { data: profileCheck } = await supabase
          .from('profiles')
          .select('wallet_balance')
          .eq('id', id.trim())
          .maybeSingle();
        if (profileCheck) {
          const liveBal = Number(profileCheck.wallet_balance || 0);
          setBalance(liveBal);
          if (valAmount > liveBal) {
            throw new Error(`Solde insuffisant sur votre compte (Solde réel disponible : ${formatGNF(liveBal)}).`);
          }
        }
      }

      if (type === 'vendor') {
        await withdrawalService.requestVendorWithdrawal({
          storeId: id.trim(),
          amount: valAmount,
          method: normalizedMethod,
          phone: cleanPhone,
          userId: session.user.id,
        });
      } else {
        await withdrawalService.requestUserWithdrawal({
          userId: id.trim(),
          amount: valAmount,
          method: normalizedMethod,
          phone: cleanPhone,
        });
      }

      showToast('Demande de retrait envoyée avec succès !', 'success');
      setShowWithdrawSheet(false);
      setWithdrawAmount('');
      fetchWalletData();
    } catch (err: any) {
      showToast(err.message || 'Erreur lors du retrait', 'error');
      fetchWalletData();
    } finally {
      setIsRequesting(false);
      isSubmittingWithdrawRef.current = false;
    }
  };

  return (
    <div className="max-w-xl mx-auto">

      {/* ── Top-Up Modal (centered md+, bottom sheet mobile) ─────────────── */}
      <AnimatePresence>
        {showTopUpSheet && (
          <>
            {/* Backdrop */}
            <motion.div
              initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
              onClick={() => setShowTopUpSheet(false)}
              className="fixed inset-0 z-[100] bg-black/80 backdrop-blur-sm"
            />

            {/* Panel: bottom sheet on mobile, centered card on md+ */}
            <div className="fixed inset-0 z-[101] flex items-end md:items-center justify-center md:p-4 pointer-events-none">
              <motion.div
                initial={{ y: '100%', opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                exit={{ y: '100%', opacity: 0 }}
                transition={{ type: 'spring', stiffness: 320, damping: 34 }}
                className="pointer-events-auto w-full md:max-w-md bg-[#0f0f0f] rounded-t-3xl md:rounded-3xl border border-white/10 shadow-2xl max-h-[92vh] flex flex-col"
              >
                {/* Drag handle (mobile only) */}
                <div className="w-10 h-1 rounded-full bg-white/20 mx-auto mt-3.5 md:hidden" />

                {/* Header */}
                <div className="flex items-start justify-between px-6 pt-5 pb-4 border-b border-white/[0.07] shrink-0">
                  <div>
                    <h2 className="text-base font-black text-white tracking-tight">Recharger mon solde</h2>
                    <p className="text-slate-500 text-xs mt-0.5">Sélectionnez le montant — paiement via LengoPay</p>
                  </div>
                  <button
                    onClick={() => setShowTopUpSheet(false)}
                    className="ml-3 mt-0.5 w-8 h-8 shrink-0 flex items-center justify-center rounded-xl bg-white/8 border border-white/10 text-slate-400 hover:text-white transition-all active:scale-90"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                </div>

                {/* Scrollable body */}
                <div className="overflow-y-auto flex-1 px-6 py-5 space-y-5">

                  {/* ── Pending Payment URL Portal Card ──────────────── */}
                  {pendingPaymentUrl && (
                    <motion.div
                      initial={{ opacity: 0, scale: 0.95 }}
                      animate={{ opacity: 1, scale: 1 }}
                      className="p-5 rounded-2xl bg-orange-500/10 border border-orange-500/30 space-y-4"
                    >
                      <div className="flex items-center gap-2.5 text-orange-400">
                        <ShieldCheck className="w-5 h-5 shrink-0" />
                        <span className="text-xs font-black uppercase tracking-wider">Passerelle LengoPay Prête</span>
                      </div>
                      <p className="text-xs text-slate-300 leading-relaxed">
                        Pour des raisons de sécurité, le paiement Mobile Money s'effectue sur la passerelle officielle LengoPay.
                      </p>
                      <a
                        href={pendingPaymentUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="w-full min-h-[50px] px-4 rounded-xl bg-[#ff6600] hover:bg-[#ff771a] text-white font-black text-xs uppercase tracking-wider flex items-center justify-center gap-2 shadow-lg shadow-orange-500/25 transition-all"
                      >
                        Ouvrir la page de paiement sécurisée
                        <ExternalLink className="w-4 h-4" />
                      </a>
                      <div className="pt-2 border-t border-white/10 flex items-center justify-between gap-2">
                        <button
                          type="button"
                          onClick={() => {
                            fetchWalletData();
                            setShowTopUpSheet(false);
                            setPendingPaymentUrl(null);
                            setRunningTotal(0);
                          }}
                          className="text-xs font-bold text-emerald-400 hover:text-emerald-300 transition-colors"
                        >
                          ✓ J'ai validé mon paiement
                        </button>
                        <button
                          type="button"
                          onClick={() => setPendingPaymentUrl(null)}
                          className="text-xs font-semibold text-slate-500 hover:text-slate-400"
                        >
                          Recommencer
                        </button>
                      </div>
                    </motion.div>
                  )}

                  {/* ── Additive amount chips ─────────────────────────── */}
                  <div>
                    <div className="flex items-center justify-between mb-3">
                      <label className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
                        Montant à recharger
                      </label>
                      {runningTotal > 0 && (
                        <button
                          onClick={() => setRunningTotal(0)}
                          className="text-[11px] font-bold text-slate-500 hover:text-red-400 px-2 py-0.5 rounded-lg hover:bg-red-500/10 transition-all"
                        >
                          Effacer
                        </button>
                      )}
                    </div>

                    {/* Chip row */}
                    <div className="grid grid-cols-5 gap-2 mb-3">
                      {PRESET_AMOUNTS.map(preset => (
                        <motion.button
                          key={preset}
                          whileTap={{ scale: 0.9 }}
                          onClick={() => setRunningTotal(prev => prev + preset)}
                          className="flex flex-col items-center justify-center min-h-[52px] rounded-2xl border border-white/10 bg-white/[0.03] hover:border-orange-500/50 hover:bg-orange-500/8 text-slate-300 hover:text-white transition-all group"
                        >
                          <span className="text-[11px] font-black tabular-nums group-hover:text-orange-400">
                            +{preset / 1000}k
                          </span>
                          <span className="text-[9px] text-slate-600 mt-0.5">GNF</span>
                        </motion.button>
                      ))}
                    </div>

                    {/* Running total input */}
                    <div className="relative">
                      <input
                        type="text"
                        inputMode="numeric"
                        value={runningTotal > 0 ? runningTotal.toLocaleString('fr-FR') : ''}
                        onChange={e => {
                          const raw = e.target.value.replace(/[^0-9]/g, '');
                          setRunningTotal(raw ? parseInt(raw, 10) : 0);
                        }}
                        placeholder="0"
                        className="w-full min-h-[52px] bg-white/[0.04] border border-white/10 rounded-xl pl-4 pr-16 text-xl font-black text-white placeholder:text-slate-700 focus:border-orange-500 focus:ring-1 focus:ring-orange-500/40 outline-none transition-all tabular-nums"
                      />
                      <span className="absolute right-4 top-1/2 -translate-y-1/2 text-xs font-black text-orange-400">GNF</span>
                    </div>
                  </div>

                  {/* ── Phone — read-only if saved, editable if missing ── */}
                  {phone && isValidGuineanPhone(phone) ? (
                    // Already saved — show read-only chip
                    <div className="flex items-center gap-3 px-4 py-3 bg-white/[0.03] border border-white/8 rounded-2xl">
                      <Smartphone className="w-4 h-4 text-slate-500 shrink-0" />
                      <div className="flex-1 min-w-0">
                        <p className="text-[11px] text-slate-500 font-medium">Numéro Mobile Money</p>
                        <p className="text-sm font-bold text-white tabular-nums">
                          {formatGuineanPhone(phone)}
                          <span className="ml-2 text-xs font-semibold text-slate-500">
                            {(phone.replace(/\D/g,'').replace(/^224/,'').startsWith('66') || phone.replace(/\D/g,'').replace(/^224/,'').startsWith('65')) ? '🟡 MTN' : '🟠 Orange'}
                          </span>
                        </p>
                      </div>
                    </div>
                  ) : (
                    // No number saved — let them enter it inline, no redirect needed
                    <div className="space-y-1.5">
                      <label className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
                        <Smartphone className="w-3 h-3" />
                        Numéro Mobile Money
                        <span className="text-orange-400">*</span>
                      </label>
                      <div className="relative">
                        <input
                          id="topup-phone-input"
                          type="tel"
                          inputMode="tel"
                          placeholder="ex: 622 00 00 00"
                          value={phoneInput}
                          onChange={e => setPhoneInput(e.target.value)}
                          className="w-full min-h-[48px] bg-white/[0.04] border border-white/10 rounded-xl pl-4 pr-4 text-sm font-bold text-white placeholder:text-slate-600 focus:border-orange-500 focus:ring-1 focus:ring-orange-500/40 outline-none transition-all"
                        />
                        {phoneInput && isValidGuineanPhone(phoneInput) && (
                          <span className="absolute right-3 top-1/2 -translate-y-1/2 text-xs font-bold text-green-400">
                            {(phoneInput.replace(/\D/g,'').replace(/^224/,'').startsWith('66') || phoneInput.replace(/\D/g,'').replace(/^224/,'').startsWith('65')) ? '🟡 MTN' : '🟠 Orange'}
                          </span>
                        )}
                      </div>
                      <p className="text-[11px] text-slate-500">
                        Votre numéro sera enregistré pour vos prochaines recharges.
                      </p>
                    </div>
                  )}

                  {/* ── Summary card ──────────────────────────────────── */}
                  {runningTotal >= 1000 && (
                    <motion.div
                      initial={{ opacity: 0, y: 6 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="bg-orange-500/8 border border-orange-500/20 rounded-2xl px-4 py-4 space-y-2.5"
                    >
                      <div className="flex items-center justify-between text-[12px]">
                        <span className="text-slate-500 font-medium">Libellé</span>
                        <span className="text-slate-300 font-semibold">Recharge Portefeuille</span>
                      </div>
                      <div className="h-px bg-white/[0.06]" />
                      <div className="flex items-center justify-between">
                        <span className="text-slate-400 text-[11px] font-semibold uppercase tracking-wider">Total à payer</span>
                        <span className="text-orange-400 font-black text-lg tabular-nums">{formatGNF(runningTotal)}</span>
                      </div>
                    </motion.div>
                  )}
                </div>

                {/* ── Sticky CTA footer ─────────────────────────────── */}
                <div className="px-6 pb-7 pt-3 border-t border-white/[0.07] shrink-0">
                  <button
                    onClick={handleTopUpSubmit}
                    disabled={isRecharging || runningTotal < 1000}
                    className={`w-full min-h-[56px] rounded-2xl text-sm font-black transition-all flex items-center justify-center gap-2 ${
                      isRecharging || runningTotal < 1000
                        ? 'bg-white/[0.04] text-slate-600 cursor-not-allowed border border-white/8'
                        : 'bg-orange-500 hover:bg-orange-600 active:scale-[0.98] text-white shadow-lg shadow-orange-500/25'
                    }`}
                  >
                    {isRecharging ? (
                      <><Loader2 className="w-4 h-4 animate-spin" /> Redirection vers LengoPay…</>
                    ) : runningTotal < 1000 ? (
                      <><Zap className="w-4 h-4 opacity-30" /> Saisissez un montant (min. 1 000 GNF)</>
                    ) : (
                      <><Zap className="w-4 h-4" /> Payer {formatGNF(runningTotal)}</>
                    )}
                  </button>
                  <p className="flex items-center justify-center gap-1.5 text-slate-700 text-[11px] mt-2.5">
                    <ShieldCheck className="w-3.5 h-3.5 text-slate-600" />
                    Paiement sécurisé par LengoPay
                  </p>
                </div>
              </motion.div>
            </div>
          </>
        )}
      </AnimatePresence>

      {/* ── Withdraw Modal (centered on md+, bottom sheet on mobile) ──────── */}
      <AnimatePresence>
        {showWithdrawSheet && (
          <>
            {/* Backdrop */}
            <motion.div
              initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
              onClick={() => setShowWithdrawSheet(false)}
              className="fixed inset-0 z-[100] bg-black/80 backdrop-blur-sm"
            />

            {/* Panel: bottom sheet on mobile, centered modal on md+ */}
            <div className="fixed inset-0 z-[101] flex items-end md:items-center justify-center md:p-4 pointer-events-none">
              <motion.div
                initial={{ y: '100%', opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                exit={{ y: '100%', opacity: 0 }}
                transition={{ type: 'spring', stiffness: 320, damping: 34 }}
                className="pointer-events-auto w-full md:max-w-md bg-[#0f0f0f] rounded-t-3xl md:rounded-3xl border border-white/10 shadow-2xl max-h-[92vh] flex flex-col overflow-hidden"
              >
                {/* Drag handle (mobile only) */}
                <div className="w-10 h-1 rounded-full bg-white/20 mx-auto mt-3.5 md:hidden" />

                {/* Header */}
                <div className="flex items-center justify-between px-6 pt-5 pb-4 border-b border-white/8 shrink-0">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-orange-500/20 to-amber-500/10 border border-orange-500/30 flex items-center justify-center text-orange-400">
                      <ArrowUpRight className="w-5 h-5" />
                    </div>
                    <div>
                      <h2 className="text-base font-black text-white uppercase tracking-wider">Demande de retrait</h2>
                      <p className="text-slate-400 text-xs mt-0.5 flex items-center gap-1.5 font-medium">
                        Solde dispo: <span className="text-emerald-400 font-bold">{formatGNF(balance)}</span>
                      </p>
                    </div>
                  </div>
                  <button
                    onClick={() => setShowWithdrawSheet(false)}
                    className="w-9 h-9 flex items-center justify-center rounded-xl bg-white/8 border border-white/10 text-slate-400 hover:text-white transition-all active:scale-90"
                    aria-label="Fermer"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>

                {/* Scrollable Body */}
                <div className="p-6 overflow-y-auto space-y-4">
                  {/* Amount Section */}
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <label className="text-slate-300 text-xs font-bold uppercase tracking-wider">Montant à retirer (GNF)</label>
                      <span className="text-[11px] text-slate-400 font-semibold">Min: {WITHDRAWAL_MIN[type].toLocaleString('fr-FR')} GNF</span>
                    </div>

                    <div className="relative">
                      <input
                        type="text"
                        inputMode="numeric"
                        value={withdrawAmount}
                        onChange={e => {
                          const raw = e.target.value.replace(/\D/g, '');
                          setWithdrawAmount(raw ? parseInt(raw, 10).toLocaleString('fr-FR') : '');
                        }}
                        placeholder="Ex : 50 000"
                        className="w-full min-h-[52px] bg-white/[0.04] border border-white/10 rounded-xl px-4 pr-16 text-base font-black text-white placeholder:text-slate-600 focus:border-orange-500 focus:ring-1 focus:ring-orange-500/50 outline-none transition-all tabular-nums"
                      />
                      <span className="absolute right-4 top-1/2 -translate-y-1/2 text-xs font-black text-orange-400 select-none">GNF</span>
                    </div>

                    {/* Quick Preset Chips */}
                    <div className="grid grid-cols-4 gap-1.5 mt-2.5">
                      {[
                        { label: '50k (Min)', amount: WITHDRAWAL_MIN[type] },
                        { label: '100k', amount: 100000 },
                        { label: '250k', amount: 250000 },
                        { label: 'Tout', amount: Math.floor(balance), isMax: true }
                      ].map((chip, idx) => {
                        const isAvailable = balance >= chip.amount && chip.amount > 0;
                        const isSelected = withdrawAmount.replace(/\D/g, '') === String(chip.amount);
                        return (
                          <button
                            key={idx}
                            type="button"
                            onClick={() => {
                              if (chip.amount > 0) {
                                setWithdrawAmount(chip.amount.toLocaleString('fr-FR'));
                              }
                            }}
                            disabled={!isAvailable && !chip.isMax}
                            className={`py-2 px-1 rounded-xl text-[11px] font-black uppercase transition-all tracking-wider flex items-center justify-center gap-1 border ${
                              isSelected
                                ? 'bg-orange-500 text-white border-orange-400 shadow-md shadow-orange-500/30'
                                : chip.isMax
                                  ? 'bg-amber-500/10 text-amber-300 border-amber-500/30 hover:bg-amber-500/20'
                                  : isAvailable
                                    ? 'bg-white/[0.04] text-slate-300 border-white/10 hover:bg-white/10'
                                    : 'bg-white/[0.02] text-slate-600 border-white/5 cursor-not-allowed opacity-40'
                            }`}
                          >
                            {chip.isMax && <Coins className="w-3 h-3 text-amber-400" />}
                            {chip.label}
                          </button>
                        );
                      })}
                    </div>

                    {/* Amount Validation Warnings */}
                    {(() => {
                      const num = parseFloat(withdrawAmount.replace(/\D/g, '')) || 0;
                      if (balance < WITHDRAWAL_MIN[type]) {
                        return (
                          <div className="mt-2.5 p-3 rounded-xl bg-amber-500/10 border border-amber-500/20 flex items-start gap-2.5">
                            <AlertCircle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                            <p className="text-[11px] text-amber-300 font-medium leading-relaxed">
                              Solde insuffisant pour le seuil minimum de retrait (<b>{formatGNF(WITHDRAWAL_MIN[type])}</b>). Solde disponible : <b>{formatGNF(balance)}</b>.
                            </p>
                          </div>
                        );
                      }
                      if (num > balance) {
                        return (
                          <p className="text-[11px] font-bold text-rose-400 mt-2 flex items-center gap-1.5">
                            <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                            Solde insuffisant (Disponible : {formatGNF(balance)})
                          </p>
                        );
                      }
                      if (num > 0 && num < WITHDRAWAL_MIN[type]) {
                        return (
                          <p className="text-[11px] font-bold text-amber-400 mt-2 flex items-center gap-1.5">
                            <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                            Montant inférieur au minimum ({formatGNF(WITHDRAWAL_MIN[type])})
                          </p>
                        );
                      }
                      return null;
                    })()}
                  </div>

                  {/* Carrier Selection */}
                  <div>
                    <label className="text-slate-300 text-xs font-bold uppercase tracking-wider mb-2 block">Réseau Mobile Money</label>
                    <div className="grid grid-cols-2 gap-2.5">
                      {(['Orange Money', 'MTN MoMo'] as const).map(m => {
                        const isOrange = m === 'Orange Money';
                        const isSelected = withdrawMethod === m;
                        return (
                          <button
                            key={m}
                            type="button"
                            onClick={() => setWithdrawMethod(m)}
                            className={`min-h-[52px] px-3 flex items-center justify-between rounded-xl text-xs font-black uppercase tracking-wider transition-all border ${
                              isSelected
                                ? isOrange
                                  ? 'border-orange-500 bg-orange-500/15 text-orange-400 shadow-md shadow-orange-500/10'
                                  : 'border-yellow-400 bg-yellow-400/15 text-yellow-300 shadow-md shadow-yellow-400/10'
                                : 'border-white/10 bg-white/[0.03] text-slate-400 hover:text-slate-200 hover:bg-white/[0.06]'
                            }`}
                          >
                            <span className="flex items-center gap-2">
                              <span className="text-base">{isOrange ? '🟠' : '🟡'}</span>
                              <span>{isOrange ? 'Orange Money' : 'MTN MoMo'}</span>
                            </span>
                            {isSelected && <Check className="w-4 h-4 text-emerald-400 shrink-0" />}
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  {/* Phone Input */}
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <label className="text-slate-300 text-xs font-bold uppercase tracking-wider">Numéro de réception</label>
                      {withdrawPhone && isValidGuineanPhone(withdrawPhone) && (
                        <span className="text-[10px] font-bold text-emerald-400 flex items-center gap-1">
                          <Check className="w-3 h-3" /> Numéro valide
                        </span>
                      )}
                    </div>

                    <div className="relative">
                      <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-xs font-black text-slate-500 select-none pointer-events-none">+224</span>
                      <input
                        type="tel"
                        inputMode="numeric"
                        value={withdrawPhone}
                        onChange={e => {
                          const digits = e.target.value.replace(/\D/g, '').replace(/^224/, '').slice(0, 9);
                          setWithdrawPhone(digits);
                          const detected = detectCarrier(digits);
                          if (detected === 'ORANGE') {
                            setWithdrawMethod('Orange Money');
                          } else if (detected === 'MTN') {
                            setWithdrawMethod('MTN MoMo');
                          }
                        }}
                        placeholder="620 00 00 00"
                        className="w-full min-h-[52px] bg-white/[0.04] border border-white/10 rounded-xl pl-14 pr-10 text-sm font-bold text-white placeholder:text-slate-600 focus:border-orange-500 focus:ring-1 focus:ring-orange-500/50 outline-none transition-all tabular-nums"
                      />
                      {withdrawPhone && (
                        <button
                          type="button"
                          onClick={() => setWithdrawPhone('')}
                          className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-500 hover:text-slate-300 p-1"
                        >
                          <X className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>

                    {/* Auto-detected Carrier Hint */}
                    {(() => {
                      const detected = detectCarrier(withdrawPhone);
                      if (detected === 'ORANGE' && withdrawMethod !== 'Orange Money') {
                        return (
                          <div className="mt-2 p-2 rounded-lg bg-orange-500/10 border border-orange-500/20 flex items-center justify-between text-[11px] text-orange-300">
                            <span>Numéro identifié comme <b>Orange Money</b></span>
                            <button
                              type="button"
                              onClick={() => setWithdrawMethod('Orange Money')}
                              className="font-black underline ml-2 hover:text-white"
                            >
                              Basculer sur Orange
                            </button>
                          </div>
                        );
                      }
                      if (detected === 'MTN' && withdrawMethod !== 'MTN MoMo') {
                        return (
                          <div className="mt-2 p-2 rounded-lg bg-yellow-500/10 border border-yellow-500/20 flex items-center justify-between text-[11px] text-yellow-300">
                            <span>Numéro identifié comme <b>MTN MoMo</b></span>
                            <button
                              type="button"
                              onClick={() => setWithdrawMethod('MTN MoMo')}
                              className="font-black underline ml-2 hover:text-white"
                            >
                              Basculer sur MTN
                            </button>
                          </div>
                        );
                      }
                      return null;
                    })()}
                  </div>

                  {/* Summary Card */}
                  {(() => {
                    const num = parseFloat(withdrawAmount.replace(/\D/g, '')) || 0;
                    return (
                      <div className="p-4 rounded-2xl bg-white/[0.03] border border-white/8 space-y-2.5">
                        <div className="flex justify-between items-center text-xs">
                          <span className="text-slate-400 font-medium">Montant à transférer</span>
                          <span className="text-white font-bold">{formatGNF(num)}</span>
                        </div>
                        <div className="flex justify-between items-center text-xs">
                          <span className="text-slate-400 font-medium">Frais de virement</span>
                          <span className="text-emerald-400 font-bold">0 GNF (Offerts)</span>
                        </div>
                        <div className="flex justify-between items-center text-xs border-t border-white/5 pt-2">
                          <span className="text-slate-400 font-medium">Solde restant estimé</span>
                          <span className="text-slate-300 font-bold">{formatGNF(Math.max(0, balance - num))}</span>
                        </div>
                        <div className="flex items-center gap-1.5 text-[11px] text-slate-400 pt-1">
                          <Clock className="w-3.5 h-3.5 text-orange-400 shrink-0" />
                          <span>Délai habituel : <b>5 à 15 minutes</b> (Direct Mobile Money)</span>
                        </div>
                      </div>
                    );
                  })()}

                  {/* Unverified store alert banner */}
                  {type === 'vendor' && !effectiveVerified && (
                    <div className="p-3.5 rounded-2xl bg-amber-500/10 border border-amber-500/20 flex items-start gap-3">
                      <AlertCircle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                      <div className="text-xs text-amber-300">
                        <p className="font-bold">Boutique en attente de vérification</p>
                        <p className="text-[11px] text-amber-400/80 mt-0.5 leading-relaxed">
                          Votre boutique doit être validée par les administrateurs avant que les retraits puissent être exécutés.
                        </p>
                      </div>
                    </div>
                  )}

                  {/* Non-owner alert banner */}
                  {type === 'vendor' && !isStoreOwner && (
                    <div className="p-3.5 rounded-2xl bg-amber-500/10 border border-amber-500/20 flex items-start gap-3">
                      <AlertCircle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                      <div className="text-xs text-amber-300">
                        <p className="font-bold">Accès restreint aux retraits</p>
                        <p className="text-[11px] text-amber-400/80 mt-0.5 leading-relaxed">
                          Seul le compte propriétaire de la boutique peut initier des retraits de trésorerie.
                        </p>
                      </div>
                    </div>
                  )}

                  {/* Submit CTA */}
                  {(() => {
                    const num = parseFloat(withdrawAmount.replace(/\D/g, '')) || 0;
                    const isValidAmount = num >= WITHDRAWAL_MIN[type] && num <= balance;
                    const isValidPhone = isValidGuineanPhone(withdrawPhone);
                    const canSubmit = isValidAmount && isValidPhone && !isRequesting && Boolean(id) && (type !== 'vendor' || (effectiveVerified && isStoreOwner));

                    return (
                      <button
                        type="button"
                        onClick={handleWithdrawSubmit}
                        disabled={!canSubmit}
                        className={`w-full min-h-[56px] rounded-2xl text-xs font-black uppercase tracking-widest transition-all flex items-center justify-center gap-2 active:scale-[0.98] ${
                          canSubmit
                            ? 'bg-gradient-to-r from-orange-500 to-amber-500 text-white shadow-xl shadow-orange-500/25 hover:from-orange-400 hover:to-amber-400 cursor-pointer'
                            : 'bg-white/5 text-slate-500 border border-white/10 cursor-not-allowed opacity-60'
                        }`}
                      >
                        {isRequesting ? (
                          <><Loader2 className="w-4 h-4 animate-spin text-white" /> Envoi de la demande…</>
                        ) : !id ? (
                          'Boutique non trouvée'
                        ) : type === 'vendor' && !effectiveVerified ? (
                          'Validation requise pour retirer'
                        ) : type === 'vendor' && !isStoreOwner ? (
                          'Réservé au propriétaire'
                        ) : balance < WITHDRAWAL_MIN[type] ? (
                          `Solde insuffisant (< ${WITHDRAWAL_MIN[type].toLocaleString('fr-FR')} GNF)`
                        ) : num > balance ? (
                          'Montant supérieur au solde disponible'
                        ) : num > 0 && num < WITHDRAWAL_MIN[type] ? (
                          `Minimum ${WITHDRAWAL_MIN[type].toLocaleString('fr-FR')} GNF`
                        ) : (
                          <>
                            <ArrowUpRight className="w-4 h-4" />
                            Exécuter le retrait {num > 0 ? `(${formatGNF(num)})` : ''}
                          </>
                        )}
                      </button>
                    );
                  })()}

                  <p className="flex items-center justify-center gap-1.5 text-slate-500 text-[11px] text-center">
                    <ShieldCheck className="w-3.5 h-3.5 text-emerald-500 shrink-0" />
                    Transaction sécurisée et vérifiée par FATIBARA
                  </p>
                </div>
              </motion.div>
            </div>
          </>
        )}
      </AnimatePresence>

      {/* ── Hero Balance Card ─────────────────────────────────────────────── */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-[#1a0a00] via-[#100800] to-[#0a0a12] border border-orange-500/20 shadow-2xl mb-5">
        <div className="absolute top-0 left-1/4 w-72 h-72 bg-orange-500/15 rounded-full blur-[80px] pointer-events-none" />
        <div className="absolute bottom-0 right-0 w-56 h-56 bg-orange-600/10 rounded-full blur-[60px] pointer-events-none" />

        <div className="relative z-10 p-6 md:p-8">
          {/* Label row */}
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 bg-orange-500/20 rounded-xl flex items-center justify-center border border-orange-500/30">
                <Wallet className="w-4 h-4 text-orange-400" />
              </div>
              <span className="text-slate-300 text-sm font-medium">{walletLabel(type)}</span>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={() => {
                  if (typeof (window as any).auditWallet === 'function') {
                    (window as any).auditWallet(type, id);
                    showToast("Audit du portefeuille exécuté (voir Console F12)", "info");
                  }
                }}
                title="Inspecter le livre comptable dans la console"
                className="flex items-center gap-1.5 px-3 py-1.5 bg-orange-500/10 hover:bg-orange-500/20 border border-orange-500/30 rounded-full text-orange-400 hover:text-orange-300 text-[11px] font-semibold transition-all active:scale-95"
              >
                <ReceiptText className="w-3.5 h-3.5" />
                <span>Auditer</span>
              </button>
              <div className="flex items-center gap-2 px-3 py-1.5 bg-emerald-500/10 border border-emerald-500/20 rounded-full">
                <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                <span className="text-emerald-400 text-[11px] font-semibold">En direct</span>
              </div>
            </div>
          </div>

          {/* Balance */}
          {loading ? (
            <div className="mb-6 space-y-3">
              <Sk className="h-12 w-52" />
              <Sk className="h-5 w-28" />
            </div>
          ) : (
            <div className="mb-6">
              <div className="flex items-start gap-3">
                <div className="flex-1">
                  <p className="text-slate-400 text-xs font-medium mb-1 uppercase tracking-widest">Solde disponible</p>
                  <h2 className="text-4xl md:text-5xl font-black tracking-tight leading-none tabular-nums text-white">
                    {showBalance
                      ? formatGNF(balance)
                      : <span className="blur-sm select-none text-slate-600">██████ GNF</span>
                    }
                  </h2>
                </div>
                <button
                  onClick={() => setShowBalance(p => !p)}
                  className="mt-1 w-10 h-10 flex items-center justify-center rounded-xl bg-white/8 border border-white/12 hover:bg-white/15 text-slate-400 hover:text-white transition-all active:scale-90"
                  aria-label={showBalance ? 'Masquer le solde' : 'Afficher le solde'}
                >
                  {showBalance ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>

              {lockedAmount > 0 && (
                <div className="mt-3 inline-flex items-center gap-2 px-3.5 py-1.5 rounded-xl bg-amber-500/10 border border-amber-500/20 text-amber-300 text-xs font-medium">
                  <Clock className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                  <span>En cours de virement : <strong className="font-black text-amber-200">{formatGNF(lockedAmount)}</strong></span>
                </div>
              )}
            </div>
          )}

          {/* Pending deposit notice — shown when balance=0 but deposits are pending */}
          {!loading && balance === 0 && transactions.some(tx => tx.type === 'deposit' && tx.status === 'pending') && (
            <div className="mb-5 flex items-start gap-3 px-4 py-3.5 rounded-2xl bg-amber-500/10 border border-amber-500/25">
              <div className="shrink-0 w-7 h-7 rounded-xl bg-amber-500/20 flex items-center justify-center mt-0.5">
                <Smartphone className="w-3.5 h-3.5 text-amber-400" />
              </div>
              <div>
                <p className="text-amber-300 text-xs font-bold leading-tight">Recharge en attente</p>
                <p className="text-amber-400/70 text-[11px] mt-0.5 leading-snug">
                  Votre paiement Mobile Money est en cours de traitement.
                  Votre solde sera mis à jour automatiquement à la confirmation.
                </p>
              </div>
            </div>
          )}

          {/* CTA Buttons */}
          <div className="flex gap-3">
            <button
              onClick={() => setShowTopUpSheet(true)}
              className="flex-1 min-h-[52px] flex items-center justify-center gap-2 bg-orange-500 hover:bg-orange-600 active:scale-95 text-white font-bold text-sm rounded-2xl shadow-lg shadow-orange-500/30 transition-all"
            >
              <Zap className="w-4 h-4" />
              Recharger
            </button>
            {canWithdraw && (
              type === 'vendor' && isVerified === false ? (
                // H-1: Unverified vendor — show explanation instead of silently failing
                <div className="flex-1 min-h-[52px] flex items-center justify-center gap-2 border border-amber-500/30 bg-amber-500/10 rounded-2xl px-3 text-center">
                  <span className="text-amber-400 text-[11px] font-semibold leading-tight">
                    Retraits disponibles après validation de votre boutique
                  </span>
                </div>
              ) : (
                <button
                  onClick={openWithdrawSheet}
                  className="flex-1 min-h-[52px] flex items-center justify-center gap-2 border-2 border-white/15 bg-white/5 hover:bg-white/10 active:scale-95 text-white font-semibold text-sm rounded-2xl transition-all"
                >
                  <ArrowDownRight className="w-4 h-4" />
                  Retirer
                </button>
              )
            )}
          </div>
        </div>
      </div>

      {/* ── Desktop Ledger (full width on desktop, no sidebar form) ────────── */}
      <div className="hidden md:block mb-5">
        <TransactionLedger loading={loading} transactions={transactions} onVerify={handleVerifyPayment} verifyingTxId={verifyingTxId} pollCountdown={pollCountdown} />
        {canWithdraw && <div className="mt-5"><WithdrawalPanel loading={loading} withdrawals={withdrawals} /></div>}
      </div>

      {/* ── Mobile ledger panel (tabs) ────────────────────────────────────── */}
      <div className="md:hidden">
        {canWithdraw ? (
          <>
            <div className="flex bg-slate-900/80 border border-white/8 rounded-2xl p-1 mb-4">
              {(['history', 'withdrawals'] as const).map(tab => (
                <button
                  key={tab}
                  onClick={() => setActivePanel(tab)}
                  className={`flex-1 min-h-[44px] rounded-xl text-xs font-semibold transition-all flex items-center justify-center gap-1.5 ${
                    activePanel === tab
                      ? 'bg-orange-500 text-white shadow-sm'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  {tab === 'history'
                    ? <><History className="w-3.5 h-3.5" /> Transactions</>
                    : <><Send className="w-3.5 h-3.5" /> Retraits</>}
                </button>
              ))}
            </div>
            {activePanel === 'history'
              ? <TransactionLedger loading={loading} transactions={transactions} onVerify={handleVerifyPayment} verifyingTxId={verifyingTxId} pollCountdown={pollCountdown} />
              : <WithdrawalPanel loading={loading} withdrawals={withdrawals} />}
          </>
        ) : (
          <TransactionLedger loading={loading} transactions={transactions} onVerify={handleVerifyPayment} verifyingTxId={verifyingTxId} pollCountdown={pollCountdown} />
        )}
      </div>

      {/* ── Sticky Mobile Bottom Bar ──────────────────────────────────────── */}
      <div className="fixed bottom-0 left-0 right-0 z-50 md:hidden">
        <div className="bg-[#0d0d0d]/95 backdrop-blur-xl border-t border-white/10 px-4 py-3 pb-safe">
          <div className="flex gap-3 max-w-lg mx-auto">
            <button
              onClick={() => setShowTopUpSheet(true)}
              className="flex-1 min-h-[52px] flex items-center justify-center gap-2 bg-orange-500 hover:bg-orange-600 active:scale-95 text-white font-bold text-sm rounded-2xl shadow-lg shadow-orange-500/30 transition-all"
            >
              <Zap className="w-4 h-4" /> Recharger
            </button>
            {canWithdraw && (
              <button
                onClick={openWithdrawSheet}
                className="min-h-[52px] px-5 flex items-center justify-center gap-2 border border-white/15 bg-white/5 hover:bg-white/10 active:scale-95 text-white font-semibold text-sm rounded-2xl transition-all"
              >
                <ArrowDownRight className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── Extracted: Transaction Ledger ────────────────────────────────────────────
function TransactionLedger({ loading, transactions, onVerify, verifyingTxId, pollCountdown }: {
  loading: boolean;
  transactions: any[];
  onVerify: (tx: any) => void;
  verifyingTxId: string | null;
  pollCountdown: number;
}) {
  return (
    <div className="bg-[#0d0d0d] border border-white/8 rounded-3xl p-6 overflow-hidden">
      <div className="flex items-center justify-between mb-5">
        <h3 className="text-sm font-bold text-slate-200 flex items-center gap-2">
          <History className="w-4 h-4 text-orange-400" />
          Historique des transactions
        </h3>
        <div className="flex items-center gap-1.5 px-2.5 py-1 bg-emerald-500/10 border border-emerald-500/20 rounded-full">
          <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
          <span className="text-emerald-400 text-[10px] font-semibold">En direct</span>
        </div>
      </div>
      <div className="space-y-2">
        {loading ? (
          Array.from({ length: 4 }).map((_, i) => (
            <div key={i} className="flex items-center gap-3 p-3.5 rounded-2xl bg-white/[0.02]">
              <Sk className="w-10 h-10 shrink-0" />
              <div className="flex-1 space-y-2"><Sk className="h-3 w-3/4" /><Sk className="h-2.5 w-1/2" /></div>
              <Sk className="h-4 w-20" />
            </div>
          ))
        ) : transactions.length > 0 ? (
          transactions.map((tx, i) => {
            const isCredit     = Number(tx.amount) > 0;
            const isPending    = tx.status === 'pending';
            const isCancelled  = tx.status === 'cancelled';
            const isFailed     = tx.status === 'failed';
            const isResolved   = isFailed || isCancelled;
            const isBoost      = tx.type === 'boost';
            return (
              <motion.div
                key={tx.id || i}
                initial={{ opacity: 0, x: -8 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: i * 0.03 }}
                className="flex items-center justify-between p-3.5 bg-white/[0.025] border border-white/[0.06] rounded-2xl hover:border-white/10 transition-all"
              >
                <div className={`w-10 h-10 shrink-0 rounded-xl flex items-center justify-center ${
                  isResolved ? 'bg-red-500/10 text-red-400' :
                  isPending  ? 'bg-amber-500/10 text-amber-400' :
                  isBoost    ? 'bg-[#ff6600]/15 text-[#ff6600]' :
                  isCredit   ? 'bg-emerald-500/10 text-emerald-400'
                             : 'bg-rose-500/10 text-rose-400'
                }`}>
                  {isResolved  ? <AlertCircle className="w-5 h-5" /> :
                   isPending   ? <Loader2 className="w-5 h-5 animate-spin" /> :
                   isBoost     ? <Sparkles className="w-5 h-5 text-[#ff6600]" /> :
                   isCredit    ? <ArrowUpRight className="w-5 h-5" />
                               : <ArrowDownRight className="w-5 h-5" />}
                </div>
                <div className="flex-1 min-w-0 mx-3">
                  <p className="text-slate-200 text-sm font-semibold truncate">{txTypeLabel(tx)}</p>
                  <div className="flex items-center gap-2 mt-0.5 flex-wrap">
                    <span className="text-slate-500 text-xs">{relativeDate(tx.created_at)}</span>

                    {/* ─ Pending: badge + tooltip + verify button + countdown ─ */}
                    {isPending && (
                      <>
                        {/* Badge with tooltip */}
                        <span className="group relative flex items-center gap-1 px-2 py-0.5 rounded-full bg-amber-500/10 border border-amber-500/20 text-amber-400 text-[10px] font-bold animate-pulse cursor-help">
                          <Smartphone className="w-2.5 h-2.5" />
                          Confirmation requise
                          {/* Tooltip */}
                          <span className="pointer-events-none absolute bottom-full left-1/2 -translate-x-1/2 mb-2 w-56 p-2 rounded-xl bg-[#1a1a1a] border border-white/10 text-slate-300 text-[10px] font-normal leading-relaxed opacity-0 group-hover:opacity-100 transition-opacity z-50 shadow-xl">
                            Vérifiez votre téléphone et entrez votre code secret <strong>Orange Money</strong> ou <strong>MTN MoMo</strong> pour valider le paiement.
                          </span>
                        </span>

                        {/* Verify button */}
                        <button
                          onClick={() => onVerify(tx)}
                          disabled={!!verifyingTxId}
                          className="flex items-center gap-1 px-2 py-0.5 rounded-full bg-orange-500/10 border border-orange-500/30 text-orange-400 text-[10px] font-bold hover:bg-orange-500/20 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
                        >
                          {verifyingTxId === tx.id ? (
                            <Loader2 className="w-2.5 h-2.5 animate-spin" />
                          ) : (
                            <RefreshCw className="w-2.5 h-2.5" />
                          )}
                          Vérifier
                        </button>

                        {/* Auto-poll countdown */}
                        <span className="text-slate-600 text-[10px] tabular-nums">
                          Vérif auto dans {pollCountdown}s
                        </span>
                      </>
                    )}

                    {/* ─ Cancelled badge ─ */}
                    {isCancelled && (
                      <span className="px-2 py-0.5 rounded-full bg-red-500/10 border border-red-500/20 text-red-400 text-[10px] font-bold">
                        Annulée
                      </span>
                    )}

                    {/* ─ Failed badge ─ */}
                    {isFailed && (
                      <span className="px-2 py-0.5 rounded-full bg-red-500/10 border border-red-500/20 text-red-400 text-[10px] font-bold">
                        Échouée
                      </span>
                    )}
                  </div>
                </div>

                {/* ─ Amount column ─ */}
                <div className={`text-sm font-black tabular-nums shrink-0 ${
                  isResolved ? 'text-slate-600' :
                  isPending  ? 'text-amber-400' :
                  isCredit   ? 'text-emerald-400'
                             : 'text-rose-400'
                }`}>
                  {isResolved
                    ? <span className="text-slate-600 font-semibold">— GNF</span>
                    : <>{isCredit ? '+' : ''}{formatGNF(Math.abs(Number(tx.amount)))}</>}
                </div>
              </motion.div>
            );
          })
        ) : (
          <div className="py-12 flex flex-col items-center gap-4 text-center">
            <div className="w-14 h-14 rounded-2xl bg-white/[0.04] border border-white/8 flex items-center justify-center text-slate-600">
              <ReceiptText className="w-6 h-6" />
            </div>
            <div>
              <p className="text-slate-300 font-semibold text-sm">Aucune transaction</p>
              <p className="text-slate-600 text-xs mt-1 max-w-[200px] mx-auto leading-relaxed">
                Vos dépôts et achats apparaîtront ici.
              </p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

// ─── Extracted: Withdrawal Panel ──────────────────────────────────────────────
function WithdrawalPanel({ loading, withdrawals }: { loading: boolean; withdrawals: any[] }) {
  return (
    <div className="bg-[#0d0d0d] border border-white/8 rounded-3xl p-6 overflow-hidden">
      <h3 className="text-sm font-bold text-slate-200 flex items-center gap-2 mb-5">
        <TrendingUp className="w-4 h-4 text-orange-400" />
        Demandes de retrait
      </h3>
      <div className="space-y-3">
        {loading ? (
          Array.from({ length: 2 }).map((_, i) => (
            <div key={i} className="p-4 rounded-2xl bg-white/[0.02] space-y-3">
              <div className="flex justify-between"><Sk className="h-5 w-28" /><Sk className="h-5 w-20 rounded-full" /></div>
              <div className="flex justify-between"><Sk className="h-4 w-24" /><Sk className="h-6 w-28" /></div>
            </div>
          ))
        ) : withdrawals.length > 0 ? (
          withdrawals.map((w, i) => (
            <div key={w.id || i} className="flex items-center gap-3 p-4 bg-white/[0.025] border border-white/[0.06] rounded-2xl hover:border-white/10 transition-all">
              <div className="w-10 h-10 shrink-0 bg-orange-500/10 rounded-xl flex items-center justify-center">
                <Smartphone className="w-4 h-4 text-orange-400" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-slate-200 text-sm font-semibold truncate">{methodBadge(w.method) || w.method}</p>
                <p className="text-slate-500 text-xs mt-0.5 truncate">{w.phone || w.phone_number || '—'}</p>
              </div>
              <div className="text-right shrink-0">
                <p className="text-white font-black text-sm tabular-nums">{formatGNF(Number(w.amount))}</p>
                <span className={`mt-1 inline-block px-2.5 py-0.5 rounded-full text-[10px] font-bold border ${
                  w.status === 'processed'
                    ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20'
                    : w.status === 'rejected'
                    ? 'bg-red-500/10 text-red-400 border-red-500/20'
                    : 'bg-amber-500/10 text-amber-400 border-amber-500/20 animate-pulse'
                }`}>
                  {w.status === 'processed' ? '✓ Confirmé' : w.status === 'rejected' ? '✗ Rejeté' : 'En attente'}
                </span>
              </div>
            </div>
          ))
        ) : (
          <div className="py-10 flex flex-col items-center gap-3 text-center">
            <div className="w-12 h-12 rounded-2xl bg-white/[0.04] border border-white/8 flex items-center justify-center text-slate-600">
              <Send className="w-5 h-5" />
            </div>
            <div>
              <p className="text-slate-300 font-semibold text-sm">Aucune demande</p>
              <p className="text-slate-600 text-xs mt-1">Vos retraits apparaîtront ici.</p>
            </div>
          </div>
        )}
      </div>
      <div className="mt-4 bg-orange-500/5 border border-orange-500/10 p-4 rounded-2xl flex items-start gap-3">
        <Info className="w-4 h-4 text-orange-400 shrink-0 mt-0.5" />
        <p className="text-slate-500 text-xs leading-relaxed">
          Délai de traitement : <span className="text-slate-300 font-semibold">24h à 72h</span> après validation.
        </p>
      </div>
    </div>
  );
}
