import React, { useState, useEffect } from 'react';
import { useAppContext, SavedAddress } from '../context/AppContext';
import { supabase } from '../lib/supabase';
import { MapPin, Phone, Edit2, Loader2, CheckCircle } from 'lucide-react';
import { useToast } from '../context/ToastContext';
import { GUINEA_LOCATIONS, ALL_REGIONS } from '../constants/locations';
import AppSelect from './ui/AppSelect';
import FormField from './ui/FormField';

export default function AddressManager() {
  const { user, savedAddress, setSavedAddress } = useAppContext();
  const { showToast } = useToast();
  const [isEditing, setIsEditing] = useState(false);
  const [saving, setSaving] = useState(false);
  const [addressErrors, setAddressErrors] = useState<{ quartier?: string, phone?: string }>({});
  
  const [region, setRegion] = useState(savedAddress?.region || 'Conakry');
  const [commune, setCommune] = useState(savedAddress?.commune || 'Ratoma');
  const [quartier, setQuartier] = useState(savedAddress?.quartier || '');
  const [indications, setIndications] = useState(savedAddress?.indications || '');
  const [phone, setPhone] = useState(savedAddress?.phone || '');

  const availableCommunes = GUINEA_LOCATIONS[region as keyof typeof GUINEA_LOCATIONS] || [];

  const handleRegionChange = (newRegion: string) => {
    setRegion(newRegion);
    const communes = GUINEA_LOCATIONS[newRegion as keyof typeof GUINEA_LOCATIONS] || [];
    setCommune(communes[0] || '');
  };

  // Update local state if context updates
  useEffect(() => {
    if (savedAddress && !isEditing) {
      setRegion(savedAddress.region);
      setCommune(savedAddress.commune);
      setQuartier(savedAddress.quartier);
      setIndications(savedAddress.indications);
      setPhone(savedAddress.phone);
    }
  }, [savedAddress, isEditing]);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;
    
    let hasError = false;
    const errors: any = {};
    if (!quartier || quartier.trim().length < 3) {
      errors.quartier = "Veuillez préciser le quartier (min. 3 caractères).";
      hasError = true;
    }
    if (!phone || phone.replace(/\D/g, '').length < 9) {
      errors.phone = "Numéro de téléphone invalide (min. 9 chiffres).";
      hasError = true;
    }
    
    if (hasError) {
      setAddressErrors(errors);
      showToast("Veuillez remplir correctement l'adresse", 'warning');
      return;
    }
    setAddressErrors({});
    
    setSaving(true);
    const newAddress: SavedAddress = {
      region,
      commune,
      quartier,
      indications,
      phone
    };

    try {
      const { error } = await supabase
        .from('profiles')
        .update({ saved_address: newAddress })
        .eq('id', user.id);

      if (error) throw error;
      
      setSavedAddress(newAddress);
      setIsEditing(false);
      showToast("Adresse enregistrée avec succès", 'success');
    } catch (err: any) {
      showToast("Erreur lors de la sauvegarde: " + err.message, 'error');
    } finally {
      setSaving(false);
    }
  };

  if (!isEditing && savedAddress) {
    return (
      <div className="bg-white dark:bg-gray-900 border border-brand-border/30 dark:border-white/5 p-8 rounded-[2.5rem] shadow-sm max-w-2xl">
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 bg-emerald-50 dark:bg-emerald-950/20 rounded-2xl flex items-center justify-center border border-emerald-100 dark:border-emerald-900/30">
              <CheckCircle className="w-7 h-7 text-emerald-700 dark:text-emerald-400" />
            </div>
            <div>
              <h2 className="text-xl font-bold text-gray-900 dark:text-white uppercase tracking-tight">Adresse configurée</h2>
              <p className="text-[11px] font-bold tracking-wider text-brand-text-dim dark:text-gray-400 mt-1">Prête pour le paiement en un clic</p>
            </div>
          </div>
          <button 
            onClick={() => setIsEditing(true)}
            className="p-4 bg-gray-50 dark:bg-gray-800 hover:bg-gray-100 dark:hover:bg-[#ff6600] hover:text-white rounded-2xl transition-all text-gray-900 dark:text-white border border-brand-border/20 dark:border-white/5 shadow-sm min-h-[44px]"
          >
            <Edit2 className="w-5 h-5" />
          </button>
        </div>

        <div className="space-y-4">
          <div className="flex gap-4 p-5 bg-gray-50 dark:bg-black/20 rounded-3xl border border-brand-border/10 dark:border-white/5">
            <MapPin className="w-5 h-5 text-[#ff6600] dark:text-orange-400 shrink-0 mt-0.5" />
            <div>
              <p className="font-bold text-gray-900 dark:text-white uppercase tracking-tight">{savedAddress.quartier}, {savedAddress.commune}</p>
              <p className="text-[11px] font-bold text-brand-text-dim dark:text-gray-400 tracking-wider mt-1">{savedAddress.region}</p>
              {savedAddress.indications && (
                <p className="text-sm text-brand-text-dim dark:text-gray-400 mt-3 italic bg-white/50 dark:bg-white/5 p-3 rounded-xl border border-brand-border/5 dark:border-white/5">"{savedAddress.indications}"</p>
              )}
            </div>
          </div>
          <div className="flex gap-4 p-5 bg-gray-50 dark:bg-black/20 rounded-3xl border border-brand-border/10 dark:border-white/5 items-center">
            <Phone className="w-5 h-5 text-[#ff6600] dark:text-orange-400 shrink-0" />
            <p className="font-bold text-gray-900 dark:text-white tracking-wider">{savedAddress.phone || 'Non renseigné'}</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white dark:bg-gray-900 border border-brand-border/30 dark:border-white/5 p-8 md:p-12 shadow-sm rounded-[3rem] max-w-2xl">
      <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-2 uppercase tracking-tighter">Mon adresse de livraison</h2>
      <p className="text-brand-text-dim dark:text-gray-400 text-[13px] font-bold tracking-wider mb-10 leading-relaxed">Gagnez du temps lors de vos commandes en enregistrant votre adresse par défaut.</p>
      
      <form onSubmit={handleSave} className="space-y-8">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Région */}
          <FormField label="Région Administrative" icon={<MapPin className="w-4 h-4" />}>
            <AppSelect
              value={region}
              onChange={handleRegionChange}
              icon={<MapPin className="w-4 h-4" />}
              options={ALL_REGIONS.map(r => ({ value: r, label: r }))}
            />
          </FormField>

          {/* Commune */}
          <FormField label="Préfecture / Commune" icon={<MapPin className="w-4 h-4" />}>
            <AppSelect
              value={commune}
              onChange={setCommune}
              icon={<MapPin className="w-4 h-4" />}
              options={availableCommunes.map(c => ({ value: c, label: c }))}
            />
          </FormField>
        </div>

        {/* Quartier */}
        <FormField
          label="Quartier exact"
          error={addressErrors.quartier}
          required
        >
          <input
            type="text"
            value={quartier}
            onChange={(e) => { setQuartier(e.target.value); if(addressErrors.quartier) setAddressErrors({...addressErrors, quartier: undefined}); }}
            placeholder="Ex: Kipé Centre Émetteur"
            className={`form-input uppercase tracking-tight ${addressErrors.quartier ? 'is-error' : ''}`}
          />
        </FormField>

        {/* Phone */}
        <FormField
          label="Numéro de téléphone direct"
          error={addressErrors.phone}
          required
          icon={<Phone className="w-4 h-4" />}
        >
          <input
            type="tel"
            value={phone}
            onChange={(e) => { setPhone(e.target.value); if(addressErrors.phone) setAddressErrors({...addressErrors, phone: undefined}); }}
            placeholder="Ex: 620 00 00 00"
            className={`form-input ${addressErrors.phone ? 'is-error' : ''}`}
          />
        </FormField>

        {/* Indications */}
        <FormField label="Indications de livraison (Optionnel)">
          <textarea
            value={indications}
            onChange={(e) => setIndications(e.target.value)}
            placeholder="Ex: Portail bleu à côté de la pharmacie..."
            className="form-textarea uppercase tracking-tight"
          />
        </FormField>

        <div className="pt-6 flex flex-col sm:flex-row gap-4">
          {savedAddress && (
            <button
              type="button"
              onClick={() => setIsEditing(false)}
              className="flex-1 px-8 py-5 border border-brand-border/30 dark:border-white/10 text-[12px] font-bold tracking-wider text-gray-900 dark:text-white hover:bg-gray-50 dark:hover:bg-white/5 transition-all rounded-full min-h-[52px]"
            >
              Annuler
            </button>
          )}
          <button
            type="submit"
            disabled={saving}
            className="flex-[2] bg-gray-900 dark:bg-[#ff6600] text-white py-5 text-[12px] font-bold tracking-wider hover:bg-black dark:hover:bg-[#e65c00] transition-all disabled:opacity-70 rounded-full flex items-center justify-center gap-3 shadow-xl min-h-[52px]"
          >
            {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : null}
            <span>{saving ? 'SAUVEGARDE EN COURS...' : 'ENREGISTRER MON ADRESSE'}</span>
          </button>
        </div>
      </form>
    </div>
  );
}
