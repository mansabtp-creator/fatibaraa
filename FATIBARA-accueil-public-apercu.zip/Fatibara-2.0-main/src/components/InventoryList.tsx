import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Package, Edit, BarChart3, AlertTriangle, Clock, Trash2, Zap, Plus, Download, Minus, Loader2 } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { useToast } from '../context/ToastContext';
import { APP_NAME } from '../lib/constants';
import QuickAddProductWizard from './QuickAddProductWizard';
import { thumbUrl } from '../utils/imageUtils';

// Helper to check stock status
const getStockStatus = (quantity: number, threshold: number) => {
  if (quantity === 0) return { label: 'Épuisé', color: 'text-red-600', bg: 'bg-red-500' };
  if (quantity <= threshold) return { label: 'Stock Critique', color: 'text-orange-600', bg: 'bg-orange-500' };
  return { label: 'Stock OK', color: 'text-green-600', bg: 'bg-green-500' };
};

interface InventoryListProps {
  products: any[];
  searchQuery: string;
  onEditProduct: (product: any) => void;
  pendingEdits: Record<string, any>;
  setProducts: React.Dispatch<React.SetStateAction<any[]>>;
  setIsAddingProduct: () => void;
  /** Store ID needed for the QuickAddProductWizard image upload */
  storeId?: string;
}

const InventoryRow = React.memo(({ 
  product, 
  idx, 
  threshold, 
  qte, 
  statusInfo, 
  isAlert, 
  hasVariants, 
  pendingEdits, 
  localStocks, 
  updatingStockId, 
  handleStockUpdate, 
  setLocalStocks, 
  showToast, 
  onEditProduct, 
  setConfirmConfig, 
  setProducts,
  products 
}: any) => {
  const currentQty = localStocks[product.id] !== undefined ? localStocks[product.id] : qte;
  const stepperColor = currentQty > 5 ? 'emerald' : currentQty >= 2 ? 'amber' : 'red';
  const stepperBg = stepperColor === 'emerald'
    ? 'bg-emerald-50 dark:bg-emerald-500/5 border-emerald-200/50 dark:border-emerald-500/10'
    : stepperColor === 'amber'
    ? 'bg-amber-50 dark:bg-amber-500/5 border-amber-200/50 dark:border-amber-500/10'
    : 'bg-red-50 dark:bg-red-500/5 border-red-200/50 dark:border-red-500/10';

  return (
    <motion.tr 
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ type: 'spring', stiffness: 200, damping: 22, delay: idx * 0.04 }}
      key={product.id} 
      className="group hover:bg-gray-50/60 dark:hover:bg-white/5 transition-all duration-300"
    >
      <td className="px-8 py-6">
        <div className="flex items-center gap-5">
          <div className="w-16 h-16 bg-gray-100 dark:bg-white/10 rounded-2xl overflow-hidden border border-gray-200/60 dark:border-white/5 flex-shrink-0 relative group/img cursor-pointer shadow-sm">
              <img src={thumbUrl(product.image_urls?.[0])} alt={product.title} className="w-full h-full object-cover transition-transform duration-700 group-hover/img:scale-110" />
              {pendingEdits[product.id] && (
                <div className="absolute top-1.5 right-1.5 w-3 h-3 bg-[#ff6600] rounded-full border-2 border-white dark:border-[#1A1D21] shadow-sm animate-pulse" title="Modifications locales" />
              )}
              <div className="absolute inset-0 bg-black/40 opacity-0 group-hover/img:opacity-100 transition-opacity flex items-center justify-center">
                <Plus className="w-5 h-5 text-white" />
              </div>
          </div>
          <div className="flex flex-col">
            <div className="flex items-center gap-3 mb-1.5">
              <span className="font-black text-[15px] text-gray-900 dark:text-white leading-none tracking-tight uppercase italic">{product?.title}</span>
              {isAlert && (
                <motion.span 
                   animate={{ scale: [1, 1.05, 1] }}
                   transition={{ repeat: Infinity, duration: 1.2 }}
                   className="bg-[#ff6600]/10 text-[#ff6600] text-[8px] font-black px-2.5 py-0.5 rounded-full border border-[#ff6600]/20 uppercase tracking-widest flex items-center gap-1"
                >
                   <Zap className="w-3 h-3 fill-current" /> ALERT
                </motion.span>
              )}
            </div>
            <div className="flex items-center gap-3">
               <span className="text-[10px] font-black text-[#ff6600] tracking-widest uppercase italic">{product.category || 'Standard'}</span>
               <span className="text-[9px] font-bold text-gray-400 tabular-nums uppercase">#{product?.id?.substring(0, 8) || 'NEW'}</span>
               {product.is_digital && (
                 <span className="flex items-center gap-1 bg-blue-500/10 text-blue-500 text-[8px] font-black px-2 py-0.5 rounded-full border border-blue-500/20 uppercase tracking-widest">
                   <Download className="w-2.5 h-2.5" /> Bitstream
                 </span>
               )}
            </div>
          </div>
        </div>
      </td>
      <td className="px-8 py-6">
        <div className="flex flex-col">
          <span className="text-[16px] font-black text-gray-900 dark:text-white tabular-nums tracking-tight">
            {(product.price_gnf || 0).toLocaleString()}
          </span>
          <span className="text-[9px] font-black text-gray-400 uppercase tracking-widest">GNF Currency</span>
        </div>
      </td>
      <td className="px-8 py-6">
        <div className="flex flex-col gap-2.5 w-48">
            <div className="flex justify-between items-center">
              <span className={`text-[9px] font-black uppercase tracking-widest ${statusInfo.color} decoration-current underline-offset-4`}>
                {statusInfo.label}
              </span>
              <span className="text-[10px] font-black text-gray-900 dark:text-white tabular-nums">
                {qte} <span className="text-[8px] text-gray-400 ml-0.5 font-bold">UNITÉS</span>
              </span>
            </div>
            
            {hasVariants ? (
              <>
                <div className="h-1.5 w-full bg-gray-100 dark:bg-white/5 rounded-full overflow-hidden border border-gray-100 dark:border-white/5 relative mb-1">
                  <motion.div 
                    initial={{ width: 0 }}
                    animate={{ width: `${Math.min((qte / Math.max(100, threshold * 4)) * 100, 100)}%` }}
                    className={`h-full absolute left-0 top-0 bottom-0 ${statusInfo.bg.includes('bg-red') ? 'bg-red-500' : statusInfo.bg.includes('bg-orange') ? 'bg-[#ff6600]' : 'bg-emerald-500'} transition-all`}
                  />
                </div>
                
                {/* Variant Breakdown for Vendors */}
                <div className="flex flex-wrap gap-1 mt-1">
                  {product.variations.slice(0, 4).map((v: any, i: number) => (
                    <span key={i} className="text-[7px] font-black px-1.5 py-0.5 bg-gray-50 dark:bg-white/5 border border-gray-100 dark:border-white/5 rounded text-gray-400 uppercase tracking-tighter">
                      {v.size || v.color}: {v.stock_count}
                    </span>
                  ))}
                  {product.variations.length > 4 && (
                    <span className="text-[7px] font-black px-1.5 py-0.5 bg-gray-50 text-gray-400 rounded">...</span>
                  )}
                </div>
              </>
            ) : (
              <div className={`flex items-center gap-1.5 ${stepperBg} rounded-xl p-1 shadow-inner w-full max-w-[150px]`}>
                <button
                  type="button"
                  onClick={() => {
                    const currentQty = localStocks[product.id] !== undefined ? localStocks[product.id] : qte;
                    handleStockUpdate(product.id, currentQty - 1);
                  }}
                  disabled={updatingStockId === product.id || (localStocks[product.id] !== undefined ? localStocks[product.id] : qte) <= 1}
                  className="w-7 h-7 bg-white dark:bg-gray-800 rounded-lg flex items-center justify-center border border-gray-200/40 dark:border-white/5 text-gray-500 hover:text-gray-900 dark:hover:text-white disabled:opacity-50 transition-all active:scale-90"
                >
                  <Minus className="w-3.5 h-3.5" />
                </button>
                
                <input
                  type="number"
                  min="1"
                  value={localStocks[product.id] !== undefined ? localStocks[product.id] : qte}
                  disabled={updatingStockId === product.id}
                  onChange={(e) => {
                    const val = parseInt(e.target.value);
                    setLocalStocks((prev: any) => ({ ...prev, [product.id]: isNaN(val) ? 0 : val }));
                  }}
                  onBlur={() => {
                    const val = localStocks[product.id] !== undefined ? localStocks[product.id] : qte;
                    if (val !== qte && val >= 1) {
                      handleStockUpdate(product.id, val, true);
                    } else if (val < 1) {
                      showToast("Le stock minimum doit être de 1", "warning");
                      setLocalStocks((prev: any) => { const next = {...prev}; delete next[product.id]; return next; });
                    }
                  }}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') {
                      const val = localStocks[product.id] !== undefined ? localStocks[product.id] : qte;
                      if (val !== qte && val >= 1) {
                        handleStockUpdate(product.id, val, true);
                      } else if (val < 1) {
                        showToast("Le stock minimum doit être de 1", "warning");
                        setLocalStocks((prev: any) => { const next = {...prev}; delete next[product.id]; return next; });
                      }
                    }
                  }}
                  className="w-10 bg-transparent text-center text-xs font-black text-gray-900 dark:text-white outline-none focus:ring-0 [appearance:textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none"
                />
                
                <button
                  type="button"
                  onClick={() => {
                    const currentQty = localStocks[product.id] !== undefined ? localStocks[product.id] : qte;
                    handleStockUpdate(product.id, currentQty + 1);
                  }}
                  disabled={updatingStockId === product.id}
                  className="w-7 h-7 bg-white dark:bg-gray-800 rounded-lg flex items-center justify-center border border-gray-200/40 dark:border-white/5 text-gray-500 hover:text-gray-900 dark:hover:text-white disabled:opacity-50 transition-all active:scale-90"
                >
                  {updatingStockId === product.id ? (
                    <Loader2 className="w-3.5 h-3.5 animate-spin text-[#ff6600]" />
                  ) : (
                    <Plus className="w-3.5 h-3.5" />
                  )}
                </button>
              </div>
            )}
        </div>
      </td>
      <td className="px-8 py-6">
        {product?.is_active ? (
          <div className="inline-flex items-center gap-2 px-3 py-1.5 bg-emerald-500/10 border border-emerald-500/20 rounded-full">
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" />
              <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500" />
            </span>
            <span className="text-[10px] font-black uppercase tracking-widest text-emerald-600 dark:text-emerald-400">En Ligne</span>
          </div>
        ) : (
          <div className="inline-flex items-center gap-2 px-3 py-1.5 bg-gray-100 dark:bg-white/5 border border-gray-200 dark:border-white/10 rounded-full">
            <span className="w-2 h-2 rounded-full bg-gray-400" />
            <span className="text-[10px] font-black uppercase tracking-widest text-gray-500">Hors Ligne</span>
          </div>
        )}
      </td>
      <td className="px-8 py-6 text-right">
        <div className="flex justify-end gap-2.5 transition-all duration-300">
          <button 
            className={`w-10 h-10 border rounded-xl flex items-center justify-center transition-all ${product.is_featured ? 'bg-[#ff6600]/10 border-[#ff6600]/30 text-[#ff6600]' : 'bg-white dark:bg-white/5 border-gray-100 dark:border-white/10 text-gray-400 hover:text-[#ff6600] hover:border-[#ff6600] hover:scale-105 active:scale-95 shadow-sm'}`} 
            title="Booster ce produit"
            onClick={async () => {
              const { error } = await supabase.from('products').update({ is_featured: !product.is_featured }).eq('id', product.id);
              if (!error) {
                setProducts(products.map((p: any) => p.id === product.id ? { ...p, is_featured: !p.is_featured } : p));
              }
            }}
          >
            <Zap className={`w-4 h-4 ${product.is_featured ? 'fill-current' : ''}`} />
          </button>
          <button 
            className="w-10 h-10 bg-white dark:bg-white/5 border border-gray-100 dark:border-white/10 text-gray-400 hover:text-[#ff6600] hover:border-[#ff6600] hover:scale-105 active:scale-95 rounded-xl flex items-center justify-center transition-all shadow-sm" 
            title="Modifier ce produit"
            onClick={() => onEditProduct(product)}
          >
            <Edit className="w-4 h-4" />
          </button>
          <button 
            className="w-10 h-10 bg-white dark:bg-white/5 border border-gray-100 dark:border-white/10 text-gray-400 hover:text-red-500 hover:border-red-500/20 hover:scale-105 active:scale-95 rounded-xl flex items-center justify-center transition-all shadow-sm" 
            title="Supprimer ce produit"
            onClick={() => setConfirmConfig({ isOpen: true, productId: product.id })}
          >
            <Trash2 className="w-4 h-4" />
          </button>
        </div>
      </td>
    </motion.tr>
  );
});

export default function InventoryList({ products, searchQuery, onEditProduct, pendingEdits, setProducts, setIsAddingProduct, storeId }: InventoryListProps) {
  const [confirmConfig, setConfirmConfig] = useState<{
    isOpen: boolean;
    productId: string | null;
  }>({ isOpen: false, productId: null });
  const [showWizard, setShowWizard] = useState(false);
  const { showToast } = useToast();

  const [localStocks, setLocalStocks] = useState<Record<string, number>>({});
  const [updatingStockId, setUpdatingStockId] = useState<string | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);
  const timeoutRefs = React.useRef<Record<string, any>>({});

  // Fix 10: clear all pending debounce timers on unmount to prevent memory leaks
  // and state updates on an unmounted component.
  useEffect(() => {
    return () => {
      Object.values(timeoutRefs.current).forEach(clearTimeout);
    };
  }, []);

  const performStockDbUpdate = async (productId: string, value: number) => {
    setUpdatingStockId(productId);
    try {
      const { error } = await supabase
        .from('products')
        .update({ stock_quantity: value })
        .eq('id', productId);

      if (error) throw error;
      
      setProducts(prev => prev.map(p => p.id === productId ? { ...p, stock_quantity: value } : p));
      showToast("Stock mis à jour avec succès", "success");
      setLocalStocks(prev => {
        const next = { ...prev };
        if (next[productId] === value) {
          delete next[productId];
        }
        return next;
      });
    } catch (err: any) {
      console.error("Error updating stock:", err);
      showToast(err.message || "Erreur de mise à jour du stock", "error");
    } finally {
      setUpdatingStockId(null);
    }
  };

  const handleStockUpdate = (productId: string, newStock: number, immediate = false) => {
    if (newStock < 1) {
      showToast("Le stock minimum doit être de 1", "warning");
      return;
    }

    setLocalStocks(prev => ({ ...prev, [productId]: newStock }));

    if (timeoutRefs.current[productId]) {
      clearTimeout(timeoutRefs.current[productId]);
    }

    if (immediate) {
      performStockDbUpdate(productId, newStock);
    } else {
      timeoutRefs.current[productId] = setTimeout(() => {
        performStockDbUpdate(productId, newStock);
      }, 600);
    }
  };

  const handleConfirmDelete = async () => {
    if (!confirmConfig.productId || isDeleting) return;
    setIsDeleting(true);
    try {
      const { error } = await supabase.from('products').delete().eq('id', confirmConfig.productId);
      if (error) throw error;
      setProducts(prev => prev.filter(p => p.id !== confirmConfig.productId));
      // Also clear any pending local stock state for this product
      setLocalStocks(prev => { const next = { ...prev }; delete next[confirmConfig.productId!]; return next; });
      showToast("Produit supprimé", "success");
      setConfirmConfig({ isOpen: false, productId: null });
    } catch {
      showToast("Erreur lors de la suppression. Veuillez réessayer.", "error");
      // Keep modal open so the vendor knows the delete failed
    } finally {
      setIsDeleting(false);
    }
  };

  const filteredProducts = products.filter(p => 
    (p?.title || '').toLowerCase().includes(searchQuery.toLowerCase()) || 
    (p?.category && p.category.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  if (products.length === 0) {
    return (
      <>
        <div className="bg-white dark:bg-gray-900 border border-brand-border/30 dark:border-white/10 p-20 text-center rounded-[3rem] shadow-sm">
          <div className="w-24 h-24 bg-gray-50 dark:bg-gray-800 rounded-[2.5rem] flex items-center justify-center mx-auto mb-8">
            <Package className="w-12 h-12 text-brand-text-dim dark:text-gray-400" />
          </div>
          <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">La boutique est vide</h3>
          <p className="text-brand-text-dim dark:text-gray-400 mb-10 max-w-sm mx-auto font-medium leading-relaxed">Vous n'avez pas encore de produits. Publiez votre premier article pour commencer à vendre en Guinée.</p>
          <button
            onClick={() => storeId ? setShowWizard(true) : setIsAddingProduct()}
            className="bg-[#ff6600] text-brand-inverse px-10 py-4 rounded-full font-bold tracking-wider text-[12px] shadow-xl shadow-[#ff6600]/20 transition-all hover:scale-105 active:scale-95 min-h-[52px]"
          >
            Ajouter mon premier article
          </button>
          <p className="mt-4 text-[11px] text-gray-400">
            Vous préférez le formulaire complet ?{' '}
            <button onClick={() => setIsAddingProduct()} className="underline hover:text-[#ff6600] transition-colors">Cliquer ici</button>
          </p>
        </div>

        {/* Quick-add wizard overlay */}
        {showWizard && storeId && (
          <QuickAddProductWizard
            storeId={storeId}
            onSuccess={(product) => {
              setProducts(prev => [product, ...prev]);
              setShowWizard(false);
            }}
            onClose={() => setShowWizard(false)}
          />
        )}
      </>
    );
  }

  return (
    <div className="bg-white dark:bg-[#1A1D21] rounded-[2.5rem] border border-gray-100 dark:border-white/5 overflow-hidden shadow-sm">
      <div className="hidden md:block overflow-x-auto custom-scrollbar">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="bg-gray-50/20 dark:bg-white/5">
              <th className="px-8 py-5 text-[10px] font-black uppercase tracking-[0.2em] text-gray-400 border-b border-gray-100 dark:border-white/5">Inventaire</th>
              <th className="px-8 py-5 text-[10px] font-black uppercase tracking-[0.2em] text-gray-400 border-b border-gray-100 dark:border-white/5">Tarification</th>
              <th className="px-8 py-5 text-[10px] font-black uppercase tracking-[0.2em] text-gray-400 border-b border-gray-100 dark:border-white/5">Volume Stock</th>
              <th className="px-8 py-5 text-[10px] font-black uppercase tracking-[0.2em] text-gray-400 border-b border-gray-100 dark:border-white/5">Logistique</th>
              <th className="px-8 py-5 text-[10px] font-black uppercase tracking-[0.2em] text-gray-400 border-b border-gray-100 dark:border-white/5 text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-50 dark:divide-white/5">
            {filteredProducts.map((product, idx) => {
              const threshold = product.low_stock_threshold || 5;
              const qte = product.stock_quantity || 0;
              const statusInfo = getStockStatus(qte, threshold);
              const isAlert = qte <= threshold && qte > 0;
              const hasVariants = product.variations && Array.isArray(product.variations) && product.variations.length > 0;
              
              return (
                <InventoryRow
                  key={product.id}
                  product={product}
                  idx={idx}
                  threshold={threshold}
                  qte={qte}
                  statusInfo={statusInfo}
                  isAlert={isAlert}
                  hasVariants={hasVariants}
                  pendingEdits={pendingEdits}
                  localStocks={localStocks}
                  updatingStockId={updatingStockId}
                  handleStockUpdate={handleStockUpdate}
                  setLocalStocks={setLocalStocks}
                  showToast={showToast}
                  onEditProduct={onEditProduct}
                  setConfirmConfig={setConfirmConfig}
                  setProducts={setProducts}
                  products={products}
                />
              );
            })}
          </tbody>
        </table>
      </div>
      
      {/* ── Mobile view — High-contrast glassmorphic product cards ── */}
      <div className="md:hidden flex flex-col gap-3 p-3">
        {filteredProducts.map((product) => {
          const threshold = product.low_stock_threshold || 5;
          const qte = product.stock_quantity || 0;
          const statusInfo = getStockStatus(qte, threshold);
          const isAlert = qte <= threshold && qte > 0;
          const isOut = qte === 0;
          
          const currentQty = localStocks[product.id] !== undefined ? localStocks[product.id] : qte;
          const stepperColor = currentQty > 5 ? 'emerald' : currentQty >= 2 ? 'amber' : 'red';
          const stepperBg = stepperColor === 'emerald'
            ? 'bg-emerald-50 dark:bg-emerald-500/5 border-emerald-200/50 dark:border-emerald-500/10'
            : stepperColor === 'amber'
            ? 'bg-amber-50 dark:bg-amber-500/5 border-amber-200/50 dark:border-amber-500/10'
            : 'bg-red-50 dark:bg-red-500/5 border-red-200/50 dark:border-red-500/10';

          return (
            <motion.div
              key={product.id}
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              className={`relative rounded-2xl border shadow-sm overflow-hidden ${
                isOut
                  ? 'bg-rose-50/80 dark:bg-rose-900/20 border-rose-200 dark:border-rose-500/30'
                  : isAlert
                  ? 'bg-orange-50/80 dark:bg-orange-900/20 border-orange-200 dark:border-orange-500/30'
                  : 'bg-white dark:bg-[#1A1D21] border-gray-100 dark:border-white/8'
              }`}
            >
              {/* Pending-edit indicator dot */}
              {pendingEdits[product.id] && (
                <div className="absolute top-3 right-3 w-2.5 h-2.5 bg-[#ff6600] rounded-full border-2 border-white dark:border-[#1A1D21] shadow-sm animate-pulse z-10" title="Modifications locales" />
              )}

              <div className="flex gap-3 p-4">
                {/* Product image */}
                <div className="w-[72px] h-[72px] rounded-xl overflow-hidden border border-gray-200/60 dark:border-white/8 flex-shrink-0 bg-gray-100 dark:bg-white/5">
                  <img
                    src={product.image_urls?.[0]}
                    alt={product.title}
                    className="w-full h-full object-cover"
                    onError={(e) => { (e.target as HTMLImageElement).style.display = 'none'; }}
                  />
                </div>

                {/* Info */}
                <div className="flex-1 min-w-0">
                  {/* Title + category */}
                  <p className="font-black text-[14px] text-gray-900 dark:text-white leading-tight truncate mb-1">
                    {product?.title}
                  </p>
                  <div className="flex items-center gap-2 mb-2">
                    <span className="text-[9px] font-black text-[#ff6600] bg-[#ff6600]/10 px-2 py-0.5 rounded-full uppercase tracking-widest border border-[#ff6600]/20 truncate max-w-[120px]">
                      {product.category || 'Standard'}
                    </span>
                    <span className={`text-[9px] font-black px-2 py-0.5 rounded-full uppercase tracking-widest ${
                      isOut
                        ? 'bg-rose-500/15 text-rose-600 dark:text-rose-400 border border-rose-500/20'
                        : isAlert
                        ? 'bg-orange-500/15 text-orange-600 dark:text-orange-400 border border-orange-500/20'
                        : 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/20'
                    }`}>
                      {isOut ? 'Épuisé' : isAlert ? `${qte} restant${qte > 1 ? 's' : ''}` : 'En stock'}
                    </span>
                  </div>

                  {/* Price */}
                  <p className="font-black text-[15px] text-gray-900 dark:text-white tabular-nums">
                    {(product.price_gnf || 0).toLocaleString('fr-FR')}{' '}
                    <span className="text-[9px] text-gray-400 font-bold">GNF</span>
                  </p>
                </div>
              </div>

              {/* Footer: stock stepper + action buttons */}
              <div className="flex items-center justify-between gap-3 px-4 py-3 border-t border-gray-100 dark:border-white/5">
                {/* Stock stepper */}
                <div className="flex-1">
                  {(() => {
                    const hasVariants = product.variations && Array.isArray(product.variations) && product.variations.length > 0;
                    return hasVariants ? (
                      <div className="flex items-center gap-2">
                        <span className={`text-[10px] font-black uppercase tracking-wider ${statusInfo.color}`}>
                          {statusInfo.label} ({qte})
                        </span>
                      </div>
                    ) : (
                      /* ── Inline quick-stock stepper ── */
                      <div className={`flex items-center gap-1.5 ${stepperBg} rounded-xl p-1 shadow-inner w-fit`}>
                        {/* Decrement — min 44px touch target */}
                        <button
                          type="button"
                          onClick={() => {
                            const currentQty = localStocks[product.id] !== undefined ? localStocks[product.id] : qte;
                            handleStockUpdate(product.id, currentQty - 1);
                          }}
                          disabled={updatingStockId === product.id || (localStocks[product.id] !== undefined ? localStocks[product.id] : qte) <= 1}
                          className="w-10 h-10 bg-white dark:bg-gray-800 rounded-lg flex items-center justify-center border border-gray-200/40 dark:border-white/5 text-gray-500 hover:text-gray-900 dark:hover:text-white disabled:opacity-40 transition-all active:scale-90"
                          aria-label="Diminuer le stock"
                        >
                          <Minus className="w-4 h-4" />
                        </button>

                        {/* Quantity display / input */}
                        <input
                          type="number"
                          min="1"
                          value={localStocks[product.id] !== undefined ? localStocks[product.id] : qte}
                          disabled={updatingStockId === product.id}
                          onChange={(e) => {
                            const val = parseInt(e.target.value);
                            setLocalStocks(prev => ({ ...prev, [product.id]: isNaN(val) ? 0 : val }));
                          }}
                          onBlur={() => {
                            const val = localStocks[product.id] !== undefined ? localStocks[product.id] : qte;
                            if (val !== qte && val >= 1) {
                              handleStockUpdate(product.id, val, true);
                            } else if (val < 1) {
                              showToast("Le stock minimum doit être de 1", "warning");
                              setLocalStocks(prev => { const next = {...prev}; delete next[product.id]; return next; });
                            }
                          }}
                          onKeyDown={(e) => {
                            if (e.key === 'Enter') {
                              const val = localStocks[product.id] !== undefined ? localStocks[product.id] : qte;
                              if (val !== qte && val >= 1) {
                                handleStockUpdate(product.id, val, true);
                              } else if (val < 1) {
                                showToast("Le stock minimum doit être de 1", "warning");
                                setLocalStocks(prev => { const next = {...prev}; delete next[product.id]; return next; });
                              }
                            }
                          }}
                          className="w-10 bg-transparent text-center text-sm font-black text-gray-900 dark:text-white outline-none focus:ring-0 [appearance:textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none"
                          aria-label="Quantité en stock"
                        />

                        {/* Increment */}
                        <button
                          type="button"
                          onClick={() => {
                            const currentQty = localStocks[product.id] !== undefined ? localStocks[product.id] : qte;
                            handleStockUpdate(product.id, currentQty + 1);
                          }}
                          disabled={updatingStockId === product.id}
                          className="w-10 h-10 bg-white dark:bg-gray-800 rounded-lg flex items-center justify-center border border-gray-200/40 dark:border-white/5 text-gray-500 hover:text-[#ff6600] dark:hover:text-[#ff6600] disabled:opacity-40 transition-all active:scale-90"
                          aria-label="Augmenter le stock"
                        >
                          {updatingStockId === product.id ? (
                            <Loader2 className="w-4 h-4 animate-spin text-[#ff6600]" />
                          ) : (
                            <Plus className="w-4 h-4" />
                          )}
                        </button>
                      </div>
                    );
                  })()}
                </div>

                {/* Edit + delete buttons — min 44px */}
                <div className="flex items-center gap-2 shrink-0">
                  <button 
                    className="w-11 h-11 flex items-center justify-center rounded-xl border border-gray-200 dark:border-white/10 bg-white dark:bg-white/5 text-gray-400 hover:text-[#ff6600] hover:border-[#ff6600]/30 transition-all active:scale-90"
                    onClick={() => onEditProduct(product)}
                    aria-label="Modifier ce produit"
                    title="Modifier ce produit"
                  >
                    <Edit className="w-4 h-4" />
                  </button>
                  <button 
                    className="w-11 h-11 flex items-center justify-center rounded-xl border border-gray-200 dark:border-white/10 bg-white dark:bg-white/5 text-gray-400 hover:text-rose-500 hover:border-rose-500/30 transition-all active:scale-90"
                    onClick={() => setConfirmConfig({ isOpen: true, productId: product.id })}
                    aria-label="Supprimer ce produit"
                    title="Supprimer ce produit"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </motion.div>
          );
        })}
      </div>

      <AnimatePresence>
        {confirmConfig.isOpen && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm"
            onClick={() => !isDeleting && setConfirmConfig({ isOpen: false, productId: null })}
          >
            <motion.div 
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              onClick={(e) => e.stopPropagation()}
              className="bg-white dark:bg-gray-900 dark:bg-gray-800 p-6 rounded-2xl w-full max-w-sm shadow-xl flex flex-col items-center text-center"
            >
              <div className="w-16 h-16 bg-red-100 text-red-600 rounded-full flex items-center justify-center mb-4">
                <Trash2 className="w-8 h-8" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 text-gray-900 dark:text-white mb-2">Supprimer le produit</h3>
              <p className="text-gray-500 text-gray-500 dark:text-gray-400 mb-6 font-medium">
                Voulez-vous vraiment supprimer ce produit de l'écosystème {APP_NAME} ? Cette action est irréversible.
              </p>
              <div className="flex w-full gap-3">
                <button
                  onClick={() => setConfirmConfig({ isOpen: false, productId: null })}
                  className="flex-1 py-3 px-4 rounded-xl font-medium text-gray-700 bg-gray-100 hover:bg-gray-200 dark:text-gray-300 dark:bg-gray-700 dark:hover:bg-gray-600 transition"
                >
                  Annuler
                </button>
                <button
                  onClick={handleConfirmDelete}
                  disabled={isDeleting}
                  className="flex-1 py-3 px-4 rounded-xl font-medium text-white bg-red-600 hover:bg-red-700 transition shadow-sm border border-red-500/20 disabled:opacity-60 flex items-center justify-center gap-2"
                >
                  {isDeleting ? <><Loader2 className="w-4 h-4 animate-spin" /> Suppression...</> : 'Supprimer'}
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

    </div>
  );
}
