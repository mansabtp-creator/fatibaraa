import React, { useState, useEffect, useRef } from 'react';
import type { FormEvent } from 'react';
import { Search, Mic, Clock, X, TrendingUp, Sparkles, Flame, ShoppingBag, ArrowRight, Camera, Image as ImageIcon, Loader2 } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { useAppContext } from '../context/AppContext';
import { useStore } from '../store/useStore';
import { useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'motion/react';
import { useDebounce } from '../hooks/useDebounce';
import { useToast } from '../context/ToastContext';
import { interpretSearchQuery, analyzeSearchImage, SmartSearchFilters } from '../services/aiSearchService';
import { formatGNF } from '../utils/formatters';

// Type for Speech Recognition
declare global {
  interface Window {
    SpeechRecognition: any;
    webkitSpeechRecognition: any;
  }
}

interface SearchBarProps {
  className?: string;
  placeholder?: string;
}

export default function SearchBar({ className, placeholder }: SearchBarProps) {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<any[]>([]);
  const [isSearching, setIsSearching] = useState(false);
  const [showDropdown, setShowDropdown] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [aiFilters, setAiFilters] = useState<SmartSearchFilters | null>(null);
  const [isAiProcessing, setIsAiProcessing] = useState(false);
  const [isAnalyzingImage, setIsAnalyzingImage] = useState(false);
  const { showToast } = useToast();
  
  const [shopResults, setShopResults] = useState<any[]>([]);
  const { recentlyViewed, modeEconomie, searchHistory, addSearchTerm, clearSearchHistory, globalSearchQuery, setGlobalSearchQuery } = useStore();
  const [recentProducts, setRecentProducts] = useState<any[]>([]);
  
  const { proMode } = useAppContext();
  
  const dropdownRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const navigate = useNavigate();
  const debouncedQuery = useDebounce(query, 300);

  const handleImageSearch = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsAnalyzingImage(true);
    setShowDropdown(true);
    
    try {
      const reader = new FileReader();
      reader.onloadend = async () => {
        const base64String = (reader.result as string).split(',')[1];
        const result = await analyzeSearchImage(base64String, file.type);
        
        if (result) {
          setAiFilters(result);
          if (result.description) {
            setQuery(result.description);
          }
          showToast("Image analysée par l'IA Alpha ⚡", "success");
        }
        setIsAnalyzingImage(false);
      };
      reader.readAsDataURL(file);
    } catch (error) {
      console.error("Image analysis failed:", error);
      showToast("L'analyse de l'image a échoué.", "error");
      setIsAnalyzingImage(false);
    }
  };

  // Fetch recent products data
  useEffect(() => {
    if (showDropdown && recentlyViewed.length > 0 && query === '') {
      const fetchRecents = async () => {
        const uuidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
        const validIds = recentlyViewed.filter(id => uuidRegex.test(id)).slice(0, 3);
        
        if (validIds.length === 0) return;

        const { data } = await supabase
          .from('products')
          .select('id, title, image_urls, price_gnf')
          .in('id', validIds);
        if (data) setRecentProducts(data);
      };
      fetchRecents();
    }
  }, [showDropdown, query, recentlyViewed]);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setShowDropdown(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  useEffect(() => {
    const searchAll = async () => {
      if (!debouncedQuery.trim()) {
        setResults([]);
        setShopResults([]);
        setAiFilters(null);
        setIsSearching(false);
        return;
      }
      
      setIsSearching(true);
      
      // AI Intelligence: If query is long/complex, interpret it
      if (debouncedQuery.split(' ').length > 2) {
        setIsAiProcessing(true);
        interpretSearchQuery(debouncedQuery).then(filters => {
          setAiFilters(filters);
          setIsAiProcessing(false);
        });
      } else {
        setAiFilters(null);
      }
      try {
        // Search Products
        let queryBuilder = supabase
          .from('products')
          .select('id, title, price_gnf, wholesale_price_gnf, image_urls, category');

        const words = debouncedQuery.split(/\s+/).filter(w => w.length >= 2);
        if (words.length > 0) {
          words.forEach(word => {
            queryBuilder = queryBuilder.or(`title.ilike.%${word}%,category.ilike.%${word}%`);
          });
        }

        if (aiFilters?.category) {
          queryBuilder = queryBuilder.ilike('category', `%${aiFilters.category}%`);
        }
        if (aiFilters?.maxPrice) {
          queryBuilder = queryBuilder.lte('price_gnf', aiFilters.maxPrice);
        }
        if (aiFilters?.minPrice) {
          queryBuilder = queryBuilder.gte('price_gnf', aiFilters.minPrice);
        }

        const { data: pData } = await queryBuilder.limit(5);
        
        setResults(pData || []);

        // Search Stores (Shops)
        const { data: sData } = await supabase
          .from('stores')
          .select('id, store_name, avatar_url, location_commune')
          .ilike('store_name', `%${debouncedQuery}%`)
          .limit(2);
        
        setShopResults(sData || []);

      } catch (err: any) {
        console.error(err);
        showToast(err.message || "Erreur de recherche", "error");
      } finally {
        setIsSearching(false);
      }
    };

    searchAll();
  }, [debouncedQuery]);

  const handleResultClick = (id: string, title: string) => {
    addSearchTerm(title);
    setShowDropdown(false);
    setQuery('');
    setGlobalSearchQuery(''); 
    navigate(`/product/${id}`);
  };

  const handleShopClick = (storeName: string) => {
    setShowDropdown(false);
    setQuery('');
    navigate(`/boutique/${storeName}`);
  };

  const handleSearchSubmit = (e: FormEvent) => {
    e.preventDefault();
    if (query.trim()) {
      addSearchTerm(query);
      setGlobalSearchQuery(query);
      setShowDropdown(false);
      
      // Navigate to search page
      navigate(`/search?q=${encodeURIComponent(query)}`);
    } else {
      setGlobalSearchQuery('');
      navigate('/search');
    }
  };

  const handleHistoryClick = (term: string) => {
    setQuery(term);
    setGlobalSearchQuery(term);
    setShowDropdown(false);
    navigate(`/search?q=${encodeURIComponent(term)}`);
  };

  const clearSearch = () => {
    setQuery('');
    setGlobalSearchQuery('');
    setResults([]);
    setShowDropdown(false);
  };

  const startVoiceSearch = () => {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechRecognition) {
      showToast("La recherche vocale n'est pas supportée.", 'error');
      return;
    }

    const recognition = new SpeechRecognition();
    recognition.lang = 'fr-FR';
    recognition.interimResults = false;
    recognition.maxAlternatives = 1;

    recognition.onstart = () => {
      setIsListening(true);
      setShowDropdown(true);
    };

    recognition.onresult = (event: any) => {
      const transcript = event.results[0][0].transcript;
      setQuery(transcript);
      setGlobalSearchQuery(transcript);
      navigate(`/search?q=${encodeURIComponent(transcript)}`);
    };

    recognition.onerror = (event: any) => {
      console.error("Erreur de reconnaissance vocale:", event.error);
      setIsListening(false);
    };

    recognition.onend = () => {
      setIsListening(false);
    };

    recognition.start();
  };

  return (
    <div className={`relative w-full ${className || 'lg:max-w-lg lg:mx-8'}`} ref={dropdownRef}>
      <form onSubmit={handleSearchSubmit} className="relative w-full flex items-center group">
        <div className="absolute inset-y-0 left-4 flex items-center pointer-events-none z-10 hidden md:flex">
          <Search className="h-4 w-4 text-brand-text-dim group-focus-within:text-gray-900 dark:text-white transition-colors" />
        </div>
        
          <input
            ref={inputRef}
            type="text"
            value={query}
            onChange={(e) => {
              setQuery(e.target.value);
              setShowDropdown(true);
              if (e.target.value === '') {
                setGlobalSearchQuery('');
              }
            }}
            onFocus={() => setShowDropdown(true)}
            className="block w-full pl-6 md:pl-12 pr-14 md:pr-[240px] py-3 md:py-3.5 border border-[#ff6600] dark:border-orange-500 text-[15px] bg-white dark:bg-gray-900 placeholder:text-gray-400 dark:placeholder:text-gray-600 text-gray-900 dark:text-white focus:outline-none rounded-full shadow-sm transition-all duration-300 relative z-0 font-medium"
            placeholder={placeholder || (isListening ? "Écoute en cours..." : isAnalyzingImage ? "Analyse Image..." : "Rechercher une pépite...")}
          />
          
          <div className="absolute right-1 top-1 bottom-1 flex items-center gap-1.5 z-10">
            <input 
              type="file" 
              ref={fileInputRef} 
              className="hidden" 
              accept="image/*" 
              capture="environment"
              onChange={handleImageSearch}
            />

            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              className={`p-2 rounded-full transition-colors relative hidden md:block ${isAnalyzingImage ? 'text-[#ff6600]' : 'text-gray-400 hover:bg-gray-100 hover:text-gray-600'}`}
              title="Recherche par image"
            >
              {isAnalyzingImage ? <Loader2 className="w-5 h-5 animate-spin" /> : <Camera className="w-5 h-5" />}
            </button>

            {query && (
              <button
                type="button"
                onClick={clearSearch}
                className="p-2 text-gray-400 hover:text-gray-600 transition-colors hidden md:block"
              >
                <X className="w-4 h-4" />
              </button>
            )}

            <button
              type="button"
              onClick={startVoiceSearch}
              className={`p-2 rounded-full transition-colors relative hidden md:block ${isListening ? 'text-[#ff6600]' : 'text-gray-400 hover:bg-gray-100 hover:text-gray-600'}`}
              title="Recherche vocale"
            >
              <Mic className="w-5 h-5" />
              {isListening && (
                <motion.span 
                  className="absolute inset-0 rounded-full bg-[#ff6600]/20"
                  animate={{ scale: [1, 1.5, 1], opacity: [0.5, 0, 0.5] }}
                  transition={{ duration: 1.5, repeat: Infinity }}
                />
              )}
            </button>
            
            <button 
              type="submit"
              className="flex items-center justify-center gap-2 bg-[#ff6600] hover:bg-orange-600 text-white w-10 md:w-auto h-10 px-0 md:px-6 rounded-full font-semibold transition-colors shrink-0"
            >
              <Search className="w-4 h-4 text-white" />
              <span className="hidden md:inline">Rechercher</span>
            </button>
          </div>
        </form>

        <AnimatePresence>
          {showDropdown && (
            <motion.div 
              initial={{ opacity: 0, y: -10, scale: 0.98 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: -10, scale: 0.98 }}
              transition={{ duration: 0.2, ease: "easeOut" }}
              className="absolute top-[calc(100%+8px)] left-0 w-full bg-white dark:bg-gray-900 dark:bg-gray-950 shadow-xl z-[99999] border border-gray-100 dark:border-gray-800 dark:border-white/10 rounded-3xl overflow-hidden"
            >
            {/* Trending & Suggestions */}
            {!query.trim() && (
            <div className="p-0">
                {/* Visual History: Recently Viewed Products */}
                {recentProducts.length > 0 && (
                  <div className="p-6 border-b border-brand-border/30 dark:border-white/5 bg-gray-50/30 dark:bg-gray-900/10">
                    <div className="flex items-center justify-between mb-5">
                      <span className="text-[10px] tracking-wider font-bold text-brand-text-dim dark:text-gray-500 dark:text-gray-400 flex items-center gap-2">
                        <Clock className="w-4 h-4" /> REPRENDRE VOS ACHATS
                      </span>
                      <button 
                        onClick={(e) => { e.stopPropagation(); clearSearchHistory(); }}
                        className="text-[10px] text-[#ff6600] tracking-wider font-bold hover:underline p-2"
                      >
                        EFFACER
                      </button>
                    </div>
                    <div className="flex gap-5 overflow-x-auto pb-2 scrollbar-hide">
                      {recentProducts.map((p) => (
                        <button
                          key={p.id}
                          onClick={() => handleResultClick(p.id, p.title)}
                          className="flex flex-col gap-3 min-w-[110px] group transition-all"
                        >
                          <div className="aspect-square rounded-2xl overflow-hidden border border-brand-border/30 dark:border-white/5 bg-white bg-white dark:bg-gray-900 shadow-sm transition-transform group-hover:scale-105 group-hover:shadow-md">
                            <img 
                              src={p.image_urls?.[0] || 'https://picsum.photos/seed/p/100/100'} 
                              alt={p.title} 
                              className="w-full h-full object-cover"
                              referrerPolicy="no-referrer"
                            />
                          </div>
                          <div className="text-left space-y-0.5">
                            <span className="text-[11px] font-bold text-gray-900 text-gray-900 dark:text-white truncate block uppercase tracking-tight">{p.title}</span>
                            <span className="text-[10px] font-bold text-[#ff6600] block tracking-tighter">{formatGNF(p.price_gnf)}</span>
                          </div>
                        </button>
                      ))}
                    </div>
                  </div>
                )}
                <div className="p-6">
                  {/* Quick Commands */}
                  <div className="mb-10">
                    <span className="text-[10px] tracking-wider font-bold text-brand-text-dim dark:text-gray-500 dark:text-gray-400 mb-5 block">Navigation rapide</span>
                    <div className="grid grid-cols-2 gap-3">
                      <button 
                        onClick={() => navigate('/cart')}
                        className="flex items-center gap-4 p-4 bg-gray-900 dark:bg-gray-800 text-brand-inverse rounded-[1.5rem] hover:bg-black dark:hover:bg-gray-700 transition-all group shadow-xl shadow-brand-foreground/10"
                      >
                        <div className="p-2.5 bg-white/20 rounded-xl group-hover:scale-110 transition-transform">
                          <ShoppingBag className="w-5 h-5 text-[#ff6600]" />
                        </div>
                        <span className="text-[11px] font-bold tracking-wider">Panier</span>
                      </button>
                      <button 
                        onClick={() => navigate('/vendor/dashboard')}
                        className="flex items-center gap-4 p-4 bg-[#ff6600] text-brand-inverse rounded-[1.5rem] hover:opacity-95 transition-all group shadow-xl shadow-[#ff6600]/20"
                      >
                        <div className="p-2.5 bg-white/20 rounded-xl group-hover:scale-110 transition-transform">
                          <Flame className="w-5 h-5 text-brand-inverse" />
                        </div>
                        <span className="text-[11px] font-bold tracking-wider">Vendre</span>
                      </button>
                    </div>
                  </div>

                  <div className="flex items-center gap-3 mb-5 border-b border-brand-border/10 dark:border-white/5 pb-2">
                    <TrendingUp className="w-5 h-5 text-[#ff6600]" />
                    <span className="text-[10px] tracking-wider font-bold text-brand-text-dim dark:text-gray-500 dark:text-gray-400">Tendances actuelles</span>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    {[
                      { label: 'iPhone 15 Pro', icon: <Flame className="w-4 h-4" /> },
                      { label: 'MacBook M3', icon: <Sparkles className="w-4 h-4" /> },
                      { label: 'Abaya Dubaï', icon: null },
                      { label: 'Laptops Gamer', icon: null }
                    ].map((item, idx) => (
                      <button
                        key={idx}
                        onClick={() => { setQuery(item.label); inputRef.current?.focus(); }}
                        className="flex items-center justify-between bg-gray-50 dark:bg-gray-800 dark:bg-gray-900 hover:bg-white dark:bg-gray-900 dark:hover:bg-gray-800 p-5 rounded-[1.5rem] border border-brand-border/20 dark:border-white/10 transition-all text-left group shadow-sm hover:shadow-md hover:scale-[1.02]"
                      >
                        <span className="text-[14px] font-bold text-gray-900 text-gray-900 dark:text-white group-hover:text-[#ff6600] dark:group-hover:text-orange-400 transition-colors tracking-tight uppercase">{item.label}</span>
                        {item.icon && <span className="text-[#ff6600] opacity-80">{item.icon}</span>}
                      </button>
                    ))}
                  </div>

                  <div className="mt-10">
                    <div className="flex items-center gap-3 mb-5">
                      <Sparkles className="w-5 h-5 text-blue-500" />
                      <span className="text-[10px] tracking-wider font-bold text-brand-text-dim dark:text-gray-500 dark:text-gray-400">SÉLECTION PAR UNIVERS</span>
                    </div>
                    <div className="flex flex-wrap gap-3">
                      {['ÉLECTRONIQUE', 'MODE GUINÉE', 'MÉDICAMENTS', 'COSMÉTIQUES'].map(cat => (
                        <button 
                          key={cat}
                          onClick={() => { setQuery(cat); inputRef.current?.focus(); }}
                          className="px-6 py-3 bg-blue-50 dark:bg-blue-900/20 text-blue-700 dark:text-blue-400 rounded-full text-[11px] font-bold tracking-[2px] transition-all hover:bg-blue-600 hover:text-white border border-blue-100 dark:border-blue-900/30 shadow-sm"
                        >
                          {cat}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Shop Results */}
            {!isSearching && query.trim() !== '' && shopResults.length > 0 && (
              <div className="px-6 py-5 border-b border-brand-border/20 dark:border-white/5 bg-[#ff6600]/[0.03]">
                <span className="text-[10px] tracking-[3px] font-bold text-[#ff6600] dark:text-orange-400 uppercase mb-5 block">Boutiques suggérées</span>
                <div className="flex flex-col gap-3">
                  {shopResults.map(shop => (
                    <button
                      key={shop.id}
                      onClick={() => handleShopClick(shop.store_name)}
                      className="flex items-center gap-4 p-3 rounded-[1.5rem] hover:bg-[#ff6600]/10 transition-all group bg-white bg-white dark:bg-gray-900 border border-brand-border/10 dark:border-white/5 shadow-sm"
                    >
                      <div className="w-12 h-12 rounded-full border border-white dark:border-gray-800 shadow-md overflow-hidden group-hover:scale-110 transition-transform">
                        <img 
                          src={shop.avatar_url || 'https://picsum.photos/seed/shop/100/100'} 
                          alt={shop.store_name} 
                          className="w-full h-full object-cover"
                        />
                      </div>
                      <div className="flex-1 text-left">
                        <div className="text-[14px] font-bold text-gray-900 text-gray-900 dark:text-white uppercase tracking-tight">{shop.store_name}</div>
                        <div className="text-[10px] text-brand-text-dim dark:text-gray-400 uppercase tracking-[1px]">{shop.location_commune} • Boutique Officielle</div>
                      </div>
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Loading Skeletons */}
            {isSearching && query.trim() && (
              <div className="p-4 space-y-4">
                {[1, 2, 3].map((i) => (
                  <div key={i} className="flex items-center gap-5 px-4 py-3">
                    <div className="w-16 h-16 rounded-2xl bg-gray-50 dark:bg-gray-800 animate-pulse border border-brand-border/20" />
                    <div className="flex-1 space-y-3">
                      <div className="h-4 bg-gray-50 dark:bg-gray-800 rounded-[10rem] animate-pulse w-3/4" />
                      <div className="h-3 bg-gray-50 dark:bg-gray-800 rounded-[10rem] animate-pulse w-1/4" />
                    </div>
                  </div>
                ))}
              </div>
            )}

            {/* Results */}
            {!isSearching && query.trim() !== '' && (
              <div className="flex flex-col py-3">
                {aiFilters && (
                  <div className="mx-6 mb-4 p-5 bg-gradient-to-r from-[#ff6600]/10 to-blue-500/10 border border-[#ff6600]/20 rounded-2xl relative overflow-hidden group">
                    <div className="absolute top-0 right-0 w-24 h-24 bg-[#ff6600]/10 rounded-full blur-2xl -mr-12 -mt-12 group-hover:scale-150 transition-transform duration-700" />
                    <div className="flex items-center gap-3 mb-2 relative z-10">
                       <Sparkles className="w-5 h-5 text-[#ff6600] dark:text-orange-400 animate-pulse" />
                       <span className="text-[10px] font-bold tracking-wider text-gray-900 text-gray-900 dark:text-white">IA SMART SEARCH</span>
                    </div>
                    <p className="text-[13px] font-bold text-gray-900 dark:text-white dark:text-gray-300 mb-3 leading-tight relative z-10">
                       On dirait que vous cherchez {aiFilters.category ? `dans ${aiFilters.category}` : 'quelque chose de spécifique'}. 
                       {aiFilters.maxPrice && ` Budget : < ${formatGNF(aiFilters.maxPrice)}.`}
                    </p>
                    <button 
                      onClick={() => navigate(`/search?q=${encodeURIComponent(query)}&category=${aiFilters.category || ''}&maxPrice=${aiFilters.maxPrice || ''}`)}
                      className="text-[10px] font-bold tracking-wider text-[#ff6600] dark:text-orange-400 hover:underline flex items-center gap-2 relative z-10"
                    >
                       Appliquer les filtres intelligents <ArrowRight className="w-3 h-3" />
                    </button>
                  </div>
                )}
                
                {results.length > 0 && (
                  <div className="px-6 py-3 border-b border-brand-border/10 dark:border-white/5">
                    <span className="text-[10px] tracking-[3px] font-bold text-brand-text-dim dark:text-gray-500 dark:text-gray-400 uppercase">Produits correspondants</span>
                  </div>
                )}
                {results.map((product) => {
                  const baseImageUrl = product.image_urls?.[0] || 'https://picsum.photos/seed/fallback/100/100';
                  const displayPrice = (proMode && product.wholesale_price_gnf) 
                    ? product.wholesale_price_gnf 
                    : product.price_gnf;

                  return (
                    <div 
                      key={product.id} 
                      onClick={() => handleResultClick(product.id, product.title)}
                      className="flex items-center gap-5 px-6 py-4 hover:bg-[#ff6600]/[0.04] cursor-pointer transition-all group"
                    >
                      <div className="w-16 h-16 flex-shrink-0 bg-white dark:bg-gray-900 dark:bg-gray-800 rounded-2xl overflow-hidden border border-brand-border/30 dark:border-white/10 group-hover:scale-105 transition-transform shadow-sm">
                        <img 
                          src={modeEconomie ? `${baseImageUrl}?blur=2&q=50` : baseImageUrl} 
                          alt={product.title} 
                          className="w-full h-full object-cover"
                          loading="lazy"
                        />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-1">
                          <div className="text-[15px] font-bold text-gray-900 text-gray-900 dark:text-white truncate group-hover:text-[#ff6600] transition-colors uppercase tracking-tight">{product.title}</div>
                        </div>
                        <div className="flex items-center justify-between">
                          <div className="text-[14px] font-bold text-[#ff6600] dark:text-orange-400 tracking-tighter">
                             {formatGNF(displayPrice)}
                          </div>
                          {product.category && (
                            <span className="text-[9px] font-bold tracking-wider text-brand-text-dim dark:text-gray-500 dark:text-gray-400 bg-gray-50 dark:bg-gray-800 dark:bg-gray-900 px-3 py-1 rounded-full border border-brand-border/20 dark:border-white/10">
                              {product.category}
                            </span>
                          )}
                        </div>
                      </div>
                    </div>
                  );
                })}
                <button 
                  onClick={handleSearchSubmit}
                  className="mx-6 my-4 py-5 bg-gray-50 dark:bg-gray-800 dark:bg-gray-900 hover:bg-gray-900 dark:hover:bg-[#ff6600] hover:text-brand-inverse text-[12px] font-bold tracking-wider text-gray-900 text-gray-900 dark:text-white rounded-[1.5rem] transition-all border border-brand-border/30 dark:border-white/10 shadow-sm active:scale-95"
                >
                  Tout voir pour "{query}"
                </button>
              </div>
            )}

            {/* No Results */}
            {!isSearching && query.trim() !== '' && results.length === 0 && (
              <div className="p-12 text-center bg-gray-50/30 dark:bg-gray-900/10">
                <div className="w-20 h-20 bg-white bg-white dark:bg-gray-900 rounded-[2rem] flex items-center justify-center mx-auto mb-6 shadow-xl border border-brand-border/30 dark:border-white/10">
                  <Search className="w-10 h-10 text-brand-text-dim/40" />
                </div>
                <div className="text-[18px] font-bold text-gray-900 text-gray-900 dark:text-white mb-2 uppercase tracking-tighter">Aucune pépite trouvée</div>
                <div className="text-[13px] text-brand-text-dim dark:text-gray-400 mb-10 max-w-[280px] mx-auto font-bold tracking-wider leading-relaxed">Changez de mots-clés ou explorez nos univers recommandés.</div>
                
                <div className="text-left bg-white bg-white dark:bg-gray-900 p-6 rounded-[2rem] border border-brand-border/20 dark:border-white/10 shadow-inner">
                  <div className="text-[10px] font-bold tracking-wider text-brand-text-dim dark:text-gray-500 dark:text-gray-400 mb-5">UNIVERS POPULAIRES</div>
                  <div className="flex flex-wrap gap-3">
                    {['ÉLECTRONIQUE', 'MODE', 'MAISON', 'COSMÉTIQUES'].map(cat => (
                      <button 
                        key={cat}
                        onClick={() => { setQuery(cat); inputRef.current?.focus(); }}
                        className="px-5 py-2.5 bg-gray-50 bg-gray-50 dark:bg-gray-800 border border-brand-border/30 dark:border-white/10 rounded-full text-[12px] font-bold tracking-wider text-gray-900 text-gray-900 dark:text-white hover:border-[#ff6600] hover:text-[#ff6600] transition-all shadow-sm active:scale-95"
                      >
                        {cat}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
