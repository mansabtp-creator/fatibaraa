/**
 * VendorInvitationPanel.tsx
 *
 * Admin panel for generating and managing vendor invitation links.
 * Rendered inside AdminDashboardPage under the vendors tab (or a dedicated
 * "Invitations" subsection).
 *
 * Features:
 *   - Generate a new invite link (optional email hint + label + expiry)
 *   - Copy the full invite URL to clipboard
 *   - List recent invitations with status (pending / used / expired / revoked)
 *   - Revoke any pending invitation
 *
 * Usage:
 *   <VendorInvitationPanel />
 *
 * The invite URL format: https://www.fatibara.com/join?invite=<token>
 * When the user clicks this link, VendorRegistrationPage reads the token from
 * the URL, calls consume_vendor_invitation() on form submit, and upgrades the
 * profile automatically.
 */
import React, { useState, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Link2, Copy, Check, Trash2, RefreshCw, PlusCircle,
  Clock, UserCheck, XCircle, Loader2, Mail
} from 'lucide-react';
import { supabase } from '../lib/supabase';
import { useToast } from '../context/ToastContext';

// ─── Types ────────────────────────────────────────────────────────────────────

interface Invitation {
  id: string;
  token: string;
  email_hint: string | null;
  label: string | null;
  used_at: string | null;
  expires_at: string;
  is_revoked: boolean;
  created_at: string;
}

// ─── Component ────────────────────────────────────────────────────────────────

export default function VendorInvitationPanel() {
  const { showToast } = useToast();
  const [invitations, setInvitations] = useState<Invitation[]>([]);
  const [loading, setLoading] = useState(true);
  const [generating, setGenerating] = useState(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  // Form state
  const [emailHint, setEmailHint] = useState('');
  const [label, setLabel] = useState('');
  const [expiry, setExpiry] = useState(7);
  const [showForm, setShowForm] = useState(false);

  // ── Fetch invitations ──────────────────────────────────────────────────────

  const fetchInvitations = useCallback(async () => {
    setLoading(true);
    try {
      const { data: sessionData } = await supabase.auth.getSession();
      const token = sessionData?.session?.access_token;
      const res = await fetch('/api/admin/vendor-invitations', {
        headers: token ? { Authorization: `Bearer ${token}` } : {},
      });
      if (res.ok) {
        const json = await res.json();
        if (json.success && Array.isArray(json.data)) {
          setInvitations(json.data);
          setLoading(false);
          return;
        }
      }
    } catch (e) {
      console.warn('[VendorInvitationPanel] Failed to fetch invitations:', e);
    }
    setLoading(false);
  }, []);

  useEffect(() => { fetchInvitations(); }, [fetchInvitations]);

  // ── Generate invite ────────────────────────────────────────────────────────

  const handleGenerate = async () => {
    setGenerating(true);
    try {
      const { data: sessionData } = await supabase.auth.getSession();
      const token = sessionData?.session?.access_token;
      const res = await fetch('/api/admin/vendor-invitations', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(token ? { Authorization: `Bearer ${token}` } : {}),
        },
        body: JSON.stringify({
          emailHint: emailHint.trim() || null,
          label: label.trim() || null,
          expiresDays: expiry,
        }),
      });

      const json = await res.json();
      if (!res.ok || !json.success) {
        throw new Error(json.error || 'Erreur lors de la création');
      }

      showToast('Lien d\'invitation créé !', 'success');
      setShowForm(false);
      setEmailHint('');
      setLabel('');
      setExpiry(7);
      fetchInvitations();

      // Auto-copy the new invite link
      const url = `${window.location.origin}/join?invite=${json.token}`;
      await navigator.clipboard.writeText(url);
      showToast('Lien copié dans le presse-papiers 📋', 'success');
    } catch (err: any) {
      showToast('Erreur : ' + err.message, 'error');
    } finally {
      setGenerating(false);
    }
  };

  // ── Copy link ──────────────────────────────────────────────────────────────

  const handleCopy = async (inv: Invitation) => {
    const url = `${window.location.origin}/join?invite=${inv.token}`;
    await navigator.clipboard.writeText(url);
    setCopiedId(inv.id);
    setTimeout(() => setCopiedId(null), 2000);
    showToast('Lien copié !', 'success');
  };

  // ── Revoke ─────────────────────────────────────────────────────────────────

  const handleRevoke = async (id: string) => {
    try {
      const { data: sessionData } = await supabase.auth.getSession();
      const token = sessionData?.session?.access_token;
      const res = await fetch(`/api/admin/vendor-invitations/${id}/revoke`, {
        method: 'POST',
        headers: token ? { Authorization: `Bearer ${token}` } : {},
      });
      const json = await res.json();
      if (res.ok && json.success) {
        setInvitations(prev => prev.map(i => i.id === id ? { ...i, is_revoked: true } : i));
        showToast('Invitation révoquée.', 'success');
      } else {
        throw new Error(json.error || 'Erreur');
      }
    } catch {
      showToast('Erreur lors de la révocation.', 'error');
    }
  };

  // ── Status helpers ─────────────────────────────────────────────────────────

  const getStatus = (inv: Invitation) => {
    if (inv.is_revoked) return 'revoked';
    if (inv.used_at) return 'used';
    if (new Date(inv.expires_at) < new Date()) return 'expired';
    return 'pending';
  };

  const STATUS_CONFIG = {
    pending:  { label: 'En attente',  color: 'text-amber-600 bg-amber-50 dark:bg-amber-900/20 dark:text-amber-400',  icon: Clock },
    used:     { label: 'Utilisé',     color: 'text-green-600 bg-green-50 dark:bg-green-900/20 dark:text-green-400',  icon: UserCheck },
    expired:  { label: 'Expiré',      color: 'text-gray-500 bg-gray-50 dark:bg-gray-800 dark:text-gray-400',         icon: XCircle },
    revoked:  { label: 'Révoqué',     color: 'text-red-600 bg-red-50 dark:bg-red-900/20 dark:text-red-400',          icon: XCircle },
  };

  // ── Render ─────────────────────────────────────────────────────────────────

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-[15px] font-black text-gray-900 dark:text-white uppercase tracking-tight">
            Invitations Vendeurs
          </h3>
          <p className="text-[11px] text-gray-400 font-bold mt-0.5">
            Liens à usage unique — expirent automatiquement
          </p>
        </div>
        <div className="flex items-center gap-2">
          <button onClick={fetchInvitations} className="p-2 rounded-xl border border-gray-200 dark:border-white/10 text-gray-400 hover:text-[#ff6600] transition-colors">
            <RefreshCw className="w-4 h-4" />
          </button>
          <button
            onClick={() => setShowForm(v => !v)}
            className="flex items-center gap-2 bg-[#ff6600] text-white px-4 py-2 rounded-xl text-[11px] font-black uppercase tracking-wide hover:bg-[#e65c00] transition-colors shadow-lg shadow-[#ff6600]/20"
          >
            <PlusCircle className="w-4 h-4" />
            Créer un lien
          </button>
        </div>
      </div>

      {/* Generation form */}
      <AnimatePresence>
        {showForm && (
          <motion.div
            initial={{ opacity: 0, y: -8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            className="bg-white dark:bg-gray-900 border border-gray-200 dark:border-white/10 rounded-2xl p-5 space-y-4"
          >
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="text-[10px] font-black text-gray-400 uppercase tracking-wider block mb-1.5">
                  E-mail (optionnel)
                </label>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-gray-400" />
                  <input
                    type="email"
                    value={emailHint}
                    onChange={e => setEmailHint(e.target.value)}
                    placeholder="vendor@example.com"
                    className="w-full pl-8 pr-3 py-2.5 rounded-xl border border-gray-200 dark:border-gray-700 text-[12px] font-medium bg-white dark:bg-gray-800 text-gray-900 dark:text-white placeholder:text-gray-300 focus:outline-none focus:border-[#ff6600]"
                  />
                </div>
              </div>
              <div>
                <label className="text-[10px] font-black text-gray-400 uppercase tracking-wider block mb-1.5">
                  Note interne (optionnel)
                </label>
                <input
                  type="text"
                  value={label}
                  onChange={e => setLabel(e.target.value)}
                  placeholder="Ex: Marché Madina — lot 5"
                  className="w-full px-3 py-2.5 rounded-xl border border-gray-200 dark:border-gray-700 text-[12px] font-medium bg-white dark:bg-gray-800 text-gray-900 dark:text-white placeholder:text-gray-300 focus:outline-none focus:border-[#ff6600]"
                />
              </div>
            </div>
            <div>
              <label className="text-[10px] font-black text-gray-400 uppercase tracking-wider block mb-1.5">
                Expire dans
              </label>
              <div className="flex gap-2 flex-wrap">
                {[1, 3, 7, 14, 30].map(d => (
                  <button
                    key={d}
                    onClick={() => setExpiry(d)}
                    className={`px-3 py-1.5 rounded-lg border text-[11px] font-black transition-colors ${
                      expiry === d
                        ? 'bg-[#ff6600] border-[#ff6600] text-white'
                        : 'border-gray-200 dark:border-gray-700 text-gray-500 hover:border-[#ff6600]'
                    }`}
                  >
                    {d}j
                  </button>
                ))}
              </div>
            </div>
            <button
              onClick={handleGenerate}
              disabled={generating}
              className="w-full flex items-center justify-center gap-2 bg-[#ff6600] text-white py-2.5 rounded-xl text-[12px] font-black uppercase tracking-wide hover:bg-[#e65c00] disabled:opacity-50 transition-colors"
            >
              {generating ? <Loader2 className="w-4 h-4 animate-spin" /> : <Link2 className="w-4 h-4" />}
              Générer et copier le lien
            </button>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Invitations list */}
      {loading ? (
        <div className="flex justify-center py-10">
          <Loader2 className="w-6 h-6 text-[#ff6600] animate-spin" />
        </div>
      ) : invitations.length === 0 ? (
        <div className="text-center py-10 text-[12px] text-gray-400 font-bold">
          Aucune invitation créée pour le moment.
        </div>
      ) : (
        <div className="space-y-2">
          {invitations.map(inv => {
            const status = getStatus(inv);
            const cfg = STATUS_CONFIG[status];
            const StatusIcon = cfg.icon;
            const isPending = status === 'pending';
            return (
              <div
                key={inv.id}
                className={`flex items-center gap-3 p-4 rounded-2xl border bg-white dark:bg-gray-900 transition-colors ${
                  isPending ? 'border-gray-200 dark:border-white/10' : 'border-gray-100 dark:border-white/5 opacity-60'
                }`}
              >
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2 mb-1 flex-wrap">
                    <span className={`flex items-center gap-1 px-2 py-0.5 rounded-full text-[9px] font-black uppercase tracking-wider ${cfg.color}`}>
                      <StatusIcon className="w-3 h-3" /> {cfg.label}
                    </span>
                    {inv.label && (
                      <span className="text-[10px] font-bold text-gray-500 dark:text-gray-400 truncate">
                        {inv.label}
                      </span>
                    )}
                    {inv.email_hint && (
                      <span className="text-[10px] font-bold text-[#ff6600] truncate">
                        {inv.email_hint}
                      </span>
                    )}
                  </div>
                  <p className="text-[10px] font-mono text-gray-400 truncate">
                    /join?invite={inv.token.substring(0, 16)}…
                  </p>
                  <p className="text-[9px] text-gray-400 font-bold mt-0.5">
                    Expire le {new Date(inv.expires_at).toLocaleDateString('fr-GN')}
                    {inv.used_at && ` • Utilisé le ${new Date(inv.used_at).toLocaleDateString('fr-GN')}`}
                  </p>
                </div>
                <div className="flex items-center gap-1.5 shrink-0">
                  {isPending && (
                    <>
                      <button
                        onClick={() => handleCopy(inv)}
                        className="p-2 rounded-xl border border-gray-200 dark:border-white/10 text-gray-400 hover:text-[#ff6600] hover:border-[#ff6600] transition-all"
                        title="Copier le lien"
                      >
                        {copiedId === inv.id
                          ? <Check className="w-3.5 h-3.5 text-green-500" />
                          : <Copy className="w-3.5 h-3.5" />}
                      </button>
                      <button
                        onClick={() => handleRevoke(inv.id)}
                        className="p-2 rounded-xl border border-gray-200 dark:border-white/10 text-gray-400 hover:text-red-500 hover:border-red-400 transition-all"
                        title="Révoquer ce lien"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
