import React, { useState, useEffect } from 'react';

// In production, this component renders nothing at all.
// It is only active during local development to help catch runtime errors.
export default function DebugOverlay() {
  const [errors, setErrors] = useState<string[]>([]);

  useEffect(() => {
    if (import.meta.env.PROD) return;

    const originalError = console.error;
    console.error = (...args: any[]) => {
      const message = args.map(arg => {
        if (arg instanceof Error) {
          return `${arg.name}: ${arg.message}\n${arg.stack}`;
        }
        return typeof arg === 'object' ? JSON.stringify(arg, null, 2) : String(arg);
      }).join(' ');
      setErrors((prev) => [...prev, message]);
      originalError(...args);
    };
    return () => {
      console.error = originalError;
    };
  }, []);

  if (import.meta.env.PROD) return null;
  if (errors.length === 0) return null;

  return (
    <div className="fixed top-0 left-0 right-0 z-[9999] bg-red-500/90 text-white p-2 text-xs overflow-auto max-h-[30vh]">
      <button onClick={() => setErrors([])} className="float-right font-bold">[Clear]</button>
      <strong>Errors:</strong>
      {errors.map((err, i) => <div key={i} className="border-b border-red-400 p-1">{err}</div>)}
    </div>
  );
}
