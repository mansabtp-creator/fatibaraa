import React from 'react';
import { Package } from 'lucide-react';

interface VolumePricingProps {
  qty: string;
  percent: string;
  onChangeQty: (val: string) => void;
  onChangePercent: (val: string) => void;
}

export function VolumePricing({ qty, percent, onChangeQty, onChangePercent }: VolumePricingProps) {
  return (
    <div className="space-y-4 pt-4 border-t border-brand-border/30 dark:border-white/10 mt-4">
      <div className="flex items-center gap-3 ml-1 mb-2">
        <Package className="w-4 h-4 text-[#ff6600] dark:text-orange-400" />
        <label className="text-[12px] font-bold tracking-wider text-brand-text-dim dark:text-gray-400">Prix de Gros / Volume</label>
      </div>
      
      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <input 
            type="number" 
            placeholder="Quantité (ex: 3)" 
            value={qty}
            onChange={e => onChangeQty(e.target.value)}
            className="w-full bg-gray-50 bg-gray-50 dark:bg-gray-800 border border-brand-border/50 dark:border-white/10 rounded-[1.5rem] p-4 text-[13px] font-bold text-gray-900 text-gray-900 dark:text-white focus:outline-none focus:border-[#ff6600] transition-all" 
            min="0"
          />
        </div>
        <div className="space-y-2 relative" x-id="reduction-input">
          <input 
            type="number" 
            placeholder="Réduction (ex: 10)" 
            value={percent}
            onChange={e => onChangePercent(e.target.value)}
            className="w-full bg-gray-50 bg-gray-50 dark:bg-gray-800 border border-brand-border/50 dark:border-white/10 rounded-[1.5rem] p-4 text-[13px] font-bold text-gray-900 text-gray-900 dark:text-white focus:outline-none focus:border-[#ff6600] transition-all pr-8" 
            min="0"
            max="100"
          />
          <span className="absolute right-4 top-1/2 -translate-y-1/2 font-bold text-brand-text-dim dark:text-gray-500 dark:text-gray-400">%</span>
        </div>
      </div>
    </div>
  );
}
