import React, { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { useToast } from '../context/ToastContext';
import { ShoppingCart, Send, Mail } from 'lucide-react';

export function AbandonedCarts({ storeId }: { storeId: string }) {
  const [events, setEvents] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const { showToast } = useToast();

  useEffect(() => {
    fetchEvents();
  }, [storeId]);

  const fetchEvents = async () => {
    setLoading(true);
    // Ideally user data would be joined here, simulating with profiles or users view depending on setup
    const { data, error } = await supabase.from('cart_events')
      .select('*, profiles(full_name, avatar_url)')
      .eq('store_id', storeId)
      .eq('status', 'abandoned')
      .order('updated_at', { ascending: false });
    
    if (!error && data) setEvents(data);
    setLoading(false);
  };

  const handleSendOffer = async (eventId: string) => {
    // Mock sending email
    showToast("Offre de récupération envoyée !", "success");
    // Update status to prevent spam
    try {
      await supabase.from('cart_events').update({ status: 'contacted' }).eq('id', eventId);
      setEvents(events.filter(e => e.id !== eventId));
    } catch {}
  };

  return (
    <div className="bg-white dark:bg-gray-900 border border-brand-border/30 rounded-[2rem] p-6 space-y-6">
      <div className="flex items-center gap-3 mb-4">
        <div className="w-10 h-10 rounded-xl bg-orange-500/10 flex items-center justify-center text-orange-500">
          <ShoppingCart className="w-5 h-5" />
        </div>
        <div>
          <h2 className="text-xl font-bold text-gray-900 dark:text-white">Paniers Abandonnés</h2>
          <p className="text-[11px] font-bold text-brand-text-dim">Récupérez les ventes perdues</p>
        </div>
      </div>

      <div className="space-y-4">
        {events.map(event => (
          <div key={event.id} className="flex flex-col sm:flex-row justify-between bg-gray-50 dark:bg-gray-800 border border-brand-border/50 rounded-[1.5rem] p-4 gap-4">
            <div className="flex gap-4 items-center">
              <div className="w-12 h-12 rounded-full overflow-hidden bg-white dark:bg-gray-900 border border-brand-border/30">
                <img src={event.profiles?.avatar_url || `https://api.dicebear.com/7.x/avataaars/svg?seed=${event.user_id}`} className="w-full h-full object-cover" />
              </div>
              <div>
                <h4 className="font-bold text-[14px] text-gray-900 dark:text-white">{event.profiles?.full_name || 'Utilisateur'}</h4>
                <p className="text-[12px] font-bold text-orange-600">Total: {parseFloat(event.total_value).toLocaleString()} GNF</p>
                <p className="text-[10px] uppercase font-bold text-brand-text-dim mt-1">{new Date(event.updated_at).toLocaleString()}</p>
              </div>
            </div>
            
            <div className="flex items-center">
              <button 
                onClick={() => handleSendOffer(event.id)}
                className="w-full sm:w-auto bg-[#ff6600]/10 text-[#ff6600] hover:bg-[#ff6600] hover:text-white border border-[#ff6600]/20 px-6 py-3 rounded-xl font-bold text-[11px] tracking-wider transition-all flex items-center justify-center gap-2"
              >
                <Mail className="w-4 h-4" /> Envoyer Offre (-10%)
              </button>
            </div>
          </div>
        ))}

        {events.length === 0 && !loading && (
          <div className="text-center py-10">
            <p className="text-brand-text-dim text-[13px] font-bold tracking-wider">Aucun panier abandonné récent</p>
          </div>
        )}
      </div>
    </div>
  );
}
