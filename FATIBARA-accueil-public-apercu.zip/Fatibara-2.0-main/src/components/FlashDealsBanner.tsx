import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Zap, Clock, ArrowRight, TrendingDown } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { Link } from 'react-router-dom';

export default function FlashDealsBanner() {
  const [deals, setDeals] = useState<any[]>([]);
  const [currentDeal, setCurrentDeal] = useState<any>(null);
  const [timeLeft, setTimeLeft] = useState<{h: number, m: number, s: number} | null>(null);

  useEffect(() => {
    fetchActiveDeals();
  }, []);

  const fetchActiveDeals = async () => {
    const { data } = await supabase
      .from('flash_deals')
      .select('*, product:product_id(title, image_urls, price_gnf, id)')
      .eq('is_active', true)
      .gt('end_time', new Date().toISOString())
      .lt('start_time', new Date().toISOString())
      .order('created_at', { ascending: false });
    
    if (data && data.length > 0) {
      setDeals(data);
      setCurrentDeal(data[0]);
    }
  };

  useEffect(() => {
    if (!currentDeal) return;

    const timer = setInterval(() => {
      const now = new Date().getTime();
      const end = new Date(currentDeal.end_time).getTime();
      const distance = end - now;

      if (distance < 0) {
        setTimeLeft(null);
        clearInterval(timer);
        return;
      }

      setTimeLeft({
        h: Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60)),
        m: Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60)),
        s: Math.floor((distance % (1000 * 60)) / 1000)
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [currentDeal]);

  // A deal can reference a product that was removed or is temporarily unavailable.
  // Hide that incomplete promotion instead of allowing it to break the public homepage.
  if (!currentDeal?.product || !timeLeft) return null;

  const originalPrice = Number(currentDeal.product.price_gnf || 0);
  const discountPercent = originalPrice > 0
    ? Math.max(0, Math.round(((originalPrice - Number(currentDeal.discount_price || 0)) / originalPrice) * 100))
    : 0;

  return (
    <div className="px-3 md:px-10 mt-6 mb-4 md:mt-8 md:mb-6">
      <div className="bg-gray-900 rounded-[1.5rem] md:rounded-[2.5rem] p-6 md:p-8 relative overflow-hidden flex flex-col md:flex-row items-center justify-between gap-6 md:gap-8 group border border-brand-border/20 shadow-2xl">
        {/* Dynamic Image Background */}
        <div className="absolute inset-0 z-0 h-full w-full opacity-10">
           <img src={currentDeal.product.image_urls?.[0]} alt="" className="w-full h-full object-cover scale-150 blur-3xl" />
        </div>
        
        {/* Animated Effects */}
        <div className="absolute top-0 right-0 w-[400px] h-[400px] bg-[#ff6600] opacity-20 blur-[100px] -mr-40 -mt-40 pointer-events-none" />

        <div className="relative z-10 text-center md:text-left space-y-4 max-w-lg">
          <div className="inline-flex items-center gap-2 bg-[#ff6600] text-brand-inverse px-4 py-2 rounded-full shadow-lg shadow-[#ff6600]/30">
             <Zap className="w-4 h-4 fill-current animate-pulse" />
             <span className="text-[10px] md:text-[11px] font-bold tracking-wider">OFFRE ÉCLAIR ALPHA</span>
          </div>
          <h2 className="text-3xl md:text-5xl font-bold text-brand-inverse tracking-tighter leading-none uppercase">
            {currentDeal.product.title.split(' ')[0]} <span className="text-[#ff6600] italic">FLASH</span>
          </h2>
          <p className="text-brand-inverse/70 text-[12px] md:text-[14px] font-bold tracking-wider leading-relaxed">
            Economisez <span className="text-[#ff6600] font-bold text-xl md:text-2xl">-{discountPercent}%</span> sur cette pépite de {currentDeal.product.title}. Ne laissez pas passer l'instant !
          </p>
        </div>

        <div className="relative z-10 flex flex-col items-center gap-6 bg-brand-inverse/5 backdrop-blur-2xl p-5 md:p-8 rounded-[1.5rem] md:rounded-[2rem] border border-brand-inverse/10 shadow-inner w-full md:w-auto">
           {/* Price Tag */}
           <div className="flex flex-col items-center">
              <span className="text-[9px] font-bold text-[#ff6600] tracking-wider mb-2">PRIX EXCLUSIF</span>
              <div className="flex items-center gap-4">
                 <span className="text-2xl md:text-4xl font-bold text-brand-inverse tracking-tighter">{currentDeal.discount_price.toLocaleString()} GNF</span>
                 <span className="text-sm md:text-lg font-bold text-brand-inverse/30 line-through">{currentDeal.product.price_gnf.toLocaleString()}</span>
              </div>
           </div>

           {/* Countdown */}
           <div className="flex gap-3 md:gap-4">
              {[
                { val: timeLeft.h, label: 'H' },
                { val: timeLeft.m, label: 'M' },
                { val: timeLeft.s, label: 'S' }
              ].map((t, i) => (
                <div key={i} className="flex flex-col items-center">
                  <div className="w-12 h-12 md:w-16 md:h-16 bg-brand-inverse/10 border border-brand-inverse/30 rounded-xl md:rounded-2xl flex items-center justify-center text-xl md:text-2xl font-bold text-brand-inverse shadow-xl">
                    <span className="tabular-nums">{t.val.toString().padStart(2, '0')}</span>
                  </div>
                  <span className="text-[8px] font-bold text-brand-inverse/40 mt-1 uppercase">{t.label}</span>
                </div>
              ))}
           </div>

           <Link 
             to={`/product/${currentDeal.product.id}`}
             className="w-full bg-brand-inverse text-gray-900 dark:text-white px-10 py-4 rounded-full text-[12px] font-bold tracking-wider flex items-center justify-center gap-3 hover:bg-[#ff6600] hover:text-brand-inverse transition-all shadow-xl active:scale-95 group/btn"
           >
              Profit Alpha <ArrowRight className="w-4 h-4 group-hover/btn:translate-x-2 transition-transform" />
           </Link>
        </div>
      </div>
    </div>
  );
}
