import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { supabase, validateSessionOrClear } from '../lib/supabase';
import { 
  CheckCircle2, 
  MapPin, 
  Truck, 
  Package, 
  Phone, 
  Timer, 
  Navigation, 
  ChevronRight,
  ShieldCheck,
  Star,
  PartyPopper,
  Store,
  Car,
} from 'lucide-react';
import { hapticFeedback } from '../lib/haptics';
import { useToast } from '../context/ToastContext';
import { APP_NAME, SUPPORT_WHATSAPP, SUPPORT_PHONE, AISATA_AVATAR_URL } from '../lib/constants';

interface TrackingStep {
  id: number;
  label: string;
  sub: string;
  icon: any;
  status: 'complete' | 'active' | 'upcoming';
}

const STATUS_MAP: Record<string, number> = {
  'pending': 0,
  'accepted': 1,
  'preparing': 2,
  'assigned': 3,
  'picked_up': 4,
  'in_transit': 4,
  'arriving_soon': 5,
  'delivered': 6
};

export default function LiveOrderTracking({ orderId, orderUUID, region, quartier }: { orderId: string; orderUUID?: string; region: string; quartier: string }) {
  const { showToast } = useToast();
  const [activeStep, setActiveStep] = useState(0);
  const [progress, setProgress] = useState(0);
  const [orderStatus, setOrderStatus] = useState('accepted');
  const [courierInfo, setCourierInfo] = useState<any>(null);
  const [courierPos, setCourierPos] = useState({ lat: 0, lng: 0 });
  const [showCelebration, setShowCelebration] = useState(false);
  const [etaMinutes, setEtaMinutes] = useState<number | null>(null);
  // Self-delivery state
  const [fulfillmentType, setFulfillmentType] = useState<string | null>(null);
  const [selfDeliveryDriver, setSelfDeliveryDriver] = useState<{
    name: string | null;
    phone: string | null;
    plate: string | null;
  } | null>(null);

  // Live support contact — fetched from platform_settings, falls back to constants
  const [liveWhatsapp, setLiveWhatsapp] = useState(SUPPORT_WHATSAPP);
  const [livePhone, setLivePhone]       = useState(SUPPORT_PHONE);

  // Fetch support contact numbers from platform_settings once on mount
  useEffect(() => {
    let isMounted = true;
    supabase
      .from('platform_settings')
      .select('id, value')
      .in('id', ['support_whatsapp', 'support_phone'])
      .then(({ data }) => {
        if (!isMounted || !data) return;
        data.forEach(row => {
          if (row.id === 'support_whatsapp' && row.value) setLiveWhatsapp(row.value);
          if (row.id === 'support_phone'    && row.value) setLivePhone(row.value);
        });
      });
    return () => {
      isMounted = false;
    };
  }, []);

  useEffect(() => {
    async function fetchOrderDetails() {
      // ── Session guard ──────────────────────────────────────────────────
      // A stale/missing JWT causes PostgREST to return HTTP 406 before reaching
      // RLS. Non-existent columns cause HTTP 400 (PGRST200). Validate first.
      const session = await validateSessionOrClear();
      if (!session) {
        console.warn('[LiveOrderTracking] No active session — skipping order fetch.');
        return;
      }

      // ── Query — use UUID when available, tracking_number as fallback ───────
      // orderId is an ORD- display ID (e.g. "ORD-1785459540557-546"), NOT a UUID.
      // Passing it to .eq('id', ...) triggers Postgres error 22P02
      // "invalid input syntax for type uuid". We now receive the real UUID as
      // orderUUID and use it directly. If unavailable, filter by tracking_number.
      // NOTE: delivery_otp is intentionally excluded from the SELECT.
      // OTP verification is done server-side via the complete_courier_delivery RPC.
      // Returning it to the browser would be a security vulnerability.
      let query = supabase
        .from('orders')
        .select(`
          id,
          status,
          tracking_number,
          courier_id,
          fulfillment_type,
          self_delivery_driver_name,
          self_delivery_driver_phone,
          self_delivery_driver_plate
        `);

      if (orderUUID) {
        query = query.eq('id', orderUUID);
      } else {
        // Fallback: filter by the human-readable tracking number
        query = query.eq('tracking_number', orderId);
      }

      const { data, error: orderError } = await query.maybeSingle();

      // ── Error handling: 400 + 406 ────────────────────────────────────
      if (orderError) {
        const code = orderError.code as string | undefined;
        const msg  = orderError.message as string | undefined;

        if (code === '406' || msg?.toLowerCase().includes('not acceptable')) {
          console.error(
            '[LiveOrderTracking] HTTP 406 on orders query — JWT may be stale.',
            orderError
          );
          await validateSessionOrClear();
          return;
        }

        // 22P02 = invalid UUID syntax — orderId is an ORD- display ID, not a UUID.
        // This should no longer happen now that we pass orderUUID, but guard anyway.
        if (code === '22P02') {
          console.error(
            '[LiveOrderTracking] 22P02 invalid UUID — orderId is a display ID, not a UUID. ' +
            'Ensure orderUUID prop is passed from CheckoutPage.',
            orderError
          );
          return;
        }

        if (
          code === '400' || code === 'PGRST200' ||
          (msg?.toLowerCase().includes('column') && msg?.toLowerCase().includes('does not exist'))
        ) {
          console.error(
            '[LiveOrderTracking] HTTP 400 — One of [delivery_otp, tracking_number, courier_id] ' +
            'is missing from the orders table. Run the schema fix migration.',
            orderError
          );
          return;
        }

        console.error('[LiveOrderTracking] orders query error:', orderError);
        return;
      }
      
      if (data) {
        setOrderStatus(data.status);
        setActiveStep(STATUS_MAP[data.status] || 0);
        setFulfillmentType(data.fulfillment_type || null);

        // Self-delivery driver info
        if (data.fulfillment_type === 'vendor_self_delivery') {
          setSelfDeliveryDriver({
            name: data.self_delivery_driver_name || null,
            phone: data.self_delivery_driver_phone || null,
            plate: data.self_delivery_driver_plate || null,
          });
        }
        
        if (data.status === 'delivered') {
          setShowCelebration(true);
        }

        if (data.courier_id) {
          const { data: profile } = await supabase
            .from('profiles')
            .select('id, full_name, phone_number, avatar_url, vehicle_type, license_plate_number, courier_rating')
            .eq('id', data.courier_id)
            .single();
          setCourierInfo(profile);

          // Fetch last known location
          const targetOrderId = orderUUID || data.id || (orderId?.length === 36 ? orderId : null);
          if (targetOrderId) {
            const { data: loc } = await supabase
              .from('courier_locations')
              .select('lat, lng')
              .eq('order_id', targetOrderId)
              .order('updated_at', { ascending: false })
              .limit(1)
              .maybeSingle();
            if (loc) setCourierPos(loc);
          }
        }
      }
    }

    if (orderId && orderId.length > 20) {
      fetchOrderDetails();

      const orderChannel = supabase.channel(`order-tracking-${orderId}`)
        .on(
          'postgres_changes',
          // Fix: orderId is a display ID (ORD-xxx), not a UUID — filter on tracking_number
          { event: 'UPDATE', schema: 'public', table: 'orders', filter: `tracking_number=eq.${orderId}` },
          (payload) => {
            const newStatus = payload.new.status;
            setOrderStatus(newStatus);
            setActiveStep(STATUS_MAP[newStatus] || 0);
            hapticFeedback('success');

            if (newStatus === 'delivered') {
              setShowCelebration(true);
              showToast(`Votre commande a été livrée ! Profitez bien de vos achats ${APP_NAME}.`, "success");
              confettiBurst();
            }
          }
        )
        .subscribe();

      const targetLocId = orderUUID || (orderId?.length === 36 ? orderId : null);
      const locChannel = supabase.channel(`courier-loc-${orderId}`)
        .on(
          'postgres_changes',
          { event: '*', schema: 'public', table: 'courier_locations', ...(targetLocId ? { filter: `order_id=eq.${targetLocId}` } : {}) },
          (payload: any) => {
            if (payload.new?.lat && payload.new?.lng) {
              setCourierPos({ lat: payload.new.lat, lng: payload.new.lng });
              // Use real movement to update progress bar visually
              setProgress(prev => Math.min(95, prev + 2)); 
            }
          }
        )
        .subscribe();

      // Subscribe to deliveries table for arriving_soon flag.
      // The courier writes arriving_soon=true here; we react by advancing
      // the customer tracking step to 'Arrivée imminente'.
      const deliveriesChannel = supabase.channel(`deliveries-tracking-${orderId}`)
        .on(
          'postgres_changes',
          { event: '*', schema: 'public', table: 'deliveries', filter: `order_id=eq.${orderUUID || orderId}` },
          (payload) => {
            if (payload.new?.arriving_soon) {
              setOrderStatus('arriving_soon');
              setActiveStep(STATUS_MAP['arriving_soon'] || 5);
              hapticFeedback('success');
              showToast('Votre livreur arrive bientôt !', 'success');
            }
          }
        )
        .subscribe();

      return () => {
        supabase.removeChannel(orderChannel);
        supabase.removeChannel(locChannel);
        supabase.removeChannel(deliveriesChannel);
      };
    }
  }, [orderId]);

  const confettiBurst = () => {
    // Simple visual cue - the actual animation is in the JSX below
    setTimeout(() => setShowCelebration(false), 5000);
  };

  // Minor progress simulation within the active step for visual polish
  useEffect(() => {
    const interval = setInterval(() => {
      setProgress(prev => (prev >= 95 ? 95 : prev + 1));
    }, 2000);
    return () => clearInterval(interval);
  }, [activeStep]);

  const steps: TrackingStep[] = [
    { id: 0, label: 'Validée', sub: 'Paiement reçu', icon: ShieldCheck, status: activeStep > 0 ? 'complete' : activeStep === 0 ? 'active' : 'upcoming' },
    { id: 1, label: 'Préparation', sub: 'Vendeur emballe', icon: Package, status: activeStep > 2 ? 'complete' : activeStep === 2 ? 'active' : 'upcoming' },
    { id: 2, label: 'Retrait', sub: 'Assigné au livreur', icon: Truck, status: activeStep > 3 ? 'complete' : activeStep === 3 ? 'active' : 'upcoming' },
    { id: 3, label: 'En Transit', sub: 'Livraison en cours', icon: Navigation, status: activeStep > 4 ? 'complete' : activeStep === 4 ? 'active' : 'upcoming' },
  ];

  // Coordinate mapping for Conakry (Simple projection from Lat/Lng to 0-100 SVG space)
  // Conakry Window: Lat [9.49, 9.65], Lng [-13.72, -13.55]
  const mapPos = (pos: { lat: number, lng: number }) => {
    if (!pos.lat || !pos.lng) return { x: 50, y: 50 };
    const x = ((pos.lng + 13.72) / (13.72 - 13.55)) * 100;
    const y = 100 - ((pos.lat - 9.49) / (9.65 - 9.49)) * 100;
    return { 
      x: Math.max(10, Math.min(90, x || 50)), 
      y: Math.max(10, Math.min(90, y || 50)) 
    };
  };

  // Haversine distance in km between two lat/lng points
  const haversineKm = (a: { lat: number; lng: number }, b: { lat: number; lng: number }) => {
    const R = 6371;
    const dLat = (b.lat - a.lat) * Math.PI / 180;
    const dLng = (b.lng - a.lng) * Math.PI / 180;
    const h = Math.sin(dLat/2)**2 + Math.cos(a.lat * Math.PI/180) * Math.cos(b.lat * Math.PI/180) * Math.sin(dLng/2)**2;
    return R * 2 * Math.asin(Math.sqrt(h));
  };

  // Compute ETA when courier position is available (avg speed 30 km/h)
  const computedEta = (() => {
    if (!courierPos.lat || !courierPos.lng) return null;
    // Approximate destination: centre of Conakry if no real coords available
    const destLat = 9.5370, destLng = -13.6773;
    const dist = haversineKm(courierPos, { lat: destLat, lng: destLng });
    return Math.ceil((dist / 30) * 60); // minutes at 30 km/h
  })();

  const courierMapPos = mapPos(courierPos);
  
  // Destination offset logic
  const destPos = { x: 80, y: 35 }; // Generic destination for quartier
  const originPos = { x: 20, y: 75 }; // Generic origin for vendor

  return (
    <div className="bg-white dark:bg-gray-900 border border-brand-border/30 rounded-[2.5rem] md:rounded-[3rem] overflow-hidden shadow-xl shadow-brand-foreground/5 animate-in fade-in slide-in-from-bottom-10 relative">
      <AnimatePresence>
        {showCelebration && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="absolute inset-0 z-50 pointer-events-none flex items-center justify-center bg-[#ff6600]/10 backdrop-blur-[2px]"
          >
             <motion.div 
               initial={{ scale: 0, rotate: -45 }}
               animate={{ scale: 1.5, rotate: 0 }}
               className="p-10 bg-white dark:bg-gray-900 rounded-full shadow-2xl border-4 border-[#ff6600]"
             >
                <PartyPopper className="w-20 h-20 text-[#ff6600]" />
             </motion.div>
             
             {/* Simple Floating Points to simulate confetti */}
             {[...Array(20)].map((_, i) => (
                <motion.div
                  key={i}
                  initial={{ x: 0, y: 0, opacity: 1 }}
                  animate={{ 
                    x: (Math.random() - 0.5) * 400, 
                    y: (Math.random() - 0.5) * 400, 
                    opacity: 0,
                    rotate: Math.random() * 360 
                  }}
                  transition={{ duration: 2, ease: "easeOut" }}
                  className="absolute w-3 h-3 rounded-sm"
                  style={{ backgroundColor: ['#ff6600', '#000', '#fff'][i % 3] }}
                />
             ))}
          </motion.div>
        )}
      </AnimatePresence>

      {/* Dynamic Mini Map - High Fidelity 2D Mode */}
      <div className="h-[300px] md:h-[350px] bg-slate-900 relative overflow-hidden">
        {/* Background Map Graphic */}
        <div className="absolute inset-0 opacity-40">
           <svg viewBox="0 0 100 100" className="w-full h-full">
              {/* Simplified Conakry Path */}
              <path 
                d="M 5 95 Q 15 90 20 80 Q 25 70 35 65 Q 45 60 55 40 Q 65 30 80 30 Q 95 30 95 40 L 95 50 Q 80 55 70 65 Q 60 75 45 85 Q 35 95 15 100 L 5 95" 
                fill="none" 
                stroke="white" 
                strokeWidth="0.2" 
                strokeDasharray="1 1"
              />
              {/* Grid dots */}
              {[...Array(10)].map((_, i) => (
                [...Array(10)].map((_, j) => (
                  <circle key={`${i}-${j}`} cx={i * 10} cy={j * 10} r="0.1" fill="white" opacity="0.3" />
                ))
              ))}
           </svg>
        </div>
        
        <div className="absolute inset-0">
           <svg viewBox="0 0 100 100" className="w-full h-full p-12">
              {/* Path line if active */}
              {activeStep >= 3 && (
                <motion.line 
                  x1={originPos.x} y1={originPos.y} 
                  x2={courierMapPos.x} y2={courierMapPos.y} 
                  stroke="#ff6600" 
                  strokeWidth="0.8" 
                  strokeDasharray="2 2"
                  initial={{ pathLength: 0 }}
                  animate={{ pathLength: 1 }}
                />
              )}

              {/* Vendor Landmark */}
              <g transform={`translate(${originPos.x - 5}, ${originPos.y - 12})`}>
                <rect width="10" height="24" rx="5" fill="rgba(255,255,255,0.05)" />
                <foreignObject width="10" height="10" x="0" y="0">
                  <div className="w-10 h-10 bg-white/10 dark:bg-white/20 backdrop-blur-md border border-white/20 rounded-xl flex items-center justify-center">
                    <Package className="w-4 h-4 text-white" />
                  </div>
                </foreignObject>
              </g>

              {/* Destination Landmark */}
              <g transform={`translate(${destPos.x - 5}, ${destPos.y - 12})`}>
                <motion.circle 
                  cx="5" cy="5" r="10" 
                  fill="rgba(255,102,0,0.15)" 
                  animate={{ scale: [1, 1.5, 1], opacity: [0.3, 0.1, 0.3] }}
                  transition={{ duration: 2, repeat: Infinity }}
                />
                <foreignObject width="10" height="10" x="0" y="0">
                  <div className="w-10 h-10 bg-[#ff6600] border-2 border-white rounded-xl flex items-center justify-center shadow-lg shadow-[#ff6600]/40">
                    <MapPin className="w-5 h-5 text-white" />
                  </div>
                </foreignObject>
                <text x="5" y="18" textAnchor="middle" className="text-[3px] font-bold fill-white tracking-widest uppercase">{quartier}</text>
              </g>

              {/* Moving Courier */}
              <motion.g
                animate={{ 
                  x: activeStep >= 4 ? courierMapPos.x - 5 : originPos.x - 5,
                  y: activeStep >= 4 ? courierMapPos.y - 5 : originPos.y - 5
                }}
                transition={{ type: "spring", stiffness: 50, damping: 20 }}
              >
                <foreignObject width="10" height="10">
                  <div className={`w-10 h-10 rounded-xl flex items-center justify-center text-white shadow-2xl transition-all duration-1000 ${
                    activeStep >= 4 ? 'bg-[#ff6600] scale-110 rotate-0' : 'bg-gray-500 scale-90 -rotate-12 opacity-50'
                  }`}>
                    <Navigation className="w-5 h-5" style={{ transform: `rotate(${activeStep >= 4 ? 90 : 0}deg)` }} />
                  </div>
                </foreignObject>
                {activeStep >= 4 && (
                  <text x="5" y="-4" textAnchor="middle" className="text-[3px] font-black fill-[#ff6600] tracking-tighter uppercase animate-pulse">Livreur en mouvement</text>
                )}
              </motion.g>
           </svg>
        </div>

        {/* ETA Widget */}
        <div className="absolute bottom-4 right-4 md:bottom-8 md:right-8 flex flex-col gap-3">
          <div className="bg-gray-900 text-brand-inverse p-4 md:p-6 rounded-[1.5rem] md:rounded-[2rem] shadow-2xl flex items-center gap-4">
             <div className="w-10 h-10 md:w-12 md:h-12 bg-white/10 rounded-xl flex items-center justify-center">
                <Timer className="w-5 h-5 md:w-6 md:h-6 text-[#ff6600] animate-pulse" />
             </div>
             <div>
                <p className="text-[10px] md:text-[11px] font-bold tracking-wider text-white/50 leading-none mb-1 md:mb-1.5">Estimation</p>
                <p className="text-[14px] md:text-[18px] font-bold italic">
                  {orderStatus === 'delivered'
                    ? 'Livré ✓'
                    : activeStep < 2
                    ? 'Calcul en cours...'
                    : computedEta !== null
                    ? `${computedEta} min`
                    : activeStep > 4 ? '1 - 3 min' : '14 - 22 min'}
                </p>
             </div>
          </div>
        </div>
      </div>

      <div className="p-6 md:p-10">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 md:mb-12 gap-6">
          <div>
            <h3 className="text-xl md:text-2xl font-bold text-gray-900 dark:text-white tracking-tight flex items-center gap-2 md:gap-3">
              Suivi de Commande <span className="text-[14px] md:text-[16px] text-brand-text-dim opacity-50 font-medium">#{orderId.slice(0, 8)}</span>
            </h3>
            <p className="text-[11px] md:text-[12px] font-bold text-[#ff6600] tracking-wider mt-1">En cours de traitement • {region}</p>
          </div>
          <button className="flex items-center gap-2 bg-gray-50/50 px-6 py-3 rounded-full hover:bg-gray-50 dark:bg-gray-800 transition-colors group">
            <span className="text-[10px] md:text-[11px] font-bold tracking-wider text-gray-900 dark:text-white">Détails Colis</span>
            <ChevronRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
          </button>
        </div>

        {/* Timeline Steps */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 md:gap-8 mb-12">
          {steps.map((step, idx) => (
            <div key={idx} className="relative group">
              <div className="flex md:flex-col items-center gap-4 md:gap-4 text-left md:text-center">
                <div className={`w-12 h-12 md:w-16 md:h-16 rounded-[1.25rem] md:rounded-[1.5rem] flex items-center justify-center transition-all duration-500 shadow-sm ${
                  step.status === 'complete' ? 'bg-green-500 text-white shadow-green-100' :
                  step.status === 'active' ? 'bg-[#ff6600] text-white shadow-[#ff6600]/20 scale-110 drop-shadow-xl' :
                  'bg-gray-50 dark:bg-gray-800 text-brand-text-dim'
                }`}>
                  {step.status === 'complete' ? <CheckCircle2 className="w-6 h-6" /> : <step.icon className="w-6 h-6" />}
                </div>
                <div>
                   <h4 className={`text-[12px] md:text-[13px] font-bold tracking-wider ${step.status === 'upcoming' ? 'text-brand-text-dim' : 'text-gray-900 dark:text-white'}`}>
                     {step.label}
                   </h4>
                   <p className="text-[10px] md:text-[11px] font-bold text-brand-text-muted">{step.sub}</p>
                </div>
              </div>
              
              {/* Connector line for desktop */}
              {idx < 3 && (
                <div className="hidden md:block absolute top-[32px] left-[calc(50%+40px)] w-[calc(100%-80px)] h-[2px] bg-brand-border/30">
                  <motion.div 
                    className="h-full bg-green-500" 
                    initial={{ width: '0%' }}
                    animate={{ width: step.status === 'complete' ? '100%' : '0%' }}
                  />
                </div>
              )}
            </div>
          ))}
        </div>

        {/* Courier / Driver Section */}
        <div className="p-4 md:p-8 bg-gray-50/30 border border-brand-border/20 rounded-[2rem] md:rounded-[2.5rem] flex flex-col sm:flex-row items-center justify-between gap-6">
          {fulfillmentType === 'vendor_self_delivery' && selfDeliveryDriver ? (
            /* Self-Delivery: show internal rider details */
            <>
              <div className="flex items-center gap-4 md:gap-6 w-full sm:w-auto">
                <div className="w-16 h-16 md:w-20 md:h-20 bg-emerald-500/10 border border-emerald-500/20 rounded-2xl md:rounded-[1.5rem] flex items-center justify-center shrink-0">
                  <Store className="w-8 h-8 text-emerald-500" />
                </div>
                <div className="flex-1">
                  <div className="flex flex-wrap items-center gap-2 mb-1">
                    <span className="px-2.5 py-1 text-[9px] font-black tracking-widest uppercase bg-emerald-500/10 text-emerald-600 rounded-full border border-emerald-500/20">
                      Livraison assurée par la boutique
                    </span>
                  </div>
                  <h4 className="text-[14px] md:text-[16px] font-bold text-gray-900 dark:text-white tracking-tight">
                    {selfDeliveryDriver.name || 'Livreur de la boutique'}
                  </h4>
                  {selfDeliveryDriver.plate && (
                    <div className="flex items-center gap-1.5 mt-1">
                      <Car className="w-3.5 h-3.5 text-gray-400" />
                      <span className="text-[11px] font-black text-gray-500 dark:text-gray-400 tracking-widest">
                        Plaque: {selfDeliveryDriver.plate}
                      </span>
                    </div>
                  )}
                </div>
              </div>
              <div className="flex w-full sm:w-auto gap-3">
                <button
                  disabled={!selfDeliveryDriver.phone}
                  onClick={() => {
                    if (selfDeliveryDriver.phone) window.location.href = `tel:${selfDeliveryDriver.phone}`;
                  }}
                  className={`flex-1 sm:flex-none flex items-center justify-center gap-3 px-6 md:px-10 py-3 md:py-4 rounded-full text-[11px] md:text-[12px] font-bold tracking-wider transition-all shadow-xl ${
                    selfDeliveryDriver.phone
                      ? 'bg-emerald-500 text-white hover:bg-emerald-400 shadow-emerald-500/20'
                      : 'bg-brand-border text-brand-text-dim cursor-not-allowed'
                  }`}
                >
                  <Phone className="w-4 h-4" /> Appeler
                </button>
              </div>
            </>
          ) : (
            /* Fatibara Courier / platform delivery */
            <>
              <div className="flex items-center gap-4 md:gap-6 w-full sm:w-auto">
                <div className={`w-16 h-16 md:w-20 md:h-20 rounded-2xl md:rounded-[1.5rem] overflow-hidden shadow-md shrink-0 transition-all duration-500 ${
                  courierInfo
                    ? 'border border-white bg-brand-border/30'
                    : 'border-2 border-[#ff6600]/60 bg-gradient-to-br from-[#ff6600]/10 to-[#ff6600]/5'
                }`}>
                   <img
                     src={courierInfo?.avatar_url || AISATA_AVATAR_URL}
                     alt={courierInfo ? 'Photo du livreur' : 'Aisata — Assistante Fatibara'}
                     className="w-full h-full object-cover"
                     referrerPolicy="no-referrer"
                   />
                </div>
                <div>
                   <div className="flex items-center gap-2 mb-1">
                     <h4 className="text-[14px] md:text-[16px] font-bold text-gray-900 dark:text-white tracking-tight">
                        {courierInfo?.full_name || 'Livreur en approche'}
                     </h4>
                     {courierInfo?.courier_rating > 0 && (
                       <div className="flex items-center gap-1 bg-yellow-100 text-yellow-700 px-2 py-0.5 rounded-full text-[9px] font-bold">
                          <Star className="w-3 h-3 fill-yellow-700" />
                          {Number(courierInfo.courier_rating).toFixed(1)}
                       </div>
                     )}
                   </div>
                   <p className="text-[10px] md:text-[11px] font-bold text-brand-text-muted uppercase tracking-[1px]">
                      {courierInfo
                        ? [
                            courierInfo.vehicle_type === 'motorcycle' ? '🏍️ Moto' :
                            courierInfo.vehicle_type === 'car'        ? '🚗 Voiture' :
                            courierInfo.vehicle_type === 'bicycle'    ? '🚲 Vélo' :
                            courierInfo.vehicle_type === 'foot'       ? '🚶 À Pied' : '',
                            courierInfo.license_plate_number ? `• ${courierInfo.license_plate_number}` : '',
                          ].filter(Boolean).join(' ') || 'Partenaire Certifié'
                        : 'Assignation en cours...'}
                   </p>
                </div>
              </div>
              
              <div className="flex w-full sm:w-auto gap-3">
                 {/* Call button: rings courier if assigned, otherwise rings support */}
                 <button
                   onClick={() => {
                     hapticFeedback('light');
                     const tel = courierInfo?.phone ?? livePhone;
                     window.location.href = `tel:${tel}`;
                   }}
                   className="flex-1 sm:flex-none flex items-center justify-center gap-3 px-6 md:px-10 py-3 md:py-4 rounded-full text-[11px] md:text-[12px] font-bold tracking-wider transition-all shadow-xl bg-gray-900 text-white hover:bg-black shadow-brand-foreground/10 active:scale-95"
                 >
                   <Phone className="w-4 h-4" />
                   {courierInfo ? 'Appeler livreur' : 'Appeler support'}
                 </button>

                 {/* WhatsApp button — opens pre-filled message to Fatibara support */}
                 <a
                   href={`https://wa.me/${liveWhatsapp}?text=${encodeURIComponent(
                     `Bonjour Fatibara ! 👋%0A` +
                     `J'ai passé une commande et souhaite un suivi.%0A%0A` +
                     `📦 Commande : ${orderId}%0A` +
                     `📍 Livraison : ${region}${quartier ? `, ${quartier}` : ''}%0A%0A` +
                     `Merci !`
                   )}`}
                   target="_blank"
                   rel="noopener noreferrer"
                   onClick={() => hapticFeedback('light')}
                   className="flex-1 sm:flex-none flex items-center justify-center gap-2.5 px-6 md:px-8 py-3 md:py-4 rounded-full text-[11px] md:text-[12px] font-bold tracking-wider transition-all shadow-xl active:scale-95"
                   style={{ backgroundColor: '#25D366', color: '#fff' }}
                 >
                   {/* WhatsApp SVG icon */}
                   <svg viewBox="0 0 24 24" className="w-4 h-4 fill-white shrink-0" xmlns="http://www.w3.org/2000/svg">
                     <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z"/>
                   </svg>
                   WhatsApp
                 </a>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
