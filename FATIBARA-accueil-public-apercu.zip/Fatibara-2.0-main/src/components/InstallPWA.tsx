import { Download } from 'lucide-react';
import { useStore } from '../store/useStore';
import { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { showInstallModal } from './PWAInstallModal';

// Store the deferred prompt globally outside React state to avoid proxy/freeze issues
let deferredPrompt: any = null;

export const triggerInstallPrompt = async (): Promise<boolean> => {
  if (deferredPrompt) {
    try {
      await deferredPrompt.prompt();
      const { outcome } = await deferredPrompt.userChoice;
      if (outcome === 'accepted') {
        deferredPrompt = null;
        return true;
      }
    } catch (err) {
      console.error('PWA: Error during native prompt:', err);
    }
    return false;
  }

  // Native prompt not available → show our beautiful instruction modal instead
  showInstallModal();
  return false;
};

export default function InstallPWA() {
  const { modeEconomie } = useStore();
  const [isInstalled, setIsInstalled] = useState(false);
  const [canInstall, setCanInstall] = useState(false);

  useEffect(() => {
    // Check if already running as installed PWA
    if (
      window.matchMedia('(display-mode: standalone)').matches ||
      (navigator as any).standalone === true
    ) {
      setIsInstalled(true);
      return;
    }

    const handleBeforeInstallPrompt = (e: any) => {
      e.preventDefault();
      deferredPrompt = e;
      setCanInstall(true);
    };

    const handleAppInstalled = () => {
      setIsInstalled(true);
      deferredPrompt = null;
      setCanInstall(false);
    };

    window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
    window.addEventListener('appinstalled', handleAppInstalled);

    return () => {
      window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
      window.removeEventListener('appinstalled', handleAppInstalled);
    };
  }, []);

  if (!canInstall || isInstalled) return null;

  return (
    <AnimatePresence>
      <motion.button
        initial={{ opacity: modeEconomie ? 1 : 0, scale: modeEconomie ? 1 : 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: modeEconomie ? 1 : 0, scale: modeEconomie ? 1 : 0.9 }}
        transition={{ duration: modeEconomie ? 0 : 0.3 }}
        onClick={async () => {
          const success = await triggerInstallPrompt();
          if (success) setCanInstall(false);
        }}
        className="flex items-center gap-2 bg-gray-900 text-brand-inverse px-4 py-2 rounded-full text-[13px] font-bold tracking-wider hover:bg-black transition-all hover:scale-105 shadow-xl shadow-brand-foreground/10"
      >
        <Download className="w-4 h-4" />
        <span className="hidden sm:inline">Installer l'application</span>
        <span className="sm:hidden">Installer</span>
      </motion.button>
    </AnimatePresence>
  );
}
