import React, { useState, useEffect, useRef, useMemo } from 'react';
import { MessageSquare, Send, X, User, Store, ShieldCheck, MoreVertical, Search, CheckCircle2, Check, Loader2, Image as ImageIcon, Camera, Plus, Paperclip, ChevronDown, AlertTriangle, Share2, ShoppingBag, Zap, Smartphone } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { supabase } from '../lib/supabase';
import { APP_NAME } from '../lib/constants';
import { realtimeKey } from '../lib/realtimeKeys';
import { useAppContext } from '../context/AppContext';
import { useToast } from '../context/ToastContext';
import { safeNotify } from '../utils/notifications';

// Recommendation 5: moved outside component so the array is not re-created on every render
const SENSITIVE_PATTERNS = [
  /(\+?224[-.\s]?)?[6][12356][-.\s]?\d{2}[-.\s]?\d{2}[-.\s]?\d{2}/g, // Guinean numbers
  /\b(whatsapp|facebook|fb|insta|instagram|numero|téléphone|appel|orange money|momo|payement dehors)\b/gi,
];

interface Message {
  id: string;
  channel_id: string;
  sender_id: string;
  message: string;
  metadata?: any;
  image_url?: string;
  created_at: string;
  is_read?: boolean;
}

interface Conversation {
  id: string;
  buyer_id: string;
  store_id: string;
  last_message: string;
  last_message_at: string;
  product_id?: string;
  stores?: {
    store_name: string;
    avatar_url: string;
    is_verified_store?: boolean;
    owner_id: string;
  };
  buyer_profile?: {
    full_name: string;
    avatar_url: string;
  };
  product?: {
    title: string;
    image_urls: string[];
    price_gnf: number;
  };
}

interface ChatMessengerProps {
  isOpen: boolean;
  onClose: () => void;
  initialStoreId?: string;
  initialUserId?: string;
}

export default function ChatMessenger({ isOpen, onClose, initialStoreId, initialUserId }: ChatMessengerProps) {
  const { user } = useAppContext();
  const { showToast } = useToast();
  const [messages, setMessages] = useState<Message[]>([]);
  const [newMessage, setNewMessage] = useState('');
  const [chats, setChats] = useState<Conversation[]>([]);
  const [activeChat, setActiveChat] = useState<Conversation | null>(null);
  const [loading, setLoading] = useState(false);
  const [uploading, setUploading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [showScrollBottom, setShowScrollBottom] = useState(false);
  const [isTyping, setIsTyping] = useState(false);
  const [securityWarning, setSecurityWarning] = useState<string | null>(null);
  // Ref to track current activeChat.id without causing subscription re-runs (Fix 5)
  const activeChatIdRef = useRef<string | null>(null);
  // Ref to guard async callbacks after unmount (Fix 6)
  const isMountedRef = useRef(true);
  // Presence & pagination
  const [isOtherPartyOnline, setIsOtherPartyOnline] = useState(false);
  const [hasMoreMessages, setHasMoreMessages] = useState(false);
  const [loadingMore, setLoadingMore] = useState(false);
  const presenceChannelRef = useRef<any>(null);

  useEffect(() => {
    isMountedRef.current = true;
    return () => { isMountedRef.current = false; };
  }, []);

  // Fix #23: reset active conversation on close so the next open() starts fresh
  const handleClose = () => {
    setActiveChat(null);
    setShowSearch(false);
    setSearchQuery('');
    onClose();
  };

  // isTyping is kept for future Supabase Realtime Presence integration.
  // The fake setTimeout was removed — it was entirely simulated and misleading.

  const scanForSensitiveContent = (text: string) => {
    const hasSensitive = SENSITIVE_PATTERNS.some(pattern => pattern.test(text));
    if (hasSensitive) {
      setSecurityWarning(`Par souci de sécurité, n'échangez jamais vos coordonnées personnelles ou de paiement en dehors de ${APP_NAME}. Seuls les paiements via l'application sont protégés par notre garantie.`);
    } else {
      setSecurityWarning(null);
    }
  };

  useEffect(() => {
    scanForSensitiveContent(newMessage);
  }, [newMessage]);

  // Fix #22: use ISO date string (YYYY-MM-DD) as key — locale-independent
  const groupedMessages = useMemo(() => {
    const groups: { [key: string]: Message[] } = {};
    messages.forEach(msg => {
      const date = new Date(msg.created_at).toISOString().split('T')[0];
      if (!groups[date]) groups[date] = [];
      groups[date].push(msg);
    });
    return groups;
  }, [messages]);

  // Fix #15: search state for customer conversation list
  const [showSearch, setShowSearch] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  const filteredChats = useMemo(() => {
    if (!searchQuery.trim()) return chats;
    const q = searchQuery.toLowerCase();
    return chats.filter(c =>
      (c.stores?.store_name || '').toLowerCase().includes(q) ||
      (c.last_message || '').toLowerCase().includes(q)
    );
  }, [chats, searchQuery]);

  const handleScroll = (e: React.UIEvent<HTMLDivElement>) => {
    const { scrollTop, scrollHeight, clientHeight } = e.currentTarget;
    setShowScrollBottom(scrollHeight - scrollTop - clientHeight > 300);
  };

  const scrollToBottom = () => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: 'smooth' });
  };

  // Fix #22: parse ISO date key (YYYY-MM-DD) instead of locale string
  const isToday = (dateStr: string) => {
    return dateStr === new Date().toISOString().split('T')[0];
  };

  const formatDateHeader = (dateStr: string) => {
    if (isToday(dateStr)) return "Aujourd'hui";
    const [year, month, day] = dateStr.split('-');
    return `${day}/${month}/${year}`;
  };

  const QUICK_REPLIES = [
    "C'est disponible ?",
    "Le prix est négociable ?",
    "Où se trouve votre boutique ?",
    "Quel est le délai de livraison ?",
    "Je suis intéressé par ce produit."
  ];

  // Fetch Conversations
  useEffect(() => {
    if (!user || !isOpen) return;

    async function fetchChats(retryCount = 0) {
      setLoading(true);
      try {
        const { data: ownedStores } = await supabase
          .from('stores')
          .select('id')
          .eq('owner_id', user.id);
        
        const storeIds = ownedStores?.map(s => s.id) || [];

        const query = supabase
          .from('chat_channels')
          .select(`
            *,
            stores (
              store_name,
              avatar_url,
              is_verified_store,
              owner_id
            ),
            product:product_id (
              title,
              image_urls,
              price_gnf
            )
          `);

        if (storeIds.length > 0) {
          query.or(`buyer_id.eq.${user.id},store_id.in.(${storeIds.join(',')})`);
        } else {
          query.eq('buyer_id', user.id);
        }

        const { data, error } = await query.order('last_message_at', { ascending: false });

        if (error) throw error;

        if (data) {
          // Fetch buyer profiles separately to avoid PostgREST FK-alias issues
          // with 'buyer_profile:buyer_id' syntax
          const uniqueBuyerIds = [...new Set(data.map((c: any) => c.buyer_id).filter(Boolean))];
          let profilesMap: Record<string, { full_name: string; avatar_url: string }> = {};
          if (uniqueBuyerIds.length > 0) {
            const { data: profilesData } = await supabase
              .from('profiles')
              .select('id, full_name, avatar_url')
              .in('id', uniqueBuyerIds);
            if (profilesData) {
              profilesMap = Object.fromEntries(profilesData.map((p: any) => [p.id, p]));
            }
          }

          // Merge profiles into channel data
          const dataWithProfiles = data.map((chat: any) => ({
            ...chat,
            buyer_profile: chat.buyer_id ? profilesMap[chat.buyer_id] || null : null,
          }));

          // Single batch query for all unread counts (eliminates N+1)
          const channelIds = dataWithProfiles.map(c => c.id);
          let unreadMap: Record<string, number> = {};
          if (channelIds.length > 0) {
            const { data: unreadRows } = await supabase
              .from('chat_messages')
              .select('channel_id')
              .in('channel_id', channelIds)
              .eq('is_read', false)
              .neq('sender_id', user.id);
            unreadRows?.forEach((row: any) => {
              unreadMap[row.channel_id] = (unreadMap[row.channel_id] || 0) + 1;
            });
          }
          const mappedData = dataWithProfiles.map(chat => ({
            ...chat,
            unread_count: unreadMap[chat.id] || 0
          }));

          setChats(mappedData as Conversation[]);
          
          if (initialStoreId) {
            // BUG FIX: was c.user_id (doesn't exist) → c.buyer_id
            // Also: use mappedData (has profiles) not raw data
            const existing = mappedData.find(c =>
              c.store_id === initialStoreId &&
              (!initialUserId || (c as any).buyer_id === initialUserId || (c as any).buyer_id === user.id)
            );
            if (existing) {
              setActiveChat(existing as any);
            }
          } else if (mappedData.length > 0 && !activeChat) {
            setActiveChat(mappedData[0] as any);
          }
        }
      } catch (err) {
        console.error("Error fetching chats", err);
        if (retryCount < 3 && isMountedRef.current) {
          const delay = Math.pow(2, retryCount) * 1000;
          setTimeout(() => fetchChats(retryCount + 1), delay);
        } else {
          showToast("Erreur lors du chargement des conversations", "error");
        }
      } finally {
        if (isMountedRef.current) {
          setLoading(false);
        }
      }
    }

    fetchChats();
  }, [user, isOpen, initialStoreId, initialUserId]);

  // Handle focus on initial store/user if isOpen changes
  useEffect(() => {
    if (isOpen && initialStoreId && chats.length > 0) {
      const existing = chats.find(c =>
        c.store_id === initialStoreId &&
        (!initialUserId || (c as any).buyer_id === initialUserId || (c as any).buyer_id === user?.id)
      );
      if (existing) {
        setActiveChat(existing);
      }
    }
  }, [isOpen, initialStoreId, initialUserId, chats]);

  // Keep activeChatIdRef in sync so subscription callbacks never use a stale closure (Fix 5)
  useEffect(() => {
    activeChatIdRef.current = activeChat?.id ?? null;
  }, [activeChat?.id]);

  // Fetch Messages + Subscription
  useEffect(() => {
    if (!activeChat) return;

    const PAGE_SIZE = 50;

    async function fetchMessages() {
      // Fetch newest 50 messages first (DESC), then reverse for chronological display
      const { data, error } = await supabase
        .from('chat_messages')
        .select('*')
        .eq('channel_id', activeChat.id)
        .order('created_at', { ascending: false })
        .limit(PAGE_SIZE);

      if (!error && data) {
        const msgs = [...data].reverse();
        setMessages(msgs);
        setHasMoreMessages(data.length === PAGE_SIZE);

        // Mark as read
        const unreadIds = data
          .filter(m => m.sender_id !== user?.id && !m.is_read)
          .map(m => m.id);

        if (unreadIds.length > 0) {
          await supabase
            .from('chat_messages')
            .update({ is_read: true })
            .in('id', unreadIds);
        }
      }
    }

    fetchMessages();

    const channel = supabase
      .channel(realtimeKey.chat(activeChat.id))
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'chat_messages',
          filter: `channel_id=eq.${activeChat.id}`
        },
        (payload) => {
          const newMsg = payload.new as Message;
          setMessages(prev => {
            if (prev.some(m => m.id === newMsg.id)) return prev;
            return [...prev, newMsg];
          });
          
          // Use ref instead of stale closure to get current activeChat.id (Fix 5)
          if (newMsg.sender_id !== user?.id) {
            setChats(prev => prev.map(c =>
              c.id === newMsg.channel_id
                ? { ...c, unread_count: (activeChatIdRef.current === c.id) ? 0 : ((c as any).unread_count + 1), last_message_at: newMsg.created_at }
                : c
            ));
          }
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [activeChat?.id, user?.id]);

  // Load older messages (cursor-based, prepend to list)
  const loadMoreMessages = async () => {
    if (!activeChat || messages.length === 0 || loadingMore) return;
    setLoadingMore(true);
    const oldest = messages[0].created_at;
    const { data } = await supabase
      .from('chat_messages')
      .select('*')
      .eq('channel_id', activeChat.id)
      .lt('created_at', oldest)
      .order('created_at', { ascending: false })
      .limit(50);
    if (data) {
      const older = [...data].reverse();
      setMessages(prev => [...older, ...prev]);
      setHasMoreMessages(data.length === 50);
    }
    setLoadingMore(false);
  };

  // Supabase Realtime Presence — show who is currently viewing this conversation
  useEffect(() => {
    if (!activeChat || !user) {
      setIsOtherPartyOnline(false);
      return;
    }

    const isVendor = (activeChat as any).stores?.owner_id === user.id;
    const otherPartyId = isVendor
      ? activeChat.buyer_id
      : (activeChat as any).stores?.owner_id;

    const ch = supabase.channel(`presence:chat:${activeChat.id}`, {
      config: { presence: { key: user.id } }
    });

    ch.on('presence', { event: 'sync' }, () => {
      const state = ch.presenceState() as Record<string, { user_id: string }[]>;
      const online = Object.keys(state).some(k => k === otherPartyId);
      if (isMountedRef.current) setIsOtherPartyOnline(online);
    })
    .subscribe(async (status) => {
      if (status === 'SUBSCRIBED') {
        await ch.track({ user_id: user.id });
      }
    });

    presenceChannelRef.current = ch;
    return () => {
      ch.untrack();
      supabase.removeChannel(ch);
      presenceChannelRef.current = null;
      setIsOtherPartyOnline(false);
    };
  }, [activeChat?.id, user?.id]);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSend = async (e?: React.FormEvent, contentOverride?: string) => {
    if (e) e.preventDefault();
    const content = contentOverride || newMessage;
    if (!content.trim() || !user || !activeChat) return;

    if (!contentOverride) setNewMessage('');

    try {
      const { data: insertedMsg, error } = await supabase
        .from('chat_messages')
        .insert([
          {
            channel_id: activeChat.id,
            sender_id: user.id,
            message: content
          }
        ])
        .select()
        .single();

      if (error) throw error;

      // Fix #3/#20: persist last_message so conversation previews update correctly
      const preview = content.length > 80 ? content.substring(0, 77) + '\u2026' : content;
      await supabase
        .from('chat_channels')
        .update({
          last_message_at: new Date().toISOString(),
          last_message: preview
        })
        .eq('id', activeChat.id);

      // Optimistic local update of conversation list preview
      setChats(prev => prev.map(c =>
        c.id === activeChat.id
          ? { ...c, last_message: preview, last_message_at: new Date().toISOString() }
          : c
      ));

      // Notification
      const isVendorMessage = (activeChat as any).stores?.owner_id === user.id;
      const recipientId = isVendorMessage ? activeChat.buyer_id : (activeChat as any).stores?.owner_id;

      // Fix #6: auto-reply is intentionally NOT done client-side.
      // Inserting with sender_id = owner_id while authenticated as the buyer
      // violates RLS (sender_id = auth.uid()). Auto-replies must be handled
      // via a Supabase Database Trigger or Edge Function.

      if (recipientId) {
        await safeNotify({
          user_id: recipientId,
          type: 'message',
          title: isVendorMessage ? `Message de ${(activeChat as any).stores?.store_name}` : `Message de ${(activeChat as any).buyer_profile?.full_name || 'un client'}`,
          message: content.length > 50 ? content.substring(0, 47) + '...' : content
        });
      }
    } catch (err: any) {
      console.error("Error sending message", err);
      showToast(err.message || "Erreur d'envoi", "error");
    }
  };

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !user || !activeChat) return;

    // Fix #10: validate file type and size before uploading
    const MAX_SIZE = 5 * 1024 * 1024; // 5 MB
    const ALLOWED_TYPES = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
    if (!ALLOWED_TYPES.includes(file.type)) {
      showToast('Format non supporté. Utilisez JPG, PNG, GIF ou WebP.', 'error');
      return;
    }
    if (file.size > MAX_SIZE) {
      showToast("L'image ne doit pas dépasser 5 Mo.", 'error');
      return;
    }

    setUploading(true);
    try {
      // Fix #8: use crypto.randomUUID() to prevent filename collisions
      const fileExt = file.name.split('.').pop()?.toLowerCase() || 'jpg';
      const fileName = `${user.id}/${crypto.randomUUID()}.${fileExt}`;
      const filePath = `chat_images/${fileName}`;

      const { error: uploadError } = await supabase.storage
        .from('chat-images')
        .upload(filePath, file);

      if (uploadError) throw uploadError;

      const { data: { publicUrl } } = supabase.storage
        .from('chat-images')
        .getPublicUrl(filePath);

      const { error: msgError } = await supabase
        .from('chat_messages')
        .insert([
          {
            channel_id: activeChat.id,
            sender_id: user.id,
            message: 'Photo envoyée',
            image_url: publicUrl
          }
        ]);

      if (msgError) throw msgError;
      // DB trigger handles last_message_at update automatically

    } catch (err: any) {
      console.error("Error uploading image", err);
      showToast(err.message || "Erreur lors de l'envoi de l'image.", "error");
    } finally {
      setUploading(false);
    }
  };


  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Backdrop (mobile) */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={handleClose}
            className="fixed inset-0 z-[90] lg:hidden bg-black/50 backdrop-blur-sm"
          />

          {/* Panel */}
          <motion.div
            initial={{ opacity: 0, y: 40, scale: 0.97 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 40, scale: 0.97 }}
            transition={{ type: 'spring', stiffness: 260, damping: 26 }}
            className="fixed inset-0 lg:inset-auto lg:bottom-24 lg:right-6 xl:right-10 w-full lg:w-[920px] lg:h-[680px] bg-white dark:bg-gray-900 lg:border lg:border-gray-200 dark:lg:border-white/10 lg:shadow-2xl lg:rounded-[2rem] overflow-hidden z-[10002] flex flex-col lg:flex-row"
          >

            {/* ── CONVERSATION LIST ─────────────────────────────────────────── */}
            <div className={`lg:w-[300px] shrink-0 border-r border-gray-100 dark:border-white/5 bg-gray-50 dark:bg-gray-950 flex flex-col ${(activeChat || (initialStoreId && loading)) ? 'hidden lg:flex' : 'flex-1 lg:flex'}`}>

              {/* List header */}
              <div className="px-4 pt-12 pb-4 lg:pt-4 border-b border-gray-100 dark:border-white/5">
                <div className="flex items-center justify-between mb-3">
                  <h3 className="text-sm font-black text-gray-900 dark:text-white tracking-tight">Messages</h3>
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => { setShowSearch(v => !v); setSearchQuery(''); }}
                      className={`w-8 h-8 rounded-xl flex items-center justify-center transition-all ${showSearch ? 'bg-orange-100 dark:bg-orange-900/30 text-orange-500' : 'bg-white dark:bg-white/5 border border-gray-200 dark:border-white/10 text-gray-500 hover:text-orange-500'}`}
                    >
                      <Search className="w-4 h-4" />
                    </button>
                    <button
                      onClick={handleClose}
                      className="lg:hidden w-8 h-8 rounded-xl bg-white dark:bg-white/5 border border-gray-200 dark:border-white/10 flex items-center justify-center text-gray-500 hover:text-gray-900 dark:hover:text-white transition-all"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                </div>
                {showSearch && (
                  <input
                    autoFocus
                    type="text"
                    value={searchQuery}
                    onChange={e => setSearchQuery(e.target.value)}
                    placeholder="Rechercher..."
                    className="w-full px-3 py-2 rounded-xl bg-white dark:bg-white/5 border border-gray-200 dark:border-white/10 text-sm text-gray-900 dark:text-white placeholder-gray-400 focus:outline-none focus:border-orange-400 transition-colors"
                  />
                )}
              </div>

              {/* Chat list */}
              <div className="flex-1 overflow-y-auto">
                {loading && !initialStoreId ? (
                  <div className="flex flex-col items-center justify-center py-16 gap-3 opacity-50">
                    <Loader2 className="w-6 h-6 animate-spin text-orange-500" />
                    <span className="text-xs font-bold text-gray-400 uppercase tracking-widest">Chargement...</span>
                  </div>
                ) : filteredChats.length > 0 ? filteredChats.map(chat => {
                  const isVendor = (chat as any).stores?.owner_id === user?.id;
                  const partnerName = isVendor
                    ? ((chat as any).buyer_profile?.full_name || 'Client')
                    : (chat.stores?.store_name || 'Boutique');
                  const partnerAvatar = isVendor
                    ? (chat as any).buyer_profile?.avatar_url
                    : chat.stores?.avatar_url;
                  const unread = (chat as any).unread_count || 0;
                  const isActive = activeChat?.id === chat.id;
                  return (
                    <button
                      key={chat.id}
                      onClick={() => setActiveChat(chat)}
                      className={`w-full px-4 py-3.5 flex gap-3 text-left transition-all border-r-2 ${isActive ? 'bg-orange-50 dark:bg-orange-950/20 border-orange-500' : 'hover:bg-white dark:hover:bg-white/5 border-transparent'}`}
                    >
                      {/* Avatar */}
                      <div className="relative shrink-0">
                        <div className="w-11 h-11 rounded-full overflow-hidden bg-gradient-to-br from-gray-700 to-gray-900 flex items-center justify-center font-bold text-sm text-white border border-gray-200 dark:border-white/5">
                          {partnerAvatar
                            ? <img src={partnerAvatar} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                            : partnerName.charAt(0).toUpperCase()
                          }
                        </div>
                        {unread > 0 && (
                          <div className="absolute -top-0.5 -right-0.5 min-w-[18px] h-[18px] px-1 bg-orange-500 text-white text-[10px] font-black rounded-full flex items-center justify-center shadow-sm">
                            {unread > 9 ? '9+' : unread}
                          </div>
                        )}
                      </div>
                      {/* Text */}
                      <div className="flex-1 min-w-0">
                        <div className="flex justify-between items-start gap-1 mb-0.5">
                          <span className={`text-[13px] truncate ${isActive ? 'font-black text-orange-600 dark:text-orange-400' : unread > 0 ? 'font-black text-gray-900 dark:text-white' : 'font-semibold text-gray-800 dark:text-gray-200'}`}>
                            {partnerName}
                          </span>
                          <span className="text-[10px] text-gray-400 whitespace-nowrap shrink-0">
                            {chat.last_message_at
                              ? new Date(chat.last_message_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
                              : ''}
                          </span>
                        </div>
                        <p className={`text-[12px] truncate ${unread > 0 ? 'text-gray-700 dark:text-gray-200 font-medium' : 'text-gray-400 dark:text-gray-500'}`}>
                          {chat.last_message || 'Démarrer la discussion…'}
                        </p>
                        {chat.stores?.is_verified_store && (
                          <span className="text-[10px] font-bold text-orange-500 flex items-center gap-1 mt-0.5">
                            <ShieldCheck className="w-2.5 h-2.5" /> Vérifié
                          </span>
                        )}
                      </div>
                    </button>
                  );
                }) : (
                  <div className="text-center py-16 opacity-40">
                    <MessageSquare className="w-8 h-8 text-gray-400 mx-auto mb-2" />
                    <p className="text-xs font-bold text-gray-400 uppercase tracking-widest">
                      {loading ? 'Synchronisation...' : 'Aucune conversation'}
                    </p>
                  </div>
                )}
              </div>
            </div>

            {/* ── ACTIVE CONVERSATION ───────────────────────────────────────── */}
            <div className={`flex-1 flex flex-col min-w-0 bg-white dark:bg-gray-950 overflow-hidden ${(!activeChat && !(initialStoreId && loading)) ? 'hidden lg:flex' : 'flex'}`}>
              {activeChat ? (
                <>
                  {/* Header */}
                  <div className="px-4 py-3 pt-12 lg:pt-3 border-b border-gray-100 dark:border-white/5 bg-white/95 dark:bg-gray-950/95 backdrop-blur-md flex items-center gap-3 shrink-0 shadow-sm z-10">
                    <button
                      onClick={() => setActiveChat(null)}
                      className="lg:hidden p-2 -ml-1 hover:bg-gray-100 dark:hover:bg-white/5 rounded-xl transition-all min-h-[44px] flex items-center justify-center"
                    >
                      <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><path d="m15 18-6-6 6-6"/></svg>
                    </button>

                    {/* Avatar + online dot */}
                    <div className="relative shrink-0">
                      <div className="w-10 h-10 rounded-full overflow-hidden bg-gradient-to-br from-gray-700 to-gray-900 flex items-center justify-center font-bold text-sm text-white border border-gray-200 dark:border-white/10">
                        {(() => {
                          const isVendorView = (activeChat as any).stores?.owner_id === user?.id;
                          const avatarUrl = isVendorView
                            ? (activeChat as any).buyer_profile?.avatar_url
                            : activeChat.stores?.avatar_url;
                          const name = isVendorView
                            ? ((activeChat as any).buyer_profile?.full_name || 'C')
                            : (activeChat.stores?.store_name || 'B');
                          return avatarUrl
                            ? <img src={avatarUrl} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                            : name.charAt(0).toUpperCase();
                        })()}
                      </div>
                      <div className={`absolute bottom-0 right-0 w-2.5 h-2.5 rounded-full border-2 border-white dark:border-gray-950 ${isOtherPartyOnline ? 'bg-green-500' : 'bg-gray-300 dark:bg-gray-600'}`} />
                    </div>

                    {/* Name + status */}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-1.5">
                        <h4 className="font-bold text-sm text-gray-900 dark:text-white truncate leading-tight">
                          {(activeChat as any).stores?.owner_id === user?.id
                            ? ((activeChat as any).buyer_profile?.full_name || 'Client')
                            : activeChat.stores?.store_name}
                        </h4>
                        {activeChat.stores?.is_verified_store && (
                          <ShieldCheck className="w-3.5 h-3.5 text-orange-500 shrink-0" />
                        )}
                      </div>
                      <p className={`text-[11px] font-medium leading-tight ${isOtherPartyOnline ? 'text-green-500' : 'text-gray-400'}`}>
                        {isOtherPartyOnline ? 'En ligne' : 'Hors ligne'}
                      </p>
                    </div>

                    {/* Product pill (desktop) */}
                    {activeChat.product && (
                      <div className="hidden sm:flex items-center gap-2 bg-gray-50 dark:bg-white/5 border border-gray-200 dark:border-white/10 rounded-xl px-3 py-1.5 max-w-[160px] shrink-0">
                        {activeChat.product.image_urls?.[0] && (
                          <img src={activeChat.product.image_urls[0]} className="w-7 h-7 rounded-lg object-cover shrink-0" />
                        )}
                        <div className="min-w-0">
                          <p className="text-[10px] font-bold text-gray-900 dark:text-white truncate leading-tight">{activeChat.product.title}</p>
                          <p className="text-[10px] font-bold text-orange-500 leading-tight">{activeChat.product.price_gnf.toLocaleString()} GNF</p>
                        </div>
                      </div>
                    )}

                    {/* Actions */}
                    <div className="flex items-center gap-1 shrink-0">
                      <button
                        onClick={() => {
                          const text = `Je discute avec ${activeChat.stores?.store_name} sur ${APP_NAME} !`;
                          window.open(`https://wa.me/?text=${encodeURIComponent(text)}`, '_blank');
                        }}
                        className="p-2 hover:bg-green-50 dark:hover:bg-green-900/20 text-green-600 rounded-xl transition-all min-h-[44px] flex items-center justify-center"
                        title="Partager sur WhatsApp"
                      >
                        <Share2 className="w-4 h-4" />
                      </button>
                      <button
                        onClick={async () => {
                          if (!activeChat || !user) return;
                          const storeId = (activeChat as any).stores?.id || activeChat.store_id;
                          await supabase.from('chat_reports').insert({
                            channel_id: activeChat.id,
                            reporter_id: user.id,
                            reported_store_id: storeId,
                            reason: 'Reported by user'
                          });
                          showToast('Signalement envoyé. Nos modérateurs vont vérifier.', 'info');
                        }}
                        className="p-2 hover:bg-red-50 dark:hover:bg-red-900/20 hover:text-red-500 text-gray-400 rounded-xl transition-all min-h-[44px] flex items-center justify-center"
                        title="Signaler"
                      >
                        <AlertTriangle className="w-4 h-4" />
                      </button>
                      <button
                        onClick={handleClose}
                        className="p-2 hover:bg-gray-100 dark:hover:bg-white/5 text-gray-500 rounded-xl transition-all min-h-[44px] flex items-center justify-center"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    </div>
                  </div>

                  {/* Security banner */}
                  <div className="bg-amber-50 dark:bg-amber-900/10 border-b border-amber-100 dark:border-amber-900/20 px-4 py-2.5 flex items-center gap-3 shrink-0">
                    <ShieldCheck className="w-4 h-4 text-amber-600 shrink-0" />
                    <p className="text-[11px] font-medium text-amber-800 dark:text-amber-300 leading-snug">
                      Restez sur {APP_NAME} — paiements hors appli non protégés
                    </p>
                  </div>

                  {/* Messages */}
                  <div className="flex-1 relative overflow-hidden flex flex-col bg-gray-50/30 dark:bg-gray-950">
                    <div
                      ref={scrollRef}
                      onScroll={handleScroll}
                      className="flex-1 overflow-y-auto px-4 py-5"
                    >
                      {hasMoreMessages && (
                        <div className="flex justify-center py-2 mb-4">
                          <button
                            onClick={loadMoreMessages}
                            disabled={loadingMore}
                            className="text-[11px] font-bold text-gray-400 hover:text-orange-500 transition-colors px-4 py-2 rounded-full border border-gray-200 dark:border-white/10 hover:border-orange-300 disabled:opacity-40 flex items-center gap-2"
                          >
                            {loadingMore ? <Loader2 className="w-3 h-3 animate-spin" /> : '↑ Messages précédents'}
                          </button>
                        </div>
                      )}

                      {Object.keys(groupedMessages).length === 0 && !uploading ? (
                        <div className="flex flex-col items-center justify-center py-20 text-center gap-4 opacity-60">
                          <motion.div
                            initial={{ scale: 0.8, opacity: 0 }}
                            animate={{ scale: 1, opacity: 1 }}
                            className="w-20 h-20 bg-white dark:bg-gray-900 rounded-2xl flex items-center justify-center border border-gray-200 dark:border-white/5 shadow-sm"
                          >
                            <MessageSquare className="w-9 h-9 text-orange-500" />
                          </motion.div>
                          <div>
                            <h4 className="font-bold text-base text-gray-900 dark:text-white mb-1">Démarrez la discussion</h4>
                            <p className="text-xs text-gray-400 leading-relaxed max-w-[220px]">
                              Négociez, demandez des photos et concluez en direct.
                            </p>
                          </div>
                        </div>
                      ) : (
                        <>
                          {/* Product context card */}
                          {activeChat.product && (
                            <div className="flex justify-center mb-6">
                              <div className="bg-white dark:bg-gray-900 border border-gray-200 dark:border-white/10 rounded-2xl p-3 flex items-center gap-3 max-w-xs shadow-sm">
                                {activeChat.product.image_urls?.[0] && (
                                  <img src={activeChat.product.image_urls[0]} className="w-12 h-12 rounded-xl object-cover shrink-0" />
                                )}
                                <div className="min-w-0">
                                  <span className="text-[10px] font-bold text-orange-500 uppercase tracking-widest block">Produit lié</span>
                                  <p className="text-[12px] font-bold text-gray-900 dark:text-white truncate leading-tight">{activeChat.product.title}</p>
                                  <p className="text-[11px] font-bold text-orange-500">{activeChat.product.price_gnf.toLocaleString()} GNF</p>
                                </div>
                              </div>
                            </div>
                          )}

                          {Object.entries(groupedMessages).map(([date, msgs]: [string, Message[]]) => (
                            <div key={date}>
                              {/* Date separator */}
                              <div className="flex items-center gap-3 py-4">
                                <div className="flex-1 h-px bg-gray-200 dark:bg-white/10" />
                                <span className="text-[10px] font-bold text-gray-400 dark:text-gray-500 px-3 py-1 bg-gray-100 dark:bg-white/5 rounded-full whitespace-nowrap">
                                  {formatDateHeader(date)}
                                </span>
                                <div className="flex-1 h-px bg-gray-200 dark:bg-white/10" />
                              </div>

                              <div className="space-y-0.5">
                                {msgs.map((msg, idx) => {
                                  const isMe = msg.sender_id === user?.id;
                                  const prevMsg = msgs[idx - 1];
                                  const nextMsg = msgs[idx + 1];
                                  const isFirstInGroup = !prevMsg || prevMsg.sender_id !== msg.sender_id;
                                  const isLastInGroup = !nextMsg || nextMsg.sender_id !== msg.sender_id;
                                  const isOffer = msg.metadata?.type === 'offer';

                                  return (
                                    <motion.div
                                      initial={{ opacity: 0, x: isMe ? 16 : -16 }}
                                      animate={{ opacity: 1, x: 0 }}
                                      transition={{ duration: 0.2 }}
                                      key={msg.id}
                                      className={`flex ${isMe ? 'justify-end' : 'justify-start'} ${isLastInGroup ? 'mb-4' : 'mb-0.5'}`}
                                    >
                                      {/* Incoming mini avatar */}
                                      {!isMe && (
                                        <div className="w-7 h-7 shrink-0 mr-1.5 self-end">
                                          {isLastInGroup && (() => {
                                            const isVendorView = (activeChat as any).stores?.owner_id === user?.id;
                                            const avatarUrl = isVendorView
                                              ? (activeChat as any).buyer_profile?.avatar_url
                                              : activeChat.stores?.avatar_url;
                                            const name = isVendorView
                                              ? ((activeChat as any).buyer_profile?.full_name || 'C')
                                              : (activeChat.stores?.store_name || 'B');
                                            return (
                                              <div className="w-7 h-7 rounded-full overflow-hidden bg-gradient-to-br from-gray-700 to-gray-900 flex items-center justify-center text-xs font-bold text-white">
                                                {avatarUrl
                                                  ? <img src={avatarUrl} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                                                  : name.charAt(0).toUpperCase()
                                                }
                                              </div>
                                            );
                                          })()}
                                        </div>
                                      )}

                                      <div className={`max-w-[75%] sm:max-w-[65%] flex flex-col ${isMe ? 'items-end' : 'items-start'}`}>
                                        <div className={`px-4 py-2.5 text-[14px] leading-relaxed shadow-sm
                                          ${isMe
                                            ? `bg-gray-900 dark:bg-[#ff6600] text-white ${isFirstInGroup ? 'rounded-t-2xl' : 'rounded-t-md'} ${isLastInGroup ? 'rounded-bl-2xl rounded-br-sm' : 'rounded-b-md'}`
                                            : `bg-white dark:bg-gray-800 text-gray-900 dark:text-white border border-gray-100 dark:border-white/5 ${isFirstInGroup ? 'rounded-t-2xl' : 'rounded-t-md'} ${isLastInGroup ? 'rounded-br-2xl rounded-bl-sm' : 'rounded-b-md'}`
                                          }
                                        `}>
                                          {msg.image_url && (
                                            <div className="mb-2 -mx-1">
                                              <img
                                                src={msg.image_url}
                                                className="rounded-xl cursor-pointer hover:opacity-90 transition-opacity"
                                                style={{ maxHeight: 200, maxWidth: '100%' }}
                                                onClick={() => window.open(msg.image_url, '_blank')}
                                                referrerPolicy="no-referrer"
                                              />
                                            </div>
                                          )}
                                          <p>{msg.message}</p>
                                          {msg.metadata?.type === 'auto-reply' && (
                                            <div className="mt-1.5 flex items-center gap-1 opacity-60">
                                              <Smartphone className="w-2.5 h-2.5" />
                                              <span className="text-[9px] uppercase tracking-widest font-bold">Réponse auto</span>
                                            </div>
                                          )}
                                          {isOffer && (
                                            <div className="mt-3 pt-3 border-t border-white/20">
                                              <div className="flex items-center justify-between mb-2">
                                                <span className="text-[10px] font-bold uppercase tracking-widest opacity-70">💰 Prix Spécial</span>
                                                <Zap className="w-3 h-3 text-yellow-300" />
                                              </div>
                                              <div className="flex items-baseline gap-2 mb-3">
                                                <span className="text-xl font-black">{msg.metadata.price?.toLocaleString()} GNF</span>
                                                {msg.metadata.originalPrice && (
                                                  <span className="text-[11px] line-through opacity-50">{msg.metadata.originalPrice.toLocaleString()} GNF</span>
                                                )}
                                              </div>
                                              {!isMe && (
                                                <button
                                                  onClick={() => showToast(`Redirection vers le paiement sécurisé ${APP_NAME}...`, "info")}
                                                  className="w-full py-2.5 bg-white text-gray-900 rounded-xl text-[11px] font-bold uppercase tracking-wider hover:bg-gray-100 transition-all flex items-center justify-center gap-2"
                                                >
                                                  <ShoppingBag className="w-4 h-4" />
                                                  Acheter à ce prix
                                                </button>
                                              )}
                                            </div>
                                          )}
                                        </div>

                                        {isLastInGroup && (
                                          <div className={`flex items-center gap-1 mt-1 px-1 ${isMe ? 'flex-row-reverse' : 'flex-row'}`}>
                                            <span className="text-[10px] text-gray-400">
                                              {new Date(msg.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                                            </span>
                                            {isMe && (
                                              <CheckCircle2 className={`w-3 h-3 ${msg.is_read ? 'text-orange-400' : 'text-gray-300 dark:text-gray-600'}`} />
                                            )}
                                          </div>
                                        )}
                                      </div>
                                    </motion.div>
                                  );
                                })}
                              </div>
                            </div>
                          ))}
                        </>
                      )}

                      {/* Upload spinner */}
                      {uploading && (
                        <div className="flex justify-end mt-2">
                          <div className="bg-orange-50 dark:bg-orange-950/20 border border-orange-100 dark:border-orange-900/30 px-4 py-3 rounded-2xl flex items-center gap-3">
                            <Loader2 className="w-4 h-4 animate-spin text-orange-500" />
                            <span className="text-xs font-bold text-orange-700 dark:text-orange-300">Envoi en cours...</span>
                          </div>
                        </div>
                      )}

                      {/* Typing Indicator */}
                      <AnimatePresence>
                        {isTyping && (
                          <motion.div
                            initial={{ opacity: 0, y: 10 }}
                            animate={{ opacity: 1, y: 0 }}
                            exit={{ opacity: 0, y: 10 }}
                            className="flex justify-start mt-2"
                          >
                            <div className="bg-white dark:bg-gray-800 border border-gray-100 dark:border-white/5 px-4 py-3 rounded-2xl rounded-bl-sm shadow-sm flex items-center gap-2">
                              <div className="flex gap-1">
                                <motion.div animate={{ scale: [1, 1.3, 1] }} transition={{ repeat: Infinity, duration: 1, delay: 0 }} className="w-1.5 h-1.5 bg-orange-400 rounded-full" />
                                <motion.div animate={{ scale: [1, 1.3, 1] }} transition={{ repeat: Infinity, duration: 1, delay: 0.2 }} className="w-1.5 h-1.5 bg-orange-400 rounded-full" />
                                <motion.div animate={{ scale: [1, 1.3, 1] }} transition={{ repeat: Infinity, duration: 1, delay: 0.4 }} className="w-1.5 h-1.5 bg-orange-400 rounded-full" />
                              </div>
                              <span className="text-[10px] font-bold text-gray-400 tracking-wider">Le vendeur écrit...</span>
                            </div>
                          </motion.div>
                        )}
                      </AnimatePresence>
                    </div>

                    {/* Scroll to bottom FAB */}
                    <AnimatePresence>
                      {showScrollBottom && (
                        <motion.button
                          initial={{ opacity: 0, scale: 0.8 }}
                          animate={{ opacity: 1, scale: 1 }}
                          exit={{ opacity: 0, scale: 0.8 }}
                          onClick={scrollToBottom}
                          className="absolute bottom-4 right-4 z-30 w-10 h-10 bg-[#ff6600] text-white rounded-2xl shadow-xl flex items-center justify-center hover:scale-110 active:scale-90 transition-transform"
                        >
                          <ChevronDown className="w-5 h-5 stroke-[2.5]" />
                        </motion.button>
                      )}
                    </AnimatePresence>
                  </div>

                  {/* ── INPUT ── */}
                  <div className="bg-white dark:bg-gray-900 border-t border-gray-100 dark:border-white/5 shrink-0 z-10">
                    {/* Security warning */}
                    <AnimatePresence>
                      {securityWarning && (
                        <motion.div
                          initial={{ opacity: 0, y: 8 }}
                          animate={{ opacity: 1, y: 0 }}
                          exit={{ opacity: 0, y: 8 }}
                          className="mx-4 mt-3 p-3 bg-red-50 dark:bg-red-950/20 border border-red-100 dark:border-red-900/30 rounded-xl flex items-start gap-2.5"
                        >
                          <ShieldCheck className="w-4 h-4 text-red-500 shrink-0 mt-0.5" />
                          <p className="text-[11px] font-medium text-red-800 dark:text-red-300 leading-snug">{securityWarning}</p>
                        </motion.div>
                      )}
                    </AnimatePresence>

                    {/* Quick replies */}
                    <div className="px-4 pt-3 pb-2 flex flex-wrap gap-1.5">
                      {QUICK_REPLIES.map((reply, idx) => (
                        <button
                          key={idx}
                          onClick={() => handleSend(undefined, reply)}
                          className="px-3 py-1.5 bg-gray-50 dark:bg-white/5 border border-gray-200 dark:border-white/10 rounded-full text-[11px] font-medium text-gray-600 dark:text-gray-300 hover:bg-orange-50 hover:text-orange-600 hover:border-orange-200 transition-all active:scale-95"
                        >
                          {reply}
                        </button>
                      ))}
                    </div>

                    {/* Text row */}
                    <div className="px-4 pb-4 flex items-end gap-2">
                      <button
                        type="button"
                        onClick={() => fileInputRef.current?.click()}
                        className="p-2.5 bg-gray-50 dark:bg-white/5 border border-gray-200 dark:border-white/10 rounded-xl hover:bg-gray-100 dark:hover:bg-white/10 transition-all shrink-0 hover:text-orange-500 text-gray-500 min-h-[44px] flex items-center justify-center"
                        title="Joindre une image"
                      >
                        <Paperclip className="w-4 h-4" />
                      </button>
                      <input type="file" ref={fileInputRef} onChange={handleImageUpload} accept="image/*" className="hidden" />

                      <form onSubmit={handleSend} className="flex-1 flex items-end gap-2">
                        <textarea
                          value={newMessage}
                          onChange={(e) => {
                            setNewMessage(e.target.value);
                            e.target.style.height = 'auto';
                            e.target.style.height = Math.min(e.target.scrollHeight, 120) + 'px';
                          }}
                          onKeyDown={(e) => {
                            if (e.key === 'Enter' && !e.shiftKey) {
                              e.preventDefault();
                              handleSend(e as any);
                            }
                          }}
                          placeholder="Votre message..."
                          rows={1}
                          className="flex-1 bg-gray-50 dark:bg-white/5 border border-gray-200 dark:border-white/10 rounded-xl px-4 py-2.5 text-sm outline-none focus:border-orange-400 dark:focus:border-orange-500 text-gray-900 dark:text-white placeholder-gray-400 transition-all resize-none overflow-hidden leading-relaxed"
                          style={{ minHeight: 42 }}
                        />
                        <motion.button
                          type="submit"
                          disabled={!newMessage.trim() || uploading}
                          whileHover={{ scale: 1.05 }}
                          whileTap={{ scale: 0.93 }}
                          className="p-2.5 bg-gray-900 dark:bg-[#ff6600] hover:bg-black dark:hover:bg-orange-600 disabled:bg-gray-200 dark:disabled:bg-white/10 text-white disabled:text-gray-400 rounded-xl transition-colors shrink-0 shadow-sm min-h-[44px] flex items-center justify-center gap-2"
                        >
                          <span className="hidden sm:inline text-xs font-bold uppercase tracking-wider">Envoyer</span>
                          <Send className="w-4 h-4" />
                        </motion.button>
                      </form>
                    </div>
                  </div>
                </>
              ) : initialStoreId && loading ? (
                <div className="flex-1 flex flex-col items-center justify-center gap-4 opacity-50">
                  <Loader2 className="w-8 h-8 animate-spin text-orange-500" />
                  <p className="text-xs font-bold text-gray-400 uppercase tracking-widest">Connexion au vendeur...</p>
                </div>
              ) : (
                /* Full empty state */
                <div className="flex-1 flex flex-col items-center justify-center p-8 text-center pt-20 lg:pt-8">
                  <div className="w-24 h-24 bg-gray-50 dark:bg-gray-900 rounded-[2rem] flex items-center justify-center mb-6 border border-gray-100 dark:border-white/5 shadow-inner relative">
                    <MessageSquare className="w-10 h-10 text-orange-500" />
                    <div className="absolute -bottom-2 -right-2 w-9 h-9 bg-orange-500 rounded-xl flex items-center justify-center text-white shadow-lg animate-bounce">
                      <Plus className="w-5 h-5" />
                    </div>
                  </div>
                  <h3 className="text-2xl font-black text-gray-900 dark:text-white mb-3 tracking-tighter">Messagerie Instantanée</h3>
                  <p className="text-sm text-gray-500 dark:text-gray-400 leading-relaxed mb-8 max-w-[260px]">
                    Négociez, demandez des photos réelles et concluez en direct.
                  </p>
                  <div className="grid grid-cols-2 gap-3 w-full max-w-xs mb-8">
                    <div className="p-4 bg-gray-50 dark:bg-gray-900 rounded-2xl border border-gray-100 dark:border-white/5 flex flex-col items-center gap-2">
                      <ImageIcon className="w-5 h-5 text-orange-500" />
                      <span className="text-[10px] font-black tracking-widest text-gray-900 dark:text-white uppercase">Partage Photo</span>
                    </div>
                    <div className="p-4 bg-gray-50 dark:bg-gray-900 rounded-2xl border border-gray-100 dark:border-white/5 flex flex-col items-center gap-2">
                      <ShieldCheck className="w-5 h-5 text-orange-500" />
                      <span className="text-[10px] font-black tracking-widest text-gray-900 dark:text-white uppercase">Safe & VIP</span>
                    </div>
                  </div>
                  <button
                    onClick={handleClose}
                    className="px-8 py-3 border border-gray-200 dark:border-white/10 text-gray-700 dark:text-gray-300 rounded-full font-bold text-sm hover:bg-gray-900 dark:hover:bg-[#ff6600] hover:text-white transition-all"
                  >
                    Retourner à la boutique
                  </button>
                </div>
              )}
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
