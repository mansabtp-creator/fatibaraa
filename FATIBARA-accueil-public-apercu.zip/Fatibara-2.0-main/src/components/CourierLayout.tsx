import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { LogOut, Truck, ChevronDown, Zap, PauseCircle, AlertTriangle, Loader2 } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useAppContext } from '../context/AppContext';
import { supabase } from '../lib/supabase';
import { APP_NAME } from '../lib/constants';

interface CourierLayoutProps {
  children: React.ReactNode;
  isOnline?: boolean;
  onToggleOnline?: () => void;
  togglingOnline?: boolean;
  avatarUrl?: string | null;
}

// ─── Courier Header Bar ─────────────────────────────────────────────────────

function CourierHeaderBar({
  isOnline = false,
  onToggleOnline,
  togglingOnline = false,
  avatarUrl,
}: {
  isOnline?: boolean;
  onToggleOnline?: () => void;
  togglingOnline?: boolean;
  avatarUrl?: string | null;
}) {
  const { user } = useAppContext();
  const navigate = useNavigate();
  const [showProfileMenu, setShowProfileMenu] = useState(false);
  const [isLoggingOut, setIsLoggingOut] = useState(false);

  const handleLogout = async () => {
    setIsLoggingOut(true);
    try {
      await supabase.auth.signOut();
      navigate('/');
    } catch (err) {
      console.error('Courier logout error:', err);
    } finally {
      setIsLoggingOut(false);
      setShowProfileMenu(false);
    }
  };

  // Derive display name safely — Supabase Auth stores the name under
  // user_metadata.full_name, not as a top-level property on the User object.
  const displayName: string = user?.user_metadata?.full_name
    ?? user?.email?.split('@')[0]
    ?? 'Livreur';

  const avatarSeed = user?.id ?? 'default';

  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-[#0d0d0d] border-b border-white/5 shadow-xl shadow-black/40">
      {/* Orange accent top-line */}
      <div className="absolute top-0 left-0 w-full h-[3px] bg-gradient-to-r from-[#ff6600] via-[#ff8c00] to-[#ff6600]" />

      <div className="max-w-5xl mx-auto px-4 h-16 flex items-center justify-between gap-4">

        {/* ── Left: Brand wordmark ── */}
        <div className="flex items-center gap-3 select-none">
          <div className="w-8 h-8 bg-[#ff6600] rounded-lg flex items-center justify-center shadow-lg shadow-[#ff6600]/30">
            <Truck className="w-4 h-4 text-white" strokeWidth={2.5} />
          </div>
          <span className="text-[15px] font-black tracking-[0.15em] text-white uppercase">
            {APP_NAME}
          </span>
          <span className="hidden sm:inline text-[9px] font-bold tracking-[0.25em] text-white/30 uppercase border border-white/10 px-2 py-0.5 rounded-full">
            Fleet
          </span>
        </div>

        {/* ── Center: Online/Offline toggle button ── */}
        <button
          onClick={onToggleOnline}
          disabled={togglingOnline}
          className="focus:outline-none disabled:cursor-wait"
          title={isOnline ? 'Passer En Pause' : 'Démarrer le service'}
        >
          <AnimatePresence mode="wait">
            {isOnline ? (
              <motion.div
                key="active"
                initial={{ opacity: 0, scale: 0.85 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.85 }}
                className="flex items-center gap-2 px-4 py-1.5 rounded-full bg-emerald-500/10 border border-emerald-500/25 backdrop-blur-sm hover:bg-emerald-500/20 transition-colors"
              >
                {togglingOnline ? (
                  <Loader2 className="w-3 h-3 text-emerald-400 animate-spin" />
                ) : (
                  <span className="relative flex h-2 w-2">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" />
                    <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500" />
                  </span>
                )}
                <Zap className="w-3 h-3 text-emerald-400 fill-current" />
                <span className="text-[10px] font-black tracking-[0.2em] text-emerald-400 uppercase">En Service</span>
              </motion.div>
            ) : (
              <motion.div
                key="paused"
                initial={{ opacity: 0, scale: 0.85 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.85 }}
                className="flex items-center gap-2 px-4 py-1.5 rounded-full bg-white/5 border border-white/10 backdrop-blur-sm hover:bg-white/10 transition-colors"
              >
                {togglingOnline ? (
                  <Loader2 className="w-3.5 h-3.5 text-white/40 animate-spin" />
                ) : (
                  <PauseCircle className="w-3.5 h-3.5 text-white/40" />
                )}
                <span className="text-[10px] font-black tracking-[0.2em] text-white/40 uppercase">En Pause</span>
              </motion.div>
            )}
          </AnimatePresence>
        </button>

        {/* ── Right: User profile node ── */}
        <div className="relative">
          <button
            id="courier-profile-menu-trigger"
            onClick={() => setShowProfileMenu(prev => !prev)}
            className="flex items-center gap-2.5 px-3 py-2 rounded-xl bg-white/5 border border-white/10 hover:bg-white/10 hover:border-white/20 transition-all group"
            aria-haspopup="true"
            aria-expanded={showProfileMenu}
          >
            <div className="w-7 h-7 rounded-lg overflow-hidden border border-white/10 bg-white/5 shrink-0">
              <img
                src={avatarUrl || `https://api.dicebear.com/7.x/avataaars/svg?seed=${avatarSeed}`}
                alt={displayName}
                className="w-full h-full object-cover"
              />
            </div>
            <span className="hidden sm:block text-[11px] font-bold text-white/70 tracking-wider max-w-[100px] truncate">
              {displayName}
            </span>
            <ChevronDown
              className={`w-3.5 h-3.5 text-white/40 transition-transform duration-200 ${showProfileMenu ? 'rotate-180' : ''}`}
            />
          </button>

          {/* Dropdown */}
          <AnimatePresence>
            {showProfileMenu && (
              <>
                {/* Backdrop */}
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  className="fixed inset-0 z-40"
                  onClick={() => setShowProfileMenu(false)}
                />
                <motion.div
                  initial={{ opacity: 0, scale: 0.92, y: -8 }}
                  animate={{ opacity: 1, scale: 1, y: 0 }}
                  exit={{ opacity: 0, scale: 0.92, y: -8 }}
                  transition={{ duration: 0.15, ease: 'easeOut' }}
                  className="absolute right-0 top-full mt-2 z-50 w-52 bg-[#111] border border-white/10 rounded-2xl shadow-2xl shadow-black/60 overflow-hidden"
                >
                  {/* User info header */}
                  <div className="px-4 py-3 border-b border-white/5">
                    <p className="text-[11px] font-bold text-white tracking-wide truncate">
                      {displayName}
                    </p>
                    <p className="text-[10px] text-white/30 tracking-wider truncate mt-0.5">
                      {user?.email ?? '—'}
                    </p>
                  </div>

                  {/* Nav links */}
                  <div className="p-2 border-b border-white/5">
                    <button
                      onClick={() => { navigate('/livreur/dashboard'); setShowProfileMenu(false); }}
                      className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-[11px] font-bold tracking-wider text-white/60 hover:bg-white/5 hover:text-white transition-all"
                    >
                      <span className="text-[13px]">⚙️</span> Paramètres
                    </button>
                    <a
                      href="/"
                      className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-[11px] font-bold tracking-wider text-white/60 hover:bg-white/5 hover:text-white transition-all"
                      onClick={() => setShowProfileMenu(false)}
                    >
                      <span className="text-[13px]">🛍️</span> Retour à la boutique
                    </a>
                  </div>

                  {/* Sign Out */}
                  <div className="p-2">
                    <button
                      id="courier-signout-btn"
                      onClick={handleLogout}
                      disabled={isLoggingOut}
                      className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-[11px] font-bold tracking-wider text-red-400 hover:bg-red-500/10 hover:text-red-300 transition-all disabled:opacity-50"
                    >
                      {isLoggingOut ? (
                        <span className="w-4 h-4 border border-red-400 border-t-transparent rounded-full animate-spin" />
                      ) : (
                        <LogOut className="w-4 h-4" />
                      )}
                      {isLoggingOut ? 'Déconnexion...' : 'Déconnexion'}
                    </button>
                  </div>
                </motion.div>
              </>
            )}
          </AnimatePresence>
        </div>
      </div>
    </header>
  );
}

// ─── Courier Not Authenticated Guard ────────────────────────────────────────

function CourierAuthGuard({ children }: { children: React.ReactNode }) {
  const { user, isAuthLoading, isProfileReady, activeRole } = useAppContext();
  const navigate = useNavigate();
  // Normalize: both 'courier' and 'livreur' are valid courier role spellings
  const isCourierRole = activeRole === 'courier' || activeRole === 'livreur';

  // ── Auth loading ─────────────────────────────────────────────────────────
  // Wait for BOTH auth and profile before evaluating the role guard
  if (isAuthLoading || !isProfileReady) {
    return (
      <div className="min-h-screen bg-[#0d0d0d] flex items-center justify-center">
        <div className="flex flex-col items-center gap-4">
          <div className="w-10 h-10 border-2 border-[#ff6600] border-t-transparent rounded-full animate-spin" />
          <p className="text-[10px] font-bold text-white/30 tracking-widest uppercase">
            Vérification session…
          </p>
        </div>
      </div>
    );
  }

  // ── Not logged in ─────────────────────────────────────────────────────────
  if (!user) {
    return (
      <div className="min-h-screen bg-[#0d0d0d] flex items-center justify-center p-6">
        <div className="flex flex-col items-center gap-6 text-center max-w-xs">
          <div className="w-16 h-16 bg-red-500/10 border border-red-500/20 rounded-2xl flex items-center justify-center">
            <AlertTriangle className="w-8 h-8 text-red-400" />
          </div>
          <div>
            <h2 className="text-lg font-black text-white uppercase tracking-tighter mb-2">
              Accès restreint
            </h2>
            <p className="text-[11px] text-white/40 tracking-wider leading-relaxed">
              Vous devez être connecté pour accéder à ce tableau de bord.
            </p>
          </div>
          <button
            onClick={() => navigate('/login')}
            className="px-8 py-3 bg-[#ff6600] text-white rounded-xl text-[11px] font-black tracking-widest uppercase hover:bg-[#e65c00] transition-colors"
          >
            Se connecter
          </button>
        </div>
      </div>
    );
  }

  // ── activeRole empty → profile still loading ──────────────────────────
  // Gated above by isProfileReady but kept as a safety net.
  if (!isCourierRole && activeRole === '') return null;

  // ── Active role is not courier ──────────────────────────────────────────────
  // RoleGuard in App.tsx handles redirection; this renders a fallback UI
  // if the user somehow reaches this page with the wrong active role.
  if (!isCourierRole) {
    const redirectTo = activeRole === 'vendor'
      ? '/vendor/dashboard'
      : activeRole === 'admin'
      ? '/admin'
      : '/';

    return (
      <div className="min-h-screen bg-[#0d0d0d] flex items-center justify-center p-6">
        <div className="flex flex-col items-center gap-6 text-center max-w-xs">
          <div className="w-16 h-16 bg-amber-500/10 border border-amber-500/20 rounded-2xl flex items-center justify-center">
            <AlertTriangle className="w-8 h-8 text-amber-400" />
          </div>
          <div>
            <h2 className="text-lg font-black text-white uppercase tracking-tighter mb-2">
              Accès non autorisé
            </h2>
            <p className="text-[11px] text-white/40 tracking-wider leading-relaxed">
              Ce tableau de bord est réservé aux livreurs {APP_NAME}.
            </p>
          </div>
          <div className="flex flex-col gap-3 w-full">
            <button
              id="courier-apply-btn"
              onClick={() => navigate('/courier-onboarding')}
              className="w-full px-8 py-3 bg-[#ff6600] text-white rounded-xl text-[11px] font-black tracking-widest uppercase hover:bg-[#e65c00] transition-colors"
            >
              Devenir Livreur
            </button>
            <button
              id="courier-back-to-space-btn"
              onClick={() => navigate(redirectTo)}
              className="w-full px-8 py-3 bg-white/5 border border-white/10 text-white/60 rounded-xl text-[11px] font-bold tracking-widest uppercase hover:bg-white/10 transition-colors"
            >
              Mon Espace
            </button>
          </div>
        </div>
      </div>
    );
  }

  return <>{children}</>;
}


// ─── Main Layout Export ──────────────────────────────────────────────────────

export default function CourierLayout({
  children,
  isOnline = false,
  onToggleOnline,
  togglingOnline = false,
  avatarUrl,
}: CourierLayoutProps) {
  return (
    <div className="min-h-screen flex flex-col bg-gray-50 dark:bg-[#0a0a0a]">
      <CourierHeaderBar
        isOnline={isOnline}
        onToggleOnline={onToggleOnline}
        togglingOnline={togglingOnline}
        avatarUrl={avatarUrl}
      />

      {/* Offset for fixed header height (h-16 = 64px) */}
      <div className="h-16 shrink-0" aria-hidden="true" />

      <CourierAuthGuard>
        <main className="flex-grow w-full">
          {children}
        </main>
      </CourierAuthGuard>
    </div>
  );
}
