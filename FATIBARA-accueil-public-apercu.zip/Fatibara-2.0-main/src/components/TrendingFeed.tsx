import { useEffect, useState } from 'react';
import { supabase } from '../lib/supabase';
import { motion } from 'motion/react';
import { useAppContext } from '../context/AppContext';
import { useStore } from '../store/useStore';
import { Skeleton } from './ui/Skeleton';
import { Link } from 'react-router-dom';
import { ArrowRight, Flame } from 'lucide-react';

export default function TrendingFeed() {
  const [products, setProducts] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const { proMode } = useAppContext();
  const { modeEconomie, selectedRegion } = useStore();

  useEffect(() => {
    async function fetchTrending() {
      try {
        // Try to use the new RPC for trending products
        const { data, error } = await supabase.rpc('get_trending_products');
        
        if (!error && data && data.length > 0) {
          setProducts(data);
        } else {
          // Fallback if RPC doesn't exist or returns empty
          const { data: fallbackData, error: fallbackError } = await supabase
            .from('products')
            .select('id, title, price_gnf, wholesale_price_gnf, image_urls, category, created_at')
            .limit(6);
            
          if (fallbackError) throw fallbackError;
          setProducts(fallbackData || []);
        }
      } catch (err) {
        console.warn('Trending fetch failed: ', err);
        setProducts([]);
      } finally {
        setLoading(false);
      }
    }
    fetchTrending();
  }, []);

  if (loading) {
    return (
      <section className="px-4 md:px-10 py-6">
        <div className="max-w-7xl mx-auto">
          <h2 className="text-xl md:text-2xl font-bold text-gray-900 text-gray-900 dark:text-white mb-6 tracking-tight flex items-center gap-2">
            <Flame className="w-6 h-6 text-[#ff6600]" /> Tendances
          </h2>
          <div className="flex gap-4 overflow-x-auto scrollbar-hide">
            {[...Array(5)].map((_, i) => (
              <div key={i} className="min-w-[120px] md:min-w-[200px] flex-shrink-0 flex flex-col gap-3">
                <Skeleton className="w-full aspect-square rounded-xl" />
                <Skeleton className="w-3/4 h-3" />
                <Skeleton className="w-1/2 h-3" />
              </div>
            ))}
          </div>
        </div>
      </section>
    );
  }

  return (
    <section className="px-4 md:px-10 py-6">
      <div className="max-w-7xl mx-auto">
        <div className="flex items-center justify-between mb-4 md:mb-6">
          <h2 className="text-xl md:text-2xl font-black text-gray-900 text-gray-900 dark:text-white tracking-tight flex items-center gap-2">
            Ventes Flash
          </h2>
          <button className="flex items-center gap-1 text-[#ff6600] hover:text-[#e62e00] font-bold text-[13px] transition-colors">
            Voir plus <ArrowRight className="w-4 h-4" />
          </button>
        </div>
        
        <div className="flex gap-3 md:gap-4 overflow-x-auto scrollbar-hide pb-4 -mx-4 px-4 md:mx-0 md:px-0 snap-x snap-mandatory">
          {products.map((product, index) => {
            const baseImageUrl = product.image_urls?.[0] || 'https://picsum.photos/seed/fallback/400/400';
            const imageUrl = modeEconomie ? `${baseImageUrl}?blur=2&q=50` : baseImageUrl;
            const displayPrice = (proMode && product.wholesale_price_gnf) 
              ? product.wholesale_price_gnf 
              : product.price_gnf;

            return (
              <Link to={`/product/${product.id}`} key={product.id} className="min-w-[130px] md:min-w-[200px] w-[130px] md:w-[200px] flex-shrink-0 snap-start group outline-none">
                <motion.div
                  initial={{ opacity: modeEconomie ? 1 : 0, x: modeEconomie ? 0 : 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: modeEconomie ? 0 : index * 0.1, duration: modeEconomie ? 0 : 0.6 }}
                  className="flex flex-col h-full bg-white bg-white dark:bg-gray-900 rounded-xl overflow-hidden hover:shadow-lg transition-all duration-300 border border-gray-100 border-gray-100 dark:border-gray-800"
                >
                  <div className="relative aspect-square bg-white dark:bg-gray-900 dark:bg-gray-800 overflow-hidden flex items-center justify-center p-2">
                    <img
                      src={imageUrl}
                      alt={product.title}
                      width={200}
                      height={200}
                      className={`w-full h-full object-contain ${modeEconomie ? '' : 'group-hover:scale-105 transition-transform duration-500'}`}
                      referrerPolicy="no-referrer"
                      loading="lazy"
                    />
                    <div className="absolute top-2 left-2 bg-[#ff6600] text-white px-2 py-0.5 text-[10px] font-bold tracking-wide rounded shadow-sm">
                      -50%
                    </div>
                  </div>
                  
                  <div className="p-2 md:p-3 flex flex-col gap-1">
                    <div className="text-[10px] font-bold text-[#16a34a] truncate">
                      LIVRAISON GRATUITE
                    </div>
                    <h3 className="text-[12px] md:text-[13px] font-medium text-gray-800 dark:text-gray-200 leading-tight line-clamp-2 min-h-[32px] group-hover:text-[#ff6600] transition-colors">
                      {product.title}
                    </h3>
                    <div className="mt-1 flex items-end gap-2">
                      <div className="text-[14px] md:text-[16px] font-bold text-[#e62e00] leading-none">
                        {(displayPrice || 0).toLocaleString()} <span className="text-[10px] font-medium text-gray-500 dark:text-gray-400">GNF</span>
                      </div>
                    </div>
                  </div>
                </motion.div>
              </Link>
            );
          })}
        </div>
      </div>
    </section>
  );
}
