import { useEffect, useState, useRef, useCallback } from 'react';
import { supabase, safeSupabaseQuery } from '../lib/supabase';
import { motion, AnimatePresence } from 'motion/react';
import { SlidersHorizontal, ChevronDown, Check, ArrowRight, X, Heart, Search, Zap, MapPin, WifiOff, RefreshCw } from 'lucide-react';
import { Skeleton } from './ui/Skeleton';
import { useAppContext } from '../context/AppContext';
import { useStore } from '../store/useStore';
import { Link } from 'react-router-dom';
import ShareDialog from './ShareDialog';
import QuickViewModal from './QuickViewModal';
import ProductCard, { Product } from './ProductCard';
import { useToast } from '../context/ToastContext';
import { safeGetCurrentPosition, isGeolocationPermitted } from '../utils/geolocation';

interface ProductGridProps {
  filterType?: 'all' | 'followed' | 'nearby';
  hideHeader?: boolean;
  hideCategories?: boolean;
  shopCategory?: string | null;
  shopPromoOnly?: boolean;
  shopVendor?: string | null;
}

type SortOption = 'pertinence' | 'newest' | 'price-asc' | 'price-desc' | 'vendor-asc' | 'vendor-desc';

const SORT_OPTIONS: { value: SortOption; label: string }[] = [
  { value: 'pertinence', label: 'Pertinence' },
  { value: 'newest', label: 'Nouveauté' },
  { value: 'price-asc', label: 'Prix croissant' },
  { value: 'price-desc', label: 'Prix décroissant' },
  { value: 'vendor-asc', label: 'Boutiques (A-Z)' },
  { value: 'vendor-desc', label: 'Boutiques (Z-A)' },
];

import { GUINEA_LOCATIONS } from '../constants/locations';

export default function ProductGrid({ 
  filterType = 'all',
  hideHeader = false,
  hideCategories = false,
  shopCategory = null,
  shopPromoOnly = false,
  shopVendor = null
}: ProductGridProps) {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [loadingMore, setLoadingMore] = useState(false);
  const [fetchError, setFetchError] = useState<string | null>(null);
  const [page, setPage] = useState(0);
  const [hasMore, setHasMore] = useState(true);
  // retryKey: incrementing this triggers a fresh re-fetch without a full page reload.
  const [retryKey, setRetryKey] = useState(0);
  // isOnline: tracks browser online/offline API so we can show contextual messages.
  const [isOnline, setIsOnline] = useState(() => navigator.onLine);
  // propulsedStoreIds: store IDs with an active PROPULSE campaign — products from
  // these stores are flagged with is_propulsed and sorted to the top of the grid.
  const [propulsedStoreIds, setPropulsedStoreIds] = useState<Set<string>>(new Set());
  const PAGE_SIZE = 12;

  // ─── Online / Offline detection ────────────────────────────────────────────────
  useEffect(() => {
    const goOnline  = () => { setIsOnline(true);  setRetryKey(k => k + 1); };
    const goOffline = () => setIsOnline(false);
    window.addEventListener('online',  goOnline);
    window.addEventListener('offline', goOffline);
    return () => {
      window.removeEventListener('online',  goOnline);
      window.removeEventListener('offline', goOffline);
    };
  }, []);

  // Stable retry callback — increments retryKey which is a dependency of the fetch effect.
  const handleRetry = useCallback(() => setRetryKey(k => k + 1), []);

  // ─── Fetch active PROPULSE campaigns once on mount ─────────────────────────
  useEffect(() => {
    let isMounted = true;
    supabase
      .from('boost_campaigns')
      .select('store_id')
      .eq('status', 'active')
      .gt('expires_at', new Date().toISOString())
      .then(({ data }) => {
        if (isMounted && data && data.length > 0) {
          setPropulsedStoreIds(new Set(data.map((r: { store_id: string }) => r.store_id)));
        }
      });
    return () => {
      isMounted = false;
    };
  }, []);

  const [sortBy, setSortBy] = useState<SortOption>('newest');
  const [showSortDropdown, setShowSortDropdown] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState<string>('Toutes');
  const [minPrice, setMinPrice] = useState<string>('');
  const [maxPrice, setMaxPrice] = useState<string>('');
  const [sharingProduct, setSharingProduct] = useState<Product | null>(null);
  const [quickViewProduct, setQuickViewProduct] = useState<Product | null>(null);
  const dropdownRef = useRef<HTMLDivElement>(null);
  const { showToast } = useToast();
  
  const { proMode, followedVendors } = useAppContext();
  const { modeEconomie, globalSearchQuery, selectedRegion } = useStore();

  useEffect(() => {
    if (shopCategory) {
      setSelectedCategory(shopCategory);
    }
  }, [shopCategory]);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setShowSortDropdown(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  // Extracted master query builder to eliminate duplication
  const buildProductQuery = () => {
    let selectStr = 'id, title, price_gnf, wholesale_price_gnf, image_urls, description, category, created_at, stock_quantity, max_stock, stores(id, store_name, avatar_url, location_commune, is_open, is_verified_store)';
    
    // We use !inner here because we are filtering by columns in the joined 'stores' table.
    // Without !inner, Supabase (PostgREST) won't prioritize/apply the filter deep in the join properly in some contexts.
    if (filterType === 'followed' || shopVendor || (selectedRegion !== 'Toute la Guinée')) {
       selectStr = 'id, title, price_gnf, wholesale_price_gnf, image_urls, description, category, created_at, stock_quantity, max_stock, stores!inner(id, store_name, avatar_url, location_commune, is_open, is_verified_store)';
    }

    let query = supabase
      .from('products')
      .select(selectStr, { count: 'exact' })
      // SF-BUG-1 FIX: Only fetch active, visible, approved products on the
      // public storefront. Real enforcement is at the RLS layer, but we
      // apply these filters here as well for defense-in-depth.
      .eq('is_active', true)
      .neq('moderation_status', 'rejected');

    if (filterType === 'followed') {
       if (followedVendors.length > 0) {
         query = query.in('stores.id', followedVendors);
       } else {
         return null; // Signals early exit (empty state)
       }
    } else if (filterType === 'nearby') {
       return null; // Signals early exit (empty state via map requirement)
    }

    if (shopVendor) {
      query = query.ilike('stores.store_name', shopVendor);
    }
    if (shopPromoOnly) {
      query = query.lt('stock_quantity', 10);
    }
        if (globalSearchQuery) {
          const words = globalSearchQuery.split(/\s+/).filter(w => w.length >= 2);
          if (words.length > 0) {
            words.forEach(word => {
              query = query.or(`title.ilike.%${word}%,description.ilike.%${word}%,category.ilike.%${word}%`);
            });
          }
        }
    if (selectedCategory !== 'Toutes') {
      query = query.eq('category', selectedCategory);
    }
    if (minPrice) {
      query = query.gte('price_gnf', parseInt(minPrice));
    }
    if (maxPrice) {
      query = query.lte('price_gnf', parseInt(maxPrice));
    }
    if (selectedRegion !== 'Toute la Guinée') {
      if (selectedRegion === 'Conakry') {
         query = query.in('stores.location_commune', GUINEA_LOCATIONS['Conakry']);
      } else {
         query = query.eq('stores.location_commune', selectedRegion);
      }
    }

    switch (sortBy) {
      case 'price-asc': return query.order('price_gnf', { ascending: true });
      case 'price-desc': return query.order('price_gnf', { ascending: false });
      case 'vendor-asc': return query.order('title', { ascending: true });
      case 'vendor-desc': return query.order('title', { ascending: false });
      case 'newest':
      case 'pertinence':
      default: return query.order('created_at', { ascending: false });
    }
  };

  useEffect(() => {
    async function fetchProducts(isLoadMore = false) {
      if (!isLoadMore) {
        setLoading(true);
        setFetchError(null);
        setPage(0);
      } else {
        setLoadingMore(true);
      }

      try {
        const from = isLoadMore ? (page + 1) * PAGE_SIZE : 0;
        const to = from + PAGE_SIZE - 1;

        const query = buildProductQuery();
        
        if (!query) {
           setProducts([]);
           setHasMore(false);
           setLoading(false);
           return;
        }

        // Use safeSupabaseQuery for resilience
        const { data, error, count } = await safeSupabaseQuery(query.range(from, to));
        
        if (error) {
          // If it's a transient network error, don't show the full error screen immediately
          if (error.isFetchError) {
             console.warn("Transient network issue, keeping existing data.");
             setHasMore(false); // Stop loading more for now
             return;
          }
          throw error;
        }
        
        if (data && data.length > 0) {
          if (isLoadMore) {
             setProducts(prev => {
               const newProducts = data.filter(d => !prev.some(p => p.id === d.id));
               return [...prev, ...newProducts as unknown as Product[]];
             });
          } else {
             setProducts(data as unknown as Product[]);
          }
          
          if (count && from + data.length >= count) {
            setHasMore(false);
          } else if (data.length < PAGE_SIZE) {
            setHasMore(false);
          } else {
            setHasMore(true);
          }
        } else {
          // ⚠ 0 results is NOT an error — clear any stale fetchError from a
          // previous failed attempt so the empty-state UI is shown instead of
          // the "Erreur de connexion" banner.
          if (!isLoadMore) {
            setProducts([]);
            setFetchError(null);
          }
          setHasMore(false);
        }

        if (isLoadMore) {
           setPage(prev => prev + 1);
        }
      } catch (err: any) {
        console.error('Database connection failed:', err);
        // Distinguish a Supabase mis-configuration (bad/missing env vars) from a
        // true network failure so the banner message stays accurate.
        const isConfigError =
          err?.message?.includes('Supabase is not configured') ||
          err?.message?.includes('Missing Supabase credentials');
        setFetchError(
          isConfigError
            ? "La configuration du service est incomplète. Contactez le support."
            : "Une erreur de connexion est survenue. Veuillez vérifier votre réseau et réessayer."
        );
        if (!isLoadMore && products.length === 0) setProducts([]);
      } finally {
        setLoading(false);
        setLoadingMore(false);
      }
    }

    fetchProducts();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [filterType, selectedRegion, globalSearchQuery, selectedCategory, sortBy, minPrice, maxPrice, followedVendors, retryKey]);

  // Infinite Scroll Intersection Observer
  const loadMoreRef = useRef<HTMLDivElement>(null);

  const filterDependenciesHash = [filterType, selectedRegion, globalSearchQuery, selectedCategory, sortBy, minPrice, maxPrice, followedVendors].join('|');

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting && hasMore && !loadingMore && !loading) {
          setLoadingMore(true);
          const currentLength = products.length;
          const from = currentLength;
          const to = currentLength + PAGE_SIZE - 1;
          
          const query = buildProductQuery();

          if (!query) {
             setLoadingMore(false);
             return;
          }

          query.range(from, to).then(({ data, error }) => {
            if (!error && data) {
              if (data.length < PAGE_SIZE) setHasMore(false);
              setProducts(prev => {
                const newProducts = data.filter(d => !prev.some(p => p.id === d.id));
                return [...prev, ...newProducts as unknown as Product[]];
              });
              setPage(prev => prev + 1);
            } else {
              setHasMore(false);
            }
            setLoadingMore(false);
          });
        }
      },
      { threshold: 0.1 }
    );

    const currentRef = loadMoreRef.current;
    if (currentRef) observer.observe(currentRef);

    return () => {
      if (currentRef) observer.unobserve(currentRef);
    };
  }, [hasMore, loadingMore, loading, products.length, filterDependenciesHash]);

  if (loading) {
    return (
      <section className="px-4 md:px-10 py-16 bg-gray-50 dark:bg-gray-800 dark:bg-gray-950 min-h-screen">
        <div className="max-w-[1600px] mx-auto">
          {/* Skeleton Controls */}
          <div className="flex justify-between items-center mb-8">
            <Skeleton className="h-6 w-64 rounded-xl bg-gray-200 dark:bg-gray-800" />
            <div className="hidden sm:flex gap-4">
              <Skeleton className="h-10 w-40 rounded-full bg-gray-200 dark:bg-gray-800" />
            </div>
          </div>

          {/* Offline pill — shown when loading but the device reports offline */}
          {!isOnline && (
            <div className="flex items-center gap-2 mb-6 px-4 py-3 rounded-2xl bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-700/40 text-amber-700 dark:text-amber-400 text-sm font-semibold">
              <WifiOff className="w-4 h-4 shrink-0" />
              <span>Aucune connexion. Les données se chargeront automatiquement quand vous serez en ligne.</span>
            </div>
          )}

          {/* Skeleton Grid */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6">
            {[...Array(8)].map((_, i) => (
              <div key={i} className="flex flex-col bg-white bg-white dark:bg-gray-900 rounded-2xl overflow-hidden border border-gray-100 border-gray-100 dark:border-gray-800">
                <Skeleton className="w-full aspect-[4/5] bg-gray-200 dark:bg-gray-800" />
                <div className="p-4 flex flex-col gap-2 relative">
                  <Skeleton className="absolute -top-6 right-4 w-10 h-10 rounded-full bg-gray-200 dark:bg-gray-800 border-2 border-white dark:border-gray-900" />
                  <Skeleton className="w-24 h-4 rounded mt-4 bg-gray-200 dark:bg-gray-800" />
                  <Skeleton className="w-full h-4 bg-gray-200 dark:bg-gray-800" />
                  <div className="mt-2 pt-2 border-t border-gray-50 dark:border-gray-800">
                    <Skeleton className="w-20 h-6 bg-gray-200 dark:bg-gray-800" />
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
    );
  }

  // Flag boosted products and sort them to the top
  const displayedProducts = [...products]
    .map(p => ({
      ...p,
      is_propulsed: p.stores?.id ? propulsedStoreIds.has(p.stores.id) : false,
    }))
    .sort((a, b) => {
      if (a.is_propulsed && !b.is_propulsed) return -1;
      if (!a.is_propulsed && b.is_propulsed) return 1;
      return 0;
    });

  const popularProducts = products.slice(0, 4);

  if (fetchError) {
    return (
      <section className="px-4 md:px-10 py-20 bg-gray-50 dark:bg-gray-950 flex items-center justify-center min-h-screen">
        <div className="bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-700 text-gray-900 dark:text-white p-8 md:p-12 rounded-3xl flex flex-col items-center gap-6 text-center max-w-md w-full shadow-xl">

          {/* Animated icon */}
          <div className={`w-20 h-20 rounded-full flex items-center justify-center ${
            isOnline ? 'bg-red-50 dark:bg-red-900/20 text-red-500' : 'bg-amber-50 dark:bg-amber-900/20 text-amber-500'
          }`}>
            {isOnline
              ? <X className="w-9 h-9" />
              : <WifiOff className="w-9 h-9" />
            }
          </div>

          <div className="space-y-2">
            <h3 className="text-xl md:text-2xl font-bold tracking-tight">
              {isOnline ? 'Erreur de connexion' : 'Pas de connexion internet'}
            </h3>
            <p className="text-sm font-medium text-gray-500 dark:text-gray-400 leading-relaxed">
              {isOnline
                ? 'Impossible de charger les produits. Le serveur est peut-être momentanément indisponible.'
                : 'Vous êtes hors ligne. Vérifiez votre connexion Wi-Fi ou données mobiles, puis réessayez.'}
            </p>
          </div>

          {/* Connection status indicator */}
          <div className={`flex items-center gap-2 text-xs font-semibold px-4 py-2 rounded-full border ${
            isOnline
              ? 'bg-green-50 dark:bg-green-900/20 text-green-600 dark:text-green-400 border-green-200 dark:border-green-800'
              : 'bg-red-50 dark:bg-red-900/20 text-red-600 dark:text-red-400 border-red-200 dark:border-red-800'
          }`}>
            <span className={`w-2 h-2 rounded-full ${
              isOnline ? 'bg-green-500 animate-pulse' : 'bg-red-500'
            }`} />
            {isOnline ? 'Connexion active' : 'Hors ligne'}
          </div>

          {/* Retry button — triggers a re-fetch via retryKey, NO full page reload */}
          <button
            id="products-retry-btn"
            onClick={handleRetry}
            disabled={!isOnline}
            className="flex items-center justify-center gap-2 bg-[#ff6600] disabled:opacity-50 disabled:cursor-not-allowed text-white px-8 py-3 rounded-full text-[13px] font-bold tracking-wide hover:bg-[#e62e00] active:scale-95 transition-all shadow-md w-full"
          >
            <RefreshCw className="w-4 h-4" />
            {isOnline ? 'Réessayer' : 'En attente de connexion…'}
          </button>
        </div>
      </section>
    );
  }

  if (displayedProducts.length === 0 && !loading) {
    return (
      <motion.section 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        className="px-4 md:px-10 py-10 md:py-20 bg-gray-50 dark:bg-gray-800 dark:bg-transparent"
      >
        <div className="max-w-2xl mx-auto text-center mb-16 px-4">
          <motion.div 
            animate={{ 
              y: [0, -10, 0]
            }}
            transition={{ 
              duration: 4, 
              repeat: Infinity, 
              ease: "easeInOut" 
            }}
            className="w-20 h-20 md:w-24 md:h-24 bg-white bg-white dark:bg-gray-900 rounded-full flex items-center justify-center mx-auto mb-6 md:mb-8 shadow-md border border-gray-200 dark:border-gray-700 dark:border-white/10 text-[#ff6600]"
          >
            {filterType === 'followed' ? (
              <Heart className="w-8 h-8 md:w-10 md:h-10" />
            ) : filterType === 'nearby' ? (
              <MapPin className="w-8 h-8 md:w-10 md:h-10" />
            ) : (
              <Search className="w-8 h-8 md:w-10 md:h-10" />
            )}
          </motion.div>
          <h3 
            className="text-2xl md:text-3xl font-bold text-gray-900 text-gray-900 dark:text-white mb-4 tracking-tight"
          >
            {filterType === 'followed' ? 'Aucune boutique suivie' : filterType === 'nearby' ? 'Boutiques autour de vous' : 'Aucun résultat trouvé...'}
          </h3>
          <p 
            className="text-gray-500 text-gray-500 dark:text-gray-400 text-[14px] md:text-base font-medium leading-relaxed mb-8"
          >
            {filterType === 'followed' 
              ? "Vous ne suivez encore aucune boutique. Abonnez-vous à vos vendeurs préférés pour ne rien rater !"
              : filterType === 'nearby'
                ? "Activez la géolocalisation de votre appareil pour découvrir instantanément les produits vendus à quelques pas de chez vous."
                : globalSearchQuery 
                  ? `Le terme "${globalSearchQuery}" ne correspond à aucun produit actuellement à ${selectedRegion}.`
                  : `Aucun produit disponible pour ces filtres à ${selectedRegion}.`}
          </p>
          <div className="flex flex-col sm:flex-row justify-center gap-3">
             {filterType === 'followed' ? (
               <button 
                 onClick={() => window.location.href = '/'}
                 className="bg-[#16a34a] text-white px-6 py-3 rounded-full text-[13px] font-bold tracking-wide hover:bg-[#15803d] transition-colors shadow-md"
               >
                 Découvrir des boutiques
               </button>
             ) : filterType === 'nearby' ? (
               <button
                 onClick={() => {
                   if (!isGeolocationPermitted()) {
                     showToast("Localisation Conakry activée ! Boutiques à proximité affichées.", "success");
                     return;
                   }
                   safeGetCurrentPosition(
                     () => showToast("Localisation activée ! Boutiques à proximité chargées.", "success"),
                     (err) => {
                       if (err.isPolicyRestricted) {
                         showToast("Localisation Conakry activée ! Boutiques à proximité affichées.", "success");
                       } else {
                         showToast("Accès refusé. Activez la localisation dans les paramètres.", "error");
                       }
                     }
                   );
                 }}
                 className="bg-[#16a34a] text-white px-6 py-3 rounded-full text-[13px] font-bold tracking-wide hover:bg-[#15803d] transition-colors shadow-md flex items-center justify-center gap-2 mx-auto"
               >
                 <MapPin className="w-4 h-4" /> Activer la localisation
               </button>
             ) : (
               <>
                 <button 
                    onClick={() => useStore.getState().setGlobalSearchQuery('')}
                    className="bg-[#ff6600] text-white px-6 py-3 rounded-full text-[13px] font-bold tracking-wide hover:bg-[#e62e00] transition-colors shadow-md w-full sm:w-auto"
                  >
                    Effacer la recherche
                  </button>
                  <button 
                    onClick={() => useStore.getState().setSelectedRegion('Toute la Guinée')}
                    className="bg-white dark:bg-gray-900 text-gray-700 border border-gray-300 px-6 py-3 rounded-full text-[13px] font-bold tracking-wide hover:bg-gray-50 dark:bg-gray-800 transition-colors w-full sm:w-auto"
                  >
                    Partout en Guinée
                  </button>
               </>
             )}
          </div>
        </div>

        {/* Popular Section (Discovery Feed) */}
        <div className="max-w-7xl mx-auto border-t border-gray-200 dark:border-gray-700 dark:border-white/5 pt-8">
           <div className="flex items-center justify-between mb-4 gap-4">
              <h4 className="text-xl font-bold text-gray-900 text-gray-900 dark:text-white flex items-center gap-2">
                 <Zap className="w-5 h-5 text-yellow-500" fill="currentColor" /> Populaire
              </h4>
           </div>
           
           <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 md:gap-4">
              {popularProducts.map((product, index) => (
                <ProductCard 
                  key={product.id}
                  product={product} 
                  index={index}
                />
              ))}
           </div>
        </div>
      </motion.section>
    );
  }

  return (
    <section className="px-2 md:px-6 pt-4 pb-12 bg-gray-50 dark:bg-gray-800 dark:bg-gray-950 min-h-screen">
      <div className="max-w-[1400px] mx-auto">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6 md:mb-8">
          <div className="text-lg md:text-xl font-bold text-gray-900 text-gray-900 dark:text-white">
            Produits <span className="text-gray-500 dark:text-gray-400 font-normal text-sm ml-2">{displayedProducts.length} articles</span>
          </div>
          
          <div className="flex items-center gap-3 w-full sm:w-auto">
            {/* Price Range Filter */}
            <div className="hidden md:flex items-center gap-2 bg-white bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-700 dark:border-gray-800 rounded-lg px-3 py-1.5 shadow-sm">
              <input 
                type="number" 
                placeholder="Min" 
                value={minPrice}
                onChange={(e) => setMinPrice(e.target.value)}
                className="w-16 text-[13px] text-gray-900 text-gray-900 dark:text-white outline-none bg-transparent"
              />
              <span className="text-gray-300">-</span>
              <input 
                type="number" 
                placeholder="Max" 
                value={maxPrice}
                onChange={(e) => setMaxPrice(e.target.value)}
                className="w-16 text-[13px] text-gray-900 text-gray-900 dark:text-white outline-none bg-transparent"
              />
              {(minPrice || maxPrice) && (
                <button 
                  onClick={() => { setMinPrice(''); setMaxPrice(''); }}
                  className="ml-1 p-1 text-gray-400 hover:text-red-500"
                >
                  <X className="w-3 h-3" />
                </button>
              )}
            </div>

            {/* Sort Dropdown */}
            <div className="relative w-full sm:w-auto" ref={dropdownRef}>
              <button
                onClick={() => setShowSortDropdown(!showSortDropdown)}
                className="flex items-center justify-between gap-4 text-[13px] font-bold text-gray-700 dark:text-gray-200 bg-white bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-700 dark:border-gray-800 rounded-lg px-4 py-2 w-full sm:w-auto shadow-sm hover:border-[#ff6600] transition-colors"
              >
                <div className="flex items-center gap-2">
                  <SlidersHorizontal className="w-4 h-4 text-gray-400" />
                  <span>{SORT_OPTIONS.find(opt => opt.value === sortBy)?.label}</span>
                </div>
                <ChevronDown className="w-4 h-4 text-gray-400" />
              </button>

              <AnimatePresence>
                {showSortDropdown && (
                  <motion.div
                    initial={{ opacity: 0, y: 5 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: 5 }}
                    className="absolute right-0 top-full mt-2 w-56 bg-white bg-white dark:bg-gray-900 border border-gray-100 border-gray-100 dark:border-gray-800 rounded-xl z-50 py-2 shadow-xl"
                  >
                    {SORT_OPTIONS.map((option) => (
                      <button
                        key={option.value}
                        onClick={() => {
                          setSortBy(option.value);
                          setShowSortDropdown(false);
                        }}
                        className={`w-full flex items-center justify-between px-4 py-2 text-[13px] font-medium transition-colors ${
                          sortBy === option.value ? 'bg-orange-50 dark:bg-orange-900/20 text-[#ff6600]' : 'text-gray-600 dark:text-gray-300 hover:bg-gray-50 dark:bg-gray-800 dark:hover:bg-gray-800'
                        }`}
                      >
                        {option.label}
                        {sortBy === option.value && <Check className="w-4 h-4" />}
                      </button>
                    ))}
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-3 md:gap-4">
          {displayedProducts.map((product, index) => (
            <ProductCard 
              key={product.id}
              product={product} 
              index={index}
              onShare={setSharingProduct}
              onQuickView={setQuickViewProduct}
            />
          ))}
        </div>

        {/* Infinite Scroll Loader */}
        {hasMore && (
           <div ref={loadMoreRef} className="w-full py-16 flex justify-center">
              {loadingMore ? (
                 <div className="w-8 h-8 border-[3px] border-gray-200 dark:border-gray-700 border-t-[#ff6600] rounded-full animate-spin" />
              ) : (
                <div className="h-2 w-full" />
              )}
           </div>
        )}
      </div>

      <ShareDialog
        isOpen={!!sharingProduct}
        onClose={() => setSharingProduct(null)}
        productTitle={sharingProduct?.title || ''}
        productId={sharingProduct?.id || ''}
      />

      <QuickViewModal
        isOpen={!!quickViewProduct}
        onClose={() => setQuickViewProduct(null)}
        product={quickViewProduct}
      />
    </section>
  );
}