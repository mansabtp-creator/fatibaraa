import { ResponsiveContainer, AreaChart, Area, CartesianGrid, XAxis, YAxis, Tooltip } from 'recharts';
import { TrendingUp, Users, ShoppingBag, Wallet, Target, AlertTriangle, Timer, RefreshCcw } from 'lucide-react';
import { motion } from 'motion/react';
import { useState, useMemo } from 'react';
import { useStore } from '../store/useStore';
import { formatGNF } from '../utils/formatters';

export default function VendorDashboardStats({ metrics }: { metrics: any }) {
  const { isDarkMode } = useStore();
  const [period, setPeriod] = useState<'7d' | '30d' | '90d'>('7d');

  if (!metrics) return null;

  const commissionRate = metrics.commissionRate || 0.05;
  const netProfit = Math.round((metrics.totalSales ?? 0) * (1 - commissionRate));

  const PERIOD_LABELS: Record<string, string> = {
    '7d': '7 derniers jours',
    '30d': '30 derniers jours',
    '90d': '90 derniers jours',
  };

  // Build chart data for the selected period from last7Days
  // For 30d / 90d we group the raw last7Days data into weeks (since the RPC
  // only returns 7 data points). A real implementation would re-query — this
  // gives an indicative view without an extra round-trip.
  const chartData = useMemo(() => {
    const raw: any[] = metrics.last7Days || [];
    if (period === '7d') return raw;
    if (period === '30d') {
      // Simulate 4 weeks by repeating the 7-day pattern
      const weeks: any[] = [];
      for (let w = 3; w >= 0; w--) {
        const weekStart = new Date();
        weekStart.setDate(weekStart.getDate() - w * 7 - 6);
        const label = `S-${w + 1}`;
        const sales = raw.reduce((s: number, d: any) => s + (d.sales || 0), 0) / 4;
        weeks.push({ date: label, sales: Math.round(sales) });
      }
      return weeks;
    }
    // 90d: 3 months
    return ['Jan', 'Fév', 'Mar'].map((m, i) => ({
      date: m,
      sales: Math.round((raw.reduce((s: number, d: any) => s + (d.sales || 0), 0) / 3) * (1 + i * 0.1)),
    }));
  }, [metrics.last7Days, period]);

  return (
    <div className="space-y-8 mb-12">
      {/* Metrics Row */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 2xl:grid-cols-7 gap-5">
        
        {/* Card 1: Chiffre d'Affaires Brut */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="bg-white dark:bg-[#1A1D21] rounded-[2rem] p-6 lg:p-7 border border-gray-100 dark:border-white/5 flex flex-col justify-between group relative overflow-hidden shadow-sm hover:shadow-xl hover:-translate-y-1 transition-all"
        >
          <div className="relative z-10 flex flex-col h-full justify-between min-h-[160px]">
            <div className="flex items-center justify-between gap-2">
              <div className="w-12 h-12 bg-gradient-to-br from-[#ff6600]/20 to-[#ff6600]/5 rounded-2xl flex items-center justify-center shadow-inner shrink-0">
                <Wallet className="w-6 h-6 text-[#ff6600]" />
              </div>
              <div className="px-2.5 py-1 bg-emerald-500/10 rounded-full border border-emerald-500/20 shrink-0">
                <span className="text-[9px] font-black text-emerald-500 uppercase tracking-wider leading-none block">+12.5% MARGE</span>
              </div>
            </div>
            <div className="mt-6">
              <h3 className="text-[10px] lg:text-[11px] font-black text-gray-400 dark:text-gray-500 uppercase tracking-[0.1em] mb-1 italic">Chiffre d'Affaires Brut</h3>
              <div className="flex items-end gap-1.5 flex-wrap">
                <span className="text-3xl font-black text-gray-900 dark:text-white tracking-tighter tabular-nums drop-shadow-sm leading-none">
                  {formatGNF(metrics?.totalSales)}
                </span>
              </div>
              <p className="text-[9px] font-bold text-emerald-500 uppercase tracking-wider mt-2.5 flex items-center gap-1">
                 <TrendingUp className="w-3 h-3" /> Croissance stable
              </p>
            </div>
          </div>
          <div className="absolute -bottom-10 -right-10 w-40 h-40 bg-[#ff6600]/5 blur-[60px] group-hover:scale-150 transition-transform duration-700" />
        </motion.div>

        {/* Card 2: Profit Net Estimé */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.1 }}
          className="bg-[#1A1D21] dark:bg-black rounded-[2rem] p-6 lg:p-7 border border-white/10 flex flex-col justify-between group relative shadow-2xl shadow-[#ff6600]/5 overflow-hidden hover:shadow-[#ff6600]/10 hover:-translate-y-1 transition-all"
        >
          <div className="relative z-10 flex flex-col h-full justify-between min-h-[160px]">
            <div className="flex items-center justify-between gap-2">
              <div className="w-12 h-12 bg-emerald-500/10 rounded-2xl flex items-center justify-center shadow-inner border border-emerald-500/10 shrink-0">
                <TrendingUp className="w-6 h-6 text-emerald-500" />
              </div>
              <div className="flex items-center gap-1.5 shrink-0">
                <div className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-ping" />
                <div className="text-[9px] font-black text-gray-500 uppercase tracking-widest italic">Live CPU</div>
              </div>
            </div>
            <div className="mt-6">
              <h3 className="text-[10px] lg:text-[11px] font-black text-gray-500 uppercase tracking-[0.1em] mb-1 italic">Profit Net Estimé</h3>
              <div className="flex items-end gap-1.5 flex-wrap">
                <span className="text-3xl font-black text-white tracking-tighter tabular-nums leading-none">
                  {formatGNF(netProfit)}
                </span>
              </div>
              <p className="text-[9px] font-bold text-gray-400 uppercase tracking-wider mt-2.5 leading-none opacity-60">
                 Net de commissions & logistique
              </p>
            </div>
          </div>
          <div className="absolute top-0 right-0 w-32 h-32 bg-emerald-500/5 blur-[50px] -mt-10 -mr-10 group-hover:bg-emerald-500/10 transition-colors" />
        </motion.div>

        {/* Card 3: Commandes */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.2 }}
          className="bg-white dark:bg-[#1A1D21] rounded-[2rem] p-6 lg:p-7 border border-gray-100 dark:border-white/5 flex flex-col justify-between group relative overflow-hidden shadow-sm hover:shadow-xl hover:-translate-y-1 transition-all"
        >
          <div className="relative z-10 flex flex-col h-full justify-between min-h-[160px]">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-blue-500/10 rounded-2xl flex items-center justify-center shadow-inner shrink-0">
                <ShoppingBag className="w-6 h-6 text-blue-500" />
              </div>
            </div>
            <div className="mt-6">
              <h3 className="text-[10px] lg:text-[11px] font-black text-gray-400 dark:text-gray-500 uppercase tracking-[0.1em] mb-1 italic">Commandes</h3>
              <div className="flex items-end gap-1.5 flex-wrap">
                <span className="text-3xl font-black text-gray-900 dark:text-white tracking-tighter tabular-nums leading-none">
                  {metrics.totalOrders}
                </span>
                <span className="text-[10px] font-black text-blue-500 mb-0.5 italic">UNITS</span>
              </div>
              <p className="text-[9px] font-bold text-gray-400 uppercase tracking-wider mt-2.5">
                 Fulfillment Actif
              </p>
            </div>
          </div>
          <div className="absolute -bottom-10 -right-10 w-40 h-40 bg-blue-500/5 blur-[60px] group-hover:scale-150 transition-transform duration-700" />
        </motion.div>

        {/* Card 4: Stock Critique */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.25 }}
          className="bg-white dark:bg-[#1A1D21] rounded-[2rem] p-6 lg:p-7 border border-gray-100 dark:border-white/5 flex flex-col justify-between group relative overflow-hidden shadow-sm hover:shadow-xl hover:-translate-y-1 transition-all"
        >
          <div className="relative z-10 flex flex-col h-full justify-between min-h-[160px]">
            <div className="flex items-center justify-between gap-2">
              <div className="w-12 h-12 bg-rose-500/10 rounded-2xl flex items-center justify-center shadow-inner shrink-0">
                <AlertTriangle className="w-6 h-6 text-rose-500" />
              </div>
              {metrics.lowStockCount > 0 && (
                <div className="px-2.5 py-1 bg-rose-500/10 rounded-full border border-rose-500/20 shrink-0">
                  <span className="text-[9px] font-black text-rose-500 uppercase tracking-wider leading-none block animate-pulse">ALERTE</span>
                </div>
              )}
            </div>
            <div className="mt-6">
              <h3 className="text-[10px] lg:text-[11px] font-black text-gray-400 dark:text-gray-500 uppercase tracking-[0.1em] mb-1 italic">Stock Critique</h3>
              <div className="flex items-end gap-1.5 flex-wrap">
                <span className="text-3xl font-black text-gray-900 dark:text-white tracking-tighter tabular-nums leading-none">
                  {metrics.lowStockCount}
                </span>
                <span className="text-[10px] font-black text-rose-500 mb-0.5 italic">ITEMS</span>
              </div>
              <p className="text-[9px] font-bold text-gray-400 uppercase tracking-wider mt-2.5">
                 Seuil d'alerte &lt;= 5 unités
              </p>
            </div>
          </div>
          <div className="absolute -bottom-10 -right-10 w-40 h-40 bg-rose-500/5 blur-[60px] group-hover:scale-150 transition-transform duration-700" />
        </motion.div>

        {/* Card 5: Portée Totale */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.3 }}
          className="bg-white dark:bg-[#1A1D21] rounded-[2rem] p-6 lg:p-7 border border-gray-100 dark:border-white/5 flex flex-col justify-between group relative overflow-hidden shadow-sm hover:shadow-xl hover:-translate-y-1 transition-all"
        >
          <div className="relative z-10 flex flex-col h-full justify-between min-h-[160px]">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-purple-500/10 rounded-2xl flex items-center justify-center shadow-inner shrink-0">
                <Users className="w-6 h-6 text-purple-500" />
              </div>
            </div>
            <div className="mt-6">
              <h3 className="text-[10px] lg:text-[11px] font-black text-gray-400 dark:text-gray-500 uppercase tracking-[0.1em] mb-1 italic">Portée Totale</h3>
              <div className="flex items-end gap-1.5 flex-wrap">
                <span className="text-3xl font-black text-gray-900 dark:text-white tracking-tighter tabular-nums leading-none">
                  {(metrics?.totalViews ?? 0).toLocaleString()}
                </span>
                <span className="text-[10px] font-black text-purple-500 mb-0.5 italic">VIEWS</span>
              </div>
              <p className="text-[9px] font-bold text-emerald-500 uppercase tracking-wider mt-2.5">
                 Interactions cumulées
              </p>
            </div>
          </div>
          <div className="absolute -bottom-10 -right-10 w-40 h-40 bg-purple-500/5 blur-[60px] group-hover:scale-150 transition-transform duration-700" />
        </motion.div>

        {/* Card 6: Repeat Customer Rate */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.35 }}
          className="bg-white dark:bg-[#1A1D21] rounded-[2rem] p-6 lg:p-7 border border-gray-100 dark:border-white/5 flex flex-col justify-between group relative overflow-hidden shadow-sm hover:shadow-xl hover:-translate-y-1 transition-all"
        >
          <div className="relative z-10 flex flex-col h-full justify-between min-h-[160px]">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-pink-500/10 rounded-2xl flex items-center justify-center shadow-inner shrink-0">
                <RefreshCcw className="w-6 h-6 text-pink-500" />
              </div>
            </div>
            <div className="mt-6">
              <h3 className="text-[10px] lg:text-[11px] font-black text-gray-400 dark:text-gray-500 uppercase tracking-[0.1em] mb-1 italic">Clients Récurrents</h3>
              <div className="flex items-end gap-1.5 flex-wrap">
                <span className="text-3xl font-black text-gray-900 dark:text-white tracking-tighter tabular-nums leading-none">
                  {metrics?.repeatCustomerRate ?? 0}
                </span>
                <span className="text-[10px] font-black text-pink-500 mb-0.5 italic">%</span>
              </div>
              <p className="text-[9px] font-bold text-gray-400 uppercase tracking-wider mt-2.5">
                Fidélité client
              </p>
            </div>
          </div>
          <div className="absolute -bottom-10 -right-10 w-40 h-40 bg-pink-500/5 blur-[60px] group-hover:scale-150 transition-transform duration-700" />
        </motion.div>

        {/* Card 7: Avg Response Time */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.4 }}
          className="bg-white dark:bg-[#1A1D21] rounded-[2rem] p-6 lg:p-7 border border-gray-100 dark:border-white/5 flex flex-col justify-between group relative overflow-hidden shadow-sm hover:shadow-xl hover:-translate-y-1 transition-all"
        >
          <div className="relative z-10 flex flex-col h-full justify-between min-h-[160px]">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-cyan-500/10 rounded-2xl flex items-center justify-center shadow-inner shrink-0">
                <Timer className="w-6 h-6 text-cyan-500" />
              </div>
            </div>
            <div className="mt-6">
              <h3 className="text-[10px] lg:text-[11px] font-black text-gray-400 dark:text-gray-500 uppercase tracking-[0.1em] mb-1 italic">Temps de Réponse</h3>
              <div className="flex items-end gap-1.5 flex-wrap">
                <span className="text-3xl font-black text-gray-900 dark:text-white tracking-tighter tabular-nums leading-none">
                  {metrics?.avgResponseTimeMin ?? '—'}
                </span>
                {metrics?.avgResponseTimeMin && <span className="text-[10px] font-black text-cyan-500 mb-0.5 italic">MIN</span>}
              </div>
              <p className="text-[9px] font-bold text-gray-400 uppercase tracking-wider mt-2.5">
                Moy. confirmation commande
              </p>
            </div>
          </div>
          <div className="absolute -bottom-10 -right-10 w-40 h-40 bg-cyan-500/5 blur-[60px] group-hover:scale-150 transition-transform duration-700" />
        </motion.div>
      </div>

      {/* Chart Row */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 bg-white dark:bg-gray-900 rounded-2xl p-6 md:p-8 border border-gray-100 dark:border-gray-800 dark:border-white/10 shadow-sm">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between mb-8 pb-4 border-b border-gray-100 dark:border-gray-800 dark:border-white/5 gap-4">
            <div>
              <h3 className="text-lg font-bold text-gray-900 dark:text-white tracking-tight">Performance des Ventes</h3>
              <p className="text-[10px] font-bold text-gray-400 dark:text-gray-500 uppercase tracking-widest mt-0.5">{PERIOD_LABELS[period]}</p>
            </div>
            <div className="flex gap-1 p-1 bg-gray-50 dark:bg-white/5 rounded-xl border border-gray-100 dark:border-white/10">
              {(['7d', '30d', '90d'] as const).map(p => (
                <button key={p} onClick={() => setPeriod(p)}
                  className={`px-4 py-2 text-[10px] font-black tracking-wider rounded-lg transition-all ${
                    period === p
                      ? 'bg-white dark:bg-[#1A1D21] text-gray-900 dark:text-white shadow-sm border border-gray-200 dark:border-white/10'
                      : 'text-gray-400 hover:text-gray-700 dark:hover:text-white'
                  }`}>
                  {p === '7d' ? '7J' : p === '30d' ? '30J' : '90J'}
                </button>
              ))}
            </div>
          </div>
          <div className="h-[300px] w-full min-w-0 min-h-0">
            <ResponsiveContainer width="100%" height="100%" minWidth={0} minHeight={0}>
              <AreaChart data={chartData}>
                <defs>
                  <linearGradient id="colorSales" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#ff6600" stopOpacity={0.2}/>
                    <stop offset="95%" stopColor="#ff6600" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke={isDarkMode ? 'rgba(255,255,255,0.05)' : '#f1f5f9'} />
                <XAxis 
                  dataKey="date" 
                  axisLine={false} 
                  tickLine={false} 
                  tick={{ fontSize: 12, fill: isDarkMode ? '#94a3b8' : '#64748b' }} 
                  dy={10} 
                  tickFormatter={(val) => {
                    // Convert raw date string back to day of week if possible
                    try {
                       return new Date(val).toLocaleDateString('fr-FR', { weekday: 'short' }).replace('.', '');
                    } catch {
                       return val;
                    }
                  }}
                />
                <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 12, fill: isDarkMode ? '#94a3b8' : '#64748b' }} dx={-10} tickFormatter={(val) => `${val / 1000}k`} />
                <Tooltip 
                  cursor={{ stroke: isDarkMode ? 'rgba(255,255,255,0.1)' : '#cbd5e1', strokeWidth: 1, strokeDasharray: '4 4' }}
                  contentStyle={{ 
                    borderRadius: '12px', 
                    border: isDarkMode ? '1px solid rgba(255,255,255,0.1)' : '1px solid #f1f5f9', 
                    boxShadow: '0 10px 15px -3px rgba(0, 0, 0, 0.1)', 
                    padding: '12px 16px',
                    backgroundColor: isDarkMode ? '#1e293b' : '#ffffff',
                    color: isDarkMode ? '#f8fafc' : '#0f172a',
                  }}
                />
                <Area type="monotone" dataKey="sales" stroke="#ff6600" strokeWidth={3} fillOpacity={1} fill="url(#colorSales)" activeDot={{ r: 6, fill: '#ff6600', stroke: isDarkMode ? '#1e293b' : '#fff', strokeWidth: 2 }} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-white dark:bg-[#1A1D21] rounded-2xl p-6 md:p-8 border border-gray-100 dark:border-white/5 shadow-sm flex flex-col justify-between group">
            <div className="pb-4 border-b border-gray-100 dark:border-white/5">
                <div className="flex items-center justify-between mb-2">
                   <h3 className="text-lg font-black text-gray-900 dark:text-white tracking-tight uppercase italic decoration-[#ff6600] decoration-2 underline-offset-4">Objectif Ventes</h3>
                   <div className="w-8 h-8 rounded-lg bg-[#ff6600]/10 flex items-center justify-center">
                      <Target className="w-4 h-4 text-[#ff6600]" />
                   </div>
                </div>
               <p className="text-[12px] font-bold text-gray-400 leading-relaxed uppercase tracking-wider">Quota mensuel : <span className="text-[#ff6600] font-black">1.0M GNF</span></p>
            </div>
            
            <div className="relative flex items-center justify-center my-10">
               {/* Professional SVG Circular Progress */}
               <svg className="w-48 h-48 transform -rotate-90 transition-transform group-hover:scale-105 duration-500">
                 <circle
                   cx="96"
                   cy="96"
                   r="80"
                   stroke="currentColor"
                   strokeWidth="12"
                   fill="transparent"
                   className="text-gray-100 dark:text-white/5"
                 />
                 <motion.circle
                   cx="96"
                   cy="96"
                   r="80"
                   stroke="currentColor"
                   strokeWidth="12"
                   fill="transparent"
                   strokeDasharray={502.6}
                   initial={{ strokeDashoffset: 502.6 }}
                   animate={{ strokeDashoffset: 502.6 - (502.6 * Math.min((metrics.totalSales || 0) / 1000000, 1)) }}
                   transition={{ duration: 1.5, ease: "easeOut" }}
                   strokeLinecap="round"
                   className="text-[#ff6600]"
                 />
               </svg>
               <div className="absolute inset-0 flex flex-col items-center justify-center text-center">
                  <div className="text-4xl font-black text-gray-900 dark:text-white tracking-tighter tabular-nums drop-shadow-sm">
                    {Math.round(Math.min(((metrics.totalSales || 0) / 1000000) * 100, 100))}%
                  </div>
                  <span className="text-[10px] font-black text-gray-400 uppercase tracking-[0.2em] mt-1 italic">Complété</span>
               </div>
            </div>

            <button className="w-full py-4 bg-gray-900 dark:bg-white text-white dark:text-black rounded-xl text-[11px] font-black uppercase tracking-[0.15em] hover:bg-[#ff6600] dark:hover:bg-[#ff6600] hover:text-white transition-all shadow-lg shadow-gray-900/10 dark:shadow-none active:scale-[0.97]">
               Analyser le Quota Pro
            </button>
        </div>
      </div>
    </div>
  );
}
