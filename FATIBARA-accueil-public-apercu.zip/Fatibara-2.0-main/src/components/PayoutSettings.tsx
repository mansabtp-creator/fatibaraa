import React, { useState } from 'react';
import { supabase } from '../lib/supabase';
import { useToast } from '../context/ToastContext';
import { CreditCard, Wallet, AlertCircle, Percent } from 'lucide-react';
import { hapticFeedback } from '../lib/haptics';

interface PayoutSettingsProps {
  storeId: string;
  initialOrangeMoney?: string;
  initialMtnMoney?: string;
  initialStoreStatus?: string;
  initialGlobalSaleActive?: boolean;
  initialGlobalSalePercent?: number;
  onUpdate: (data: any) => void;
}

export function PayoutSettings({ storeId, initialOrangeMoney, initialMtnMoney, initialStoreStatus, initialGlobalSaleActive, initialGlobalSalePercent, onUpdate }: PayoutSettingsProps) {
  const { showToast } = useToast();
  const [orangeMoney, setOrangeMoney] = useState(initialOrangeMoney || '');
  const [mtnMoney, setMtnMoney] = useState(initialMtnMoney || '');
  const [storeStatus, setStoreStatus] = useState(initialStoreStatus || 'active');
  const [globalSaleActive, setGlobalSaleActive] = useState(initialGlobalSaleActive || false);
  const [globalSalePercent, setGlobalSalePercent] = useState(initialGlobalSalePercent || '');
  const [loading, setLoading] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrors({});
    let newErrors: Record<string, string> = {};

    const sanitizedOrange = orangeMoney.trim().replace(/\D/g, '');
    const sanitizedMtn = mtnMoney.trim().replace(/\D/g, '');

    if (sanitizedOrange && !/^(62|61|60)\d{7}$/.test(sanitizedOrange)) {
      newErrors.orangeMoney = "Numéro Orange invalide (Doit commencer par 62, 61 ou 60 et comporter 9 chiffres)";
    }
    if (sanitizedMtn && !/^(66|65)\d{7}$/.test(sanitizedMtn)) {
      newErrors.mtnMoney = "Numéro MTN invalide (Doit commencer par 66 ou 65 et comporter 9 chiffres)";
    }

    if (storeStatus === 'active' && !sanitizedOrange && !sanitizedMtn) {
      newErrors.general = "Veuillez configurer au moins un compte Orange ou MTN pour recevoir vos paiements.";
    }

    if (globalSaleActive) {
      const p = parseFloat(globalSalePercent as string);
      if (isNaN(p) || p < 1 || p > 100) {
        newErrors.globalSalePercent = "Le pourcentage doit être compris entre 1 et 100";
      }
    }

    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
      hapticFeedback('error');
      if (newErrors.general) {
        showToast(newErrors.general, "warning");
      } else {
        showToast("Veuillez corriger les erreurs de saisie.", "error");
      }
      return;
    }

    setLoading(true);
    try {
      const updateData: any = {
        payout_orange_money: sanitizedOrange,
        payout_mtn_money: sanitizedMtn,
        store_status: storeStatus,
        global_sale_active: globalSaleActive,
        global_sale_percent: globalSalePercent ? parseFloat(globalSalePercent as string) : null
      };

      const { error } = await supabase.from('stores').update(updateData).eq('id', storeId);

      if (error) {
        // Fallback for missing columns
        if (error.message.includes('column') && error.message.includes('not exist')) {
          console.warn('Metadata columns missing, retrying with core columns only...');
          const { global_sale_active, global_sale_percent, ...coreData } = updateData;
          const { error: retryError } = await supabase.from('stores').update(coreData).eq('id', storeId);
          if (retryError) throw retryError;
        } else {
          throw error;
        }
      }
      
      onUpdate({
        payout_orange_money: sanitizedOrange,
        payout_mtn_money: sanitizedMtn,
        store_status: storeStatus,
        global_sale_active: globalSaleActive,
        global_sale_percent: globalSalePercent ? parseFloat(globalSalePercent as string) : null
      });
      hapticFeedback('success');
      showToast("Paramètres mis à jour", "success");
    } catch (err: any) {
      hapticFeedback('error');
      showToast(err.message, "error");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-white bg-white dark:bg-gray-900 border border-brand-border/30 dark:border-white/10 rounded-[2rem] p-6 md:p-8 space-y-8">
      <div>
        <h2 className="text-2xl font-bold text-gray-900 text-gray-900 dark:text-white tracking-tighter flex items-center gap-2">
          <Wallet className="w-6 h-6 text-[#ff6600] dark:text-orange-400" />
          Paiements & Versements Directs
        </h2>
        <p className="text-[13px] font-bold text-brand-text-dim dark:text-gray-400 mt-2 tracking-wide">Configurez vos moyens de réception des paiements sécurisés.</p>
      </div>

      <form onSubmit={handleSave} className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-3">
             <label className="text-[12px] font-bold tracking-wider text-brand-text-dim dark:text-gray-400 ml-1 flex items-center gap-2">
               Orange Money (Guinée)
             </label>
             <input 
               type="text" 
               value={orangeMoney}
               onChange={(e) => setOrangeMoney(e.target.value.replace(/\D/g, ''))}
               placeholder="Ex: 620000000"
               maxLength={9}
               className={`w-full bg-gray-50 bg-gray-50 dark:bg-gray-800 border rounded-[1rem] p-4 text-[15px] font-bold text-gray-900 text-gray-900 dark:text-white outline-none transition-all ${errors.orangeMoney ? 'border-red-500' : 'border-brand-border/50 dark:border-white/10 focus:border-[#ff6600]'}`}
             />
             {errors.orangeMoney && <p className="text-red-500 text-xs font-bold uppercase tracking-wide flex items-center gap-1"><AlertCircle className="w-3 h-3"/>{errors.orangeMoney}</p>}
          </div>

          <div className="space-y-3">
             <label className="text-[12px] font-bold tracking-wider text-brand-text-dim dark:text-gray-400 ml-1 flex items-center gap-2">
               MTN Mobile Money (Guinée)
             </label>
             <input 
               type="text" 
               value={mtnMoney}
               onChange={(e) => setMtnMoney(e.target.value.replace(/\D/g, ''))}
               placeholder="Ex: 660000000"
               maxLength={9}
               className={`w-full bg-gray-50 bg-gray-50 dark:bg-gray-800 border rounded-[1rem] p-4 text-[15px] font-bold text-gray-900 text-gray-900 dark:text-white outline-none transition-all ${errors.mtnMoney ? 'border-red-500' : 'border-brand-border/50 dark:border-white/10 focus:border-[#ff6600]'}`}
             />
             {errors.mtnMoney && <p className="text-red-500 text-xs font-bold uppercase tracking-wide flex items-center gap-1"><AlertCircle className="w-3 h-3"/>{errors.mtnMoney}</p>}
          </div>
        </div>

        <div className="p-5 bg-gray-50 dark:bg-gray-800 dark:bg-white/5 border border-brand-border/50 dark:border-white/10 rounded-[1.5rem] mt-6 space-y-4">
          <div className="flex items-center justify-between">
             <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-orange-500/10 flex items-center justify-center">
                   <AlertCircle className="w-5 h-5 text-orange-500" />
                </div>
                <div>
                   <h3 className="font-bold text-[14px] text-gray-900 text-gray-900 dark:text-white">Mode Vacances (Holiday Mode)</h3>
                   <p className="text-[11px] font-bold text-brand-text-dim dark:text-gray-400">Mettez votre boutique en pause. Les clients ne pourront plus commander.</p>
                </div>
             </div>
             <label className="relative inline-flex items-center cursor-pointer">
                <input 
                  type="checkbox" 
                  className="sr-only peer" 
                  checked={storeStatus === 'holiday'} 
                  onChange={(e) => setStoreStatus(e.target.checked ? 'holiday' : 'active')} 
                />
                <div className="w-14 h-7 bg-brand-text-dim/20 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[4px] after:left-[4px] after:bg-white dark:bg-gray-900 after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-orange-500"></div>
             </label>
          </div>

          <div className="pt-4 border-t border-brand-border/30 dark:border-white/10 flex flex-col md:flex-row md:items-center justify-between gap-4">
             <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-red-600/10 flex items-center justify-center text-red-600">
                   <Percent className="w-5 h-5" />
                </div>
                <div>
                   <h3 className="font-bold text-[14px] text-gray-900 text-gray-900 dark:text-white">Soldes Globales</h3>
                   <p className="text-[11px] font-bold text-brand-text-dim dark:text-gray-400">Appliquez une réduction sur toute la boutique</p>
                </div>
             </div>
             <div className="flex items-center gap-4">
               {globalSaleActive && (
                 <div className="relative w-24">
                   <input 
                     type="number" 
                     value={globalSalePercent}
                     onChange={(e) => setGlobalSalePercent(e.target.value)}
                     placeholder="Ex: 15"
                     className={`w-full bg-white dark:bg-gray-900 border ${errors.globalSalePercent ? 'border-red-500' : 'border-brand-border/50 dark:border-white/10 text-gray-900 dark:text-white'} rounded-xl p-2 pr-8 text-[12px] font-bold focus:border-red-500 outline-none`}
                     min="0" max="100"
                   />
                   <Percent className="absolute right-3 top-1/2 -translate-y-1/2 w-3 h-3 text-brand-text-dim" />
                 </div>
               )}
               <label className="relative inline-flex items-center cursor-pointer">
                  <input 
                    type="checkbox" 
                    className="sr-only peer" 
                    checked={globalSaleActive} 
                    onChange={(e) => { setGlobalSaleActive(e.target.checked); if (!e.target.checked) setGlobalSalePercent(''); }} 
                  />
                  <div className="w-14 h-7 bg-brand-text-dim/20 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[4px] after:left-[4px] after:bg-white dark:bg-gray-900 after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-red-600"></div>
               </label>
             </div>
          </div>
          {errors.globalSalePercent && <p className="text-red-500 text-xs font-bold uppercase tracking-wide flex items-center gap-1 mt-2 text-right justify-end"><AlertCircle className="w-3 h-3"/>{errors.globalSalePercent}</p>}
        </div>

        <button 
          type="submit" 
          disabled={loading}
          className="w-full md:w-auto px-8 bg-gray-900 dark:bg-[#ff6600] text-brand-inverse font-bold tracking-wider text-[12px] py-4 rounded-[1rem] hover:bg-black dark:hover:bg-[#e62e00] transition-all disabled:opacity-50"
        >
          {loading ? 'Sauvegarde...' : 'Sauvegarder les Payouts'}
        </button>
      </form>
    </div>
  );
}
