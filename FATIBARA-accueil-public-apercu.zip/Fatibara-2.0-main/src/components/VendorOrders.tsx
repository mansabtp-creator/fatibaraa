import React, { useState, useEffect, useCallback, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Package, Truck, CheckCircle, Clock, Search, ExternalLink, MessageCircle, MoreHorizontal, Navigation, ShieldCheck, AlertTriangle, FileText, Download, XCircle, Users, Timer, UserCheck, Radio, Store, Phone, Eye, MapPin, ChevronRight, X, Copy, Check, RefreshCw, LayoutGrid, List, Filter } from 'lucide-react';
import { Skeleton } from './ui/Skeleton';
import { supabase } from '../lib/supabase';
import { realtimeKey } from '../lib/realtimeKeys';
import { useToast } from '../context/ToastContext';
import { useAppContext } from '../context/AppContext';
import { hapticFeedback } from '../lib/haptics';
import OrderInvoiceModal from './OrderInvoiceModal';
import { OrderKanban, KanbanOrder, KanbanOrderItem, OrderStatus as KanbanOrderStatus } from './OrderKanban';
import { safeNotify } from '../utils/notifications';
import { formatGNF, timeAgo } from '../utils/formatters';

const STATUS_CONFIG: Record<string, any> = {
  pending:          { label: 'Audit Paiement',              color: 'text-amber-600',   bg: 'bg-amber-500/10',   icon: Clock        },
  paid:             { label: 'Payée (Elite)',               color: 'text-emerald-600', bg: 'bg-emerald-500/10', icon: ShieldCheck  },
  confirmed:        { label: 'Confirmée (COD)',             color: 'text-blue-500',    bg: 'bg-blue-500/5',     icon: CheckCircle  },
  accepted:         { label: 'Confirmée Vendeur',           color: 'text-blue-600',    bg: 'bg-blue-500/10',    icon: CheckCircle  },
  // 'preparing' is a legacy status kept for display compat with older orders
  preparing:        { label: 'En Préparation',              color: 'text-purple-600',  bg: 'bg-purple-500/10',  icon: Package      },
  // 'processing' is the DB-canonical status for orders being packed
  processing:       { label: 'En Préparation',              color: 'text-purple-600',  bg: 'bg-purple-500/10',  icon: Package      },
  ready_for_pickup: { label: 'Prêt pour Expédition',        color: 'text-orange-600',  bg: 'bg-orange-500/10',  icon: Truck        },
  in_transit:       { label: 'Transit National',            color: 'text-[#ff6600]',   bg: 'bg-[#ff6600]/10',   icon: Navigation   },
  out_for_delivery: { label: 'En cours de livraison',       color: 'text-[#ff6600]',   bg: 'bg-[#ff6600]/10',   icon: Navigation   },
  delivered:        { label: 'Délivrée avec Succès',        color: 'text-emerald-700', bg: 'bg-emerald-500/10', icon: CheckCircle  },
  cancelled:        { label: 'Litige / Annulée',            color: 'text-rose-600',    bg: 'bg-rose-500/10',    icon: AlertTriangle},
};

interface VendorOrdersProps {
  /** DB status strings to filter on — empty array means 'all' */
  activeStatuses?: string[];
}

export default function VendorOrders({ activeStatuses = [] }: VendorOrdersProps) {
  const [orders, setOrders] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [copiedOrderId, setCopiedOrderId] = useState<string | null>(null);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [viewMode, setViewMode] = useState<'list' | 'kanban'>('list');
  const [selectedOrder, setSelectedOrder] = useState<any>(null);
  const [isInvoiceOpen, setIsInvoiceOpen] = useState(false);
  // Cached store ID — many orders have store_id = null (created before the
  // store_id column was added to the checkout flow). We resolve it once from
  // the stores table and reuse it for all Message button clicks.
  const [vendorStoreId, setVendorStoreId] = useState<string | null>(null);
  const { showToast } = useToast();
  const { user, openChat } = useAppContext();

  // Detail panel
  const [detailOrder, setDetailOrder]   = useState<any>(null);

  // Track previous order count to detect new orders via Realtime
  const prevOrderCountRef = useRef<number | null>(null);

  // Manual courier assignment modal
  const [assignModal, setAssignModal] = useState<{ orderId: string } | null>(null);
  const [couriersList, setCouriersList] = useState<any[]>([]);
  const [courierTab, setCourierTab] = useState<'all' | 'online'>('all');
  const [courierSearch, setCourierSearch] = useState('');
  const [loadingCouriers, setLoadingCouriers] = useState(false);
  const [assigningId, setAssigningId] = useState<string | null>(null);
  // Per-order loading state — prevents double-tap on action buttons
  const [updatingOrderId, setUpdatingOrderId] = useState<string | null>(null);

  // Self-Delivery dispatch modal
  interface SelfDeliveryData {
    name: string;
    phone: string;
    plate: string;
  }
  const [selfDeliveryModal, setSelfDeliveryModal] = useState<{
    isOpen: boolean;
    orderId: string;
    prefill: SelfDeliveryData;
    resolve: (data: SelfDeliveryData | null) => void;
  } | null>(null);
  const [sdForm, setSdForm] = useState<SelfDeliveryData>({ name: '', phone: '', plate: '' });

  // Fulfillment type choice modal (Fatibara vs Self-Delivery)
  const [fulfillmentModal, setFulfillmentModal] = useState<{
    isOpen: boolean;
    orderId: string;
    resolve: (choice: 'fatibara_courier' | 'vendor_self_delivery' | null) => void;
  } | null>(null);

  /** Asks the vendor how they want to fulfill the delivery. Returns 'fatibara_courier' | 'vendor_self_delivery' | null */
  const askFulfillmentType = (orderId: string): Promise<'fatibara_courier' | 'vendor_self_delivery' | null> =>
    new Promise((resolve) => {
      setFulfillmentModal({ isOpen: true, orderId, resolve });
    });

  /** Opens the self-delivery form modal pre-filled with store defaults. */
  const askSelfDeliveryDetails = async (orderId: string): Promise<SelfDeliveryData | null> => {
    // Pre-fill from store settings
    let prefill: SelfDeliveryData = { name: '', phone: '', plate: '' };
    if (user?.id) {
      const { data: store } = await supabase
        .from('stores')
        .select('internal_driver_name, internal_driver_phone, internal_driver_plate')
        .eq('owner_id', user.id)
        .maybeSingle();
      if (store) {
        prefill = {
          name: store.internal_driver_name || '',
          phone: store.internal_driver_phone || '',
          plate: store.internal_driver_plate || '',
        };
      }
    }
    setSdForm(prefill);
    return new Promise((resolve) => {
      setSelfDeliveryModal({ isOpen: true, orderId, prefill, resolve });
    });
  };

  const openAssignModal = async (orderId: string) => {
    setAssignModal({ orderId });
    setCourierSearch('');
    setCourierTab('all');
    setLoadingCouriers(true);
    try {
      // Query profiles table for all courier accounts
      const { data, error } = await supabase
        .from('profiles')
        .select('id, full_name, phone_number, courier_zone, avatar_url, is_courier_online, courier_status, profile_type, allowed_roles');

      if (!error && data) {
        // Filter profiles that are couriers
        const list = data.filter((p: any) => 
          p.profile_type === 'courier' || 
          (Array.isArray(p.allowed_roles) && p.allowed_roles.includes('courier')) ||
          p.courier_status != null ||
          p.is_courier_online === true
        );
        // Sort online couriers first
        list.sort((a: any, b: any) => (b.is_courier_online ? 1 : 0) - (a.is_courier_online ? 1 : 0));
        setCouriersList(list);
      } else {
        // Fallback directly to profile_type = 'courier'
        const { data: fallbackData } = await supabase
          .from('profiles')
          .select('id, full_name, phone_number, courier_zone, avatar_url, is_courier_online, courier_status, profile_type')
          .eq('profile_type', 'courier');
        setCouriersList(fallbackData || []);
      }
    } catch {
      setCouriersList([]);
    } finally {
      setLoadingCouriers(false);
    }
  };

  const assignCourier = async (courierId: string) => {
    if (!assignModal) return;
    setAssigningId(courierId);
    const { error } = await supabase
      .from('orders')
      .update({ courier_id: courierId })
      .eq('id', assignModal.orderId);
    if (error) {
      showToast(`Erreur d'assignation: ${error.message}`, 'error');
    } else {
      // Also update/upsert in deliveries table so courier app picks up assignment
      try {
        const { error: delErr } = await supabase
          .from('deliveries')
          .update({ courier_id: courierId })
          .eq('order_id', assignModal.orderId);
        
        if (delErr) {
          await supabase
            .from('deliveries')
            .upsert(
              { order_id: assignModal.orderId, courier_id: courierId },
              { onConflict: 'order_id' }
            );
        }
      } catch {
        // Suppress RLS permission differences if deliveries table has strict role policies
      }
      showToast('Livreur assigné avec succès ✓', 'success');
      hapticFeedback('success');
      setOrders(prev => prev.map(o => o.id === assignModal.orderId ? { ...o, courier_id: courierId } : o));
      setAssignModal(null);
    }
    setAssigningId(null);
  };

  /** Resolves the vendor's store ID from order data or the stores table. */
  const resolveStoreId = async (order: any): Promise<string | null> => {
    // Fast path: order already has store_id
    if (order.store_id) return order.store_id;
    // Cached from a previous lookup
    if (vendorStoreId) return vendorStoreId;
    // Query the stores table
    if (!user?.id) return null;
    const { data } = await supabase
      .from('stores')
      .select('id')
      .eq('owner_id', user.id)
      .maybeSingle();
    if (data?.id) {
      setVendorStoreId(data.id);
      return data.id;
    }
    return null;
  };

  const fetchOrders = useCallback(async (retryCount = 0) => {
    if (!user) return;
    try {
      // ── Strategy 1: orders where vendor_id = user.id (standard flow) ──
      const { data: byVendorId, error: e1 } = await supabase
        .from('orders')
        .select('*, order_items(*, product:products(title, image_urls))')
        .eq('vendor_id', user.id)
        .order('created_at', { ascending: false });

      if (e1) throw e1;

      // ── Strategy 2: orders via store ownership (vendor_id = NULL legacy) ──
      // First resolve this vendor's store_id (cached after first call).
      let storeId = vendorStoreId;
      if (!storeId) {
        const { data: storeRow } = await supabase
          .from('stores')
          .select('id')
          .eq('owner_id', user.id)
          .maybeSingle();
        storeId = storeRow?.id ?? null;
        if (storeId) setVendorStoreId(storeId);
      }

      let byStoreId: any[] = [];
      if (storeId) {
        const { data: storeOrders } = await supabase
          .from('orders')
          .select('*, order_items(*, product:products(title, image_urls))')
          .eq('store_id', storeId)
          .order('created_at', { ascending: false });
        byStoreId = storeOrders ?? [];
      }

      // ── Merge + deduplicate by order id ──────────────────────────────
      const seen = new Set<string>();
      const merged: any[] = [];
      for (const o of [...(byVendorId ?? []), ...byStoreId]) {
        if (!seen.has(o.id)) {
          seen.add(o.id);
          merged.push(o);
        }
      }
      // Re-sort after merge
      merged.sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());

      // Detect newly arrived order — only after the first successful load
      if (prevOrderCountRef.current !== null && merged.length > prevOrderCountRef.current) {
        const newest = merged[0];
        const buyerName = newest?.customer_name || newest?.profiles?.full_name || 'Un client';
        showToast(`🛍️ Nouvelle commande de ${buyerName} — ${formatGNF(newest?.total_amount ?? 0)}`, 'success');
        // Subtle audio ping via Web Audio API (no external asset needed)
        try {
          const ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
          const osc = ctx.createOscillator();
          const gain = ctx.createGain();
          osc.connect(gain);
          gain.connect(ctx.destination);
          osc.frequency.value = 880;
          gain.gain.setValueAtTime(0.3, ctx.currentTime);
          gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.4);
          osc.start(ctx.currentTime);
          osc.stop(ctx.currentTime + 0.4);
        } catch { /* AudioContext blocked — silent fallback */ }
      }
      prevOrderCountRef.current = merged.length;

      setOrders(merged);
    } catch (err) {
      console.error('Error fetching orders:', err);
      if (retryCount < 3) {
        const delay = Math.pow(2, retryCount) * 1000;
        setTimeout(() => fetchOrders(retryCount + 1), delay);
      } else {
        showToast('Erreur lors du chargement des commandes', 'error');
      }
    } finally {
      setLoading(false);
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user, vendorStoreId]);

  // Primary effect: initial fetch + Channel A realtime subscription
  useEffect(() => {
    fetchOrders();

    if (!user?.id) return;
    // Channel A — standard orders (vendor_id = user.id)
    const channelA = supabase
      .channel(realtimeKey.vendorOrders(user.id))
      .on('postgres_changes', {
        event: '*',
        schema: 'public',
        table: 'orders',
        filter: `vendor_id=eq.${user.id}`
      }, () => { fetchOrders(); })
      .subscribe((status, err) => {
        if (status === 'CHANNEL_ERROR' || status === 'TIMED_OUT') {
          const errMsg = err?.message || String(err || '');
          if (errMsg.toLowerCase().includes('heartbeat') || errMsg.toLowerCase().includes('timeout')) {
            console.debug('[VendorOrders] Realtime channel A transient heartbeat timeout — auto-reconnecting');
          } else {
            console.warn('[VendorOrders] Realtime channel A notice:', status, err);
          }
        }
      });

    return () => {
      supabase.removeChannel(channelA);
    };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user?.id]);

  // Channel B — legacy store_id-based orders (vendor_id may be null).
  // Placed in a separate useEffect so it subscribes as soon as vendorStoreId
  // is resolved by fetchOrders (which runs async). If it were in the primary
  // effect it would read null on first mount and never subscribe.
  useEffect(() => {
    if (!vendorStoreId) return;
    // fetchOrders is stable within this effect closure — safe to call inline
    const channelB = supabase
      .channel(`vendor-orders-store-${vendorStoreId}`)
      .on('postgres_changes', {
        event: '*',
        schema: 'public',
        table: 'orders',
        filter: `store_id=eq.${vendorStoreId}`
      }, () => { fetchOrders(); })
      .subscribe((status, err) => {
        if (status === 'CHANNEL_ERROR' || status === 'TIMED_OUT') {
          const errMsg = err?.message || String(err || '');
          if (errMsg.toLowerCase().includes('heartbeat') || errMsg.toLowerCase().includes('timeout')) {
            console.debug('[VendorOrders] Realtime channel B transient heartbeat timeout — auto-reconnecting');
          } else {
            console.warn('[VendorOrders] Realtime channel B notice:', status, err);
          }
        }
      });
    return () => { supabase.removeChannel(channelB); };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [vendorStoreId]);

// Use state to manage the custom prompt
  const [promptConfig, setPromptConfig] = useState<{
    isOpen: boolean;
    title: string;
    description?: string;
    resolve: (value: string | null) => void;
  } | null>(null);

  const askPrompt = (title: string, description?: string): Promise<string | null> => {
    return new Promise((resolve) => {
      setPromptConfig({ isOpen: true, title, description, resolve });
    });
  };

  // Cancel reason modal state
  const [cancelReasonModal, setCancelReasonModal] = useState<{
    isOpen: boolean;
    orderId: string;
    resolve: (reason: string | null) => void;
  } | null>(null);

  const CANCEL_REASONS = [
    'Rupture de stock',
    'Boutique fermée',
    'Prix incorrect',
    'Commande dupliquée',
    'Client a demandé l’annulation',
    'Article indisponible',
    'Autre raison',
  ];

  const [selectedCancelReason, setSelectedCancelReason] = useState(CANCEL_REASONS[0]);

  const askCancelReason = (orderId: string): Promise<string | null> =>
    new Promise((resolve) => {
      setSelectedCancelReason(CANCEL_REASONS[0]);
      setCancelReasonModal({ isOpen: true, orderId, resolve });
    });

  // Bulk selection state
  const [selectedOrderIds, setSelectedOrderIds] = useState<Set<string>>(new Set());
  const [bulkProcessing, setBulkProcessing] = useState(false);

  const toggleSelect = (id: string) => {
    setSelectedOrderIds(prev => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id); else next.add(id);
      return next;
    });
  };

  const toggleSelectAll = (filtered: any[]) => {
    if (selectedOrderIds.size === filtered.length) {
      setSelectedOrderIds(new Set());
    } else {
      setSelectedOrderIds(new Set(filtered.map((o: any) => o.id)));
    }
  };

  const bulkUpdateStatus = async (newStatus: string) => {
    if (selectedOrderIds.size === 0) return;
    // V12: Terminal statuses (delivered/cancelled) require individual OTP/reason
    // prompts — they cannot be bulk-applied safely. Guard them here.
    if (['delivered', 'cancelled'].includes(newStatus)) {
      showToast("Les statuts « Livré » et « Annulé » doivent être appliqués commande par commande.", 'warning');
      return;
    }
    setBulkProcessing(true);
    let successCount = 0;
    for (const id of selectedOrderIds) {
      try {
        await updateOrderStatus(id, newStatus);
        successCount++;
      } catch { /* individual error already toasted */ }
    }
    showToast(`${successCount} commande(s) mises à jour ✓`, 'success');
    setSelectedOrderIds(new Set());
    setBulkProcessing(false);
  };

  // SLA: orders waiting >30min at ready_for_pickup without a courier are flagged
  const getSlaWarning = (order: any): string | null => {
    if (order.status !== 'ready_for_pickup' || order.courier_id) return null;
    const age = (Date.now() - new Date(order.updated_at || order.created_at).getTime()) / 60000;
    if (age >= 30) return `${Math.floor(age)} min sans livreur`;
    return null;
  };

  const ALLOWED_TRANSITIONS: Record<string, string[]> = {
    // 'paid' is the immediate next legal state after 'pending' (payment gateway webhook).
    // This must mirror the DB state machine exactly — never skip a gate.
    pending:          ['paid', 'accepted', 'cancelled'],
    paid:             ['accepted', 'preparing', 'cancelled'],
    // COD orders arrive as 'confirmed'
    confirmed:        ['accepted', 'preparing', 'cancelled'],
    accepted:         ['preparing', 'processing', 'ready_for_pickup', 'in_transit', 'cancelled'],
    preparing:        ['processing', 'ready_for_pickup', 'in_transit', 'cancelled'],
    // 'processing' is DB-canonical for orders being packed (same as 'preparing')
    processing:       ['ready_for_pickup', 'in_transit', 'cancelled'],
    ready_for_pickup: ['in_transit', 'cancelled'],
    in_transit:       ['out_for_delivery', 'delivered', 'cancelled'],
    // 'out_for_delivery' is set by courier app — vendor can still confirm delivery
    out_for_delivery: ['delivered', 'cancelled'],
  };

  const updateOrderStatus = async (orderId: string, newStatus: string) => {
    // Guard: prevent concurrent updates on the same order
    if (updatingOrderId === orderId) return;
    setUpdatingOrderId(orderId);
    const previousStatus = orders.find(o => o.id === orderId)?.status;
    try {
      const order = orders.find(o => o.id === orderId);
      if (!order) return;

      // HARDENING: Transition Logic Check
      // The pending → paid path is always authorized (payment gateway webhook simulation).
      // We skip the guard for this specific transition to avoid false toast blocks.
      const isWebhookSimulation = order.status === 'pending' && newStatus === 'paid';
      if (!isWebhookSimulation) {
        const allowed = ALLOWED_TRANSITIONS[order.status] || [];
        if (!allowed.includes(newStatus) && !['delivered', 'cancelled'].includes(order.status)) {
          showToast(`Transition impossible de ${order.status} vers ${newStatus}`, "warning");
          return;
        }
      }

      // HARDENING: Terminal State Lock
      // If order is already delivered or cancelled, it cannot be changed via UI
      if (['delivered', 'cancelled'].includes(order.status)) {
        showToast("Cette commande est déjà dans un état terminal.", "warning");
        return;
      }

      let updateData: any = { status: newStatus };

      // ── In-transit dispatch: choose Fatibara Courier vs Self-Delivery ─────
      if (newStatus === 'in_transit') {
        const fulfillmentChoice = await askFulfillmentType(orderId);
        if (fulfillmentChoice === null) return; // user dismissed

        const tracking = `${fulfillmentChoice === 'vendor_self_delivery' ? 'SD' : 'LP'}-${Math.random().toString(36).substring(2, 9).toUpperCase()}`;

        if (fulfillmentChoice === 'vendor_self_delivery') {
          // Collect internal rider details
          const driverDetails = await askSelfDeliveryDetails(orderId);
          if (driverDetails === null) return; // user cancelled

          // Validate plate (required for safety)
          if (!driverDetails.plate || driverDetails.plate.trim().length < 2) {
            showToast("La plaque d'immatriculation est obligatoire pour la sécurité du client.", 'error');
            return;
          }

          updateData = {
            ...updateData,
            tracking_number: tracking,
            fulfillment_type: 'vendor_self_delivery',
            self_delivery_driver_name: driverDetails.name.trim() || null,
            self_delivery_driver_phone: driverDetails.phone.trim() || null,
            self_delivery_driver_plate: driverDetails.plate.trim().toUpperCase(),
            delivery_notes: `Livraison assurée par le marchand — Livreur: ${driverDetails.name || 'Interne'}`,
          };
        } else {
          // Fatibara Courier: standard flow
          updateData = {
            ...updateData,
            tracking_number: tracking,
            fulfillment_type: 'fatibara_courier',
            delivery_notes: 'Expédié via Fatibara Courier',
          };
        }
      }

      // SECURITY GUARD: Delegate terminal states to secure backend API / PostgreSQL RPC
      if (newStatus === 'delivered') {
        let inputOtp: string | null = null;
        if (order.delivery_otp) {
          inputOtp = await askPrompt(
            "CODE DE CONFIRMATION CLIENT (4 CHIFFRES)",
            `Demandez au client son code de livraison et saisissez-le ici.\nCode attendu côté client : ${order.delivery_otp}`
          );
          if (!inputOtp) return; // User cancelled
          inputOtp = inputOtp.trim();
          if (!/^\d{4}$/.test(inputOtp)) {
            showToast("Le code doit être composé de 4 chiffres.", "error");
            return;
          }
        }
        
        let completed = false;

        // 1. Try secure backend endpoint first
        try {
          const { data: sessionData } = await supabase.auth.getSession();
          const token = sessionData.session?.access_token;
          if (token) {
            const resp = await fetch('/api/vendor/complete-order', {
              method: 'POST',
              headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`,
              },
              body: JSON.stringify({ orderId, otp: inputOtp }),
            });
            const json = await resp.json();
            if (resp.ok && json.success) {
              completed = true;
            } else if (json.error) {
              if (json.error.includes('OTP')) {
                hapticFeedback('warning');
                showToast(json.error, 'error');
                return;
              }
              console.warn('[VendorOrders] API complete-order returned error, falling back to RPC:', json.error);
            }
          }
        } catch (apiErr: any) {
          console.warn('[VendorOrders] API complete-order call failed, falling back to RPC:', apiErr.message);
        }

        // 2. Fallback to PostgreSQL complete_vendor_order RPC if API didn't handle it
        if (!completed) {
          let { error: rpcError } = await supabase.rpc('complete_vendor_order', {
             target_order_id: orderId,
             status_text: inputOtp
          });

          // Fallback if older parameter name exists in schema cache
          if (rpcError && (rpcError.code === 'PGRST202' || rpcError.message.includes('function') || rpcError.message.includes('not found') || rpcError.message.includes('schema cache'))) {
            const retry1 = await supabase.rpc('complete_vendor_order', {
               target_order_id: orderId,
               provided_otp: inputOtp
            });
            if (!retry1.error) {
              rpcError = null;
            } else {
              const retry2 = await supabase.rpc('complete_vendor_order', {
                 p_order_id: orderId,
                 p_otp: inputOtp
              });
              if (!retry2.error) {
                rpcError = null;
              }
            }
          }

          if (rpcError) {
             // If already processed/delivered, treat as success idempotently
             if (rpcError.message.includes('already processed') || rpcError.message.includes('déjà livrée')) {
               completed = true;
             } else {
               hapticFeedback('error');
               const userMsg = rpcError.message.includes('OTP')
                 ? 'Code OTP incorrect. Veuillez vérifier avec le client et réessayer.'
                 : `Erreur Livraison: ${rpcError.message}`;
               showToast(userMsg, "error");
               return;
             }
          } else {
            completed = true;
          }
        }

        showToast("Livraison confirmée et portefeuille crédité !", 'success');
        hapticFeedback('success');
        setOrders(orders.map(o => o.id === orderId ? { ...o, status: newStatus } : o));
        if (order.user_id) {
          await safeNotify({
            user_id: order.user_id,
            type: 'order',
            title: 'Commande livrée',
            message: `Votre commande #${orderId.slice(0, 8)} a été livrée avec succès.`,
          });
        }
        return;
      } 
      else if (newStatus === 'cancelled') {
        // Collect cancel reason before calling the RPC
        const reason = await askCancelReason(orderId);
        if (reason === null) return; // user dismissed the modal

        const { error: rpcError } = await supabase.rpc('cancel_vendor_order', {
           target_order_id: orderId,
           cancel_reason: reason
        });

        if (rpcError) {
           showToast(`Erreur Annulation: ${rpcError.message}`, "error");
           return;
        }
        // V1: return early — the generic toast below must NOT fire for terminal states
        showToast("Commande annulée et remboursée si applicable.", 'success');
        hapticFeedback('success');
        setOrders(orders.map(o => o.id === orderId ? { ...o, status: newStatus } : o));
        if (order.user_id) {
          await safeNotify({
            user_id: order.user_id,
            type: 'order',
            title: 'Commande annulée',
            message: `Votre commande #${orderId.slice(0, 8)} a été annulée.`,
          });
        }
        return;
      } 
      else {
        // Standard non-financial status updates
        const { error } = await supabase
          .from('orders')
          .update(updateData)
          .eq('id', orderId);
          
        if (error) throw error;
      }

      // Notify the customer about the status change
      if (order.user_id) {
          const statusLabels: Record<string, string> = {
            accepted: 'confirmée',
            preparing: 'en cours de préparation',
            in_transit: 'en route',
            delivered: 'livrée',
            cancelled: 'annulée'
          };

          await safeNotify({
              user_id: order.user_id,
              type: 'order',
              title: `Commande ${statusLabels[newStatus] || newStatus}`,
              message: `Votre commande #${orderId.slice(0, 8)} est maintenant ${statusLabels[newStatus] || newStatus}.`
          });
      }

      // Optimistic update
      setOrders(orders.map(o => o.id === orderId ? { ...o, status: newStatus } : o));
      showToast("Statut de la commande mis à jour", 'success');
      hapticFeedback('success');
    } catch (err: unknown) {
      // Rollback optimistic update to previous status on error
      if (previousStatus) {
        setOrders(prev => prev.map(o => o.id === orderId ? { ...o, status: previousStatus } : o));
      }
      const errObj = err && typeof err === 'object' ? err as Record<string, unknown> : {};
      const message = typeof errObj['message'] === 'string' ? errObj['message'] : 'Erreur lors de la mise à jour';
      showToast(message, 'error');
      throw err;
    } finally {
      setUpdatingOrderId(null);
    }
  };

  const handleCopyOrderId = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    const shortId = id.slice(0, 8).toUpperCase();
    navigator.clipboard.writeText(shortId).then(() => {
      setCopiedOrderId(id);
      showToast(`N° #${shortId} copié !`, 'success');
      setTimeout(() => setCopiedOrderId(null), 2000);
    }).catch(() => {});
  };

  const handleRefresh = async () => {
    setIsRefreshing(true);
    await fetchOrders();
    showToast('Commandes synchronisées', 'info');
    setTimeout(() => setIsRefreshing(false), 500);
  };

  if (loading) return (
    <div className="space-y-6">
      <Skeleton className="h-20 w-full rounded-2xl" />
      {[1, 2, 3].map(i => (
        <Skeleton key={i} className="h-44 w-full rounded-2xl" />
      ))}
    </div>
  );

  const filteredOrders = orders.filter(o => {
    if (activeStatuses.length > 0 && !activeStatuses.includes(o.status)) return false;
    if (filter !== 'all' && o.status !== filter) return false;
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase().trim();
      const idMatch = o.id?.toLowerCase().includes(q);
      const nameMatch = (o.customer_name || o.profiles?.full_name || '').toLowerCase().includes(q);
      const phoneMatch = (o.customer_phone || o.profiles?.phone_number || '').includes(q);
      const trackingMatch = (o.tracking_number || '').toLowerCase().includes(q);
      const otpMatch = (o.delivery_otp || '').includes(q);
      const itemMatch = o.order_items?.some((i: any) => i.product?.title?.toLowerCase().includes(q));
      const communeMatch = (o.shipping_address?.commune || '').toLowerCase().includes(q);
      if (!idMatch && !nameMatch && !phoneMatch && !trackingMatch && !otpMatch && !itemMatch && !communeMatch) {
        return false;
      }
    }
    return true;
  });

  return (
    <div className="space-y-5">
      {/* ── Consolidated Toolbar: Search, View Mode, CSV & Refresh ── */}
      <div className="flex flex-col sm:flex-row justify-between items-stretch sm:items-center gap-3 bg-white dark:bg-slate-900/70 p-3 sm:p-4 rounded-2xl border border-gray-200/80 dark:border-white/10 shadow-sm">
        {/* Search input */}
        <div className="relative flex-1 min-w-[220px]">
          <Search className="w-4 h-4 text-gray-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Rechercher par n° de commande, client, téléphone, article..."
            className="w-full pl-10 pr-9 py-2 bg-gray-50 dark:bg-white/5 border border-gray-200 dark:border-white/10 rounded-xl text-xs sm:text-sm font-medium text-gray-900 dark:text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-[#ff6600]/30 focus:border-[#ff6600] transition-all"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600 dark:hover:text-white p-0.5"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          )}
        </div>

        {/* View mode toggle + CSV + Refresh */}
        <div className="flex items-center gap-2 shrink-0 flex-wrap justify-end">
          <div className="flex items-center p-1 bg-gray-100 dark:bg-white/5 rounded-xl border border-gray-200/60 dark:border-white/10">
            <button
              onClick={() => setViewMode('list')}
              className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold rounded-lg transition-all ${
                viewMode === 'list'
                  ? 'bg-white dark:bg-slate-800 text-gray-900 dark:text-white shadow-sm'
                  : 'text-gray-500 hover:text-gray-900 dark:hover:text-white'
              }`}
            >
              <List className="w-3.5 h-3.5" />
              <span>Liste</span>
            </button>
            <button
              onClick={() => setViewMode('kanban')}
              className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold rounded-lg transition-all ${
                viewMode === 'kanban'
                  ? 'bg-white dark:bg-slate-800 text-gray-900 dark:text-white shadow-sm'
                  : 'text-gray-500 hover:text-gray-900 dark:hover:text-white'
              }`}
            >
              <LayoutGrid className="w-3.5 h-3.5" />
              <span>Kanban</span>
            </button>
          </div>

          <button
            onClick={() => {
              const headers = ['ID', 'Date', 'Client', 'Articles', 'Total', 'Statut'];
              const rows = filteredOrders.map(o => [
                o.id.slice(0, 8),
                new Date(o.created_at).toLocaleDateString(),
                o.customer_name || o.profiles?.full_name || 'Inconnu',
                o.order_items?.length ?? 0,
                o.total_amount,
                o.status
              ]);
              const csvContent = 'data:text/csv;charset=utf-8,' + encodeURIComponent(
                [headers.join(','), ...rows.map(r => r.join(','))].join('\n')
              );
              const link = document.createElement('a');
              link.setAttribute('href', csvContent);
              link.setAttribute('download', `COMMANDES_${new Date().toISOString().split('T')[0]}.csv`);
              document.body.appendChild(link);
              link.click();
              link.remove();
              showToast('Fichier CSV téléchargé !', 'success');
            }}
            className="flex items-center gap-1.5 px-3 py-2 text-xs font-bold rounded-xl bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 hover:bg-emerald-500/20 border border-emerald-500/20 transition-all active:scale-[0.98]"
            title="Télécharger l'export CSV"
          >
            <Download className="w-3.5 h-3.5" />
            <span>CSV</span>
          </button>

          <button
            onClick={handleRefresh}
            disabled={isRefreshing}
            className="p-2 rounded-xl text-gray-500 hover:text-gray-900 dark:hover:text-white hover:bg-gray-100 dark:hover:bg-white/5 border border-gray-200/60 dark:border-white/10 transition-all active:scale-[0.95]"
            title="Actualiser les commandes"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isRefreshing ? 'animate-spin text-[#ff6600]' : ''}`} />
          </button>
        </div>
      </div>

      {viewMode === 'kanban' ? (
        <OrderKanban
          // Pass real DB statuses directly — no proxy mapping.
          // Orders with statuses outside the KanbanOrderStatus union (e.g. 'cancelled')
          // are intentionally excluded from the Kanban view.
          orders={orders
            .filter((o): o is typeof o & { status: KanbanOrderStatus } =>
              ['pending', 'paid', 'confirmed', 'accepted', 'preparing', 'ready_for_pickup', 'in_transit', 'delivered'].includes(o.status)
            )
            .map((o): KanbanOrder => ({
              id: o.id,
              status: o.status as KanbanOrderStatus,
              total_amount: o.total_amount,
              customer_name: o.customer_name || o.profiles?.full_name || 'Client Inconnu',
              created_at: o.created_at,
              // Map order_items → compact checklist entries for the card UI
              items: (o.order_items ?? []).map((item: any): KanbanOrderItem => ({
                title:    item.product?.title ?? 'Article',
                quantity: typeof item.quantity === 'number' ? item.quantity : 1,
              })),
            }))}
          // onStatusChange receives the real DB target status — delegate directly
          // to updateOrderStatus which has the ALLOWED_TRANSITIONS guard.
          onStatusChange={async (id: string, newStatus: KanbanOrderStatus) => {
            await updateOrderStatus(id, newStatus);
          }}
          // onRejectOrder: calls the secure cancel_vendor_order RPC (handles refunds)
          onRejectOrder={async (orderId: string) => {
            const reason = await askCancelReason(orderId);
            if (reason === null) return; // user dismissed
            const { error: rpcError } = await supabase.rpc('cancel_vendor_order', {
              target_order_id: orderId,
              cancel_reason: reason,
            });
            if (rpcError) {
              hapticFeedback('error');
              showToast(`Erreur: ${rpcError.message}`, 'error');
              throw rpcError;
            }
            showToast('Commande refusée et remboursée si applicable.', 'success');
            hapticFeedback('success');
            setOrders((prev) => prev.filter((o) => o.id !== orderId));
          }}
        />
      ) : (
        <div className="space-y-4">
          {/* Bulk action toolbar */}
          <div className="flex items-center justify-between">
            <label className="flex items-center gap-2 cursor-pointer">
              <input type="checkbox" className="w-4 h-4 rounded accent-[#ff6600]"
                checked={selectedOrderIds.size > 0 && selectedOrderIds.size === orders.filter(o => filter === 'all' || o.status === filter).length}
                onChange={() => toggleSelectAll(orders.filter(o => filter === 'all' || o.status === filter))}
              />
              <span className="text-[11px] font-bold text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                {selectedOrderIds.size > 0 ? `${selectedOrderIds.size} sélectionné(s)` : 'Tout sélectionner'}
              </span>
            </label>
            <AnimatePresence>
              {selectedOrderIds.size > 0 && (
                <motion.div initial={{ opacity: 0, y: -6 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -6 }}
                  className="flex items-center gap-2">
                  <span className="text-[10px] font-bold text-gray-400 dark:text-gray-500 uppercase tracking-wider">Action groupée :</span>
                  {['accepted', 'preparing', 'ready_for_pickup'].map(s => (
                    <button key={s} onClick={() => bulkUpdateStatus(s)} disabled={bulkProcessing}
                      className="px-3 py-2 text-[10px] font-black tracking-wider rounded-xl transition-all disabled:opacity-50 bg-[#ff6600]/10 text-[#ff6600] border border-[#ff6600]/20 hover:bg-[#ff6600] hover:text-white">
                      {s === 'accepted' ? 'Confirmer' : s === 'preparing' ? 'Préparer' : 'Prêt'}
                    </button>
                  ))}
                  <button onClick={() => setSelectedOrderIds(new Set())}
                    className="px-3 py-2 text-[10px] font-black tracking-wider rounded-xl bg-gray-100 dark:bg-white/5 text-gray-500 dark:text-gray-400 hover:bg-gray-200 dark:hover:bg-white/10 transition-all">
                    Annuler
                  </button>
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          <div className="grid grid-cols-1 gap-4">
            {filteredOrders.length === 0 ? (
              <div className="flex flex-col items-center justify-center p-12 bg-white dark:bg-slate-900/60 rounded-2xl border border-gray-200/80 dark:border-white/10 text-center">
                <div className="w-14 h-14 rounded-2xl bg-orange-50 dark:bg-[#ff6600]/10 border border-orange-200 dark:border-[#ff6600]/20 flex items-center justify-center text-[#ff6600] mb-3">
                  <Package className="w-7 h-7" />
                </div>
                <h3 className="text-base font-bold text-gray-900 dark:text-white">
                  Aucune commande trouvée
                </h3>
                <p className="text-xs text-gray-500 dark:text-gray-400 max-w-sm mt-1">
                  {searchQuery
                    ? `Aucun résultat pour la recherche "${searchQuery}". Essayez avec un autre terme ou réinitialisez.`
                    : 'Aucune commande ne correspond à ce filtre pour le moment.'}
                </p>
                {searchQuery && (
                  <button
                    onClick={() => setSearchQuery('')}
                    className="mt-4 px-4 py-2 bg-gray-100 dark:bg-white/10 hover:bg-gray-200 dark:hover:bg-white/20 text-gray-700 dark:text-gray-200 text-xs font-bold rounded-xl transition-all"
                  >
                    Effacer la recherche
                  </button>
                )}
              </div>
            ) : (
              filteredOrders.map((order, idx) => {
                const status = STATUS_CONFIG[order.status as keyof typeof STATUS_CONFIG] || STATUS_CONFIG.pending;
                const StatusIcon = status.icon || Package;
                const slaWarning = getSlaWarning(order);
                const isSelected = selectedOrderIds.has(order.id);
                const isCopied = copiedOrderId === order.id;
                const buyerPhone: string | null =
                  order.customer_phone ||
                  order.profiles?.phone_number ||
                  null;

                // Primary CTA: the single most-relevant next action for this order
                const getPrimaryAction = (): { label: string; handler: () => void; color: string } | null => {
                  if (['pending', 'confirmed'].includes(order.status))
                    return { label: 'Accepter la commande', handler: () => updateOrderStatus(order.id, order.status === 'confirmed' ? 'accepted' : 'paid'), color: 'bg-[#ff6600] hover:bg-[#e65c00]' };
                  if (order.status === 'paid')
                    return { label: 'Accepter la commande', handler: () => updateOrderStatus(order.id, 'accepted'), color: 'bg-[#ff6600] hover:bg-[#e65c00]' };
                  if (order.status === 'accepted')
                    return { label: 'Commencer la préparation', handler: () => updateOrderStatus(order.id, 'preparing'), color: 'bg-purple-600 hover:bg-purple-700' };
                  if (order.status === 'preparing')
                    return { label: 'Marquer Prêt pour Livraison', handler: () => updateOrderStatus(order.id, 'ready_for_pickup'), color: 'bg-[#ff6600] hover:bg-[#e65c00]' };
                  if (order.status === 'ready_for_pickup')
                    return { label: 'Expédier la commande', handler: () => updateOrderStatus(order.id, 'in_transit'), color: 'bg-blue-600 hover:bg-blue-700' };
                  if (order.status === 'in_transit')
                    return { label: 'Confirmer la livraison', handler: () => updateOrderStatus(order.id, 'delivered'), color: 'bg-emerald-600 hover:bg-emerald-700' };
                  return null;
                };
                const primaryAction = getPrimaryAction();

                // Build buyer initials avatar
                const buyerName: string = order.customer_name || order.profiles?.full_name || 'Client Inconnu';
                const buyerInitials = buyerName
                  .split(' ')
                  .filter(Boolean)
                  .slice(0, 2)
                  .map((w: string) => w[0]?.toUpperCase() ?? '')
                  .join('');

                const shortId = order.id?.split('-')[0].toUpperCase();

                return (
                  <motion.div
                    layout
                    initial={{ opacity: 0, y: 8 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: idx * 0.02 }}
                    key={order.id}
                    onClick={() => setDetailOrder(order)}
                    className={`group relative bg-white dark:bg-[#12151c] rounded-2xl border transition-all duration-200 cursor-pointer overflow-hidden p-5 sm:p-6 flex flex-col gap-4 ${
                      isSelected
                        ? 'border-[#ff6600] ring-2 ring-[#ff6600]/20 shadow-md shadow-[#ff6600]/5'
                        : slaWarning
                        ? 'border-amber-400 dark:border-amber-500/40 shadow-sm'
                        : 'border-gray-200/80 dark:border-white/10 hover:border-gray-300 dark:hover:border-white/20 hover:shadow-md'
                    }`}
                  >
                    {/* ── Top Header Row: Reference, Date, Status, Total ── */}
                    <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 pb-3 border-b border-gray-100 dark:border-white/5">
                      <div className="flex items-center gap-3 flex-wrap">
                        {/* Checkbox */}
                        <input
                          type="checkbox"
                          checked={isSelected}
                          onChange={(e) => { e.stopPropagation(); toggleSelect(order.id); }}
                          className="w-4 h-4 rounded accent-[#ff6600] shrink-0 cursor-pointer"
                        />

                        {/* Order identifier with 1-click copy */}
                        <button
                          type="button"
                          onClick={(e) => handleCopyOrderId(order.id, e)}
                          className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-gray-100 dark:bg-white/5 hover:bg-gray-200 dark:hover:bg-white/10 text-gray-800 dark:text-gray-200 text-xs font-black tracking-wider transition-colors"
                          title="Cliquer pour copier l'identifiant"
                        >
                          <span>#{shortId}</span>
                          {isCopied ? (
                            <Check className="w-3 h-3 text-emerald-500" />
                          ) : (
                            <Copy className="w-3 h-3 text-gray-400 group-hover:text-gray-600" />
                          )}
                        </button>

                        {/* Relative time */}
                        <div className="flex items-center gap-1 text-[11px] font-medium text-gray-400 dark:text-gray-500">
                          <Clock className="w-3 h-3" />
                          <span>{timeAgo(order.created_at)}</span>
                        </div>

                        {/* Status badge */}
                        <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 text-[11px] font-bold rounded-full ${status.bg} ${status.color} border border-current/15`}>
                          <StatusIcon className="w-3 h-3" />
                          {status.label}
                        </span>

                        {/* SLA warning badge */}
                        {slaWarning && (
                          <span className="flex items-center gap-1 px-2.5 py-1 text-[10px] font-bold rounded-full bg-amber-500/10 text-amber-600 dark:text-amber-400 border border-amber-300 dark:border-amber-500/30 animate-pulse">
                            <Timer className="w-3 h-3" /> {slaWarning}
                          </span>
                        )}
                      </div>

                      {/* Total Amount & Payment Mode */}
                      <div className="flex items-baseline sm:flex-col sm:items-end gap-2 sm:gap-0.5 ml-auto sm:ml-0">
                        <span className="text-lg sm:text-xl font-black text-gray-900 dark:text-white tracking-tight tabular-nums">
                          {formatGNF(order.total_amount)}
                        </span>
                        <span className="text-[11px] font-semibold text-gray-400 dark:text-gray-500 flex items-center gap-1">
                          {order.payment_method === 'wallet' || order.status === 'paid' ? (
                            <>
                              <ShieldCheck className="w-3 h-3 text-emerald-500" /> Payé en ligne
                            </>
                          ) : (
                            <>
                              <CheckCircle className="w-3 h-3 text-blue-500" /> Paiement à la livraison
                            </>
                          )}
                        </span>
                      </div>
                    </div>

                    {/* ── Middle Row: Customer Info & Logistics ── */}
                    <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-3">
                      {/* Customer info */}
                      <div className="flex items-center gap-3 min-w-0">
                        <div className="w-10 h-10 rounded-full bg-gradient-to-br from-[#ff6600]/20 to-amber-500/20 border border-[#ff6600]/20 flex items-center justify-center shrink-0 text-xs font-black text-[#ff6600] uppercase tracking-tight select-none">
                          {buyerInitials || '?'}
                        </div>
                        <div className="min-w-0">
                          <p className="text-sm font-bold text-gray-900 dark:text-white truncate">
                            {buyerName}
                          </p>
                          {order.shipping_address && (
                            <p className="text-[11px] font-medium text-gray-500 dark:text-gray-400 flex items-center gap-1 truncate">
                              <MapPin className="w-3 h-3 text-gray-400 shrink-0" />
                              <span>{order.shipping_address?.commune}, {order.shipping_address?.region}</span>
                            </p>
                          )}
                        </div>
                      </div>

                      {/* Quick Communication Actions */}
                      <div className="flex items-center gap-2 w-full md:w-auto justify-end">
                        {buyerPhone && (
                          <a
                            href={`tel:${buyerPhone}`}
                            onClick={(e) => e.stopPropagation()}
                            className="flex items-center gap-1 px-3 py-1.5 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-400 hover:bg-emerald-100 dark:hover:bg-emerald-900/60 border border-emerald-200 dark:border-emerald-500/20 text-xs font-semibold transition-all"
                            title={`Appeler le client (${buyerPhone})`}
                          >
                            <Phone className="w-3.5 h-3.5" />
                            <span>Appeler</span>
                          </a>
                        )}
                        <button
                          type="button"
                          onClick={async (e) => {
                            e.stopPropagation();
                            if (!order.user_id) {
                              showToast("Impossible d'ouvrir le chat : client introuvable.", 'error');
                              return;
                            }
                            const storeId = await resolveStoreId(order);
                            if (!storeId) {
                              showToast("Impossible d'ouvrir le chat : boutique introuvable.", 'error');
                              return;
                            }
                            openChat(storeId, `Commande #${shortId}`, order.user_id);
                          }}
                          className="flex items-center gap-1 px-3 py-1.5 rounded-xl bg-orange-50 dark:bg-[#ff6600]/10 text-[#ff6600] hover:bg-orange-100 dark:hover:bg-[#ff6600]/20 border border-orange-200 dark:border-[#ff6600]/20 text-xs font-semibold transition-all"
                          title="Discuter avec le client"
                        >
                          <MessageCircle className="w-3.5 h-3.5" />
                          <span>Message</span>
                        </button>
                      </div>
                    </div>

                    {/* ── Products Preview Gallery ── */}
                    <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none -mx-1 px-1">
                      {order.order_items?.map((item: any, i: number) => (
                        <div
                          key={i}
                          className="flex-shrink-0 flex items-center gap-2.5 bg-gray-50 dark:bg-white/[0.03] p-2 rounded-xl border border-gray-100 dark:border-white/5 max-w-[220px]"
                        >
                          <img
                            src={item.product?.image_urls?.[0] || 'https://images.unsplash.com/photo-1560393464-5c69a73c5770?q=80&w=100'}
                            className="w-10 h-10 rounded-lg object-cover bg-gray-100 dark:bg-gray-800 shrink-0"
                            alt=""
                          />
                          <div className="min-w-0 pr-1">
                            <p className="text-xs font-bold text-gray-800 dark:text-gray-200 truncate">
                              {item.product?.title || 'Article'}
                            </p>
                            <div className="flex items-center gap-1.5 mt-0.5 text-[10px] font-medium text-gray-500 dark:text-gray-400">
                              <span className="font-bold text-[#ff6600]">x{item.quantity || 1}</span>
                              {item.selected_variations && Object.keys(item.selected_variations).length > 0 && (
                                <span className="truncate">
                                  · {Object.values(item.selected_variations).join(', ')}
                                </span>
                              )}
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>

                    {/* ── Single Delivery OTP & Tracking Bar (Clean & De-duplicated) ── */}
                    {(order.delivery_otp || order.tracking_number) && order.status !== 'delivered' && (
                      <div className="flex items-center gap-2.5 flex-wrap pt-1">
                        {order.delivery_otp && (
                          <div className="flex items-center gap-2 px-3 py-1.5 bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200/80 dark:border-emerald-500/20 rounded-xl text-emerald-700 dark:text-emerald-300 text-xs font-bold">
                            <ShieldCheck className="w-4 h-4 text-emerald-600 dark:text-emerald-400 shrink-0" />
                            <span>Code OTP Client :</span>
                            <span className="font-mono text-sm tracking-widest bg-emerald-100 dark:bg-emerald-900/60 px-1.5 py-0.5 rounded text-emerald-800 dark:text-emerald-200">
                              {order.delivery_otp}
                            </span>
                            <span className="hidden sm:inline text-[10px] font-normal text-emerald-600/80 dark:text-emerald-400/80">
                              (à valider à la livraison)
                            </span>
                          </div>
                        )}
                        {order.tracking_number && (
                          <div className="flex items-center gap-1.5 px-3 py-1.5 bg-blue-50 dark:bg-blue-950/40 border border-blue-200/80 dark:border-blue-500/20 rounded-xl text-blue-700 dark:text-blue-300 text-xs font-bold">
                            <Truck className="w-3.5 h-3.5 text-blue-500" />
                            <span>Suivi : <strong className="font-mono">{order.tracking_number}</strong></span>
                          </div>
                        )}
                      </div>
                    )}

                    {/* ── Footer Actions Row: Reçu, Détails, Annuler, Primary CTA ── */}
                    <div className="flex flex-col sm:flex-row justify-between items-stretch sm:items-center gap-3 pt-3 border-t border-gray-100 dark:border-white/5">
                      {/* Secondary utility actions */}
                      <div className="flex items-center gap-2">
                        <button
                          type="button"
                          onClick={(e) => { e.stopPropagation(); setSelectedOrder(order); setIsInvoiceOpen(true); }}
                          className="flex-1 sm:flex-none flex items-center justify-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold text-gray-700 dark:text-gray-300 bg-gray-50 dark:bg-white/5 hover:bg-gray-100 dark:hover:bg-white/10 border border-gray-200 dark:border-white/10 transition-all active:scale-[0.98]"
                        >
                          <FileText className="w-3.5 h-3.5" />
                          <span>Reçu</span>
                        </button>
                        <button
                          type="button"
                          onClick={(e) => { e.stopPropagation(); setDetailOrder(order); }}
                          className="flex-1 sm:flex-none flex items-center justify-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold text-[#ff6600] bg-[#ff6600]/10 hover:bg-[#ff6600]/20 border border-[#ff6600]/20 transition-all active:scale-[0.98]"
                        >
                          <Eye className="w-3.5 h-3.5" />
                          <span>Détails</span>
                        </button>
                      </div>

                      {/* Main operation buttons */}
                      <div className="flex items-center gap-2 justify-end">
                        {/* Cancel button for early-stage orders */}
                        {['pending', 'confirmed', 'paid', 'accepted'].includes(order.status) && (
                          <button
                            type="button"
                            onClick={(e) => { e.stopPropagation(); updateOrderStatus(order.id, 'cancelled'); }}
                            disabled={updatingOrderId === order.id}
                            className="px-3 py-2 rounded-xl text-xs font-bold text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/40 border border-rose-200 dark:border-rose-500/20 transition-all active:scale-[0.98] disabled:opacity-40"
                          >
                            Annuler
                          </button>
                        )}

                        {/* Manual courier assignment button */}
                        {order.status === 'ready_for_pickup' && !order.courier_id && (
                          <button
                            type="button"
                            onClick={(e) => { e.stopPropagation(); openAssignModal(order.id); }}
                            className="flex items-center gap-1.5 px-4 py-2.5 rounded-xl text-xs font-bold bg-blue-500/10 text-blue-600 dark:text-blue-400 hover:bg-blue-500 hover:text-white border border-blue-500/20 transition-all active:scale-[0.98]"
                          >
                            <UserCheck className="w-3.5 h-3.5" />
                            <span>Assigner Livreur</span>
                          </button>
                        )}

                        {/* Primary single CTA */}
                        {primaryAction && (
                          <motion.button
                            whileTap={{ scale: 0.98 }}
                            type="button"
                            onClick={(e) => { e.stopPropagation(); primaryAction.handler(); }}
                            disabled={updatingOrderId === order.id}
                            className={`flex items-center justify-center gap-2 px-5 py-2.5 rounded-xl text-xs font-black text-white ${primaryAction.color} shadow-sm shadow-black/10 transition-all disabled:opacity-50 min-h-[38px]`}
                          >
                            {updatingOrderId === order.id ? (
                              <span className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                            ) : (
                              <CheckCircle className="w-3.5 h-3.5" />
                            )}
                            <span>{updatingOrderId === order.id ? 'Traitement...' : primaryAction.label}</span>
                          </motion.button>
                        )}

                        {/* Terminal status badge */}
                        {['delivered', 'cancelled'].includes(order.status) && (
                          <span
                            className={`px-3 py-1.5 rounded-xl text-xs font-bold ${
                              order.status === 'delivered'
                                ? 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/20'
                                : 'bg-rose-500/10 text-rose-600 dark:text-rose-400 border border-rose-500/20'
                            }`}
                          >
                            {order.status === 'delivered' ? '✓ Livré' : '✗ Annulé'}
                          </span>
                        )}
                      </div>
                    </div>
                  </motion.div>
                );
              })
            )}
          </div>
        </div>
      )}
      <OrderInvoiceModal 
        isOpen={isInvoiceOpen}
        onClose={() => setIsInvoiceOpen(false)}
        order={selectedOrder}
      />

      {/* ── Order Detail Panel ── */}
      <AnimatePresence>
        {detailOrder && (
          <OrderDetailPanel
            order={detailOrder}
            onClose={() => setDetailOrder(null)}
            onStatusUpdate={updateOrderStatus}
            onOpenChat={async (order) => {
              if (!order.user_id) { showToast("Client introuvable.", 'error'); return; }
              const sid = await resolveStoreId(order);
              if (!sid) { showToast("Boutique introuvable.", 'error'); return; }
              openChat(sid, `Commande #${order.id.slice(0,8)}`, order.user_id);
            }}
            updatingOrderId={updatingOrderId}
          />
        )}
      </AnimatePresence>

      {/* ── Assign Courier Modal ── */}
      <AnimatePresence>
        {assignModal && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/70 backdrop-blur-md"
            onClick={() => setAssignModal(null)}>
            <motion.div initial={{ scale: 0.9, opacity: 0, y: 20 }} animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.9, opacity: 0, y: 20 }} onClick={e => e.stopPropagation()}
              className="bg-white dark:bg-[#111] border border-gray-100 dark:border-white/10 p-8 rounded-[2rem] w-full max-w-lg flex flex-col gap-5 shadow-2xl">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-blue-500/10 rounded-xl flex items-center justify-center shrink-0">
                  <UserCheck className="w-5 h-5 text-blue-500" />
                </div>
                <div>
                  <h3 className="text-lg font-black text-gray-900 dark:text-white tracking-tight uppercase">Assigner un Livreur</h3>
                  <p className="text-[11px] text-gray-400 dark:text-white/30 font-bold tracking-wider flex items-center gap-1.5">
                    <Radio className="w-3 h-3 text-emerald-500" />
                    {loadingCouriers ? 'Recherche...' : `${couriersList.length} livreur(s) disponible(s)`}
                  </p>
                </div>
              </div>

              {/* Tabs & Search */}
              <div className="flex flex-col gap-2.5">
                <div className="flex gap-1.5 p-1 bg-gray-100 dark:bg-white/5 rounded-xl">
                  <button
                    type="button"
                    onClick={() => setCourierTab('all')}
                    className={`flex-1 py-1.5 px-3 rounded-lg text-xs font-bold transition-all ${
                      courierTab === 'all'
                        ? 'bg-white dark:bg-gray-800 text-gray-900 dark:text-white shadow-sm'
                        : 'text-gray-500 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white'
                    }`}
                  >
                    Tous les livreurs ({couriersList.length})
                  </button>
                  <button
                    type="button"
                    onClick={() => setCourierTab('online')}
                    className={`flex-1 py-1.5 px-3 rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-1.5 ${
                      courierTab === 'online'
                        ? 'bg-white dark:bg-gray-800 text-gray-900 dark:text-white shadow-sm'
                        : 'text-gray-500 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white'
                    }`}
                  >
                    <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                    En ligne ({couriersList.filter(c => c.is_courier_online || ['disponible', 'active', 'en_course', 'on_delivery'].includes(c.courier_status)).length})
                  </button>
                </div>

                <div className="relative">
                  <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
                  <input
                    type="text"
                    value={courierSearch}
                    onChange={e => setCourierSearch(e.target.value)}
                    placeholder="Rechercher par nom, zone ou téléphone..."
                    className="w-full pl-9 pr-8 py-2 bg-gray-50 dark:bg-white/[0.03] border border-gray-200 dark:border-white/10 rounded-xl text-xs outline-none focus:border-blue-500 text-gray-900 dark:text-white placeholder:text-gray-400"
                  />
                  {courierSearch && (
                    <button
                      type="button"
                      onClick={() => setCourierSearch('')}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600 dark:hover:text-white"
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
              </div>

              <div className="space-y-2 max-h-80 overflow-y-auto pr-1">
                {loadingCouriers ? (
                  <div className="flex items-center justify-center py-10">
                    <div className="w-6 h-6 border-2 border-[#ff6600] border-t-transparent rounded-full animate-spin" />
                  </div>
                ) : (() => {
                  const filtered = couriersList.filter(c => {
                    const isOnline = c.is_courier_online || ['disponible', 'active', 'en_course', 'on_delivery'].includes(c.courier_status);
                    if (courierTab === 'online' && !isOnline) return false;
                    if (!courierSearch.trim()) return true;
                    const q = courierSearch.toLowerCase();
                    return (
                      (c.full_name && c.full_name.toLowerCase().includes(q)) ||
                      (c.courier_zone && c.courier_zone.toLowerCase().includes(q)) ||
                      (c.operating_zone && c.operating_zone.toLowerCase().includes(q)) ||
                      (c.phone_number && c.phone_number.includes(q)) ||
                      (c.phone && c.phone.includes(q))
                    );
                  });

                  if (filtered.length === 0) {
                    return (
                      <div className="text-center py-10">
                        <Users className="w-8 h-8 text-gray-200 dark:text-white/10 mx-auto mb-3" />
                        <p className="text-[12px] font-bold text-gray-400 dark:text-white/30">
                          {courierTab === 'online' ? 'Aucun livreur en ligne actuellement' : 'Aucun livreur trouvé'}
                        </p>
                      </div>
                    );
                  }

                  return filtered.map(courier => {
                    const isOnline = courier.is_courier_online || ['disponible', 'active', 'en_course', 'on_delivery'].includes(courier.courier_status);
                    const isEnCourse = ['en_course', 'on_delivery'].includes(courier.courier_status);
                    const phone = courier.phone_number || courier.phone;
                    const zone = courier.courier_zone || courier.operating_zone;

                    return (
                      <div key={courier.id} className="flex items-center justify-between gap-4 p-3.5 bg-gray-50 dark:bg-white/[0.03] border border-gray-100 dark:border-white/10 rounded-xl hover:border-blue-200 dark:hover:border-blue-500/20 transition-all">
                        <div className="flex items-center gap-3 min-w-0">
                          {courier.avatar_url ? (
                            <img src={courier.avatar_url} alt="" className="w-9 h-9 rounded-full object-cover shrink-0" />
                          ) : (
                            <div className="w-9 h-9 rounded-full bg-blue-500/10 flex items-center justify-center shrink-0">
                              <UserCheck className="w-4 h-4 text-blue-500" />
                            </div>
                          )}
                          <div className="min-w-0">
                            <div className="flex items-center gap-2">
                              <p className="text-[12px] font-bold text-gray-900 dark:text-white truncate">{courier.full_name || 'Livreur'}</p>
                              <span className={`inline-flex items-center gap-1 text-[9px] font-bold px-1.5 py-0.5 rounded-full ${
                                isEnCourse
                                  ? 'bg-blue-500/10 text-blue-600 dark:text-blue-400'
                                  : isOnline
                                  ? 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400'
                                  : 'bg-gray-200 dark:bg-white/10 text-gray-500 dark:text-gray-400'
                              }`}>
                                <span className={`w-1.5 h-1.5 rounded-full ${
                                  isEnCourse ? 'bg-blue-500' : isOnline ? 'bg-emerald-500 animate-pulse' : 'bg-gray-400'
                                }`} />
                                {isEnCourse ? 'En course' : isOnline ? 'En ligne' : 'Hors ligne'}
                              </span>
                            </div>
                            <div className="flex items-center gap-2 text-[10px] font-medium text-gray-400 dark:text-white/40 mt-0.5">
                              <span>{zone ? `Zone: ${zone}` : 'Toutes zones'}</span>
                              {phone && (
                                <>
                                  <span>·</span>
                                  <a href={`tel:${phone}`} className="hover:underline flex items-center gap-0.5 text-blue-500 font-semibold">
                                    <Phone className="w-2.5 h-2.5" />
                                    {phone}
                                  </a>
                                </>
                              )}
                            </div>
                          </div>
                        </div>
                        <button
                          type="button"
                          onClick={() => assignCourier(courier.id)}
                          disabled={assigningId === courier.id}
                          className="shrink-0 flex items-center gap-1.5 px-3.5 py-2 bg-blue-500 hover:bg-blue-400 text-white rounded-xl text-[10px] font-black tracking-wider transition-all disabled:opacity-50"
                        >
                          {assigningId === courier.id
                            ? <div className="w-3 h-3 border border-white border-t-transparent rounded-full animate-spin" />
                            : <UserCheck className="w-3 h-3" />}
                          Assigner
                        </button>
                      </div>
                    );
                  });
                })()}
              </div>

              <button onClick={() => setAssignModal(null)}
                className="w-full py-3 rounded-xl text-[10px] font-black tracking-wider text-gray-400 hover:text-gray-600 dark:hover:text-white hover:bg-gray-50 dark:hover:bg-white/5 transition-all">
                ANNULER
              </button>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Custom Prompt Modal */}
      <AnimatePresence>
        {promptConfig?.isOpen && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm"
            onClick={() => {
              promptConfig.resolve(null);
              setPromptConfig(null);
            }}
          >
            <motion.div 
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              onClick={(e) => e.stopPropagation()}
              className="bg-white dark:bg-gray-900 dark:bg-gray-800 p-6 rounded-2xl w-full max-w-sm flex flex-col gap-4 shadow-xl"
            >
              <div>
                <h3 className="text-lg font-bold text-gray-900 text-gray-900 dark:text-white">{promptConfig.title}</h3>
                {promptConfig.description && (
                  <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">{promptConfig.description}</p>
                )}
              </div>
              
              <input
                id="promptInput"
                type="text"
                autoFocus
                className="w-full p-3 rounded-xl border border-gray-200 border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-800 dark:bg-gray-900 focus:outline-none focus:ring-2 focus:ring-[#ff6600]"
                placeholder="Tapez ici..."
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    promptConfig.resolve((e.target as HTMLInputElement).value);
                    setPromptConfig(null);
                  }
                }}
              />
              
              <div className="flex gap-3 mt-2">
                <button
                  onClick={() => {
                    promptConfig.resolve(null);
                    setPromptConfig(null);
                  }}
                  className="flex-1 py-3 px-4 rounded-xl font-medium text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 transition"
                >
                  Annuler
                </button>
                <button
                  onClick={() => {
                    const input = document.getElementById('promptInput') as HTMLInputElement;
                    promptConfig.resolve(input.value);
                    setPromptConfig(null);
                  }}
                  className="flex-1 py-3 px-4 rounded-xl font-medium text-white bg-[#ff6600] hover:bg-[#e62e00] transition shadow-sm"
                >
                  Confirmer
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ── Cancel Reason Modal ── */}
      <AnimatePresence>
        {cancelReasonModal?.isOpen && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/70 backdrop-blur-md"
            onClick={() => { cancelReasonModal.resolve(null); setCancelReasonModal(null); }}>
            <motion.div initial={{ scale: 0.9, opacity: 0, y: 20 }} animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.9, opacity: 0, y: 20 }} onClick={e => e.stopPropagation()}
              className="bg-white dark:bg-[#111] border border-gray-100 dark:border-white/10 p-8 rounded-[2rem] w-full max-w-md flex flex-col gap-5 shadow-2xl">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-rose-500/10 rounded-xl flex items-center justify-center shrink-0">
                  <XCircle className="w-5 h-5 text-rose-500" />
                </div>
                <div>
                  <h3 className="text-lg font-black text-gray-900 dark:text-white tracking-tight uppercase">Annuler la commande</h3>
                  <p className="text-[11px] text-gray-500 dark:text-white/40 font-bold tracking-wider">Sélectionnez une raison</p>
                </div>
              </div>
              <div className="space-y-2">
                {CANCEL_REASONS.map(reason => (
                  <button key={reason} onClick={() => setSelectedCancelReason(reason)}
                    className={`w-full text-left px-4 py-3 rounded-xl text-[12px] font-bold tracking-wide transition-all border ${
                      selectedCancelReason === reason
                        ? 'bg-rose-500/10 border-rose-500/40 text-rose-600 dark:text-rose-400'
                        : 'bg-gray-50 dark:bg-white/[0.03] border-gray-100 dark:border-white/10 text-gray-600 dark:text-white/50 hover:border-gray-200 dark:hover:border-white/20'
                    }`}>
                    {reason}
                  </button>
                ))}
              </div>
              <div className="flex gap-3 pt-2 border-t border-gray-100 dark:border-white/5">
                <button onClick={() => { cancelReasonModal.resolve(null); setCancelReasonModal(null); }}
                  className="flex-1 py-4 rounded-xl font-black text-[10px] tracking-wider text-gray-400 hover:text-gray-700 hover:bg-gray-50 dark:hover:bg-white/5 transition-all">
                  GARDER
                </button>
                <button onClick={() => { cancelReasonModal.resolve(selectedCancelReason); setCancelReasonModal(null); }}
                  className="flex-1 py-4 rounded-xl font-black text-[10px] tracking-wider text-white bg-rose-500 hover:bg-rose-400 transition-all shadow-lg">
                  CONFIRMER L'ANNULATION
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ── Fulfillment Choice Modal ── */}
      <AnimatePresence>
        {fulfillmentModal?.isOpen && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="fixed inset-0 z-[110] flex items-center justify-center p-4 bg-black/70 backdrop-blur-md"
            onClick={() => { fulfillmentModal.resolve(null); setFulfillmentModal(null); }}>
            <motion.div initial={{ scale: 0.9, opacity: 0, y: 20 }} animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.9, opacity: 0, y: 20 }} onClick={e => e.stopPropagation()}
              className="bg-white dark:bg-[#111] border border-gray-100 dark:border-white/10 p-8 rounded-[2rem] w-full max-w-md flex flex-col gap-5 shadow-2xl">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-[#ff6600]/10 rounded-xl flex items-center justify-center shrink-0">
                  <Truck className="w-5 h-5 text-[#ff6600]" />
                </div>
                <div>
                  <h3 className="text-lg font-black text-gray-900 dark:text-white tracking-tight uppercase">Mode d'Expédition</h3>
                  <p className="text-[11px] text-gray-400 dark:text-white/30 font-bold tracking-wider">Choisissez comment livrer cette commande</p>
                </div>
              </div>

              <div className="space-y-3">
                {/* Option A — Fatibara Courier */}
                <button
                  id="dispatch-fatibara-courier"
                  onClick={() => { fulfillmentModal.resolve('fatibara_courier'); setFulfillmentModal(null); }}
                  className="w-full flex items-center gap-4 p-5 bg-gray-50 dark:bg-white/[0.03] border-2 border-gray-200 dark:border-white/10 hover:border-[#ff6600] hover:bg-[#ff6600]/5 rounded-2xl text-left transition-all group"
                >
                  <div className="w-11 h-11 bg-[#ff6600]/10 rounded-xl flex items-center justify-center shrink-0 group-hover:bg-[#ff6600]/20 transition-colors">
                    <Navigation className="w-5 h-5 text-[#ff6600]" />
                  </div>
                  <div>
                    <p className="text-[13px] font-black text-gray-900 dark:text-white tracking-tight">Livreur Fatibara</p>
                    <p className="text-[11px] text-gray-400 font-bold tracking-wide mt-0.5">Assignation d'un coursier de la plateforme</p>
                  </div>
                </button>

                {/* Option B — Vendor Self-Delivery */}
                <button
                  id="dispatch-self-delivery"
                  onClick={() => { fulfillmentModal.resolve('vendor_self_delivery'); setFulfillmentModal(null); }}
                  className="w-full flex items-center gap-4 p-5 bg-gray-50 dark:bg-white/[0.03] border-2 border-gray-200 dark:border-white/10 hover:border-emerald-500 hover:bg-emerald-500/5 rounded-2xl text-left transition-all group"
                >
                  <div className="w-11 h-11 bg-emerald-500/10 rounded-xl flex items-center justify-center shrink-0 group-hover:bg-emerald-500/20 transition-colors">
                    <Store className="w-5 h-5 text-emerald-500" />
                  </div>
                  <div>
                    <p className="text-[13px] font-black text-gray-900 dark:text-white tracking-tight">Ma Propre Livraison <span className="ml-1 text-[9px] bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 px-1.5 py-0.5 rounded-full font-black uppercase tracking-widest">Marchand-Livreur</span></p>
                    <p className="text-[11px] text-gray-400 font-bold tracking-wide mt-0.5">Je livre avec mon propre coursier interne</p>
                  </div>
                </button>
              </div>

              <button onClick={() => { fulfillmentModal.resolve(null); setFulfillmentModal(null); }}
                className="w-full py-3 rounded-xl text-[10px] font-black tracking-wider text-gray-400 hover:text-gray-600 dark:hover:text-white hover:bg-gray-50 dark:hover:bg-white/5 transition-all">
                ANNULER
              </button>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ── Self-Delivery Driver Details Modal ── */}
      <AnimatePresence>
        {selfDeliveryModal?.isOpen && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="fixed inset-0 z-[120] flex items-center justify-center p-4 bg-black/70 backdrop-blur-md"
            onClick={() => { selfDeliveryModal.resolve(null); setSelfDeliveryModal(null); }}>
            <motion.div initial={{ scale: 0.9, opacity: 0, y: 20 }} animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.9, opacity: 0, y: 20 }} onClick={e => e.stopPropagation()}
              className="bg-white dark:bg-[#111] border border-gray-100 dark:border-white/10 p-8 rounded-[2rem] w-full max-w-lg flex flex-col gap-6 shadow-2xl">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-emerald-500/10 rounded-xl flex items-center justify-center shrink-0">
                  <ShieldCheck className="w-5 h-5 text-emerald-500" />
                </div>
                <div>
                  <h3 className="text-lg font-black text-gray-900 dark:text-white tracking-tight uppercase">Détails du Livreur Interne</h3>
                  <p className="text-[11px] text-gray-400 dark:text-white/30 font-bold tracking-wider">Ces infos seront visibles par l'acheteur pour sa sécurité</p>
                </div>
              </div>

              <div className="space-y-4">
                <div className="space-y-2">
                  <label className="text-[10px] font-black tracking-widest text-gray-400 uppercase">Nom Complet du Livreur</label>
                  <input
                    id="sd-driver-name"
                    type="text"
                    value={sdForm.name}
                    onChange={e => setSdForm(f => ({ ...f, name: e.target.value }))}
                    placeholder="Ex: Mamadou Diallo"
                    className="w-full bg-gray-50 dark:bg-white/5 border border-gray-200 dark:border-white/10 rounded-xl p-4 text-[14px] font-bold text-gray-900 dark:text-white focus:border-emerald-500 outline-none transition-all"
                  />
                </div>

                <div className="space-y-2">
                  <label className="text-[10px] font-black tracking-widest text-gray-400 uppercase">Numéro de Téléphone</label>
                  <input
                    id="sd-driver-phone"
                    type="tel"
                    value={sdForm.phone}
                    onChange={e => setSdForm(f => ({ ...f, phone: e.target.value }))}
                    placeholder="Ex: 6xx xxx xxx"
                    className="w-full bg-gray-50 dark:bg-white/5 border border-gray-200 dark:border-white/10 rounded-xl p-4 text-[14px] font-bold text-gray-900 dark:text-white focus:border-emerald-500 outline-none transition-all"
                  />
                </div>

                <div className="space-y-2">
                  <label className="text-[10px] font-black tracking-widest text-gray-400 uppercase">
                    Plaque d'Immatriculation <span className="text-rose-500">*</span>
                  </label>
                  <input
                    id="sd-driver-plate"
                    type="text"
                    value={sdForm.plate}
                    onChange={e => setSdForm(f => ({ ...f, plate: e.target.value.toUpperCase() }))}
                    placeholder="Ex: AB-1234-CD"
                    className="w-full bg-gray-50 dark:bg-white/5 border border-gray-200 dark:border-white/10 rounded-xl p-4 text-[14px] font-black text-gray-900 dark:text-white focus:border-emerald-500 outline-none transition-all tracking-widest"
                  />
                  <p className="text-[10px] text-gray-400 font-medium">Obligatoire — visible par l'acheteur sur la page de suivi</p>
                </div>
              </div>

              <div className="flex gap-3 pt-2 border-t border-gray-100 dark:border-white/5">
                <button onClick={() => { selfDeliveryModal.resolve(null); setSelfDeliveryModal(null); }}
                  className="flex-1 py-4 rounded-xl font-black text-[10px] tracking-wider text-gray-400 hover:text-gray-700 hover:bg-gray-50 dark:hover:bg-white/5 transition-all">
                  ANNULER
                </button>
                <button
                  id="confirm-self-delivery"
                  onClick={() => {
                    selfDeliveryModal.resolve(sdForm);
                    setSelfDeliveryModal(null);
                  }}
                  className="flex-1 py-4 rounded-xl font-black text-[10px] tracking-wider text-white bg-emerald-500 hover:bg-emerald-400 transition-all shadow-lg flex items-center justify-center gap-2">
                  <Truck className="w-3.5 h-3.5" />
                  CONFIRMER L'EXPÉDITION
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

// ─── Order Detail Panel ────────────────────────────────────────────────────────
function OrderDetailPanel({
  order,
  onClose,
  onStatusUpdate,
  onOpenChat,
  updatingOrderId,
}: {
  order: any;
  onClose: () => void;
  onStatusUpdate: (id: string, status: string) => void;
  onOpenChat: (order: any) => void;
  updatingOrderId: string | null;
}) {
  const status = STATUS_CONFIG[order.status] || STATUS_CONFIG.pending;
  const buyerName = order.customer_name || order.profiles?.full_name || 'Client Inconnu';
  const buyerPhone = order.customer_phone || order.profiles?.phone_number || null;
  const addr = order.shipping_address;

  const ALLOWED: Record<string, string[]> = {
    pending:          ['paid', 'accepted', 'cancelled'],
    paid:             ['accepted', 'preparing', 'cancelled'],
    confirmed:        ['accepted', 'preparing', 'cancelled'],
    accepted:         ['preparing', 'processing', 'ready_for_pickup', 'in_transit', 'cancelled'],
    preparing:        ['processing', 'ready_for_pickup', 'in_transit', 'cancelled'],
    processing:       ['ready_for_pickup', 'in_transit', 'cancelled'],
    ready_for_pickup: ['in_transit', 'cancelled'],
    in_transit:       ['out_for_delivery', 'delivered', 'cancelled'],
    out_for_delivery: ['delivered', 'cancelled'],
  };

  const nextSteps = (ALLOWED[order.status] || []).filter((s: string) => s !== 'cancelled');
  const canCancel = !['delivered', 'cancelled'].includes(order.status);

  const ACTION_LABELS: Record<string, string> = {
    paid: 'Marquer Payée',
    accepted: 'Accepter la commande',
    preparing: 'Commencer la préparation',
    processing: 'En préparation',
    ready_for_pickup: 'Prêt pour expédition',
    in_transit: 'Expédier',
    out_for_delivery: 'En livraison',
    delivered: 'Confirmer la livraison',
  };

  return (
    <>
      {/* Backdrop */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        onClick={onClose}
        className="fixed inset-0 z-[150] bg-black/50 backdrop-blur-sm"
      />
      {/* Panel */}
      <motion.div
        initial={{ x: '100%' }}
        animate={{ x: 0 }}
        exit={{ x: '100%' }}
        transition={{ type: 'spring', damping: 28, stiffness: 300 }}
        className="fixed inset-y-0 right-0 z-[160] w-full max-w-[520px] bg-white dark:bg-[#111] flex flex-col shadow-2xl overflow-hidden"
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-5 border-b border-gray-100 dark:border-white/5 shrink-0">
          <div>
            <p className="text-[10px] font-black text-gray-400 dark:text-gray-500 uppercase tracking-widest mb-1">Commande</p>
            <h2 className="text-lg font-black text-gray-900 dark:text-white tracking-tight leading-none">
              #{order.id?.split('-')[0].toUpperCase()}
            </h2>
          </div>
          <div className="flex items-center gap-3">
            <span className={`px-3 py-1.5 text-[10px] font-black rounded-full ${status.bg} ${status.color} uppercase tracking-wider`}>
              {status.label}
            </span>
            <button onClick={onClose} className="w-9 h-9 rounded-xl bg-gray-100 dark:bg-white/5 flex items-center justify-center text-gray-500 dark:text-gray-400 hover:bg-gray-200 dark:hover:bg-white/10 transition-all">
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Scrollable body */}
        <div className="flex-1 overflow-y-auto px-6 py-5 space-y-6">

          {/* Customer block */}
          <div className="bg-gray-50 dark:bg-white/[0.03] border border-gray-100 dark:border-white/[0.08] rounded-2xl p-4 space-y-3">
            <p className="text-[10px] font-black text-gray-400 dark:text-gray-500 uppercase tracking-widest">Client</p>
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-gradient-to-br from-[#ff6600]/20 to-purple-500/20 flex items-center justify-center text-[13px] font-black text-[#ff6600] uppercase shrink-0">
                {buyerName.split(' ').slice(0,2).map((w: string) => w[0]).join('')}
              </div>
              <div>
                <p className="text-[15px] font-black text-gray-900 dark:text-white leading-none">{buyerName}</p>
                {buyerPhone && (
                  <a href={`tel:${buyerPhone}`} className="text-[11px] font-bold text-[#ff6600] flex items-center gap-1 mt-1">
                    <Phone className="w-3 h-3" />{buyerPhone}
                  </a>
                )}
              </div>
            </div>
          </div>

          {/* Delivery address */}
          {addr && (
            <div className="bg-gray-50 dark:bg-white/[0.03] border border-gray-100 dark:border-white/[0.08] rounded-2xl p-4 space-y-2">
              <p className="text-[10px] font-black text-gray-400 dark:text-gray-500 uppercase tracking-widest">Adresse de livraison</p>
              <div className="flex items-start gap-2">
                <MapPin className="w-4 h-4 text-[#ff6600] mt-0.5 shrink-0" />
                <div className="text-[13px] font-bold text-gray-800 dark:text-gray-200 leading-relaxed">
                  {[addr.commune, addr.region, addr.quartier, addr.details].filter(Boolean).join(', ')}
                </div>
              </div>
            </div>
          )}

          {/* OTP / Tracking */}
          {(order.delivery_otp || order.tracking_number) && order.status !== 'delivered' && (
            <div className="flex gap-3 flex-wrap">
              {order.tracking_number && (
                <div className="flex items-center gap-2 px-3 py-2 bg-orange-50 dark:bg-orange-950/40 border border-orange-200 dark:border-orange-500/20 rounded-xl">
                  <Truck className="w-3.5 h-3.5 text-[#ff6600]" />
                  <span className="text-[11px] font-black text-[#e62e00] dark:text-orange-400 tracking-wide uppercase">{order.tracking_number}</span>
                </div>
              )}
              {order.delivery_otp && (
                <div className="flex items-center gap-2 px-3 py-2 bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-500/20 rounded-xl">
                  <ShieldCheck className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
                  <span className="text-[11px] font-black text-emerald-700 dark:text-emerald-400 tracking-wide uppercase">Code client: {order.delivery_otp}</span>
                </div>
              )}
            </div>
          )}

          {/* Order items */}
          <div>
            <p className="text-[10px] font-black text-gray-400 dark:text-gray-500 uppercase tracking-widest mb-3">
              Articles commandés ({order.order_items?.length ?? 0})
            </p>
            <div className="space-y-3">
              {(order.order_items ?? []).map((item: any, i: number) => (
                <div key={i} className="flex items-center gap-3 bg-gray-50 dark:bg-white/[0.03] border border-gray-100 dark:border-white/[0.08] rounded-xl p-3">
                  <img
                    src={item.product?.image_urls?.[0] || 'https://images.unsplash.com/photo-1560393464-5c69a73c5770?q=80&w=100'}
                    className="w-14 h-14 rounded-lg object-cover shrink-0 border border-gray-200 dark:border-white/10"
                    alt=""
                  />
                  <div className="flex-1 min-w-0">
                    <p className="text-[13px] font-bold text-gray-900 dark:text-white truncate">{item.product?.title ?? 'Article'}</p>
                    {item.selected_variations && Object.keys(item.selected_variations).length > 0 && (
                      <p className="text-[10px] font-black text-gray-400 uppercase tracking-wider mt-0.5">
                        {Object.entries(item.selected_variations).map(([k, v]) => `${k}: ${v}`).join(' · ')}
                      </p>
                    )}
                    <p className="text-[11px] font-bold text-gray-500 dark:text-gray-400 mt-0.5">
                      Qté: {item.quantity ?? 1}
                    </p>
                  </div>
                  <p className="text-[13px] font-black text-[#ff6600] shrink-0 tabular-nums">
                    {formatGNF(Number(item.price_at_purchase ?? 0) * Number(item.quantity ?? 1))}
                  </p>
                </div>
              ))}
            </div>
          </div>

          {/* Order notes */}
          {order.notes && (
            <div className="bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-500/20 rounded-2xl p-4">
              <p className="text-[10px] font-black text-amber-600 dark:text-amber-400 uppercase tracking-widest mb-1">Note du client</p>
              <p className="text-[13px] font-medium text-amber-900 dark:text-amber-200 leading-relaxed">{order.notes}</p>
            </div>
          )}

          {/* Totals */}
          <div className="bg-gray-50 dark:bg-white/[0.03] border border-gray-100 dark:border-white/[0.08] rounded-2xl p-4 space-y-2">
            <div className="flex justify-between text-[12px] text-gray-500 dark:text-gray-400">
              <span>Sous-total</span>
              <span className="font-bold">{formatGNF(order.total_amount)}</span>
            </div>
            {order.vendor_delivery_fee > 0 && (
              <div className="flex justify-between text-[12px] text-rose-500">
                <span>Frais logistique</span>
                <span className="font-bold">-{formatGNF(order.vendor_delivery_fee)}</span>
              </div>
            )}
            <div className="flex justify-between text-[15px] font-black text-gray-900 dark:text-white border-t border-gray-200 dark:border-white/10 pt-2 mt-2">
              <span>Total</span>
              <span className="text-[#ff6600]">{formatGNF(order.total_amount)}</span>
            </div>
          </div>
        </div>

        {/* Sticky footer — action buttons */}
        <div className="shrink-0 px-6 py-4 border-t border-gray-100 dark:border-white/5 bg-white dark:bg-[#111] space-y-2">
          <div className="flex gap-2 flex-wrap">
            {nextSteps.slice(0, 1).map((s: string) => (
              <motion.button
                key={s}
                whileTap={{ scale: 0.97 }}
                disabled={updatingOrderId === order.id}
                onClick={() => onStatusUpdate(order.id, s)}
                className="flex-1 bg-[#ff6600] hover:bg-[#e65c00] text-white py-3.5 rounded-xl text-[13px] font-black tracking-wide flex items-center justify-center gap-2 transition-all disabled:opacity-50 shadow-lg shadow-[#ff6600]/20"
              >
                {updatingOrderId === order.id
                  ? <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  : <CheckCircle className="w-4 h-4" />}
                {ACTION_LABELS[s] ?? s}
              </motion.button>
            ))}
            <button
              onClick={() => onOpenChat(order)}
              className="px-4 py-3.5 bg-gray-100 dark:bg-white/5 text-gray-700 dark:text-gray-300 rounded-xl text-[12px] font-bold flex items-center gap-2 hover:bg-gray-200 dark:hover:bg-white/10 transition-all"
            >
              <MessageCircle className="w-4 h-4" /> Message
            </button>
          </div>
          {canCancel && (
            <button
              disabled={updatingOrderId === order.id}
              onClick={() => onStatusUpdate(order.id, 'cancelled')}
              className="w-full py-3 rounded-xl text-[11px] font-black tracking-wider text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-950/40 transition-all border border-transparent hover:border-rose-200 dark:hover:border-rose-500/20"
            >
              Annuler la commande
            </button>
          )}
        </div>
      </motion.div>
    </>
  );
}
