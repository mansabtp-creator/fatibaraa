import React, {
  useState,
  useEffect,
  useRef,
  useCallback,
} from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  AlertCircle,
  CheckCheck,
  ChefHat,
  Clock,
  Package,
  Truck,
  User,
  X,
  Zap,
  CheckCircle2,
  ShoppingBag,
  Volume2,
  VolumeX,
} from 'lucide-react';
import { startChime, stopChime } from '../utils/orderChime';

// ─────────────────────────────────────────────────────────────────────────────
// Types
// ─────────────────────────────────────────────────────────────────────────────

export type OrderStatus =
  | 'pending'
  | 'paid'
  | 'confirmed'
  | 'accepted'
  | 'preparing'
  | 'ready_for_pickup'
  | 'in_transit'
  | 'delivered';

export interface KanbanOrderItem {
  title: string;
  quantity: number;
}

export interface KanbanOrder {
  id: string;
  status: OrderStatus;
  total_amount: number;
  customer_name?: string;
  created_at: string;
  items?: KanbanOrderItem[];
}

export interface OrderKanbanProps {
  orders: KanbanOrder[];
  /** Called with the real DB status string. Must reject with a Supabase error shape on failure. */
  onStatusChange: (orderId: string, newStatus: OrderStatus) => Promise<void>;
  /** Called to cancel/reject an order via the secure RPC */
  onRejectOrder?: (orderId: string) => Promise<void>;
}

// ─────────────────────────────────────────────────────────────────────────────
// Status grouping — 3 semantic columns
// ─────────────────────────────────────────────────────────────────────────────

type ColumnKey = 'new' | 'kitchen' | 'done';

interface ColumnDef {
  key: ColumnKey;
  label: string;
  statuses: OrderStatus[];
  badgeClass: string;    // Tailwind classes for the count badge
  pulses: boolean;       // Whether the badge pulses (pending alert)
  icon: React.ElementType;
  accentColor: string;
  borderColor: string;
}

const COLUMNS: ColumnDef[] = [
  {
    key: 'new',
    label: 'Nouveaux',
    // 'confirmed' = COD order confirmed by buyer
    statuses: ['pending', 'paid', 'confirmed'],
    badgeClass: 'bg-orange-500/20 text-orange-400 border border-orange-500/30',
    pulses: true,
    icon: Zap,
    accentColor: 'text-orange-400',
    borderColor: 'border-orange-500/20',
  },
  {
    key: 'kitchen',
    label: 'En cuisine',
    statuses: ['accepted', 'preparing'],
    badgeClass: 'bg-blue-500/20 text-blue-400 border border-blue-500/30',
    pulses: false,
    icon: ChefHat,
    accentColor: 'text-blue-400',
    borderColor: 'border-blue-500/20',
  },
  {
    key: 'done',
    label: 'Prêt / Livré',
    statuses: ['ready_for_pickup', 'delivered'],
    badgeClass: 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30',
    pulses: false,
    icon: CheckCheck,
    accentColor: 'text-emerald-400',
    borderColor: 'border-emerald-500/20',
  },
];

// ─────────────────────────────────────────────────────────────────────────────
// Legal next-status state machine
// ─────────────────────────────────────────────────────────────────────────────

const PRIMARY_ACTION: Partial<Record<OrderStatus, { label: string; nextStatus: OrderStatus; style: 'orange' | 'blue' | 'green' }>> = {
  pending:          { label: 'Accepter',    nextStatus: 'paid',             style: 'orange' },
  paid:             { label: 'Confirmer →', nextStatus: 'accepted',         style: 'orange' },
  // COD orders land here — vendor accepts them directly
  confirmed:        { label: 'Traiter →',   nextStatus: 'accepted',         style: 'orange' },
  accepted:         { label: 'En cuisine',  nextStatus: 'preparing',        style: 'blue'   },
  preparing:        { label: 'Prêt !',      nextStatus: 'ready_for_pickup', style: 'blue'   },
  // NOTE: ready_for_pickup and in_transit are intentionally omitted.
  // Once a courier picks up the order, only the courier (via OTP-validated
  // complete_courier_delivery RPC) can advance to 'delivered'.
  // Allowing vendors to set 'in_transit' or 'delivered' directly would
  // bypass OTP validation and courier payout logic.
};

const CAN_REJECT: OrderStatus[] = ['pending', 'paid', 'confirmed', 'accepted'];

// ─────────────────────────────────────────────────────────────────────────────
// Helpers
// ─────────────────────────────────────────────────────────────────────────────

function formatElapsed(createdAt: string): string {
  const diffMs = Date.now() - new Date(createdAt).getTime();
  const mins = Math.floor(diffMs / 60_000);
  if (mins < 1)  return 'À l\'instant';
  if (mins < 60) return `il y a ${mins} min${mins > 1 ? 's' : ''}`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24)  return `il y a ${hrs} h`;
  return `il y a ${Math.floor(hrs / 24)} j`;
}

interface DbError {
  message: string;
  code?: string;
}

/** Maps raw Supabase / PostgreSQL errors to safe French user messages. */
function extractDbError(err: unknown): DbError {
  if (err && typeof err === 'object') {
    const e = err as Record<string, unknown>;
    const rawMsg  = typeof e['message'] === 'string' ? e['message'].toLowerCase() : '';
    const rawCode = typeof e['code']    === 'string' ? e['code'] : '';

    // Map known Supabase/PostgreSQL codes to safe French messages
    if (rawCode === '42501' || rawMsg.includes('permission denied') || rawMsg.includes('rls')) {
      return { message: 'Permission refusée. Contactez le support si cela persiste.' };
    }
    if (rawCode === '23503' || rawMsg.includes('foreign key')) {
      return { message: 'Opération impossible : une dépendance existe déjà.' };
    }
    if (rawCode === '23505' || rawMsg.includes('duplicate') || rawMsg.includes('unique')) {
      return { message: 'Cette opération a déjà été effectuée.' };
    }
    if (rawCode === 'PGRST116' || rawMsg.includes('jwt') || rawMsg.includes('token') || rawMsg.includes('expired')) {
      return { message: 'Session expirée. Veuillez vous reconnecter.' };
    }
    if (rawMsg.includes('network') || rawMsg.includes('fetch') || rawMsg.includes('timeout')) {
      return { message: 'Erreur réseau. Vérifiez votre connexion et réessayez.' };
    }
    if (rawMsg.includes('already') || rawMsg.includes('status') || rawMsg.includes('cannot')) {
      // Business logic rejections — safe to surface a truncated version
      return { message: 'Mise à jour impossible dans état actuel. Actualisez la page.' };
    }
    // Generic fallback — do NOT leak raw DB message
    return { message: 'Erreur lors de la mise à jour. Veuillez réessayer.' };
  }
  return { message: 'Erreur lors de la mise à jour. Veuillez réessayer.' };
}

// ─────────────────────────────────────────────────────────────────────────────
// StatusChip — small inline status badge for each card
// ─────────────────────────────────────────────────────────────────────────────

const STATUS_CHIP_CONFIG: Record<OrderStatus, { label: string; className: string; icon: React.ElementType }> = {
  pending:          { label: 'En attente',  className: 'bg-orange-500/15 text-orange-300 border-orange-500/25', icon: Clock        },
  paid:             { label: 'Payé',        className: 'bg-amber-500/15  text-amber-300  border-amber-500/25',  icon: CheckCircle2 },
  confirmed:        { label: 'Confirmée',   className: 'bg-blue-500/15   text-blue-300   border-blue-500/25',   icon: CheckCircle2 },
  accepted:         { label: 'Accepté',     className: 'bg-blue-500/15   text-blue-300   border-blue-500/25',   icon: CheckCircle2 },
  preparing:        { label: 'En cuisine',  className: 'bg-purple-500/15 text-purple-300 border-purple-500/25', icon: ChefHat      },
  ready_for_pickup: { label: 'Prêt',        className: 'bg-teal-500/15   text-teal-300   border-teal-500/25',   icon: Package      },
  in_transit:       { label: 'En transit',  className: 'bg-[#ff6600]/15  text-orange-400 border-[#ff6600]/25',  icon: Truck        },
  delivered:        { label: 'Livré',       className: 'bg-emerald-500/15 text-emerald-300 border-emerald-500/25', icon: CheckCheck },
};

// ─────────────────────────────────────────────────────────────────────────────
// OrderCard component
// ─────────────────────────────────────────────────────────────────────────────

interface OrderCardProps {
  order: KanbanOrder;
  isLoading: boolean;
  error: DbError | null;
  onAdvance: (order: KanbanOrder) => void;
  onReject:  (order: KanbanOrder) => void;
  onClearError: (orderId: string) => void;
}

const OrderCard: React.FC<OrderCardProps> = ({
  order,
  isLoading,
  error,
  onAdvance,
  onReject,
  onClearError,
}) => {
  const shortId = order.id.slice(0, 8).toUpperCase();
  const chip = STATUS_CHIP_CONFIG[order.status];
  const ChipIcon = chip.icon;
  const primaryAction = PRIMARY_ACTION[order.status];
  const canReject = CAN_REJECT.includes(order.status);
  const isTerminal = order.status === 'delivered';

  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 14, scale: 0.97 }}
      animate={{ opacity: 1, y: 0,  scale: 1    }}
      exit={{ opacity: 0, scale: 0.94, transition: { duration: 0.15 } }}
      key={order.id}
      className={[
        'relative rounded-xl p-4 border transition-all',
        'hover:scale-[1.01] hover:shadow-lg hover:shadow-black/20',
        error
          ? 'bg-red-950/25 border-red-500/40 ring-1 ring-red-500/20'
          : 'bg-white/[0.03] border-slate-800/60 hover:border-slate-700/80',
      ].join(' ')}
    >
      {/* ── Loading overlay ── */}
      {isLoading && (
        <div className="absolute inset-0 rounded-xl bg-slate-900/60 backdrop-blur-[2px] flex items-center justify-center z-10">
          <div className="w-5 h-5 border-2 border-[#ff6600] border-t-transparent rounded-full animate-spin" />
        </div>
      )}

      {/* ── Card header: Order ID + Total ── */}
      <div className="grid grid-cols-[1fr_auto] items-start gap-3 mb-3 pb-3 border-b border-slate-800/60">
        <div className="flex flex-col gap-1 min-w-0">
          <span className="font-mono text-[11px] text-slate-500 tracking-wider">
            Commande
          </span>
          <span className="font-mono text-[13px] font-bold text-slate-400 tracking-wide">
            #{shortId}
          </span>
        </div>
        <div className="flex flex-col items-end gap-1 shrink-0">
          <span className="text-[11px] text-slate-500">Total</span>
          <span className="text-[15px] font-black text-white whitespace-nowrap">
            {order.total_amount.toLocaleString('fr-FR')}
            <span className="text-[10px] font-semibold text-slate-500 ml-1">GNF</span>
          </span>
        </div>
      </div>

      {/* ── Card body ── */}
      <div className="space-y-2.5 mb-4">
        {/* Customer */}
        <div className="flex items-center gap-2">
          <div className="w-6 h-6 rounded-lg bg-slate-800/80 flex items-center justify-center shrink-0">
            <User className="w-3 h-3 text-slate-500" />
          </div>
          <p className="text-[13px] font-semibold text-white/80 truncate leading-none">
            {order.customer_name || 'Client Anonyme'}
          </p>
        </div>

        {/* Elapsed time + Status chip */}
        <div className="flex items-center gap-2 flex-wrap">
          <div className="flex items-center gap-1 text-[11px] text-slate-500">
            <Clock className="w-3 h-3 shrink-0" />
            <span>{formatElapsed(order.created_at)}</span>
          </div>
          <span className={`inline-flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded-full border ${chip.className}`}>
            <ChipIcon className="w-2.5 h-2.5" />
            {chip.label}
          </span>
        </div>

        {/* Items checklist */}
        {order.items && order.items.length > 0 && (
          <ul className="space-y-1 pl-1">
            {order.items.slice(0, 5).map((item, i) => (
              <li key={i} className="flex items-center gap-2 text-[11.5px] text-slate-400">
                <span className="w-1.5 h-1.5 rounded-full bg-slate-600 shrink-0" />
                <span className="truncate">
                  <span className="font-bold text-slate-300">{item.quantity}×</span>{' '}
                  {item.title}
                </span>
              </li>
            ))}
            {order.items.length > 5 && (
              <li className="text-[10px] text-slate-600 pl-3.5">
                +{order.items.length - 5} articles supplémentaires
              </li>
            )}
          </ul>
        )}
      </div>

      {error && (
        <div className="mb-3 flex items-start gap-2 bg-red-950/40 border border-red-500/25 rounded-lg px-3 py-2">
          <AlertCircle className="w-3.5 h-3.5 text-red-400 mt-0.5 shrink-0" />
          <p className="flex-1 text-[11px] font-semibold text-red-400">{error.message}</p>
          <button
            onClick={() => onClearError(order.id)}
            className="shrink-0 text-red-500/50 hover:text-red-400 transition-colors"
          >
            <X className="w-3 h-3" />
          </button>
        </div>
      )}

      {/* ── Action footer ── */}
      {isTerminal ? (
        <div className="w-full flex items-center justify-center gap-2 bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 py-3 rounded-xl text-[12px] font-bold tracking-wide">
          <CheckCheck className="w-4 h-4" />
          Livraison Complète
        </div>
      ) : (
        <div className={`flex gap-2 ${canReject ? 'flex-row' : ''}`}>
          {/* Reject button */}
          {canReject && (
            <button
              id={`reject-order-${order.id}`}
              onClick={() => onReject(order)}
              disabled={isLoading}
              className="flex-1 flex items-center justify-center gap-1.5 py-3.5 rounded-xl text-[12px] font-bold border border-rose-500/30 text-rose-400 hover:bg-rose-500/10 hover:border-rose-500/50 disabled:opacity-40 disabled:cursor-not-allowed transition-all"
            >
              <X className="w-3.5 h-3.5" />
              Refuser
            </button>
          )}

          {/* Primary advance button */}
          {primaryAction && (
            <button
              id={`advance-order-${order.id}`}
              onClick={() => onAdvance(order)}
              disabled={isLoading}
              className={[
                'flex-[2] flex items-center justify-center gap-2 py-3.5 rounded-xl text-[13px] font-black tracking-wide transition-all',
                'disabled:opacity-40 disabled:cursor-not-allowed',
                primaryAction.style === 'orange'
                  ? 'bg-[#ff6600] hover:bg-[#e65c00] text-white shadow-lg shadow-[#ff6600]/20 hover:shadow-[#ff6600]/30'
                  : primaryAction.style === 'blue'
                  ? 'bg-blue-600 hover:bg-blue-500 text-white shadow-lg shadow-blue-600/20'
                  : 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-lg shadow-emerald-600/20',
              ].join(' ')}
            >
              {isLoading ? (
                <div className="w-4 h-4 border-2 border-white/40 border-t-white rounded-full animate-spin" />
              ) : (
                primaryAction.label
              )}
            </button>
          )}
        </div>
      )}
    </motion.div>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// ColumnPanel — a single scrollable column (used only on ≥ md)
// ─────────────────────────────────────────────────────────────────────────────

interface ColumnPanelProps {
  col: ColumnDef;
  colOrders: KanbanOrder[];
  loadingIds: Set<string>;
  errors: Record<string, DbError>;
  onAdvance: (order: KanbanOrder) => void;
  onReject:  (order: KanbanOrder) => void;
  onClearError: (orderId: string) => void;
}

const ColumnPanel: React.FC<ColumnPanelProps> = ({
  col,
  colOrders,
  loadingIds,
  errors,
  onAdvance,
  onReject,
  onClearError,
}) => {
  const ColIcon = col.icon;
  const count = colOrders.length;

  return (
    <div className="flex flex-col rounded-2xl bg-slate-900/50 border border-slate-800/40 overflow-hidden h-full">
      {/* Column header */}
      <div className={`flex items-center gap-3 px-4 py-3.5 border-b border-slate-800/40 bg-slate-900/80 shrink-0`}>
        <div className={`w-8 h-8 rounded-xl bg-slate-800/80 flex items-center justify-center shrink-0`}>
          <ColIcon className={`w-4 h-4 ${col.accentColor}`} />
        </div>
        <h3 className="font-black text-[13px] text-white/80 uppercase tracking-widest flex-1">
          {col.label}
        </h3>
        <span
          className={[
            'text-[11px] px-2.5 py-1 rounded-full font-black min-w-[28px] text-center',
            col.badgeClass,
            col.pulses && count > 0 ? 'animate-pulse' : '',
          ].join(' ')}
        >
          {count}
        </span>
      </div>

      {/* Cards area */}
      <div className="flex-1 overflow-y-auto p-3 space-y-3 custom-scrollbar">
        <AnimatePresence mode="popLayout">
          {colOrders.map((order) => (
            <OrderCard
              key={order.id}
              order={order}
              isLoading={loadingIds.has(order.id)}
              error={errors[order.id] ?? null}
              onAdvance={onAdvance}
              onReject={onReject}
              onClearError={onClearError}
            />
          ))}
        </AnimatePresence>

        {count === 0 && (
          <div className="flex flex-col items-center justify-center h-32 rounded-xl border border-dashed border-slate-800/60 text-slate-700 gap-2">
            <ShoppingBag className="w-5 h-5 opacity-30" />
            <span className="text-[11px] font-medium tracking-wide opacity-50">Aucune commande</span>
          </div>
        )}
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// OrderKanban — main export
// ─────────────────────────────────────────────────────────────────────────────

export function OrderKanban({ orders, onStatusChange, onRejectOrder }: OrderKanbanProps) {
  const [localOrders, setLocalOrders] = useState<KanbanOrder[]>(orders);
  const [errors,      setErrors]      = useState<Record<string, DbError>>({});
  const [loadingIds,  setLoadingIds]  = useState<Set<string>>(new Set());
  const [activeTab,   setActiveTab]   = useState<ColumnKey>('new');

  // Sync prop → local when parent refetches
  useEffect(() => {
    setLocalOrders(orders);
  }, [orders]);

  const [chimeEnabled, setChimeEnabled] = useState(() => {
    try {
      const stored = localStorage.getItem('vendor_chime_enabled');
      return stored !== 'false'; // default to true
    } catch {
      return true;
    }
  });

  // Sync preference to localStorage
  useEffect(() => {
    try {
      localStorage.setItem('vendor_chime_enabled', String(chimeEnabled));
    } catch (e) {
      console.warn('Failed to save chime preference:', e);
    }
  }, [chimeEnabled]);

  // ── Audio chime for pending orders ─────────────────────────────────────────
  const pendingCount = localOrders.filter(
    (o) => o.status === 'pending' || o.status === 'paid'
  ).length;

  const chimeShouldRun = pendingCount > 0 && chimeEnabled;
  const chimeRef = useRef(chimeShouldRun);
  chimeRef.current = chimeShouldRun;

  useEffect(() => {
    if (chimeShouldRun) {
      startChime();
    } else {
      stopChime();
    }
    return () => {
      stopChime();
    };
  }, [chimeShouldRun]);

  // ── Helpers ────────────────────────────────────────────────────────────────
  const clearError = useCallback((orderId: string) => {
    setErrors((prev) => {
      const n = { ...prev };
      delete n[orderId];
      return n;
    });
  }, []);

  const setLoading = useCallback((orderId: string, val: boolean) => {
    setLoadingIds((prev) => {
      const n = new Set(prev);
      val ? n.add(orderId) : n.delete(orderId);
      return n;
    });
  }, []);

  // ── Advance order ──────────────────────────────────────────────────────────
  const handleAdvance = useCallback(async (order: KanbanOrder) => {
    const action = PRIMARY_ACTION[order.status];
    if (!action) return;
    const nextStatus = action.nextStatus;

    // Optimistic update
    setLocalOrders((prev) =>
      prev.map((o) => (o.id === order.id ? { ...o, status: nextStatus } : o))
    );
    setLoading(order.id, true);
    clearError(order.id);

    try {
      await onStatusChange(order.id, nextStatus);
    } catch (err) {
      // Rollback
      setLocalOrders(orders);
      setErrors((prev) => ({ ...prev, [order.id]: extractDbError(err) }));
      console.error(`[OrderKanban] Transition ${order.status} → ${nextStatus} failed:`, err);
    } finally {
      setLoading(order.id, false);
    }
  }, [orders, onStatusChange, setLoading, clearError]);

  // ── Reject order ───────────────────────────────────────────────────────────
  const handleReject = useCallback(async (order: KanbanOrder) => {
    setLoading(order.id, true);
    clearError(order.id);

    try {
      if (onRejectOrder) {
        await onRejectOrder(order.id);
      } else {
        await onStatusChange(order.id, 'delivered'); // fallback — should not happen
      }
      // Remove from local list after reject (parent will re-sync via subscription)
      setLocalOrders((prev) => prev.filter((o) => o.id !== order.id));
    } catch (err) {
      setErrors((prev) => ({ ...prev, [order.id]: extractDbError(err) }));
      console.error(`[OrderKanban] Reject ${order.id} failed:`, err);
    } finally {
      setLoading(order.id, false);
    }
  }, [onRejectOrder, onStatusChange, setLoading, clearError]);

  // ── Derived data ───────────────────────────────────────────────────────────
  const columnOrders = COLUMNS.reduce<Record<ColumnKey, KanbanOrder[]>>(
    (acc, col) => {
      acc[col.key] = localOrders.filter((o) => col.statuses.includes(o.status));
      return acc;
    },
    { new: [], kitchen: [], done: [] }
  );

  const activeColOrders = columnOrders[activeTab];
  const activeCol = COLUMNS.find((c) => c.key === activeTab)!;

  return (
    <div className="w-full">
      {/* Sound alert control bar */}
      <div className="flex justify-between items-center mb-6 px-4 py-3 bg-slate-900/40 border border-slate-800/40 rounded-xl">
        <div className="flex items-center gap-2.5">
          {pendingCount > 0 && chimeEnabled && (
            <span className="flex h-2.5 w-2.5 relative">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-amber-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-amber-500"></span>
            </span>
          )}
          <span className="text-[11px] font-bold text-slate-400 tracking-wider uppercase">
            {pendingCount > 0 
              ? `${pendingCount} commande(s) en attente — Alerte Sonore`
              : "Aucune commande en attente — Alerte Sonore en veille"
            }
          </span>
        </div>
        <button
          onClick={() => {
            setChimeEnabled((p) => {
              const nextVal = !p;
              if (!nextVal) stopChime();
              return nextVal;
            });
          }}
          className={[
            "flex items-center gap-2 px-3 py-1.5 rounded-lg border text-[11px] font-black uppercase tracking-wider transition-all",
            chimeEnabled
              ? "bg-amber-500/10 text-amber-500 border-amber-500/30 hover:bg-amber-500/20 cursor-pointer"
              : "bg-slate-800/50 text-slate-400 border-slate-800/80 hover:bg-slate-800 cursor-pointer"
          ].join(" ")}
        >
          {chimeEnabled ? (
            <>
              <Volume2 className="w-3.5 h-3.5 animate-pulse" /> Actif
            </>
          ) : (
            <>
              <VolumeX className="w-3.5 h-3.5" /> Muet
            </>
          )}
        </button>
      </div>
      {/* ═══════════════════════════════════════════════════════════════════
          MOBILE LAYOUT  (< md = < 768px)
          Sticky tab bar + single-column card list
      ═══════════════════════════════════════════════════════════════════ */}
      <div className="md:hidden flex flex-col gap-4">
        {/* Sticky horizontal tab bar */}
        <div className="sticky top-0 z-20 -mx-4 px-4 pt-2 pb-3 bg-[#0B0E11]/95 backdrop-blur-md border-b border-slate-800/60">
          <div className="flex gap-2">
            {COLUMNS.map((col) => {
              const ColIcon = col.icon;
              const count = columnOrders[col.key].length;
              const isActive = activeTab === col.key;

              return (
                <button
                  key={col.key}
                  id={`kanban-tab-${col.key}`}
                  onClick={() => setActiveTab(col.key)}
                  className={[
                    'flex-1 flex flex-col items-center gap-1.5 py-3 px-2 rounded-xl text-[11px] font-black uppercase tracking-widest transition-all',
                    isActive
                      ? 'bg-slate-800 text-white shadow-md'
                      : 'text-slate-600 hover:text-slate-400 hover:bg-slate-800/40',
                  ].join(' ')}
                >
                  <div className="relative">
                    <ColIcon className={`w-5 h-5 ${isActive ? col.accentColor : ''}`} />
                    {count > 0 && (
                      <span
                        className={[
                          'absolute -top-1.5 -right-2 text-[9px] font-black px-1 rounded-full min-w-[16px] text-center',
                          col.badgeClass,
                          col.pulses && count > 0 ? 'animate-pulse' : '',
                        ].join(' ')}
                      >
                        {count}
                      </span>
                    )}
                  </div>
                  <span className="leading-none text-center">{col.label}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Active tab column header on mobile */}
        <div className={`flex items-center gap-2 px-1`}>
          <activeCol.icon className={`w-4 h-4 ${activeCol.accentColor}`} />
          <span className="text-[12px] font-black text-white/60 uppercase tracking-widest">
            {activeCol.label}
          </span>
          <span className={`text-[10px] px-2 py-0.5 rounded-full font-black ${activeCol.badgeClass}`}>
            {activeColOrders.length}
          </span>
        </div>

        {/* Card list for active tab */}
        <AnimatePresence mode="popLayout">
          {activeColOrders.length === 0 ? (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="flex flex-col items-center justify-center py-16 gap-3 text-slate-700"
            >
              <ShoppingBag className="w-8 h-8 opacity-30" />
              <p className="text-[12px] font-medium tracking-wide opacity-50">
                Aucune commande dans cette section
              </p>
            </motion.div>
          ) : (
            activeColOrders.map((order) => (
              <OrderCard
                key={order.id}
                order={order}
                isLoading={loadingIds.has(order.id)}
                error={errors[order.id] ?? null}
                onAdvance={handleAdvance}
                onReject={handleReject}
                onClearError={clearError}
              />
            ))
          )}
        </AnimatePresence>
      </div>

      {/* ═══════════════════════════════════════════════════════════════════
          DESKTOP LAYOUT  (≥ md = ≥ 768px)
          3-column grid — all columns visible simultaneously
      ═══════════════════════════════════════════════════════════════════ */}
      <div
        className="hidden md:grid md:grid-cols-3 gap-6"
        style={{ height: 'calc(100vh - 180px)' }}
      >
        {COLUMNS.map((col) => (
          <ColumnPanel
            key={col.key}
            col={col}
            colOrders={columnOrders[col.key]}
            loadingIds={loadingIds}
            errors={errors}
            onAdvance={handleAdvance}
            onReject={handleReject}
            onClearError={clearError}
          />
        ))}
      </div>
    </div>
  );
}
