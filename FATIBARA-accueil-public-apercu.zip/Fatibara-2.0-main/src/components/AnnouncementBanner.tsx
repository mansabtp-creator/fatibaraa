import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Megaphone, X, ChevronRight } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { useAppContext } from '../context/AppContext';

export default function AnnouncementBanner() {
  const [announcements, setAnnouncements] = useState<any[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isVisible, setIsVisible] = useState(true);
  const { user } = useAppContext();

  useEffect(() => {
    async function fetchAnnouncements() {
      // Fetch user role to filter announcements
      let userRole = 'user';
      if (user) {
        const { data: profile } = await supabase
          .from('profiles')
          .select('is_admin')
          .eq('id', user.id)
          .single();
        
        const { data: store } = await supabase
          .from('stores')
          .select('id')
          .eq('owner_id', user.id)
          .maybeSingle();

        if (profile?.is_admin) userRole = 'all';   // admins see everything
        else if (store) userRole = 'vendors';
        else userRole = 'buyers';
      }

      // target_type values: 'all' | 'vendors' | 'buyers' | 'couriers'
      const { data, error } = await supabase
        .from('announcements')
        .select('*')
        .eq('is_active', true)
        .or(`target_type.eq.all,target_type.eq.${userRole}`)
        .order('created_at', { ascending: false });

      if (data && data.length > 0) {
        setAnnouncements(data);
      }
    }

    fetchAnnouncements();

    // Rotate announcements every 10 seconds
    const interval = setInterval(() => {
      setAnnouncements(prev => {
        if (prev.length <= 1) return prev;
        setCurrentIndex(current => (current + 1) % prev.length);
        return prev;
      });
    }, 10000);

    return () => clearInterval(interval);
  }, [user]);

  if (!isVisible || announcements.length === 0) return null;

  const current = announcements[currentIndex];

  return (
    <AnimatePresence>
      <motion.div 
        initial={{ height: 0, opacity: 0 }}
        animate={{ height: 'auto', opacity: 1 }}
        exit={{ height: 0, opacity: 0 }}
        className="bg-[#ff6600] text-white relative overflow-hidden z-40"
      >
        <div className="max-w-7xl mx-auto px-4 py-2 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3 overflow-hidden">
            <div className="bg-white/20 p-1.5 rounded-lg flex-shrink-0 animate-pulse">
              <Megaphone className="w-3.5 h-3.5" />
            </div>
            <div className="flex flex-col sm:flex-row sm:items-center gap-1 sm:gap-3 overflow-hidden">
              <span className="text-[10px] font-bold tracking-wider bg-white dark:bg-gray-900 text-[#ff6600] px-2 py-0.5 rounded leading-none whitespace-nowrap">
                Annonce
              </span>
              <p className="text-[11px] font-bold truncate uppercase tracking-tight">
                {current.title}: <span className="opacity-80 font-medium">{current.content}</span>
              </p>
            </div>
          </div>
          
          <div className="flex items-center gap-4">
            {announcements.length > 1 && (
               <div className="hidden sm:flex items-center gap-1">
                 {announcements.map((_, i) => (
                   <div 
                    key={i} 
                    className={`h-1 rounded-full transition-all duration-500 ${i === currentIndex ? 'w-4 bg-white dark:bg-gray-900' : 'w-1 bg-white/30'}`}
                   />
                 ))}
               </div>
            )}
            <button 
              onClick={() => setIsVisible(false)}
              className="p-1 hover:bg-white/10 rounded-lg transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>
        <div className="absolute bottom-0 left-0 h-[1px] bg-white/20 w-full" />
      </motion.div>
    </AnimatePresence>
  );
}
