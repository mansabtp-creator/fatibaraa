import React from 'react';
import { ShieldCheck, Zap, Truck, Star, Award } from 'lucide-react';
import { APP_NAME } from '../lib/constants';

export type BadgeType = 'verified' | 'fast_shipper' | 'top_rated' | 'premium' | 'guarantee';

interface SellerBadgeProps {
  type: BadgeType;
  showLabel?: boolean;
  className?: string;
  key?: React.Key;
}

const BADGE_CONFIG = {
  verified: {
    label: 'Vérifié Pro',
    icon: ShieldCheck,
    color: 'text-[#ff6600]',
    bg: 'bg-[#ff6600]/10',
    border: 'border-[#ff6600]/20',
    description: `Boutique physique authentifiée par ${APP_NAME}`
  },
  fast_shipper: {
    label: 'Expédition Éclair',
    icon: Zap,
    color: 'text-orange-600',
    bg: 'bg-orange-600/10',
    border: 'border-orange-600/20',
    description: 'Expédie généralement en moins de 12 heures'
  },
  top_rated: {
    label: 'Mieux Noté',
    icon: Star,
    color: 'text-orange-500',
    bg: 'bg-orange-500/10',
    border: 'border-orange-500/20',
    description: 'Maintenir une note moyenne supérieure à 4.8/5'
  },
  premium: {
    label: 'Vendeur Élite',
    icon: Award,
    color: 'text-purple-600',
    bg: 'bg-purple-600/10',
    border: 'border-purple-600/20',
    description: 'Membre du programme exclusif Vendeur Élite'
  },
  guarantee: {
    label: 'Qualité Garantie',
    icon: Truck,
    color: 'text-blue-600',
    bg: 'bg-blue-600/10',
    border: 'border-blue-600/20',
    description: 'Engagement de conformité sur tous les articles'
  }
};

export default function SellerBadge({ type, showLabel = true, className = "" }: SellerBadgeProps) {
  const config = BADGE_CONFIG[type];
  const Icon = config.icon;

  return (
    <div 
      className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full border ${config.bg} ${config.color} ${config.border} transition-all hover:scale-105 cursor-help ${className}`}
      title={config.description}
    >
      <Icon className="w-3.5 h-3.5" />
      {showLabel && <span className="text-[10px] font-bold tracking-wider">{config.label}</span>}
    </div>
  );
}

export function BadgeShelf({ badges }: { badges: string[] }) {
  return (
    <div className="flex flex-wrap gap-2">
      {badges.map((b) => (
        <SellerBadge key={b} type={b as BadgeType} />
      ))}
    </div>
  );
}
