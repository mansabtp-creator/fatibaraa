/**
 * VendorTour.tsx
 *
 * A lightweight first-login tooltip walkthrough for new vendors.
 * Shown once per browser (localStorage flag). No external library
 * needed — uses a step-by-step overlay with a highlight ring and
 * an arrow tooltip positioned via data-tour attributes.
 *
 * HOW TO USE:
 *   1. Add `data-tour="dashboard-stats"` (etc.) to any element you
 *      want highlighted.
 *   2. The tour reads the element's bounding rect and draws a spotlight.
 *   3. Render <VendorTour /> inside VendorLayout or each vendor page.
 *
 * STEPS are defined in the TOUR_STEPS array below. Each step targets
 * a `data-tour` attribute value on a DOM element.
 *
 * SKIP / DISMISS:
 *   - "Suivant" advances the step.
 *   - "Passer" or the final "Terminer" marks the tour done in localStorage.
 */
import React, { useState, useEffect, useCallback, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, ChevronRight, Sparkles } from 'lucide-react';

// ─── Types ────────────────────────────────────────────────────────────────────

interface TourStep {
  target: string;        // value of data-tour attribute
  title: string;
  body: string;
  placement?: 'top' | 'bottom' | 'left' | 'right';
}

interface SpotlightRect {
  top: number;
  left: number;
  width: number;
  height: number;
}

// ─── Tour steps ───────────────────────────────────────────────────────────────

const TOUR_STEPS: TourStep[] = [
  {
    target: 'vendor-stats',
    title: '📊 Vos indicateurs clés',
    body: "Ventes, revenus et commandes en cours — tout d'un coup d'œil. Actualisés en temps réel.",
    placement: 'bottom',
  },
  {
    target: 'vendor-products-link',
    title: '🛍️ Gérez vos produits',
    body: 'Ajoutez, modifiez et retirez vos articles depuis cet onglet. Chaque produit mis en ligne booste votre visibilité.',
    placement: 'right',
  },
  {
    target: 'vendor-orders-link',
    title: '📦 Suivez vos commandes',
    body: "Les nouvelles commandes apparaissent ici instantanément. Confirmez ou annulez en un clic.",
    placement: 'right',
  },
  {
    target: 'vendor-marketing-link',
    title: '⚡ Boostez votre boutique',
    body: "Créez des promotions et des campagnes Boost pour apparaître en tête des résultats.",
    placement: 'right',
  },
  {
    target: 'vendor-inbox-link',
    title: '💬 Centre de messages',
    body: "Discutez directement avec vos acheteurs. Un vendeur réactif vend plus !",
    placement: 'right',
  },
];

// ─── Constants ────────────────────────────────────────────────────────────────

const TOUR_DONE_KEY = 'fatibara_vendor_tour_done';
const PADDING = 8; // px spotlight padding around element

// ─── Utilities ────────────────────────────────────────────────────────────────

function getElementRect(tourKey: string): DOMRect | null {
  const el = document.querySelector(`[data-tour="${tourKey}"]`);
  return el ? el.getBoundingClientRect() : null;
}

// ─── Component ────────────────────────────────────────────────────────────────

export default function VendorTour() {
  const [step, setStep] = useState(0);
  const [visible, setVisible] = useState(false);
  const [spotlight, setSpotlight] = useState<SpotlightRect | null>(null);
  const [tooltipPos, setTooltipPos] = useState({ top: 0, left: 0 });
  const tooltipRef = useRef<HTMLDivElement>(null);

  // Only show if not already done
  useEffect(() => {
    const done = localStorage.getItem(TOUR_DONE_KEY) === 'true';
    if (!done) {
      // Small delay so vendor layout elements have mounted
      const t = setTimeout(() => setVisible(true), 800);
      return () => clearTimeout(t);
    }
  }, []);

  const positionForStep = useCallback((stepIdx: number) => {
    const currentStep = TOUR_STEPS[stepIdx];
    const rect = getElementRect(currentStep.target);
    if (!rect) {
      // Target not in DOM — skip this step
      return false;
    }

    setSpotlight({
      top: rect.top - PADDING + window.scrollY,
      left: rect.left - PADDING + window.scrollX,
      width: rect.width + PADDING * 2,
      height: rect.height + PADDING * 2,
    });

    // Position tooltip relative to viewport
    const placement = currentStep.placement ?? 'bottom';
    const tooltipWidth = 280;
    const tooltipHeight = 160; // approximate

    let top = 0;
    let left = 0;

    if (placement === 'bottom') {
      top = rect.bottom + PADDING + 12;
      left = Math.max(8, rect.left + rect.width / 2 - tooltipWidth / 2);
    } else if (placement === 'top') {
      top = rect.top - PADDING - tooltipHeight - 12;
      left = Math.max(8, rect.left + rect.width / 2 - tooltipWidth / 2);
    } else if (placement === 'right') {
      top = rect.top + rect.height / 2 - tooltipHeight / 2;
      left = rect.right + PADDING + 12;
    } else if (placement === 'left') {
      top = rect.top + rect.height / 2 - tooltipHeight / 2;
      left = rect.left - PADDING - tooltipWidth - 12;
    }

    // Clamp to viewport
    top = Math.max(8, Math.min(top, window.innerHeight - tooltipHeight - 8));
    left = Math.max(8, Math.min(left, window.innerWidth - tooltipWidth - 8));

    setTooltipPos({ top, left });
    return true;
  }, []);

  useEffect(() => {
    if (!visible) return;
    positionForStep(step);
  }, [step, visible, positionForStep]);

  const markDone = () => {
    localStorage.setItem(TOUR_DONE_KEY, 'true');
    setVisible(false);
  };

  const handleNext = () => {
    if (step < TOUR_STEPS.length - 1) {
      setStep(s => s + 1);
    } else {
      markDone();
    }
  };

  if (!visible) return null;

  const currentStep = TOUR_STEPS[step];
  const isLast = step === TOUR_STEPS.length - 1;

  return (
    <AnimatePresence>
      {/* Scrim */}
      <motion.div
        key="tour-scrim"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 z-[500] pointer-events-none"
        style={{
          background: spotlight
            ? `radial-gradient(ellipse ${spotlight.width + 32}px ${spotlight.height + 32}px at ${spotlight.left + spotlight.width / 2}px ${spotlight.top + spotlight.height / 2 - window.scrollY}px, transparent 40%, rgba(0,0,0,0.65) 70%)`
            : 'rgba(0,0,0,0.65)',
        }}
      />

      {/* Click-away capture */}
      <div
        key="tour-clickaway"
        className="fixed inset-0 z-[501]"
        onClick={markDone}
        aria-hidden
      />

      {/* Spotlight ring */}
      {spotlight && (
        <motion.div
          key={`spotlight-${step}`}
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.25 }}
          className="fixed z-[502] pointer-events-none rounded-2xl border-2 border-[#ff6600] shadow-[0_0_0_4px_rgba(255,102,0,0.2)]"
          style={{
            top: spotlight.top - window.scrollY,
            left: spotlight.left,
            width: spotlight.width,
            height: spotlight.height,
          }}
        />
      )}

      {/* Tooltip card */}
      <motion.div
        key={`tooltip-${step}`}
        ref={tooltipRef}
        initial={{ opacity: 0, y: 8, scale: 0.96 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        exit={{ opacity: 0, y: 8, scale: 0.96 }}
        transition={{ duration: 0.25, ease: 'easeOut' }}
        className="fixed z-[503] w-[280px] bg-white dark:bg-gray-900 rounded-2xl shadow-2xl border border-gray-100 dark:border-white/10 p-5 pointer-events-auto"
        style={{ top: tooltipPos.top, left: tooltipPos.left }}
        onClick={e => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-start justify-between gap-2 mb-3">
          <div className="flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-[#ff6600] shrink-0" />
            <h3 className="text-[13px] font-black text-gray-900 dark:text-white leading-tight">
              {currentStep.title}
            </h3>
          </div>
          <button
            onClick={markDone}
            className="w-6 h-6 rounded-full bg-gray-100 dark:bg-gray-800 flex items-center justify-center hover:bg-gray-200 dark:hover:bg-gray-700 transition-colors shrink-0 mt-0.5"
          >
            <X className="w-3 h-3 text-gray-500" />
          </button>
        </div>

        {/* Body */}
        <p className="text-[12px] text-gray-500 dark:text-gray-400 font-medium leading-relaxed mb-4">
          {currentStep.body}
        </p>

        {/* Footer */}
        <div className="flex items-center justify-between">
          {/* Step dots */}
          <div className="flex items-center gap-1">
            {TOUR_STEPS.map((_, i) => (
              <div
                key={i}
                className={`h-1.5 rounded-full transition-all duration-300 ${
                  i === step ? 'w-4 bg-[#ff6600]' : i < step ? 'w-2 bg-green-400' : 'w-2 bg-gray-200 dark:bg-gray-700'
                }`}
              />
            ))}
          </div>

          {/* Actions */}
          <div className="flex items-center gap-2">
            <button
              onClick={markDone}
              className="text-[11px] font-bold text-gray-400 hover:text-gray-600 dark:hover:text-gray-300 transition-colors"
            >
              Passer
            </button>
            <button
              onClick={handleNext}
              className="flex items-center gap-1 bg-[#ff6600] text-white px-3.5 py-1.5 rounded-lg text-[11px] font-black uppercase tracking-wide hover:bg-[#e65c00] transition-colors"
            >
              {isLast ? 'Terminer ✓' : 'Suivant'}
              {!isLast && <ChevronRight className="w-3 h-3" />}
            </button>
          </div>
        </div>
      </motion.div>
    </AnimatePresence>
  );
}
