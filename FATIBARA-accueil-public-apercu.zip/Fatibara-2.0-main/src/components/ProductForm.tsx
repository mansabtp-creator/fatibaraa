import React, { useState, useRef, useEffect, useCallback } from 'react';
import { Loader2, Sparkles, Upload, X, Mic, RotateCcw, Check, Wand2, Plus, Calendar, Download, Package, TrendingUp, Coins, Banknote, AlertCircle, ShieldCheck, Target, Image as ImageIcon, Settings, FileText, Layers } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { supabase } from '../lib/supabase';
import { extractProductMetadata, generateProductDescription, generateSEOContent } from '../services/geminiService';
import { getAIDynamicPricing, PricingInsight } from '../services/pricingService';
import { hapticFeedback } from '../lib/haptics';
import { useToast } from '../context/ToastContext';
import { SEOTracker } from './SEOTracker';
import { VolumePricing } from './VolumePricing';
import { PRODUCT_CATEGORIES, APP_NAME } from '../lib/constants';

interface ProductVariant {
  id: string;
  size: string;
  color: string;
  stock_count: number;
  price_override: number | null;
}

interface ProductFormProps {
  product: {
    title: string;
    description: string;
    price_gnf: string;
    buying_price_gnf?: string;
    stock_quantity: string;
    image_url: string;
    image_urls: string[];
    is_hero?: boolean;
    variants: ProductVariant[];
    status: 'draft' | 'published' | 'scheduled';
    scheduled_at: string;
    low_stock_threshold: string;
    is_digital: boolean;
    download_url: string;
    volume_discount_qty?: string;
    volume_discount_percent?: string;
    category?: string;
    seo_description?: string;
  };
  errors?: Record<string, string>;
  touched?: Record<string, boolean>;
  onChange: (field: string, value: any) => void;
  onBlur?: (field: string) => void;
  onSubmit: (e: React.FormEvent) => void;
  onSaveAsDraft?: (e: React.MouseEvent) => void;
  onGenerateAI: () => void;
  isGeneratingAI: boolean;
  isSaving: boolean;
}

// ─── Section Header ──────────────────────────────────────────────────────────
function SectionHeader({ icon: Icon, title, step }: { icon: React.ElementType; title: string; step: number }) {
  return (
    <div className="flex items-center gap-3 mb-5">
      <div className="w-7 h-7 bg-[#ff6600]/10 rounded-lg flex items-center justify-center shrink-0">
        <Icon className="w-3.5 h-3.5 text-[#ff6600]" />
      </div>
      <span className="text-[11px] font-black text-gray-900 dark:text-white uppercase tracking-[0.2em]">{title}</span>
      <div className="h-px bg-gray-100 dark:bg-white/5 flex-1" />
      <span className="text-[9px] font-black text-gray-400 tabular-nums">{step}/6</span>
    </div>
  );
}

// ─── Field wrapper ────────────────────────────────────────────────────────────
function Field({ label, required, children, hint, error }: {
  label: string; required?: boolean; children: React.ReactNode; hint?: string; error?: string;
}) {
  return (
    <div className="space-y-1.5">
      <label className="flex items-center gap-1 text-[11px] font-black text-gray-500 dark:text-gray-400 uppercase tracking-widest">
        {label}{required && <span className="text-[#ff6600]">*</span>}
      </label>
      {children}
      {error && <p className="text-red-500 text-[10px] font-bold uppercase tracking-wide ml-1">{error}</p>}
      {hint && !error && <p className="text-gray-400 text-[10px] font-medium ml-1 italic">{hint}</p>}
    </div>
  );
}

// ─── Section Card ─────────────────────────────────────────────────────────────
function SectionCard({ children, className = '' }: { children: React.ReactNode; className?: string }) {
  return (
    <div className={`bg-white dark:bg-[#1A1D21] rounded-2xl sm:rounded-[2rem] border border-gray-100 dark:border-white/5 p-5 sm:p-7 shadow-sm ${className}`}>
      {children}
    </div>
  );
}

export function ProductForm({
  product,
  errors = {},
  touched = {},
  onChange,
  onBlur,
  onSubmit,
  onSaveAsDraft,
  onGenerateAI,
  isGeneratingAI,
  isSaving
}: ProductFormProps) {
  const [isUploading, setIsUploading] = useState(false);
  const [uploadError, setUploadError] = useState('');
  const [isDragging, setIsDragging] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [isExtracting, setIsExtracting] = useState(false);
  const [isPricingLoading, setIsPricingLoading] = useState(false);
  const [isGenLoading, setIsGenLoading] = useState(false);
  const [pricingInsight, setPricingInsight] = useState<PricingInsight | null>(null);
  const [aiModifiedFields, setAiModifiedFields] = useState<Set<string>>(new Set());
  const [preAiState, setPreAiState] = useState<any>(null);
  const [isCleaningImage, setIsCleaningImage] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { showToast } = useToast();

  const totalVariantStock = (product.variants || []).reduce((sum, v) => sum + (Number(v.stock_count) || 0), 0);
  const hasVariants = (product.variants || []).length > 0;
  const imageUrls: string[] = Array.isArray(product.image_urls)
    ? product.image_urls.filter(Boolean)
    : product.image_url ? [product.image_url] : [];

  useEffect(() => {
    if (hasVariants) onChange('stock_quantity', totalVariantStock.toString());
  }, [totalVariantStock, hasVariants]);

  const addVariantPreset = (type: 'size' | 'color') => {
    const presets = { size: ['S', 'M', 'L', 'XL', 'XXL'], color: ['Noir', 'Blanc', 'Bleu', 'Rouge', 'Vert'] };
    const newVariants = [...(product.variants || [])];
    presets[type].forEach(val => {
      newVariants.push({ id: Math.random().toString(36).substring(2, 9), size: type === 'size' ? val : '', color: type === 'color' ? val : '', stock_count: 0, price_override: null });
    });
    onChange('variants', newVariants);
    showToast(`Pack de ${type === 'size' ? 'tailles' : 'couleurs'} ajouté`, 'info');
  };

  const handleManualChange = (field: string, value: string) => {
    if (aiModifiedFields.has(field)) {
      const newModified = new Set(aiModifiedFields);
      newModified.delete(field);
      setAiModifiedFields(newModified);
    }
    onChange(field, value);
  };

  const handleRestore = (field: string) => {
    if (preAiState && preAiState[field] !== undefined) {
      onChange(field, preAiState[field]);
      const newModified = new Set(aiModifiedFields);
      newModified.delete(field);
      setAiModifiedFields(newModified);
      hapticFeedback('selection');
    }
  };

  const handleApprove = (field: string) => {
    const newModified = new Set(aiModifiedFields);
    newModified.delete(field);
    setAiModifiedFields(newModified);
    hapticFeedback('success');
  };

  const recognitionRef = useRef<any>(null);
  useEffect(() => {
    const SR = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SR) return;
    const rec = new SR();
    rec.continuous = false; rec.lang = 'fr-FR'; rec.interimResults = false;
    rec.onresult = async (event: any) => {
      const transcript = event.results[0][0].transcript;
      setIsListening(false); hapticFeedback('success'); setIsExtracting(true);
      setPreAiState({ ...product });
      try {
        const metadata = await extractProductMetadata(transcript);
        const newlyModified = new Set<string>();
        if (metadata.title) { onChange('title', metadata.title); newlyModified.add('title'); }
        if (metadata.price) { onChange('price_gnf', metadata.price.toString()); newlyModified.add('price_gnf'); }
        if (metadata.stock) { onChange('stock_quantity', metadata.stock.toString()); newlyModified.add('stock_quantity'); }
        if (metadata.description) { onChange('description', metadata.description); newlyModified.add('description'); }
        setAiModifiedFields(newlyModified); hapticFeedback('bloom');
      } catch (err: any) {
        showToast(err.message || "L'extraction IA a échoué.", 'error');
      } finally { setIsExtracting(false); }
    };
    rec.onerror = () => { setIsListening(false); hapticFeedback('warning'); };
    recognitionRef.current = rec;
    return () => { try { rec.abort(); } catch { /* noop */ } };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const toggleListening = () => {
    const recognition = recognitionRef.current;
    if (!recognition) { showToast("La recherche vocale n'est pas supportée.", 'error'); return; }
    if (isListening) { recognition.stop(); setIsListening(false); }
    else { hapticFeedback('selection'); recognition.start(); setIsListening(true); }
  };

  const uploadFiles = useCallback(async (files: File[]) => {
    if (files.length === 0) return;
    if (imageUrls.length + files.length > 5) { setUploadError('Maximum 5 images autorisées.'); return; }
    setIsUploading(true); setUploadError('');
    try {
      const urls = await Promise.all(files.map(async (file) => {
        if (!file.type.startsWith('image/')) throw new Error(`Fichier non valide: ${file.name}`);
        if (file.size > 5 * 1024 * 1024) throw new Error(`Trop volumineux: ${file.name}`);
        const fileExt = file.name.split('.').pop();
        const fileName = `${Math.random().toString(36).substring(2, 15)}_${Date.now()}.${fileExt}`;
        const filePath = `products/${fileName}`;
        const { error: uploadErr } = await supabase.storage.from('product-images').upload(filePath, file, { cacheControl: '3600', upsert: true });
        if (uploadErr) throw uploadErr;
        const { data: { publicUrl } } = supabase.storage.from('product-images').getPublicUrl(filePath);
        if (!publicUrl) throw new Error("Échec de la génération de l'URL publique");
        return publicUrl;
      }));
      const newUrls = [...imageUrls, ...urls];
      onChange('image_urls', newUrls);
      if (newUrls.length > 0) onChange('image_url', newUrls[0]);
      showToast(`${urls.length} image(s) ajoutée(s)`, 'success');
    } catch (error: any) {
      let message = error.message || 'Échec du téléchargement.';
      if (message.includes('schema is invalid') || message.includes('Schema is invalid')) {
        message = "Supabase: Le bucket 'product-images' est manquant. Créez-le dans votre tableau de bord Supabase.";
      }
      setUploadError(message);
    } finally {
      setIsUploading(false);
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  }, [imageUrls, onChange, showToast]);

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => uploadFiles(Array.from(e.target.files || []));
  const handleDrop = useCallback((e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault(); setIsDragging(false);
    uploadFiles((Array.from(e.dataTransfer.files) as File[]).filter(f => f.type.startsWith('image/')));
  }, [uploadFiles]);
  const handleDragOver = (e: React.DragEvent<HTMLDivElement>) => { e.preventDefault(); setIsDragging(true); };
  const handleDragLeave = () => setIsDragging(false);

  const removeImage = (index: number) => {
    const newUrls = imageUrls.filter((_, i) => i !== index);
    onChange('image_urls', newUrls);
    onChange('image_url', newUrls[0] || '');
    hapticFeedback('selection');
  };

  const handleSubmit = (e: React.FormEvent) => { e.preventDefault(); hapticFeedback('reward'); onSubmit(e); };

  // AI action pills
  const AIActions = ({ field }: { field: string }) => (
    <AnimatePresence>
      {aiModifiedFields.has(field) && (
        <motion.div initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0, scale: 0.9 }} className="flex items-center gap-1.5">
          <button type="button" onClick={() => handleRestore(field)}
            className="flex items-center gap-1 px-2 py-0.5 bg-gray-100 dark:bg-white/10 rounded-full text-[9px] font-black uppercase tracking-wider text-gray-500 hover:bg-gray-200 transition-all border border-gray-200 dark:border-white/10">
            <RotateCcw className="w-2.5 h-2.5" /> Restaurer
          </button>
          <button type="button" onClick={() => handleApprove(field)}
            className="flex items-center gap-1 px-2 py-0.5 bg-emerald-500/10 rounded-full text-[9px] font-black uppercase tracking-wider text-emerald-600 hover:bg-emerald-500/20 transition-all border border-emerald-500/20">
            <Check className="w-2.5 h-2.5" /> OK
          </button>
        </motion.div>
      )}
    </AnimatePresence>
  );

  const inputCls = (field: string, extra = '') =>
    `w-full transition-all duration-300 rounded-xl sm:rounded-[1.5rem] p-4 sm:p-5 text-[14px] sm:text-[15px] font-bold focus:outline-none placeholder:text-gray-300 dark:placeholder:text-gray-600 text-gray-900 dark:text-white ${
      aiModifiedFields.has(field)
        ? 'bg-[#ff6600]/5 border border-[#ff6600]/40 ring-2 ring-[#ff6600]/10'
        : touched[field] && errors[field]
        ? 'bg-red-50 dark:bg-red-500/5 border border-red-400 focus:border-red-500'
        : 'bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-white/8 focus:border-[#ff6600] dark:focus:border-[#ff6600]'
    } ${extra}`;

  return (
    <>
      <form id="product-form" onSubmit={handleSubmit} className="space-y-5 pb-28 sm:pb-6">

        {/* ── VOICE ASSISTANT ─────────────────────────────────────────────── */}
        <div
          aria-live="polite"
          aria-label={isExtracting ? "IA en train d'analyser" : isListening ? "En écoute vocale" : "Assistant vocal"}
          className={`p-4 sm:p-5 rounded-2xl border transition-all flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 ${
            isListening ? 'bg-[#ff6600]/10 border-[#ff6600] animate-pulse'
            : isExtracting ? 'bg-gray-900 border-gray-700'
            : 'bg-white dark:bg-[#1A1D21] border-gray-100 dark:border-white/5'
          }`}
        >
          <div className="flex items-center gap-3.5">
            <div className={`w-11 h-11 rounded-2xl flex items-center justify-center shrink-0 transition-all ${isListening ? 'bg-[#ff6600] text-white scale-110' : 'bg-gray-100 dark:bg-white/10 text-gray-500 dark:text-gray-300'}`}>
              {isExtracting ? <Loader2 className="w-5 h-5 animate-spin text-white" /> : <Mic className="w-5 h-5" />}
            </div>
            <div>
              <p className={`text-[13px] font-black leading-none mb-0.5 ${isExtracting ? 'text-white' : 'text-gray-900 dark:text-white'}`}>
                {isExtracting ? "IA en train d'analyser..." : isListening ? 'En écoute...' : 'Magie Vocale'}
              </p>
              <p className="text-[10px] font-bold tracking-wide text-gray-400">
                {isListening ? 'Parlez maintenant (ex: Nike Air Max à 450 000 GNF)' : 'Remplissez le formulaire par la voix'}
              </p>
            </div>
          </div>
          <button
            type="button" onClick={toggleListening} disabled={isExtracting}
            aria-label={isListening ? "Arrêter la reconnaissance vocale" : "Démarrer l'assistant vocal IA"}
            className={`shrink-0 px-6 py-2.5 rounded-full text-[11px] font-black tracking-wider transition-all active:scale-95 min-h-[40px] ${
              isListening ? 'bg-red-500 text-white shadow-lg shadow-red-500/30' : 'bg-gray-900 dark:bg-white text-white dark:text-gray-900 hover:bg-[#ff6600] hover:text-white'
            }`}
          >
            {isListening ? 'Arrêter' : 'Démarrer IA'}
          </button>
        </div>

        {/* ── SECTION 1: PRODUIT ──────────────────────────────────────────── */}
        <SectionCard>
          <SectionHeader icon={Package} title="Produit" step={1} />
          <div className="space-y-4">
            <Field label="Catégorie" required error={touched.category && errors.category ? errors.category : undefined}>
              <div className="relative">
                <select required value={product.category || PRODUCT_CATEGORIES[0]}
                  onChange={(e) => handleManualChange('category', e.target.value)}
                  onBlur={() => onBlur && onBlur('category')}
                  className={inputCls('category', 'appearance-none cursor-pointer pr-10')}>
                  {PRODUCT_CATEGORIES.map(cat => <option key={cat} value={cat}>{cat}</option>)}
                </select>
                <div className="pointer-events-none absolute right-4 top-1/2 -translate-y-1/2 text-gray-400">
                  <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" /></svg>
                </div>
              </div>
            </Field>

            <Field label="Titre de l'annonce" required error={touched.title && errors.title ? errors.title : undefined}>
              <div className="space-y-1">
                <div className="relative">
                  <input type="text" required value={product.title}
                    onChange={(e) => handleManualChange('title', e.target.value)}
                    onBlur={() => onBlur && onBlur('title')}
                    placeholder="Ex: iPhone 15 Pro Max 256GB"
                    className={inputCls('title', 'pr-28')} />
                  <div className="absolute right-3 top-1/2 -translate-y-1/2"><AIActions field="title" /></div>
                </div>
                {product.title && <p className="text-[10px] text-gray-400 font-medium ml-1">{product.title.length} / 80 caractères</p>}
              </div>
            </Field>

            <label className="flex items-center gap-3 p-3.5 bg-amber-50 dark:bg-amber-500/5 border border-amber-200/50 dark:border-amber-500/10 rounded-xl cursor-pointer hover:bg-amber-100/50 transition-all">
              <input type="checkbox" id="is_hero" checked={!!product.is_hero} onChange={(e) => onChange('is_hero', e.target.checked)} className="w-4 h-4 accent-amber-500 rounded" />
              <div>
                <p className="text-[12px] font-black text-gray-900 dark:text-white">⭐ Produit Vedette (Hero)</p>
                <p className="text-[10px] text-gray-400 font-medium">Affiché en priorité sur votre page boutique</p>
              </div>
            </label>
          </div>
        </SectionCard>

        {/* ── SECTION 2: CONTENU MARKETING ────────────────────────────────── */}
        <SectionCard>
          <SectionHeader icon={FileText} title="Contenu Marketing" step={2} />
          <div className="space-y-4">
            <Field label="Description" required error={touched.description && errors.description ? errors.description : undefined}>
              <div className="relative">
                <div className="absolute top-3 right-3 z-10 flex items-center gap-1.5">
                  <AIActions field="description" />
                  <button type="button"
                    onClick={() => { setPreAiState({ ...product }); onGenerateAI(); setTimeout(() => { const nm = new Set(aiModifiedFields); nm.add('description'); setAiModifiedFields(nm); }, 500); }}
                    disabled={isGeneratingAI}
                    className="flex items-center gap-1 px-2.5 py-1 bg-[#ff6600]/10 text-[#ff6600] rounded-full text-[9px] font-black uppercase tracking-wider hover:bg-[#ff6600] hover:text-white transition-all border border-[#ff6600]/20">
                    {isGeneratingAI ? <Loader2 className="w-3 h-3 animate-spin" /> : <Sparkles className="w-3 h-3" />} IA
                  </button>
                </div>
                <textarea required value={product.description}
                  onChange={(e) => handleManualChange('description', e.target.value)}
                  onBlur={() => onBlur && onBlur('description')}
                  placeholder="Décrivez votre produit pour séduire vos clients..."
                  className={`${inputCls('description')} min-h-[150px] resize-none pt-10`} />
              </div>
            </Field>

            <Field label="Description Courte (SEO)">
              <div className="relative">
                <div className="absolute top-3 right-3 z-10">
                  <button type="button"
                    onClick={async () => {
                      if (!product.title) { showToast("Saisissez d'abord un titre.", 'info'); return; }
                      setIsGenLoading(true);
                      try {
                        const seo = await generateSEOContent(product.title, product.description);
                        if (seo) { setPreAiState({ ...product }); onChange('seo_description', seo); const nm = new Set(aiModifiedFields); nm.add('seo_description'); setAiModifiedFields(nm); showToast("SEO optimisé par l'IA", 'success'); hapticFeedback('success'); }
                      } catch { showToast('Erreur SEO', 'error'); } finally { setIsGenLoading(false); }
                    }}
                    disabled={isGenLoading}
                    className="flex items-center gap-1 px-2.5 py-1 bg-blue-500/10 text-blue-500 rounded-full text-[9px] font-black uppercase tracking-wider hover:bg-blue-500 hover:text-white transition-all border border-blue-500/20">
                    {isGenLoading ? <Loader2 className="w-3 h-3 animate-spin" /> : <Sparkles className="w-3 h-3" />} SEO IA
                  </button>
                </div>
                <textarea value={product.seo_description || ''}
                  onChange={(e) => handleManualChange('seo_description', e.target.value)}
                  placeholder="Résumé en 150 caractères pour les moteurs de recherche..."
                  className={`${inputCls('seo_description')} min-h-[90px] resize-none pt-10`} />
              </div>
            </Field>

            <SEOTracker title={product.title || ''} description={product.description || ''} />
          </div>
        </SectionCard>

        {/* ── SECTION 3: PRIX & STOCK ──────────────────────────────────────── */}
        <SectionCard>
          <SectionHeader icon={Coins} title="Prix & Stock" step={3} />
          <div className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {/* ── Selling price ── */}
              <Field label="Prix de Vente (GNF)" required error={touched.price_gnf && errors.price_gnf ? errors.price_gnf : undefined}>
                <div className="relative">
                  <input
                    type="text"
                    inputMode="numeric"
                    required
                    value={product.price_gnf !== undefined && product.price_gnf !== '' ? product.price_gnf.toString().replace(/\D/g, '').replace(/\B(?=(\d{3})+(?!\d))/g, ' ') : ''}
                    onChange={(e) => handleManualChange('price_gnf', e.target.value.replace(/\D/g, ''))}
                    onBlur={() => onBlur && onBlur('price_gnf')}
                    placeholder="0"
                    className={inputCls('price_gnf', 'pr-36 text-[16px] sm:text-[18px] font-black tabular-nums')}
                  />
                  {/* GNF label + Optimiser pill — absolutely positioned inside input */}
                  <div className="absolute right-3 top-1/2 -translate-y-1/2 flex items-center gap-1.5 select-none">
                    <AIActions field="price_gnf" />
                    <button
                      type="button"
                      onClick={async () => {
                        if (!product.title) { showToast("Saisissez d'abord un titre.", 'info'); return; }
                        setIsPricingLoading(true);
                        const insight = await getAIDynamicPricing(product.title, 'Général', parseInt(product.price_gnf) || 0, parseInt(product.stock_quantity) || 0);
                        setPricingInsight(insight); setIsPricingLoading(false); hapticFeedback('bloom');
                      }}
                      disabled={isPricingLoading}
                      className="flex items-center gap-1 px-2.5 py-1 bg-[#ff6600]/10 text-[#ff6600] rounded-lg text-[9px] font-black uppercase tracking-wider hover:bg-[#ff6600] hover:text-white transition-all border border-[#ff6600]/20 shrink-0 cursor-pointer shadow-xs"
                      title="Suggérer un prix avec l'IA"
                    >
                      {isPricingLoading ? <Loader2 className="w-2.5 h-2.5 animate-spin" /> : <Sparkles className="w-2.5 h-2.5 text-[#ff6600]" />} IA
                    </button>
                    <span className="text-[11px] font-black text-gray-400 dark:text-gray-500 uppercase tracking-wider shrink-0 px-1">GNF</span>
                  </div>
                </div>
              </Field>

              {/* ── Buying price ── */}
              <Field label="Prix d'Achat (Privé)" hint="Optionnel — pour le calcul de marge">
                <div className="relative">
                  <input
                    type="text"
                    inputMode="numeric"
                    value={product.buying_price_gnf !== undefined && product.buying_price_gnf !== '' ? product.buying_price_gnf.toString().replace(/\D/g, '').replace(/\B(?=(\d{3})+(?!\d))/g, ' ') : ''}
                    onChange={(e) => onChange('buying_price_gnf', e.target.value.replace(/\D/g, ''))}
                    onBlur={() => onBlur && onBlur('buying_price_gnf')}
                    placeholder="Secret"
                    className={`${inputCls('buying_price_gnf', 'pr-16 text-[16px] sm:text-[18px] font-black tabular-nums')} focus:border-emerald-500`}
                  />
                  <span className="absolute right-4 top-1/2 -translate-y-1/2 text-[11px] font-black text-gray-400 dark:text-gray-500 uppercase tracking-wider select-none">GNF</span>
                </div>
              </Field>
            </div>

            {/* AI Pricing Card */}
            <AnimatePresence>
              {pricingInsight && (
                <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }} exit={{ opacity: 0, height: 0 }} className="overflow-hidden">
                  <div className="bg-gradient-to-br from-[#ff6600]/8 to-transparent border border-[#ff6600]/20 rounded-2xl p-5 space-y-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <TrendingUp className={`w-4 h-4 ${pricingInsight.marketTrend === 'rising' ? 'text-emerald-500' : 'text-blue-500'}`} />
                        <span className="text-[10px] font-black text-gray-900 dark:text-white uppercase tracking-widest italic">Suggéré par IA {APP_NAME}</span>
                      </div>
                      <button onClick={() => setPricingInsight(null)} aria-label="Fermer les suggestions IA" className="text-gray-400 hover:text-gray-600 dark:hover:text-white transition-colors"><X className="w-3.5 h-3.5" /></button>
                    </div>
                    <div className="flex items-end justify-between border-b border-gray-100 dark:border-white/5 pb-4">
                      <div>
                        <p className="text-[9px] font-black uppercase text-gray-400 mb-1 tracking-widest">Prix Optimal</p>
                        <p className="text-[22px] font-black text-[#ff6600] leading-none italic">{pricingInsight.suggestedPrice.toLocaleString()} <span className="text-[12px]">GNF</span></p>
                      </div>
                      <button type="button"
                        onClick={() => { setPreAiState({ ...product }); onChange('price_gnf', pricingInsight.suggestedPrice.toString()); const nm = new Set(aiModifiedFields); nm.add('price_gnf'); setAiModifiedFields(nm); hapticFeedback('success'); }}
                        className="bg-[#ff6600] text-white px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest hover:scale-105 transition-all shadow-lg shadow-[#ff6600]/20">
                        Appliquer
                      </button>
                    </div>
                    <ul className="space-y-1.5">
                      {pricingInsight.reasoning.map((reason, idx) => (
                        <li key={idx} className="text-[10px] text-gray-400 font-bold flex items-start gap-2">
                          <div className="w-1 h-1 rounded-full bg-[#ff6600] mt-1.5 shrink-0" />{reason}
                        </li>
                      ))}
                    </ul>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>

            {/* Margin Calculator */}
            {product.price_gnf && parseInt(product.price_gnf) > 0 && (
              <div className="bg-gradient-to-br from-gray-900 to-black rounded-2xl p-5 sm:p-7 border border-white/5 shadow-2xl relative overflow-hidden">
                <div className="relative z-10">
                  <p className="text-[9px] font-black text-gray-500 uppercase tracking-[0.4em] mb-2 italic">Simulation Revenu {APP_NAME}</p>
                  <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
                    <div>
                      <h4 className="text-3xl sm:text-4xl font-black text-white italic tracking-tighter tabular-nums">
                        {Math.max(0, parseInt(product.price_gnf) - (parseInt(product.buying_price_gnf || '0') || 0) - Math.floor(parseInt(product.price_gnf) * 0.075 + 500)).toLocaleString()}
                        <span className="text-sm font-black text-[#ff6600] ml-2">GNF</span>
                      </h4>
                      <div className="flex flex-wrap items-center gap-2 mt-2">
                        <span className="text-[10px] font-bold text-emerald-400 uppercase tracking-wider flex items-center gap-1.5 bg-emerald-400/10 px-3 py-1 rounded-full border border-emerald-400/20">
                          <TrendingUp className="w-3 h-3" />
                          Marge: {product.buying_price_gnf ? Math.round(((parseInt(product.price_gnf) - parseInt(product.buying_price_gnf) - (parseInt(product.price_gnf) * 0.075 + 500)) / parseInt(product.price_gnf)) * 100) : 0}%
                        </span>
                        <span className="text-[10px] font-bold text-blue-400 uppercase tracking-wider bg-blue-400/10 px-3 py-1 rounded-full border border-blue-400/20">
                          ROI: {product.buying_price_gnf && parseInt(product.buying_price_gnf) > 0 ? Math.round(((parseInt(product.price_gnf) - parseInt(product.buying_price_gnf) - (parseInt(product.price_gnf) * 0.075 + 500)) / parseInt(product.buying_price_gnf)) * 100) : 0}%
                        </span>
                      </div>
                    </div>
                    <div className="flex-1 sm:max-w-[260px] space-y-2">
                      <div className="flex justify-between text-[9px] font-black uppercase tracking-widest text-gray-500">
                        <span className="flex items-center gap-1">Frais {APP_NAME} <ShieldCheck className="w-3 h-3 text-[#ff6600]" /></span>
                        <span className="text-rose-400">-{Math.floor(parseInt(product.price_gnf) * 0.075 + 500).toLocaleString()} GNF</span>
                      </div>
                      <div className="h-2 w-full bg-white/5 rounded-full overflow-hidden">
                        <motion.div initial={{ width: 0 }} animate={{ width: '7.5%' }} transition={{ duration: 1.5, delay: 0.3 }} className="h-full bg-gradient-to-r from-[#ff6600] to-orange-400" />
                      </div>
                      <p className="text-right text-[9px] font-bold text-gray-600 uppercase italic">Commission 7.5% + frais fixe</p>
                    </div>
                  </div>
                </div>
                <div className="absolute -bottom-16 -right-16 w-48 h-48 bg-[#ff6600]/10 blur-[80px]" />
                <div className="absolute top-0 right-0 p-6 opacity-5"><Target className="w-32 h-32 text-white" /></div>
              </div>
            )}

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <Field label="Unités en stock" required error={touched.stock_quantity && errors.stock_quantity ? errors.stock_quantity : undefined}>
                <div className="relative">
                  <input type="number" required disabled={hasVariants} min="1"
                    value={hasVariants ? totalVariantStock : product.stock_quantity}
                    onChange={(e) => handleManualChange('stock_quantity', e.target.value)}
                    onBlur={() => onBlur && onBlur('stock_quantity')}
                    placeholder="Stock"
                    className={`${inputCls('stock_quantity')} ${hasVariants ? 'opacity-60 cursor-not-allowed' : ''} pr-24`} />
                  {hasVariants && <span className="absolute right-3 top-1/2 -translate-y-1/2 text-[9px] font-black text-[#ff6600] bg-[#ff6600]/10 px-2 py-0.5 rounded-full">Via variantes</span>}
                  {!hasVariants && <div className="absolute right-3 top-1/2 -translate-y-1/2"><AIActions field="stock_quantity" /></div>}
                </div>
              </Field>

              <Field label="Alerte stock minimum" hint="Notification envoyée en dessous de ce seuil">
                <input type="number" min="0" value={product.low_stock_threshold || ''}
                  onChange={(e) => onChange('low_stock_threshold', e.target.value)}
                  placeholder="Ex: 5" className={inputCls('low_stock_threshold')} />
              </Field>
            </div>
          </div>
        </SectionCard>

        {/* ── SECTION 4: MÉDIAS ───────────────────────────────────────────── */}
        <SectionCard>
          <SectionHeader icon={ImageIcon} title="Médias Produit" step={4} />

          <div
            onDrop={handleDrop} onDragOver={handleDragOver} onDragLeave={handleDragLeave}
            onClick={() => imageUrls.length === 0 && fileInputRef.current?.click()}
            className={`relative rounded-2xl border-2 border-dashed transition-all duration-300 ${
              isDragging ? 'border-[#ff6600] bg-[#ff6600]/5 scale-[1.01]'
              : imageUrls.length > 0 ? 'border-gray-200 dark:border-white/8 bg-gray-50/50 dark:bg-white/2'
              : 'border-gray-300 dark:border-white/10 bg-gray-50 dark:bg-gray-800/50 cursor-pointer hover:border-[#ff6600] hover:bg-[#ff6600]/2'
            }`}
          >
            {imageUrls.length > 0 ? (
              <div className="p-4 space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-black text-gray-500 uppercase tracking-widest">{imageUrls.length}/5 photos</span>
                  {imageUrls.length < 5 && (
                    <button type="button" onClick={() => fileInputRef.current?.click()}
                      className="flex items-center gap-1.5 px-3 py-1.5 bg-[#ff6600] text-white rounded-lg text-[10px] font-black hover:opacity-90 transition-all">
                      <Plus className="w-3.5 h-3.5" /> Ajouter
                    </button>
                  )}
                </div>
                <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 gap-2.5">
                  {imageUrls.map((url, idx) => {
                    const isMain = product.image_url === url;
                    return (
                      <motion.div key={url} initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }}
                        className={`relative aspect-square rounded-xl overflow-hidden group/img border-2 transition-all ${isMain ? 'border-[#ff6600] ring-2 ring-[#ff6600]/20' : 'border-transparent hover:border-gray-300 dark:hover:border-white/20'}`}>
                        <img src={url} alt={`Photo ${idx + 1}`} className="w-full h-full object-cover" />
                        {isMain && <div className="absolute top-1 left-1 bg-[#ff6600] text-white text-[7px] font-black px-1.5 py-0.5 rounded-full uppercase tracking-widest">★ Principal</div>}
                        <div className="absolute inset-0 bg-black/50 opacity-0 group-hover/img:opacity-100 transition-opacity flex flex-col items-center justify-center gap-1.5 p-1">
                          {!isMain && (
                            <button type="button" onClick={() => { onChange('image_url', url); hapticFeedback('success'); }}
                              className="w-full px-1.5 py-1 bg-white text-gray-900 rounded text-[8px] font-black uppercase hover:scale-105 transition-all">
                              Principal
                            </button>
                          )}
                          <button type="button" onClick={() => removeImage(idx)} aria-label="Retirer cette image"
                            className="w-8 h-8 bg-red-500 text-white rounded-lg flex items-center justify-center hover:scale-110 transition-transform">
                            <X className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </motion.div>
                    );
                  })}
                  {imageUrls.length < 5 && (
                    <button type="button" onClick={() => fileInputRef.current?.click()}
                      className="aspect-square border-2 border-dashed border-gray-300 dark:border-white/10 rounded-xl flex flex-col items-center justify-center gap-1 hover:border-[#ff6600] hover:bg-[#ff6600]/5 transition-all text-gray-400 hover:text-[#ff6600]">
                      {isUploading ? <Loader2 className="w-5 h-5 animate-spin text-[#ff6600]" /> : <Plus className="w-5 h-5" />}
                      <span className="text-[8px] font-black uppercase">Ajouter</span>
                    </button>
                  )}
                </div>
                <button type="button"
                  onClick={() => { setIsCleaningImage(true); setTimeout(() => { setIsCleaningImage(false); showToast("Nettoyage IA appliqué.", 'success'); }, 1500); }}
                  disabled={isCleaningImage}
                  aria-label="Nettoyer l'image avec IA"
                  className="w-full flex items-center justify-center gap-2 py-2.5 bg-white dark:bg-white/5 border border-gray-200 dark:border-white/8 rounded-xl text-[11px] font-black text-gray-700 dark:text-gray-300 hover:border-[#ff6600] hover:text-[#ff6600] transition-all">
                  {isCleaningImage ? <Loader2 className="w-4 h-4 animate-spin" /> : <Wand2 className="w-4 h-4 text-[#ff6600]" />}
                  Magie Visuelle IA — Nettoyage automatique
                </button>
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center py-12 px-6 text-center">
                <div className={`w-16 h-16 rounded-2xl flex items-center justify-center mb-4 transition-all ${isDragging ? 'bg-[#ff6600] text-white scale-110' : isUploading ? 'bg-[#ff6600]/10 text-[#ff6600]' : 'bg-white dark:bg-white/10 text-[#ff6600] shadow-md'}`}>
                  {isUploading ? <Loader2 className="w-8 h-8 animate-spin" /> : <Upload className="w-8 h-8" />}
                </div>
                <p className="text-[14px] font-black text-gray-900 dark:text-white uppercase tracking-tight mb-1">
                  {isDragging ? 'Déposez ici !' : 'Télécharger les photos'}
                </p>
                <p className="text-[11px] font-bold text-gray-400 tracking-wide">Glissez-déposez ou cliquez · Max 5 photos · 5 Mo chacune</p>
              </div>
            )}
            {isUploading && imageUrls.length === 0 && (
              <div className="absolute inset-0 bg-white/80 dark:bg-black/80 rounded-2xl flex items-center justify-center">
                <div className="flex flex-col items-center gap-3">
                  <Loader2 className="w-8 h-8 text-[#ff6600] animate-spin" />
                  <p className="text-[11px] font-black text-gray-500 uppercase tracking-widest">Téléchargement...</p>
                </div>
              </div>
            )}
          </div>

          {uploadError && (
            <div className="flex items-start gap-2 p-4 bg-red-50 dark:bg-red-500/8 border border-red-200 dark:border-red-500/20 rounded-xl mt-3">
              <AlertCircle className="w-4 h-4 text-red-500 shrink-0 mt-0.5" />
              <p className="text-[11px] font-bold text-red-600 dark:text-red-400 leading-relaxed">{uploadError}</p>
            </div>
          )}

          <details className="group mt-4">
            <summary className="text-[10px] font-black text-gray-400 uppercase tracking-widest cursor-pointer hover:text-[#ff6600] transition-colors flex items-center gap-2 list-none select-none">
              <div className="h-px bg-gray-100 dark:bg-white/5 flex-1" />
              Utiliser un lien URL
              <div className="h-px bg-gray-100 dark:bg-white/5 flex-1" />
            </summary>
            <div className="pt-3">
              <input type="url" value={product.image_url} onChange={(e) => onChange('image_url', e.target.value)}
                placeholder="https://exemple.com/image.jpg" className={inputCls('image_url')} />
            </div>
          </details>

          <input type="file" ref={fileInputRef} onChange={handleImageUpload} accept="image/png,image/jpeg,image/webp" multiple className="hidden" />
        </SectionCard>

        {/* ── SECTION 5: OPTIONS & VARIANTES ──────────────────────────────── */}
        <SectionCard>
          <SectionHeader icon={Settings} title="Options & Variantes" step={5} />
          <div className="space-y-6">
            <div>
              <div className="flex items-center justify-between mb-3">
                <p className="text-[11px] font-black text-gray-500 dark:text-gray-400 uppercase tracking-widest">Variantes</p>
                <div className="flex flex-wrap gap-2">
                  <button type="button" onClick={() => addVariantPreset('size')}
                    className="px-2.5 py-1 bg-blue-50 dark:bg-blue-900/20 text-blue-600 dark:text-blue-400 text-[9px] font-black rounded-full uppercase tracking-widest hover:bg-blue-600 hover:text-white transition-all">
                    + Tailles
                  </button>
                  <button type="button" onClick={() => addVariantPreset('color')}
                    className="px-2.5 py-1 bg-emerald-50 dark:bg-emerald-900/20 text-emerald-600 dark:text-emerald-400 text-[9px] font-black rounded-full uppercase tracking-widest hover:bg-emerald-600 hover:text-white transition-all">
                    + Couleurs
                  </button>
                  <button type="button"
                    onClick={() => onChange('variants', [...(product.variants || []), { id: Date.now().toString(), size: '', color: '', stock_count: 0, price_override: null }])}
                    className="flex items-center gap-1 px-2.5 py-1 bg-[#ff6600] text-white text-[9px] font-black rounded-full uppercase tracking-widest hover:bg-[#e62e00] transition-all">
                    <Plus className="w-3 h-3" /> Ajouter
                  </button>
                </div>
              </div>

              {product.variants && product.variants.length > 0 && (
                <div className="space-y-2">
                  {/* Desktop table */}
                  <div className="hidden sm:block bg-gray-50 dark:bg-gray-800/50 rounded-2xl overflow-hidden border border-gray-100 dark:border-white/5">
                    <div className="grid grid-cols-[1fr_1fr_80px_110px_36px] text-[9px] font-black text-gray-400 uppercase tracking-widest px-4 py-2.5 border-b border-gray-100 dark:border-white/5">
                      <span>Taille</span><span>Couleur</span><span>Stock</span><span>Prix +</span><span />
                    </div>
                    {product.variants.map((variant, index) => (
                      <div key={variant.id} className="grid grid-cols-[1fr_1fr_80px_110px_36px] items-center px-4 py-2.5 border-b border-gray-100 dark:border-white/5 last:border-0 hover:bg-white/50 dark:hover:bg-white/2 transition-all gap-2">
                        <input type="text" value={variant.size} onChange={(e) => { const nv = [...product.variants]; nv[index].size = e.target.value; onChange('variants', nv); }} placeholder="Ex: XL"
                          className="w-full bg-white dark:bg-gray-900 border border-gray-200 dark:border-white/10 rounded-lg px-2.5 py-1.5 text-[12px] font-bold focus:border-[#ff6600] outline-none text-gray-900 dark:text-white" />
                        <input type="text" value={variant.color} onChange={(e) => { const nv = [...product.variants]; nv[index].color = e.target.value; onChange('variants', nv); }} placeholder="Ex: Rouge"
                          className="w-full bg-white dark:bg-gray-900 border border-gray-200 dark:border-white/10 rounded-lg px-2.5 py-1.5 text-[12px] font-bold focus:border-[#ff6600] outline-none text-gray-900 dark:text-white" />
                        <input type="number" min="0" value={variant.stock_count} onChange={(e) => { const nv = [...product.variants]; nv[index].stock_count = parseInt(e.target.value) || 0; onChange('variants', nv); }}
                          className="w-full bg-white dark:bg-gray-900 border border-gray-200 dark:border-white/10 rounded-lg px-2.5 py-1.5 text-[12px] font-bold focus:border-[#ff6600] outline-none text-gray-900 dark:text-white" />
                        <input type="number" min="0" value={variant.price_override || ''} onChange={(e) => { const nv = [...product.variants]; nv[index].price_override = e.target.value ? parseInt(e.target.value) : null; onChange('variants', nv); }} placeholder="+0 GNF"
                          className="w-full bg-white dark:bg-gray-900 border border-gray-200 dark:border-white/10 rounded-lg px-2.5 py-1.5 text-[12px] font-bold focus:border-[#ff6600] outline-none text-gray-900 dark:text-white" />
                        <button type="button" onClick={() => onChange('variants', product.variants.filter(v => v.id !== variant.id))}
                          className="p-1.5 text-gray-400 hover:text-red-500 hover:bg-red-50 dark:hover:bg-red-500/10 rounded-lg transition-all">
                          <X className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    ))}
                  </div>

                  {/* Mobile card layout */}
                  <div className="sm:hidden space-y-2">
                    {product.variants.map((variant, index) => (
                      <div key={variant.id} className="bg-gray-50 dark:bg-gray-800/50 rounded-xl p-4 border border-gray-100 dark:border-white/5">
                        <div className="flex items-center justify-between mb-3">
                          <span className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Variante {index + 1}</span>
                          <button type="button" onClick={() => onChange('variants', product.variants.filter(v => v.id !== variant.id))}
                            className="p-1.5 text-gray-400 hover:text-red-500 hover:bg-red-50 dark:hover:bg-red-500/10 rounded-lg transition-all">
                            <X className="w-4 h-4" />
                          </button>
                        </div>
                        <div className="grid grid-cols-2 gap-2">
                          {[['Taille', 'size', 'text', 'Ex: XL'], ['Couleur', 'color', 'text', 'Ex: Rouge'], ['Stock', 'stock_count', 'number', '0'], ['Prix +', 'price_override', 'number', '+0 GNF']].map(([lbl, key, type, ph]) => (
                            <div key={key as string}>
                              <label className="text-[9px] font-black text-gray-400 uppercase tracking-widest mb-1 block">{lbl}</label>
                              <input type={type as string}
                                value={key === 'price_override' ? (variant.price_override || '') : (variant as any)[key]}
                                onChange={(e) => { const nv = [...product.variants]; if (key === 'stock_count') (nv[index] as any)[key] = parseInt(e.target.value) || 0; else if (key === 'price_override') (nv[index] as any)[key] = e.target.value ? parseInt(e.target.value) : null; else (nv[index] as any)[key] = e.target.value; onChange('variants', nv); }}
                                placeholder={ph as string} min={type === 'number' ? '0' : undefined}
                                className="w-full bg-white dark:bg-gray-900 border border-gray-200 dark:border-white/10 rounded-lg px-3 py-2 text-[12px] font-bold focus:border-[#ff6600] outline-none text-gray-900 dark:text-white" />
                            </div>
                          ))}
                        </div>
                      </div>
                    ))}
                  </div>

                  {hasVariants && (
                    <div className="flex items-center gap-2 px-3 py-2 bg-[#ff6600]/5 border border-[#ff6600]/15 rounded-xl">
                      <Package className="w-3.5 h-3.5 text-[#ff6600]" />
                      <p className="text-[10px] font-black text-[#ff6600]">Stock total via variantes: {totalVariantStock} unités</p>
                    </div>
                  )}
                </div>
              )}
            </div>

            {/* Digital product */}
            <div className="p-4 sm:p-5 rounded-2xl border border-gray-100 dark:border-white/5 bg-gray-50 dark:bg-gray-800/30 hover:bg-gray-100/50 dark:hover:bg-white/3 transition-colors">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-xl bg-blue-500/10 flex items-center justify-center text-blue-500"><Download className="w-4 h-4" /></div>
                  <div>
                    <p className="text-[13px] font-black text-gray-900 dark:text-white">Produit Numérique</p>
                    <p className="text-[10px] text-gray-400 font-medium">PDF, Software, Fichier téléchargeable</p>
                  </div>
                </div>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input type="checkbox" className="sr-only peer" checked={product.is_digital} onChange={(e) => onChange('is_digital', e.target.checked)} />
                  <div className="w-12 h-6 bg-gray-200 dark:bg-white/10 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[3px] after:left-[3px] after:bg-white after:border after:rounded-full after:h-[18px] after:w-[18px] after:transition-all peer-checked:bg-[#ff6600]" />
                </label>
              </div>
              {product.is_digital && (
                <motion.div initial={{ opacity: 0, y: -6 }} animate={{ opacity: 1, y: 0 }} className="mt-4 pt-4 border-t border-gray-200 dark:border-white/5">
                  <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest block mb-2">Lien de téléchargement</label>
                  <input type="url" value={product.download_url || ''} onChange={(e) => onChange('download_url', e.target.value)}
                    placeholder="https://drive.google.com/..." className={inputCls('download_url')} />
                </motion.div>
              )}
            </div>

            <VolumePricing
              qty={product.volume_discount_qty || ''}
              percent={product.volume_discount_percent || ''}
              onChangeQty={(v) => onChange('volume_discount_qty', v)}
              onChangePercent={(v) => onChange('volume_discount_percent', v)}
            />
          </div>
        </SectionCard>

        {/* ── SECTION 6: PUBLICATION ──────────────────────────────────────── */}
        <SectionCard>
          <SectionHeader icon={Layers} title="Publication" step={6} />
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <Field label="Statut">
              <div className="relative">
                <select value={product.status || 'published'} onChange={(e) => onChange('status', e.target.value)}
                  className={inputCls('status', 'appearance-none cursor-pointer pr-10')}>
                  <option value="published">✅ Publié</option>
                  <option value="draft">📝 Brouillon</option>
                  <option value="scheduled">🕐 Planifié</option>
                </select>
                <div className="pointer-events-none absolute right-4 top-1/2 -translate-y-1/2 text-gray-400">
                  <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" /></svg>
                </div>
              </div>
            </Field>

            {product.status === 'scheduled' && (
              <Field label="Date & Heure de publication">
                <div className="relative">
                  <input type="datetime-local" value={product.scheduled_at?.slice(0, 16) || ''}
                    onChange={(e) => onChange('scheduled_at', e.target.value)} className={inputCls('scheduled_at')} />
                  <Calendar className="absolute right-4 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400 pointer-events-none" />
                </div>
              </Field>
            )}
          </div>

          {/* Desktop submit — hidden on mobile (sticky bar handles it) */}
          <div className="hidden sm:flex gap-4 mt-6">
            {onSaveAsDraft && (
              <button type="button" onClick={onSaveAsDraft} disabled={isSaving}
                className="flex-1 bg-gray-100 dark:bg-white/5 text-gray-700 dark:text-gray-300 border border-gray-200 dark:border-white/8 py-4 rounded-2xl text-[12px] font-black tracking-wider hover:bg-gray-200 dark:hover:bg-white/10 transition-all disabled:opacity-50">
                Sauver Brouillon
              </button>
            )}
            <button type="submit" disabled={isSaving}
              className={`${onSaveAsDraft ? 'flex-[2]' : 'w-full'} bg-gray-900 dark:bg-white text-white dark:text-gray-900 py-4 rounded-2xl text-[12px] font-black tracking-wider hover:bg-[#ff6600] hover:text-white dark:hover:bg-[#ff6600] dark:hover:text-white transition-all disabled:opacity-50 flex items-center justify-center gap-2`}>
              {isSaving ? (
                <><Loader2 className="w-4 h-4 animate-spin" /> Publication...</>
              ) : product.status === 'scheduled' ? (
                <><Calendar className="w-4 h-4" /> Planifier le produit</>
              ) : (
                <><Sparkles className="w-4 h-4" /> Publier le produit</>
              )}
            </button>
          </div>
        </SectionCard>
      </form>

      {/* ── STICKY MOBILE SUBMIT BAR ─────────────────────────────────────── */}
      <div className="sm:hidden fixed bottom-0 left-0 right-0 z-50 bg-white/95 dark:bg-[#1A1D21]/95 backdrop-blur-xl border-t border-gray-100 dark:border-white/8 px-4 py-3">
        <div className="flex gap-3">
          {onSaveAsDraft && (
            <button type="button" onClick={onSaveAsDraft} disabled={isSaving}
              className="flex-1 bg-gray-100 dark:bg-white/10 text-gray-700 dark:text-gray-200 py-3.5 rounded-2xl text-[11px] font-black tracking-wider hover:bg-gray-200 transition-all disabled:opacity-50 active:scale-[0.98]">
              Brouillon
            </button>
          )}
          <button type="submit" form="product-form" disabled={isSaving}
            className={`${onSaveAsDraft ? 'flex-[2]' : 'w-full'} bg-gray-900 text-white py-3.5 rounded-2xl text-[11px] font-black tracking-wider hover:bg-[#ff6600] transition-all disabled:opacity-50 active:scale-[0.98] flex items-center justify-center gap-2 shadow-lg shadow-black/20`}>
            {isSaving ? (
              <><Loader2 className="w-4 h-4 animate-spin" /> Publication...</>
            ) : product.status === 'scheduled' ? '🕐 Planifier' : '🚀 Publier'}
          </button>
        </div>
      </div>
    </>
  );
}
