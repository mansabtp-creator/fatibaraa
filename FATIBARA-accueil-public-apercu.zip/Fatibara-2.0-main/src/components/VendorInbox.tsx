import React, { useState, useEffect, useRef, useMemo } from 'react';
import { supabase } from '../lib/supabase';
import { realtimeKey } from '../lib/realtimeKeys';
import { useToast } from '../context/ToastContext';
import { Search, Send, CheckCheck, User, Loader2, ArrowLeft, Settings, Smartphone, MessageSquare, X, Share2 } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Skeleton } from './ui/Skeleton';
import { APP_NAME } from '../lib/constants';

// Hoisted outside component so the array is not re-created on every render
const QUICK_REPLIES = [
  "Bonjour ! Comment puis-je vous aider ?",
  "Oui, cet article est disponible.",
  `C'est notre meilleur prix (promo ${APP_NAME}).`,
  "On peut livrer dès demain.",
  "Quel quartier pour la livraison ?",
  "Je vous fais un prix spécial !"
];

interface Channel {
  id: string;
  store_id: string;
  buyer_id: string;
  last_message: string;
  last_message_at: string;
  product_id?: string;
  buyer_profile?: {
    full_name: string;
    avatar_url: string;
  };
  product?: {
    title: string;
    image_urls: string[];
    price_gnf: number;
    price_original?: never; // column does not exist in products table
  };
}

interface Message {
  id: string;
  channel_id: string;
  sender_id: string;
  message: string;
  is_read: boolean;
  metadata?: any;
  image_url?: string;
  created_at: string;
}

export function VendorInbox({ storeId, currentUserId }: { storeId: string; currentUserId: string }) {
  const [channels, setChannels] = useState<Channel[]>([]);
  const [activeChannel, setActiveChannel] = useState<Channel | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [newMessage, setNewMessage] = useState('');
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [showSettings, setShowSettings] = useState(false);
  const [storeSettings, setStoreSettings] = useState({
    auto_reply_enabled: false,
    auto_reply_message: '',
    whatsapp_sync_enabled: false
  });
  const [savingSettings, setSavingSettings] = useState(false);
  const [showOfferInput, setShowOfferInput] = useState(false);
  const [offerPrice, setOfferPrice] = useState('');
  const [uploading, setUploading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const { showToast } = useToast();
  // AbortController-style mount guard: prevents stale setState calls after
  // unmount or storeId change (e.g. user navigates away mid-fetch).
  const isMountedRef = useRef(true);
  // Fix #5: ref always points to current activeChannel so realtime callback
  // never reads a stale closure value after the vendor switches conversations.
  const activeChannelRef = useRef<Channel | null>(null);
  // Pagination + presence
  const [hasMoreMessages, setHasMoreMessages] = useState(false);
  const [loadingMore, setLoadingMore] = useState(false);
  const [isOtherPartyOnline, setIsOtherPartyOnline] = useState(false);
  const presenceChannelRef = useRef<any>(null);

  useEffect(() => {
    isMountedRef.current = true;
    return () => { isMountedRef.current = false; };
  }, []);

  useEffect(() => {
    fetchChannels();
    fetchStoreSettings();
    // Fix 7: return the cleanup so the channel is unsubscribed on unmount / storeId change
    const cleanup = subscribeToNewMessages();
    return cleanup;
  }, [storeId]);

  const fetchStoreSettings = async () => {
    try {
      const { data, error } = await supabase
        .from('stores')
        .select('auto_reply_enabled, auto_reply_message, whatsapp_sync_enabled')
        .eq('id', storeId)
        .single();

      if (!error && data && isMountedRef.current) {
        setStoreSettings(data);
      }
    } catch (err) {
      if (isMountedRef.current) console.error(err);
    }
  };

  const handleUpdateSettings = async (updates: any) => {
    setSavingSettings(true);
    try {
      const { error } = await supabase
        .from('stores')
        .update(updates)
        .eq('id', storeId);
      
      if (error) throw error;
      setStoreSettings(prev => ({ ...prev, ...updates }));
      showToast("Paramètres mis à jour", "success");
    } catch (err) {
      showToast("Erreur de sauvegarde", "error");
    } finally {
      setSavingSettings(false);
    }
  };

  useEffect(() => {
    // Keep the ref in sync so the realtime callback always has the latest value
    activeChannelRef.current = activeChannel;
    if (activeChannel) {
      fetchMessages(activeChannel.id);
      if (isMountedRef.current) markAsRead(activeChannel.id);
    }
  }, [activeChannel]);

  // ── Per-active-channel real-time message subscription ─────────────────────
  // CRITICAL FIX: we must use a server-side filter (`channel_id=eq.${id}`)
  // so Supabase Realtime can validate the subscription against RLS.
  // Without this filter the subscription is silently rejected and no messages
  // arrive in real-time (the table just became part of the publication, but
  // RLS still blocks unfiltered broadcasts).
  useEffect(() => {
    if (!activeChannel) return;

    const msgChannel = supabase
      .channel(`vendor:msgs:${activeChannel.id}`)
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'chat_messages',
          filter: `channel_id=eq.${activeChannel.id}`,
        },
        (payload) => {
          const msg = payload.new as Message;
          if (!isMountedRef.current) return;

          // Deduplicate (optimistic insert may already have added it)
          setMessages(prev => {
            if (prev.some(m => m.id === msg.id)) return prev;
            return [...prev, msg];
          });

          // Update conversation list preview + unread count
          const preview = (msg.message || '📷').length > 80
            ? (msg.message || '📷').substring(0, 77) + '\u2026'
            : (msg.message || '📷');

          setChannels(prev => prev.map(c =>
            c.id === msg.channel_id
              ? {
                  ...c,
                  last_message_at: msg.created_at,
                  last_message: preview,
                  unread_count:
                    c.id === activeChannelRef.current?.id
                      ? 0
                      : ((c as any).unread_count || 0) + 1,
                }
              : c
          ));

          // Auto-mark as read since vendor is currently viewing this channel
          if (activeChannelRef.current?.id === msg.channel_id) {
            markAsRead(msg.channel_id);
          }
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(msgChannel);
    };
  }, [activeChannel?.id]);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);



  const fetchChannels = async () => {
    if (!isMountedRef.current) return;
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('chat_channels')
        .select(`
          *, 
          buyer_profile:buyer_id(full_name, avatar_url),
          product:product_id(title, image_urls, price_gnf)
        `)
        .eq('store_id', storeId)
        .order('last_message_at', { ascending: false });

      if (error) throw error;

      // Fix #7: single batch query instead of N+1 COUNT queries
      const channelIds = data.map(c => c.id);
      let unreadMap: Record<string, number> = {};
      if (channelIds.length > 0) {
        const { data: unreadRows } = await supabase
          .from('chat_messages')
          .select('channel_id')
          .in('channel_id', channelIds)
          .eq('is_read', false)
          .neq('sender_id', currentUserId);
        unreadRows?.forEach(row => {
          unreadMap[row.channel_id] = (unreadMap[row.channel_id] || 0) + 1;
        });
      }

      const mappedData = data.map(chat => ({
        ...chat,
        unread_count: unreadMap[chat.id] || 0
      }));

      if (isMountedRef.current) setChannels(mappedData as any);
    } catch (error) {
      if (isMountedRef.current) console.error('Error fetching channels:', error);
    } finally {
      if (isMountedRef.current) setLoading(false);
    }
  };

  const PAGE_SIZE = 50;

  const fetchMessages = async (channelId: string) => {
    try {
      const { data, error } = await supabase
        .from('chat_messages')
        .select('*')
        .eq('channel_id', channelId)
        .order('created_at', { ascending: false })
        .limit(PAGE_SIZE);

      if (error) throw error;
      if (isMountedRef.current) {
        const msgs = [...(data || [])].reverse();
        setMessages(msgs);
        setHasMoreMessages((data?.length || 0) === PAGE_SIZE);
      }
    } catch (error) {
      if (isMountedRef.current) console.error('Error fetching messages:', error);
    }
  };

  const loadMoreMessages = async () => {
    if (!activeChannel || messages.length === 0 || loadingMore) return;
    setLoadingMore(true);
    const oldest = messages[0].created_at;
    const { data } = await supabase
      .from('chat_messages')
      .select('*')
      .eq('channel_id', activeChannel.id)
      .lt('created_at', oldest)
      .order('created_at', { ascending: false })
      .limit(PAGE_SIZE);
    if (data && isMountedRef.current) {
      const older = [...data].reverse();
      setMessages(prev => [...older, ...prev]);
      setHasMoreMessages(data.length === PAGE_SIZE);
    }
    setLoadingMore(false);
  };

  const markAsRead = async (channelId: string) => {
    try {
      await supabase
        .from('chat_messages')
        .update({ is_read: true })
        .eq('channel_id', channelId)
        .neq('sender_id', currentUserId)
        .eq('is_read', false);
    } catch (error) {
      console.error('Error marking as read:', error);
    }
  };

  const subscribeToNewMessages = () => {
    // ── Channel B: new chat_channels (buyer starts a new conversation) ──────────
    // This subscription watches for new conversations arriving for this store.
    // We use store_id filter so it is properly scoped and passes RLS.
    const channelsChannel = supabase
      .channel(realtimeKey.storeInbox(storeId))
      .on('postgres_changes', {
        event: 'INSERT',
        schema: 'public',
        table: 'chat_channels',
        filter: `store_id=eq.${storeId}`
      }, () => {
        // Re-fetch so we get buyer_profile and product joins
        fetchChannels();
      })
      .subscribe();

    return () => {
      supabase.removeChannel(channelsChannel);
    };
  };

  const handleSendMessage = async (e: React.FormEvent, contentOverride?: string) => {
    e.preventDefault();
    const msgText = (contentOverride || newMessage).trim();
    if (!msgText || !activeChannel) return;

    if (!contentOverride) {
      setNewMessage('');
      if (textareaRef.current) {
        textareaRef.current.style.height = 'auto';
      }
    }

    try {
      const { data: insertedMsg, error } = await supabase
        .from('chat_messages')
        .insert({
          channel_id: activeChannel.id,
          sender_id: currentUserId,
          message: msgText
        })
        .select()
        .single();

      if (error) throw error;

      // Fix #20: persist last_message text so conversation preview is accurate
      const preview = msgText.length > 80 ? msgText.substring(0, 77) + '\u2026' : msgText;
      await supabase
        .from('chat_channels')
        .update({ 
          last_message_at: new Date().toISOString(),
          last_message: preview
        })
        .eq('id', activeChannel.id);

      // Optimistic local update of channel list preview
      setChannels(prev => prev.map(c =>
        c.id === activeChannel.id
          ? { ...c, last_message: preview, last_message_at: new Date().toISOString() }
          : c
      ));

    } catch (error) {
      showToast("Erreur lors de l'envoi du message", "error");
    }
  };

  const filteredChannels = channels.filter(c => 
    c.buyer_profile?.full_name?.toLowerCase().includes(search.toLowerCase())
  );

  const handleSendOffer = async () => {
    if (!activeChannel?.product || !offerPrice) return;
    const price = parseInt(offerPrice.replace(/\D/g, ''));
    if (isNaN(price)) return;
    
    const msgText = `Offre Spéciale ! Je vous propose cet article à ${price.toLocaleString()} GNF au lieu de ${activeChannel.product.price_gnf.toLocaleString()} GNF.`;
    
    try {
      const { data: msg, error } = await supabase
        .from('chat_messages')
        .insert([{
          channel_id: activeChannel.id,
          sender_id: currentUserId,
          message: msgText,
          metadata: { 
            type: 'offer', 
            productId: activeChannel.product_id, 
            price: price,
            originalPrice: activeChannel.product.price_gnf
          }
        }])
        .select()
        .single();

      if (error) throw error;
      
      await supabase
        .from('chat_channels')
        .update({ 
          last_message_at: new Date().toISOString(),
          last_message: `💰 Offre: ${offerPrice} GNF`
        })
        .eq('id', activeChannel.id);

      // Update local channel list preview
      setChannels(prev => prev.map(c =>
        c.id === activeChannel.id
          ? { ...c, last_message_at: new Date().toISOString(), last_message: `💰 Offre: ${offerPrice} GNF` }
          : c
      ));

      setMessages(prev => [...prev, msg]);
      setNewMessage("");
      setShowOfferInput(false);
      setOfferPrice("");
    } catch (err) {
      console.error(err);
      showToast("Erreur lors de l'envoi de l'offre", "error");
    }
  };

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !activeChannel) return;

    // Fix #10: validate file type and size before uploading
    const MAX_SIZE = 5 * 1024 * 1024; // 5 MB
    const ALLOWED_TYPES = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
    if (!ALLOWED_TYPES.includes(file.type)) {
      showToast('Format non supporté. Utilisez JPG, PNG, GIF ou WebP.', 'error');
      return;
    }
    if (file.size > MAX_SIZE) {
      showToast("L'image ne doit pas dépasser 5 Mo.", 'error');
      return;
    }

    setUploading(true);
    try {
      // Fix #8: use crypto.randomUUID() to prevent filename collisions
      const fileExt = file.name.split('.').pop()?.toLowerCase() || 'jpg';
      const fileName = `${currentUserId}/${crypto.randomUUID()}.${fileExt}`;
      const filePath = `chat_images/${fileName}`;

      const { error: uploadError } = await supabase.storage
        .from('chat-images')
        .upload(filePath, file);

      if (uploadError) throw uploadError;

      const { data: { publicUrl } } = supabase.storage
        .from('chat-images')
        .getPublicUrl(filePath);

      const { data: msg, error: msgError } = await supabase
        .from('chat_messages')
        .insert([
          {
            channel_id: activeChannel.id,
            sender_id: currentUserId,
            message: 'Photo envoyée',
            metadata: { type: 'image' },
            image_url: publicUrl
          }
        ])
        .select()
        .single();

      if (msgError) throw msgError;
      // DB trigger handles last_message_at update automatically
      setMessages(prev => [...prev, msg]);

    } catch (err) {
      console.error("Error uploading image", err);
      showToast("Erreur lors du téléchargement de l'image", "error");
    } finally {
      setUploading(false);
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  // Realtime Presence — track buyer online status when vendor has a conversation open
  useEffect(() => {
    if (!activeChannel || !currentUserId) {
      setIsOtherPartyOnline(false);
      return;
    }
    const otherPartyId = activeChannel.buyer_id;
    const ch = supabase.channel(`vendor:presence:${activeChannel.id}`, {
      config: { presence: { key: currentUserId } }
    });
    ch.on('presence', { event: 'sync' }, () => {
      const state = ch.presenceState() as Record<string, { user_id: string }[]>;
      const online = Object.keys(state).some(k => k === otherPartyId);
      if (isMountedRef.current) setIsOtherPartyOnline(online);
    })
    .subscribe(async (status) => {
      if (status === 'SUBSCRIBED') await ch.track({ user_id: currentUserId });
    });
    presenceChannelRef.current = ch;
    return () => {
      ch.untrack();
      supabase.removeChannel(ch);
      presenceChannelRef.current = null;
      setIsOtherPartyOnline(false);
    };
  }, [activeChannel?.id, currentUserId]);

  // ─────────────────────────────────────────────────────────────────────────
  // RENDER
  // ─────────────────────────────────────────────────────────────────────────
  return (
    <div
      className="flex bg-white dark:bg-gray-900 border border-gray-200 dark:border-white/10 rounded-[2rem] overflow-hidden shadow-xl"
      style={{ height: 'clamp(500px, 80vh, 760px)' }}
    >

      {/* ── SIDEBAR ─────────────────────────────────────────────────────────── */}
      <div
        className={`w-full md:w-[320px] shrink-0 border-r border-gray-100 dark:border-white/5 flex flex-col bg-white dark:bg-gray-900 ${activeChannel ? 'hidden md:flex' : 'flex'}`}
      >
        {/* Header */}
        <div className="px-5 pt-5 pb-4 border-b border-gray-100 dark:border-white/5">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-black text-gray-900 dark:text-white tracking-tight">Messages</h2>
            <button
              onClick={() => setShowSettings(!showSettings)}
              className={`p-2 rounded-xl transition-all ${showSettings ? 'bg-orange-100 dark:bg-orange-900/30 text-orange-600' : 'hover:bg-gray-100 dark:hover:bg-white/5 text-gray-400'}`}
              title="Paramètres"
            >
              <Settings className="w-4 h-4" />
            </button>
          </div>
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
            <input
              type="text"
              placeholder="Rechercher..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full bg-gray-50 dark:bg-white/5 border border-gray-200 dark:border-white/10 rounded-xl py-2.5 pl-9 pr-3 text-sm outline-none focus:border-orange-400 dark:focus:border-orange-500 text-gray-900 dark:text-white placeholder-gray-400 transition-all"
            />
          </div>
        </div>

        {/* List + Settings overlay */}
        <div className="flex-1 overflow-y-auto relative">
          <AnimatePresence>
            {showSettings && (
              <motion.div
                initial={{ x: -320 }}
                animate={{ x: 0 }}
                exit={{ x: -320 }}
                transition={{ type: 'spring', damping: 25, stiffness: 300 }}
                className="absolute inset-0 bg-white dark:bg-gray-900 z-20 overflow-y-auto p-5 space-y-6"
              >
                <div className="flex items-center justify-between">
                  <h3 className="font-black text-sm uppercase tracking-widest text-gray-900 dark:text-white">Paramètres</h3>
                  <button
                    onClick={() => setShowSettings(false)}
                    className="p-1.5 hover:bg-gray-100 dark:hover:bg-white/5 rounded-lg transition-all"
                  >
                    <X className="w-4 h-4 text-gray-500" />
                  </button>
                </div>

                {/* WhatsApp Sync */}
                <div className="p-4 bg-gradient-to-br from-green-50 to-emerald-50 dark:from-green-950/20 dark:to-emerald-950/20 rounded-2xl border border-green-100 dark:border-green-900/30">
                  <div className="flex items-start gap-3 mb-4">
                    <Smartphone className="w-5 h-5 text-green-600 mt-0.5 shrink-0" />
                    <div>
                      <h4 className="text-xs font-black uppercase tracking-tight text-gray-900 dark:text-white">WhatsApp Sync</h4>
                      <p className="text-[11px] text-gray-500 mt-0.5 leading-relaxed">Notifications clients sur WhatsApp Elite.</p>
                    </div>
                  </div>
                  <button
                    onClick={() => handleUpdateSettings({ whatsapp_sync_enabled: !storeSettings.whatsapp_sync_enabled })}
                    disabled={savingSettings}
                    className={`w-full py-2.5 rounded-xl text-[11px] font-bold uppercase tracking-wider transition-all ${storeSettings.whatsapp_sync_enabled ? 'bg-green-600 text-white' : 'bg-white dark:bg-gray-800 border border-green-200 dark:border-green-900/40 text-gray-700 dark:text-white hover:bg-green-50'}`}
                  >
                    {storeSettings.whatsapp_sync_enabled ? '✅ Sync Activée' : 'Activer WhatsApp Sync'}
                  </button>
                </div>

                {/* Auto-Reply */}
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <MessageSquare className="w-4 h-4 text-gray-400" />
                      <span className="text-xs font-bold uppercase tracking-wide text-gray-700 dark:text-gray-300">Réponse Auto</span>
                    </div>
                    <button
                      onClick={() => handleUpdateSettings({ auto_reply_enabled: !storeSettings.auto_reply_enabled })}
                      className={`w-10 h-5 rounded-full transition-all relative ${storeSettings.auto_reply_enabled ? 'bg-orange-500' : 'bg-gray-200 dark:bg-gray-700'}`}
                    >
                      <div className={`absolute top-0.5 w-4 h-4 bg-white rounded-full shadow transition-all ${storeSettings.auto_reply_enabled ? 'left-5' : 'left-0.5'}`} />
                    </button>
                  </div>
                  <textarea
                    value={storeSettings.auto_reply_message}
                    onChange={(e) => setStoreSettings(prev => ({ ...prev, auto_reply_message: e.target.value }))}
                    onBlur={() => handleUpdateSettings({ auto_reply_message: storeSettings.auto_reply_message })}
                    placeholder="Message d'absence automatique..."
                    rows={4}
                    className="w-full bg-gray-50 dark:bg-white/5 border border-gray-200 dark:border-white/10 rounded-xl p-3 text-xs outline-none focus:border-orange-400 resize-none text-gray-800 dark:text-white placeholder-gray-400 transition-all"
                  />
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Channel list */}
          {loading ? (
            <div className="p-4 space-y-3">
              {[1, 2, 3, 4].map(i => (
                <div key={i} className="flex gap-3 px-2 py-3">
                  <Skeleton className="w-11 h-11 rounded-full shrink-0" />
                  <div className="flex-1 space-y-2 py-1">
                    <Skeleton className="h-3 w-2/5 rounded" />
                    <Skeleton className="h-2.5 w-3/4 rounded" />
                  </div>
                </div>
              ))}
            </div>
          ) : filteredChannels.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-20 opacity-40 gap-3">
              <MessageSquare className="w-10 h-10 text-gray-400" />
              <p className="text-xs font-bold tracking-wider text-gray-500 dark:text-white uppercase">Aucune conversation</p>
            </div>
          ) : filteredChannels.map(channel => {
            const unread = (channel as any).unread_count || 0;
            const isActive = activeChannel?.id === channel.id;
            const initials = channel.buyer_profile?.full_name?.charAt(0)?.toUpperCase() || '?';
            return (
              <button
                key={channel.id}
                onClick={() => setActiveChannel(channel)}
                className={`w-full px-4 py-3.5 flex gap-3 text-left transition-all relative border-r-2 ${
                  isActive
                    ? 'bg-orange-50 dark:bg-orange-950/20 border-orange-500'
                    : 'hover:bg-gray-50 dark:hover:bg-white/5 border-transparent'
                }`}
              >
                {/* Avatar */}
                <div className="relative shrink-0">
                  <div className="w-11 h-11 rounded-full overflow-hidden bg-gradient-to-br from-gray-300 to-gray-400 dark:from-gray-700 dark:to-gray-600 flex items-center justify-center font-bold text-sm text-white">
                    {channel.buyer_profile?.avatar_url
                      ? <img src={channel.buyer_profile.avatar_url} className="w-full h-full object-cover" />
                      : initials
                    }
                  </div>
                  {unread > 0 && (
                    <div className="absolute -top-0.5 -right-0.5 min-w-[18px] h-[18px] px-1 bg-orange-500 text-white text-[10px] font-black rounded-full flex items-center justify-center shadow-sm">
                      {unread > 9 ? '9+' : unread}
                    </div>
                  )}
                </div>

                {/* Text */}
                <div className="flex-1 min-w-0">
                  <div className="flex justify-between items-start gap-1 mb-0.5">
                    <span className={`text-[13px] truncate ${isActive ? 'font-black text-orange-600 dark:text-orange-400' : unread > 0 ? 'font-black text-gray-900 dark:text-white' : 'font-semibold text-gray-800 dark:text-gray-200'}`}>
                      {channel.buyer_profile?.full_name || 'Client'}
                    </span>
                    <span className="text-[10px] text-gray-400 whitespace-nowrap shrink-0">
                      {channel.last_message_at
                        ? new Date(channel.last_message_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
                        : ''}
                    </span>
                  </div>
                  <p className={`text-[12px] truncate ${unread > 0 ? 'text-gray-700 dark:text-gray-200 font-medium' : 'text-gray-400 dark:text-gray-500'}`}>
                    {channel.last_message || 'Démarrer la discussion…'}
                  </p>
                  {channel.product && (
                    <span className="text-[10px] font-semibold text-orange-500 truncate block mt-0.5">
                      📦 {channel.product.title}
                    </span>
                  )}
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* ── CHAT AREA ────────────────────────────────────────────────────────── */}
      <div className={`flex-1 flex flex-col min-w-0 bg-gray-50 dark:bg-gray-950 ${activeChannel ? 'flex' : 'hidden md:flex'}`}>
        {activeChannel ? (
          <>
            {/* Chat header */}
            <div className="px-4 py-3 border-b border-gray-100 dark:border-white/5 bg-white dark:bg-gray-900 flex items-center gap-3 shrink-0 shadow-sm">
              <button
                onClick={() => setActiveChannel(null)}
                className="md:hidden p-2 -ml-1 hover:bg-gray-100 dark:hover:bg-white/5 rounded-xl transition-all"
              >
                <ArrowLeft className="w-5 h-5 text-gray-700 dark:text-white" />
              </button>

              {/* Avatar + online dot */}
              <div className="relative shrink-0">
                <div className="w-10 h-10 rounded-full overflow-hidden bg-gradient-to-br from-gray-300 to-gray-400 dark:from-gray-700 dark:to-gray-600 flex items-center justify-center text-sm font-bold text-white">
                  {activeChannel.buyer_profile?.avatar_url
                    ? <img src={activeChannel.buyer_profile.avatar_url} className="w-full h-full object-cover" />
                    : (activeChannel.buyer_profile?.full_name?.charAt(0)?.toUpperCase() || <User className="w-5 h-5" />)
                  }
                </div>
                <div className={`absolute bottom-0 right-0 w-2.5 h-2.5 rounded-full border-2 border-white dark:border-gray-900 transition-colors ${isOtherPartyOnline ? 'bg-green-500' : 'bg-gray-300 dark:bg-gray-600'}`} />
              </div>

              {/* Name + status */}
              <div className="flex-1 min-w-0">
                <h4 className="font-bold text-sm text-gray-900 dark:text-white truncate leading-tight">
                  {activeChannel.buyer_profile?.full_name || 'Client'}
                </h4>
                <p className={`text-[11px] font-medium leading-tight ${isOtherPartyOnline ? 'text-green-500' : 'text-gray-400'}`}>
                  {isOtherPartyOnline ? 'En ligne' : 'Hors ligne'}
                </p>
              </div>

              {/* Product context pill (desktop) */}
              {activeChannel.product && (
                <div className="hidden sm:flex items-center gap-2 bg-gray-50 dark:bg-white/5 border border-gray-200 dark:border-white/10 rounded-xl px-3 py-1.5 max-w-[180px] shrink-0">
                  {activeChannel.product.image_urls?.[0] && (
                    <img src={activeChannel.product.image_urls[0]} className="w-7 h-7 rounded-lg object-cover shrink-0" />
                  )}
                  <div className="min-w-0">
                    <p className="text-[10px] font-bold text-gray-900 dark:text-white truncate leading-tight">{activeChannel.product.title}</p>
                    <p className="text-[10px] font-bold text-orange-500 leading-tight">{activeChannel.product.price_gnf.toLocaleString()} GNF</p>
                  </div>
                </div>
              )}

              {/* WhatsApp share */}
              <button
                onClick={() => {
                  const text = `Discussion avec ${activeChannel.buyer_profile?.full_name || 'client'} sur ${APP_NAME}`;
                  window.open(`https://wa.me/?text=${encodeURIComponent(text)}`, '_blank');
                }}
                className="p-2 hover:bg-green-50 dark:hover:bg-green-900/20 text-green-600 rounded-xl transition-all shrink-0"
                title="Partager sur WhatsApp"
              >
                <Share2 className="w-4 h-4" />
              </button>
            </div>

            {/* Messages area */}
            <div ref={scrollRef} className="flex-1 overflow-y-auto px-4 py-5 scroll-smooth">
              {hasMoreMessages && (
                <div className="flex justify-center py-2 mb-4">
                  <button
                    onClick={loadMoreMessages}
                    disabled={loadingMore}
                    className="text-[11px] font-bold text-gray-400 hover:text-orange-500 transition-colors px-4 py-2 rounded-full border border-gray-200 dark:border-white/10 hover:border-orange-300 disabled:opacity-40 flex items-center gap-2"
                  >
                    {loadingMore ? <Loader2 className="w-3 h-3 animate-spin" /> : '↑ Messages précédents'}
                  </button>
                </div>
              )}

              {/* Product context card (mobile — top of messages) */}
              {activeChannel.product && (
                <div className="flex justify-center mb-6 sm:hidden">
                  <div className="bg-white dark:bg-gray-900 border border-gray-200 dark:border-white/10 rounded-2xl p-3 flex items-center gap-3 max-w-xs shadow-sm">
                    {activeChannel.product.image_urls?.[0] && (
                      <img src={activeChannel.product.image_urls[0]} className="w-12 h-12 rounded-xl object-cover shrink-0" />
                    )}
                    <div>
                      <span className="text-[10px] font-bold text-orange-500 uppercase tracking-widest block">Produit</span>
                      <p className="text-[12px] font-bold text-gray-900 dark:text-white leading-tight truncate">{activeChannel.product.title}</p>
                      <p className="text-[11px] font-bold text-orange-500">{activeChannel.product.price_gnf.toLocaleString()} GNF</p>
                    </div>
                  </div>
                </div>
              )}

              {/* Messages */}
              {messages.map((msg, idx) => {
                const isMine = msg.sender_id === currentUserId;
                const prevMsg = messages[idx - 1];
                const nextMsg = messages[idx + 1];
                const prevDate = prevMsg ? new Date(prevMsg.created_at).toDateString() : null;
                const thisDate = new Date(msg.created_at).toDateString();
                const nextDate = nextMsg ? new Date(nextMsg.created_at).toDateString() : null;
                const showDateSep = prevDate !== thisDate;
                const isFirstInGroup = !prevMsg || prevMsg.sender_id !== msg.sender_id || prevDate !== thisDate;
                const isLastInGroup = !nextMsg || nextMsg.sender_id !== msg.sender_id || nextDate !== thisDate;
                const isOffer = msg.metadata?.type === 'offer';
                const isAutoReply = msg.metadata?.type === 'auto-reply';
                const today = new Date().toDateString();
                const yesterday = new Date(Date.now() - 86400000).toDateString();
                const dateLabel = thisDate === today
                  ? "Aujourd'hui"
                  : thisDate === yesterday
                  ? 'Hier'
                  : new Date(msg.created_at).toLocaleDateString('fr-FR', { day: 'numeric', month: 'long' });

                return (
                  <React.Fragment key={msg.id}>
                    {showDateSep && (
                      <div className="flex items-center gap-3 py-5">
                        <div className="flex-1 h-px bg-gray-200 dark:bg-white/10" />
                        <span className="text-[10px] font-bold text-gray-400 dark:text-gray-500 px-3 py-1 bg-gray-100 dark:bg-white/5 rounded-full whitespace-nowrap">
                          {dateLabel}
                        </span>
                        <div className="flex-1 h-px bg-gray-200 dark:bg-white/10" />
                      </div>
                    )}

                    <div className={`flex ${isMine ? 'justify-end' : 'justify-start'} ${isLastInGroup ? 'mb-4' : 'mb-0.5'}`}>
                      {/* Incoming avatar */}
                      {!isMine && (
                        <div className="w-7 h-7 shrink-0 mr-1.5 self-end">
                          {isLastInGroup && (
                            <div className="w-7 h-7 rounded-full overflow-hidden bg-gradient-to-br from-gray-300 to-gray-400 dark:from-gray-700 dark:to-gray-600 flex items-center justify-center text-xs font-bold text-white">
                              {activeChannel.buyer_profile?.avatar_url
                                ? <img src={activeChannel.buyer_profile.avatar_url} className="w-full h-full object-cover" />
                                : (activeChannel.buyer_profile?.full_name?.charAt(0)?.toUpperCase() || '?')
                              }
                            </div>
                          )}
                        </div>
                      )}

                      <div className={`max-w-[72%] sm:max-w-[60%] flex flex-col ${isMine ? 'items-end' : 'items-start'}`}>
                        {/* Bubble */}
                        <div className={`px-4 py-2.5 text-[14px] leading-relaxed shadow-sm
                          ${isMine
                            ? `bg-[#ff6600] text-white ${isFirstInGroup ? 'rounded-t-2xl' : 'rounded-t-md'} ${isLastInGroup ? 'rounded-bl-2xl rounded-br-sm' : 'rounded-b-md'}`
                            : `bg-white dark:bg-gray-800 text-gray-900 dark:text-white border border-gray-100 dark:border-white/5 ${isFirstInGroup ? 'rounded-t-2xl' : 'rounded-t-md'} ${isLastInGroup ? 'rounded-br-2xl rounded-bl-sm' : 'rounded-b-md'}`
                          }
                        `}>
                          {/* Image */}
                          {msg.image_url && (
                            <div className="mb-2 -mx-1">
                              <img
                                src={msg.image_url}
                                className="rounded-xl cursor-pointer hover:opacity-90 transition-opacity"
                                style={{ maxHeight: 200, maxWidth: '100%' }}
                                onClick={() => window.open(msg.image_url, '_blank')}
                              />
                            </div>
                          )}

                          {/* Message text */}
                          <span>{msg.message}</span>

                          {/* Auto-reply badge */}
                          {isAutoReply && (
                            <div className="mt-1.5 flex items-center gap-1 opacity-60">
                              <Smartphone className="w-2.5 h-2.5" />
                              <span className="text-[9px] uppercase tracking-widest font-bold">Réponse auto</span>
                            </div>
                          )}

                          {/* Offer card */}
                          {isOffer && (
                            <div className="mt-2 pt-2 border-t border-white/20">
                              <div className="flex items-center justify-between mb-1">
                                <span className="text-[10px] uppercase tracking-widest font-bold opacity-70">💰 Offre Spéciale</span>
                                <span className="text-[9px] bg-white/20 px-1.5 py-0.5 rounded font-bold">En attente</span>
                              </div>
                              <div className="text-xl font-black">{msg.metadata.price?.toLocaleString()} GNF</div>
                              {msg.metadata.originalPrice && (
                                <div className="text-[11px] opacity-60 line-through">{msg.metadata.originalPrice.toLocaleString()} GNF</div>
                              )}
                            </div>
                          )}
                        </div>

                        {/* Timestamp + read receipt */}
                        {isLastInGroup && (
                          <div className={`flex items-center gap-1 mt-1 px-1 ${isMine ? 'flex-row-reverse' : 'flex-row'}`}>
                            <span className="text-[10px] text-gray-400">
                              {new Date(msg.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                            </span>
                            {isMine && (
                              <CheckCheck className={`w-3 h-3 ${msg.is_read ? 'text-orange-400' : 'text-gray-300 dark:text-gray-600'}`} />
                            )}
                          </div>
                        )}
                      </div>
                    </div>
                  </React.Fragment>
                );
              })}

              {messages.length === 0 && !loading && (
                <div className="flex flex-col items-center justify-center h-full py-16 opacity-40 gap-3">
                  <MessageSquare className="w-10 h-10 text-gray-400" />
                  <p className="text-sm font-bold text-gray-500 dark:text-white">Aucun message</p>
                  <p className="text-xs text-gray-400">Démarrez la conversation</p>
                </div>
              )}
            </div>

            {/* ── INPUT AREA ── */}
            <form onSubmit={handleSendMessage} className="shrink-0 border-t border-gray-100 dark:border-white/5 bg-white dark:bg-gray-900 relative">

              {/* Offer input panel */}
              <AnimatePresence>
                {showOfferInput && (
                  <motion.div
                    initial={{ y: 20, opacity: 0 }}
                    animate={{ y: 0, opacity: 1 }}
                    exit={{ y: 20, opacity: 0 }}
                    transition={{ duration: 0.18 }}
                    className="px-4 pt-4 pb-3 border-b border-gray-100 dark:border-white/5 bg-orange-50 dark:bg-orange-950/20"
                  >
                    <div className="flex items-center justify-between mb-3">
                      <h4 className="text-xs font-black uppercase tracking-widest text-orange-600">💰 Proposer un prix</h4>
                      <button
                        type="button"
                        onClick={() => setShowOfferInput(false)}
                        className="p-1 hover:bg-orange-100 dark:hover:bg-orange-900/30 rounded-lg transition-all"
                      >
                        <X className="w-3.5 h-3.5 text-orange-600" />
                      </button>
                    </div>
                    <div className="flex gap-2">
                      <input
                        type="number"
                        placeholder="Prix en GNF..."
                        value={offerPrice}
                        onChange={(e) => setOfferPrice(e.target.value)}
                        className="flex-1 bg-white dark:bg-gray-800 border border-orange-200 dark:border-orange-900/40 rounded-xl px-3 py-2 text-sm font-bold outline-none focus:border-orange-500 text-gray-900 dark:text-white"
                      />
                      <button
                        type="button"
                        onClick={handleSendOffer}
                        className="bg-orange-500 hover:bg-orange-600 text-white px-4 py-2 rounded-xl text-xs font-bold uppercase tracking-wider transition-all active:scale-95"
                      >
                        Envoyer
                      </button>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>

              {/* Quick replies — wrap on mobile */}
              <div className="px-4 pt-3 pb-2 flex flex-wrap gap-1.5">
                <button
                  type="button"
                  onClick={() => setShowOfferInput(!showOfferInput)}
                  disabled={!activeChannel.product_id}
                  className={`px-3 py-1.5 rounded-full text-[11px] font-bold uppercase tracking-wide transition-all active:scale-95 disabled:opacity-40 ${showOfferInput ? 'bg-orange-100 dark:bg-orange-900/30 text-orange-600 border border-orange-300' : 'bg-orange-500 hover:bg-orange-600 text-white'}`}
                >
                  {showOfferInput ? '✕ Annuler' : '💰 Offre'}
                </button>
                {QUICK_REPLIES.map((reply, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={(e) => handleSendMessage(e as any, reply)}
                    className="px-3 py-1.5 bg-gray-50 dark:bg-white/5 border border-gray-200 dark:border-white/10 rounded-full text-[11px] font-medium text-gray-600 dark:text-gray-300 hover:bg-orange-50 hover:text-orange-600 hover:border-orange-200 transition-all active:scale-95"
                  >
                    {reply}
                  </button>
                ))}
              </div>

              {/* Text input row */}
              <div className="px-4 pb-4 flex items-end gap-2">
                <input
                  type="file"
                  ref={fileInputRef}
                  onChange={handleImageUpload}
                  accept="image/*"
                  className="hidden"
                />
                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  disabled={uploading}
                  className="p-2.5 bg-gray-50 dark:bg-white/5 border border-gray-200 dark:border-white/10 rounded-xl hover:bg-gray-100 dark:hover:bg-white/10 transition-all shrink-0 disabled:opacity-40"
                  title="Envoyer une image"
                >
                  {uploading
                    ? <Loader2 className="w-4 h-4 text-gray-400 animate-spin" />
                    : (
                      <svg className="w-4 h-4 text-gray-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.172 7l-6.586 6.586a2 2 0 102.828 2.828l6.414-6.586a4 4 0 00-5.656-5.656l-6.415 6.585a6 6 0 108.486 8.486L20.5 13" />
                      </svg>
                    )
                  }
                </button>

                <textarea
                  ref={textareaRef}
                  autoFocus
                  placeholder="Écrivez votre message..."
                  value={newMessage}
                  onChange={(e) => {
                    setNewMessage(e.target.value);
                    e.target.style.height = 'auto';
                    e.target.style.height = Math.min(e.target.scrollHeight, 120) + 'px';
                  }}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' && !e.shiftKey) {
                      e.preventDefault();
                      handleSendMessage(e as any);
                    }
                  }}
                  rows={1}
                  className="flex-1 bg-gray-50 dark:bg-white/5 border border-gray-200 dark:border-white/10 rounded-xl px-4 py-2.5 text-sm outline-none focus:border-orange-400 dark:focus:border-orange-500 text-gray-900 dark:text-white placeholder-gray-400 transition-all resize-none overflow-hidden leading-relaxed"
                  style={{ minHeight: 42 }}
                />

                <motion.button
                  type="submit"
                  disabled={!newMessage.trim()}
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.93 }}
                  className="p-2.5 bg-[#ff6600] hover:bg-orange-600 disabled:bg-gray-200 dark:disabled:bg-white/10 text-white disabled:text-gray-400 rounded-xl transition-colors shrink-0 shadow-sm shadow-orange-200 dark:shadow-none"
                >
                  <Send className="w-4 h-4" />
                </motion.button>
              </div>
            </form>
          </>
        ) : (
          /* Empty state */
          <div className="flex-1 flex flex-col items-center justify-center gap-4 opacity-50">
            <div className="w-16 h-16 bg-white dark:bg-white/5 border border-gray-200 dark:border-white/10 rounded-2xl flex items-center justify-center shadow-sm">
              <MessageSquare className="w-7 h-7 text-gray-400" />
            </div>
            <div className="text-center">
              <p className="text-sm font-bold text-gray-500 dark:text-gray-400">Sélectionnez une conversation</p>
              <p className="text-xs text-gray-400 mt-1">Vos échanges avec les clients apparaîtront ici</p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
