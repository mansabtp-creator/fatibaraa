import React, { useState, useEffect } from 'react';
import { supabase, validateSessionOrClear } from '../lib/supabase';
import { withdrawalService } from '../services/withdrawalService';
import { Wallet, ArrowDownRight, ArrowUpRight, Search, Filter, Download, Coins, PieChart, TrendingUp, Calendar, AlertCircle, Loader2, BarChart3 } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { useToast } from '../context/ToastContext';
import { APP_NAME } from '../lib/constants';
import { formatGNF } from '../utils/formatters';

interface Transaction {
  id: string;
  amount: number;
  type: 'sale' | 'withdrawal' | 'refund' | 'adjustment';
  status: string;
  reference_id: string;
  description: string;
  created_at: string;
}

interface StoreData {
  id: string;
  balance: number;
  payout_orange_money?: string;
  payout_mtn_money?: string;
  is_verified_store?: boolean;
  is_verified?: boolean;
  status?: string;
  store_status?: string;
  owner_id?: string;
}

export default function VendorLedger({ storeId }: { storeId: string }) {
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [loading, setLoading] = useState(true);
  const [storeData, setStoreData] = useState<StoreData | null>(null);
  const [showPayoutModal, setShowPayoutModal] = useState(false);
  const [payoutAmount, setPayoutAmount] = useState('');
  const [payoutMethod, setPayoutMethod] = useState<'Orange' | 'MTN'>('Orange');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [hasMore, setHasMore] = useState(false);
  const [page, setPage] = useState(0);
  const PAGE_SIZE = 100;
  const { showToast } = useToast();

  const [stats, setStats] = useState({
    totalSales: 0,
    totalWithdrawals: 0,
    netEarnings: 0
  });

  const fetchData = async () => {
    try {
      // Fetch store balance and payout settings
      const { data: store, error: storeError } = await supabase
        .from('stores')
        .select('id, balance, payout_orange_money, payout_mtn_money, is_verified_store, is_verified, status, store_status, owner_id')
        .eq('id', storeId)
        .single();

      if (storeError) throw storeError;
      setStoreData(store);

      const { data, error, count } = await supabase
        .from('wallet_transactions')
        .select('*', { count: 'exact' })
        .eq('store_id', storeId)
        .order('created_at', { ascending: false })
        .range(page * PAGE_SIZE, (page + 1) * PAGE_SIZE - 1);

      if (error) throw error;
      const rows = data || [];
      setTransactions(prev => page === 0 ? rows : [...prev, ...rows]);
      setHasMore((count ?? 0) > (page + 1) * PAGE_SIZE);

      const sales = data?.filter(t => t.type === 'sale').reduce((acc, t) => acc + t.amount, 0) || 0;
      const withdrawals = data?.filter(t => t.type === 'withdrawal').reduce((acc, t) => acc + t.amount, 0) || 0;
      
      setStats({
        totalSales: sales,
        totalWithdrawals: Math.abs(withdrawals),
        // Always trust the authoritative stores.balance column as the source of truth.
        // It is updated atomically by secure_process_order_financials and withdrawal RPCs.
        netEarnings: store.balance ?? 0
      });
    } catch (err: any) {
      console.error("Error fetching ledger:", err);
      showToast(err.message || "Erreur lors du chargement de la comptabilité.", "error");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (storeId) { setPage(0); fetchData(); }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [storeId]);

  const handleRequestPayout = async () => {
    if (!storeId || !/^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(storeId.trim())) {
      showToast('Identifiant de boutique invalide ou introuvable.', 'error');
      return;
    }

    const isStoreValid = Boolean(
      storeData?.is_verified_store ||
      storeData?.is_verified ||
      storeData?.status === 'active' ||
      storeData?.status === 'approved' ||
      storeData?.store_status === 'active' ||
      storeData?.store_status === 'approved'
    );
    if (!isStoreValid) {
      showToast('Votre boutique doit être validée par les administrateurs avant de pouvoir effectuer des retraits.', 'warning');
      return;
    }

    const amount = parseInt(payoutAmount.replace(/\D/g, ''), 10);
    if (!amount || isNaN(amount) || amount < 50000) {
      showToast("Minimum de retrait: 50.000 GNF", "warning");
      return;
    }

    if (amount > (storeData?.balance || 0)) {
      showToast("Solde insuffisant", "error");
      return;
    }

    const rawPhone = payoutMethod === 'Orange' ? storeData?.payout_orange_money : storeData?.payout_mtn_money;
    const phone = (rawPhone || '').replace(/\D/g, '').replace(/^224/, '');
    if (!phone || phone.length !== 9) {
      showToast(`Veuillez configurer un numéro ${payoutMethod} valide dans les réglages`, "warning");
      return;
    }

    setIsSubmitting(true);
    try {
      const session = await validateSessionOrClear();
      if (!session) {
        throw new Error('Session expirée. Veuillez vous reconnecter.');
      }

      // Re-verify live store balance before making RPC
      const { data: latestStore } = await supabase
        .from('stores')
        .select('balance, is_verified_store, is_verified, status, store_status, owner_id')
        .eq('id', storeId.trim())
        .maybeSingle();

      if (latestStore) {
        setStoreData(latestStore);
        if (amount > (latestStore.balance || 0)) {
          throw new Error(`Solde insuffisant sur votre compte (Disponible : ${(latestStore.balance || 0).toLocaleString('fr-FR')} GNF).`);
        }
        const isLatestValid = Boolean(
          latestStore.is_verified_store ||
          latestStore.is_verified ||
          latestStore.status === 'active' ||
          latestStore.status === 'approved' ||
          latestStore.store_status === 'active' ||
          latestStore.store_status === 'approved'
        );
        if (!isLatestValid) {
          throw new Error('Votre boutique doit être validée par les administrateurs avant de pouvoir effectuer des retraits.');
        }
      }

      await withdrawalService.requestVendorWithdrawal({
        storeId: storeId.trim(),
        amount: amount,
        method: payoutMethod === 'Orange' ? 'orange_money' : 'mtn_money',
        phone: phone,
        userId: session.user.id,
      });

      showToast("Demande de retrait envoyée avec succès !", "success");
      setShowPayoutModal(false);
      setPayoutAmount('');
      fetchData(); // Refresh balance
    } catch (err: any) {
      showToast(err.message, "error");
      fetchData();
    } finally {
      setIsSubmitting(false);
    }
  };

  if (loading) return (
    <div className="space-y-4 animate-pulse">
      <div className="h-40 bg-gray-100 dark:bg-gray-800 rounded-3xl" />
      <div className="h-64 bg-gray-50 dark:bg-gray-800/50 rounded-3xl" />
    </div>
  );

  return (
    <div className="space-y-10">
      {/* Financial Summary */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        <div className="bg-white dark:bg-[#1A1D21] p-10 rounded-[2.5rem] border border-gray-100 dark:border-white/5 shadow-sm group hover:scale-[1.02] transition-all">
          <div className="flex items-center gap-4 mb-8">
            <div className="w-14 h-14 bg-emerald-50 dark:bg-emerald-500/10 rounded-2xl flex items-center justify-center text-emerald-600">
              <TrendingUp className="w-7 h-7" />
            </div>
            <span className="text-[10px] font-black text-gray-400 dark:text-gray-500 uppercase tracking-[0.2em] italic">Volumes Bruts</span>
          </div>
          <div className="flex items-end gap-2">
            <p className="text-4xl font-black text-gray-900 dark:text-white tracking-tighter tabular-nums leading-none">
              {formatGNF(stats.totalSales)}
            </p>
          </div>
          <p className="text-[10px] font-bold text-emerald-500 mt-4 flex items-center gap-1 uppercase tracking-widest">
            <TrendingUp className="w-3 h-3" /> Audité par l'IA {APP_NAME}
          </p>
        </div>

        <div className="bg-white dark:bg-[#1A1D21] p-10 rounded-[2.5rem] border border-gray-100 dark:border-white/5 shadow-sm group hover:scale-[1.02] transition-all">
          <div className="flex items-center gap-4 mb-8">
            <div className="w-14 h-14 bg-rose-50 dark:bg-rose-500/10 rounded-2xl flex items-center justify-center text-rose-600">
              <ArrowDownRight className="w-7 h-7" />
            </div>
            <span className="text-[10px] font-black text-gray-400 dark:text-gray-500 uppercase tracking-[0.2em] italic">Retraits Effectués</span>
          </div>
          <div className="flex items-end gap-2">
            <p className="text-4xl font-black text-gray-900 dark:text-white tracking-tighter tabular-nums leading-none">
              {formatGNF(stats.totalWithdrawals)}
            </p>
          </div>
        </div>

        <div className="bg-[#1A1D21] dark:bg-black p-10 rounded-[2.5rem] border border-white/5 shadow-2xl relative overflow-hidden group hover:scale-[1.05] transition-all">
          <div className="relative z-10">
            <div className="flex items-center justify-between mb-8">
              <div className="flex items-center gap-4">
                <div className="w-14 h-14 bg-[#ff6600]/20 rounded-2xl flex items-center justify-center text-[#ff6600]">
                  <Coins className="w-8 h-8" />
                </div>
                <span className="text-[10px] font-black text-gray-400 uppercase tracking-[0.2em] italic">Liquidité Immédiate</span>
              </div>
            </div>
            <div className="flex items-end gap-2 mb-8">
              <p className="text-5xl font-black text-white tracking-tighter tabular-nums leading-none">
                {formatGNF(stats.netEarnings)}
              </p>
            </div>
            
            <button 
              onClick={() => setShowPayoutModal(true)}
              className="w-full bg-[#ff6600] text-white py-4 rounded-2xl text-[11px] font-black uppercase tracking-widest hover:bg-[#ff6600]/90 transition-all shadow-xl shadow-[#ff6600]/20 active:scale-[0.98]"
            >
              Demander un retrait instantané
            </button>
          </div>
          <div className="absolute top-0 right-0 w-32 h-32 bg-[#ff6600]/10 blur-[60px] -mr-10 -mt-10 group-hover:scale-150 transition-transform duration-700" />
        </div>
      </div>


      {/* Transaction List */}
      <div className="bg-white dark:bg-[#1A1D21] rounded-[3rem] border border-gray-100 dark:border-white/5 shadow-sm overflow-hidden mt-12">
        <div className="p-10 border-b border-gray-50 dark:border-white/5 flex justify-between items-center">
          <div>
            <h3 className="text-xl font-black text-gray-900 dark:text-white tracking-tighter uppercase italic">Grand Livre de Caisse</h3>
            <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest italic leading-none mt-1">Audit comptable et historique des flux</p>
          </div>
          <div className="flex items-center gap-4">
           <div className="relative group hidden sm:block">
               <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400 group-focus-within:text-[#ff6600] transition-colors" />
               <input
                 type="text"
                 value={searchQuery}
                 onChange={(e) => setSearchQuery(e.target.value)}
                 placeholder="Rechercher Ref..."
                 className="bg-gray-50 dark:bg-black/20 border border-transparent dark:border-white/5 rounded-xl pl-11 pr-4 py-2.5 text-[12px] font-bold focus:bg-white dark:focus:bg-black focus:border-[#ff6600] outline-none transition-all w-60"
               />
             </div>
             <button
               onClick={() => {
                 const visible = transactions.filter(tx =>
                   !searchQuery ||
                   (tx.reference_id || '').toLowerCase().includes(searchQuery.toLowerCase()) ||
                   (tx.description || '').toLowerCase().includes(searchQuery.toLowerCase())
                 );
                 const headers = ['Date', 'Description', 'Référence', 'Montant (GNF)'];
                 const rows = visible.map(tx => [
                   new Date(tx.created_at).toLocaleDateString(),
                   `"${(tx.description || '').replace(/"/g, '""')}"`,
                   tx.reference_id || '',
                   tx.amount,
                 ]);
                 const csv = 'data:text/csv;charset=utf-8,' + encodeURIComponent(
                   [headers.join(','), ...rows.map(r => r.join(','))].join('\n')
                 );
                 const a = document.createElement('a');
                 a.href = csv;
                 a.download = `GRAND_LIVRE_${new Date().toISOString().split('T')[0]}.csv`;
                 a.click();
                 showToast('Export CSV téléchargé !', 'success');
               }}
               className="p-3 bg-gray-50 dark:bg-black/20 hover:bg-[#ff6600]/10 hover:text-[#ff6600] rounded-xl transition-all border border-transparent dark:border-white/5"
               title="Exporter en CSV"
             >
               <Download className="w-5 h-5" />
             </button>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-gray-50/50 dark:bg-black/20">
                <th className="px-10 py-6 text-[10px] font-black uppercase tracking-widest text-gray-400">Date Log</th>
                <th className="px-10 py-6 text-[10px] font-black uppercase tracking-widest text-gray-400">Nature du Flux</th>
                <th className="px-10 py-6 text-[10px] font-black uppercase tracking-widest text-gray-400">Référence</th>
                <th className="px-10 py-6 text-[10px] font-black uppercase tracking-widest text-gray-400 text-right">Valeur Net</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-50 dark:divide-white/5">
              {transactions.length === 0 ? (
                <tr>
                  <td colSpan={4} className="px-10 py-20 text-center text-gray-400 font-black uppercase tracking-widest text-[12px]">
                    <div className="flex flex-col items-center gap-4">
                       <BarChart3 className="w-10 h-10 opacity-20" />
                       Aucune activité enregistrée
                    </div>
                  </td>
                </tr>
              ) : (
                transactions
                  .filter(tx =>
                    !searchQuery ||
                    (tx.reference_id || '').toLowerCase().includes(searchQuery.toLowerCase()) ||
                    (tx.description || '').toLowerCase().includes(searchQuery.toLowerCase())
                  )
                  .map((tx) => (
                  <tr key={tx.id} className="hover:bg-gray-50/50 dark:hover:bg-white/5 transition-colors group cursor-default">
                    <td className="px-10 py-8">
                      <div className="flex items-center gap-3">
                        <div className="w-1.5 h-1.5 rounded-full bg-[#ff6600] group-hover:scale-150 transition-transform" />
                        <span className="text-[14px] font-black text-gray-900 dark:text-gray-200 tabular-nums">
                          {new Date(tx.created_at).toLocaleDateString()}
                        </span>
                      </div>
                    </td>
                    <td className="px-10 py-8">
                      <div className="flex flex-col">
                        <span className="text-[13px] font-black text-gray-900 dark:text-gray-100 uppercase tracking-tighter leading-none mb-1">{tx.description}</span>
                        <div className="flex items-center gap-2">
                           <span className={`text-[9px] font-black uppercase tracking-widest italic ${
                             tx.type === 'sale' ? 'text-emerald-500' :
                             tx.type === 'withdrawal' ? 'text-orange-500' :
                             'text-gray-400'
                           }`}>
                             Type: {tx.type}
                           </span>
                           <span className="text-[10px] text-emerald-500 font-bold">• VÉRIFIÉ</span>
                        </div>
                      </div>
                    </td>
                    <td className="px-10 py-8">
                       <span className="text-[10px] font-black text-gray-400 uppercase tracking-widest bg-gray-50 dark:bg-black/30 px-3 py-1 rounded-md border border-gray-100 dark:border-white/5">
                          ID: #{tx.reference_id?.slice(0, 10)}
                       </span>
                    </td>
                    <td className="px-10 py-8 text-right">
                      <div className="flex flex-col items-end">
                        <span className={`text-lg font-black tracking-tighter tabular-nums leading-none ${
                          tx.amount > 0 ? 'text-emerald-500' : 'text-rose-500'
                        }`}>
                          {tx.amount > 0 ? '+' : '-'}{formatGNF(Math.abs(tx.amount))}
                        </span>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Load More — only shown when there are more than 100 transactions */}
      {hasMore && (
        <div className="text-center py-4">
          <button
            onClick={() => { setPage(p => p + 1); fetchData(); }}
            className="px-8 py-3 rounded-2xl text-[11px] font-black uppercase tracking-widest border border-gray-200 dark:border-white/10 text-gray-500 dark:text-gray-400 hover:bg-gray-50 dark:hover:bg-white/5 transition-all"
          >
            Charger plus de transactions
          </button>
        </div>
      )}

      {/* Payout Modal */}
      <AnimatePresence>
        {showPayoutModal && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
             <motion.div 
               initial={{ opacity: 0 }}
               animate={{ opacity: 1 }}
               exit={{ opacity: 0 }}
               onClick={() => setShowPayoutModal(false)}
               className="absolute inset-0 bg-black/60 backdrop-blur-sm"
             />
             <motion.div
               initial={{ opacity: 0, scale: 0.9, y: 20 }}
               animate={{ opacity: 1, scale: 1, y: 0 }}
               exit={{ opacity: 0, scale: 0.9, y: 20 }}
               className="bg-white dark:bg-gray-900 w-full max-w-md rounded-[2.5rem] p-8 md:p-10 shadow-2xl relative z-10 border border-brand-border/20"
             >
                <div className="flex items-center gap-4 mb-8">
                  <div className="w-14 h-14 bg-[#ff6600]/10 rounded-2xl flex items-center justify-center text-[#ff6600]">
                    <ArrowUpRight className="w-8 h-8" />
                  </div>
                  <div>
                    <h3 className="text-xl font-bold text-gray-900 dark:text-white tracking-tight">Retrait de Fonds</h3>
                    <p className="text-[11px] font-bold text-gray-500 uppercase tracking-wider">Transférez vos gains vers votre mobile money</p>
                  </div>
                </div>

                <div className="space-y-6">
                  <div className="bg-gray-50 dark:bg-gray-800 p-5 rounded-2xl border border-dashed border-brand-border/30">
                    <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1">Solde actuel</p>
                    <p className="text-2xl font-black text-gray-900 dark:text-white">{formatGNF(storeData?.balance || 0)}</p>
                  </div>

                  <div className="space-y-2">
                    <label className="text-[11px] font-bold text-gray-500 uppercase tracking-wider ml-1">Montant à retirer (GNF)</label>
                    <input 
                      type="number" 
                      value={payoutAmount}
                      onChange={(e) => setPayoutAmount(e.target.value)}
                      placeholder="Min. 50,000"
                      className="w-full bg-gray-50 dark:bg-gray-800 border border-gray-100 dark:border-gray-800 rounded-2xl p-4 text-lg font-bold text-gray-900 dark:text-white focus:border-[#ff6600] outline-none transition-all"
                    />
                  </div>

                  <div className="space-y-2">
                    <label className="text-[11px] font-bold text-gray-500 uppercase tracking-wider ml-1">Méthode de réception</label>
                    <div className="grid grid-cols-2 gap-3">
                      <button 
                        onClick={() => setPayoutMethod('Orange')}
                        className={`p-4 rounded-2xl border-2 transition-all flex flex-col items-center gap-2 ${payoutMethod === 'Orange' ? 'border-[#ff6600] bg-[#ff6600]/5 text-[#ff6600]' : 'border-gray-100 dark:border-gray-800 text-gray-400'}`}
                      >
                         <img 
                           src="https://upload.wikimedia.org/wikipedia/commons/c/c8/Orange_logo.svg" 
                           onError={(e) => {
                             e.currentTarget.style.display = 'none';
                           }}
                           className="w-6 h-6 grayscale" 
                           alt="" 
                           style={payoutMethod === 'Orange' ? {filter: 'none'} : {}} 
                         />
                         <span className="text-[10px] font-black uppercase">Orange</span>
                      </button>
                      <button 
                        onClick={() => setPayoutMethod('MTN')}
                        className={`p-4 rounded-2xl border-2 transition-all flex flex-col items-center gap-2 ${payoutMethod === 'MTN' ? 'border-yellow-500 bg-yellow-500/5 text-yellow-600' : 'border-gray-100 dark:border-gray-800 text-gray-400'}`}
                      >
                         <div className="w-6 h-6 bg-yellow-400 rounded flex items-center justify-center text-white font-black text-[8px]">MTN</div>
                         <span className="text-[10px] font-black uppercase">MTN</span>
                      </button>
                    </div>
                  </div>

                  {(payoutMethod === 'Orange' ? !storeData?.payout_orange_money : !storeData?.payout_mtn_money) && (
                    <div className="bg-red-50 dark:bg-red-900/20 p-4 rounded-xl flex items-center gap-3 text-red-600 border border-red-100 dark:border-red-900/30">
                       <AlertCircle className="w-5 h-5 shrink-0" />
                       <p className="text-[10px] font-bold leading-tight">Aucun numéro {payoutMethod} configuré. Allez dans Réglages.</p>
                    </div>
                  )}

                  <button 
                    onClick={handleRequestPayout}
                    disabled={isSubmitting || !payoutAmount || (payoutMethod === 'Orange' ? !storeData?.payout_orange_money : !storeData?.payout_mtn_money)}
                    className="w-full bg-black dark:bg-[#ff6600] text-white py-5 rounded-2xl font-black uppercase tracking-widest shadow-xl shadow-brand-foreground/20 hover:scale-[1.02] active:scale-[0.98] transition-all disabled:opacity-50 flex items-center justify-center gap-3"
                  >
                    {isSubmitting ? <Loader2 className="w-5 h-5 animate-spin" /> : "Confirmer le retrait"}
                  </button>
                </div>
             </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
