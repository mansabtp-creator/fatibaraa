import React, { useEffect, useState } from 'react';
import { supabase } from '../lib/supabase';
import { Star, MessageSquare, Send, CheckCircle, Loader2, StarHalf, MapPin } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { useToast } from '../context/ToastContext';

interface Review {
  id: string;
  product_id: string;
  user_name: string;
  avatar_url: string;
  rating: number;
  comment: string;
  location: string;
  created_at: string;
  shop_response?: string;
  products: {
    title: string;
    image_urls: string[];
  };
}

export default function VendorReviews({ storeId }: { storeId: string }) {
  const [reviews, setReviews] = useState<Review[]>([]);
  const [loading, setLoading] = useState(true);
  const [replyingTo, setReplyingTo] = useState<string | null>(null);
  const [replyText, setReplyText] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const { showToast } = useToast();

  useEffect(() => {
    async function fetchReviews() {
      try {
        const { data, error } = await supabase
          .from('reviews')
          .select('*, products(title, image_urls)')
          .eq('store_id', storeId)
          .order('created_at', { ascending: false });

        if (error) throw error;
        setReviews(data || []);
      } catch (err) {
        console.error('Error fetching reviews:', err);
      } finally {
        setLoading(false);
      }
    }

    if (storeId) fetchReviews();
  }, [storeId]);

  const handleReply = async (reviewId: string) => {
    if (!replyText.trim()) return;

    setSubmitting(true);
    try {
      const { error } = await supabase
        .from('reviews')
        .update({ shop_response: replyText })
        .eq('id', reviewId);

      if (error) throw error;

      setReviews(prev => prev.map(r => r.id === reviewId ? { ...r, shop_response: replyText } : r));
      setReplyingTo(null);
      setReplyText('');
      showToast("Votre réponse a été publiée !", 'success');
    } catch (err) {
      showToast("Erreur lors de la publication", 'error');
    } finally {
      setSubmitting(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <Loader2 className="w-10 h-10 animate-spin text-[#ff6600]" />
      </div>
    );
  }

  if (reviews.length === 0) {
    return (
      <div className="text-center py-20 bg-white bg-white dark:bg-gray-900 border border-gray-100 dark:border-gray-800 dark:border-white/10 rounded-3xl shadow-sm">
        <MessageSquare className="w-16 h-16 text-gray-300 dark:text-gray-600 mx-auto mb-6" />
        <h3 className="text-xl font-bold text-gray-900 text-gray-900 dark:text-white mb-2 tracking-tight">Aucun avis encore</h3>
        <p className="text-gray-500 text-gray-500 dark:text-gray-400 font-medium">Les avis de vos clients apparaîtront ici.</p>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between mb-8 gap-4">
        <div>
          <h2 className="text-2xl md:text-3xl font-bold text-gray-900 text-gray-900 dark:text-white tracking-tight">Feedback Clients</h2>
          <p className="text-sm font-medium text-gray-500 text-gray-500 dark:text-gray-400 mt-2">Gérez votre réputation en direct</p>
        </div>
        <div className="flex items-center gap-6 bg-white bg-white dark:bg-gray-900 py-4 px-6 rounded-2xl shadow-sm border border-gray-100 dark:border-gray-800 dark:border-white/10">
           <div className="text-center">
              <div className="text-xl font-bold text-gray-900 text-gray-900 dark:text-white">
                {(reviews.reduce((acc, r) => acc + r.rating, 0) / reviews.length).toFixed(1)}
              </div>
              <div className="text-xs font-medium text-gray-500 text-gray-500 dark:text-gray-400 uppercase tracking-wider">Moyenne</div>
           </div>
           <div className="w-[1px] h-8 bg-gray-200 dark:bg-gray-800"></div>
           <div className="text-center">
              <div className="text-xl font-bold text-gray-900 text-gray-900 dark:text-white">
                {reviews.length}
              </div>
              <div className="text-xs font-medium text-gray-500 text-gray-500 dark:text-gray-400 uppercase tracking-wider">Total</div>
           </div>
        </div>
      </div>

      <div className="grid grid-cols-1 gap-6">
        {reviews.map((review) => (
          <div key={review.id} className="bg-white bg-white dark:bg-gray-900 border border-gray-100 dark:border-gray-800 dark:border-white/10 rounded-3xl p-6 md:p-8 shadow-sm">
            <div className="flex flex-col md:flex-row gap-6 md:gap-8">
              {/* Product Info */}
              <div className="md:w-48 shrink-0">
                 <div className="aspect-square bg-gray-50 bg-gray-50 dark:bg-gray-800 rounded-xl mb-4 overflow-hidden shadow-sm">
                    <img src={review.products?.image_urls?.[0]} alt="" className="w-full h-full object-cover" />
                 </div>
                 <h4 className="text-sm font-semibold text-gray-900 text-gray-900 dark:text-white mb-1 truncate">{review.products?.title}</h4>
                 <div className="flex gap-1">
                    {[1, 2, 3, 4, 5].map(i => (
                      <Star key={i} className={`w-3.5 h-3.5 ${i <= review.rating ? 'fill-yellow-400 text-yellow-400' : 'text-gray-200 dark:text-gray-700'}`} />
                    ))}
                 </div>
              </div>

              {/* Review Content */}
              <div className="flex-1">
                <div className="flex items-center justify-between mb-4">
                   <div className="flex items-center gap-3">
                      <div className="w-10 h-10 bg-gray-100 dark:bg-gray-800 rounded-full overflow-hidden">
                         <img src={review.avatar_url || `https://api.dicebear.com/7.x/initials/svg?seed=${review.user_name || 'U'}`} alt="" className="w-full h-full object-cover" />
                      </div>
                      <div>
                         <h5 className="text-sm font-bold text-gray-900 text-gray-900 dark:text-white">{review.user_name}</h5>
                         <div className="flex items-center gap-1.5 text-xs font-medium text-gray-500 text-gray-500 dark:text-gray-400">
                           <MapPin className="w-3 h-3" /> {review.location || 'Guinée'} • {new Date(review.created_at).toLocaleDateString()}
                         </div>
                      </div>
                   </div>
                   <div className="hidden md:flex items-center gap-1.5 px-2.5 py-1 bg-emerald-50 dark:bg-emerald-500/10 text-emerald-700 dark:text-emerald-400 rounded-full">
                      <CheckCircle className="w-3.5 h-3.5" />
                      <span className="text-xs font-semibold">Achat Vérifié</span>
                   </div>
                </div>

                <p className="text-base text-gray-700 dark:text-gray-300 leading-relaxed mb-6">
                  "{review.comment}"
                </p>

                {review.shop_response ? (
                  <div className="bg-orange-50 dark:bg-[#ff6600]/10 border border-orange-100 dark:border-orange-500/20 rounded-2xl p-5 relative">
                     <div className="text-xs font-bold text-[#ff6600] mb-2">
                        Votre Réponse
                     </div>
                     <p className="text-sm text-gray-700 dark:text-gray-300 leading-relaxed">
                        {review.shop_response}
                     </p>
                  </div>
                ) : (
                  <div className="mt-4">
                    {replyingTo === review.id ? (
                      <div className="space-y-4 animate-in fade-in slide-in-from-top-2">
                        <textarea
                          placeholder="Écrivez votre réponse professionnelle..."
                          value={replyText}
                          onChange={(e) => setReplyText(e.target.value)}
                          className="w-full bg-white dark:bg-gray-900 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 dark:border-white/10 rounded-xl p-4 text-sm font-medium text-gray-900 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-[#ff6600] dark:focus:ring-[#ff6600] focus:border-transparent min-h-[100px] resize-none transition-all placeholder:text-gray-400"
                        />
                        <div className="flex gap-3">
                           <button 
                             onClick={() => setReplyingTo(null)}
                             className="px-5 py-2.5 bg-gray-50 dark:bg-gray-800 dark:bg-gray-700/50 text-gray-700 dark:text-gray-300 rounded-xl text-sm font-semibold hover:bg-gray-100 dark:hover:bg-gray-700 transition-all font-sans"
                           >
                             Annuler
                           </button>
                           <button 
                             onClick={() => handleReply(review.id)}
                             disabled={submitting || !replyText.trim()}
                             className="flex-1 bg-[#ff6600] text-white rounded-xl py-2.5 text-sm font-semibold hover:bg-[#e62e00] transition-all flex items-center justify-center gap-2 font-sans disabled:opacity-50"
                           >
                             {submitting ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
                             Publier la Réponse
                           </button>
                        </div>
                      </div>
                    ) : (
                      <button 
                        onClick={() => setReplyingTo(review.id)}
                        className="flex items-center gap-2 text-sm font-semibold text-[#ff6600] hover:text-[#e62e00] transition-colors py-2"
                      >
                        <MessageSquare className="w-4 h-4" /> Répondre à cet avis
                      </button>
                    )}
                  </div>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
