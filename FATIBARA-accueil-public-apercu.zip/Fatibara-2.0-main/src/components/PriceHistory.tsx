import { useEffect, useState } from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { useStore } from '../store/useStore';
import { TrendingDown, Info } from 'lucide-react';
import { motion } from 'motion/react';
import { supabase } from '../lib/supabase';
import { APP_NAME } from '../lib/constants';

interface PricePoint {
  date: string;
  price: number;
}

export default function PriceHistory({ productId, currentPrice }: { productId: string; currentPrice: number }) {
  const { modeEconomie } = useStore();
  const [data, setData] = useState<PricePoint[]>([]);

  useEffect(() => {
    async function fetchHistory() {
      const { data: dbData } = await supabase
        .from('price_history')
        .select('price, recorded_at')
        .eq('product_id', productId)
        .order('recorded_at', { ascending: true });

      if (dbData && dbData.length > 0) {
        setData(dbData.map(d => ({
          date: new Date(d.recorded_at).toLocaleDateString('fr-FR', { month: 'short' }),
          price: d.price
        })));
      } else {
        setData([]);
      }
    }
    
    if (productId) fetchHistory();
  }, [productId, currentPrice]);

  const minPrice = data.length > 0 ? Math.min(...data.map(d => d.price)) : currentPrice;
  const isBestPrice = currentPrice <= minPrice;

  if (modeEconomie) return null;

  return (
    <div className="bg-white dark:bg-gray-900 rounded-[2rem] border border-brand-border/50 p-6 md:p-8 shadow-sm">
      <div className="flex items-center justify-between mb-8">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-[#ff6600]/10 rounded-full flex items-center justify-center text-[#ff6600]">
            <TrendingDown className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-[15px] font-bold text-gray-900 dark:text-white tracking-tighter uppercase">Historique des Prix</h3>
            <p className="text-[12px] text-gray-900/60 font-bold uppercase tracking-[1px]">Évolution sur 4 mois</p>
          </div>
        </div>
        {isBestPrice && (
          <div className="bg-emerald-500/10 text-emerald-700 px-3 py-1.5 rounded-full text-[10px] font-bold tracking-wider flex items-center gap-1.5 border border-emerald-500/20 shadow-sm">
            <span className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse" /> Meilleur Prix
          </div>
        )}
      </div>

      <div className="h-[200px] w-full mt-4 flex items-center justify-center">
        {data.length > 0 ? (
          <ResponsiveContainer width="100%" height="100%" minWidth={0} minHeight={0}>
            <LineChart data={data}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f3f4f6" />
              <XAxis 
                dataKey="date" 
                axisLine={false} 
                tickLine={false} 
                tick={{ fontSize: 10, fill: '#9ca3af', fontWeight: 'bold' }} 
                dy={10}
              />
              <YAxis hide domain={['dataMin - 10000', 'dataMax + 10000']} />
              <Tooltip 
                content={({ active, payload }) => {
                  if (active && payload && payload.length) {
                    return (
                      <div className="bg-gray-900 text-brand-inverse p-4 rounded-[1.5rem] shadow-2xl border border-white/10 backdrop-blur-md">
                        <p className="text-[9px] font-bold tracking-wider text-brand-inverse/50 mb-1">{payload[0].payload.date}</p>
                        <p className="text-[14px] font-bold tracking-tighter">{payload[0].value?.toLocaleString()} GNF</p>
                      </div>
                    );
                  }
                  return null;
                }}
              />
              <Line 
                type="monotone" 
                dataKey="price" 
                stroke="#ff6600" 
                strokeWidth={3} 
                dot={{ fill: '#ff6600', strokeWidth: 2, r: 4, stroke: '#fff' }} 
                activeDot={{ r: 6, strokeWidth: 0 }}
                animationDuration={2000}
              />
            </LineChart>
          </ResponsiveContainer>
        ) : (
          <div className="text-center">
            <p className="text-[11px] text-gray-900/50 font-bold tracking-wider">Pas assez de données historiques</p>
          </div>
        )}
      </div>

      <div className="mt-8 pt-6 border-t border-brand-border/20">
        <div className="flex items-start gap-3">
          <Info className="w-4 h-4 mt-0.5 flex-shrink-0 text-[#ff6600]" />
          <p className="text-[11px] font-bold uppercase tracking-tighter leading-relaxed text-gray-900/70">
            Nous analysons les prix sur {APP_NAME} pour vous aider à acheter au meilleur moment. Ce graphique montre la moyenne des prix pour ce modèle chez l'ensemble de nos vendeurs vérifiés.
          </p>
        </div>
      </div>
    </div>
  );
}
