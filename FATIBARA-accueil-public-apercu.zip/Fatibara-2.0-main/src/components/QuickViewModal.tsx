import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, ShoppingCart, Store, ChevronLeft, ChevronRight, Check, Eye, Share2, Zap, ArrowRight, MessageCircle } from 'lucide-react';
import { Product } from './ProductCard';
import { useAppContext } from '../context/AppContext';
import { useStore } from '../store/useStore';
import { useCommerceStore } from '../store/useCommerceStore';
import { useToast } from '../context/ToastContext';
import { useNavigate } from 'react-router-dom';
import { hapticFeedback } from '../lib/haptics';
import { shareProduct } from '../lib/share';
import { calculateProductPrice } from '../utils/pricing';

interface QuickViewModalProps {
  isOpen: boolean;
  onClose: () => void;
  product: Product | null;
}

export default function QuickViewModal({ isOpen, onClose, product }: QuickViewModalProps) {
  const { proMode, user, openChat } = useAppContext();
  const { modeEconomie } = useStore();
  const { showToast } = useToast();
  const { addToCart } = useCommerceStore();
  const navigate = useNavigate();
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const [selectedVariations, setSelectedVariations] = useState<Record<string, string>>({});
  const [quantity, setQuantity] = useState(1);

  if (!product) return null;

  const handleChat = async () => {
    if (!product.stores?.id) {
      showToast("Boutique introuvable", "error");
      return;
    }
    await openChat(product.stores.id, product.title, undefined, product.id);
  };

  const priceInfo = React.useMemo(() => {
    return calculateProductPrice(product, quantity, proMode, selectedVariations);
  }, [product, quantity, proMode, selectedVariations]);

  const displayPrice = priceInfo.finalPrice;

  const handleVariationSelect = (variationId: string, option: string) => {
    setSelectedVariations(prev => ({ ...prev, [variationId]: option }));
  };

  const nextImage = () => {
    if (product.image_urls) {
      setCurrentImageIndex((prev) => (prev + 1) % product.image_urls.length);
    }
  };

  const prevImage = () => {
    if (product.image_urls) {
      setCurrentImageIndex((prev) => (prev - 1 + product.image_urls.length) % product.image_urls.length);
    }
  };

  const handleAddToCart = () => {
    const allSelected = product.variations?.every(v => selectedVariations[v.id]) ?? true;
    if (!allSelected) {
      hapticFeedback('error');
      showToast("Veuillez sélectionner toutes les options.", "info");
      return;
    }
    hapticFeedback('success');
    addToCart(product.id, quantity, user?.id);
    showToast(`Ajouté au panier: ${quantity}x ${product.title}`, "success");
    onClose();
  };

  const handleBuyNow = () => {
    const allSelected = product.variations?.every(v => selectedVariations[v.id]) ?? true;
    if (!allSelected) {
      hapticFeedback('error');
      showToast("Veuillez sélectionner toutes les options.", "info");
      return;
    }
    hapticFeedback('reward');
    onClose();
    navigate(`/checkout/${product.id}?qty=${quantity}`);
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/60 backdrop-blur-md z-[200]"
          />
          
          {/* Modal Container */}
          <motion.div
            initial={{ opacity: 0, scale: 0.9, y: 40 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9, y: 40 }}
            className="fixed inset-4 md:inset-auto md:left-1/2 md:top-1/2 md:-translate-x-1/2 md:-translate-y-1/2 md:w-[900px] md:max-h-[90vh] bg-white dark:bg-gray-900 dark:bg-gray-950 rounded-[3rem] shadow-2xl z-[201] overflow-hidden flex flex-col md:flex-row border border-brand-border/30 dark:border-white/10"
          >
            {/* Close & Share Buttons */}
            <div className="absolute top-6 right-6 flex items-center gap-3 z-20">
              <button 
                onClick={async () => {
                  try {
                    const productUrl = `${window.location.origin}/product/${product.id}`;
                    await shareProduct(product.title, productUrl, showToast);
                  } catch (err) { }
                }}
                className="p-4 bg-white/90 dark:bg-gray-800/90 backdrop-blur-md text-gray-900 text-gray-900 dark:text-white rounded-full shadow-lg hover:scale-110 active:scale-95 transition-all outline-none"
              >
                <Share2 className="w-6 h-6" />
              </button>
              <button 
                onClick={onClose}
                className="p-4 bg-gray-900 dark:bg-[#ff6600] text-brand-inverse rounded-full shadow-lg hover:scale-110 active:scale-95 transition-all outline-none"
              >
                <X className="w-6 h-6" />
              </button>
            </div>

            {/* Left Column: Image Gallery */}
            <div className="w-full md:w-1/2 relative bg-gray-50 dark:bg-gray-800 dark:bg-gray-900 border-r border-brand-border/30 dark:border-white/5">
              <div className="aspect-square relative flex items-center justify-center overflow-hidden h-full">
                <AnimatePresence mode="wait">
                  <motion.img
                    key={currentImageIndex}
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: -20 }}
                    src={product.image_urls?.[currentImageIndex] || 'https://picsum.photos/seed/fallback/600/600'}
                    alt={product.title}
                    className="w-full h-full object-cover"
                    referrerPolicy="no-referrer"
                  />
                </AnimatePresence>

                {product.image_urls && product.image_urls.length > 1 && (
                  <>
                    <button 
                      onClick={prevImage}
                      className="absolute left-4 p-4 bg-white/80 dark:bg-gray-800/80 backdrop-blur-md rounded-full shadow-md hover:bg-white dark:bg-gray-900 dark:hover:bg-gray-700 transition-all min-h-[44px]"
                    >
                      <ChevronLeft className="w-6 h-6" />
                    </button>
                    <button 
                      onClick={nextImage}
                      className="absolute right-4 p-4 bg-white/80 dark:bg-gray-800/80 backdrop-blur-md rounded-full shadow-md hover:bg-white dark:bg-gray-900 dark:hover:bg-gray-700 transition-all min-h-[44px]"
                    >
                      <ChevronRight className="w-6 h-6" />
                    </button>
                  </>
                )}
              </div>
              
              {/* Image Indicators */}
              {product.image_urls && product.image_urls.length > 1 && (
                <div className="absolute bottom-6 left-1/2 -translate-x-1/2 flex gap-2">
                  {product.image_urls.map((_, i) => (
                    <div 
                      key={i} 
                      className={`h-1.5 rounded-full transition-all ${i === currentImageIndex ? 'w-8 bg-[#ff6600]' : 'w-2 bg-gray-900/20 dark:bg-white/10'}`} 
                    />
                  ))}
                </div>
              )}
            </div>

            {/* Right Column: Details */}
            <div className="flex-1 p-8 md:p-12 overflow-y-auto no-scrollbar dark:bg-gray-950">
              <div className="flex items-center gap-3 mb-4">
                <span className="bg-[#ff6600] text-brand-inverse px-4 py-1.5 rounded-full text-[11px] font-bold tracking-wider">
                  {product.category || 'EXCLUSIF'}
                </span>
                <div className="flex items-center gap-1 text-green-600 dark:text-green-400 text-[10px] font-bold tracking-wider">
                  <Check className="w-3.5 h-3.5" /> En stock
                </div>
              </div>

              <h2 className="text-3xl font-bold text-gray-900 text-gray-900 dark:text-white tracking-tight mb-4 leading-tight uppercase">
                {product.title}
              </h2>

              <div className="flex items-center gap-3 mb-8">
                {product.stores?.avatar_url ? (
                  <img src={product.stores.avatar_url} className="w-6 h-6 rounded-full border border-brand-border dark:border-white/10" alt="" />
                ) : (
                  <Store className="w-6 h-6 text-gray-900/40 dark:text-white/20" />
                )}
                <span className="text-[13px] font-bold text-gray-900 dark:text-white dark:text-gray-300 uppercase tracking-tight">
                  Vendu par <span className="text-[#ff6600] dark:text-orange-400">{product.stores?.store_name}</span>
                </span>
              </div>

              <div className="text-4xl font-bold text-gray-900 text-gray-900 dark:text-white mb-8 border-b border-brand-border/30 dark:border-white/5 pb-8 flex items-end gap-3 tracking-tighter">
                {(displayPrice || 0).toLocaleString()} <span className="text-xl font-bold text-gray-900/40 dark:text-gray-500 dark:text-gray-400 tracking-wider">GNF</span>
                {proMode && <span className="text-[10px] bg-brand-secondary/10 text-brand-secondary border border-brand-secondary/20 px-3 py-1 tracking-wider font-bold rounded-md mb-2">PRIX PRO</span>}
              </div>

              {/* Stock Indicator */}
              <div className="mb-8 p-6 bg-gray-50 dark:bg-gray-800 dark:bg-gray-900 rounded-[2.5rem] border border-brand-border/30 dark:border-white/5">
                <div className="flex justify-between items-center mb-3">
                  <span className="text-[11px] font-bold text-gray-900 text-gray-900 dark:text-white tracking-wider">Stocks disponibles</span>
                  <span className={`text-[11px] font-bold uppercase tracking-[1px] ${
                    (product.stock_count ?? 100) === 0 ? 'text-red-600' : 
                    (product.stock_count ?? 100) <= 50 ? 'text-orange-600' : 'text-green-600'
                  }`}>
                    {(product.stock_count ?? 100) > 0 ? `${product.stock_count ?? 100} ARTICLES` : 'Rupture'}
                  </span>
                </div>
                <div className="h-2.5 w-full bg-white dark:bg-gray-900 dark:bg-gray-800 rounded-full overflow-hidden border border-brand-border/20 dark:border-white/5">
                  <motion.div
                    initial={{ width: 0 }}
                    animate={{ width: `${Math.min(100, ((product.stock_count ?? 100) / (product.max_stock ?? 100)) * 100)}%` }}
                    transition={{ duration: 1.2, ease: "circOut" }}
                    className={`h-full rounded-full ${
                      (product.stock_count ?? 100) === 0 ? 'bg-red-500' : 
                      (product.stock_count ?? 100) <= 50 ? 'bg-orange-500' : 'bg-green-500'
                    }`}
                  />
                </div>
              </div>

              <div className="space-y-8 mb-10">
                {/* Variations */}
                {product.variations?.map((v) => (
                  <div key={v.id}>
                    <label className="block text-[10px] font-bold text-gray-900/40 dark:text-gray-500 dark:text-gray-400 tracking-wider mb-4">Selectionnez {v.type}</label>
                    <div className="flex flex-wrap gap-4">
                      {v.options.map((opt) => {
                        const isColor = v.type.toLowerCase() === 'couleur';
                        const isSelected = selectedVariations[v.id] === opt.label;

                        return (
                          <button
                            key={opt.label}
                            onClick={() => handleVariationSelect(v.id, opt.label)}
                            title={opt.label}
                            className={`group relative transition-all duration-300 min-h-[44px] ${
                              isColor 
                                ? `w-12 h-12 rounded-full border ${isSelected ? 'border-[#ff6600] scale-110 shadow-lg' : 'border-transparent dark:border-white/10 hover:border-brand-border'}`
                                : `px-6 py-4 rounded-2xl text-[13px] font-bold transition-all border tracking-wider ${
                                    isSelected
                                      ? 'bg-gray-900 dark:bg-[#ff6600] text-brand-inverse border-gray-200 dark:border-gray-700 dark:border-orange-400 scale-105 shadow-md'
                                      : 'bg-white bg-white dark:bg-gray-900 text-gray-900 dark:text-white dark:text-gray-300 border-brand-border/40 dark:border-white/10 hover:border-[#ff6600]'
                                  }`
                            }`}
                          >
                            {isColor ? (
                              <span 
                                className="absolute inset-1 rounded-full border border-gray-200/10 transition-transform group-hover:scale-95 shadow-inner" 
                                style={{ backgroundColor: opt.value }}
                              />
                            ) : (
                              opt.label
                            )}
                          </button>
                        );
                      })}
                    </div>
                  </div>
                ))}

                {/* Description */}
                <div>
                  <label className="block text-[10px] font-bold text-gray-900/40 dark:text-gray-500 dark:text-gray-400 tracking-wider mb-3">Détails</label>
                  <p className="text-[14px] text-gray-900/70 dark:text-gray-400 leading-relaxed font-medium uppercase tracking-tight">
                    {product.description}
                  </p>
                </div>
              </div>

              {/* Action Bar */}
              <div className="flex flex-col gap-4 pt-8 border-t border-brand-border/30 dark:border-white/5 sticky bottom-0 bg-white dark:bg-gray-900 dark:bg-gray-950 pb-2">
                <div className="flex items-center gap-4">
                  <div className="flex items-center bg-gray-50 dark:bg-gray-800 dark:bg-gray-900 p-2 rounded-2xl border border-brand-border/50 dark:border-white/10">
                    <button 
                      onClick={() => setQuantity(Math.max(1, quantity - 1))}
                      className="p-4 hover:bg-white dark:bg-gray-900 dark:hover:bg-gray-800 rounded-xl transition-all font-bold text-xl min-h-[44px] min-w-[44px] dark:text-white"
                    >
                      -
                    </button>
                    <span className="w-12 text-center font-bold text-[15px] dark:text-white">{quantity}</span>
                    <button 
                      onClick={() => setQuantity(quantity + 1)}
                      className="p-4 hover:bg-white dark:bg-gray-900 dark:hover:bg-gray-800 rounded-xl transition-all font-bold text-xl min-h-[44px] min-w-[44px] dark:text-white"
                    >
                      +
                    </button>
                  </div>

                  <button
                    onClick={handleChat}
                    className="p-5 bg-white dark:bg-gray-800 border border-brand-border/50 dark:border-white/10 rounded-2xl flex items-center justify-center text-gray-900 text-gray-900 dark:text-white hover:bg-gray-50 dark:bg-gray-900 dark:hover:bg-gray-700 transition-all min-h-[60px] min-w-[60px]"
                    title="Contacter le vendeur"
                  >
                    <MessageCircle className="w-6 h-6" />
                  </button>

                  <button
                    onClick={handleAddToCart}
                    className="flex-1 flex items-center justify-center gap-3 bg-gray-50 dark:bg-gray-800 dark:bg-gray-900 text-gray-900 text-gray-900 dark:text-white border border-brand-border/50 dark:border-white/10 py-5 rounded-[2.5rem] text-[13px] font-bold tracking-wider hover:bg-white dark:bg-gray-900 dark:hover:bg-gray-800 transition-all min-h-[60px]"
                  >
                    <ShoppingCart className="w-5 h-5" />
                    Ajouter
                  </button>
                </div>

                <button
                  onClick={handleBuyNow}
                  className="w-full flex items-center justify-center gap-3 bg-gray-900 dark:bg-[#ff6600] text-brand-inverse py-6 rounded-[2.5rem] text-[14px] font-bold tracking-wider shadow-2xl shadow-brand-foreground/20 dark:shadow-orange-950/40 hover:bg-black dark:hover:bg-[#ff6600] transition-all group/btn min-h-[64px]"
                >
                  <Zap className="w-5 h-5 text-[#ff6600]" />
                  Acheter maintenant
                  <ArrowRight className="w-5 h-5 group-hover/btn:translate-x-2 transition-transform" />
                </button>
              </div>
            </div>
          </motion.div>

        </>
      )}
    </AnimatePresence>
  );
}
