import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ShoppingBag, Star, Zap, MapPin } from 'lucide-react';
import { supabase } from '../lib/supabase';

interface PulseEvent {
  id: string;
  user: string;
  action: string;
  item: string;
  location: string;
}

export default function LivePulse() {
  const [pulseEvents, setPulseEvents] = useState<PulseEvent[]>([]);
  const [event, setEvent] = useState<PulseEvent | null>(null);
  const [index, setIndex] = useState(0);

  useEffect(() => {
    async function loadRecentEvents() {
      try {
        const { data: products } = await supabase
          .from('products')
          .select('id, title, stores(store_name, location_commune)')
          .order('created_at', { ascending: false })
          .limit(10);
        
        if (products && products.length > 0) {
          const events: PulseEvent[] = products.map((p: any) => ({
            id: p.id,
            user: p.stores?.store_name || 'Un membre',
            action: 'vient de publier',
            item: p.title,
            location: p.stores?.location_commune || 'Conakry'
          }));
          setPulseEvents(events);
        }
      } catch (err) {
        console.error('Pulse logic error', err);
      }
    }
    loadRecentEvents();

    // REAL-TIME PULSE: Listen for anonymized pulse events
    const channel = supabase
      .channel('global-pulse')
      .on(
        'postgres_changes',
        { event: 'INSERT', schema: 'public', table: 'public_pulse_events' },
        (payload) => {
          const newPulse = payload.new;
          const newEvent: PulseEvent = {
            id: newPulse.id,
            user: newPulse.user_name,
            action: 'vient de commander',
            item: newPulse.item_name,
            location: newPulse.location
          };
          setPulseEvents(prev => [newEvent, ...prev].slice(0, 15));
          setEvent(newEvent);
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, []);

  useEffect(() => {
    if (pulseEvents.length === 0) return;

    const timer = setInterval(() => {
      setEvent(pulseEvents[index]);
      setIndex((prev) => (prev + 1) % pulseEvents.length);
      
      // Auto-hide after 5 seconds
      setTimeout(() => setEvent(null), 5000);
    }, 12000);

    return () => clearInterval(timer);
  }, [index, pulseEvents]);

  return (
    <div className="fixed bottom-24 left-6 z-[60] pointer-events-none hidden md:block">
      <AnimatePresence>
        {event && (
          <motion.div
            initial={{ opacity: 0, y: 100, scale: 0.9, filter: 'blur(10px)' }}
            animate={{ opacity: 1, y: 0, scale: 1, filter: 'blur(0px)' }}
            exit={{ opacity: 0, scale: 0.95, filter: 'blur(5px)' }}
            transition={{ type: 'spring', damping: 20, stiffness: 100 }}
            className="group pointer-events-auto"
          >
            <div className="bg-white/80 dark:bg-gray-950/80 backdrop-blur-3xl p-5 pr-10 rounded-[2.5rem] shadow-[0_32px_64px_-16px_rgba(0,0,0,0.3)] flex items-center gap-6 border border-white/20 dark:border-white/5 relative overflow-hidden">
               {/* Animated Pulse Ring */}
               <div className="absolute inset-0 bg-gradient-to-r from-[#ff6600]/5 to-transparent animate-pulse" />

               <div className="w-14 h-14 bg-gray-900 dark:bg-brand-primary rounded-2xl flex items-center justify-center shrink-0 shadow-2xl relative group-hover:scale-110 transition-transform duration-500 overflow-hidden">
                 <div className="absolute inset-0 bg-gradient-to-tr from-white/20 to-transparent" />
                 {event.action.includes('commander') ? <ShoppingBag className="w-7 h-7 text-white" /> : <Zap className="w-7 h-7 text-white" />}
               </div>
               
               <div className="flex flex-col relative z-10">
                 <span className="text-[10px] font-black uppercase tracking-[0.3em] text-[#ff6600] mb-1">Direct Live</span>
                 <p className="text-[14px] font-bold text-gray-900 dark:text-white leading-none mb-1">
                   {event.user} <span className="font-medium lowercase text-gray-500">{event.action}</span>
                 </p>
                 <p className="text-[16px] font-black tracking-tighter uppercase text-gray-900 dark:text-white truncate max-w-[200px] italic">
                   {event.item}
                 </p>
                 <div className="flex items-center gap-2 mt-3 text-[10px] font-bold text-gray-400 uppercase tracking-widest">
                   <MapPin className="w-3 h-3 text-[#ff6600]" /> {event.location}
                 </div>
               </div>

               {/* Modern Progress Line */}
               <div className="absolute bottom-0 left-0 right-0 h-1 bg-gray-100 dark:bg-white/5">
                  <motion.div 
                    initial={{ width: '0%' }}
                    animate={{ width: '100%' }}
                    transition={{ duration: 5, ease: 'linear' }}
                    className="h-full bg-[#ff6600]"
                  />
               </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
