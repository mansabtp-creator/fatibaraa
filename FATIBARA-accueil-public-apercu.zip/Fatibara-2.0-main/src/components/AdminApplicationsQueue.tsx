import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Store, Truck, CheckCircle, XCircle, FileText, Clock,
  MapPin, MessageCircle, Inbox, ChevronDown, ChevronUp, AlertTriangle
} from 'lucide-react';
import { supabase } from '../lib/supabase';
import { useToast } from '../context/ToastContext';

// ── Types ────────────────────────────────────────────────────────────────────

interface PendingVendor {
  id: string;
  store_name: string;
  store_category: string;
  location_commune: string;
  description: string;
  avatar_url: string | null;
  logo_url: string | null;
  verification_document_url: string | null;
  is_verified_store: boolean;
  store_status: string;
  created_at: string;
  // owner profile joined
  owner_phone?: string;
  owner_email?: string;
  owner_name?: string;
}

interface PendingCourier {
  id: string;
  full_name: string | null;
  email: string;
  phone: string | null;
  phone_number: string | null;
  courier_zone: string | null;
  avatar_url: string | null;
  courier_status: string;
  courier_terms_accepted_at: string | null;
  created_at: string;
}

interface Props {
  pendingVendors: PendingVendor[];
  pendingCouriers: PendingCourier[];
  supportWhatsapp: string;
  onRefresh: () => void;
  onLogAction: (action: string, entity: string, id: string, details: Record<string, unknown>) => void;
  askPrompt: (title: string, desc?: string) => Promise<string | null>;
}

// ── Helpers ──────────────────────────────────────────────────────────────────

function timeAgo(iso: string) {
  const ms = Date.now() - new Date(iso).getTime();
  const h = Math.floor(ms / 3_600_000);
  if (h < 1) return 'À l\'instant';
  if (h < 24) return `Il y a ${h}h`;
  return `Il y a ${Math.floor(h / 24)}j`;
}

function waLink(phone: string, message: string) {
  const num = phone.replace(/\D/g, '');
  return `https://wa.me/${num}?text=${encodeURIComponent(message)}`;
}

// ── Vendor Card ──────────────────────────────────────────────────────────────

function VendorApplicationCard({
  vendor, supportWhatsapp, onApprove, onReject,
}: {
  vendor: PendingVendor;
  supportWhatsapp: string;
  onApprove: (id: string) => Promise<void>;
  onReject: (id: string) => Promise<void>;
}) {
  const [busy, setBusy] = useState<'approve' | 'reject' | null>(null);
  const [docLoading, setDocLoading] = useState(false);
  const [expanded, setExpanded] = useState(false);

  const viewDoc = async () => {
    if (!vendor.verification_document_url) return;
    setDocLoading(true);
    const { data } = await supabase.storage
      .from('verification-documents')
      .createSignedUrl(vendor.verification_document_url, 600);
    if (data?.signedUrl) window.open(data.signedUrl, '_blank');
    setDocLoading(false);
  };

  const phone = vendor.owner_phone || '';
  const approveWa = phone
    ? waLink(phone, `Bonjour ${vendor.owner_name || vendor.store_name} ! Votre boutique "${vendor.store_name}" a été approuvée sur Fatibara. Vous pouvez maintenant ajouter vos produits. 🎉`)
    : null;

  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.97 }}
      className="bg-white dark:bg-[#111622] border border-amber-500/30 dark:border-amber-500/20 rounded-3xl overflow-hidden shadow-sm"
    >
      {/* Orange top stripe */}
      <div className="h-1 w-full bg-gradient-to-r from-amber-400 to-orange-500" />

      <div className="p-5">
        {/* Header */}
        <div className="flex items-start justify-between gap-3 mb-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-slate-100 dark:bg-black/20 border border-slate-200 dark:border-white/10 flex items-center justify-center overflow-hidden shrink-0">
              {vendor.avatar_url || vendor.logo_url
                ? <img src={vendor.avatar_url || vendor.logo_url!} alt="" className="w-full h-full object-cover" />
                : <Store className="w-6 h-6 text-orange-500" />
              }
            </div>
            <div>
              <h3 className="font-extrabold text-slate-800 dark:text-white text-sm tracking-tight">{vendor.store_name || 'Sans nom'}</h3>
              <p className="text-[10px] font-semibold text-slate-400 dark:text-white/30 uppercase tracking-wider">{vendor.store_category || 'Catégorie ?'}</p>
            </div>
          </div>
          <div className="flex flex-col items-end gap-1 shrink-0">
            <span className="flex items-center gap-1 text-[9px] font-bold text-amber-600 dark:text-amber-400 bg-amber-500/10 border border-amber-500/20 px-2 py-0.5 rounded-full">
              <Clock className="w-2.5 h-2.5" /> EN ATTENTE
            </span>
            <span className="text-[9px] text-slate-300 dark:text-white/20">{timeAgo(vendor.created_at)}</span>
          </div>
        </div>

        {/* Meta */}
        <div className="flex flex-wrap gap-1.5 mb-4">
          {vendor.location_commune && (
            <span className="flex items-center gap-1 text-[10px] font-semibold text-slate-500 dark:text-white/30 bg-slate-50 dark:bg-white/5 border border-slate-200 dark:border-white/10 px-2 py-0.5 rounded-md">
              <MapPin className="w-2.5 h-2.5" /> {vendor.location_commune}
            </span>
          )}
          {phone && (
            <span className="text-[10px] font-semibold text-slate-500 dark:text-white/30 bg-slate-50 dark:bg-white/5 border border-slate-200 dark:border-white/10 px-2 py-0.5 rounded-md">
              📞 {phone}
            </span>
          )}
          {vendor.verification_document_url ? (
            <span className="flex items-center gap-1 text-[10px] font-bold text-sky-600 dark:text-sky-400 bg-sky-500/10 border border-sky-500/20 px-2 py-0.5 rounded-md">
              <FileText className="w-2.5 h-2.5" /> Document soumis
            </span>
          ) : (
            <span className="flex items-center gap-1 text-[10px] font-bold text-rose-500 bg-rose-500/10 border border-rose-500/20 px-2 py-0.5 rounded-md">
              <AlertTriangle className="w-2.5 h-2.5" /> Pas de document
            </span>
          )}
        </div>

        {/* Expandable description */}
        {vendor.description && (
          <button
            onClick={() => setExpanded(v => !v)}
            className="flex items-center gap-1 text-[10px] font-bold text-slate-400 hover:text-slate-600 dark:hover:text-white/50 mb-3 transition-colors"
          >
            {expanded ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
            {expanded ? 'Masquer' : 'Description'}
          </button>
        )}
        <AnimatePresence>
          {expanded && vendor.description && (
            <motion.p
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: 'auto', opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              className="text-[11px] text-slate-500 dark:text-white/30 leading-relaxed mb-3 overflow-hidden"
            >
              {vendor.description}
            </motion.p>
          )}
        </AnimatePresence>

        {/* Actions */}
        <div className="grid grid-cols-2 gap-2 mt-2">
          {/* View document */}
          <button
            onClick={viewDoc}
            disabled={!vendor.verification_document_url || docLoading}
            className="flex items-center justify-center gap-1.5 py-2.5 rounded-xl text-[10px] font-bold uppercase tracking-wider border border-slate-200 dark:border-white/10 text-slate-500 dark:text-white/40 hover:border-sky-400 hover:text-sky-500 transition-all disabled:opacity-30 disabled:cursor-not-allowed col-span-2"
          >
            <FileText className="w-3.5 h-3.5" />
            {docLoading ? 'Chargement…' : 'Voir le Document d\'Identité'}
          </button>

          {/* Reject */}
          <button
            onClick={async () => { setBusy('reject'); await onReject(vendor.id); setBusy(null); }}
            disabled={!!busy}
            className="flex items-center justify-center gap-1.5 py-3 rounded-xl text-[10px] font-black uppercase tracking-wider bg-rose-500/10 border border-rose-500/30 text-rose-600 dark:text-rose-400 hover:bg-rose-500/20 transition-all disabled:opacity-50 active:scale-95"
          >
            {busy === 'reject'
              ? <span className="w-3 h-3 border border-rose-500 border-t-transparent rounded-full animate-spin" />
              : <XCircle className="w-3.5 h-3.5" />
            }
            Refuser
          </button>

          {/* Approve */}
          <button
            onClick={async () => { setBusy('approve'); await onApprove(vendor.id); setBusy(null); }}
            disabled={!!busy}
            className="flex items-center justify-center gap-1.5 py-3 rounded-xl text-[10px] font-black uppercase tracking-wider bg-emerald-500 text-white hover:bg-emerald-600 shadow-lg shadow-emerald-500/20 transition-all disabled:opacity-50 active:scale-95"
          >
            {busy === 'approve'
              ? <span className="w-3 h-3 border border-white border-t-transparent rounded-full animate-spin" />
              : <CheckCircle className="w-3.5 h-3.5" />
            }
            Approuver
          </button>

          {/* WhatsApp notify */}
          {approveWa && (
            <a
              href={approveWa}
              target="_blank"
              rel="noopener noreferrer"
              className="col-span-2 flex items-center justify-center gap-1.5 py-2.5 rounded-xl text-[10px] font-bold uppercase tracking-wider border border-emerald-500/30 text-emerald-600 dark:text-emerald-400 hover:bg-emerald-500/10 transition-all"
            >
              <MessageCircle className="w-3.5 h-3.5" />
              Notifier via WhatsApp
            </a>
          )}
        </div>
      </div>
    </motion.div>
  );
}

// ── Courier Card ─────────────────────────────────────────────────────────────

function CourierApplicationCard({
  courier, supportWhatsapp, onApprove, onReject,
}: {
  courier: PendingCourier;
  supportWhatsapp: string;
  onApprove: (id: string) => Promise<void>;
  onReject: (id: string) => Promise<void>;
}) {
  const [busy, setBusy] = useState<'approve' | 'reject' | null>(null);
  const phone = courier.phone || courier.phone_number || '';
  const displayName = courier.full_name || courier.email?.split('@')[0] || `Livreur #${courier.id.substring(0, 6)}`;

  const approveWa = phone
    ? waLink(phone, `Bonjour ${displayName} ! Votre candidature livreur Fatibara a été approuvée. Connectez-vous maintenant pour commencer à livrer. 🚀`)
    : null;

  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.97 }}
      className="bg-white dark:bg-[#111622] border border-blue-500/30 dark:border-blue-500/20 rounded-3xl overflow-hidden shadow-sm"
    >
      <div className="h-1 w-full bg-gradient-to-r from-blue-400 to-indigo-500" />
      <div className="p-5">
        {/* Header */}
        <div className="flex items-start justify-between gap-3 mb-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-slate-100 dark:bg-black/20 border border-slate-200 dark:border-white/10 flex items-center justify-center overflow-hidden shrink-0">
              {courier.avatar_url
                ? <img src={courier.avatar_url} alt="" className="w-full h-full object-cover" />
                : <Truck className="w-6 h-6 text-blue-500" />
              }
            </div>
            <div>
              <h3 className="font-extrabold text-slate-800 dark:text-white text-sm tracking-tight">{displayName}</h3>
              <p className="text-[10px] font-semibold text-slate-400 dark:text-white/30">{courier.email}</p>
            </div>
          </div>
          <div className="flex flex-col items-end gap-1 shrink-0">
            <span className="flex items-center gap-1 text-[9px] font-bold text-blue-600 dark:text-blue-400 bg-blue-500/10 border border-blue-500/20 px-2 py-0.5 rounded-full">
              <Clock className="w-2.5 h-2.5" /> EN ATTENTE
            </span>
            <span className="text-[9px] text-slate-300 dark:text-white/20">{timeAgo(courier.created_at)}</span>
          </div>
        </div>

        {/* Meta */}
        <div className="flex flex-wrap gap-1.5 mb-4">
          {phone && (
            <span className="text-[10px] font-semibold text-slate-500 dark:text-white/30 bg-slate-50 dark:bg-white/5 border border-slate-200 dark:border-white/10 px-2 py-0.5 rounded-md">
              📞 {phone}
            </span>
          )}
          {courier.courier_zone && (
            <span className="flex items-center gap-1 text-[10px] font-semibold text-slate-500 dark:text-white/30 bg-slate-50 dark:bg-white/5 border border-slate-200 dark:border-white/10 px-2 py-0.5 rounded-md">
              <MapPin className="w-2.5 h-2.5" /> Zone : {courier.courier_zone}
            </span>
          )}
          {courier.courier_terms_accepted_at ? (
            <span className="flex items-center gap-1 text-[10px] font-bold text-emerald-600 dark:text-emerald-400 bg-emerald-500/10 border border-emerald-500/20 px-2 py-0.5 rounded-md">
              ✓ CGU acceptées
            </span>
          ) : (
            <span className="flex items-center gap-1 text-[10px] font-bold text-amber-600 dark:text-amber-400 bg-amber-500/10 border border-amber-500/20 px-2 py-0.5 rounded-md">
              ⚠ CGU non acceptées
            </span>
          )}
        </div>


        {/* Actions */}
        <div className="grid grid-cols-2 gap-2">
          <button
            onClick={async () => { setBusy('reject'); await onReject(courier.id); setBusy(null); }}
            disabled={!!busy}
            className="flex items-center justify-center gap-1.5 py-3 rounded-xl text-[10px] font-black uppercase tracking-wider bg-rose-500/10 border border-rose-500/30 text-rose-600 dark:text-rose-400 hover:bg-rose-500/20 transition-all disabled:opacity-50 active:scale-95"
          >
            {busy === 'reject'
              ? <span className="w-3 h-3 border border-rose-500 border-t-transparent rounded-full animate-spin" />
              : <XCircle className="w-3.5 h-3.5" />
            }
            Refuser
          </button>
          <button
            onClick={async () => { setBusy('approve'); await onApprove(courier.id); setBusy(null); }}
            disabled={!!busy}
            className="flex items-center justify-center gap-1.5 py-3 rounded-xl text-[10px] font-black uppercase tracking-wider bg-emerald-500 text-white hover:bg-emerald-600 shadow-lg shadow-emerald-500/20 transition-all disabled:opacity-50 active:scale-95"
          >
            {busy === 'approve'
              ? <span className="w-3 h-3 border border-white border-t-transparent rounded-full animate-spin" />
              : <CheckCircle className="w-3.5 h-3.5" />
            }
            Approuver
          </button>
          {approveWa && (
            <a
              href={approveWa}
              target="_blank"
              rel="noopener noreferrer"
              className="col-span-2 flex items-center justify-center gap-1.5 py-2.5 rounded-xl text-[10px] font-bold uppercase tracking-wider border border-emerald-500/30 text-emerald-600 dark:text-emerald-400 hover:bg-emerald-500/10 transition-all"
            >
              <MessageCircle className="w-3.5 h-3.5" />
              Notifier via WhatsApp
            </a>
          )}
        </div>
      </div>
    </motion.div>
  );
}

// ── Main Component ────────────────────────────────────────────────────────────

export default function AdminApplicationsQueue({
  pendingVendors,
  pendingCouriers,
  supportWhatsapp,
  onRefresh,
  onLogAction,
  askPrompt,
}: Props) {
  const { showToast } = useToast();
  const total = pendingVendors.length + pendingCouriers.length;

  // ── Vendor Approve ───────────────────────────────────────────────────────
  const approveVendor = async (storeId: string) => {
    const { error } = await supabase
      .from('stores')
      .update({ is_verified_store: true, store_status: 'active' })
      .eq('id', storeId);
    if (error) { showToast(`Erreur : ${error.message}`, 'error'); return; }
    onLogAction('APPROVE_VENDOR', 'store', storeId, { approved_at: new Date().toISOString() });
    showToast('Boutique approuvée ✅', 'success');
    onRefresh();
  };

  // ── Vendor Reject ────────────────────────────────────────────────────────
  const rejectVendor = async (storeId: string) => {
    const reason = await askPrompt(
      'Motif du refus',
      'Ce message sera enregistré dans le dossier de la boutique. Indiquez la raison (ex: document illisible, informations incomplètes).'
    );
    if (!reason) return;
    const { error } = await supabase
      .from('stores')
      .update({ store_status: 'rejected', rejection_reason: reason })
      .eq('id', storeId);
    if (error) { showToast(`Erreur : ${error.message}`, 'error'); return; }
    onLogAction('REJECT_VENDOR', 'store', storeId, { reason });
    showToast('Boutique refusée.', 'info');
    onRefresh();
  };

  // ── Courier Approve ──────────────────────────────────────────────────────
  const approveCourier = async (courierId: string) => {
    const approvedAt = new Date().toISOString();
    const { error } = await supabase
      .from('profiles')
      .update({
        courier_status: 'disponible',
        active_role: 'courier',
        profile_type: 'courier',
        courier_approved_at: approvedAt,
      })
      .eq('id', courierId);
    if (error) { showToast(`Erreur : ${error.message}`, 'error'); return; }
    // Sync courier_profiles
    await supabase.from('courier_profiles').upsert(
      { user_id: courierId, status: 'active', active_capacity: 1, balance: 0 },
      { onConflict: 'user_id', ignoreDuplicates: false }
    );
    onLogAction('APPROVE_COURIER', 'user', courierId, { approved_at: approvedAt });
    showToast('Livreur approuvé ✅', 'success');
    onRefresh();
  };


  // ── Courier Reject ───────────────────────────────────────────────────────
  const rejectCourier = async (courierId: string) => {
    const reason = await askPrompt(
      'Motif du refus',
      'Indiquez la raison du refus (ex: profil incomplet, zone non couverte).'
    );
    if (!reason) return;
    const { error } = await supabase
      .from('profiles')
      .update({ courier_status: 'rejected', courier_rejection_reason: reason })
      .eq('id', courierId);
    if (error) { showToast(`Erreur : ${error.message}`, 'error'); return; }
    onLogAction('REJECT_COURIER', 'user', courierId, { reason });
    showToast('Candidature refusée.', 'info');
    onRefresh();
  };

  // ── Empty state ──────────────────────────────────────────────────────────
  if (total === 0) {
    return (
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        className="flex flex-col items-center justify-center py-24 text-center"
      >
        <div className="w-20 h-20 bg-emerald-500/10 border border-emerald-500/20 rounded-3xl flex items-center justify-center mb-6">
          <Inbox className="w-10 h-10 text-emerald-500" />
        </div>
        <h3 className="text-xl font-black text-slate-800 dark:text-white uppercase tracking-tighter mb-2">
          File d'attente vide
        </h3>
        <p className="text-[11px] font-bold text-slate-400 dark:text-white/30 tracking-wider uppercase">
          Aucune candidature en attente · Tout est traité ✓
        </p>
      </motion.div>
    );
  }

  return (
    <div className="space-y-10">
      {/* ── Header ── */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-black text-slate-800 dark:text-white uppercase tracking-tighter italic">
            Candidatures
          </h2>
          <p className="text-[11px] font-bold text-slate-400 dark:text-white/30 tracking-wider uppercase mt-1">
            {total} en attente · Traiter dans les 24h
          </p>
        </div>
        <div className="flex gap-3">
          {pendingVendors.length > 0 && (
            <span className="flex items-center gap-2 px-4 py-2 bg-amber-500/10 border border-amber-500/30 text-amber-600 dark:text-amber-400 rounded-2xl text-[10px] font-black uppercase tracking-wider">
              <Store className="w-3.5 h-3.5" />
              {pendingVendors.length} Boutique{pendingVendors.length > 1 ? 's' : ''}
            </span>
          )}
          {pendingCouriers.length > 0 && (
            <span className="flex items-center gap-2 px-4 py-2 bg-blue-500/10 border border-blue-500/30 text-blue-600 dark:text-blue-400 rounded-2xl text-[10px] font-black uppercase tracking-wider">
              <Truck className="w-3.5 h-3.5" />
              {pendingCouriers.length} Livreur{pendingCouriers.length > 1 ? 's' : ''}
            </span>
          )}
        </div>
      </div>

      {/* ── Pending Vendors ── */}
      {pendingVendors.length > 0 && (
        <section>
          <div className="flex items-center gap-3 mb-5">
            <div className="w-8 h-8 bg-amber-500/10 border border-amber-500/20 rounded-xl flex items-center justify-center">
              <Store className="w-4 h-4 text-amber-500" />
            </div>
            <h3 className="text-lg font-black text-slate-700 dark:text-white uppercase tracking-tighter">
              Nouvelles Boutiques
            </h3>
            <span className="px-2.5 py-1 bg-amber-500 text-white text-[10px] font-black rounded-full tracking-wider">
              {pendingVendors.length}
            </span>
          </div>
          <AnimatePresence mode="popLayout">
            <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-5">
              {pendingVendors.map(v => (
                <React.Fragment key={v.id}>
                  <VendorApplicationCard
                    vendor={v}
                    supportWhatsapp={supportWhatsapp}
                    onApprove={approveVendor}
                    onReject={rejectVendor}
                  />
                </React.Fragment>
              ))}
            </div>
          </AnimatePresence>
        </section>
      )}

      {/* ── Pending Couriers ── */}
      {pendingCouriers.length > 0 && (
        <section>
          <div className="flex items-center gap-3 mb-5">
            <div className="w-8 h-8 bg-blue-500/10 border border-blue-500/20 rounded-xl flex items-center justify-center">
              <Truck className="w-4 h-4 text-blue-500" />
            </div>
            <h3 className="text-lg font-black text-slate-700 dark:text-white uppercase tracking-tighter">
              Nouvelles Candidatures Livreurs
            </h3>
            <span className="px-2.5 py-1 bg-blue-500 text-white text-[10px] font-black rounded-full tracking-wider">
              {pendingCouriers.length}
            </span>
          </div>
          <AnimatePresence mode="popLayout">
            <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-5">
              {pendingCouriers.map(c => (
                <React.Fragment key={c.id}>
                  <CourierApplicationCard
                    courier={c}
                    supportWhatsapp={supportWhatsapp}
                    onApprove={approveCourier}
                    onReject={rejectCourier}
                  />
                </React.Fragment>
              ))}
            </div>
          </AnimatePresence>
        </section>
      )}
    </div>
  );
}
