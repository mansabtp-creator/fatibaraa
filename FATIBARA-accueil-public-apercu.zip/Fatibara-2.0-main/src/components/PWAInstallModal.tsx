import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Share, MoreVertical, Plus, Smartphone, Download, CheckCircle2, ChevronRight, HelpCircle } from 'lucide-react';

interface BeforeInstallPromptEvent extends Event {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: 'accepted' | 'dismissed'; platform: string }>;
}

// ─── Device Detection ───────────────────────────────────────────────────────
function getDeviceInfo() {
  const ua = navigator.userAgent;
  const isIOS = /iphone|ipad|ipod/i.test(ua);
  const isAndroid = /android/i.test(ua);
  const isSamsung = /samsungbrowser/i.test(ua);
  const isFirefox = /firefox/i.test(ua);
  const isChrome = /chrome/i.test(ua) && !/edge/i.test(ua);
  const isSafari = /safari/i.test(ua) && !/chrome/i.test(ua);
  const isStandalone = window.matchMedia('(display-mode: standalone)').matches
    || (navigator as any).standalone === true;

  return { isIOS, isAndroid, isSamsung, isFirefox, isChrome, isSafari, isStandalone };
}

// Global cached prompt for instant access
let globalDeferredPrompt: BeforeInstallPromptEvent | null = null;

// ─── Exported hook for use in Header ─────────────────────────────────────────
let showInstallModalFn: (() => void) | null = null;
export const showInstallModal = () => showInstallModalFn?.();

// ─── iOS Step ────────────────────────────────────────────────────────────────
function IOSInstructions() {
  const [step, setStep] = useState(0);
  const steps = [
    {
      icon: (
        <div className="w-14 h-14 bg-blue-50 dark:bg-blue-900/30 rounded-2xl flex items-center justify-center">
          <Share className="w-7 h-7 text-blue-500" />
        </div>
      ),
      title: 'Appuyez sur Partager',
      desc: 'Appuyez sur l\'icône de partage dans la barre du bas de Safari',
      hint: '↓ Barre de navigation bas',
    },
    {
      icon: (
        <div className="w-14 h-14 bg-orange-50 dark:bg-orange-900/30 rounded-2xl flex items-center justify-center">
          <Plus className="w-7 h-7 text-[#ff6600]" />
        </div>
      ),
      title: '"Sur l\'écran d\'accueil"',
      desc: 'Faites défiler le menu et appuyez sur "Ajouter à l\'écran d\'accueil"',
      hint: '↓ Défiler le menu vers le bas',
    },
    {
      icon: (
        <div className="w-14 h-14 bg-green-50 dark:bg-green-900/30 rounded-2xl flex items-center justify-center">
          <CheckCircle2 className="w-7 h-7 text-green-500" />
        </div>
      ),
      title: 'Appuyez sur "Ajouter"',
      desc: 'Confirmez en appuyant sur "Ajouter" en haut à droite. C\'est tout !',
      hint: '✓ FATIBARA apparaît sur votre écran d\'accueil',
    },
  ];

  return (
    <div className="flex flex-col gap-6">
      {/* Step Pills */}
      <div className="flex justify-center gap-2">
        {steps.map((_, i) => (
          <div
            key={i}
            className={`h-1.5 rounded-full transition-all duration-500 ${
              i === step ? 'w-8 bg-[#ff6600]' : i < step ? 'w-4 bg-green-400' : 'w-4 bg-gray-200 dark:bg-gray-700'
            }`}
          />
        ))}
      </div>

      {/* Step Content */}
      <AnimatePresence mode="wait">
        <motion.div
          key={step}
          initial={{ opacity: 0, x: 30 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: -30 }}
          transition={{ duration: 0.25 }}
          className="flex flex-col items-center text-center gap-3 min-h-[140px] justify-center"
        >
          {steps[step].icon}
          <div>
            <h3 className="text-[17px] font-black text-gray-900 dark:text-white mb-1">
              {steps[step].title}
            </h3>
            <p className="text-[13px] text-gray-500 dark:text-gray-400 leading-relaxed">
              {steps[step].desc}
            </p>
            <p className="text-[11px] text-[#ff6600] font-bold mt-2 uppercase tracking-wider">
              {steps[step].hint}
            </p>
          </div>
        </motion.div>
      </AnimatePresence>

      {/* Navigation */}
      <div className="flex gap-3">
        {step > 0 && (
          <button
            onClick={() => setStep(s => s - 1)}
            className="flex-1 py-3 rounded-2xl border border-gray-200 dark:border-gray-700 text-[14px] font-bold text-gray-600 dark:text-gray-400 cursor-pointer"
          >
            Retour
          </button>
        )}
        {step < steps.length - 1 ? (
          <button
            onClick={() => setStep(s => s + 1)}
            className="flex-1 py-3 rounded-2xl bg-[#ff6600] text-white text-[14px] font-black cursor-pointer shadow-lg shadow-orange-500/20"
          >
            Suivant →
          </button>
        ) : (
          <button
            onClick={() => {
              if (showInstallModalFn) showInstallModalFn = null;
              markDismissed();
            }}
            className="flex-1 py-3 rounded-2xl bg-green-500 text-white text-[14px] font-black cursor-pointer shadow-lg shadow-green-500/20"
          >
            J'ai compris ✓
          </button>
        )}
      </div>
    </div>
  );
}

// ─── Android/Chrome Manual Instructions ──────────────────────────────────────
function AndroidInstructions({ isSamsung }: { isSamsung: boolean }) {
  return (
    <div className="flex flex-col gap-4">
      <div className="flex items-start gap-4 p-4 bg-gray-50 dark:bg-gray-800/50 rounded-2xl">
        <div className="w-10 h-10 rounded-xl bg-gray-200 dark:bg-gray-700 flex items-center justify-center flex-shrink-0">
          <MoreVertical className="w-5 h-5 text-gray-600 dark:text-gray-300" />
        </div>
        <div>
          <p className="text-[13px] font-bold text-gray-900 dark:text-white">Étape 1</p>
          <p className="text-[12px] text-gray-500 dark:text-gray-400">
            Appuyez sur les <strong>3 points ⋮</strong> en haut à droite de {isSamsung ? 'Samsung Internet' : 'Chrome'}
          </p>
        </div>
      </div>
      <div className="flex items-start gap-4 p-4 bg-gray-50 dark:bg-gray-800/50 rounded-2xl">
        <div className="w-10 h-10 rounded-xl bg-[#ff6600]/10 flex items-center justify-center flex-shrink-0">
          <Plus className="w-5 h-5 text-[#ff6600]" />
        </div>
        <div>
          <p className="text-[13px] font-bold text-gray-900 dark:text-white">Étape 2</p>
          <p className="text-[12px] text-gray-500 dark:text-gray-400">
            Sélectionnez <strong>"Ajouter à l'écran d'accueil"</strong> ou <strong>"Installer l'application"</strong>
          </p>
        </div>
      </div>
      <div className="flex items-start gap-4 p-4 bg-green-50 dark:bg-green-900/20 rounded-2xl">
        <div className="w-10 h-10 rounded-xl bg-green-100 dark:bg-green-800/40 flex items-center justify-center flex-shrink-0">
          <CheckCircle2 className="w-5 h-5 text-green-600" />
        </div>
        <div>
          <p className="text-[13px] font-bold text-gray-900 dark:text-white">Étape 3</p>
          <p className="text-[12px] text-gray-500 dark:text-gray-400">
            Confirmez et FATIBARA s'installe instantanément !
          </p>
        </div>
      </div>
    </div>
  );
}

// ─── Visit-count helpers ──────────────────────────────────────────────────────
const VISIT_KEY    = 'fatibara_visit_count';
const DISMISS_KEY  = 'fatibara_pwa_dismissed';
const MIN_VISITS   = 2;   // Show from the 2nd visit onward
const SHOW_DELAY   = 30_000; // 30 s after page load

function getVisitCount(): number {
  return parseInt(localStorage.getItem(VISIT_KEY) || '0', 10);
}

function incrementVisitCount(): number {
  const next = getVisitCount() + 1;
  localStorage.setItem(VISIT_KEY, String(next));
  return next;
}

function isDismissed(): boolean {
  return localStorage.getItem(DISMISS_KEY) === 'true';
}

function markDismissed(): void {
  localStorage.setItem(DISMISS_KEY, 'true');
}

// ─── Main Modal Component ─────────────────────────────────────────────────────
export default function PWAInstallModal() {
  const [isOpen, setIsOpen] = useState(false);
  const [deferredPrompt, setDeferredPrompt] = useState<BeforeInstallPromptEvent | null>(globalDeferredPrompt);
  const [showManualGuide, setShowManualGuide] = useState(false);
  const [isInstalling, setIsInstalling] = useState(false);
  const device = getDeviceInfo();

  // Listen for beforeinstallprompt event and appinstalled event
  useEffect(() => {
    const handleBeforeInstallPrompt = (e: Event) => {
      // Prevent browser default automatic popups
      e.preventDefault();
      const promptEvent = e as BeforeInstallPromptEvent;
      globalDeferredPrompt = promptEvent;
      setDeferredPrompt(promptEvent);
    };

    const handleAppInstalled = () => {
      globalDeferredPrompt = null;
      setDeferredPrompt(null);
      setIsOpen(false);
      markDismissed();
    };

    window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
    window.addEventListener('appinstalled', handleAppInstalled);

    return () => {
      window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
      window.removeEventListener('appinstalled', handleAppInstalled);
    };
  }, []);

  // Register the global trigger so Header or buttons can open this modal
  useEffect(() => {
    showInstallModalFn = () => {
      if (globalDeferredPrompt) {
        setDeferredPrompt(globalDeferredPrompt);
      }
      setIsOpen(true);
    };
    return () => { showInstallModalFn = null; };
  }, []);

  // ── Auto-show logic: show from 2nd visit, after 30 s delay ─────────────────
  useEffect(() => {
    // Never show if already installed, already dismissed, or desktop (no benefit)
    if (device.isStandalone || isDismissed()) return;
    if (!device.isIOS && !device.isAndroid) return; // Mobile only

    const visits = incrementVisitCount();
    if (visits < MIN_VISITS) return; // Skip on first visit

    const timer = setTimeout(() => {
      if (!isDismissed()) setIsOpen(true);
    }, SHOW_DELAY);

    return () => clearTimeout(timer);
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const handleClose = () => {
    setIsOpen(false);
    markDismissed();
  };

  // Trigger installation prompt ONLY on explicit user button interaction
  const handleInstallClick = async () => {
    if (deferredPrompt) {
      try {
        setIsInstalling(true);
        await deferredPrompt.prompt();
        const { outcome } = await deferredPrompt.userChoice;
        if (outcome === 'accepted') {
          globalDeferredPrompt = null;
          setDeferredPrompt(null);
          setIsOpen(false);
          markDismissed();
        }
      } catch (err) {
        console.error('PWA: Error triggering installation prompt:', err);
      } finally {
        setIsInstalling(false);
      }
    } else if (device.isIOS) {
      setShowManualGuide(true);
    } else {
      setShowManualGuide(true);
    }
  };

  // Don't render anything if already installed as standalone
  if (device.isStandalone) return null;

  const hasNativePrompt = Boolean(deferredPrompt);

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => handleClose()}
            className="fixed inset-0 bg-black/60 backdrop-blur-sm z-[200]"
          />

          {/* Sheet */}
          <motion.div
            initial={{ y: '100%' }}
            animate={{ y: 0 }}
            exit={{ y: '100%' }}
            transition={{ type: 'spring', stiffness: 400, damping: 40 }}
            className="fixed bottom-0 left-0 right-0 z-[201] bg-white dark:bg-gray-900 rounded-t-3xl px-6 pb-10 pt-4 shadow-2xl max-w-lg mx-auto"
          >
            {/* Handle */}
            <div className="w-10 h-1 bg-gray-200 dark:bg-gray-700 rounded-full mx-auto mb-5" />

            {/* Close */}
            <button
              onClick={() => handleClose()}
              className="absolute top-4 right-5 w-8 h-8 flex items-center justify-center rounded-full bg-gray-100 dark:bg-gray-800 hover:bg-gray-200 dark:hover:bg-gray-700 transition cursor-pointer"
            >
              <X className="w-4 h-4 text-gray-500" />
            </button>

            {/* App identity */}
            <div className="flex items-center gap-4 mb-5">
              <div className="w-16 h-16 rounded-2xl bg-black flex items-center justify-center text-white font-black text-lg shadow-lg">
                FA
              </div>
              <div>
                <h2 className="text-[18px] font-black text-gray-900 dark:text-white">FATIBARA</h2>
                <p className="text-[12px] text-gray-400">La place de marché de Guinée</p>
                <div className="flex items-center gap-1 mt-1">
                  {[1,2,3,4,5].map(s => (
                    <div key={s} className="w-2.5 h-2.5 rounded-full bg-[#ff6600]" />
                  ))}
                  <span className="text-[11px] text-gray-400 ml-1">Gratuit • PWA</span>
                </div>
              </div>
            </div>

            {/* Benefits */}
            <div className="flex gap-3 mb-6 overflow-x-auto no-scrollbar">
              {[
                { emoji: '⚡', text: 'Ultra rapide' },
                { emoji: '📴', text: 'Hors ligne' },
                { emoji: '🔔', text: 'Notifications' },
                { emoji: '🎁', text: '-50 000 GNF' },
              ].map(b => (
                <div key={b.text} className="flex-shrink-0 flex items-center gap-2 bg-orange-50 dark:bg-orange-900/20 border border-orange-100 dark:border-orange-800/40 px-3 py-2 rounded-xl">
                  <span className="text-base">{b.emoji}</span>
                  <span className="text-[12px] font-bold text-gray-800 dark:text-gray-200 whitespace-nowrap">{b.text}</span>
                </div>
              ))}
            </div>

            {/* Primary Action Button or Step-by-Step Guide */}
            {hasNativePrompt && !showManualGuide ? (
              <div className="flex flex-col gap-3">
                <button
                  onClick={handleInstallClick}
                  disabled={isInstalling}
                  className="w-full py-4 px-6 bg-[#ff6600] hover:bg-[#e65c00] active:scale-[0.98] text-white text-[15px] font-black rounded-2xl shadow-xl shadow-orange-500/25 flex items-center justify-center gap-3 transition cursor-pointer disabled:opacity-75"
                >
                  <Download className="w-5 h-5 animate-bounce" />
                  {isInstalling ? 'Installation...' : "Installer l'application (1 clic)"}
                </button>

                <button
                  onClick={() => setShowManualGuide(true)}
                  className="w-full py-2.5 text-[12px] font-bold text-gray-500 dark:text-gray-400 hover:text-gray-800 dark:hover:text-gray-200 flex items-center justify-center gap-1.5 transition cursor-pointer"
                >
                  <HelpCircle className="w-4 h-4" />
                  Instructions manuelles
                  <ChevronRight className="w-3.5 h-3.5" />
                </button>
              </div>
            ) : device.isIOS ? (
              <IOSInstructions />
            ) : (
              <div>
                <AndroidInstructions isSamsung={device.isSamsung} />
                {hasNativePrompt && (
                  <button
                    onClick={() => setShowManualGuide(false)}
                    className="mt-4 w-full py-3 bg-[#ff6600] text-white text-[14px] font-black rounded-2xl shadow-md cursor-pointer"
                  >
                    Retour à l'installation directe
                  </button>
                )}
              </div>
            )}
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}

