import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { ShoppingBag, AlertTriangle, Package, TrendingUp, CheckCircle2 } from 'lucide-react';
import { supabase, validateSessionOrClear } from '../lib/supabase';
import { hapticFeedback } from '../lib/haptics';

interface ActivityItem {
  id: string;
  type: 'order' | 'stock' | 'system';
  title: string;
  description: string;
  time: string;
  status?: string;
}

export default function VendorActivityFeed({ vendorId }: { vendorId: string }) {
  const [activities, setActivities] = useState<ActivityItem[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!vendorId) return;

    const fetchActivity = async () => {
      setLoading(true);
      try {
        // ── Session guard ──────────────────────────────────────────────────
        // Skip the query if no valid JWT is present — avoids HTTP 406 from
        // PostgREST when a stale token reaches the Authorization header.
        const session = await validateSessionOrClear();
        if (!session) {
          console.warn('[VendorActivityFeed] No active session — skipping activity fetch.');
          setLoading(false);
          return;
        }

        // ... existing fetch logic or improved
        const { data: orders } = await supabase
          .from('orders')
          .select('id, created_at, customer_name, total_amount')
          .eq('vendor_id', vendorId)
          .order('created_at', { ascending: false })
          .limit(5);

        const { data: store, error: storeError } = await supabase
          .from('stores')
          .select('id')
          .eq('owner_id', vendorId)
          .maybeSingle();

        if (storeError) {
          const code = storeError.code as string | undefined;
          const msg  = storeError.message as string | undefined;
          if (code === '406' || msg?.toLowerCase().includes('not acceptable')) {
            console.error(
              '[VendorActivityFeed] HTTP 406 on stores query — triggering session validation.',
              storeError
            );
            await validateSessionOrClear();
          } else {
            console.error('[VendorActivityFeed] stores query error:', storeError);
          }
        }

        let lowStockProds: any[] = [];
        if (store) {
          const { data: prods } = await supabase
            .from('products')
            .select('id, title, stock_quantity')
            .eq('store_id', store.id)
            .lte('stock_quantity', 5)
            .limit(3);
          lowStockProds = prods || [];
        }

        const initialActivities: ActivityItem[] = [
          ...(orders || []).map(o => ({
            id: o.id,
            type: 'order' as const,
            title: `Nouvelle Commande #${o.id.slice(0, 4)}`,
            description: `${o.customer_name} a commandé pour ${o.total_amount.toLocaleString()} GNF`,
            time: o.created_at,
            status: 'success'
          })),
          ...lowStockProds.map(p => ({
            id: p.id,
            type: 'stock' as const,
            title: 'Alerte Stock Bas',
            description: `"${p.title}" n'a plus que ${p.stock_quantity} unités.`,
            time: new Date().toISOString(),
            status: 'warning'
          }))
        ];

        setActivities(initialActivities.sort((a, b) => new Date(b.time).getTime() - new Date(a.time).getTime()));
      } catch (err) {
        console.error('[VendorActivityFeed] Activity fetch error:', err);
      } finally {
        setLoading(false);
      }
    };

    fetchActivity();

    // REAL-TIME SUBSCRIPTION
    const channel = supabase
      .channel(`vendor-realtime-${vendorId}`)
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'orders',
          filter: `vendor_id=eq.${vendorId}`
        },
        async (payload) => {
          const newOrder = payload.new;
          const activity: ActivityItem = {
            id: newOrder.id,
            type: 'order',
            title: `URGENT: Nouvelle Commande`,
            description: `${newOrder.customer_name} vient de passer une commande de ${newOrder.total_amount.toLocaleString()} GNF`,
            time: newOrder.created_at,
            status: 'success'
          };
          
          hapticFeedback('notification');
          setActivities(prev => [activity, ...prev].slice(0, 10));
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [vendorId]);

  if (loading) {
     return (
       <div className="space-y-4 animate-pulse">
         {[1, 2, 3].map(i => (
           <div key={i} className="h-20 bg-gray-50 bg-gray-50 dark:bg-gray-800 rounded-[2rem]" />
         ))}
       </div>
     );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between mb-8">
        <h3 className="text-lg font-black text-gray-900 dark:text-white tracking-tight flex items-center gap-2.5 uppercase">
          <TrendingUp className="w-5 h-5 text-[#ff6600] animate-bounce" /> Flux d'Activité en Direct
        </h3>
        <button className="text-[10px] font-black tracking-widest text-[#ff6600] dark:text-orange-400 hover:text-[#ff6600]/80 transition-all hover:scale-105 uppercase">
          Voir Tout
        </button>
      </div>

      <div className="space-y-5 relative">
        {/* Timeline line with elegant gradient */}
        <div className="absolute left-6 top-2 bottom-2 w-0.5 bg-gradient-to-b from-[#ff6600]/40 via-transparent to-transparent hidden md:block" />

        {activities.length === 0 ? (
          <div className="text-center py-16 bg-gray-50/50 dark:bg-gray-800/30 border border-dashed border-gray-200 dark:border-gray-700/60 rounded-[2rem] backdrop-blur-md">
             <p className="text-[11px] font-bold tracking-wider text-gray-400 dark:text-gray-500 uppercase">Aucune activité récente</p>
          </div>
        ) : (
          activities.map((activity, idx) => (
            <motion.div
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ type: 'spring', stiffness: 260, damping: 20, delay: idx * 0.08 }}
              key={activity.id + activity.type}
              className="relative flex items-start gap-4 md:gap-6 group"
            >
              <div className={`w-12 h-12 md:w-14 md:h-14 rounded-2xl flex items-center justify-center shrink-0 z-10 transition-all duration-300 group-hover:scale-110 shadow-md ${
                activity.type === 'order' ? 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/20' : 
                activity.type === 'stock' ? 'bg-orange-500/10 text-orange-600 dark:text-orange-400 border border-orange-500/20' : 
                'bg-blue-500/10 text-blue-600 dark:text-blue-400 border border-blue-500/20'
              }`}>
                {activity.type === 'order' ? <ShoppingBag className="w-5 h-5 md:w-6 md:h-6" /> : 
                 activity.type === 'stock' ? <AlertTriangle className="w-5 h-5 md:w-6 md:h-6" /> : 
                 <Package className="w-5 h-5 md:w-6 md:h-6" />}
              </div>

              <div className="flex-1 bg-white/70 dark:bg-gray-900/60 backdrop-blur-md border border-gray-100 dark:border-gray-800/80 p-5 md:p-6 rounded-[2rem] shadow-sm hover:shadow-lg transition-all duration-300 hover:border-[#ff6600]/30 hover:-translate-y-0.5">
                <div className="flex justify-between items-start gap-4 mb-2">
                   <h4 className="font-black text-[14px] md:text-[15px] text-gray-900 dark:text-white leading-tight tracking-tight uppercase">{activity.title}</h4>
                   <span className="text-[9px] font-black tracking-wider text-gray-400 dark:text-gray-500 whitespace-nowrap bg-gray-50 dark:bg-gray-800 px-2 py-1 rounded-lg">
                     {new Date(activity.time).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                   </span>
                </div>
                <p className="text-[12px] md:text-[13px] text-gray-500 dark:text-gray-400 font-bold uppercase tracking-tight pr-4 leading-relaxed opacity-95">{activity.description}</p>
                
                {activity.status === 'success' && (
                  <div className="mt-4 flex items-center gap-2 bg-emerald-500/5 px-3 py-1.5 rounded-xl border border-emerald-500/10 dark:border-emerald-500/20 w-fit">
                     <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400 animate-pulse" />
                     <span className="text-[9px] font-black tracking-widest text-emerald-600 dark:text-emerald-400 uppercase">Action Recommandée: Expédier</span>
                  </div>
                )}
              </div>
            </motion.div>
          ))
        )}
      </div>
    </div>
  );
}
