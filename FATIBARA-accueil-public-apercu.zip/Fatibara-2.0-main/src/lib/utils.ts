/**
 * Centralized utility for handling and formatting errors for the UI.
 * Consolidated from utils/errorHandling to reduce bundle chunks.
 */

export function friendlyError(err: any): string {
  if (!err) return "Une erreur inconnue est survenue.";

  // Handle Supabase/PostgREST error codes
  const code = err.code || "";
  const msg = err.message || err.toString();

  // Network/Server Connectivity
  if (msg.toLowerCase().includes("fetch") || msg.toLowerCase().includes("network") || msg.toLowerCase().includes("failed to fetch")) {
    return "Problème de connexion. Veuillez vérifier votre internet.";
  }

  // Row Level Security (RLS) & Permissions (Phase 5 Hardening)
  if (code === "42501") {
    return "Accès refusé. Vous n'avez pas les permissions pour cette action.";
  }

  // Check Constraint Violations (e.g., status transitions)
  if (code === "23514") {
    return "Action non autorisée par les règles du marché (Transition d'état invalide).";
  }

  // Standard Database Errors
  if (code === "23505") return "Cette information existe déjà (Doublon).";
  if (code === "23503") return "Référence invalide. Les données liées sont introuvables.";
  if (code === "PGRST116") return "Élément introuvable.";

  // Custom Logic / Readable Messages
  if (msg.includes("insufficient balance") || msg.includes("solde insuffisant")) {
    return "Solde insuffisant dans votre portefeuille.";
  }
  
  if (msg.includes("OTP")) {
    return "Code de validation incorrect.";
  }

  // Default to the provided message if it's somewhat friendly, otherwise generic
  if (msg && msg.length < 100 && !msg.includes("{") && !msg.includes("[")) {
    return msg;
  }

  return "Une erreur technique est survenue. Veuillez réessayer.";
}

/**
 * Formats a GNF monetary amount with proper locale grouping and a
 * non-breaking space between the number and the "GNF" currency suffix.
 *
 * Example: formatCurrency(250000) → "250 000\u00a0GNF"
 */
export const formatCurrency = (amount: number): string => {
  return (
    new Intl.NumberFormat('fr-GN', {
      style: 'decimal',
      maximumFractionDigits: 0,
    }).format(amount) + '\u00a0GNF'
  );
};
