/**
 * Utility for haptic feedback
 */
export const hapticFeedback = (type: 'light' | 'medium' | 'heavy' | 'selection' | 'success' | 'warning' | 'error' | 'reward' | 'bloom' | 'notification' = 'light') => {
  if (typeof window !== 'undefined' && 'vibrate' in navigator) {
    switch (type) {
      case 'notification':
        navigator.vibrate([20, 100, 20, 100, 20]);
        break;
      case 'light':
        navigator.vibrate(10);
        break;
      case 'medium':
        navigator.vibrate(20);
        break;
      case 'heavy':
        navigator.vibrate(50);
        break;
      case 'selection':
        navigator.vibrate(15);
        break;
      case 'success':
        navigator.vibrate([10, 30, 10]);
        break;
      case 'warning':
        navigator.vibrate([30, 50, 30]);
        break;
      case 'error':
        navigator.vibrate([50, 100, 50]);
        break;
      case 'reward':
        navigator.vibrate([20, 40, 20, 80, 20]);
        break;
      case 'bloom':
        navigator.vibrate([50, 20, 10, 20, 50]);
        break;
      default:
        navigator.vibrate(10);
    }
  }
};
