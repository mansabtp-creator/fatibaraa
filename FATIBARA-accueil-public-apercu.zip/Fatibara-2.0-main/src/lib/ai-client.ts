// Client-side wrapper to call our AI proxy
export const aiClient = {
  models: {
    generateContent: async (params: any) => {
      const payload = {
        ...params,
        model: params.model || 'gemini-3.8-flash'
      };

      const response = await fetch('/api/ai/generateContent', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });

      if (!response.ok) {
        let errDetail = response.statusText;
        try {
          const errJson = await response.json();
          if (errJson?.error) errDetail = typeof errJson.error === 'string' ? errJson.error : JSON.stringify(errJson.error);
        } catch {
          // ignore json parse error
        }
        throw new Error(`AI API Error: ${errDetail || response.status}`);
      }

      return response.json();
    }
  }
};
