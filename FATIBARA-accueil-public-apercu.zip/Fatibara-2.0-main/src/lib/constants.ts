export const PRODUCT_CATEGORIES = [
  'Téléphones & Tablettes',
  'Ordinateurs & Accessoires',
  'Électronique & Vidéo',
  'Électroménagers',
  'Mode Homme',
  'Mode Femme',
  'Beauté & Santé',
  'Maison & Bureau',
  'Épicerie & Supermarché',
  'Auto & Moto',
  'Sports & Loisirs',
  'Autres'
];

export const APP_NAME = 'FATIBARA';
export const APP_DESCRIPTION = "La place de marché leader connectant l'industrie de Guinée au monde digital.";
export const CURRENCY = 'GNF';
export const BRAND_COLOR = '#ff6600';
export const BRAND_COLOR_SECONDARY = '#e62e00';
export const LOCATION_DEFAULT = 'CONAKRY';
export const COUNTRY_FLAG = '🇬🇳';

export const PARENT_BRAND = 'FATIGLOBAL';
export const FOOD_BRAND = 'FATINÈMA';
export const TICKETING_BRAND = 'FATI-BILLETS';
export const FINTECH_BRAND = 'FATI-TONTINE';
export const NETWORKING_BRAND = 'FATI-LINK';

// ── Support contacts ──────────────────────────────────────────────────────────
// Update these to the real Fatibara office numbers.
// SUPPORT_WHATSAPP must be in international format without spaces or '+' prefix
// e.g. '224625000000' for Guinea (+224 625 00 00 00)
export const SUPPORT_WHATSAPP = '224666923393'; // Fatibara office WhatsApp (no + prefix, no spaces)
export const SUPPORT_PHONE    = '+224 666 92 33 93'; // Fatibara office phone

// ── AI Assistant ──────────────────────────────────────────────────────────────
// Aisata — Fatibara's AI assistant avatar. Used as the courier placeholder
// in LiveOrderTracking and anywhere the AI assistant identity appears.
export const AISATA_AVATAR_URL = 'https://miizhdzuxidilrzwdivk.supabase.co/storage/v1/object/public/assets/assiata.png';
