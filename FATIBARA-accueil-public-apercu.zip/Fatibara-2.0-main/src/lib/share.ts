import { APP_NAME } from './constants';

export const shareProduct = async (
  title: string,
  url: string,
  showToast: (message: string, type: 'success' | 'error' | 'info') => void
) => {
  const isIframe = window !== window.top;

  // Track if we've successfully shared via Web Share API
  let sharedViaBrowser = false;

  try {
    // Only try Web Share API if we're not in an iframe OR we know it works,
    // since in iframe it often throws NotAllowedError
    if (!isIframe && navigator.share) {
      await navigator.share({
        title: title || APP_NAME,
        text: `Regarde ce que j'ai trouvé sur ${APP_NAME}: ${title}`,
        url: url,
      });
      sharedViaBrowser = true;
      return;
    }
  } catch (err) {
    console.warn('Navigator share failed or was cancelled:', err);
    if (err instanceof Error && (err.name === 'AbortError' || err.name === 'NotAllowedError')) {
      if (err.name === 'AbortError') return; // User cancelled
      // NotAllowedError is common in iframes, proceed to clipboard fallback
    }
  }

  // Fallback to clipboard
  try {
    if (navigator.clipboard && navigator.clipboard.writeText) {
      await navigator.clipboard.writeText(url);
      showToast('Lien copié dans le presse-papier !', 'success');
      return;
    }
  } catch (err) {
    console.error('Clipboard API failed:', err);
  }

  // Legacy fallback (input creation)
  try {
    const input = document.createElement('input');
    input.value = url;
    input.style.position = 'fixed';
    input.style.opacity = '0';
    document.body.appendChild(input);
    input.select();
    const successful = document.execCommand('copy');
    document.body.removeChild(input);
    if (successful) {
      showToast('Lien copié !', 'success');
    } else {
      throw new Error('execCommand failed');
    }
  } catch (err) {
    console.error('Final fallback failed:', err);
    showToast('Utilisez le bouton de partage de votre navigateur', 'info');
  }
};
