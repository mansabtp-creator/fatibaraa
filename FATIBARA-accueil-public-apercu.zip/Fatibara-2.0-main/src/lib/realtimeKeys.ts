/**
 * Centralised Supabase Realtime channel key factory.
 *
 * Convention: `entity:id`  — ensures every channel is scoped to a specific
 * resource and prevents cross-resource message leakage in multi-tab / multi-
 * mount scenarios.
 *
 * Usage:
 *   supabase.channel(realtimeKey.chat(channelId))
 *   supabase.channel(realtimeKey.storeInbox(storeId))
 *   supabase.channel(realtimeKey.vendorOrders(userId))
 */
export const realtimeKey = {
  /** Per-conversation chat messages subscription */
  chat: (channelId: string) => `chat:${channelId}`,

  /** Per-store vendor inbox subscription (all channels belonging to a store) */
  storeInbox: (storeId: string) => `inbox:${storeId}`,

  /** Per-vendor orders subscription */
  vendorOrders: (userId: string) => `orders:${userId}`,
} as const;
