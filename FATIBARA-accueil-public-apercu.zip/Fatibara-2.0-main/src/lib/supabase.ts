import { createClient } from '@supabase/supabase-js';

// ─── Network Resilience Utilities ─────────────────────────────────────────────

/**
 * Wraps a Supabase promise factory with an AbortController-based timeout.
 * If the query exceeds `ms` milliseconds the promise rejects with a
 * DOMException of name "TimeoutError" so callers can distinguish it from
 * other network failures.
 *
 * @param factory   Zero-arg function that returns a Promise (lazy so the
 *                  AbortSignal can be plumbed in before the fetch starts).
 * @param ms        Timeout in milliseconds (default: 12 000).
 */
export function withTimeout<T>(factory: () => Promise<T>, ms = 12_000): Promise<T> {
  const ctrl = new AbortController();
  const timerId = setTimeout(() => ctrl.abort(new DOMException('Query timed out', 'TimeoutError')), ms);
  return factory()
    .then((result) => { clearTimeout(timerId); return result; })
    .catch((err) => { clearTimeout(timerId); throw err; });
}

/**
 * Retries `fn` up to `maxAttempts` times using exponential back-off.
 * Only retries on network-level errors (TypeError / AbortError / TimeoutError);
 * Supabase application errors (RLS violations, bad queries) are surfaced
 * immediately so they are not silently swallowed.
 *
 * @param fn          Async function to retry.
 * @param maxAttempts Total attempts (1 = no retry). Default: 3.
 * @param baseDelayMs Base back-off delay in ms.          Default: 600.
 */
export async function withRetry<T>(
  fn: () => Promise<T>,
  maxAttempts = 3,
  baseDelayMs = 600
): Promise<T> {
  let lastError: unknown;
  for (let attempt = 1; attempt <= maxAttempts; attempt++) {
    try {
      return await fn();
    } catch (err: any) {
      lastError = err;
      const isTransient =
        err instanceof TypeError ||
        err?.name === 'AbortError' ||
        err?.name === 'TimeoutError' ||
        err?.message?.includes('Failed to fetch') ||
        err?.message?.includes('NetworkError') ||
        err?.message?.includes('timed out');

      if (!isTransient || attempt === maxAttempts) throw err;

      const delay = baseDelayMs * 2 ** (attempt - 1); // 600 ms, 1 200 ms
      console.warn(`[Supabase] Transient error on attempt ${attempt}/${maxAttempts}. Retrying in ${delay} ms…`, err?.message);
      await new Promise((resolve) => setTimeout(resolve, delay));
    }
  }
  throw lastError;
}

function sanitizeJwt(val: unknown): string {
  if (typeof val !== 'string') return '';
  const match = val.match(/^[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+/);
  return match ? match[0] : val.trim().replace(/^["']|["']$/g, '');
}

// Strip any accidental trailing path (e.g. /rest/v1, /auth/v1) that Supabase
// dashboard sometimes shows as the "API URL" — the client adds these itself.
const rawSupabaseUrl = import.meta.env.VITE_SUPABASE_URL as string;
const supabaseUrl = rawSupabaseUrl
  ? rawSupabaseUrl.replace(/\/(rest|auth|realtime|storage)\/v\d.*$/, '').replace(/\/$/, '')
  : rawSupabaseUrl;
const supabaseAnonKey = sanitizeJwt(import.meta.env.VITE_SUPABASE_ANON_KEY);


const isConfigured = supabaseUrl && supabaseUrl !== 'https://your-project-id.supabase.co' && !supabaseUrl.includes('placeholder');

// We use a proxy to allow the app to boot without crashing if keys are missing.
// The actual error will only trigger when a query is attempted.
export const supabase = isConfigured 
  ? createClient(supabaseUrl, supabaseAnonKey, {
      auth: {
        persistSession: true,
        autoRefreshToken: true,
        detectSessionInUrl: true
      },
      // Realtime resilience for slow / intermittent connections (common in Guinea).
      // - heartbeatIntervalMs: ping every 15 s (default 30 s) to detect drops faster
      // - reconnectAfterMs:    aggressive reconnect schedule (1 s, 2 s, 5 s, 10 s)
      realtime: {
        heartbeatIntervalMs: 15_000,
        reconnectAfterMs: (tries: number) => [1_000, 2_000, 5_000, 10_000][Math.min(tries, 3)],
      },
      global: {
        headers: { 'x-client-info': 'fatibara-web/2.0' },
      },
    })
  : new Proxy({} as any, {
      get: (_, prop) => {
        if (prop === 'auth') return { 
          getSession: async () => ({ data: { session: null }, error: null }),
          onAuthStateChange: () => ({ data: { subscription: { unsubscribe: () => {} } } })
        };
        return () => {
          console.error(`Supabase action "${String(prop)}" attempted but credentials are missing.`);
          return Promise.resolve({ data: null, error: { message: 'Missing Supabase credentials' } });
        };
      }
    });

/**
 * Safely sign out the user.
 * Tries standard sign-out; if the server rejects with 403 (e.g. token already expired/invalid),
 * falls back cleanly to local session purge without throwing or polluting console.
 */
export async function safeSignOut() {
  if (!isConfigured) return;
  try {
    // Attempt local first if token is stale, or standard sign out
    await supabase.auth.signOut({ scope: 'local' });
  } catch {
    try {
      localStorage.removeItem('sb-miizhdzuxidilrzwdivk-auth-token');
      sessionStorage.clear();
    } catch {}
  }
}

/**
 * Validates the current auth session. Returns the active Session if valid, or null
 * when missing. If the token looks corrupted (JWT / refresh-token errors), signs out
 * proactively so subsequent queries don't hit HTTP 406 (PostgREST content-negotiation
 * failure caused by a malformed Authorization header).
 */
export async function validateSessionOrClear() {
  if (!isConfigured) return null;
  try {
    const { data: { session }, error } = await supabase.auth.getSession();
    if (error) {
      const msg = error.message ?? '';
      if (
        msg.includes('Refresh Token') ||
        msg.includes('invalid refresh token') ||
        msg.includes('expired') ||
        msg.includes('JWT')
      ) {
        console.warn(
          '[Auth] validateSessionOrClear — token appears invalid, clearing session.',
          error.message
        );
        await safeSignOut();
        return null;
      }
    }
    return session ?? null;
  } catch (e) {
    console.error('[Auth] Unexpected error during session validation:', e);
    return null;
  }
}

/**
 * Global resilience helper to catch "Failed to fetch", HTTP 406, and HTTP 400 errors.
 *
 * HTTP 400 (Bad Request / PGRST200) is thrown by PostgREST when a SELECT query
 * references a column that does not exist on the table — the most common cause is
 * a migration adding `delivery_otp`, `tracking_number`, or `courier_id` that was
 * not yet applied to the live database, or a PostgREST schema cache that is stale.
 */
/**
 * DEFAULT_TIMEOUT_MS — How long (in ms) to wait for a Supabase query before
 * treating it as a network failure and triggering the retry loop.
 * 12 s covers slow 2G / satellite connections common in Guinea.
 */
export const DEFAULT_QUERY_TIMEOUT_MS = 12_000;

export async function safeSupabaseQuery<T = any>(query: any, operationType?: string, path?: string): Promise<{ data: T | null; error: any; count?: number | null }> {
  if (!isConfigured) {
    return { data: null, error: { message: 'Supabase is not configured' } };
  }
  try {
    // Wrap with retry (up to 3 total attempts) + per-attempt timeout (12 s).
    // The query is already a thenable at this point, so we just race it against
    // a timeout rather than re-issuing the HTTP request on each attempt.
    // For true per-attempt re-issue, callers should pass a factory function.
    const result = await withRetry(
      () => withTimeout(() => Promise.resolve(query), DEFAULT_QUERY_TIMEOUT_MS)
    );

    if (result.error) {
      const code = result.error.code as string | undefined;
      const msg  = result.error.message as string | undefined;

      // ── HTTP 406 Not Acceptable ───────────────────────────────────────────────
      // PostgREST returns 406 when the Authorization header contains a structurally
      // broken JWT that prevents content-negotiation before the query is executed.
      // This is distinct from an expired token (401) and typically surfaces after
      // database schema migrations that reload the PostgREST schema cache.
      if (code === '406' || msg?.toLowerCase().includes('not acceptable')) {
        const authInfo = await supabase.auth.getSession();
        const diagInfo = {
          error: msg,
          code,
          operationType: operationType || 'unknown',
          path: path || 'unknown',
          user: authInfo.data.session?.user?.id || 'anonymous',
          timestamp: new Date().toISOString(),
          context: 'HTTP 406 — PostgREST content-negotiation failure',
          hint: 'Likely causes: stale/malformed JWT, PostgREST schema-cache mismatch after migration. Run NOTIFY pgrst, \'reload schema\' on the database, or have the user re-authenticate.',
        };
        console.error('SUPABASE 406 ERROR', JSON.stringify(diagInfo, null, 2));
        // Non-blocking session probe — clears the session if the token is unusable.
        validateSessionOrClear().then(session => {
          if (!session) {
            console.warn('[Auth] 406 triggered session clear — user must re-authenticate.');
          }
        });
      }

      // ── HTTP 400 Bad Request (PGRST200 — column / relation not found) ─────────
      // PostgREST returns 400 with code PGRST200 when a SELECT query names a column
      // that does not exist on the table.  In this project the most common triggers
      // are: `delivery_otp`, `tracking_number`, `courier_id` queried on `orders`
      // before the ADD COLUMN migrations have been applied to the live database,
      // OR when the PostgREST schema cache has not been refreshed after a migration.
      //
      // Resolution checklist (run in Supabase SQL editor):
      //   ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS delivery_otp    TEXT;
      //   ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS tracking_number TEXT;
      //   ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS courier_id      UUID REFERENCES public.profiles(id) ON DELETE SET NULL;
      //   NOTIFY pgrst, 'reload schema';
      if (
        code === '400' ||
        code === 'PGRST200' ||
        msg?.toLowerCase().includes('bad request') ||
        msg?.toLowerCase().includes('column') && msg?.toLowerCase().includes('does not exist') ||
        msg?.toLowerCase().includes('relation') && msg?.toLowerCase().includes('does not exist')
      ) {
        console.error(
          'SUPABASE 400 ERROR — Column or relation not found on table.',
          JSON.stringify({
            error: msg,
            code,
            operationType: operationType || 'unknown',
            path: path || 'unknown',
            timestamp: new Date().toISOString(),
            context: 'HTTP 400 — PostgREST PGRST200 (unknown column/relation)',
            hint:
              'Run these in the Supabase SQL editor:\n' +
              '  ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS delivery_otp TEXT;\n' +
              '  ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS tracking_number TEXT;\n' +
              '  ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS courier_id UUID REFERENCES public.profiles(id) ON DELETE SET NULL;\n' +
              '  NOTIFY pgrst, \'reload schema\';',
          }, null, 2)
        );
      }

      // ── RLS / Permission Violation (42501) ───────────────────────────────────
      if (code === '42501' || msg?.includes('insufficient permissions')) {
        const authInfo = await supabase.auth.getSession();
        const errInfo = {
          error: msg,
          code,
          operationType: operationType || 'unknown',
          path: path || 'unknown',
          user: authInfo.data.session?.user?.id || 'anonymous',
          email: authInfo.data.session?.user?.email || 'none',
          timestamp: new Date().toISOString(),
          context: 'Supabase RLS Violation',
        };
        console.error('CRITICAL: RLS Violation Detected', JSON.stringify(errInfo, null, 2));
      }
    }

    return result;
  } catch (error: any) {
    if (error instanceof TypeError && (error.message === 'Failed to fetch' || error.message.includes('NetworkError'))) {
      console.error('Supabase Network Error: Failed to fetch.');
      if (typeof window !== 'undefined') {
        window.dispatchEvent(new CustomEvent('app:network-offline'));
      }
      return { data: null, error: { message: 'Network transient issue', isFetchError: true } };
    }

    console.error('Supabase Execution Error:', error);
    return { data: null, error };
  }
}
