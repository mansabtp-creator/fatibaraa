/**
 * src/lib/sentry.ts
 *
 * Sentry error monitoring — initialization and utilities.
 *
 * DESIGN DECISIONS:
 *   - Sentry only initializes when VITE_SENTRY_DSN is set AND we are in
 *     production (`import.meta.env.PROD`). Zero overhead in local dev.
 *   - `captureException` is exported as a safe wrapper — it's a no-op when
 *     Sentry is not initialized, so callers don't need to guard against it.
 *   - `setUserContext` is called from AppContext after login so Sentry events
 *     are tied to the Fatibara user ID (never PII like email/phone).
 *   - Integration list is kept minimal to avoid adding to the bundle size:
 *     only BrowserTracing (performance) and Replay (session replay on errors).
 *
 * SETUP:
 *   1. Create a project at https://sentry.io (free tier, React)
 *   2. Copy the DSN and set VITE_SENTRY_DSN in .env.local (dev) and
 *      in Vercel → Project → Environment Variables (production)
 *   3. In Sentry project settings → Alerts, add a rule:
 *      "When error count > 5 in 1 minute → notify via email"
 */

import * as Sentry from '@sentry/react';

// ─── Init ─────────────────────────────────────────────────────────────────────

let _initialized = false;

export function initSentry(): void {
  const dsn = import.meta.env.VITE_SENTRY_DSN as string | undefined;
  const isProd = import.meta.env.PROD;

  // Only activate in production with a real DSN configured
  if (!isProd || !dsn || dsn.trim() === '') {
    if (import.meta.env.DEV) {
      console.debug('[Sentry] Disabled in development. Set VITE_SENTRY_DSN to enable.');
    }
    return;
  }

  Sentry.init({
    dsn: dsn.trim(),

    // ── Performance monitoring ──────────────────────────────────────────────
    // 10% of transactions sampled — enough signal, low overhead & quota cost
    tracesSampleRate: 0.1,

    // ── Session Replay ──────────────────────────────────────────────────────
    // Records a video-like replay of the user session when an error occurs.
    // 0% for normal sessions, 100% for sessions that contain an error.
    replaysSessionSampleRate: 0,
    replaysOnErrorSampleRate: 1.0,

    integrations: [
      Sentry.browserTracingIntegration(),
      Sentry.replayIntegration({
        // Mask all text and block all media to protect user privacy
        maskAllText: true,
        blockAllMedia: true,
      }),
    ],

    // ── Environment tagging ─────────────────────────────────────────────────
    environment: 'production',
    release: import.meta.env.VITE_APP_VERSION ?? 'fatibara@2.0.0',

    // ── Noise filtering ─────────────────────────────────────────────────────
    // Ignore known-benign errors that don't require action:
    ignoreErrors: [
      // Network fluctuations (Guinea's mobile network)
      'Network request failed',
      'Failed to fetch',
      'NetworkError',
      'Load failed',
      // Stale service worker artefacts from old builds
      'share-modal',
      // Safari-specific ResizeObserver noise
      'ResizeObserver loop limit exceeded',
      'ResizeObserver loop completed with undelivered notifications',
      // Browser extension interference
      'Non-Error promise rejection captured',
    ],
    denyUrls: [
      // Chrome extensions
      /extensions\//i,
      /^chrome:\/\//i,
      /^chrome-extension:\/\//i,
    ],
  });

  _initialized = true;
  console.info('[Sentry] Initialized — error monitoring active.');
}

// ─── Utilities ────────────────────────────────────────────────────────────────

/**
 * Safe wrapper around `Sentry.captureException`.
 * No-op when Sentry is not initialized (dev, no DSN, etc.).
 */
export function captureException(
  error: Error | unknown,
  context?: Record<string, unknown>
): void {
  if (!_initialized) return;
  Sentry.withScope((scope) => {
    if (context) {
      scope.setExtras(context as Record<string, unknown>);
    }
    Sentry.captureException(error);
  });
}

/**
 * Associates the current Sentry session with the authenticated Fatibara user.
 * Call this after login. Only sends the opaque Supabase user ID — never email or phone.
 */
export function setSentryUser(userId: string | null): void {
  if (!_initialized) return;
  if (userId) {
    Sentry.setUser({ id: userId });
  } else {
    Sentry.setUser(null); // Clear user on logout
  }
}

/**
 * Adds arbitrary key/value tags visible in Sentry's issue list.
 * Useful for tagging by vendor store, order ID, etc.
 */
export function setSentryTag(key: string, value: string): void {
  if (!_initialized) return;
  Sentry.setTag(key, value);
}
