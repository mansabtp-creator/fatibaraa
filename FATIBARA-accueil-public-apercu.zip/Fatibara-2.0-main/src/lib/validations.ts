import { z } from 'zod';

export const productVariantSchema = z.object({
  id: z.string(),
  size: z.string().optional(),
  color: z.string().optional(),
  stock_count: z.coerce.number().min(0, "Le stock ne peut pas être négatif").default(0),
  price_override: z.coerce.number().nullable().optional(),
});

export const productSchema = z.object({
  title: z.string().min(3, "Le titre doit faire au moins 3 caractères").max(100),
  category: z.string().min(1, "Catégorie requise"),
  description: z.string().min(10, "La description est trop courte"),
  price_gnf: z.coerce.number().positive("Le prix doit être positif"),
  stock_quantity: z.coerce.number().min(0, "Le stock ne peut pas être négatif").default(0),
  image_urls: z.array(z.string().url("URL d'image invalide")).min(1, "Au moins une image est requise"),
  status: z.enum(['published', 'draft', 'scheduled']),
  scheduled_at: z.string().optional().nullable(),
  is_hero: z.boolean().default(false),
  variants: z.array(productVariantSchema).optional(),
  low_stock_threshold: z.coerce.number().default(5),
});

export const loginSchema = z.object({
  email: z.string().email("Veuillez entrer une adresse email valide"),
  password: z.string().min(6, "Le mot de passe doit contenir au moins 6 caractères"),
});

export const vendorRegistrationSchema = z.object({
  storeName: z.string().min(3, "Le nom de la boutique doit faire au moins 3 caractères").max(50),
  category: z.string().min(1, "Catégorie requise"),
  location_commune: z.string().min(1, "Commune requise"),
  location_region: z.string().min(1, "Région requise"),
  phone: z.string().min(8, "Veuillez entrer un numéro de téléphone valide"),
  email: z.string().email("Veuillez entrer une adresse email valide"),
  password: z.string().min(6, "Le mot de passe doit contenir au moins 6 caractères"),
  agreeToTerms: z.boolean().refine(val => val === true, "Vous devez accepter les conditions"),
});

export const registerSchema = z.object({
  full_name: z.string().min(2, "Veuillez entrer votre nom complet"),
  email: z.string().email("Veuillez entrer une adresse email valide"),
  phone: z.string().min(8, "Veuillez entrer un numéro valide").optional().or(z.literal('')),
  password: z.string().min(6, "Le mot de passe doit contenir au moins 6 caractères"),
  confirmPassword: z.string()
}).refine((data) => data.password === data.confirmPassword, {
  message: "Les mots de passe ne correspondent pas",
  path: ["confirmPassword"],
});

export const forgotPasswordSchema = z.object({
  email: z.string().email("Veuillez entrer une adresse email valide"),
});

export type ProductInput = z.infer<typeof productSchema>;
export type LoginInput = z.infer<typeof loginSchema>;
export type VendorRegistrationInput = z.infer<typeof vendorRegistrationSchema>;
export type RegisterInput = z.infer<typeof registerSchema>;
export type ForgotPasswordInput = z.infer<typeof forgotPasswordSchema>;
