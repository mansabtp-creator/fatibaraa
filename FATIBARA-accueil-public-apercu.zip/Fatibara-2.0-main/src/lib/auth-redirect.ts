/**
 * auth-redirect.ts — Centralized Role-Based Redirect Utility
 *
 * Single source of truth for mapping each user role to its designated root
 * dashboard route. Import `getRedirectPathForRole` wherever a post-login or
 * role-switch redirect is needed.
 *
 * Role vocabulary used across the platform:
 *   admin   → full platform admin console  (/admin/dashboard)
 *   vendor  → merchant / seller dashboard  (/vendor/dashboard)
 *   livreur → delivery courier dashboard   (/livreur/dashboard)
 *   client  → regular buyer / customer home (/ — shop homepage)
 *
 * Prefer this file over the older `utils/authRedirect.ts` for synchronous,
 * role-string-based redirects. The async DB variant in utils/authRedirect.ts
 * is still used as a fallback when the role is not yet available in context.
 */

export type UserRole = 'admin' | 'vendor' | 'livreur' | 'client';

/**
 * Maps each recognized role to its canonical post-login route.
 *
 * - 'livreur' and 'courier' both resolve to /livreur/dashboard.
 * - 'client' maps to / (the shop homepage — buyers land here after login).
 * - 'admin' maps to /admin/dashboard (the admin console home).
 */
export const ROLE_ROUTES: Record<UserRole, string> = {
  admin:   '/admin/dashboard',
  vendor:  '/vendor/dashboard',
  livreur: '/livreur/dashboard',
  // Customers/buyers land on the shop homepage, not the account dashboard.
  client:  '/',
};

/**
 * Returns the canonical root route for a given role string.
 *
 * Normalizes the input to lowercase and maps known aliases:
 *   - 'courier'  → treated as 'livreur'
 *   - 'buyer' | 'customer' | 'standard' | 'pro' → treated as 'client'
 *
 * Falls back to ROLE_ROUTES.client for any unrecognized role.
 *
 * @param role - The user's role string (case-insensitive). May be undefined.
 * @returns A route path string guaranteed to be non-empty.
 *
 * @example
 * getRedirectPathForRole('vendor')    // '/vendor/dashboard'
 * getRedirectPathForRole('ADMIN')     // '/admin/dashboard'
 * getRedirectPathForRole('courier')   // '/livreur/dashboard'
 * getRedirectPathForRole(undefined)   // '/'  (shop homepage)
 */
export function getRedirectPathForRole(role?: string): string {
  const normalized = role?.toLowerCase() ?? 'client';

  // Normalize legacy / alias role names before lookup
  const canonical = normalizeToCanonicalRole(normalized);
  return ROLE_ROUTES[canonical] ?? ROLE_ROUTES.client;
}

/**
 * Maps any role string variant to one of the four canonical UserRole values.
 * Internal helper used by `getRedirectPathForRole`.
 */
export function normalizeToCanonicalRole(role: string): UserRole {
  switch (role) {
    case 'admin':
      return 'admin';
    case 'vendor':
      return 'vendor';
    case 'livreur':
    case 'courier':
      return 'livreur';
    case 'client':
    case 'buyer':
    case 'customer':
    case 'standard':
    case 'pro':
    default:
      return 'client';
  }
}
