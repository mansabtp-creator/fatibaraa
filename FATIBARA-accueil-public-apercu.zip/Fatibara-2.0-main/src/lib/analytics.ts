/**
 * analytics.ts — Fatibara unified event-tracking utility
 *
 * Usage:
 *   import { logEvent } from '@/src/lib/analytics';
 *   logEvent('purchase', { product_id: '...', amount: 5000 });
 *
 * In development  → console.log only (zero network noise)
 * In production   → dispatches to GA4 (window.gtag) + Vercel Analytics (track)
 */

// ---------------------------------------------------------------------------
// TypeScript declaration for window.gtag (injected by the GA4 snippet)
// ---------------------------------------------------------------------------
declare global {
  interface Window {
    gtag?: (
      command: 'event' | 'config' | 'js' | 'set',
      eventNameOrTarget: string | Date,
      params?: Record<string, unknown>
    ) => void;
    dataLayer?: unknown[];
  }
}

// Vercel Analytics — stubbed for non-Vercel environment
// ---------------------------------------------------------------------------
let _vercelTrack: ((name: string, properties?: Record<string, unknown>) => void) | null = null;

async function getVercelTrack() {
  if (_vercelTrack) return _vercelTrack;
  _vercelTrack = () => undefined;
  return _vercelTrack;
}

// ---------------------------------------------------------------------------
// Core export
// ---------------------------------------------------------------------------

/**
 * Log a named analytics event with optional properties.
 *
 * @param eventName  - Lowercase, underscore-separated event name (e.g. 'add_to_cart')
 * @param properties - Arbitrary key/value payload merged into both GA4 and Vercel events
 */
export async function logEvent(
  eventName: string,
  properties?: Record<string, unknown>
): Promise<void> {
  const isProd = import.meta.env.PROD;

  // ── Development: console only ──────────────────────────────────────────────
  if (!isProd) {
    console.log('[Analytics][DEV]', eventName, properties ?? {});
    return;
  }

  // ── Production ─────────────────────────────────────────────────────────────

  // GA4 via gtag (injected by the GA4 <script> tag in index.html)
  if (typeof window !== 'undefined' && typeof window.gtag === 'function') {
    try {
      window.gtag('event', eventName, properties);
    } catch (err) {
      console.warn('[Analytics] gtag dispatch failed:', err);
    }
  }

  // Vercel Analytics
  try {
    const track = await getVercelTrack();
    track?.(eventName, properties);
  } catch (err) {
    console.warn('[Analytics] Vercel track failed:', err);
  }
}

// ---------------------------------------------------------------------------
// Convenience aliases for common Fatibara events
// ---------------------------------------------------------------------------

export const analytics = {
  /** User viewed a product detail page */
  viewProduct: (productId: string, productName: string) =>
    logEvent('view_item', { item_id: productId, item_name: productName }),

  /** User added a product to cart */
  addToCart: (productId: string, price: number) =>
    logEvent('add_to_cart', { item_id: productId, value: price, currency: 'GNF' }),

  /** User completed a purchase */
  purchase: (orderId: string, total: number) =>
    logEvent('purchase', { transaction_id: orderId, value: total, currency: 'GNF' }),

  /** User started checkout */
  beginCheckout: (cartTotal: number) =>
    logEvent('begin_checkout', { value: cartTotal, currency: 'GNF' }),

  /** User performed a search */
  search: (query: string) =>
    logEvent('search', { search_term: query }),

  /** User signed up */
  signUp: (method: string) =>
    logEvent('sign_up', { method }),

  /** User logged in */
  login: (method: string) =>
    logEvent('login', { method }),

  /** User submitted a review */
  submitReview: (productId: string, rating: number) =>
    logEvent('submit_review', { item_id: productId, rating }),
} as const;
