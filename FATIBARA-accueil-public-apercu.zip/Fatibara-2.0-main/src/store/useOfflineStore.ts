import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';

interface OfflineProduct {
  id: string;
  title: string;
  description: string;
  price_gnf: number;
  stock_quantity: number;
  image_urls: string[];
  category: string;
  is_hero: boolean;
  status: string;
  variations: any[];
  low_stock_threshold: number;
}

interface NewProductInput {
  __offline_id: string;
  store_id: string;
  title: string;
  description: string;
  price_gnf: number;
  stock_quantity: number;
  image_urls: string[];
  category: string;
  is_hero: boolean;
  status: string;
  variations: any[];
  low_stock_threshold: number;
}

interface OfflineStore {
  pendingEdits: Record<string, Partial<OfflineProduct>>;
  pendingCreations: Record<string, NewProductInput>;
  addEdit: (productId: string, edit: Partial<OfflineProduct>) => void;
  removeEdit: (productId: string) => void;
  addCreation: (creation: NewProductInput) => void;
  removeCreation: (offlineId: string) => void;
  clearPersisted: () => void;
}

export const useOfflineStore = create<OfflineStore>()(
  persist(
    (set) => ({
      pendingEdits: {},
      pendingCreations: {},
      addEdit: (productId, edit) =>
        set((state) => ({
          pendingEdits: {
            ...state.pendingEdits,
            [productId]: { ...(state.pendingEdits[productId] || {}), ...edit },
          },
        })),
      removeEdit: (productId) =>
        set((state) => {
          const newState = { ...state.pendingEdits };
          delete newState[productId];
          return { pendingEdits: newState };
        }),
      addCreation: (creation) =>
        set((state) => ({
          pendingCreations: {
            ...state.pendingCreations,
            [creation.__offline_id]: creation
          }
        })),
      removeCreation: (offlineId) =>
        set((state) => {
          const newState = { ...state.pendingCreations };
          delete newState[offlineId];
          return { pendingCreations: newState };
        }),
      clearPersisted: () => set({ pendingEdits: {}, pendingCreations: {} }),
    }),
    {
      name: 'vendor-offline-storage',
      storage: createJSONStorage(() => localStorage),
    }
  )
);

