import { create } from 'zustand';
import { persist } from 'zustand/middleware';

export interface UserProfile {
  id: string;
  email?: string;
  full_name?: string;
  avatar_url?: string;
  profile_type?: 'standard' | 'pro' | 'vendor' | 'courier' | 'admin' | 'client';
  is_admin?: boolean;
  is_pro_member?: boolean;
}

interface AppState {
  modeEconomie: boolean;
  setModeEconomie: (val: boolean) => void;
  isDarkMode: boolean;
  setIsDarkMode: (val: boolean) => void;
  userProfile: UserProfile | null;
  setUserProfile: (profile: UserProfile | null) => void;
  isOffline: boolean;
  setIsOffline: (val: boolean) => void;
  deferredPrompt: any;
  setDeferredPrompt: (prompt: any) => void;
  searchHistory: string[];
  addSearchTerm: (term: string) => void;
  clearSearchHistory: () => void;
  globalSearchQuery: string;
  setGlobalSearchQuery: (query: string) => void;
  recentlyViewed: string[];
  addRecentlyViewed: (productId: string) => void;
  clearRecentlyViewed: () => void;
  isNavigating: boolean;
  setIsNavigating: (val: boolean) => void;
  selectedRegion: string;
  setSelectedRegion: (region: string) => void;
  stagedBulkEdits: { [id: string]: any };
  updateStagedBulkEdit: (productId: string, changes: any) => void;
  clearStagedBulkEdits: () => void;
}

export const useStore = create<AppState>()(
  persist(
    (set) => ({
      modeEconomie: false,
      setModeEconomie: (val) => set({ modeEconomie: val }),
      isDarkMode: true,
      setIsDarkMode: (val) => {
        set({ isDarkMode: val });
        if (val) {
          document.documentElement.classList.add('dark');
        } else {
          document.documentElement.classList.remove('dark');
        }
      },
      userProfile: null,
      setUserProfile: (profile) => set({ userProfile: profile }),
      isOffline: !navigator.onLine,
      setIsOffline: (val) => set({ isOffline: val }),
      deferredPrompt: null,
      setDeferredPrompt: (prompt) => set({ deferredPrompt: prompt }),
      searchHistory: [],
      addSearchTerm: (term) => set((state) => {
        const trimmed = term.trim();
        if (!trimmed) return state;
        const filtered = state.searchHistory.filter(t => t.toLowerCase() !== trimmed.toLowerCase());
        return { searchHistory: [trimmed, ...filtered].slice(0, 3) };
      }),
      clearSearchHistory: () => set({ searchHistory: [] }),
      globalSearchQuery: '',
      setGlobalSearchQuery: (query) => set({ globalSearchQuery: query }),
      recentlyViewed: [],
      addRecentlyViewed: (productId) => set((state) => {
        const filtered = state.recentlyViewed.filter(id => id !== productId);
        return { recentlyViewed: [productId, ...filtered].slice(0, 10) };
      }),
      clearRecentlyViewed: () => set({ recentlyViewed: [] }),
      isNavigating: false,
      setIsNavigating: (val) => set({ isNavigating: val }),
      selectedRegion: 'Toute la Guinée',
      setSelectedRegion: (region) => set({ selectedRegion: region }),
      stagedBulkEdits: {},
      updateStagedBulkEdit: (id, changes) => set((state) => ({
        stagedBulkEdits: {
          ...state.stagedBulkEdits,
          [id]: { ...(state.stagedBulkEdits[id] || {}), ...changes }
        }
      })),
      clearStagedBulkEdits: () => set({ stagedBulkEdits: {} }),
    }),
    {
      name: 'fatibara-storage',
      partialize: (state) => ({ 
        modeEconomie: state.modeEconomie, 
        isDarkMode: state.isDarkMode,
        userProfile: state.userProfile,
        searchHistory: state.searchHistory,
        recentlyViewed: state.recentlyViewed,
        selectedRegion: state.selectedRegion,
        stagedBulkEdits: state.stagedBulkEdits,
      }),
      onRehydrateStorage: () => (state) => {
        if (state?.isDarkMode) {
          document.documentElement.classList.add('dark');
        } else {
          document.documentElement.classList.remove('dark');
        }
      }
    }
  )
);

