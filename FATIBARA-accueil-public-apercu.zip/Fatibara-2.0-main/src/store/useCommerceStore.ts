import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { supabase, safeSupabaseQuery } from '../lib/supabase';

export interface CartItem {
  id?: string; // Supabase ID
  product_id: string;
  quantity: number;
  selected_variations?: Record<string, string>;
}

export interface OfflineAction {
  id: string;
  type: 'SET' | 'REMOVE';
  product_id: string;
  quantity?: number;
  selected_variations?: Record<string, string>;
}

interface CommerceState {
  wishlist: string[];
  cart: CartItem[];
  cartPulse: boolean;
  offlineActions: OfflineAction[];
  
  // Actions
  setCartPulse: (val: boolean) => void;
  toggleWishlist: (productId: string, userId?: string) => Promise<void>;
  addToCart: (productId: string, quantity?: number, selectedVariations?: Record<string, string>, userId?: string) => Promise<void>;
  updateCartQuantity: (productId: string, quantity: number, variations?: Record<string, string>, userId?: string) => Promise<void>;
  removeFromCart: (productId: string, variations?: Record<string, string>, userId?: string) => Promise<void>;
  clearCart: (userId?: string) => Promise<void>;
  
  // Cloud Sync
  queueOfflineAction: (action: OfflineAction) => void;
  processOfflineActions: (userId: string) => Promise<void>;
  syncWithCloud: (userId: string) => Promise<void>;
}

export const useCommerceStore = create<CommerceState>()(
  persist(
    (set, get) => ({
      wishlist: [],
      cart: [],
      cartPulse: false,
      offlineActions: [],

      setCartPulse: (val) => set({ cartPulse: val }),

      toggleWishlist: async (productId, userId) => {
        const { wishlist } = get();
        const exists = wishlist.includes(productId);
        const newWishlist = exists
          ? wishlist.filter((id) => id !== productId)
          : [...wishlist, productId];

        // Optimistic UI update
        set({ wishlist: newWishlist });

        // Cloud sync if user is logged in
        if (userId) {
          try {
            if (exists) {
              const { error } = await supabase
                .from('user_wishlists')
                .delete()
                .eq('user_id', userId)
                .eq('product_id', productId);
              if (error) throw error;
            } else {
              // Use a SECURITY DEFINER RPC with SQL-level ON CONFLICT DO NOTHING.
              // This is guaranteed silent — no 409 regardless of PostgREST version.
              const { error } = await supabase.rpc('add_wishlist_item', {
                p_product_id: productId,
              });
              if (error) throw error;
            }
          } catch (error) {
            console.error('Failed to sync wishlist with cloud:', error);
          }
        }
      },

      queueOfflineAction: (action) => {
        const currentActions = get().offlineActions;
        const varStr = JSON.stringify(action.selected_variations || {});
        // Remove previous actions for this same item to squash them
        const filtered = currentActions.filter(a => 
          !(a.product_id === action.product_id && JSON.stringify(a.selected_variations || {}) === varStr)
        );
        set({ offlineActions: [...filtered, action] });
      },

      processOfflineActions: async (userId) => {
        const actions = [...get().offlineActions];
        if (actions.length === 0) return;
        
        const successfulActionIds: string[] = [];
        
        for (const action of actions) {
          try {
            if (action.type === 'SET') {
              // Try to update first using .contains for JSONB safety
              const { data, error } = await supabase.from('cart_items')
                .update({ quantity: action.quantity })
                .eq('user_id', userId)
                .eq('product_id', action.product_id)
                .contains('selected_variations', action.selected_variations || {})
                .select('id');
                
              if (!error && data && data.length > 0) {
                 // Updated successfully
              } else {
                 // Insert since it doesn't exist
                 await supabase.from('cart_items').insert({
                   user_id: userId,
                   product_id: action.product_id,
                   quantity: action.quantity,
                   selected_variations: action.selected_variations || {}
                 });
              }
            } else if (action.type === 'REMOVE') {
               await supabase.from('cart_items')
                .delete()
                .eq('user_id', userId)
                .eq('product_id', action.product_id)
                .contains('selected_variations', action.selected_variations || {});
            }
            successfulActionIds.push(action.id);
          } catch (err) {
            console.error("Cart action failed to sync", err);
            // Stop processing on first network failure to maintain order and wait for next sync
            break; 
          }
        }
        
        // Remove successful actions from the queue
        if (successfulActionIds.length > 0) {
          set({ offlineActions: get().offlineActions.filter(a => !successfulActionIds.includes(a.id)) });
        }
      },

      addToCart: async (productId, quantity = 1, selectedVariations, userId) => {
        const { cart } = get();
        const varStr = JSON.stringify(selectedVariations || {});
        
        const existingItem = cart.find(item => 
          item.product_id === productId && 
          JSON.stringify(item.selected_variations || {}) === varStr
        );
        
        const newQuantity = existingItem ? existingItem.quantity + quantity : quantity;
        
        let newCart;
        if (existingItem) {
          newCart = cart.map(item => 
            (item.product_id === productId && JSON.stringify(item.selected_variations || {}) === varStr)
              ? { ...item, quantity: newQuantity } 
              : item
          );
        } else {
          newCart = [...cart, { product_id: productId, quantity: newQuantity, selected_variations: selectedVariations }];
        }

        set({ cart: newCart, cartPulse: true });

        if (userId) {
          get().queueOfflineAction({
            id: crypto.randomUUID(),
            type: 'SET',
            product_id: productId,
            quantity: newQuantity,
            selected_variations: selectedVariations || {}
          });
          get().processOfflineActions(userId);
        }
      },

      updateCartQuantity: async (productId, quantity, variations, userId) => {
        const variationsStr = JSON.stringify(variations || {});
        if (quantity <= 0) {
          return get().removeFromCart(productId, variations, userId);
        }

        const newCart = get().cart.map(item => 
          (item.product_id === productId && JSON.stringify(item.selected_variations || {}) === variationsStr)
            ? { ...item, quantity } 
            : item
        );
        set({ cart: newCart });

        if (userId) {
          get().queueOfflineAction({
            id: crypto.randomUUID(),
            type: 'SET',
            product_id: productId,
            quantity: quantity,
            selected_variations: variations || {}
          });
          get().processOfflineActions(userId);
        }
      },

      removeFromCart: async (productId, variations, userId) => {
        const variationsStr = JSON.stringify(variations || {});
        const newCart = get().cart.filter(item => 
          !(item.product_id === productId && JSON.stringify(item.selected_variations || {}) === variationsStr)
        );
        set({ cart: newCart });

        if (userId) {
          get().queueOfflineAction({
            id: crypto.randomUUID(),
            type: 'REMOVE',
            product_id: productId,
            selected_variations: variations || {}
          });
          get().processOfflineActions(userId);
        }
      },

      clearCart: async (userId) => {
        set({ cart: [], offlineActions: [] });
        if (userId) {
          await supabase.from('cart_items').delete().eq('user_id', userId);
        }
      },

      syncWithCloud: async (userId) => {
        const { wishlist: localWishlist } = get();
        
        try {
          // 1. Process any pending offline cart actions first
          await get().processOfflineActions(userId);
          
          // 2. Fetch absolute truth from Cloud
          const [wishlistRes, cartRes] = await Promise.all([
            safeSupabaseQuery(supabase.from('user_wishlists').select('product_id').eq('user_id', userId)),
            safeSupabaseQuery(supabase.from('cart_items').select('product_id, quantity, selected_variations').eq('user_id', userId))
          ]);

          const cloudWishlist = (wishlistRes.data || []).map((w: any) => w.product_id);
          const cloudCart = cartRes.data || [];

          // 3. Wishlist Merge Strategy (Union)
          // pendingWishlistSync = items in local state that aren't in the cloud yet.
          // The RPC silently skips any product_id that no longer exists in products,
          // so after the call we re-fetch the cloud list to know which IDs were
          // actually accepted — this prunes orphaned (deleted-product) IDs from
          // localStorage so they never cause a FK error again.
          const pendingWishlistSync = localWishlist.filter(id => !cloudWishlist.includes(id));
          if (pendingWishlistSync.length > 0) {
            // Use a SECURITY DEFINER RPC with SQL-level ON CONFLICT DO NOTHING.
            // Orphaned product IDs are silently skipped at the DB layer.
            const { error } = await supabase.rpc('sync_wishlist_items', {
              p_product_ids: pendingWishlistSync,
            });
            if (error) throw error;
          }

          // Re-fetch cloud wishlist to get the canonical set (orphans were dropped).
          // Union with cloudWishlist ensures items added in this session survive.
          const { data: freshWishlistData } = await supabase
            .from('user_wishlists')
            .select('product_id')
            .eq('user_id', userId);
          const freshCloudWishlist = (freshWishlistData || []).map((w: any) => w.product_id);
          // Use the fresh cloud list as the canonical truth — no orphaned IDs.
          const mergedWishlist = Array.from(new Set([...freshCloudWishlist]));


          // 4. Cart Merge Strategy (Cloud Overwrite)
          // We only overwrite the local cart if there are NO pending offline actions.
          // If there are pending actions, it means the network is failing, and we must preserve local state.
          if (get().offlineActions.length === 0) {
             set({ wishlist: mergedWishlist, cart: cloudCart });
          } else {
             set({ wishlist: mergedWishlist });
          }
          
        } catch (error) {
          console.error("Commerce sync failed:", error);
        }
      }
    }),
    {
      name: 'fatibara-commerce-store',
    }
  )
);
