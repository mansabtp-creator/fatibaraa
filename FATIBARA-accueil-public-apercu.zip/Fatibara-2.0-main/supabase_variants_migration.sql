-- MIGRATION: Add variation support to Orders and Cart
-- Run this in Supabase SQL Editor

-- 1. Add selected_variations to cart_items
ALTER TABLE public.cart_items ADD COLUMN IF NOT EXISTS selected_variations JSONB DEFAULT '{}';

-- 2. Update UNIQUE constraint on cart_items to include variations
-- First drop existing constraint if possible (might have a default name)
-- We'll use a more generic approach: composite unique index is usually better
ALTER TABLE public.cart_items DROP CONSTRAINT IF EXISTS cart_items_user_id_product_id_key;
ALTER TABLE public.cart_items ADD CONSTRAINT cart_items_user_id_product_id_variations_key UNIQUE (user_id, product_id, selected_variations);

-- 3. Add selected_variations to order_items
ALTER TABLE public.order_items ADD COLUMN IF NOT EXISTS selected_variations JSONB DEFAULT '{}';

-- 4. Update stock decrement function to handle variants
CREATE OR REPLACE FUNCTION public.handle_stock_decrement()
RETURNS TRIGGER AS $$
DECLARE
    item RECORD;
    product_record RECORD;
    variant_id TEXT;
    vars JSONB;
    i INT;
    found_variant BOOLEAN := false;
BEGIN
    FOR item IN SELECT * FROM public.order_items WHERE order_id = NEW.id LOOP
        -- Get current product info
        SELECT * INTO product_record FROM public.products WHERE id = item.product_id;
        
        IF product_record.variants IS NOT NULL AND jsonb_array_length(product_record.variants) > 0 THEN
           -- Try to find the matching variant in product_record.variants array
           -- This matches the variant structure used in ProductForm.tsx
           -- selected_variations is a JSONB map of attributes
           
           vars := product_record.variants;
           FOR i IN 0..jsonb_array_length(vars) - 1 LOOP
              -- Check if this variant matches selected_variations
              -- Logic: if item.selected_variations matches variant attributes
              -- For simplicity, we assume variants in `variants` array have `id`
              -- and `size`/`color` that match the keys in `selected_variations`
              
              IF (vars->i->>'size' = item.selected_variations->>'size' OR (vars->i->>'size' IS NULL AND item.selected_variations->>'size' IS NULL))
                 AND (vars->i->>'color' = item.selected_variations->>'color' OR (vars->i->>'color' IS NULL AND item.selected_variations->>'color' IS NULL)) THEN
                 
                 -- We found the variant! Update its stock
                 vars := jsonb_set(vars, ARRAY[i::text, 'stock_count'], 
                    to_jsonb(GREATEST((vars->i->>'stock_count')::int - item.quantity, 0)));
                 found_variant := true;
                 EXIT;
              END IF;
           END LOOP;

           IF found_variant THEN
              UPDATE public.products SET variants = vars WHERE id = item.product_id;
           END IF;
        END IF;

        -- Always decrement global stock as well
        UPDATE public.products 
        SET stock_quantity = GREATEST(stock_quantity - item.quantity, 0)
        WHERE id = item.product_id;
    END LOOP;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- 5. Create trigger if it doesn't exist
DROP TRIGGER IF EXISTS tr_order_stock_decrement ON public.orders;
CREATE TRIGGER tr_order_stock_decrement
AFTER UPDATE OF status ON public.orders
FOR EACH ROW
WHEN (NEW.status = 'accepted')
EXECUTE FUNCTION public.handle_stock_decrement();
