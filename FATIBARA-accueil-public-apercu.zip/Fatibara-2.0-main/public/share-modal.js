/**
 * share-modal.js — safe stub / guard version
 *
 * Context
 * ───────
 * An older deployment of Fatibara included a share-modal feature whose JS was
 * added to the Workbox precache of the Service Worker at that time.  Even after
 * the feature was removed, browsers that still had the stale SW continued to
 * inject this script into every page, causing:
 *
 *   TypeError: Cannot read properties of null (reading 'addEventListener')
 *
 * because the script tried to attach event listeners to DOM elements that only
 * existed on the product-detail page.
 *
 * Fix strategy
 * ────────────
 * 1. This file is placed in /public so it is served statically by the new
 *    deployment, replacing whatever stale content the old SW cached.
 * 2. Every DOM query is wrapped in a null-guard — the script becomes a pure
 *    no-op on pages that don't have the share UI elements.
 * 3. The whole body is wrapped in a DOMContentLoaded listener so it runs only
 *    after the DOM is ready, regardless of where the <script> tag appears.
 * 4. A top-level try/catch prevents any remaining edge-case from propagating
 *    to the global error handler (window.onerror).
 *
 * This file intentionally contains NO imports, NO ES-module syntax, and NO
 * dynamic require() calls so it is safe to run as a classic script in any
 * browser context the old SW may inject it into.
 */

(function () {
  'use strict';

  // ── Helpers ──────────────────────────────────────────────────────────────────

  /** Safely query a single element; returns null (never throws). */
  function safeQuery(selector) {
    try {
      return document.querySelector(selector);
    } catch (_) {
      return null;
    }
  }

  /** Safely query by ID; returns null (never throws). */
  function safeById(id) {
    try {
      return document.getElementById(id);
    } catch (_) {
      return null;
    }
  }

  /** Safely add an event listener; does nothing if el is falsy. */
  function safeOn(el, event, fn) {
    if (el && typeof el.addEventListener === 'function') {
      el.addEventListener(event, fn);
    }
  }

  // ── Share modal logic (guarded) ───────────────────────────────────────────────

  function initShareModal() {
    try {
      // Resolve the share trigger — accept either a dedicated button or any
      // element marked with [data-share-modal].
      var shareBtn =
        safeById('share-btn') ||
        safeQuery('[data-share-modal]') ||
        safeQuery('[data-action="share"]');

      if (!shareBtn) {
        // Not a page that has the share UI — exit silently.
        return;
      }

      var modal =
        safeById('share-modal') ||
        safeQuery('.share-modal') ||
        safeQuery('[data-modal="share"]');

      var closeBtn =
        safeById('share-modal-close') ||
        safeQuery('[data-share-modal-close]');

      var copyLinkBtn =
        safeById('share-copy-link') ||
        safeQuery('[data-share-copy]');

      // ── Open ────────────────────────────────────────────────────────────────
      safeOn(shareBtn, 'click', function (e) {
        try {
          e.preventDefault();

          // Native Web Share API — preferred on mobile
          if (navigator.share) {
            navigator
              .share({
                title: document.title || 'Fatibara',
                url: window.location.href,
              })
              .catch(function () { /* User cancelled — ignore */ });
            return;
          }

          // Fallback: show the custom modal if it exists
          if (modal) {
            modal.removeAttribute('hidden');
            modal.setAttribute('aria-hidden', 'false');
            if (typeof modal.focus === 'function') modal.focus();
          }
        } catch (_) {
          // Never let a share-modal error bubble to window.onerror
        }
      });

      // ── Close ───────────────────────────────────────────────────────────────
      safeOn(closeBtn, 'click', function () {
        try {
          if (modal) {
            modal.setAttribute('hidden', '');
            modal.setAttribute('aria-hidden', 'true');
            if (shareBtn && typeof shareBtn.focus === 'function') shareBtn.focus();
          }
        } catch (_) { /* ignore */ }
      });

      // Close on backdrop click
      safeOn(modal, 'click', function (e) {
        try {
          if (e.target === modal) {
            modal.setAttribute('hidden', '');
            modal.setAttribute('aria-hidden', 'true');
          }
        } catch (_) { /* ignore */ }
      });

      // Close on Escape key
      safeOn(document, 'keydown', function (e) {
        try {
          if (e.key === 'Escape' && modal && !modal.hasAttribute('hidden')) {
            modal.setAttribute('hidden', '');
            modal.setAttribute('aria-hidden', 'true');
          }
        } catch (_) { /* ignore */ }
      });

      // ── Copy link ────────────────────────────────────────────────────────────
      safeOn(copyLinkBtn, 'click', function () {
        try {
          var url = window.location.href;
          if (navigator.clipboard && navigator.clipboard.writeText) {
            navigator.clipboard.writeText(url).catch(function () { /* ignore */ });
          } else {
            // Legacy fallback
            var ta = document.createElement('textarea');
            ta.value = url;
            ta.style.position = 'fixed';
            ta.style.opacity = '0';
            document.body.appendChild(ta);
            ta.select();
            try { document.execCommand('copy'); } catch (_) { /* ignore */ }
            document.body.removeChild(ta);
          }
        } catch (_) { /* ignore */ }
      });

    } catch (err) {
      // Absolute last-resort guard — do not re-throw
      if (typeof console !== 'undefined' && console.debug) {
        console.debug('[share-modal] Caught internal error (suppressed):', err && err.message);
      }
    }
  }

  // ── Bootstrap ────────────────────────────────────────────────────────────────

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initShareModal);
  } else {
    // DOM already parsed (script injected after DOMContentLoaded by the SW)
    initShareModal();
  }
}());
