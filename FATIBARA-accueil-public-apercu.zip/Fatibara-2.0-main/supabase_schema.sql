-- Platform Foundation - Supabase Schema & RLS Policies

-- Enable UUID extension if not already enabled
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Clean up existing tables to avoid "already exists" errors (Full Reset)
-- WARNING: This will delete existing data in these tables.
DROP TABLE IF EXISTS public.coupons CASCADE;
DROP TABLE IF EXISTS public.notifications CASCADE;
DROP TABLE IF EXISTS public.product_views CASCADE;
DROP TABLE IF EXISTS public.user_wishlists CASCADE;
DROP TABLE IF EXISTS public.cart_items CASCADE;
DROP TABLE IF EXISTS public.order_items CASCADE;
DROP TABLE IF EXISTS public.reviews CASCADE;
DROP TABLE IF EXISTS public.orders CASCADE;
DROP TABLE IF EXISTS public.referrals CASCADE;
DROP TABLE IF EXISTS public.messages CASCADE;
DROP TABLE IF EXISTS public.conversations CASCADE;
DROP TABLE IF EXISTS public.products CASCADE;
DROP TABLE IF EXISTS public.stores CASCADE;
DROP TABLE IF EXISTS public.profiles CASCADE;

-- 1. Profiles Table (Extends auth.users)
CREATE TABLE public.profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  full_name TEXT,
  avatar_url TEXT,
  profile_type TEXT DEFAULT 'client' CHECK (profile_type IN ('client', 'pro', 'vendor', 'admin')),
  phone_number TEXT,
  is_pro_member BOOLEAN DEFAULT false,
  is_admin BOOLEAN DEFAULT false,
  wallet_balance NUMERIC DEFAULT 0,
  loyalty_points INTEGER DEFAULT 0,
  referral_code TEXT UNIQUE,
  saved_address JSONB,
  followed_vendors TEXT[] DEFAULT '{}',
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Trigger to create profile on signup
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO public.profiles (id)
  VALUES (new.id);
  RETURN new;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE PROCEDURE public.handle_new_user();

-- 2. Stores Table (Must exist before products and conversations)
CREATE TABLE public.stores (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  owner_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE,
  store_name TEXT NOT NULL,
  description TEXT,
  avatar_url TEXT,
  banner_url TEXT,
  location_commune TEXT DEFAULT 'Conakry',
  location_region TEXT DEFAULT 'Conakry',
  contact_phone TEXT,
  whatsapp_number TEXT,
  is_verified_store BOOLEAN DEFAULT false,
  is_open BOOLEAN DEFAULT true,
  rating NUMERIC DEFAULT 4.5,
  response_rate INTEGER DEFAULT 98,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 3. Products Table
CREATE TABLE public.products (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  store_id UUID REFERENCES public.stores(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  description TEXT,
  price_gnf NUMERIC NOT NULL,
  wholesale_price_gnf NUMERIC,
  image_urls TEXT[] DEFAULT '{}',
  category TEXT,
  stock_quantity INTEGER DEFAULT 0,
  max_stock INTEGER DEFAULT 100,
  is_verified BOOLEAN DEFAULT true,
  is_active BOOLEAN DEFAULT true,
  variations JSONB DEFAULT '[]',
  is_hero BOOLEAN DEFAULT false,
  is_featured BOOLEAN DEFAULT false,
  popularity INTEGER DEFAULT 0,
  relevance INTEGER DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 3.1 Product Views Table (Analytics)
CREATE TABLE public.product_views (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  product_id UUID REFERENCES public.products(id) ON DELETE CASCADE,
  user_id UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
  viewed_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE public.product_views ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Anyone can insert views" ON public.product_views FOR INSERT WITH CHECK (true);
CREATE POLICY "Store owners can see their product views" ON public.product_views FOR SELECT USING (EXISTS (SELECT 1 FROM public.products p JOIN public.stores s ON p.store_id = s.id WHERE p.id = product_views.product_id AND s.owner_id = auth.uid()));

-- 3.2 Notifications Table
CREATE TABLE public.notifications (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE,
  type TEXT NOT NULL,
  title TEXT NOT NULL,
  message TEXT NOT NULL,
  is_read BOOLEAN DEFAULT false,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE public.notifications ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users can see their own notifications" ON public.notifications FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "System can insert notifications" ON public.notifications FOR INSERT WITH CHECK (true);

-- 3.3 Coupons Table
CREATE TABLE public.coupons (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  code TEXT UNIQUE NOT NULL,
  discount_percentage INTEGER NOT NULL,
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE public.coupons ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Anyone can see active coupons" ON public.coupons FOR SELECT USING (is_active = true);

-- 4. Conversations Table
CREATE TABLE public.conversations (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE,
  store_id UUID REFERENCES public.stores(id) ON DELETE CASCADE,
  last_message TEXT,
  updated_at TIMESTAMPTZ DEFAULT NOW(),
  created_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(user_id, store_id)
);

-- 5. Messages Table
CREATE TABLE public.messages (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  conversation_id UUID REFERENCES public.conversations(id) ON DELETE CASCADE,
  sender_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE,
  content TEXT NOT NULL,
  is_read BOOLEAN DEFAULT false,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 6. Referrals Table
CREATE TABLE public.referrals (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  referrer_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE,
  referred_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE,
  status TEXT DEFAULT 'pending', 
  points_earned INTEGER DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(referred_id)
);

-- 7. Orders Table
CREATE TABLE public.orders (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  vendor_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE,
  user_id UUID REFERENCES public.profiles(id) ON DELETE SET NULL, 
  total_amount NUMERIC NOT NULL,
  delivery_fee NUMERIC DEFAULT 0,
  shipping_address JSONB,
  items_count INTEGER DEFAULT 1,
  status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'paid', 'accepted', 'preparing', 'in_transit', 'shipped', 'delivered', 'cancelled')),
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 8. Order Items Table
CREATE TABLE public.order_items (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  order_id UUID REFERENCES public.orders(id) ON DELETE CASCADE,
  product_id UUID REFERENCES public.products(id) ON DELETE SET NULL,
  quantity INTEGER NOT NULL DEFAULT 1,
  price_at_purchase NUMERIC NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 9. Reviews Table
CREATE TABLE public.reviews (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  product_id UUID REFERENCES public.products(id) ON DELETE CASCADE,
  store_id UUID REFERENCES public.stores(id) ON DELETE CASCADE,
  user_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE,
  user_name TEXT,
  rating INTEGER CHECK (rating >= 1 AND rating <= 5),
  comment TEXT,
  location TEXT,
  avatar_url TEXT,
  order_id UUID REFERENCES public.orders(id) ON DELETE SET NULL,
  is_verified_purchase BOOLEAN DEFAULT false,
  shop_response TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(user_id, product_id)
);

CREATE TABLE public.review_photos (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  review_id UUID REFERENCES public.reviews(id) ON DELETE CASCADE,
  photo_url TEXT NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 10. Wishlists Table
CREATE TABLE IF NOT EXISTS public.user_wishlists (
    id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
    user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
    product_id uuid REFERENCES public.products(id) ON DELETE CASCADE NOT NULL,
    created_at timestamp with time zone DEFAULT timezone('utc'::text, now()) NOT NULL,
    UNIQUE(user_id, product_id)
);

-- 11. Shopping Cart Table
CREATE TABLE IF NOT EXISTS public.cart_items (
    id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
    user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
    product_id uuid REFERENCES public.products(id) ON DELETE CASCADE NOT NULL,
    quantity integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT timezone('utc'::text, now()) NOT NULL,
    UNIQUE(user_id, product_id)
);

-- --- RLS POLICIES ---

-- Profiles
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Public profiles are viewable by everyone." ON public.profiles;
CREATE POLICY "Public profiles are viewable by everyone." ON public.profiles FOR SELECT USING (true);
DROP POLICY IF EXISTS "Users can insert their own profile." ON public.profiles;
CREATE POLICY "Users can insert their own profile." ON public.profiles FOR INSERT WITH CHECK (auth.uid() = id);
DROP POLICY IF EXISTS "Users can update own profile." ON public.profiles;
CREATE POLICY "Users can update own profile." ON public.profiles FOR UPDATE USING (auth.uid() = id);

-- Stores
ALTER TABLE public.stores ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Stores are viewable by everyone." ON public.stores;
CREATE POLICY "Stores are viewable by everyone." ON public.stores FOR SELECT USING (true);
DROP POLICY IF EXISTS "Users can insert their own stores." ON public.stores;
CREATE POLICY "Users can insert their own stores." ON public.stores FOR INSERT WITH CHECK (auth.uid() = owner_id);
DROP POLICY IF EXISTS "Users can update their own stores." ON public.stores;
CREATE POLICY "Users can update their own stores." ON public.stores FOR UPDATE USING (auth.uid() = owner_id);
DROP POLICY IF EXISTS "Users can delete their own stores." ON public.stores;
CREATE POLICY "Users can delete their own stores." ON public.stores FOR DELETE USING (auth.uid() = owner_id);

-- Products
ALTER TABLE public.products ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Products are viewable by everyone." ON public.products;
CREATE POLICY "Products are viewable by everyone." ON public.products FOR SELECT USING (true);
DROP POLICY IF EXISTS "Store owners can insert products into their stores." ON public.products;
CREATE POLICY "Store owners can insert products into their stores." ON public.products FOR INSERT WITH CHECK (EXISTS (SELECT 1 FROM public.stores WHERE stores.id = products.store_id AND stores.owner_id = auth.uid()));
DROP POLICY IF EXISTS "Store owners can update their own products." ON public.products;
CREATE POLICY "Store owners can update their own products." ON public.products FOR UPDATE USING (EXISTS (SELECT 1 FROM public.stores WHERE stores.id = products.store_id AND stores.owner_id = auth.uid()));
DROP POLICY IF EXISTS "Store owners can delete their own products." ON public.products;
CREATE POLICY "Store owners can delete their own products." ON public.products FOR DELETE USING (EXISTS (SELECT 1 FROM public.stores WHERE stores.id = products.store_id AND stores.owner_id = auth.uid()));

-- Conversations
ALTER TABLE public.conversations ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Users can see their own conversations." ON public.conversations;
CREATE POLICY "Users can see their own conversations." ON public.conversations FOR SELECT USING (auth.uid() = user_id OR EXISTS (SELECT 1 FROM public.stores WHERE stores.id = conversations.store_id AND stores.owner_id = auth.uid()));

-- Messages
ALTER TABLE public.messages ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Users can see messages in their conversations." ON public.messages;
CREATE POLICY "Users can see messages in their conversations." ON public.messages FOR SELECT USING (EXISTS (SELECT 1 FROM public.conversations WHERE conversations.id = messages.conversation_id AND (conversations.user_id = auth.uid() OR EXISTS (SELECT 1 FROM public.stores WHERE stores.id = conversations.store_id AND stores.owner_id = auth.uid()))));
DROP POLICY IF EXISTS "Users can insert messages into their conversations." ON public.messages;
CREATE POLICY "Users can insert messages into their conversations." ON public.messages FOR INSERT WITH CHECK (EXISTS (SELECT 1 FROM public.conversations WHERE conversations.id = conversation_id AND (conversations.user_id = auth.uid() OR EXISTS (SELECT 1 FROM public.stores WHERE stores.id = conversations.store_id AND stores.owner_id = auth.uid()))));

-- Referrals
ALTER TABLE public.referrals ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Users can see their own referral records." ON public.referrals;
CREATE POLICY "Users can see their own referral records." ON public.referrals FOR SELECT USING (auth.uid() = referrer_id OR auth.uid() = referred_id);

-- Orders
ALTER TABLE public.orders ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Users can insert their own orders." ON public.orders;
CREATE POLICY "Users can insert their own orders." ON public.orders FOR INSERT WITH CHECK (true); -- Allow insertion assuming client authenticated checks are handled in code, but ideally this would check auth.uid() or allow anon
DROP POLICY IF EXISTS "Vendors can view orders for their products." ON public.orders;
CREATE POLICY "Vendors can view orders for their products." ON public.orders FOR SELECT USING (auth.uid() = vendor_id OR auth.uid() = user_id);
DROP POLICY IF EXISTS "Vendors can update their orders." ON public.orders;
CREATE POLICY "Vendors can update their orders." ON public.orders FOR UPDATE USING (auth.uid() = vendor_id OR auth.uid() = user_id);

-- Order Items
ALTER TABLE public.order_items ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Users can insert order items" ON public.order_items;
CREATE POLICY "Users can insert order items" ON public.order_items FOR INSERT WITH CHECK (true);
DROP POLICY IF EXISTS "Users can view order items" ON public.order_items;
CREATE POLICY "Users can view order items" ON public.order_items FOR SELECT USING (EXISTS (SELECT 1 FROM public.orders WHERE orders.id = order_items.order_id AND (orders.user_id = auth.uid() OR orders.vendor_id = auth.uid())));

-- Reviews
ALTER TABLE public.reviews ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Reviews are viewable by everyone" ON public.reviews;
CREATE POLICY "Reviews are viewable by everyone" ON public.reviews FOR SELECT USING (true);
DROP POLICY IF EXISTS "Users can insert their own reviews" ON public.reviews;
CREATE POLICY "Users can insert their own reviews" ON public.reviews FOR INSERT WITH CHECK (auth.uid() = user_id);
DROP POLICY IF EXISTS "Users can update their own reviews" ON public.reviews;
CREATE POLICY "Users can update their own reviews" ON public.reviews FOR UPDATE USING (auth.uid() = user_id);
DROP POLICY IF EXISTS "Users can delete their own reviews" ON public.reviews;
CREATE POLICY "Users can delete their own reviews" ON public.reviews FOR DELETE USING (auth.uid() = user_id);

-- Wishlists
ALTER TABLE public.user_wishlists ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Users can manage their own wishlists" ON public.user_wishlists;
CREATE POLICY "Users can manage their own wishlists" ON public.user_wishlists FOR ALL USING (auth.uid() = user_id);

-- Cart Items
ALTER TABLE public.cart_items ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Users can manage their own cart" ON public.cart_items;
CREATE POLICY "Users can manage their own cart" ON public.cart_items FOR ALL USING (auth.uid() = user_id);


-- 12. Automated Inventory Management
CREATE OR REPLACE FUNCTION public.handle_stock_decrement()
RETURNS TRIGGER AS $$
BEGIN
  UPDATE public.products
  SET stock_quantity = stock_quantity - NEW.quantity
  WHERE id = NEW.product_id;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

DROP TRIGGER IF EXISTS on_order_item_created ON public.order_items;
CREATE TRIGGER on_order_item_created
  AFTER INSERT ON public.order_items
  FOR EACH ROW EXECUTE FUNCTION public.handle_stock_decrement();

-- Function to increment wallet balance (used by RPC)
CREATE OR REPLACE FUNCTION public.increment_wallet_balance(user_id uuid, amount numeric)
RETURNS void AS $$
BEGIN
  UPDATE public.profiles
  SET wallet_balance = COALESCE(wallet_balance, 0) + amount
  WHERE id = user_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- --- SEED DATA (Optional for local testing) ---
-- These inserts allow you to have data immediately after running the script.
-- Note: Store owners will be null until real users are linked.

INSERT INTO public.stores (id, store_name, description, location_commune, avatar_url, is_verified_store)
VALUES 
  ('11111111-1111-1111-1111-111111111111', 'Boutique Diallo', 'Spécialiste Apple et accessoires originaux.', 'Ratoma', 'https://picsum.photos/seed/diallo/200/200', true),
  ('22222222-2222-2222-2222-222222222222', 'Tech Store GN', 'Tout pour l''informatique et le gaming.', 'Kaloum', 'https://picsum.photos/seed/techgn/200/200', true),
  ('33333333-3333-3333-3333-333333333333', 'Sow Electronics', 'Vente de tablettes et smartphones haut de gamme.', 'Dixinn', 'https://picsum.photos/seed/sow/200/200', false);

INSERT INTO public.products (title, description, price_gnf, category, store_id, image_urls, stock_quantity, max_stock)
VALUES 
  ('Apple USB‑C 20W Power Adapter', 'Chargeur rapide Apple original. USB-C 20W.', 150000, 'ACCESSOIRES', '11111111-1111-1111-1111-111111111111', '{"https://picsum.photos/seed/apple1/600/600"}', 85, 100),
  ('iPhone 15 Pro Max 256GB', 'Titanium design, powerful camera.', 14500000, 'SMARTPHONES', '33333333-3333-3333-3333-333333333333', '{"https://picsum.photos/seed/iphone15a/600/600"}', 5, 10),
  ('MacBook Pro M3 14"', 'Puissance phénoménale pour les pros.', 22000000, 'ORDINATEURS', '22222222-2222-2222-2222-222222222222', '{"https://picsum.photos/seed/macbook/600/600"}', 10, 20);

INSERT INTO public.orders (total_amount, delivery_fee, items_count, shipping_address, status) VALUES 
(450000, 15000, 2, '{"region": "Conakry", "commune": "Kaloum"}', 'delivered'),
(150000, 15000, 1, '{"region": "Conakry", "commune": "Dixinn"}', 'pending'),
(1200000, 20000, 4, '{"region": "Conakry", "commune": "Ratoma"}', 'shipped');
