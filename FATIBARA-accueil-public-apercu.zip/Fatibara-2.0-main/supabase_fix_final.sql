
-- REFRESH STORES RLS POLICIES
-- This script ensures vendors can register their stores without RLS violations.

-- 1. Enable RLS
ALTER TABLE public.stores ENABLE ROW LEVEL SECURITY;

-- 2. Clear old policies to avoid overlapping conflicts
DROP POLICY IF EXISTS "Stores are viewable by everyone." ON public.stores;
DROP POLICY IF EXISTS "Users can insert their own stores." ON public.stores;
DROP POLICY IF EXISTS "Users can update their own stores." ON public.stores;
DROP POLICY IF EXISTS "Users can delete their own stores." ON public.stores;
DROP POLICY IF EXISTS "Admins can manage all stores" ON public.stores;
DROP POLICY IF EXISTS "View own store details" ON public.stores;
DROP POLICY IF EXISTS "Owner can view store payouts" ON public.stores;
DROP POLICY IF EXISTS "Admins can update any store" ON public.stores;
DROP POLICY IF EXISTS "Admins can delete any store" ON public.stores;

-- 3. Create Clean Policies

-- Everyone can see stores
CREATE POLICY "Stores are viewable by everyone." 
ON public.stores FOR SELECT 
USING (true);

-- Authenticated users can insert if they set themselves as owner
-- We use TO authenticated to ensure anon users can't try and fail
CREATE POLICY "Users can insert their own stores." 
ON public.stores FOR INSERT 
TO authenticated 
WITH CHECK (auth.uid() = owner_id);

-- Owners and Admins can update
CREATE POLICY "Users can update their own stores" 
ON public.stores FOR UPDATE 
TO authenticated 
USING (auth.uid() = owner_id OR public.is_admin())
WITH CHECK (auth.uid() = owner_id OR public.is_admin());

-- Owners and Admins can delete
CREATE POLICY "Users can delete their own stores" 
ON public.stores FOR DELETE 
TO authenticated 
USING (auth.uid() = owner_id OR public.is_admin());

-- 4. Global Admin Override (Optional but good for safety)
-- This ensures admins can help vendors via the dashboard
CREATE POLICY "Admins can insert any store" 
ON public.stores FOR INSERT 
TO authenticated 
WITH CHECK (public.is_admin());

-- 5. Helper for Staff/Owner checks (Phase 5)
-- These extra SELECT policies can be added if needed for staff access
-- But for now, owner_id check is primary.
