/**
 * apply_courier_rls_migration.ts
 * ─────────────────────────────────────────────────────────────────────────────
 * Applies migration 20260807000001_courier_role_and_rls_fix.sql to the live
 * Supabase project via the service-role client's RPC exec_sql function.
 *
 * Usage:
 *   npx tsx apply_courier_rls_migration.ts
 */

import { createClient } from '@supabase/supabase-js';
import * as fs from 'fs';
import * as path from 'path';
import * as dotenv from 'dotenv';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

dotenv.config({ path: path.join(__dirname, '.env') });
dotenv.config({ path: path.join(__dirname, '.env.local'), override: true });

const SUPABASE_URL     = process.env.VITE_SUPABASE_URL;
const SERVICE_ROLE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY;

if (!SUPABASE_URL || !SERVICE_ROLE_KEY) {
  console.error('❌ VITE_SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY must be set in .env');
  process.exit(1);
}

const supabase = createClient(SUPABASE_URL, SERVICE_ROLE_KEY, {
  auth: { persistSession: false, autoRefreshToken: false },
});

const MIGRATION_FILE = path.join(
  __dirname,
  'supabase/migrations/20260807000001_courier_role_and_rls_fix.sql'
);

const sql = fs.readFileSync(MIGRATION_FILE, 'utf-8');

// ── Split into individual statements ─────────────────────────────────────────
// Split on semicolons followed by newline (handles DO $$ blocks as single unit)
function splitStatements(rawSql: string): string[] {
  const statements: string[] = [];
  let current = '';
  let dollarDepth = 0;

  for (const line of rawSql.split('\n')) {
    const trimmed = line.trim();
    // Track $$ block depth
    const dollarsInLine = (line.match(/\$\$/g) ?? []).length;
    if (dollarsInLine % 2 !== 0) dollarDepth = dollarDepth > 0 ? 0 : 1;

    current += line + '\n';

    // Only split on ; at top level (not inside $$ blocks)
    if (dollarDepth === 0 && trimmed.endsWith(';')) {
      const stmt = current.trim();
      if (stmt && !stmt.startsWith('--')) {
        statements.push(stmt);
      }
      current = '';
    }
  }
  if (current.trim()) statements.push(current.trim());
  return statements.filter(s => s.length > 0);
}

async function runSQL(stmt: string): Promise<void> {
  const { error } = await supabase.rpc('exec_sql', { sql_query: stmt });
  if (error) {
    // Try alternative RPC name
    const { error: error2 } = await supabase.rpc('exec_sql_query', { query: stmt });
    if (error2) throw new Error(`exec_sql failed: ${error.message} | exec_sql_query failed: ${error2.message}`);
  }
}

async function applyMigration(): Promise<void> {
  console.log('🚀 Applying migration: 20260807000001_courier_role_and_rls_fix.sql\n');

  const statements = splitStatements(sql);
  console.log(`   Found ${statements.length} statement(s) to execute\n`);

  let applied = 0;
  let skipped = 0;

  for (let i = 0; i < statements.length; i++) {
    const stmt = statements[i];
    const preview = stmt.replace(/\s+/g, ' ').slice(0, 80);
    process.stdout.write(`  [${i + 1}/${statements.length}] ${preview}… `);

    try {
      await runSQL(stmt);
      console.log('✅');
      applied++;
    } catch (err: any) {
      // Skip if the error is a "policy already exists" or "does not exist" type
      const msg = err.message ?? '';
      if (
        msg.includes('already exists') ||
        msg.includes('does not exist') ||
        msg.includes('duplicate') ||
        msg.includes('exec_sql')  // RPC not available — try direct approach
      ) {
        console.log(`⚠️  ${msg.slice(0, 60)}`);
        skipped++;
      } else {
        console.error(`\n❌ Failed: ${msg}`);
        process.exit(1);
      }
    }
  }

  console.log(`\n✅ Migration complete: ${applied} applied, ${skipped} skipped`);
  console.log('   NOTIFY pgrst reload schema sent via migration.\n');
}

applyMigration().catch(err => {
  console.error('❌ Unexpected error:', err);
  process.exit(1);
});
