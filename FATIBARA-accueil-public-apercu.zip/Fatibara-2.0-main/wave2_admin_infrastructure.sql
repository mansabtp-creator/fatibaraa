
-- WAVE 2: INFRASTRUCTURE & ADMIN CONTROLS REPAIR
-- This script aligns the database with the Admin Dashboard expectations.

-- 1. AUDIT LOGS ALIGNMENT
-- The code expects specific column names different from some versions of the schema.
DO $$ 
BEGIN
  -- Add columns if missing
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='audit_logs' AND column_name='user_id') THEN
    ALTER TABLE public.audit_logs ADD COLUMN user_id UUID REFERENCES public.profiles(id);
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='audit_logs' AND column_name='entity_type') THEN
    ALTER TABLE public.audit_logs ADD COLUMN entity_type TEXT;
  END IF;

  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='audit_logs' AND column_name='entity_id') THEN
    ALTER TABLE public.audit_logs ADD COLUMN entity_id TEXT;
  END IF;

  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='audit_logs' AND column_name='new_data') THEN
    ALTER TABLE public.audit_logs ADD COLUMN new_data JSONB;
  END IF;
END $$;

-- 2. ANNOUNCEMENTS TARGET FIX
-- Ensure target_role exists
DO $$ 
BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='announcements' AND column_name='target_role') THEN
    ALTER TABLE public.announcements ADD COLUMN target_role TEXT DEFAULT 'all';
  END IF;
END $$;

-- 3. IS_ADMIN HELPER FUNCTION
-- Critical for RLS policies to avoid recursion
CREATE OR REPLACE FUNCTION public.is_admin()
RETURNS boolean AS $$
BEGIN
  RETURN EXISTS (
    SELECT 1 FROM public.profiles
    WHERE id = auth.uid() AND is_admin = true
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- 4. REFRESH RLS POLICIES FOR ADMIN ACCESS
-- Platform Settings
DROP POLICY IF EXISTS "Admin only write for settings" ON public.platform_settings;
CREATE POLICY "Admin only write for settings" 
ON public.platform_settings FOR ALL 
USING (public.is_admin());

-- Audit Logs
DROP POLICY IF EXISTS "Admins can view audit logs" ON public.audit_logs;
CREATE POLICY "Admins can view audit logs" 
ON public.audit_logs FOR SELECT 
USING (public.is_admin());

-- Announcements
DROP POLICY IF EXISTS "Admin full access to announcements" ON public.announcements;
CREATE POLICY "Admin full access to announcements" 
ON public.announcements FOR ALL 
USING (public.is_admin());

-- 5. NEW PLATFORM LOGS VIEW (OPTIONAL)
-- Ensuring platform_logs exists for the finance tab
CREATE TABLE IF NOT EXISTS public.platform_logs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    amount NUMERIC DEFAULT 0,
    type TEXT, -- 'commission', 'withdrawal_fee', etc.
    description TEXT,
    reference_id UUID,
    metadata JSONB,
    created_at TIMESTAMPTZ DEFAULT now()
);

-- Policy for platform logs
ALTER TABLE public.platform_logs ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Admins see platform logs" ON public.platform_logs;
CREATE POLICY "Admins see platform logs" ON public.platform_logs FOR SELECT USING (public.is_admin());

COMMENT ON TABLE public.audit_logs IS 'Admin Security Audit Trail';
