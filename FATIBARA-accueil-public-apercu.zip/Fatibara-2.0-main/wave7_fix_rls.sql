-- ADD INSERT POLICIES FOR WAVE 7 TABLES
CREATE POLICY "Admins can insert health logs" 
ON public.system_health_logs FOR INSERT 
WITH CHECK (EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND is_admin = true));

CREATE POLICY "Admins can insert/update housekeeping tasks" 
ON public.housekeeping_tasks FOR INSERT 
WITH CHECK (EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND is_admin = true));

CREATE POLICY "Admins can update housekeeping tasks" 
ON public.housekeeping_tasks FOR UPDATE 
USING (EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND is_admin = true));
