-- 1. Update existing Profiles Table safely
ALTER TABLE public.profiles 
  ADD COLUMN IF NOT EXISTS profile_type TEXT DEFAULT 'client' CHECK (profile_type IN ('client', 'pro', 'vendor', 'admin')),
  ADD COLUMN IF NOT EXISTS is_admin BOOLEAN DEFAULT false,
  ADD COLUMN IF NOT EXISTS full_name TEXT,
  ADD COLUMN IF NOT EXISTS phone_number TEXT,
  ADD COLUMN IF NOT EXISTS wallet_balance NUMERIC DEFAULT 0;

-- Ensure RLS is enabled
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

-- Safely recreate policies for profiles
DROP POLICY IF EXISTS "Public profiles are viewable by everyone." ON public.profiles;
CREATE POLICY "Public profiles are viewable by everyone." ON public.profiles FOR SELECT USING (true);

DROP POLICY IF EXISTS "Users can insert their own profile." ON public.profiles;
CREATE POLICY "Users can insert their own profile." ON public.profiles FOR INSERT WITH CHECK (auth.uid() = id);

DROP POLICY IF EXISTS "Users can update own profile." ON public.profiles;
CREATE POLICY "Users can update own profile." ON public.profiles FOR UPDATE USING (auth.uid() = id);

-- Safely recreate trigger
CREATE OR REPLACE FUNCTION public.handle_new_user() 
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO public.profiles (id, full_name)
  VALUES (new.id, new.raw_user_meta_data->>'full_name')
  ON CONFLICT (id) DO NOTHING;
  RETURN new;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE PROCEDURE public.handle_new_user();


-- 2. Create or Update Products Table safely
DROP TABLE IF EXISTS public.products CASCADE;
CREATE TABLE public.products (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  description TEXT,
  price NUMERIC NOT NULL,
  image_url TEXT,
  stock INTEGER DEFAULT 0,
  location TEXT DEFAULT 'Conakry',
  seller_name TEXT,
  vendor_region TEXT DEFAULT 'Conakry',
  status TEXT DEFAULT 'published' CHECK (status IN ('draft', 'published', 'scheduled')),
  is_hero BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now())
);

ALTER TABLE public.products ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Products are viewable by everyone." ON public.products;
CREATE POLICY "Products are viewable by everyone." ON public.products FOR SELECT USING (true);

DROP POLICY IF EXISTS "Authenticated users can insert products" ON public.products;
CREATE POLICY "Authenticated users can insert products" ON public.products FOR INSERT WITH CHECK (auth.role() = 'authenticated');


-- 3. Recreate Orders Table (Drop if exists to ensure schema matches perfectly)
DROP TABLE IF EXISTS public.orders CASCADE;

CREATE TABLE public.orders (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  vendor_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE,
  user_id UUID REFERENCES public.profiles(id) ON DELETE SET NULL, 
  customer_name TEXT NOT NULL,
  items_count INTEGER DEFAULT 1,
  amount NUMERIC NOT NULL,
  location TEXT,
  status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'shipped', 'delivered', 'cancelled', 'paid')),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now())
);

ALTER TABLE public.orders ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users and vendors can view orders." ON public.orders FOR SELECT USING (auth.uid() = user_id OR auth.uid() = vendor_id);
CREATE POLICY "Users can insert their own orders." ON public.orders FOR INSERT WITH CHECK (true);
CREATE POLICY "Vendors can update orders." ON public.orders FOR UPDATE USING (auth.uid() = vendor_id);


-- 4. Create Vendor Follows Table
CREATE TABLE IF NOT EXISTS public.vendor_follows (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE,
  seller_name TEXT NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL,
  UNIQUE(user_id, seller_name)
);

ALTER TABLE public.vendor_follows ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Users can view their own follows." ON public.vendor_follows;
CREATE POLICY "Users can view their own follows." ON public.vendor_follows FOR SELECT USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "Users can insert their own follows." ON public.vendor_follows;
CREATE POLICY "Users can insert their own follows." ON public.vendor_follows FOR INSERT WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "Users can delete their own follows." ON public.vendor_follows;
CREATE POLICY "Users can delete their own follows." ON public.vendor_follows FOR DELETE USING (auth.uid() = user_id);


-- 5. Create Cart Items Table
CREATE TABLE IF NOT EXISTS public.cart_items (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE,
  product_id UUID REFERENCES public.products(id) ON DELETE CASCADE,
  quantity INTEGER DEFAULT 1,
  selected_variations JSONB DEFAULT '{}',
  created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL,
  UNIQUE(user_id, product_id, selected_variations)
);

ALTER TABLE public.cart_items ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Users can manage their own cart" ON public.cart_items;
CREATE POLICY "Users can manage their own cart" ON public.cart_items 
  FOR ALL USING (auth.uid() = user_id);

-- 6. Create Deliveries Table
CREATE TABLE IF NOT EXISTS public.deliveries (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  order_id UUID REFERENCES public.orders(id) ON DELETE CASCADE,
  courier_id UUID REFERENCES public.profiles(id),
  status TEXT DEFAULT 'assigned' CHECK (status IN ('assigned', 'picked_up', 'in_transit', 'delivered')),
  current_location JSONB,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now())
);

ALTER TABLE public.deliveries ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view their order deliveries." ON public.deliveries FOR SELECT USING (true); -- Simplified for now, needs refinement.
CREATE POLICY "Couriers can update deliveries." ON public.deliveries FOR UPDATE USING (auth.uid() = courier_id);


-- 7. Insert Mock Data for Products (Only if they don't already exist)
INSERT INTO public.products (name, description, price, image_url, stock, location, seller_name, vendor_region)
SELECT * FROM (VALUES 
  ('Apple USB‑C 20W Power Adapter', 'Chargeur rapide Apple original.', 150000, 'https://picsum.photos/seed/apple/400/400', 15, 'Madina, Conakry', 'Boutique Diallo', 'Conakry'),
  ('TWS Wireless BT5 – Écouteurs', 'Écouteurs sans fil haute qualité.', 120000, 'https://picsum.photos/seed/tws/400/400', 3, 'Kipé, Conakry', 'Tech Store GN', 'Conakry'),
  ('Power Bank Haute Capacité', 'Batterie externe 20000mAh.', 250000, 'https://picsum.photos/seed/powerbank/400/400', 0, 'Marché Niger, Conakry', 'Sow Electronics', 'Conakry'),
  ('Beats Casque Sans Fil', 'Son immersif et basses puissantes.', 850000, 'https://picsum.photos/seed/beats/400/400', 8, 'Labé Centre', 'Fouta Tech', 'Labé'),
  ('Casque Sans Fil Bose', 'Réduction de bruit active.', 1200000, 'https://picsum.photos/seed/bose/400/400', 2, 'Kaloum, Conakry', 'Premium Audio', 'Conakry'),
  ('Microphone Sans Fil K11', 'Double micro pour vlogging.', 180000, 'https://picsum.photos/seed/mic/400/400', 25, 'Kindia Ville', 'Kindia Shop', 'Kindia')
) AS v(name, description, price, image_url, stock, location, seller_name, vendor_region)
WHERE NOT EXISTS (SELECT 1 FROM public.products WHERE name = v.name);
