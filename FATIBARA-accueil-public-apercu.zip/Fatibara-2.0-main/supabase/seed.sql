-- ==============================================================================
-- FATIBARA 2.0 — LOCAL DEVELOPMENT SEED
-- File: supabase/seed.sql
-- Purpose: Populate the local DB with realistic test data after db reset.
--
-- ACCOUNTS (use with Supabase local Auth, password: "fatibara123" for all)
--   buyer@fatibara.local   — Buyer,   wallet 2,000,000 GNF
--   vendor@fatibara.local  — Vendor,  store owner
--   courier@fatibara.local — Courier, wallet 500,000 GNF
--   admin@fatibara.local   — Admin,   is_admin = true
--
-- All statements are idempotent (ON CONFLICT DO NOTHING / DO UPDATE).
-- ==============================================================================

-- ══════════════════════════════════════════════════════════════════════════════
-- SECTION 0 — Stable seed IDs
-- Using deterministic UUIDs so re-running seed is safe
-- ══════════════════════════════════════════════════════════════════════════════

-- Profiles
-- buyer   : 11000001-0000-0000-0000-000000000001
-- vendor  : 11000001-0000-0000-0000-000000000002
-- courier : 11000001-0000-0000-0000-000000000003
-- admin   : 11000001-0000-0000-0000-000000000004

-- Store
-- Conakry Electronics & Gear : 22000001-0000-0000-0000-000000000001

-- Products
-- Galaxy A54      : 33000001-0000-0000-0000-000000000001
-- Écouteurs BT    : 33000001-0000-0000-0000-000000000002
-- Power Bank      : 33000001-0000-0000-0000-000000000003
-- Montre Connectée: 33000001-0000-0000-0000-000000000004
-- Câble USB-C     : 33000001-0000-0000-0000-000000000005
-- Coque Samsung   : 33000001-0000-0000-0000-000000000006

-- Orders
-- Pending         : 44000001-0000-0000-0000-000000000001
-- Delivered       : 44000001-0000-0000-0000-000000000002
-- COD In-Transit  : 44000001-0000-0000-0000-000000000003

-- ══════════════════════════════════════════════════════════════════════════════
-- SECTION 1 — auth.users
-- password: fatibara123  (bcrypt hash of 'fatibara123')
-- ══════════════════════════════════════════════════════════════════════════════
INSERT INTO auth.users (
  id, instance_id, aud, role, email, encrypted_password,
  email_confirmed_at, created_at, updated_at,
  raw_app_meta_data, raw_user_meta_data,
  -- String fields that GoTrue scans as non-nullable Go strings:
  -- must be '' (empty) not NULL or GoTrue crashes with
  -- "converting NULL to string is unsupported" on login.
  confirmation_token, recovery_token,
  email_change, email_change_token_new,
  email_change_token_current, reauthentication_token,
  phone_change, phone_change_token
) VALUES
  -- Buyer  (password: fatibara123)
  ('11000001-0000-0000-0000-000000000001',
   '00000000-0000-0000-0000-000000000000',
   'authenticated', 'authenticated',
   'buyer@fatibara.local',
   crypt('fatibara123', gen_salt('bf', 10)),
   NOW(), NOW() - INTERVAL '30 days', NOW(),
   '{"provider":"email","providers":["email"]}',
   '{"full_name":"Mamadou Diallo"}',
   '', '', '', '', '', '', '', ''),

  -- Vendor  (password: fatibara123)
  ('11000001-0000-0000-0000-000000000002',
   '00000000-0000-0000-0000-000000000000',
   'authenticated', 'authenticated',
   'vendor@fatibara.local',
   crypt('fatibara123', gen_salt('bf', 10)),
   NOW(), NOW() - INTERVAL '60 days', NOW(),
   '{"provider":"email","providers":["email"]}',
   '{"full_name":"Ibrahima Sow"}',
   '', '', '', '', '', '', '', ''),

  -- Courier  (password: fatibara123)
  ('11000001-0000-0000-0000-000000000003',
   '00000000-0000-0000-0000-000000000000',
   'authenticated', 'authenticated',
   'courier@fatibara.local',
   crypt('fatibara123', gen_salt('bf', 10)),
   NOW(), NOW() - INTERVAL '15 days', NOW(),
   '{"provider":"email","providers":["email"]}',
   '{"full_name":"Fatoumata Camara"}',
   '', '', '', '', '', '', '', ''),

  -- Admin  (password: fatibara123)
  ('11000001-0000-0000-0000-000000000004',
   '00000000-0000-0000-0000-000000000000',
   'authenticated', 'authenticated',
   'admin@fatibara.local',
   crypt('fatibara123', gen_salt('bf', 10)),
   NOW(), NOW() - INTERVAL '90 days', NOW(),
   '{"provider":"email","providers":["email"]}',
   '{"full_name":"Admin Fatibara"}',
   '', '', '', '', '', '', '', '')
ON CONFLICT (id) DO UPDATE SET
  encrypted_password = crypt('fatibara123', gen_salt('bf', 10)),
  email_confirmed_at = COALESCE(auth.users.email_confirmed_at, NOW()),
  email_change             = '',
  email_change_token_new   = '',
  email_change_token_current = '',
  reauthentication_token   = '';

-- ══════════════════════════════════════════════════════════════════════════════
-- SECTION 2 — Profiles
-- ══════════════════════════════════════════════════════════════════════════════
INSERT INTO public.profiles (
  id, full_name, phone_number, profile_type,
  is_pro_member, is_admin,
  wallet_balance, loyalty_points,
  courier_status, is_courier_online, courier_zone,
  referral_code, created_at
) VALUES
  -- Buyer
  ('11000001-0000-0000-0000-000000000001',
   'Mamadou Diallo', '+224 620 11 22 33', 'client',
   false, false,
   2000000, 150,
   NULL, false, NULL,
   'MDIALLO2024', NOW() - INTERVAL '30 days'),

  -- Vendor
  ('11000001-0000-0000-0000-000000000002',
   'Ibrahima Sow', '+224 655 44 55 66', 'vendor',
   true, false,
   250000, 0,
   NULL, false, NULL,
   'ISOW2024', NOW() - INTERVAL '60 days'),

  -- Courier
  ('11000001-0000-0000-0000-000000000003',
   'Fatoumata Camara', '+224 628 77 88 99', 'courier',
   false, false,
   500000, 0,
   'available', true, 'Kaloum–Dixinn',
   'FCAMARA2024', NOW() - INTERVAL '15 days'),

  -- Admin
  ('11000001-0000-0000-0000-000000000004',
   'Admin Fatibara', '+224 600 00 00 00', 'admin',
   true, true,
   0, 0,
   NULL, false, NULL,
   NULL, NOW() - INTERVAL '90 days')
ON CONFLICT (id) DO UPDATE SET
  full_name         = EXCLUDED.full_name,
  phone_number      = EXCLUDED.phone_number,
  profile_type      = EXCLUDED.profile_type,
  is_pro_member     = EXCLUDED.is_pro_member,
  is_admin          = EXCLUDED.is_admin,
  wallet_balance    = EXCLUDED.wallet_balance,
  loyalty_points    = EXCLUDED.loyalty_points,
  courier_status    = EXCLUDED.courier_status,
  is_courier_online = EXCLUDED.is_courier_online,
  courier_zone      = EXCLUDED.courier_zone,
  referral_code     = EXCLUDED.referral_code;

-- ══════════════════════════════════════════════════════════════════════════════
-- SECTION 3 — Store
-- ══════════════════════════════════════════════════════════════════════════════
INSERT INTO public.stores (
  id, owner_id,
  store_name, description,
  location_commune, location_region,
  contact_phone, whatsapp_number,
  is_verified_store, is_open, chat_enabled,
  rating, response_rate, commission_rate,
  balance, created_at
) VALUES (
  '22000001-0000-0000-0000-000000000001',
  '11000001-0000-0000-0000-000000000002',
  'Conakry Electronics & Gear',
  'Votre boutique de confiance pour les smartphones, accessoires et gadgets technologiques à Conakry. Produits 100% originaux garantis.',
  'Kaloum', 'Conakry',
  '+224 655 44 55 66', '+224 655 44 55 66',
  true, true, true,
  4.8, 97, 5,
  345000, NOW() - INTERVAL '60 days'
) ON CONFLICT (id) DO UPDATE SET
  balance  = EXCLUDED.balance,
  is_open  = EXCLUDED.is_open,
  rating   = EXCLUDED.rating;

-- ══════════════════════════════════════════════════════════════════════════════
-- SECTION 4 — Products (6 diverse SKUs, realistic GNF prices)
-- ══════════════════════════════════════════════════════════════════════════════
INSERT INTO public.products (
  id, store_id,
  title, description, category,
  price_gnf, wholesale_price_gnf,
  stock_quantity, max_stock,
  image_urls,
  is_verified, is_active, is_featured, is_hero,
  variations, popularity, relevance,
  vendor_region, location, created_at
) VALUES

  -- 1. Samsung Galaxy A54 5G
  ('33000001-0000-0000-0000-000000000001',
   '22000001-0000-0000-0000-000000000001',
   'Samsung Galaxy A54 5G — 128Go',
   'Smartphone Samsung Galaxy A54 5G, écran Super AMOLED 6.4", 128 Go de stockage, 8 Go RAM. Batterie 5000 mAh. Garantie 12 mois.',
   'Smartphones',
   3500000, 3000000,
   8, 20,
   ARRAY['https://images.unsplash.com/photo-1610945264803-c22b62831e8e?w=400'],
   true, true, true, true,
   '[{"name":"Couleur","options":["Noir Graphite","Blanc Crème","Violet Awesome"]},{"name":"Stockage","options":["128Go","256Go"]}]',
   245, 98,
   'Conakry', 'Kaloum, Conakry', NOW() - INTERVAL '55 days'),

  -- 2. Écouteurs Bluetooth TWS
  ('33000001-0000-0000-0000-000000000002',
   '22000001-0000-0000-0000-000000000001',
   'Écouteurs Bluetooth TWS Pro — Réduction Bruit Active',
   'Écouteurs sans fil True Wireless avec réduction active du bruit, autonomie 8h + 24h avec boîtier de charge. Résistance à l''eau IPX5.',
   'Audio & Accessoires',
   150000, 120000,
   25, 50,
   ARRAY['https://images.unsplash.com/photo-1590658268037-6bf12165a8df?w=400'],
   true, true, false, false,
   '[{"name":"Couleur","options":["Blanc","Noir","Bleu Navy"]}]',
   189, 85,
   'Conakry', 'Kaloum, Conakry', NOW() - INTERVAL '50 days'),

  -- 3. Power Bank 20 000 mAh
  ('33000001-0000-0000-0000-000000000003',
   '22000001-0000-0000-0000-000000000001',
   'Power Bank Solaire 20 000 mAh — Charge Rapide 65W',
   'Batterie externe avec panneau solaire intégré, charge rapide 65W USB-C PD. 3 ports de sortie. Idéal pour les coupures de courant.',
   'Batteries & Chargeurs',
   280000, 230000,
   15, 30,
   ARRAY['https://images.unsplash.com/photo-1609091839311-d5365f9ff1c5?w=400'],
   true, true, true, false,
   '[{"name":"Capacité","options":["10 000 mAh","20 000 mAh"]}]',
   132, 90,
   'Conakry', 'Kaloum, Conakry', NOW() - INTERVAL '45 days'),

  -- 4. Montre Connectée Sport
  ('33000001-0000-0000-0000-000000000004',
   '22000001-0000-0000-0000-000000000001',
   'Montre Connectée Sport — GPS + Cardiofréquencemètre',
   'Smartwatch sport avec GPS intégré, suivi cardio 24/7, 50+ modes sportifs, résistance à l''eau 5ATM. Compatible Android & iOS.',
   'Montres & Wearables',
   450000, 380000,
   6, 15,
   ARRAY['https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=400'],
   true, true, false, false,
   '[{"name":"Couleur bracelet","options":["Noir","Rouge","Bleu"]},{"name":"Taille","options":["Standard","Grand"]}]',
   98, 78,
   'Conakry', 'Kaloum, Conakry', NOW() - INTERVAL '40 days'),

  -- 5. Câble USB-C 3m Charge Rapide
  ('33000001-0000-0000-0000-000000000005',
   '22000001-0000-0000-0000-000000000001',
   'Câble USB-C vers USB-C — 3 mètres 100W',
   'Câble tressé en nylon USB-C/USB-C supporte la charge rapide 100W et le transfert de données jusqu''à 480Mb/s. 3 mètres de longueur.',
   'Câbles & Adaptateurs',
   35000, 26000,
   60, 100,
   ARRAY['https://images.unsplash.com/photo-1618478365723-5d7e27f48a13?w=400'],
   true, true, false, false,
   '[{"name":"Longueur","options":["1m","2m","3m"]},{"name":"Couleur","options":["Noir","Blanc","Rouge"]}]',
   310, 95,
   'Conakry', 'Kaloum, Conakry', NOW() - INTERVAL '35 days'),

  -- 6. Coque Samsung Galaxy A54 Antichoc
  ('33000001-0000-0000-0000-000000000006',
   '22000001-0000-0000-0000-000000000001',
   'Coque Samsung Galaxy A54 — Antichoc Militaire',
   'Protection renforcée grade militaire pour Samsung Galaxy A54. Double couche TPU + PC rigide. Protection tous angles.',
   'Coques & Protection',
   45000, 32000,
   40, 80,
   ARRAY['https://images.unsplash.com/photo-1541140532154-b024d705b90a?w=400'],
   true, true, false, false,
   '[{"name":"Couleur","options":["Transparent","Noir Mat","Bleu Cobalt","Rouge Rubis"]}]',
   156, 88,
   'Conakry', 'Kaloum, Conakry', NOW() - INTERVAL '30 days')

ON CONFLICT (id) DO UPDATE SET
  stock_quantity = EXCLUDED.stock_quantity,
  is_active      = EXCLUDED.is_active,
  price_gnf      = EXCLUDED.price_gnf;

-- ══════════════════════════════════════════════════════════════════════════════
-- SECTION 5 — Orders (3 lifecycle stages)
-- ══════════════════════════════════════════════════════════════════════════════

-- ── ORDER 1: Pending — buyer placed a wallet order, awaiting vendor acceptance
-- total_amount = 480,000 GNF (câble 35k + coque 45k × 2 + Power Bank 280k + shipping 20k)
INSERT INTO public.orders (
  id, user_id, vendor_id, store_id,
  customer_name, items_count, total_amount, delivery_fee, vendor_delivery_fee,
  shipping_address, tracking_number, delivery_otp,
  status, financial_status, created_at
) VALUES (
  '44000001-0000-0000-0000-000000000001',
  '11000001-0000-0000-0000-000000000001',
  '11000001-0000-0000-0000-000000000002',
  '22000001-0000-0000-0000-000000000001',
  'Mamadou Diallo', 4, 425000, 20000, 0,
  '{"payment_method":"wallet","commune":"Dixinn","quartier":"Donka","indications":"Près de l''hôpital Donka, portail bleu","phone":"+224 620 11 22 33"}',
  'FTB-2024-001', '7842',
  'pending', 'paid',
  NOW() - INTERVAL '2 hours'
) ON CONFLICT (id) DO NOTHING;

-- Order items for ORDER 1
INSERT INTO public.order_items (order_id, product_id, quantity, price_at_purchase, selected_variations)
VALUES
  ('44000001-0000-0000-0000-000000000001',
   '33000001-0000-0000-0000-000000000005', 1, 35000,
   '{"Longueur":"3m","Couleur":"Noir"}'),
  ('44000001-0000-0000-0000-000000000001',
   '33000001-0000-0000-0000-000000000006', 2, 45000,
   '{"Couleur":"Transparent"}'),
  ('44000001-0000-0000-0000-000000000001',
   '33000001-0000-0000-0000-000000000003', 1, 280000,
   '{"Capacité":"20 000 mAh"}')
ON CONFLICT DO NOTHING;

-- ── ORDER 2: Delivered — fully settled (wallet payment, courier assigned)
-- total_amount = 735,000 GNF (Galaxy A54 @ 3,500,000 ... wrong, let's do ecouteurs + montre)
-- ecouteurs 150,000 + montre 450,000 + delivery 35,000 = 635,000
-- Financial math (commission 5%):
--   items_real_value = 635,000 - 35,000 = 600,000
--   item_subtotal    = 600,000 / 1.05  = 571,428.57
--   platform_commission = 571,428.57 × 0.05 = 28,571 ≈ 28571
--   vendor_payout    = 571,428.57 - 0  = 571,428 ≈ 571429
--   courier_payout   = 35,000 × 0.8   = 28,000
INSERT INTO public.orders (
  id, user_id, vendor_id, store_id, courier_id,
  customer_name, items_count, total_amount, delivery_fee, vendor_delivery_fee,
  shipping_address, tracking_number, delivery_otp,
  status, financial_status, created_at, updated_at
) VALUES (
  '44000001-0000-0000-0000-000000000002',
  '11000001-0000-0000-0000-000000000001',
  '11000001-0000-0000-0000-000000000002',
  '22000001-0000-0000-0000-000000000001',
  '11000001-0000-0000-0000-000000000003',
  'Mamadou Diallo', 2, 635000, 35000, 0,
  '{"payment_method":"wallet","commune":"Matoto","quartier":"Bambéto","indications":"Rondpoint Bambéto, immeuble jaune, 2ème étage","phone":"+224 620 11 22 33"}',
  'FTB-2024-002', '5193',
  'delivered', 'processed',
  NOW() - INTERVAL '5 days', NOW() - INTERVAL '4 days'
) ON CONFLICT (id) DO NOTHING;

-- Order items for ORDER 2
INSERT INTO public.order_items (order_id, product_id, quantity, price_at_purchase, selected_variations)
VALUES
  ('44000001-0000-0000-0000-000000000002',
   '33000001-0000-0000-0000-000000000002', 1, 150000,
   '{"Couleur":"Blanc"}'),
  ('44000001-0000-0000-0000-000000000002',
   '33000001-0000-0000-0000-000000000004', 1, 450000,
   '{"Couleur bracelet":"Noir","Taille":"Standard"}')
ON CONFLICT DO NOTHING;

-- Settled wallet transactions for ORDER 2 (matches commission math above)
-- Buyer debit
INSERT INTO public.wallet_transactions
  (profile_id, amount, type, reference_id, description, status, created_at)
VALUES (
  '11000001-0000-0000-0000-000000000001',
  -635000, 'purchase', '44000001-0000-0000-0000-000000000002',
  'Paiement Portefeuille — Commande #44000001',
  'completed', NOW() - INTERVAL '5 days'
) ON CONFLICT DO NOTHING;

-- Vendor store credit (sale)
INSERT INTO public.wallet_transactions
  (profile_id, store_id, amount, type, reference_id, description, status, created_at)
VALUES (
  '11000001-0000-0000-0000-000000000002',
  '22000001-0000-0000-0000-000000000001',
  571429, 'sale', '44000001-0000-0000-0000-000000000002',
  'Vente #44000001 (Payout 571429)',
  'completed', NOW() - INTERVAL '5 days'
) ON CONFLICT DO NOTHING;

-- Courier delivery fee
INSERT INTO public.wallet_transactions
  (profile_id, amount, type, reference_id, description, status, created_at)
VALUES (
  '11000001-0000-0000-0000-000000000003',
  28000, 'delivery_fee', '44000001-0000-0000-0000-000000000002',
  'Course effectuée — Commande #44000001',
  'completed', NOW() - INTERVAL '4 days'
) ON CONFLICT DO NOTHING;

-- Platform commission log for ORDER 2
INSERT INTO public.platform_logs (type, amount, reference_id, metadata, created_at)
VALUES (
  'commission', 28571,
  '44000001-0000-0000-0000-000000000002',
  '{"order_total":635000,"vendor_id":"11000001-0000-0000-0000-000000000002","is_cash":false}',
  NOW() - INTERVAL '5 days'
) ON CONFLICT DO NOTHING;

-- Update store balance to reflect settled sale (guard: idempotent)
UPDATE public.stores
SET balance = balance + 571429
WHERE id = '22000001-0000-0000-0000-000000000001'
  AND NOT EXISTS (
    SELECT 1 FROM public.wallet_transactions
    WHERE reference_id = '44000001-0000-0000-0000-000000000002'::uuid
      AND type = 'sale'
      AND store_id  = '22000001-0000-0000-0000-000000000001'::uuid
  );

-- Update courier balance (guard: idempotent)
UPDATE public.profiles
SET wallet_balance = wallet_balance + 28000
WHERE id = '11000001-0000-0000-0000-000000000003'
  AND NOT EXISTS (
    SELECT 1 FROM public.wallet_transactions
    WHERE reference_id = '44000001-0000-0000-0000-000000000002'::uuid
      AND profile_id  = '11000001-0000-0000-0000-000000000003'::uuid
      AND type        = 'delivery_fee'
  );

-- Deduct buyer balance for the settled order (guard: idempotent)
UPDATE public.profiles
SET wallet_balance = GREATEST(0, wallet_balance - 635000)
WHERE id = '11000001-0000-0000-0000-000000000001'
  AND NOT EXISTS (
    SELECT 1 FROM public.wallet_transactions
    WHERE reference_id = '44000001-0000-0000-0000-000000000002'::uuid
      AND profile_id  = '11000001-0000-0000-0000-000000000001'::uuid
      AND type        = 'purchase'
  );

-- ── ORDER 3: COD In-Transit — assigned courier, pending financial settlement
-- Power Bank 280,000 GNF + delivery 25,000 GNF = 305,000 GNF
INSERT INTO public.orders (
  id, user_id, vendor_id, store_id, courier_id,
  customer_name, items_count, total_amount, delivery_fee, vendor_delivery_fee,
  shipping_address, tracking_number, delivery_otp,
  status, financial_status, created_at
) VALUES (
  '44000001-0000-0000-0000-000000000003',
  '11000001-0000-0000-0000-000000000001',
  '11000001-0000-0000-0000-000000000002',
  '22000001-0000-0000-0000-000000000001',
  '11000001-0000-0000-0000-000000000003',
  'Mamadou Diallo', 1, 305000, 25000, 0,
  '{"payment_method":"cash","commune":"Ratoma","quartier":"Taouyah","indications":"En face de la mosquée centrale de Taouyah","phone":"+224 620 11 22 33"}',
  'FTB-2024-003', '3317',
  'in_transit', 'pending',
  NOW() - INTERVAL '3 hours'
) ON CONFLICT (id) DO NOTHING;

-- Order items for ORDER 3
INSERT INTO public.order_items (order_id, product_id, quantity, price_at_purchase, selected_variations)
VALUES (
  '44000001-0000-0000-0000-000000000003',
  '33000001-0000-0000-0000-000000000003', 1, 280000,
  '{"Capacité":"20 000 mAh"}'
) ON CONFLICT DO NOTHING;

-- ══════════════════════════════════════════════════════════════════════════════
-- SECTION 6 — Notifications (sample in-app alerts)
-- ══════════════════════════════════════════════════════════════════════════════
INSERT INTO public.notifications (user_id, type, title, message, is_read, created_at)
VALUES
  -- Buyer: order placed confirmation
  ('11000001-0000-0000-0000-000000000001',
   'order_placed',
   'Commande confirmée !',
   'Votre commande #FTB-2024-001 a bien été reçue. Le vendeur va la confirmer très prochainement.',
   false, NOW() - INTERVAL '2 hours'),

  -- Buyer: delivery arrived
  ('11000001-0000-0000-0000-000000000001',
   'order_delivered',
   'Commande livrée 🎉',
   'Votre commande #FTB-2024-002 a été livrée avec succès. Merci pour votre confiance !',
   true, NOW() - INTERVAL '4 days'),

  -- Vendor: new order received
  ('11000001-0000-0000-0000-000000000002',
   'new_order',
   'Nouvelle commande reçue',
   'Une nouvelle commande de 425 000 GNF attend votre confirmation. Répondez vite !',
   false, NOW() - INTERVAL '2 hours'),

  -- Vendor: payout credited
  ('11000001-0000-0000-0000-000000000002',
   'payout',
   'Paiement reçu 💰',
   '571 429 GNF ont été crédités sur votre boutique suite à la livraison de la commande #FTB-2024-002.',
   true, NOW() - INTERVAL '4 days'),

  -- Courier: new delivery available
  ('11000001-0000-0000-0000-000000000003',
   'new_delivery',
   'Nouvelle livraison disponible',
   'Une livraison COD de 305 000 GNF est en cours vers Taouyah. Commande #FTB-2024-003.',
   false, NOW() - INTERVAL '3 hours')
ON CONFLICT DO NOTHING;

-- ══════════════════════════════════════════════════════════════════════════════
-- SECTION 7 — Platform settings (ensure defaults are present)
-- ══════════════════════════════════════════════════════════════════════════════
INSERT INTO public.platform_settings (id, value, description)
VALUES
  ('commission_rate',    '5',       'Commission plateforme sur chaque vente (%)'),
  ('min_withdrawal',     '50000',   'Montant minimum de retrait portefeuille (GNF)'),
  ('delivery_base_fee',  '15000',   'Frais de livraison de base (GNF)'),
  ('boost_min_budget',   '50000',   'Budget minimum pour une campagne boost (GNF)'),
  ('loyalty_per_order',  '10',      'Points fidélité accordés par commande')
ON CONFLICT (id) DO UPDATE SET value = EXCLUDED.value;

-- ══════════════════════════════════════════════════════════════════════════════
-- SECTION 8 — Verification summary
-- ══════════════════════════════════════════════════════════════════════════════
DO $$
DECLARE
  v_profiles  INT; v_stores    INT; v_products  INT;
  v_orders    INT; v_items     INT; v_wt        INT;
  v_notifs    INT; v_settings  INT;
BEGIN
  -- Cast UUID to text for prefix matching
  SELECT COUNT(*) INTO v_profiles  FROM public.profiles  WHERE id::text LIKE '11000001%';
  SELECT COUNT(*) INTO v_stores    FROM public.stores     WHERE id::text LIKE '22000001%';
  SELECT COUNT(*) INTO v_products  FROM public.products   WHERE id::text LIKE '33000001%';
  SELECT COUNT(*) INTO v_orders    FROM public.orders     WHERE id::text LIKE '44000001%';
  SELECT COUNT(*) INTO v_items     FROM public.order_items
    WHERE order_id IN (
      '44000001-0000-0000-0000-000000000001'::uuid,
      '44000001-0000-0000-0000-000000000002'::uuid,
      '44000001-0000-0000-0000-000000000003'::uuid
    );
  SELECT COUNT(*) INTO v_wt        FROM public.wallet_transactions
    WHERE reference_id::text LIKE '44000001%';
  SELECT COUNT(*) INTO v_notifs    FROM public.notifications
    WHERE user_id::text LIKE '11000001%';
  SELECT COUNT(*) INTO v_settings  FROM public.platform_settings;

  RAISE NOTICE '════════════════════════════════════════';
  RAISE NOTICE 'FATIBARA SEED — Verification Summary';
  RAISE NOTICE '════════════════════════════════════════';
  RAISE NOTICE 'Profiles         : % / 4', v_profiles;
  RAISE NOTICE 'Stores           : % / 1', v_stores;
  RAISE NOTICE 'Products         : % / 6', v_products;
  RAISE NOTICE 'Orders           : % / 3', v_orders;
  RAISE NOTICE 'Order Items      : % / 6', v_items;
  RAISE NOTICE 'Wallet Txns      : % / 3', v_wt;
  RAISE NOTICE 'Notifications    : % / 5', v_notifs;
  RAISE NOTICE 'Platform Settings: %',     v_settings;
  RAISE NOTICE '════════════════════════════════════════';

  IF v_profiles < 4 OR v_stores < 1 OR v_products < 6 OR v_orders < 3 THEN
    RAISE WARNING 'SEED INCOMPLETE — some records missing, check output above.';
  ELSE
    RAISE NOTICE 'SEED COMPLETE ✓ — All required records present.';
  END IF;
END $$;
