-- ==============================================================================
-- FATIBARA 2.0 — BETA LAUNCH SEED
-- File: supabase/seed_beta.sql
-- Purpose: Insert realistic beta stores, products, and a welcome announcement.
--          Run AFTER the main seed.sql (or directly on the production DB via
--          supabase db push + manual SQL execution in the Supabase Dashboard).
--
-- ALL stores use moderation_status = 'approved' and is_verified_store = TRUE
-- ALL products use moderation_status = 'approved' and is_active = TRUE
-- Run as: supabase sql --file supabase/seed_beta.sql
-- Or paste in Supabase Dashboard > SQL Editor
-- ==============================================================================

-- Stable UUIDs for beta stores
-- Store 1 (Electronics):  b1000001-0000-0000-0000-000000000001
-- Store 2 (Fashion):      b1000001-0000-0000-0000-000000000002
-- Store 3 (Alimentation): b1000001-0000-0000-0000-000000000003
-- Store 4 (Beauté):       b1000001-0000-0000-0000-000000000004
-- Store 5 (Maison):       b1000001-0000-0000-0000-000000000005

-- NOTE: These stores use the existing seed vendor user
-- (11000001-0000-0000-0000-000000000002).
-- In production, replace owner_id with real vendor user UUIDs.

DO $$
DECLARE
  -- Production admin UUID (fatibara platform admin account)
  -- Updated 2026-07-29 from placeholder to real production UUID
  v_vendor_id UUID := '35782753-330e-4d2a-9e80-2f96e1b02c06';
BEGIN

-- ══════════════════════════════════════════════════════════════════════════════
-- SECTION 1 — Beta Stores
-- ══════════════════════════════════════════════════════════════════════════════

INSERT INTO public.stores (
  id, owner_id, store_name, description, location_commune, is_open,
  is_verified_store, avatar_url, balance, created_at
) VALUES
  -- 1. Electronics
  (
    'b1000001-0000-0000-0000-000000000001', v_vendor_id,
    'Conakry Tech Store',
    'Votre destination premium pour smartphones, tablettes, et accessoires électroniques. Livraison rapide sur tout Conakry.',
    'Kaloum', TRUE, TRUE,
    'https://placehold.co/200x200/ff6600/white?text=CTS',
    1500000, NOW() - INTERVAL '30 days'
  ),
  -- 2. Fashion
  (
    'b1000001-0000-0000-0000-000000000002', v_vendor_id,
    'Mode & Style Guinée',
    'Les dernières tendances de la mode africaine et internationale. Vêtements, chaussures et accessoires pour homme et femme.',
    'Ratoma', TRUE, TRUE,
    'https://placehold.co/200x200/8b5cf6/white?text=MSG',
    800000, NOW() - INTERVAL '25 days'
  ),
  -- 3. Food & Grocery
  (
    'b1000001-0000-0000-0000-000000000003', v_vendor_id,
    'Épicerie Al Baraka',
    'Produits alimentaires frais et secs. Épices, riz, huile, et produits locaux guinéens livrés chez vous.',
    'Dixinn', TRUE, TRUE,
    'https://placehold.co/200x200/10b981/white?text=AB',
    400000, NOW() - INTERVAL '20 days'
  ),
  -- 4. Beauty & Cosmetics
  (
    'b1000001-0000-0000-0000-000000000004', v_vendor_id,
    'Beauté Africaine',
    'Cosmétiques naturels, soins capillaires et produits de beauté adaptés aux peaux africaines. 100% authentique.',
    'Matam', TRUE, TRUE,
    'https://placehold.co/200x200/ec4899/white?text=BA',
    600000, NOW() - INTERVAL '15 days'
  ),
  -- 5. Home & Living
  (
    'b1000001-0000-0000-0000-000000000005', v_vendor_id,
    'Maison & Confort GN',
    'Mobilier, décoration et équipements de maison. Transformez votre intérieur avec notre collection soigneusement sélectionnée.',
    'Lambanyi', TRUE, TRUE,
    'https://placehold.co/200x200/f59e0b/white?text=MC',
    700000, NOW() - INTERVAL '10 days'
  )
ON CONFLICT (id) DO UPDATE SET
  store_name        = EXCLUDED.store_name,
  description       = EXCLUDED.description,
  is_open           = EXCLUDED.is_open,
  is_verified_store = EXCLUDED.is_verified_store;

RAISE NOTICE 'Beta stores inserted ✓';

-- ══════════════════════════════════════════════════════════════════════════════
-- SECTION 2 — Products (24 total, 4-5 per store)
-- ══════════════════════════════════════════════════════════════════════════════

INSERT INTO public.products (
  id, store_id, title, description, price_gnf, category,
  is_active, stock_quantity, moderation_status, created_at
) VALUES

  -- ── Store 1: Conakry Tech Store ─────────────────────────────────────────
  (
    'c1000001-0000-0000-0000-000000000001',
    'b1000001-0000-0000-0000-000000000001',
    'Samsung Galaxy A55 5G',
    'Smartphone Samsung Galaxy A55 5G - 8Go RAM, 256Go ROM, écran AMOLED 6.6", double SIM. Couleur: Bleu glacier. Garantie 1 an.',
    4500000, 'Téléphones & Tablettes', TRUE, 5, 'approved', NOW() - INTERVAL '28 days'
  ),
  (
    'c1000001-0000-0000-0000-000000000002',
    'b1000001-0000-0000-0000-000000000001',
    'iPhone 14 - 128Go',
    'Apple iPhone 14 128Go, Minuit. Face ID, appareil photo 12 MP, puce A15 Bionic. Boîte originale, accessoires inclus.',
    7800000, 'Téléphones & Tablettes', TRUE, 3, 'approved', NOW() - INTERVAL '27 days'
  ),
  (
    'c1000001-0000-0000-0000-000000000003',
    'b1000001-0000-0000-0000-000000000001',
    'Écouteurs JBL Tune 510BT',
    'Casque Bluetooth JBL Tune 510BT - 40h d''autonomie, Pure Bass Sound, pliable. Compatible Android et iOS.',
    350000, 'Électronique', TRUE, 15, 'approved', NOW() - INTERVAL '26 days'
  ),
  (
    'c1000001-0000-0000-0000-000000000004',
    'b1000001-0000-0000-0000-000000000001',
    'Power Bank Anker 20000mAh',
    'Batterie externe Anker PowerCore 20000mAh, charge rapide 22.5W, 2 ports USB-A + 1 USB-C. Idéal pour voyages.',
    280000, 'Électronique', TRUE, 20, 'approved', NOW() - INTERVAL '25 days'
  ),
  (
    'c1000001-0000-0000-0000-000000000005',
    'b1000001-0000-0000-0000-000000000001',
    'Tablette Lenovo Tab M10 Plus',
    'Tablette Lenovo Tab M10 Plus - écran 10.6" FHD+, 4Go RAM, 128Go, batterie 7700mAh. Parfait pour études et loisirs.',
    2200000, 'Téléphones & Tablettes', TRUE, 7, 'approved', NOW() - INTERVAL '24 days'
  ),

  -- ── Store 2: Mode & Style Guinée ────────────────────────────────────────
  (
    'c1000002-0000-0000-0000-000000000001',
    'b1000001-0000-0000-0000-000000000002',
    'Boubou Grand Damask Homme',
    'Boubou grand Damask brodé pour homme - tissu de qualité supérieure, broderie dorée, taille unique ajustable. Livré avec pantalon assorti.',
    450000, 'Vêtements', TRUE, 10, 'approved', NOW() - INTERVAL '23 days'
  ),
  (
    'c1000002-0000-0000-0000-000000000002',
    'b1000001-0000-0000-0000-000000000002',
    'Robe Wax Africaine Femme',
    'Robe en tissu Wax 100% coton, imprimé bogolan. Tailles disponibles: S, M, L, XL. Lavable en machine.',
    180000, 'Vêtements', TRUE, 25, 'approved', NOW() - INTERVAL '22 days'
  ),
  (
    'c1000002-0000-0000-0000-000000000003',
    'b1000001-0000-0000-0000-000000000002',
    'Sneakers Nike Air Force 1',
    'Nike Air Force 1 Low "White" - pointures 40 à 45 disponibles. Authentique, boîte originale, neuves.',
    650000, 'Chaussures', TRUE, 8, 'approved', NOW() - INTERVAL '21 days'
  ),
  (
    'c1000002-0000-0000-0000-000000000004',
    'b1000001-0000-0000-0000-000000000002',
    'Sac Cabas Cuir Femme',
    'Sac à main femme en cuir synthétique de qualité. Grand compartiment, bandoulière amovible. Couleurs: noir, marron, rouge.',
    120000, 'Accessoires', TRUE, 30, 'approved', NOW() - INTERVAL '20 days'
  ),

  -- ── Store 3: Épicerie Al Baraka ──────────────────────────────────────────
  (
    'c1000003-0000-0000-0000-000000000001',
    'b1000001-0000-0000-0000-000000000003',
    'Riz Premium Brisure 50kg',
    'Riz brisure parfumé de qualité supérieure - sac 50kg. Idéal pour thiéboudienne, riz sauté et plats guinéens.',
    320000, 'Alimentation', TRUE, 50, 'approved', NOW() - INTERVAL '19 days'
  ),
  (
    'c1000003-0000-0000-0000-000000000002',
    'b1000001-0000-0000-0000-000000000003',
    'Huile de Palme Rouge 5L',
    'Huile de palme rouge artisanale, pure et naturelle. Produit local guinéen, idéal pour la cuisine traditionnelle.',
    95000, 'Alimentation', TRUE, 100, 'approved', NOW() - INTERVAL '18 days'
  ),
  (
    'c1000003-0000-0000-0000-000000000003',
    'b1000001-0000-0000-0000-000000000003',
    'Pack Épices Guinéennes (x6)',
    'Assortiment de 6 épices guinéennes: poivre de Guinée, gingembre en poudre, ail séché, oignon séché, piment fumé, cumin. 100g chacun.',
    85000, 'Alimentation', TRUE, 40, 'approved', NOW() - INTERVAL '17 days'
  ),
  (
    'c1000003-0000-0000-0000-000000000004',
    'b1000001-0000-0000-0000-000000000003',
    'Café Guinée Forestière 250g',
    'Café arabica de Guinée Forestière, torréfaction artisanale, moulu frais. Arômes intenses de chocolat et fruits rouges.',
    65000, 'Alimentation', TRUE, 60, 'approved', NOW() - INTERVAL '16 days'
  ),
  (
    'c1000003-0000-0000-0000-000000000005',
    'b1000001-0000-0000-0000-000000000003',
    'Miel Pur Fouta Djallon 500g',
    'Miel pur de Fouta Djallon, récolte artisanale sans additifs. Riche en antioxydants, idéal pour la santé.',
    120000, 'Alimentation', TRUE, 30, 'approved', NOW() - INTERVAL '15 days'
  ),

  -- ── Store 4: Beauté Africaine ────────────────────────────────────────────
  (
    'c1000004-0000-0000-0000-000000000001',
    'b1000001-0000-0000-0000-000000000004',
    'Beurre de Karité Pur 250ml',
    'Beurre de karité 100% naturel, non raffiné. Hydrate intensément peau et cheveux. Sans paraben, vegan. Origine Guinée.',
    55000, 'Beauté & Soins', TRUE, 80, 'approved', NOW() - INTERVAL '14 days'
  ),
  (
    'c1000004-0000-0000-0000-000000000002',
    'b1000001-0000-0000-0000-000000000004',
    'Savon au Beurre de Cacao',
    'Savon artisanal au beurre de cacao et huile de coco. Nettoie en douceur, unifie le teint. Lot de 3 savons 100g.',
    45000, 'Beauté & Soins', TRUE, 60, 'approved', NOW() - INTERVAL '13 days'
  ),
  (
    'c1000004-0000-0000-0000-000000000003',
    'b1000001-0000-0000-0000-000000000004',
    'Huile de Coco Vierge 200ml',
    'Huile de coco vierge extra pressée à froid. Multi-usage: soin capillaire, hydratant corps, démaquillant naturel.',
    75000, 'Beauté & Soins', TRUE, 45, 'approved', NOW() - INTERVAL '12 days'
  ),
  (
    'c1000004-0000-0000-0000-000000000004',
    'b1000001-0000-0000-0000-000000000004',
    'Kit Soin Cheveux Naturels',
    'Kit complet pour cheveux crépus et bouclés: shampoing sans sulfate, après-shampoing démêlant, masque deep conditioning, huile de jojoba. 4 produits.',
    150000, 'Beauté & Soins', TRUE, 20, 'approved', NOW() - INTERVAL '11 days'
  ),

  -- ── Store 5: Maison & Confort GN ─────────────────────────────────────────
  (
    'c1000005-0000-0000-0000-000000000001',
    'b1000001-0000-0000-0000-000000000005',
    'Ventilateur Tower 60cm',
    'Ventilateur colonne oscillant 60cm, 3 vitesses, télécommande incluse, minuterie 7h. Silencieux et puissant. Garantie 1 an.',
    380000, 'Maison & Jardin', TRUE, 12, 'approved', NOW() - INTERVAL '10 days'
  ),
  (
    'c1000005-0000-0000-0000-000000000002',
    'b1000001-0000-0000-0000-000000000005',
    'Groupe Électrogène 3.5KVA',
    'Générateur essence 3500W monophasé - démarrage électrique, AVR automatique, 4 prises 220V + 1 USB. Autonomie 8h à charge moyenne.',
    2800000, 'Maison & Jardin', TRUE, 4, 'approved', NOW() - INTERVAL '9 days'
  ),
  (
    'c1000005-0000-0000-0000-000000000003',
    'b1000001-0000-0000-0000-000000000005',
    'Matelas Mousse Haute Densité 160x200',
    'Matelas 160x200cm en mousse haute densité 35kg/m³. Épaisseur 20cm, housse déhoussable anti-acariens. Livraison à domicile.',
    850000, 'Maison & Jardin', TRUE, 6, 'approved', NOW() - INTERVAL '8 days'
  ),
  (
    'c1000005-0000-0000-0000-000000000004',
    'b1000001-0000-0000-0000-000000000005',
    'Set Couverts Inox 24 pièces',
    'Service de table en acier inoxydable 18/10 - 24 pièces: 6 fourchettes, 6 couteaux, 6 cuillères à soupe, 6 petites cuillères. Coffret cadeau.',
    95000, 'Maison & Jardin', TRUE, 25, 'approved', NOW() - INTERVAL '7 days'
  ),
  (
    'c1000005-0000-0000-0000-000000000005',
    'b1000001-0000-0000-0000-000000000005',
    'Chaise Pliante Premium',
    'Chaise pliante en acier renforcé, assise et dossier rembourrés. Charge max 150kg. Idéal cérémonies, bureaux, maison. Lot de 4.',
    320000, 'Maison & Jardin', TRUE, 18, 'approved', NOW() - INTERVAL '6 days'
  )

ON CONFLICT (id) DO UPDATE SET
  title             = EXCLUDED.title,
  description       = EXCLUDED.description,
  price_gnf         = EXCLUDED.price_gnf,
  is_active         = EXCLUDED.is_active,
  moderation_status = EXCLUDED.moderation_status;

RAISE NOTICE 'Beta products inserted ✓ (24 products across 5 stores)';

-- ══════════════════════════════════════════════════════════════════════════════
-- SECTION 3 — Welcome Announcement (displayed in AnnouncementBanner)
-- ══════════════════════════════════════════════════════════════════════════════

INSERT INTO public.announcements (title, content, target_type, created_at)
VALUES (
  '🎉 Bienvenue sur FATIBARA Beta !',
  'Fatibara est maintenant en accès bêta ! Profitez de la livraison gratuite sur vos 3 premières commandes. Partagez votre expérience avec nous sur WhatsApp : +224 660 34 58 58. Merci de votre confiance !',
  'all',
  NOW()
)
ON CONFLICT DO NOTHING;

RAISE NOTICE 'Welcome announcement inserted ✓';

END $$;

-- ══════════════════════════════════════════════════════════════════════════════
-- Verification
-- ══════════════════════════════════════════════════════════════════════════════
DO $$
DECLARE
  v_stores   INT;
  v_products INT;
BEGIN
  SELECT COUNT(*) INTO v_stores   FROM public.stores   WHERE id::TEXT LIKE 'b1000001%';
  SELECT COUNT(*) INTO v_products FROM public.products WHERE id::TEXT LIKE 'c1000%';

  RAISE NOTICE '══════════════════════════════════';
  RAISE NOTICE 'BETA SEED — Verification Summary';
  RAISE NOTICE '══════════════════════════════════';
  RAISE NOTICE 'Beta Stores  : % / 5', v_stores;
  RAISE NOTICE 'Beta Products: % / 24', v_products;

  IF v_stores < 5 OR v_products < 20 THEN
    RAISE WARNING 'BETA SEED INCOMPLETE — check output above.';
  ELSE
    RAISE NOTICE 'BETA SEED COMPLETE ✓';
  END IF;
END $$;
