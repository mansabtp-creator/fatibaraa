-- =============================================================================
-- Make the financial-function repair safe to execute more than once.
-- =============================================================================

DO $$
DECLARE
  v_definition TEXT;
  v_repaired_definition TEXT;
  v_function REGPROCEDURE;
BEGIN
  FOREACH v_function IN ARRAY ARRAY[
    'public.secure_process_order_financials(uuid)'::regprocedure,
    'public.admin_force_settle_cod_order(uuid)'::regprocedure
  ]
  LOOP
    SELECT pg_get_functiondef(v_function) INTO v_definition;

    -- Repair only the invalid predicate. If it is already cast to text, leave
    -- the function untouched so a retry cannot fail merely because it is fixed.
    v_repaired_definition := regexp_replace(
      v_definition,
      'reference_id\\s*=\\s*p_order_id\\s+AND\\s+type\\s*=\\s*''sale''',
      'reference_id = p_order_id::text AND type = ''sale''',
      'g'
    );

    IF v_repaired_definition <> v_definition THEN
      EXECUTE v_repaired_definition;
    END IF;
  END LOOP;
END;
$$;

NOTIFY pgrst, 'reload schema';
