-- =============================================================================
-- Migration: Multi-Order Courier Batch Acceptance
-- Created At: 2026-08-13
--
-- Changes:
--   1. Add GIN index on orders.shipping_address for fast commune-based
--      filtering in the job-board pool view.
--
--   2. Define accept_order_batch(p_order_ids UUID[], p_courier_id UUID):
--        • Validates caller identity and courier eligibility.
--        • Enforces a max of 5 concurrent in_transit orders per courier.
--        • Atomically assigns each order using FOR UPDATE SKIP LOCKED to
--          prevent double-assignment race conditions.
--        • Returns JSONB { success, accepted: uuid[], skipped: uuid[], error? }.
--
--   3. Refresh PostgREST schema cache.
--
-- NOTE: The root-level courier_batch_acceptance.sql file was the original
-- prototype. This migration is the canonical, versioned equivalent.
-- =============================================================================

-- ── 1. Ensure shipping_address JSONB column exists ───────────────────────────
ALTER TABLE public.orders
  ADD COLUMN IF NOT EXISTS shipping_address JSONB DEFAULT NULL;

-- ── 2. GIN index for fast commune-based pool filtering ───────────────────────
-- Enables queries like: shipping_address->>'commune' = 'Kaloum'
CREATE INDEX IF NOT EXISTS idx_orders_shipping_commune
  ON public.orders USING GIN (shipping_address jsonb_path_ops);

-- ── 3. accept_order_batch RPC ────────────────────────────────────────────────
DROP FUNCTION IF EXISTS public.accept_order_batch(UUID[], UUID);

CREATE OR REPLACE FUNCTION public.accept_order_batch(
    p_order_ids  UUID[],
    p_courier_id UUID
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_courier         RECORD;
    v_active_count    INT;
    v_max_concurrent  CONSTANT INT := 5;
    v_accepted        UUID[] := '{}';
    v_skipped         UUID[] := '{}';
    v_order           RECORD;
    v_order_id        UUID;
BEGIN
    -- ── Guard 1: Caller must be the courier (service-role bypasses via DEFINER) ──
    IF auth.uid() IS NOT NULL AND auth.uid() != p_courier_id THEN
        RAISE EXCEPTION 'Unauthorized: courier_id must match authenticated user';
    END IF;

    -- ── Guard 2: Courier profile must exist and be eligible ──────────────────
    SELECT id, profile_type, courier_status, is_courier_online, license_plate_number
    INTO v_courier
    FROM public.profiles
    WHERE id = p_courier_id;

    IF v_courier IS NULL THEN
        RAISE EXCEPTION 'Courier profile not found';
    END IF;

    IF v_courier.profile_type != 'courier' THEN
        RAISE EXCEPTION 'Profile is not a courier';
    END IF;

    -- ── Guard 3: Capacity check ───────────────────────────────────────────────
    -- Count how many orders this courier currently has in active states
    SELECT COUNT(*) INTO v_active_count
    FROM public.orders
    WHERE courier_id = p_courier_id
      AND status NOT IN ('delivered', 'cancelled');

    IF v_active_count + array_length(p_order_ids, 1) > v_max_concurrent THEN
        RETURN jsonb_build_object(
            'success',  false,
            'accepted', '[]'::jsonb,
            'skipped',  '[]'::jsonb,
            'error',    format(
                'Capacity exceeded: courier has %s active orders. Max concurrent = %s. ' ||
                'Cannot accept %s more.',
                v_active_count,
                v_max_concurrent,
                array_length(p_order_ids, 1)
            )
        );
    END IF;

    -- ── Per-order atomic assignment ───────────────────────────────────────────
    FOREACH v_order_id IN ARRAY p_order_ids
    LOOP
        -- Lock the row; SKIP LOCKED means a concurrent courier racing for the
        -- same order will find zero rows and skip rather than deadlock.
        SELECT id, status, courier_id
        INTO v_order
        FROM public.orders
        WHERE id         = v_order_id
          AND status     = 'ready_for_pickup'
          AND courier_id IS NULL
        FOR UPDATE SKIP LOCKED;

        IF v_order IS NULL THEN
            -- Order was already taken or is not in the right state
            v_skipped := array_append(v_skipped, v_order_id);
            CONTINUE;
        END IF;

        -- Assign the order: courier claims it, status moves to in_transit
        UPDATE public.orders
        SET courier_id = p_courier_id,
            status     = 'in_transit',
            updated_at = NOW()
        WHERE id = v_order_id;

        v_accepted := array_append(v_accepted, v_order_id);
    END LOOP;

    -- ── Return result ─────────────────────────────────────────────────────────
    RETURN jsonb_build_object(
        'success',  array_length(v_accepted, 1) > 0,
        'accepted', to_jsonb(v_accepted),
        'skipped',  to_jsonb(v_skipped),
        'error',    NULL
    );

EXCEPTION WHEN OTHERS THEN
    RETURN jsonb_build_object(
        'success',  false,
        'accepted', '[]'::jsonb,
        'skipped',  '[]'::jsonb,
        'error',    SQLERRM
    );
END;
$$;

-- ── 4. Grant execution rights to authenticated users ─────────────────────────
GRANT EXECUTE ON FUNCTION public.accept_order_batch(UUID[], UUID) TO authenticated;

-- ── 5. Comment ───────────────────────────────────────────────────────────────
COMMENT ON FUNCTION public.accept_order_batch(UUID[], UUID) IS
  'Atomically accepts a list of pool orders for a courier (max 5 concurrent).
   Uses FOR UPDATE SKIP LOCKED to prevent double-assignment race conditions.
   Returns JSONB { success, accepted: uuid[], skipped: uuid[], error? }.';

-- ── 6. Refresh PostgREST schema cache ────────────────────────────────────────
NOTIFY pgrst, 'reload schema';
