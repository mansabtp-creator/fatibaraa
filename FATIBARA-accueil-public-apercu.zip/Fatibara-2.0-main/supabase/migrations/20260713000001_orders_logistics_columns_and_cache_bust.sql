-- ==============================================================================
-- Migration: Orders Logistics Columns + PostgREST Cache Bust
-- Created At: 2026-07-13
--
-- Purpose:
--   The frontend queries `orders` requesting:
--     status, delivery_otp, tracking_number, courier_id
--
--   `supabase_schema.sql` (baseline) defines the orders table WITHOUT these
--   three logistics columns. They were appended via ad-hoc ALTER TABLE statements
--   in several patch files (migration_logistics.sql, apply_this_sql_now.sql, etc.).
--
--   If those statements were never applied to the live DB, PostgREST returns:
--     HTTP 400 (PGRST200) — "column X of relation orders does not exist"
--
--   This migration is idempotent (IF NOT EXISTS) and should be safe to run
--   even if the columns already exist.
--
-- After applying this migration, the PostgREST schema cache MUST be refreshed
-- via NOTIFY pgrst, 'reload schema' to eliminate the HTTP 400 / 406 errors.
-- ==============================================================================

-- 1. Ensure all columns requested by the frontend query exist on the orders table
ALTER TABLE public.orders
  ADD COLUMN IF NOT EXISTS delivery_otp    TEXT,
  ADD COLUMN IF NOT EXISTS tracking_number TEXT,
  ADD COLUMN IF NOT EXISTS courier_id      UUID REFERENCES public.profiles(id) ON DELETE SET NULL;

-- 2. Add an index on courier_id for efficient courier-scoped queries
--    (CourierDashboardPage queries .eq('courier_id', user?.id) on every mount)
CREATE INDEX IF NOT EXISTS idx_orders_courier_id
  ON public.orders (courier_id)
  WHERE courier_id IS NOT NULL;

-- 3. Add an index on tracking_number for PaymentResultPage / CartCheckoutPage
--    polling loops
CREATE INDEX IF NOT EXISTS idx_orders_tracking_number
  ON public.orders (tracking_number)
  WHERE tracking_number IS NOT NULL;

-- 4. Hard-reload the PostgREST schema cache.
--    This eliminates BOTH the HTTP 406 (stale cache after previous migrations)
--    AND the HTTP 400 (new columns not yet visible to PostgREST).
--    Run this last, after all structural changes above are committed.
NOTIFY pgrst, 'reload schema';
