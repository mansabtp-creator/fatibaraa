-- ============================================================
-- Migration: 20260823000001_credit_user_wallet_rpc.sql
-- Creates wallet_transactions table (if not exists) and the
-- atomic credit_user_wallet RPC used by the LengoPay webhook.
-- ============================================================

-- ─── Table ────────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS public.wallet_transactions (
  id            UUID          PRIMARY KEY DEFAULT gen_random_uuid(),
  profile_id    UUID,
  store_id      UUID,
  type          TEXT          NOT NULL DEFAULT 'deposit',
  amount        NUMERIC       NOT NULL DEFAULT 0,
  status        TEXT          NOT NULL DEFAULT 'pending',
  description   TEXT,
  method        TEXT,
  reference_id  TEXT          UNIQUE,
  pay_id        TEXT,
  created_at    TIMESTAMPTZ   NOT NULL DEFAULT now(),
  updated_at    TIMESTAMPTZ   NOT NULL DEFAULT now()
);

-- ─── RLS ──────────────────────────────────────────────────────────────────────
ALTER TABLE public.wallet_transactions ENABLE ROW LEVEL SECURITY;

DO $$ BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies
    WHERE tablename = 'wallet_transactions'
      AND policyname = 'Users read own transactions'
  ) THEN
    EXECUTE 'CREATE POLICY "Users read own transactions"
      ON public.wallet_transactions FOR SELECT
      USING (auth.uid() = profile_id)';
  END IF;
END $$;

-- ─── Indexes ──────────────────────────────────────────────────────────────────
CREATE INDEX IF NOT EXISTS idx_wt_reference_id ON public.wallet_transactions (reference_id);
CREATE INDEX IF NOT EXISTS idx_wt_profile_id   ON public.wallet_transactions (profile_id);
CREATE INDEX IF NOT EXISTS idx_wt_status       ON public.wallet_transactions (status);

-- ─── Atomic credit RPC ────────────────────────────────────────────────────────
-- Uses a CAS (Compare-And-Swap) on status = 'pending' to guarantee
-- exactly-once wallet crediting even under concurrent webhook retries.
CREATE OR REPLACE FUNCTION public.credit_user_wallet(
  p_user_id  UUID,
  p_amount   NUMERIC,
  p_tx_id    UUID,
  p_pay_id   TEXT DEFAULT NULL
)
RETURNS VOID
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  -- Only updates if still pending — prevents double-credit on retries
  UPDATE public.wallet_transactions
     SET status     = 'completed',
         pay_id     = COALESCE(p_pay_id, pay_id),
         updated_at = now()
   WHERE id = p_tx_id AND status = 'pending';

  -- Only credits the balance if the row was actually updated
  IF FOUND THEN
    UPDATE public.profiles
       SET wallet_balance = wallet_balance + p_amount,
           updated_at     = now()
     WHERE id = p_user_id;
  END IF;
END;
$$;

-- ─── Permissions ──────────────────────────────────────────────────────────────
REVOKE ALL    ON FUNCTION public.credit_user_wallet(UUID, NUMERIC, UUID, TEXT) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.credit_user_wallet(UUID, NUMERIC, UUID, TEXT) TO service_role;
