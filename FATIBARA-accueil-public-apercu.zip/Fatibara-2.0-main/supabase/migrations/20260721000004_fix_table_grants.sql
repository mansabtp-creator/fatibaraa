-- ==============================================================================
-- Migration: Fix missing role grants for anon and authenticated
-- File:      20260721000004_fix_table_grants.sql
-- Created:   2026-07-21
--
-- ROOT CAUSE:
--   Supabase Cloud automatically GRANTs SELECT/INSERT/UPDATE/DELETE on every new
--   public table to the `anon` and `authenticated` roles (controlled by the
--   dashboard "Expose via API" toggle). Supabase Local does NOT do this
--   automatically when `[db] auto_api_expose` is not set to true in config.toml.
--
--   Without these GRANTs, the RLS policies are never evaluated — Postgres rejects
--   queries with a 42501 permission error before RLS is even checked.
--
-- FIX:
--   Grant the minimal permissions each role needs. RLS policies are already in
--   place and act as the real security gate; these grants simply allow Postgres
--   to reach the RLS evaluation step.
--
--   Write access to financial tables (wallet_transactions, platform_logs,
--   platform_settings) is intentionally NOT granted — these are only writable
--   via SECURITY DEFINER RPCs.
-- ==============================================================================

-- ── Public read-only tables (marketplace discovery) ───────────────────────────
GRANT SELECT ON public.products          TO anon, authenticated;
GRANT SELECT ON public.stores            TO anon, authenticated;
GRANT SELECT ON public.boost_campaigns   TO anon, authenticated;

-- ── Profiles (own row visible via RLS) ───────────────────────────────────────
GRANT SELECT, UPDATE                     ON public.profiles TO authenticated;
GRANT SELECT                             ON public.profiles TO anon;

-- ── Orders (buyer/vendor/courier access via RLS) ──────────────────────────────
GRANT SELECT, INSERT, UPDATE             ON public.orders          TO authenticated;
GRANT SELECT, INSERT                     ON public.order_items     TO authenticated;
GRANT SELECT, UPDATE                     ON public.deliveries      TO authenticated;

-- ── Notifications (own rows via RLS) ─────────────────────────────────────────
GRANT SELECT, UPDATE                     ON public.notifications   TO authenticated;

-- ── Cart (own rows) ───────────────────────────────────────────────────────────
GRANT SELECT, INSERT, UPDATE, DELETE     ON public.cart_items      TO authenticated;

-- ── Financial tables — READ ONLY for authenticated (writes via RPC only) ──────
GRANT SELECT                             ON public.wallet_transactions TO authenticated;
GRANT SELECT                             ON public.platform_logs       TO authenticated;
GRANT SELECT                             ON public.platform_settings   TO anon, authenticated;

-- ── Vendor-managed tables ─────────────────────────────────────────────────────
GRANT SELECT, INSERT, UPDATE, DELETE     ON public.products        TO authenticated;

-- ── Sequence grants (needed for INSERT on tables with serial/identity columns) ─
-- Grant usage on all sequences in the public schema
GRANT USAGE ON ALL SEQUENCES IN SCHEMA public TO authenticated;
GRANT USAGE ON ALL SEQUENCES IN SCHEMA public TO anon;

-- Notify PostgREST to reload its schema cache
NOTIFY pgrst, 'reload schema';
