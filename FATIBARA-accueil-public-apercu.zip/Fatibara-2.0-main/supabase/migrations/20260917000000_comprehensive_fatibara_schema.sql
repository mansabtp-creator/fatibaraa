-- =============================================================================
-- FATIBARA 2.0 — COMPREHENSIVE DATABASE MIGRATION
-- Generated: 2026-09-17
-- Safe to run multiple times (idempotent). Run in the Supabase SQL editor.
-- =============================================================================

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- ─── 1. PROFILES ─────────────────────────────────────────────────────────────
ALTER TABLE public.profiles
  ADD COLUMN IF NOT EXISTS wallet_balance           BIGINT       NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS is_admin                 BOOLEAN      NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS is_pro_member            BOOLEAN      NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS is_vendor                BOOLEAN      NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS is_courier               BOOLEAN      NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS is_courier_online        BOOLEAN      NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS courier_zone             TEXT,
  ADD COLUMN IF NOT EXISTS courier_status           TEXT         DEFAULT 'inactive'
                                                    CHECK (courier_status IN ('active','inactive','on_delivery')),
  ADD COLUMN IF NOT EXISTS courier_rating           NUMERIC(3,2) DEFAULT 5.00,
  ADD COLUMN IF NOT EXISTS courier_rejection_reason TEXT,
  ADD COLUMN IF NOT EXISTS vehicle_type             TEXT         DEFAULT 'motorcycle',
  ADD COLUMN IF NOT EXISTS license_plate_number     TEXT,
  ADD COLUMN IF NOT EXISTS phone_number             TEXT,
  ADD COLUMN IF NOT EXISTS avatar_url               TEXT,
  ADD COLUMN IF NOT EXISTS full_name                TEXT,
  ADD COLUMN IF NOT EXISTS loyalty_points           INTEGER      NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS account_status           TEXT         NOT NULL DEFAULT 'active'
                                                    CHECK (account_status IN ('active','suspended','banned'));

-- ─── 2. STORES ───────────────────────────────────────────────────────────────
ALTER TABLE public.stores
  ADD COLUMN IF NOT EXISTS balance          BIGINT       NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS avatar_url       TEXT,
  ADD COLUMN IF NOT EXISTS banner_url       TEXT,
  ADD COLUMN IF NOT EXISTS description      TEXT,
  ADD COLUMN IF NOT EXISTS category         TEXT,
  ADD COLUMN IF NOT EXISTS location_region  TEXT,
  ADD COLUMN IF NOT EXISTS location_commune TEXT,
  ADD COLUMN IF NOT EXISTS phone            TEXT,
  ADD COLUMN IF NOT EXISTS whatsapp         TEXT,
  ADD COLUMN IF NOT EXISTS is_verified      BOOLEAN      NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS is_active        BOOLEAN      NOT NULL DEFAULT true,
  ADD COLUMN IF NOT EXISTS plan             TEXT         DEFAULT 'free'
                                            CHECK (plan IN ('free','starter','pro','enterprise')),
  ADD COLUMN IF NOT EXISTS rating           NUMERIC(3,2) DEFAULT 0,
  ADD COLUMN IF NOT EXISTS review_count     INTEGER      NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS fulfillment_type TEXT         DEFAULT 'platform_courier'
                                            CHECK (fulfillment_type IN ('platform_courier','vendor_self_delivery','pickup_only'));

-- ─── 3. PRODUCTS ─────────────────────────────────────────────────────────────
ALTER TABLE public.products
  ADD COLUMN IF NOT EXISTS status         TEXT    NOT NULL DEFAULT 'published'
                                          CHECK (status IN ('published','draft','scheduled','archived')),
  ADD COLUMN IF NOT EXISTS scheduled_at   TIMESTAMPTZ,
  ADD COLUMN IF NOT EXISTS image_urls     TEXT[]  DEFAULT '{}',
  ADD COLUMN IF NOT EXISTS video_url      TEXT,
  ADD COLUMN IF NOT EXISTS stock_quantity INTEGER NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS sku            TEXT,
  ADD COLUMN IF NOT EXISTS weight_kg      NUMERIC(8,3),
  ADD COLUMN IF NOT EXISTS is_featured    BOOLEAN NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS view_count     INTEGER NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS sold_count     INTEGER NOT NULL DEFAULT 0;

-- ─── 4. ORDERS ───────────────────────────────────────────────────────────────
ALTER TABLE public.orders
  ADD COLUMN IF NOT EXISTS user_id                    UUID REFERENCES auth.users(id),
  ADD COLUMN IF NOT EXISTS vendor_id                  UUID REFERENCES auth.users(id),
  ADD COLUMN IF NOT EXISTS tracking_number            TEXT UNIQUE,
  ADD COLUMN IF NOT EXISTS customer_name              TEXT,
  ADD COLUMN IF NOT EXISTS courier_id                 UUID REFERENCES auth.users(id),
  ADD COLUMN IF NOT EXISTS delivery_otp               TEXT,
  ADD COLUMN IF NOT EXISTS delivery_fee               BIGINT NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS delivery_attempts          INTEGER NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS delivery_proof_url         TEXT,
  ADD COLUMN IF NOT EXISTS last_location_lat          DOUBLE PRECISION,
  ADD COLUMN IF NOT EXISTS last_location_lng          DOUBLE PRECISION,
  ADD COLUMN IF NOT EXISTS estimated_arrival          TIMESTAMPTZ,
  ADD COLUMN IF NOT EXISTS fulfillment_type           TEXT DEFAULT 'platform_courier'
                                                      CHECK (fulfillment_type IN ('platform_courier','vendor_self_delivery','pickup_only')),
  ADD COLUMN IF NOT EXISTS self_delivery_driver_name  TEXT,
  ADD COLUMN IF NOT EXISTS self_delivery_driver_phone TEXT,
  ADD COLUMN IF NOT EXISTS self_delivery_driver_plate TEXT,
  ADD COLUMN IF NOT EXISTS payment_method             TEXT,
  ADD COLUMN IF NOT EXISTS payment_status             TEXT DEFAULT 'pending',
  ADD COLUMN IF NOT EXISTS shipping_address           JSONB DEFAULT '{}',
  ADD COLUMN IF NOT EXISTS cancel_reason              TEXT,
  ADD COLUMN IF NOT EXISTS cancelled_at               TIMESTAMPTZ,
  ADD COLUMN IF NOT EXISTS updated_at                 TIMESTAMPTZ DEFAULT now();

CREATE OR REPLACE FUNCTION public.set_updated_at()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END;
$$;
DROP TRIGGER IF EXISTS orders_set_updated_at ON public.orders;
CREATE TRIGGER orders_set_updated_at
  BEFORE UPDATE ON public.orders
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

-- ─── 5. ORDER_ITEMS ──────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS public.order_items (
  id         UUID    PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id   UUID    NOT NULL REFERENCES public.orders(id) ON DELETE CASCADE,
  product_id UUID    REFERENCES public.products(id) ON DELETE SET NULL,
  store_id   UUID    REFERENCES public.stores(id)   ON DELETE SET NULL,
  quantity   INTEGER NOT NULL DEFAULT 1,
  unit_price BIGINT  NOT NULL,
  title      TEXT,
  image_url  TEXT,
  created_at TIMESTAMPTZ DEFAULT now()
);
-- Safety: add columns that may be missing when table already existed
ALTER TABLE public.order_items
  ADD COLUMN IF NOT EXISTS store_id   UUID    REFERENCES public.stores(id)   ON DELETE SET NULL,
  ADD COLUMN IF NOT EXISTS product_id UUID    REFERENCES public.products(id) ON DELETE SET NULL,
  ADD COLUMN IF NOT EXISTS title      TEXT,
  ADD COLUMN IF NOT EXISTS image_url  TEXT;
CREATE INDEX IF NOT EXISTS idx_order_items_order   ON public.order_items(order_id);
CREATE INDEX IF NOT EXISTS idx_order_items_product ON public.order_items(product_id);
ALTER TABLE public.order_items ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "order_items_buyer_select"  ON public.order_items;
DROP POLICY IF EXISTS "order_items_vendor_select" ON public.order_items;
DROP POLICY IF EXISTS "order_items_insert"        ON public.order_items;
CREATE POLICY "order_items_buyer_select" ON public.order_items FOR SELECT
  USING (EXISTS (SELECT 1 FROM public.orders o WHERE o.id=order_id AND o.user_id=auth.uid()));
CREATE POLICY "order_items_vendor_select" ON public.order_items FOR SELECT
  USING (EXISTS (SELECT 1 FROM public.stores s WHERE s.id=store_id AND s.owner_id=auth.uid()));
CREATE POLICY "order_items_insert" ON public.order_items FOR INSERT
  WITH CHECK (EXISTS (SELECT 1 FROM public.orders o WHERE o.id=order_id AND o.user_id=auth.uid()));

-- ─── 6. DELIVERIES ───────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS public.deliveries (
  id            UUID    PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id      UUID    NOT NULL UNIQUE REFERENCES public.orders(id) ON DELETE CASCADE,
  courier_id    UUID    REFERENCES auth.users(id),
  status        TEXT    DEFAULT 'pending',
  arriving_soon BOOLEAN NOT NULL DEFAULT false,
  picked_up_at  TIMESTAMPTZ,
  delivered_at  TIMESTAMPTZ,
  notes         TEXT,
  created_at    TIMESTAMPTZ DEFAULT now(),
  updated_at    TIMESTAMPTZ DEFAULT now()
);
-- Safety: ensure all columns exist on pre-existing table
ALTER TABLE public.deliveries
  ADD COLUMN IF NOT EXISTS arriving_soon BOOLEAN NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS picked_up_at  TIMESTAMPTZ,
  ADD COLUMN IF NOT EXISTS delivered_at  TIMESTAMPTZ,
  ADD COLUMN IF NOT EXISTS notes         TEXT,
  ADD COLUMN IF NOT EXISTS updated_at    TIMESTAMPTZ DEFAULT now();

CREATE INDEX IF NOT EXISTS idx_deliveries_order   ON public.deliveries(order_id);
CREATE INDEX IF NOT EXISTS idx_deliveries_courier ON public.deliveries(courier_id);
ALTER TABLE public.deliveries ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "deliveries_courier_all"    ON public.deliveries;
DROP POLICY IF EXISTS "deliveries_buyer_select"   ON public.deliveries;
DROP POLICY IF EXISTS "deliveries_vendor_select"  ON public.deliveries;
DROP POLICY IF EXISTS "deliveries_courier_upsert" ON public.deliveries;
CREATE POLICY "deliveries_courier_all"   ON public.deliveries FOR ALL
  USING (courier_id = auth.uid()) WITH CHECK (courier_id = auth.uid());
CREATE POLICY "deliveries_buyer_select"  ON public.deliveries FOR SELECT
  USING (EXISTS (SELECT 1 FROM public.orders o WHERE o.id=order_id AND o.user_id=auth.uid()));
CREATE POLICY "deliveries_vendor_select" ON public.deliveries FOR SELECT
  USING (EXISTS (
    SELECT 1 FROM public.orders o JOIN public.stores s ON s.id=o.store_id
    WHERE o.id=order_id AND s.owner_id=auth.uid()
  ));
CREATE POLICY "deliveries_courier_upsert" ON public.deliveries FOR INSERT
  WITH CHECK (courier_id = auth.uid());

-- ─── 7. COURIER_LOCATIONS ────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS public.courier_locations (
  id          UUID    PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id    TEXT,
  courier_id  UUID    REFERENCES auth.users(id),
  lat         DOUBLE PRECISION NOT NULL,
  lng         DOUBLE PRECISION NOT NULL,
  recorded_at TIMESTAMPTZ DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_courier_loc_order   ON public.courier_locations(order_id);
CREATE INDEX IF NOT EXISTS idx_courier_loc_courier ON public.courier_locations(courier_id);
ALTER TABLE public.courier_locations ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "courier_loc_insert" ON public.courier_locations;
DROP POLICY IF EXISTS "courier_loc_select" ON public.courier_locations;
CREATE POLICY "courier_loc_insert" ON public.courier_locations FOR INSERT
  WITH CHECK (courier_id = auth.uid());
CREATE POLICY "courier_loc_select" ON public.courier_locations FOR SELECT USING (true);

-- ─── 8. WALLET_TRANSACTIONS ──────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS public.wallet_transactions (
  id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  profile_id   UUID REFERENCES auth.users(id),
  store_id     UUID REFERENCES public.stores(id),
  amount       BIGINT NOT NULL,
  type         TEXT NOT NULL DEFAULT 'adjustment'
               CHECK (type IN ('sale','withdrawal','refund','adjustment','fee','topup','payout')),
  status       TEXT NOT NULL DEFAULT 'completed'
               CHECK (status IN ('pending','completed','failed')),
  reference_id UUID,
  description  TEXT,
  created_at   TIMESTAMPTZ DEFAULT now()
);
ALTER TABLE public.wallet_transactions
  ADD COLUMN IF NOT EXISTS store_id     UUID REFERENCES public.stores(id),
  ADD COLUMN IF NOT EXISTS profile_id   UUID REFERENCES auth.users(id),
  ADD COLUMN IF NOT EXISTS reference_id UUID,
  ADD COLUMN IF NOT EXISTS description  TEXT,
  ADD COLUMN IF NOT EXISTS status       TEXT DEFAULT 'completed';

CREATE INDEX IF NOT EXISTS idx_wtx_store   ON public.wallet_transactions(store_id);
CREATE INDEX IF NOT EXISTS idx_wtx_profile ON public.wallet_transactions(profile_id);
CREATE INDEX IF NOT EXISTS idx_wtx_created ON public.wallet_transactions(created_at DESC);
ALTER TABLE public.wallet_transactions ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "wtx_owner_select" ON public.wallet_transactions;
DROP POLICY IF EXISTS "wtx_store_select" ON public.wallet_transactions;
CREATE POLICY "wtx_owner_select" ON public.wallet_transactions FOR SELECT
  USING (profile_id = auth.uid());
CREATE POLICY "wtx_store_select" ON public.wallet_transactions FOR SELECT
  USING (EXISTS (SELECT 1 FROM public.stores s WHERE s.id=store_id AND s.owner_id=auth.uid()));

-- ─── 9. WITHDRAWALS ──────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS public.withdrawals (
  id               UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  profile_id       UUID REFERENCES auth.users(id),
  store_id         UUID REFERENCES public.stores(id),
  amount           BIGINT NOT NULL,
  method           TEXT NOT NULL,
  phone_number     TEXT,
  status           TEXT NOT NULL DEFAULT 'pending'
                   CHECK (status IN ('pending','approved','rejected','processing')),
  rejection_reason TEXT,
  processed_at     TIMESTAMPTZ,
  created_at       TIMESTAMPTZ DEFAULT now()
);
ALTER TABLE public.withdrawals
  ADD COLUMN IF NOT EXISTS store_id         UUID REFERENCES public.stores(id),
  ADD COLUMN IF NOT EXISTS rejection_reason TEXT,
  ADD COLUMN IF NOT EXISTS processed_at     TIMESTAMPTZ;

CREATE INDEX IF NOT EXISTS idx_withdrawals_profile ON public.withdrawals(profile_id);
CREATE INDEX IF NOT EXISTS idx_withdrawals_store   ON public.withdrawals(store_id);
ALTER TABLE public.withdrawals ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "withdrawals_owner_select" ON public.withdrawals;
DROP POLICY IF EXISTS "withdrawals_store_select" ON public.withdrawals;
DROP POLICY IF EXISTS "withdrawals_insert"       ON public.withdrawals;
DROP POLICY IF EXISTS "withdrawals_admin_all"    ON public.withdrawals;
CREATE POLICY "withdrawals_owner_select" ON public.withdrawals FOR SELECT
  USING (profile_id = auth.uid());
CREATE POLICY "withdrawals_store_select" ON public.withdrawals FOR SELECT
  USING (EXISTS (SELECT 1 FROM public.stores s WHERE s.id=store_id AND s.owner_id=auth.uid()));
CREATE POLICY "withdrawals_insert" ON public.withdrawals FOR INSERT
  WITH CHECK (profile_id = auth.uid() OR
    EXISTS (SELECT 1 FROM public.stores s WHERE s.id=store_id AND s.owner_id=auth.uid()));
CREATE POLICY "withdrawals_admin_all" ON public.withdrawals FOR ALL
  USING (EXISTS (SELECT 1 FROM public.profiles WHERE id=auth.uid() AND is_admin=true));

-- ─── 10. PLATFORM_SETTINGS ───────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS public.platform_settings (
  id          TEXT PRIMARY KEY,
  value       TEXT,
  description TEXT,
  updated_at  TIMESTAMPTZ DEFAULT now()
);
ALTER TABLE public.platform_settings ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "platform_settings_public_select" ON public.platform_settings;
DROP POLICY IF EXISTS "platform_settings_admin_all"     ON public.platform_settings;
CREATE POLICY "platform_settings_public_select" ON public.platform_settings FOR SELECT USING (true);
CREATE POLICY "platform_settings_admin_all"     ON public.platform_settings FOR ALL
  USING (EXISTS (SELECT 1 FROM public.profiles WHERE id=auth.uid() AND is_admin=true));
INSERT INTO public.platform_settings (id, value, description) VALUES
  ('support_whatsapp',        '224666923393',       'WhatsApp number (no + prefix)'),
  ('support_phone',           '+224 666 92 33 93',  'Display phone'),
  ('delivery_fee_default',    '15000',              'Default delivery fee GNF'),
  ('platform_commission_pct', '10',                 'Commission %')
ON CONFLICT (id) DO NOTHING;

-- ─── 11. STORE_STAFF ─────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS public.store_staff (
  id         UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  store_id   UUID NOT NULL REFERENCES public.stores(id)  ON DELETE CASCADE,
  user_id    UUID NOT NULL REFERENCES auth.users(id)     ON DELETE CASCADE,
  role       TEXT NOT NULL DEFAULT 'staff' CHECK (role IN ('owner','manager','staff')),
  invited_by UUID REFERENCES auth.users(id),
  created_at TIMESTAMPTZ DEFAULT now(),
  UNIQUE (store_id, user_id)
);
ALTER TABLE public.store_staff
  ADD COLUMN IF NOT EXISTS role       TEXT DEFAULT 'staff',
  ADD COLUMN IF NOT EXISTS invited_by UUID REFERENCES auth.users(id);
CREATE INDEX IF NOT EXISTS idx_store_staff_store ON public.store_staff(store_id);
CREATE INDEX IF NOT EXISTS idx_store_staff_user  ON public.store_staff(user_id);
ALTER TABLE public.store_staff ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "store_staff_owner_all"     ON public.store_staff;
DROP POLICY IF EXISTS "store_staff_member_select" ON public.store_staff;
CREATE POLICY "store_staff_owner_all" ON public.store_staff FOR ALL
  USING (EXISTS (SELECT 1 FROM public.stores s WHERE s.id=store_id AND s.owner_id=auth.uid()));
CREATE POLICY "store_staff_member_select" ON public.store_staff FOR SELECT
  USING (user_id = auth.uid());

-- ─── 12. REVIEWS ─────────────────────────────────────────────────────────────
ALTER TABLE public.reviews
  ADD COLUMN IF NOT EXISTS store_id              UUID REFERENCES public.stores(id)   ON DELETE CASCADE,
  ADD COLUMN IF NOT EXISTS user_id               UUID REFERENCES auth.users(id)      ON DELETE CASCADE,
  ADD COLUMN IF NOT EXISTS product_id            UUID REFERENCES public.products(id) ON DELETE CASCADE,
  ADD COLUMN IF NOT EXISTS rating                INTEGER NOT NULL DEFAULT 5 CHECK (rating BETWEEN 1 AND 5),
  ADD COLUMN IF NOT EXISTS body                  TEXT,
  ADD COLUMN IF NOT EXISTS is_verified_purchase  BOOLEAN DEFAULT false;

-- ─── 13. CHAT_CHANNELS ───────────────────────────────────────────────────────
ALTER TABLE public.chat_channels
  ADD COLUMN IF NOT EXISTS product_id UUID REFERENCES public.products(id) ON DELETE SET NULL;

-- ─── 14. PRODUCT_VIEWS ───────────────────────────────────────────────────────
ALTER TABLE public.product_views
  ADD COLUMN IF NOT EXISTS store_id UUID REFERENCES public.stores(id) ON DELETE CASCADE;

-- ─── 15. VENDOR_INVITATIONS ──────────────────────────────────────────────────
-- NOTE: vendor_invitations is fully managed by dedicated migrations
-- (20260829000002, 20260829000007, 20260830000001, 20260912000005).
-- This section intentionally left empty to avoid conflicts.

-- ─── 16. INDEXES ─────────────────────────────────────────────────────────────
CREATE INDEX IF NOT EXISTS idx_orders_user_id    ON public.orders(user_id);
CREATE INDEX IF NOT EXISTS idx_orders_vendor_id  ON public.orders(vendor_id);
CREATE INDEX IF NOT EXISTS idx_orders_courier_id ON public.orders(courier_id);
CREATE INDEX IF NOT EXISTS idx_orders_status     ON public.orders(status);
CREATE INDEX IF NOT EXISTS idx_orders_tracking   ON public.orders(tracking_number);
CREATE INDEX IF NOT EXISTS idx_orders_created    ON public.orders(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_products_store    ON public.products(store_id);
CREATE INDEX IF NOT EXISTS idx_products_status   ON public.products(status);
CREATE INDEX IF NOT EXISTS idx_profiles_courier  ON public.profiles(is_courier, is_courier_online);

-- ─── 17. HELPER: is_admin() ──────────────────────────────────────────────────
CREATE OR REPLACE FUNCTION public.is_admin()
RETURNS BOOLEAN LANGUAGE sql SECURITY DEFINER AS $$
  SELECT EXISTS (SELECT 1 FROM public.profiles WHERE id=auth.uid() AND is_admin=true);
$$;

-- ─── 18. ORDERS RLS ──────────────────────────────────────────────────────────
DROP POLICY IF EXISTS "orders_buyer_select"   ON public.orders;
DROP POLICY IF EXISTS "orders_vendor_select"  ON public.orders;
DROP POLICY IF EXISTS "orders_courier_select" ON public.orders;
DROP POLICY IF EXISTS "orders_admin_all"      ON public.orders;
DROP POLICY IF EXISTS "orders_buyer_insert"   ON public.orders;
CREATE POLICY "orders_buyer_select" ON public.orders FOR SELECT
  USING (user_id = auth.uid());
CREATE POLICY "orders_vendor_select" ON public.orders FOR SELECT
  USING (EXISTS (SELECT 1 FROM public.stores s WHERE s.id=store_id AND s.owner_id=auth.uid())
      OR vendor_id = auth.uid());
CREATE POLICY "orders_courier_select" ON public.orders FOR SELECT
  USING (courier_id = auth.uid());
CREATE POLICY "orders_admin_all" ON public.orders FOR ALL
  USING (public.is_admin());
CREATE POLICY "orders_buyer_insert" ON public.orders FOR INSERT
  WITH CHECK (user_id = auth.uid());

-- ─── 19. ADMIN STORE POLICIES ────────────────────────────────────────────────
DROP POLICY IF EXISTS "Admins can update any store"   ON public.stores;
DROP POLICY IF EXISTS "Admins can delete any store"   ON public.stores;
DROP POLICY IF EXISTS "Admins can delete any product" ON public.products;
CREATE POLICY "Admins can update any store"   ON public.stores   FOR UPDATE USING (public.is_admin());
CREATE POLICY "Admins can delete any store"   ON public.stores   FOR DELETE USING (public.is_admin());
CREATE POLICY "Admins can delete any product" ON public.products FOR DELETE USING (public.is_admin());

-- =============================================================================
-- MIGRATION COMPLETE
-- =============================================================================
