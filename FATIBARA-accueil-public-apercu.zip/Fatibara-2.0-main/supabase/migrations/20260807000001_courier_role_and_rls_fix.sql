-- =============================================================================
-- Migration: Courier Role Authorization & Pool Order Self-Assignment RLS Fix
-- Created At: 2026-08-07
--
-- Problems fixed:
--   1. Couriers can now claim unclaimed pool orders (courier_id IS NULL,
--      status = 'ready_for_pickup') via the orders UPDATE policy.
--      Previously the USING clause checked `auth.uid() = courier_id` which
--      was always FALSE on unclaimed orders (courier_id = NULL).
--
--   2. profile_type index added for fast courier role lookups.
--
--   3. Ensures courier profiles can always SELECT and UPDATE their own row
--      (belt-and-suspenders — foundation schema already covers this via
--      profiles_select_public / profiles_update_own, but we make it explicit
--      in case later migrations added restrictive policies).
-- =============================================================================

-- ── 1. Rebuild orders UPDATE policy to allow courier pool self-assignment ─────
--
--    Why this is needed:
--      The existing "Fatibara flat orders update policy" checks
--        USING (auth.uid() = vendor_id OR ... OR auth.uid() = courier_id)
--      When a courier tries to claim an unclaimed order:
--        • courier_id IS NULL  → auth.uid() = courier_id is FALSE
--        • The courier is not the vendor
--      → The update is rejected even though it should be allowed.
--
--    Fix: add an explicit self-assignment clause:
--        OR (courier_id IS NULL AND status = 'ready_for_pickup')
--    This allows any authenticated user to claim an open pool order.
--    The application layer (acceptOrder) also guards with .is('courier_id', null)
--    as an optimistic-lock to prevent double-acceptance.

DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM pg_policies
    WHERE schemaname = 'public'
      AND tablename  = 'orders'
      AND policyname = 'Fatibara flat orders update policy'
  ) THEN
    DROP POLICY "Fatibara flat orders update policy" ON public.orders;
  END IF;
END
$$;

CREATE POLICY "Fatibara flat orders update policy"
ON public.orders
FOR UPDATE
TO authenticated
USING (
  -- Vendor directly owns this order
  auth.uid() = vendor_id
  -- Vendor owns the store that fulfills the order (store_id fallback)
  OR EXISTS (
    SELECT 1 FROM public.stores
    WHERE public.stores.id = orders.store_id
      AND public.stores.owner_id = auth.uid()
  )
  -- Assigned courier can update delivery fields (in_transit, delivered, etc.)
  OR auth.uid() = courier_id
  -- Any authenticated courier may CLAIM an unclaimed pool order
  -- (self-assignment: sets courier_id from NULL to auth.uid())
  OR (courier_id IS NULL AND status = 'ready_for_pickup')
)
WITH CHECK (
  -- Same set of conditions on the post-update row
  auth.uid() = vendor_id
  OR EXISTS (
    SELECT 1 FROM public.stores
    WHERE public.stores.id = orders.store_id
      AND public.stores.owner_id = auth.uid()
  )
  OR auth.uid() = courier_id
  -- After self-assignment, courier_id = auth.uid() so this covers the post-update row
  OR auth.uid() = courier_id
);

-- ── 2. Ensure courier profile fields are always readable ─────────────────────
--    The foundation schema already has:
--      profiles_select_public: FOR SELECT USING (true)  — covers all users
--    No additional SELECT policy is needed for couriers.

-- ── 3. Ensure the orders foundation SELECT policy covers couriers ─────────────
--    The foundation schema has:
--      orders_foundation_select: auth.uid() = user_id OR vendor_id OR courier_id
--    But it only covers orders WHERE courier_id IS NOT NULL.
--    We also need couriers to SELECT pool orders (courier_id IS NULL) to build
--    the available orders feed.

DROP POLICY IF EXISTS "orders_courier_pool_select" ON public.orders;
CREATE POLICY "orders_courier_pool_select"
ON public.orders
FOR SELECT
TO authenticated
USING (
  -- Already assigned to this courier
  auth.uid() = courier_id
  -- Unclaimed orders in the pool — all authenticated users can see them
  -- (application layer filters by role; this is the minimal RLS needed)
  OR (courier_id IS NULL AND status = 'ready_for_pickup')
);

-- ── 5. Reconcile vehicle_type CHECK constraint ───────────────────────────────
--    The live DB has: CHECK (vehicle_type IN ('moto', 'voiture', 'velo') OR vehicle_type IS NULL)
--    set by courier_fleet_migration.sql (applied ad-hoc, not via the migration system).
--    Migration 20260805000000 added the column with ADD COLUMN IF NOT EXISTS — since it
--    already existed, the inline CHECK in that migration was silently skipped.
--    We expand the constraint here to accept BOTH naming conventions so that
--    existing rows and new English-named values both pass validation.

ALTER TABLE public.profiles DROP CONSTRAINT IF EXISTS profiles_vehicle_type_check;
ALTER TABLE public.profiles ADD CONSTRAINT profiles_vehicle_type_check
  CHECK (
    vehicle_type IS NULL
    OR vehicle_type IN (
      -- French (legacy — courier_fleet_migration.sql)
      'moto', 'voiture', 'velo',
      -- English (20260805000000_courier_security_and_self_delivery.sql)
      'motorcycle', 'car', 'bicycle', 'foot'
    )
  );

-- ── 6. Indexes for new lookup patterns ───────────────────────────────────────
CREATE INDEX IF NOT EXISTS idx_profiles_profile_type
  ON public.profiles (profile_type)
  WHERE profile_type IS NOT NULL;

-- ── 5. Refresh PostgREST schema cache ────────────────────────────────────────
NOTIFY pgrst, 'reload schema';
