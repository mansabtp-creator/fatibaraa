-- ==============================================================================
-- MIGRATION: 20260829000005_fix_all_production_check_constraints.sql
--
-- Problem: The production (remote) DB was provisioned with older/incomplete
-- CHECK constraints that differ from the local shadow DB.  This causes 400
-- errors for any INSERT that uses a valid-in-code value that the old
-- constraint doesn't know about.  Rather than fixing one constraint per
-- deployment cycle, this migration audits and repairs ALL affected constraints
-- in one shot.
--
-- Tables fixed:
--   1. orders.financial_status   — already fixed in 20260829000004, kept here
--                                   for safety (DROP IF EXISTS is idempotent)
--   2. deliveries.status         — production is missing: 'cancelled',
--                                   'ready_for_pickup', 'out_for_delivery'
--   3. wallet_transactions.type  — verify authoritative set (safe re-add)
--   4. wallet_transactions.status — verify authoritative set (safe re-add)
-- ==============================================================================

-- ── 1. orders.financial_status ────────────────────────────────────────────────
ALTER TABLE public.orders
  DROP CONSTRAINT IF EXISTS orders_financial_status_check;

ALTER TABLE public.orders
  ADD CONSTRAINT orders_financial_status_check
  CHECK (financial_status IN (
    'pending',    -- Created, payment not yet confirmed
    'paid',       -- Payment received (wallet / mobile money)
    'processed',  -- Vendor + courier payouts distributed
    'failed',     -- Payment failed
    'refunded'    -- Buyer refunded
  ));

-- ── 2. deliveries.status ──────────────────────────────────────────────────────
-- Original constraint was: pending, assigned, picked_up, in_transit, delivered, failed
-- Missing in prod + used in codebase: cancelled, ready_for_pickup, out_for_delivery
ALTER TABLE public.deliveries
  DROP CONSTRAINT IF EXISTS deliveries_status_check;

ALTER TABLE public.deliveries
  ADD CONSTRAINT deliveries_status_check
  CHECK (status IN (
    'pending',           -- Delivery created, no courier yet
    'assigned',          -- Courier assigned, not yet started
    'ready_for_pickup',  -- Vendor has packaged the order
    'picked_up',         -- Courier collected the parcel
    'in_transit',        -- En route to customer
    'out_for_delivery',  -- Last-mile (within neighbourhood)
    'delivered',         -- Successfully handed to customer
    'failed',            -- Delivery attempt failed
    'cancelled'          -- Delivery cancelled (order cancelled)
  ));

-- ── 3. wallet_transactions.type ───────────────────────────────────────────────
ALTER TABLE public.wallet_transactions
  DROP CONSTRAINT IF EXISTS wallet_transactions_type_check;

ALTER TABLE public.wallet_transactions
  ADD CONSTRAINT wallet_transactions_type_check
  CHECK (type IN (
    'purchase',          -- Buyer wallet debit (checkout)
    'sale',              -- Vendor credit from sold order
    'refund',            -- Buyer refund credit
    'fee',               -- Platform fee debit / COD settlement debit
    'delivery_fee',      -- Courier delivery credit
    'withdrawal',        -- Cash-out payout
    'withdrawal_approved', -- Admin-approved withdrawal debit
    'deposit',           -- Wallet top-up (LengoPay / admin)
    'topup',             -- Alias used by some older webhook paths
    'boost',             -- Paid product boost
    'credit',            -- Manual admin credit
    'commission'         -- Platform commission record
  ));

-- ── 4. wallet_transactions.status ────────────────────────────────────────────
ALTER TABLE public.wallet_transactions
  DROP CONSTRAINT IF EXISTS wallet_transactions_status_check;

ALTER TABLE public.wallet_transactions
  ADD CONSTRAINT wallet_transactions_status_check
  CHECK (status IN (
    'pending',
    'completed',
    'failed',
    'reversed'
  ));

-- ── Reload PostgREST schema cache ─────────────────────────────────────────────
NOTIFY pgrst, 'reload schema';
