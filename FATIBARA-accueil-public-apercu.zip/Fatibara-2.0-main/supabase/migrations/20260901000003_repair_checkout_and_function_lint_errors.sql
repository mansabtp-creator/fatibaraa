-- =============================================================================
-- Repair production checkout/schema drift discovered by `supabase db lint`.
-- This is intentionally a forward-only migration: 20260901000001 and
-- 20260901000002 have already been applied to production.
-- =============================================================================

-- process_cart_checkout and secure_process_order_financials both rely on this
-- canonical payment-method field. Keep historical JSON-only orders readable by
-- backfilling from shipping_address.
ALTER TABLE public.orders
  ADD COLUMN IF NOT EXISTS payment_method TEXT;

UPDATE public.orders
SET payment_method = shipping_address->>'payment_method'
WHERE payment_method IS NULL
  AND shipping_address ? 'payment_method';

-- These functions existed before the current schema and are still exposed in
-- production. Their intended storage column is absent, so add it rather than
-- leave either RPC to fail at execution time.
ALTER TABLE public.profiles
  ADD COLUMN IF NOT EXISTS preferred_language TEXT;

-- reference_id is TEXT. Recreate the two affected functions from their current
-- definitions after replacing the invalid text = uuid predicate. Doing this
-- dynamically preserves their existing signatures, grants, and all unrelated
-- business logic while making the repair reproducible from a clean database.
DO $$
DECLARE
  v_definition TEXT;
  v_repaired_definition TEXT;
BEGIN
  SELECT pg_get_functiondef('public.secure_process_order_financials(uuid)'::regprocedure)
  INTO v_definition;

  v_repaired_definition := replace(
    v_definition,
    'reference_id = p_order_id AND type = ''sale''',
    'reference_id = p_order_id::text AND type = ''sale'''
  );

  IF v_repaired_definition = v_definition THEN
    RAISE EXCEPTION 'Expected reference_id predicate was not found in secure_process_order_financials';
  END IF;

  EXECUTE v_repaired_definition;

  SELECT pg_get_functiondef('public.admin_force_settle_cod_order(uuid)'::regprocedure)
  INTO v_definition;

  v_repaired_definition := replace(
    v_definition,
    'reference_id = p_order_id AND type = ''sale''',
    'reference_id = p_order_id::text AND type = ''sale'''
  );

  IF v_repaired_definition = v_definition THEN
    RAISE EXCEPTION 'Expected reference_id predicate was not found in admin_force_settle_cod_order';
  END IF;

  EXECUTE v_repaired_definition;
END;
$$;

-- similarity() returns double precision while the public function contract is
-- real. Explicitly cast it so product search cannot fail at runtime.
CREATE OR REPLACE FUNCTION public.search_products(search_query TEXT)
RETURNS TABLE (
  id UUID,
  title TEXT,
  price_gnf NUMERIC,
  wholesale_price_gnf NUMERIC,
  image_urls TEXT[],
  relevance REAL,
  category TEXT
)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  is_pro BOOLEAN := FALSE;
BEGIN
  IF auth.uid() IS NOT NULL THEN
    SELECT is_pro_member INTO is_pro
    FROM public.profiles
    WHERE profiles.id = auth.uid();
  END IF;

  RETURN QUERY
  SELECT
    p.id,
    p.title,
    p.price_gnf,
    CASE WHEN is_pro THEN p.wholesale_price_gnf ELSE NULL END,
    p.image_urls,
    (similarity(p.title, search_query) * 0.7
      + similarity(p.description, search_query) * 0.3)::REAL,
    p.category
  FROM public.products p
  WHERE p.title % search_query
     OR p.description % search_query
     OR p.title ILIKE '%' || search_query || '%'
     OR p.title ILIKE search_query || '%'
  ORDER BY relevance DESC, p.created_at DESC
  LIMIT 8;
END;
$$;

GRANT EXECUTE ON FUNCTION public.search_products(TEXT) TO anon, authenticated;

NOTIFY pgrst, 'reload schema';
