-- ================================================================
-- DEFINITIVE FIX for 409 Conflict on POST /rest/v1/notifications
-- ================================================================
-- Root cause: notifications.user_id REFERENCES public.profiles(id)
-- Vendor user IDs exist in auth.users but may not have a profiles
-- row yet, causing a FK constraint violation → HTTP 409 Conflict.
-- Fix: re-point the FK to auth.users(id) which always exists for
-- any authenticated user.
-- ================================================================

-- 0. Ensure the notifications table exists (it was missing from migrations)
CREATE TABLE IF NOT EXISTS public.notifications (
    id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id     UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    type        TEXT NOT NULL,
    title       TEXT NOT NULL,
    message     TEXT NOT NULL,
    is_read     BOOLEAN DEFAULT false,
    created_at  TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE public.notifications ENABLE ROW LEVEL SECURITY;

DO $$ BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies
    WHERE schemaname = 'public' AND tablename = 'notifications'
      AND policyname = 'Users can view their own notifications'
  ) THEN
    CREATE POLICY "Users can view their own notifications"
      ON public.notifications FOR SELECT USING (auth.uid() = user_id);
  END IF;
END $$;

-- 1. Drop the old FK constraint (no-op if table was just created above,
--    but needed for databases that had the old public.profiles FK)
ALTER TABLE public.notifications
  DROP CONSTRAINT IF EXISTS notifications_user_id_fkey;

-- Re-add FK pointing to auth.users instead of public.profiles
ALTER TABLE public.notifications
  ADD CONSTRAINT notifications_user_id_fkey
  FOREIGN KEY (user_id)
  REFERENCES auth.users(id)
  ON DELETE CASCADE;
