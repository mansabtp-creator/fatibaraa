-- =============================================================================
-- Migration: Missing tables and columns for Fatibara 2.0 frontend
-- Created: 2026-07-30
-- Adds:
--   1. stores.store_status      (ProductPage, StoreProfilePage, PayoutSettings)
--   2. reviews                  (VendorReviews, ProductReviews, ReviewModal)
--   3. promotions               (promotionService, AdminDashboardPage)
--   4. promotion_products       (promotionService)
-- =============================================================================

-- ── 1. stores.store_status ────────────────────────────────────────────────────
ALTER TABLE public.stores
  ADD COLUMN IF NOT EXISTS store_status TEXT NOT NULL DEFAULT 'active'
    CHECK (store_status IN ('active', 'suspended', 'holiday', 'closed'));

-- ── 2. reviews ────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS public.reviews (
  id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  product_id    UUID REFERENCES public.products(id) ON DELETE CASCADE,
  store_id      UUID REFERENCES public.stores(id) ON DELETE CASCADE,
  user_id       UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  user_name     TEXT,
  avatar_url    TEXT,
  rating        SMALLINT NOT NULL CHECK (rating BETWEEN 1 AND 5),
  comment       TEXT,
  location      TEXT,
  shop_response TEXT,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_reviews_product_id ON public.reviews(product_id);
CREATE INDEX IF NOT EXISTS idx_reviews_store_id   ON public.reviews(store_id);
CREATE INDEX IF NOT EXISTS idx_reviews_user_id    ON public.reviews(user_id);

ALTER TABLE public.reviews ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "reviews_public_read"          ON public.reviews;
CREATE POLICY "reviews_public_read"
  ON public.reviews FOR SELECT USING (true);

DROP POLICY IF EXISTS "reviews_authenticated_insert" ON public.reviews;
CREATE POLICY "reviews_authenticated_insert"
  ON public.reviews FOR INSERT TO authenticated
  WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "reviews_vendor_respond"       ON public.reviews;
CREATE POLICY "reviews_vendor_respond"
  ON public.reviews FOR UPDATE TO authenticated
  USING (store_id IN (SELECT id FROM public.stores WHERE owner_id = auth.uid()));

GRANT SELECT ON public.reviews TO anon;
GRANT SELECT, INSERT, UPDATE ON public.reviews TO authenticated;
GRANT ALL ON public.reviews TO service_role;

-- ── 3. promotions ─────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS public.promotions (
  id             UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  title          TEXT NOT NULL,
  promo_type     TEXT NOT NULL DEFAULT 'global_discount'
                   CHECK (promo_type IN ('flash_deal', 'bogo', 'coupon', 'global_discount')),
  discount_type  TEXT NOT NULL DEFAULT 'percentage'
                   CHECK (discount_type IN ('percentage', 'fixed')),
  discount_value NUMERIC(10, 2) NOT NULL CHECK (discount_value > 0),
  code           TEXT UNIQUE,
  store_id       UUID REFERENCES public.stores(id) ON DELETE CASCADE,
  status         TEXT NOT NULL DEFAULT 'inactive'
                   CHECK (status IN ('active', 'inactive', 'scheduled', 'expired')),
  start_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  end_at         TIMESTAMPTZ NOT NULL,
  created_by     UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at     TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_promotions_status   ON public.promotions(status);
CREATE INDEX IF NOT EXISTS idx_promotions_store_id ON public.promotions(store_id);

ALTER TABLE public.promotions ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "promotions_public_read"  ON public.promotions;
CREATE POLICY "promotions_public_read"
  ON public.promotions FOR SELECT USING (true);

DROP POLICY IF EXISTS "promotions_admin_write"  ON public.promotions;
CREATE POLICY "promotions_admin_write"
  ON public.promotions FOR ALL TO authenticated
  USING (EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND is_admin = true));

GRANT SELECT ON public.promotions TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.promotions TO authenticated;
GRANT ALL ON public.promotions TO service_role;

-- ── 4. promotion_products ─────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS public.promotion_products (
  promotion_id UUID NOT NULL REFERENCES public.promotions(id) ON DELETE CASCADE,
  product_id   UUID NOT NULL REFERENCES public.products(id) ON DELETE CASCADE,
  PRIMARY KEY (promotion_id, product_id)
);

ALTER TABLE public.promotion_products ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "promo_products_public_read"  ON public.promotion_products;
CREATE POLICY "promo_products_public_read"
  ON public.promotion_products FOR SELECT USING (true);

DROP POLICY IF EXISTS "promo_products_admin_write"  ON public.promotion_products;
CREATE POLICY "promo_products_admin_write"
  ON public.promotion_products FOR ALL TO authenticated
  USING (EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND is_admin = true));

GRANT SELECT ON public.promotion_products TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.promotion_products TO authenticated;
GRANT ALL ON public.promotion_products TO service_role;

-- Reload PostgREST schema cache
NOTIFY pgrst, 'reload schema';
