-- ==============================================================================
-- MIGRATION: 20260828000003_courier_audit_fixes.sql
-- Fatibara 2.0 — Courier Dashboard Audit Remediation
-- Date: 2026-08-28
--
-- FIXES:
--
--   [C-1+C-2+C-3] CRITICAL — finalizeDelivery in CourierDashboardPage.tsx
--         performs a non-atomic 2-step settlement: direct UPDATE orders SET
--         status='delivered' followed by a separate RPC call. If the RPC fails
--         the order is permanently marked delivered but no wallet credits happen.
--         Additionally, the OTP is compared client-side (security leak), and
--         complete_vendor_order() rejects courier callers (vendor_id != auth.uid()).
--
--         Fix: Create complete_courier_delivery(target_order_id, provided_otp)
--         — a new SECURITY DEFINER RPC callable by the assigned courier that:
--           1. Verifies the caller IS the assigned courier.
--           2. Validates the OTP server-side (eliminates client-side exposure).
--           3. Atomically sets status = 'delivered' and financial_status = 'processed'.
--           4. Credits 80% of delivery_fee → courier_profiles.balance AND
--              profiles.wallet_balance (both, for full sync).
--           5. Appends wallet_transactions row with type = 'delivery_fee'.
--           6. Triggers secure_process_order_financials for vendor settlement.
--           7. Idempotency guard prevents double-crediting.
--
--   [C-4] HIGH — accept_order_batch does not check courier_profiles.status
--         for 'suspended'. A suspended courier can still claim batch orders
--         via the RPC even though the UI hides the button.
--         Fix: Add courier_profiles status check to accept_order_batch.
--
-- ==============================================================================

-- ==============================================================================
-- FIX C-1 + C-2 + C-3: complete_courier_delivery RPC
-- ==============================================================================
DROP FUNCTION IF EXISTS public.complete_courier_delivery(UUID, TEXT) CASCADE;

CREATE OR REPLACE FUNCTION public.complete_courier_delivery(
    p_order_id   UUID,
    p_otp        TEXT DEFAULT NULL   -- NULL allowed when order has no OTP
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
    v_order               public.orders%ROWTYPE;
    v_courier_profile     RECORD;
    v_commission_str      TEXT;
    v_commission_rate     NUMERIC;
    v_delivery_fee        NUMERIC;
    v_courier_payout      NUMERIC;
    v_store_id            UUID;
    v_items_real_value    NUMERIC := 0;
    v_vendor_payout       NUMERIC;
    v_platform_commission NUMERIC;
    v_payment_method      TEXT;
    v_is_cash             BOOLEAN;
BEGIN
    -- ── 1. Lock order row to prevent race conditions ────────────────────────
    SELECT * INTO v_order
    FROM public.orders
    WHERE id = p_order_id
    FOR UPDATE;

    IF NOT FOUND THEN
        RETURN jsonb_build_object('success', false, 'error', 'Order not found');
    END IF;

    -- ── 2. Authorization: caller must be the assigned courier ───────────────
    IF v_order.courier_id IS NULL THEN
        RETURN jsonb_build_object('success', false, 'error', 'No courier assigned to this order');
    END IF;

    IF v_order.courier_id != auth.uid() THEN
        RETURN jsonb_build_object('success', false, 'error', 'Unauthorized: you are not the assigned courier');
    END IF;

    -- ── 3. State guard: only valid terminal states ──────────────────────────
    IF v_order.status = 'delivered' OR v_order.financial_status = 'processed' THEN
        RETURN jsonb_build_object('success', false, 'error', 'Order already completed');
    END IF;

    IF v_order.status NOT IN (
        'in_transit', 'out_for_delivery', 'arriving_soon',
        'ready_for_pickup', 'picked_up'
    ) THEN
        RETURN jsonb_build_object(
            'success', false,
            'error', 'Order status "' || v_order.status || '" cannot be completed'
        );
    END IF;

    -- ── 4. OTP verification (server-side — OTP never leaves the DB) ─────────
    IF v_order.delivery_otp IS NOT NULL AND TRIM(v_order.delivery_otp) != '' THEN
        IF p_otp IS NULL OR TRIM(p_otp) != TRIM(v_order.delivery_otp) THEN
            RETURN jsonb_build_object(
                'success', false,
                'error', 'Code OTP incorrect. Veuillez réessayer.'
            );
        END IF;
    END IF;

    -- ── 5. Resolve courier profile (for active_capacity reset) ──────────────
    SELECT * INTO v_courier_profile
    FROM public.courier_profiles
    WHERE user_id = auth.uid();

    -- ── 6. Financial math ───────────────────────────────────────────────────
    v_delivery_fee   := COALESCE(v_order.delivery_fee, v_order.vendor_delivery_fee, 0);
    v_courier_payout := ROUND(v_delivery_fee * 0.8);  -- courier keeps 80%

    v_payment_method := COALESCE(
        v_order.shipping_address->>'payment_method',
        CASE WHEN v_order.financial_status = 'paid' THEN 'wallet' ELSE 'cash' END
    );
    v_is_cash := (v_payment_method = 'cash');

    -- For COD: courier collected cash → deduct order total from digital credit
    -- (courier owes the platform the collected cash amount)
    IF v_is_cash THEN
        v_courier_payout := v_courier_payout - COALESCE(v_order.total_amount, 0);
    END IF;

    -- ── 7. Credit courier only if payout is positive ────────────────────────
    IF v_courier_payout > 0 THEN
        -- Credit profiles.wallet_balance
        UPDATE public.profiles
        SET wallet_balance = COALESCE(wallet_balance, 0) + v_courier_payout
        WHERE id = auth.uid();

        -- Credit courier_profiles.balance (kept in sync)
        IF v_courier_profile IS NOT NULL THEN
            UPDATE public.courier_profiles
            SET balance = COALESCE(balance, 0) + v_courier_payout
            WHERE user_id = auth.uid();
        END IF;

        -- Immutable ledger entry
        INSERT INTO public.wallet_transactions
            (profile_id, amount, type, reference_id, description, status)
        VALUES (
            auth.uid(),
            v_courier_payout,
            'delivery_fee',
            p_order_id,
            'Course livrée #' || LEFT(p_order_id::text, 8),
            'completed'
        );
    END IF;

    -- ── 8. Release courier active capacity ──────────────────────────────────
    IF v_courier_profile IS NOT NULL AND
       COALESCE(v_courier_profile.active_capacity, 0) > 0 THEN
        UPDATE public.courier_profiles
        SET active_capacity = GREATEST(0, active_capacity - 1)
        WHERE user_id = auth.uid();
    END IF;

    -- ── 9. Mark order as delivered + financially processed ──────────────────
    UPDATE public.orders
    SET status           = 'delivered',
        financial_status = 'processed',
        completed_at     = NOW(),
        updated_at       = NOW()
    WHERE id = p_order_id;

    -- ── 10. Trigger vendor-side settlement (commission + store credit) ───────
    -- Resolve store_id for vendor payout
    SELECT COALESCE(
        (SELECT p.store_id
         FROM public.order_items oi
         JOIN public.products p ON oi.product_id = p.id
         WHERE oi.order_id = p_order_id LIMIT 1),
        (SELECT id FROM public.stores WHERE owner_id = v_order.vendor_id LIMIT 1)
    ) INTO v_store_id;

    -- Commission rate from platform_settings
    SELECT value INTO v_commission_str
    FROM public.platform_settings WHERE id = 'commission_rate';
    v_commission_rate := COALESCE(NULLIF(v_commission_str, '')::NUMERIC, 5) / 100.0;

    SELECT COALESCE(SUM(price_at_purchase * quantity), 0)
    INTO v_items_real_value
    FROM public.order_items WHERE order_id = p_order_id;

    IF v_items_real_value = 0 THEN
        v_items_real_value := COALESCE(v_order.total_amount, 0) - COALESCE(v_order.delivery_fee, 0);
    END IF;

    v_vendor_payout := ROUND(
        (v_items_real_value / (1 + v_commission_rate)) * (1 - v_commission_rate)
        - COALESCE(v_order.vendor_delivery_fee, 0)
    );
    v_platform_commission := ROUND(
        (v_items_real_value / (1 + v_commission_rate)) * v_commission_rate
    );

    -- Credit vendor store balance
    IF v_vendor_payout > 0 AND v_store_id IS NOT NULL THEN
        UPDATE public.stores
        SET balance = balance + v_vendor_payout
        WHERE id = v_store_id;

        INSERT INTO public.wallet_transactions
            (store_id, profile_id, amount, type, reference_id, description)
        VALUES (
            v_store_id, v_order.vendor_id, v_vendor_payout,
            'sale', p_order_id,
            'Vente livrée #' || LEFT(p_order_id::text, 8)
        );
    END IF;

    -- Platform commission log
    IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = 'platform_logs') THEN
        INSERT INTO public.platform_logs (type, amount, reference_id, metadata)
        VALUES (
            'commission', v_platform_commission, p_order_id,
            jsonb_build_object(
                'order_total', v_order.total_amount,
                'vendor_id',   v_order.vendor_id,
                'courier_id',  auth.uid(),
                'payment',     v_payment_method
            )
        );
    END IF;

    RETURN jsonb_build_object(
        'success',        true,
        'courier_payout', v_courier_payout,
        'vendor_payout',  v_vendor_payout
    );

EXCEPTION WHEN OTHERS THEN
    RETURN jsonb_build_object('success', false, 'error', SQLERRM);
END;
$$;

GRANT EXECUTE ON FUNCTION public.complete_courier_delivery(UUID, TEXT) TO authenticated;

COMMENT ON FUNCTION public.complete_courier_delivery(UUID, TEXT) IS
'Atomic courier-side delivery completion. Verifies OTP server-side,
credits 80% delivery fee to courier_profiles.balance + profiles.wallet_balance,
appends wallet_transactions delivery_fee row, releases active_capacity,
and marks order delivered. Also settles vendor store balance.
Returns JSONB {success, courier_payout, vendor_payout} or {success:false, error}.';

-- ==============================================================================
-- FIX C-4: Add courier_profiles.status suspension check to accept_order_batch
-- ==============================================================================
-- Replace the function with an updated version that checks courier_profiles.status

DROP FUNCTION IF EXISTS public.accept_order_batch(UUID[], UUID) CASCADE;

CREATE OR REPLACE FUNCTION public.accept_order_batch(
    p_order_ids  UUID[],
    p_courier_id UUID
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_courier         RECORD;
    v_courier_profile RECORD;
    v_active_count    INT;
    v_max_concurrent  CONSTANT INT := 5;
    v_accepted        UUID[] := '{}';
    v_skipped         UUID[] := '{}';
    v_order           RECORD;
    v_order_id        UUID;
BEGIN
    -- ── Guard 1: Caller must be the courier ──────────────────────────────────
    IF auth.uid() IS NOT NULL AND auth.uid() != p_courier_id THEN
        RAISE EXCEPTION 'Unauthorized: courier_id must match authenticated user';
    END IF;

    -- ── Guard 2: Courier profile eligibility ─────────────────────────────────
    SELECT id, profile_type, is_courier_online, license_plate_number
    INTO v_courier
    FROM public.profiles
    WHERE id = p_courier_id;

    IF v_courier IS NULL THEN
        RAISE EXCEPTION 'Courier profile not found';
    END IF;

    IF v_courier.profile_type != 'courier' THEN
        RAISE EXCEPTION 'Profile is not a courier';
    END IF;

    -- ── Guard 3: Check courier_profiles for suspension ───────────────────────
    SELECT status, active_capacity INTO v_courier_profile
    FROM public.courier_profiles
    WHERE user_id = p_courier_id;

    IF v_courier_profile IS NOT NULL AND
       v_courier_profile.status IN ('suspended', 'inactive') THEN
        RETURN jsonb_build_object(
            'success', false,
            'accepted', '[]'::jsonb,
            'skipped',  '[]'::jsonb,
            'error',    'Votre compte est suspendu. Contactez le support Fatibara.'
        );
    END IF;

    -- ── Guard 4: Must be online ───────────────────────────────────────────────
    IF NOT COALESCE(v_courier.is_courier_online, false) THEN
        RETURN jsonb_build_object(
            'success', false,
            'accepted', '[]'::jsonb,
            'skipped',  '[]'::jsonb,
            'error',    'Passez En Service avant d''accepter des missions.'
        );
    END IF;

    -- ── Guard 5: Capacity check ───────────────────────────────────────────────
    SELECT COUNT(*) INTO v_active_count
    FROM public.orders
    WHERE courier_id = p_courier_id
      AND status NOT IN ('delivered', 'cancelled');

    IF v_active_count + array_length(p_order_ids, 1) > v_max_concurrent THEN
        RETURN jsonb_build_object(
            'success',  false,
            'accepted', '[]'::jsonb,
            'skipped',  '[]'::jsonb,
            'error',    format(
                'Capacité maximale atteinte: %s missions actives sur %s. Terminez une livraison avant d''en accepter une nouvelle.',
                v_active_count, v_max_concurrent
            )
        );
    END IF;

    -- ── Per-order atomic assignment ───────────────────────────────────────────
    FOREACH v_order_id IN ARRAY p_order_ids
    LOOP
        SELECT id, status, courier_id
        INTO v_order
        FROM public.orders
        WHERE id         = v_order_id
          AND status     = 'ready_for_pickup'
          AND courier_id IS NULL
        FOR UPDATE SKIP LOCKED;

        IF v_order IS NULL THEN
            v_skipped := array_append(v_skipped, v_order_id);
            CONTINUE;
        END IF;

        UPDATE public.orders
        SET courier_id = p_courier_id,
            status     = 'in_transit',
            updated_at = NOW()
        WHERE id = v_order_id;

        -- Increment courier active_capacity counter
        UPDATE public.courier_profiles
        SET active_capacity = COALESCE(active_capacity, 0) + 1
        WHERE user_id = p_courier_id;

        v_accepted := array_append(v_accepted, v_order_id);
    END LOOP;

    RETURN jsonb_build_object(
        'success',  array_length(v_accepted, 1) > 0,
        'accepted', to_jsonb(v_accepted),
        'skipped',  to_jsonb(v_skipped),
        'error',    NULL
    );

EXCEPTION WHEN OTHERS THEN
    RETURN jsonb_build_object(
        'success',  false,
        'accepted', '[]'::jsonb,
        'skipped',  '[]'::jsonb,
        'error',    SQLERRM
    );
END;
$$;

GRANT EXECUTE ON FUNCTION public.accept_order_batch(UUID[], UUID) TO authenticated;

COMMENT ON FUNCTION public.accept_order_batch(UUID[], UUID) IS
'Atomically accepts pool orders for a courier. Enforces:
  - profile_type = courier
  - courier_profiles.status NOT IN (suspended, inactive)
  - is_courier_online = true
  - max 5 concurrent active orders
  - FOR UPDATE SKIP LOCKED to prevent double-assignment
Also increments courier_profiles.active_capacity on each accepted order.
Returns JSONB { success, accepted: uuid[], skipped: uuid[], error? }.';

-- Signal PostgREST to reload schema cache
NOTIFY pgrst, 'reload schema';
