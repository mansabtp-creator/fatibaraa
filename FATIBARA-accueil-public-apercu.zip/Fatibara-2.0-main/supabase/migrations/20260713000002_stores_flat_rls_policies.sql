ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS user_id uuid;
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS vendor_id uuid;
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS courier_id uuid;
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS user_id uuid;
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS vendor_id uuid;
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS courier_id uuid;




















-- ==============================================================================
-- Migration: Stores Table — Flat RLS Policies + PostgREST Cache Bust
-- Created At: 2026-07-13
--
-- Root Cause:
--   HTTP 406 (Not Acceptable) on GET /rest/v1/stores?select=id&owner_id=eq.*
--   is caused by RECURSIVE RLS policies on the stores table. A policy that
--   subqueries `stores` within its USING() clause (e.g. to join profiles, or
--   to check membership via a nested SELECT on the same table) causes PostgREST
--   to spin into an infinite evaluation loop. PostgREST exits the loop and
--   returns HTTP 406 instead of 200.
--
--   This is NOT a JWT problem. The user UUID in the network request is valid
--   and the Authorization header is well-formed. The 406 fires even with a
--   fully authenticated session.
--
-- Secondary Problem:
--   Three 406s fire simultaneously on every app mount because:
--   1. fetchSessionWithTimeout() → fetchProfile() → stores query
--   2. fetchSessionWithTimeout() → fetchUnreadMessagesCount() → stores query
--   3. onAuthStateChange(INITIAL_SESSION) → fetchProfile() → stores query (again)
--   The client-side fix (INITIAL_SESSION guard + in-flight refs) reduces this
--   to a single request, but the DB fix below is the permanent solution.
--
-- Resolution:
--   1. DROP all legacy recursive policies (some may reference subqueries or JOINs)
--   2. CREATE flat replacement policies (auth.uid() direct comparison only)
--   3. GRANT explicit role permissions to repair PostgREST API handshakes
--   4. NOTIFY pgrst to flush the schema + policy cache
-- ==============================================================================

-- 1. NUKE ALL HISTORICAL AND LEGACY POLICIES ON THE STORES TABLE
DROP POLICY IF EXISTS "Allow public read access" ON public.stores;
DROP POLICY IF EXISTS "Allow authenticated reads" ON public.stores;
DROP POLICY IF EXISTS "Enable read access for all users" ON public.stores;
DROP POLICY IF EXISTS "Users can view their own stores" ON public.stores;
DROP POLICY IF EXISTS "Owners can update their own stores" ON public.stores;
DROP POLICY IF EXISTS "Vendors can manage stores" ON public.stores;
DROP POLICY IF EXISTS "Enable insert for authenticated users only" ON public.stores;
DROP POLICY IF EXISTS "Enable update for owners" ON public.stores;
-- Drop any other ad-hoc policies that may have been applied via previous migrations
DROP POLICY IF EXISTS "stores_select_policy" ON public.stores;
DROP POLICY IF EXISTS "stores_insert_policy" ON public.stores;
DROP POLICY IF EXISTS "stores_update_policy" ON public.stores;
DROP POLICY IF EXISTS "stores_delete_policy" ON public.stores;
DROP POLICY IF EXISTS "Fatibara flat stores read policy" ON public.stores;
DROP POLICY IF EXISTS "Fatibara flat stores insert policy" ON public.stores;
DROP POLICY IF EXISTS "Fatibara flat stores update policy" ON public.stores;

-- 2. CREATE FLAT POLICIES (Zero subqueries, zero joins = 0% chance of recursion)
--
--    SELECT: All authenticated users and anonymous visitors can read stores
--            (required for the shop page, search, and store profile pages)
DROP POLICY IF EXISTS "Fatibara flat stores read policy" ON public.stores;
CREATE POLICY "Fatibara flat stores read policy"
ON public.stores
FOR SELECT
TO authenticated, anon
USING (true);

--    INSERT: Only the authenticated user whose uid matches owner_id can create a store
DROP POLICY IF EXISTS "Fatibara flat stores insert policy" ON public.stores;
CREATE POLICY "Fatibara flat stores insert policy"
ON public.stores
FOR INSERT
TO authenticated
WITH CHECK (auth.uid() = owner_id);

--    UPDATE: Only the owner can update their own store record
DROP POLICY IF EXISTS "Fatibara flat stores update policy" ON public.stores;
CREATE POLICY "Fatibara flat stores update policy"
ON public.stores
FOR UPDATE
TO authenticated
USING (auth.uid() = owner_id)
WITH CHECK (auth.uid() = owner_id);

--    DELETE: Only the owner can delete their store (soft-delete preferred in app)
DROP POLICY IF EXISTS "Fatibara flat stores delete policy" ON public.stores;
CREATE POLICY "Fatibara flat stores delete policy"
ON public.stores
FOR DELETE
TO authenticated
USING (auth.uid() = owner_id);

-- 3. EXPLICITLY RE-GRANT ROLES TO REPAIR POSTGREST API HANDSHAKES
--    PostgREST connects as `anon` for unauthenticated requests and as
--    `authenticated` for JWT-bearing requests. Missing GRANTs at the
--    role level cause PostgREST to reject the request before RLS evaluation,
--    which also surfaces as HTTP 406.
GRANT SELECT                    ON public.stores TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.stores TO authenticated;
GRANT ALL                       ON public.stores TO service_role;
GRANT ALL                       ON public.stores TO postgres;

-- 4. FLUSH THE POSTGREST SCHEMA + POLICY CACHE COMPLETELY
--    Must run AFTER all structural changes above are committed.
--    This eliminates both the HTTP 406 (recursive RLS) and any stale
--    HTTP 400 (schema cache lag after previous migrations).
NOTIFY pgrst, 'reload schema';
