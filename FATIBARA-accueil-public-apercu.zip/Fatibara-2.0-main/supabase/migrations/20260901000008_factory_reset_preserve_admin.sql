-- =============================================================================
-- PRODUCTION FACTORY RESET (explicitly authorized 2026-09-01)
-- Preserves only the specified administrator, platform settings, schema, and
-- migration history. All other Auth users and all public operational data are
-- permanently removed.
-- =============================================================================

DO $$
DECLARE
  v_admin_id CONSTANT UUID := '35782753-330e-4d2a-9e80-2f96e1b02c06';
  v_tables TEXT;
BEGIN
  -- Fail closed: never perform a reset unless the protected administrator is
  -- present in both Auth and the application profile table.
  IF NOT EXISTS (SELECT 1 FROM auth.users WHERE id = v_admin_id) THEN
    RAISE EXCEPTION 'Factory reset aborted: protected admin Auth user is missing';
  END IF;
  IF NOT EXISTS (SELECT 1 FROM public.profiles WHERE id = v_admin_id) THEN
    RAISE EXCEPTION 'Factory reset aborted: protected admin profile is missing';
  END IF;

  CREATE TEMP TABLE factory_reset_admin_profile
  ON COMMIT DROP
  AS SELECT * FROM public.profiles WHERE id = v_admin_id;

  -- Truncate every application-owned base table, retaining only platform
  -- configuration. Extension-owned spatial metadata must not be touched.
  SELECT string_agg(format('public.%I', tablename), ', ' ORDER BY tablename)
  INTO v_tables
  FROM pg_tables
  WHERE schemaname = 'public'
    AND tablename NOT IN ('platform_settings', 'spatial_ref_sys');

  IF v_tables IS NOT NULL THEN
    EXECUTE 'TRUNCATE TABLE ' || v_tables || ' RESTART IDENTITY CASCADE';
  END IF;

  -- Remove every remaining login, identity, session, and user row except the
  -- protected admin. Deleting from auth.users cascades through Auth metadata.
  DELETE FROM auth.users WHERE id <> v_admin_id;

  -- Restore the administrator profile exactly as it was before the reset.
  INSERT INTO public.profiles
  SELECT * FROM factory_reset_admin_profile;
END;
$$;

NOTIFY pgrst, 'reload schema';
