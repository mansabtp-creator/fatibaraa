-- Migration: fix_coupon_usage_increment (C-4 audit fix)
-- Problem:  process_cart_checkout never accepted or incremented coupons.
--           A usage_limit:1 coupon could be applied by every concurrent user.
-- Solution: Add optional p_coupon_code parameter. If supplied, validate and
--           atomically increment usage_count inside the transaction using
--           SELECT FOR UPDATE to prevent concurrent double-use.

CREATE OR REPLACE FUNCTION public.process_cart_checkout(
  p_user_id        UUID,
  p_payment_method TEXT,
  p_orders         JSONB,
  p_deliveries     JSONB,
  p_order_items    JSONB,
  p_coupon_code    TEXT DEFAULT NULL
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_result           JSONB := '[]'::jsonb;
  v_order_data       JSONB;
  v_item_data        JSONB;
  v_delivery_data    JSONB;
  v_order_index      INT;
  v_new_order_id     UUID;
  v_financial_status TEXT;
  v_order_status     TEXT;
  v_coupon_id        UUID;
  v_coupon_limit     INT;
  v_coupon_count     INT;
  v_coupon_expires   TIMESTAMPTZ;
BEGIN
  -- 0. Auth guard
  IF auth.uid() IS NULL OR auth.uid() != p_user_id THEN
    RAISE EXCEPTION 'Unauthorized: caller must match p_user_id';
  END IF;

  -- 0b. Coupon validation + atomic increment (if provided)
  IF p_coupon_code IS NOT NULL AND p_coupon_code != '' THEN
    SELECT id, usage_limit, usage_count, expires_at
      INTO v_coupon_id, v_coupon_limit, v_coupon_count, v_coupon_expires
      FROM public.coupons
      WHERE code = UPPER(p_coupon_code) AND is_active = TRUE
      FOR UPDATE;  -- advisory row lock prevents race conditions

    IF NOT FOUND THEN
      RAISE EXCEPTION 'Code promo invalide ou inactif.';
    END IF;

    IF v_coupon_expires IS NOT NULL AND v_coupon_expires < NOW() THEN
      RAISE EXCEPTION 'Ce code promo a expire.';
    END IF;

    IF v_coupon_limit IS NOT NULL AND v_coupon_count >= v_coupon_limit THEN
      RAISE EXCEPTION 'Ce code promo a atteint sa limite d utilisation.';
    END IF;

    -- Atomically increment; rolled back if any INSERT below fails
    UPDATE public.coupons
       SET usage_count = usage_count + 1
     WHERE id = v_coupon_id;
  END IF;

  -- 1. Determine statuses by payment method
  IF p_payment_method = 'cash' THEN
    v_order_status     := 'confirmed';
    v_financial_status := 'pending';
  ELSE
    v_order_status     := 'pending';
    v_financial_status := 'pending';
  END IF;

  -- 2. Insert each vendor group's order atomically
  FOR v_order_index IN 0 .. jsonb_array_length(p_orders) - 1 LOOP
    v_order_data := p_orders -> v_order_index;

    INSERT INTO public.orders (
      user_id, store_id, vendor_id, customer_name,
      items_count, total_amount, delivery_fee, vendor_delivery_fee,
      status, financial_status, payment_method,
      tracking_number, delivery_otp, shipping_address
    ) VALUES (
      p_user_id,
      NULLIF((v_order_data->>'store_id'),  '')::UUID,
      NULLIF((v_order_data->>'vendor_id'), '')::UUID,
      v_order_data->>'customer_name',
      (v_order_data->>'items_count')::INT,
      (v_order_data->>'total_amount')::NUMERIC,
      COALESCE((v_order_data->>'delivery_fee')::NUMERIC, 0),
      COALESCE((v_order_data->'shipping_address'->>'vendor_delivery_fee')::NUMERIC, 0),
      v_order_status, v_financial_status, p_payment_method,
      v_order_data->>'tracking_number',
      v_order_data->>'delivery_otp',
      v_order_data->'shipping_address'
    )
    RETURNING id INTO v_new_order_id;

    v_result := v_result || jsonb_build_object(
      'id',              v_new_order_id,
      'tracking_number', v_order_data->>'tracking_number'
    );

    -- 2a. Delivery record
    IF p_deliveries IS NOT NULL AND jsonb_array_length(p_deliveries) > v_order_index THEN
      v_delivery_data := p_deliveries -> v_order_index;
      IF v_delivery_data IS NOT NULL AND jsonb_typeof(v_delivery_data) = 'object' THEN
        INSERT INTO public.deliveries (order_id, status, current_location)
        VALUES (
          v_new_order_id,
          COALESCE(v_delivery_data->>'status', 'pending'),
          v_delivery_data->'current_location'
        );
      END IF;
    END IF;

    -- 2b. Order items
    IF p_order_items IS NOT NULL AND jsonb_array_length(p_order_items) > v_order_index THEN
      FOR v_item_data IN SELECT * FROM jsonb_array_elements(p_order_items -> v_order_index) LOOP
        INSERT INTO public.order_items (
          order_id, product_id, quantity, price_at_purchase, selected_variations
        ) VALUES (
          v_new_order_id,
          (v_item_data->>'product_id')::UUID,
          (v_item_data->>'quantity')::INT,
          (v_item_data->>'price_at_purchase')::NUMERIC,
          COALESCE(v_item_data->'selected_variations', '{}'::jsonb)
        );
      END LOOP;
    END IF;

  END LOOP;

  RETURN v_result;

EXCEPTION
  WHEN OTHERS THEN
    RAISE;  -- rolls back coupon increment + all inserts atomically
END;
$$;

GRANT EXECUTE ON FUNCTION public.process_cart_checkout(UUID, TEXT, JSONB, JSONB, JSONB, TEXT)
  TO authenticated;

NOTIFY pgrst, 'reload schema';
