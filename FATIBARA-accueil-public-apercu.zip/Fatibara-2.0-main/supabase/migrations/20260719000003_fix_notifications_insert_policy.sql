-- ============================================================
-- Fix: Notifications table INSERT policy
-- Resolves: POST /rest/v1/notifications 409 (Conflict) errors
-- Root cause: supabase_schema_notifications.sql only added SELECT
-- and UPDATE policies. INSERT was missing, causing PostgREST to
-- reject inserts via FK/RLS violations.
-- ============================================================

-- 1. Ensure the INSERT policy exists (idempotent)
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies
    WHERE schemaname = 'public'
      AND tablename  = 'notifications'
      AND cmd        = 'INSERT'
  ) THEN
    EXECUTE $pol$
      CREATE POLICY "System can insert notifications"
        ON public.notifications
        FOR INSERT
        WITH CHECK (true);
    $pol$;
  END IF;
END $$;

-- 2. Ensure authenticated users can also update their notifications
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies
    WHERE schemaname = 'public'
      AND tablename  = 'notifications'
      AND policyname = 'Users can update their own notifications'
  ) THEN
    EXECUTE $pol$
      CREATE POLICY "Users can update their own notifications"
        ON public.notifications
        FOR UPDATE
        USING (auth.uid() = user_id);
    $pol$;
  END IF;
END $$;
