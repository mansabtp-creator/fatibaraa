-- ==============================================================================
-- Migration: 20260919000001_fix_stores_balance_nonneg.sql
-- Created:   2026-09-19
--
-- Bug:  process_wallet_checkout → 400 "stores_balance_nonneg" check constraint
--
-- Root Cause:
--   In secure_process_order_financials, the vendor payout is calculated as:
--
--     v_item_subtotal   = (total_amount - delivery_fee) / (1 + commission_rate)
--     v_vendor_payout   = v_item_subtotal - vendor_delivery_fee
--
--   When the customer qualifies for free delivery (delivery_fee = 0) but
--   vendor_delivery_fee is still recorded as the logistics cost, v_item_subtotal
--   can be smaller than vendor_delivery_fee — making v_vendor_payout NEGATIVE.
--
--   For wallet-payment orders, v_final_vendor_digital_change = v_vendor_payout
--   (the cash-payment subtraction path is skipped), so a negative value is
--   added to stores.balance, pushing it below zero and firing:
--     "new row for relation "stores" violates check constraint stores_balance_nonneg"
--
-- Fix:
--   1. Clamp v_vendor_payout to GREATEST(0, ...) so the store balance update
--      is never negative for a vendor credit operation.
--   2. Keep the full arithmetic intact for cash orders where negative values
--      are intentional (vendor owes the platform the commission on cash
--      collected in person).
--   3. Add a GREATEST(0, ...) guard on the final UPDATE to stores.balance as
--      a belt-and-suspenders safety net against future arithmetic drift.
-- ==============================================================================


CREATE OR REPLACE FUNCTION public.secure_process_order_financials(p_order_id uuid)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
    v_order                        RECORD;
    v_store                        RECORD;
    v_existing_tx                  BOOLEAN;
    v_commission_str               TEXT;
    v_commission_rate              NUMERIC;
    v_items_real_value             NUMERIC;
    v_item_subtotal                NUMERIC;
    v_platform_commission          NUMERIC;
    v_vendor_payout                NUMERIC;
    v_courier_payout               NUMERIC;
    v_is_cash_payment              BOOLEAN;
    v_final_vendor_digital_change  NUMERIC;
    v_final_courier_digital_change NUMERIC;
    v_courier_balance              NUMERIC;
    v_vendor_description           TEXT;
BEGIN
    -- ── A. Lock order row ────────────────────────────────────────────────────
    SELECT * INTO v_order FROM public.orders WHERE id = p_order_id FOR UPDATE;
    IF NOT FOUND THEN RAISE EXCEPTION 'Order not found: %', p_order_id; END IF;

    -- ── B. Idempotency guard ─────────────────────────────────────────────────
    IF v_order.financial_status = 'processed' THEN
        RETURN jsonb_build_object('success', true, 'alreadyProcessed', true);
    END IF;

    SELECT EXISTS (
        SELECT 1 FROM public.wallet_transactions
        WHERE reference_id = p_order_id::TEXT AND type = 'sale'
    ) INTO v_existing_tx;

    IF v_existing_tx THEN
        UPDATE public.orders SET financial_status = 'processed' WHERE id = p_order_id;
        RETURN jsonb_build_object('success', true, 'alreadyProcessed', true);
    END IF;

    -- ── C. Resolve store ─────────────────────────────────────────────────────
    IF v_order.store_id IS NOT NULL THEN
        SELECT * INTO v_store FROM public.stores WHERE id = v_order.store_id;
    ELSIF v_order.vendor_id IS NOT NULL THEN
        SELECT * INTO v_store FROM public.stores WHERE owner_id = v_order.vendor_id LIMIT 1;
    END IF;

    -- ── D. Commission arithmetic ─────────────────────────────────────────────
    v_items_real_value := COALESCE(v_order.total_amount, 0) - COALESCE(v_order.delivery_fee, 0);

    SELECT value INTO v_commission_str FROM public.platform_settings WHERE id = 'commission_rate';
    IF v_commission_str IS NULL THEN v_commission_str := '5'; END IF;
    v_commission_rate := v_commission_str::numeric / 100.0;

    v_item_subtotal       := v_items_real_value / (1 + v_commission_rate);
    v_platform_commission := v_item_subtotal * v_commission_rate;

    -- [FIX] Clamp vendor_payout to >= 0.
    -- When free delivery applies (delivery_fee = 0) but vendor_delivery_fee was
    -- set to the logistics cost, v_item_subtotal can be less than
    -- vendor_delivery_fee, making the raw difference negative. A vendor credit
    -- must never be negative — the platform absorbs the logistics shortfall.
    v_vendor_payout := GREATEST(
        0,
        v_item_subtotal - COALESCE(v_order.vendor_delivery_fee, 0)
    );

    v_courier_payout := (CASE WHEN COALESCE(v_order.delivery_fee, 0) > 0
                               THEN v_order.delivery_fee
                               ELSE COALESCE(v_order.vendor_delivery_fee, 0) END) * 0.8;

    IF v_order.courier_id IS NULL THEN
        v_vendor_payout := v_vendor_payout + v_courier_payout;
    END IF;

    v_is_cash_payment := COALESCE(
        (v_order.shipping_address->>'payment_method') = 'cash',
        v_order.financial_status != 'paid'
    );

    -- ── E. Vendor payout ─────────────────────────────────────────────────────
    IF v_store.id IS NOT NULL AND v_order.vendor_id IS NOT NULL THEN
        v_final_vendor_digital_change := v_vendor_payout;

        IF v_is_cash_payment AND v_order.courier_id IS NULL THEN
            -- Cash direct collection: vendor already holds the cash, platform
            -- must reclaim commission. This IS intentionally negative.
            v_final_vendor_digital_change := v_vendor_payout - v_order.total_amount;
        END IF;

        IF v_final_vendor_digital_change != 0 THEN
            UPDATE public.stores
            -- [FIX belt+suspenders] GREATEST ensures balance never goes below 0
            -- due to any future arithmetic edge case.
            SET balance = GREATEST(0, COALESCE(balance, 0) + ROUND(v_final_vendor_digital_change))
            WHERE id = v_store.id;

            IF v_is_cash_payment AND v_order.courier_id IS NULL THEN
                v_vendor_description :=
                    'Collecte Cash directe — Retenue commission Commande #'
                    || left(v_order.id::text, 8);
            ELSIF v_is_cash_payment AND v_order.courier_id IS NOT NULL THEN
                v_vendor_description :=
                    'Vente Cash à la livraison (Commande #'
                    || left(v_order.id::text, 8) || ')';
            ELSE
                v_vendor_description :=
                    'Vente #' || left(v_order.id::text, 8)
                    || ' (Payout ' || ROUND(v_item_subtotal) || ')';
            END IF;

            INSERT INTO public.wallet_transactions
              (profile_id, store_id, amount, type, reference_id, description)
            VALUES (
                v_order.vendor_id,
                v_store.id,
                v_final_vendor_digital_change,
                CASE WHEN v_final_vendor_digital_change > 0 THEN 'sale' ELSE 'fee' END,
                v_order.id::TEXT,
                v_vendor_description
            );
        END IF;
    END IF;

    -- ── F. Courier payout — with COD negative-balance guard ──────────────────
    -- [W2 FIX]: The COD balance guard only applies to cash-on-delivery orders.
    -- For wallet/mobile payments, couriers receive a credit (positive change) or
    -- the order has no courier yet — the balance check is irrelevant and must
    -- NOT abort the buyer's transaction.
    IF v_order.courier_id IS NOT NULL THEN
        v_final_courier_digital_change := v_courier_payout;
        IF v_is_cash_payment THEN
            v_final_courier_digital_change := v_courier_payout - v_order.total_amount;
        END IF;

        IF v_final_courier_digital_change != 0 THEN
            -- [W2 FIX]: Only block if this is a cash order AND the courier would go negative.
            -- For wallet orders: v_is_cash_payment is false → this block is skipped entirely.
            IF v_is_cash_payment AND v_final_courier_digital_change < 0 THEN
                SELECT wallet_balance INTO v_courier_balance
                FROM public.profiles
                WHERE id = v_order.courier_id
                FOR UPDATE;

                IF v_courier_balance + v_final_courier_digital_change < 0 THEN
                    -- Soft failure: return without rolling back so admin can manually settle
                    RAISE WARNING '[secure_process_order_financials] COD courier balance too low for order %. Balance=%, Required=%',
                        p_order_id, ROUND(v_courier_balance), ROUND(abs(v_final_courier_digital_change));

                    RETURN jsonb_build_object(
                        'success',        false,
                        'error',          'cod_courier_insufficient_balance',
                        'message',        format(
                            'Courier wallet too low for COD settlement. Balance: %s GNF, Required: %s GNF.',
                            ROUND(v_courier_balance),
                            ROUND(abs(v_final_courier_digital_change))
                        ),
                        'courierBalance', ROUND(v_courier_balance),
                        'debtAmount',     ROUND(abs(v_final_courier_digital_change))
                    );
                END IF;
            END IF;

            -- Credit / debit the courier
            UPDATE public.profiles
            SET wallet_balance = wallet_balance + ROUND(v_final_courier_digital_change),
                updated_at     = NOW()
            WHERE id = v_order.courier_id;

            UPDATE public.courier_profiles
            SET balance    = COALESCE(balance, 0) + ROUND(v_final_courier_digital_change),
                updated_at = NOW()
            WHERE user_id = v_order.courier_id;

            INSERT INTO public.wallet_transactions
              (profile_id, amount, type, reference_id, description)
            VALUES (
                v_order.courier_id,
                v_final_courier_digital_change,
                CASE WHEN v_final_courier_digital_change > 0 THEN 'delivery_fee' ELSE 'fee' END,
                v_order.id::TEXT,
                CASE WHEN v_is_cash_payment
                     THEN 'Collecte Cash — Remise Plateforme Commande #'
                          || left(v_order.id::text, 8)
                     ELSE 'Course effectuée — Commande #'
                          || left(v_order.id::text, 8)
                END
            );
        END IF;
    END IF;

    -- ── G. Platform commission log ────────────────────────────────────────────
    -- [W1 FIX]: Wrapped in BEGIN/EXCEPTION so a schema drift or missing table
    -- on platform_logs NEVER aborts the buyer's payment. The commission is
    -- an internal audit log — it must not block financial transactions.
    BEGIN
        INSERT INTO public.platform_logs (type, amount, reference_id, metadata)
        VALUES (
            'commission',
            ROUND(v_platform_commission),
            v_order.id,
            jsonb_build_object(
                'order_total',  v_order.total_amount,
                'vendor_id',    v_order.vendor_id,
                'is_cash',      v_is_cash_payment
            )
        );
    EXCEPTION WHEN OTHERS THEN
        -- Log a warning but do NOT re-raise — commission logging must never
        -- block a successful payment.
        RAISE WARNING '[secure_process_order_financials] platform_logs INSERT failed for order %: % (state=%)',
            p_order_id, SQLERRM, SQLSTATE;
    END;

    -- ── H. Mark order as financially settled ──────────────────────────────────
    UPDATE public.orders SET financial_status = 'processed' WHERE id = p_order_id;

    RETURN jsonb_build_object(
        'success',            true,
        'vendorPayout',       ROUND(v_vendor_payout),
        'courierPayout',      ROUND(v_courier_payout),
        'platformCommission', ROUND(v_platform_commission)
    );

EXCEPTION
    WHEN OTHERS THEN
        RAISE WARNING '[secure_process_order_financials] order=% error=% detail=%',
            p_order_id, SQLERRM, SQLSTATE;
        RAISE;
END;
$$;

GRANT EXECUTE ON FUNCTION public.secure_process_order_financials(uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION public.secure_process_order_financials(uuid) TO service_role;

DO $$ BEGIN
    RAISE NOTICE '[FIX] secure_process_order_financials: vendor_payout clamped to >= 0; stores.balance guarded against going negative';
END $$;

NOTIFY pgrst, 'reload schema';
