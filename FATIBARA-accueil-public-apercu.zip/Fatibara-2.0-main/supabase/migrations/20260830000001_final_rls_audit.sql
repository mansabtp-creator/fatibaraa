-- ==============================================================================
-- Migration: Final RLS Audit — Closing Remaining Security Gaps
-- Created: 2026-08-30
--
-- Fixes 5 remaining security gaps identified in the comprehensive RLS audit:
--
--   [1] audit_logs — no RLS enabled, no policies. Any authenticated user
--       can read every store's audit activity. Vendors should only see
--       logs for their own store; admins can see all.
--
--   [2] store_staff — table exists in production (used by useVendorData hook)
--       but has NO RLS and no policies. Staff membership is fully public —
--       any user can enumerate who works at any store.
--
--   [3] product_interactions INSERT — pi_insert_any uses WITH CHECK (true),
--       allowing any user to INSERT rows with an arbitrary user_id (forged
--       interaction tracking). Fix: scope to auth.uid() = user_id OR NULL.
--
--   [4] vendor_invitations — migration 20260829000002 created vi_select_by_token
--       and vi_anon_select_by_token policies. Migration 20260829000007 issued a
--       REVOKE SELECT but did NOT drop these policies. They still exist and
--       create a confusing/inconsistent state. Drop them explicitly so the only
--       access path is the validate_vendor_invitation_token() SECURITY DEFINER RPC.
--
--   [5] guinea_locations — has a guinea_locations_public_read policy from
--       migration 20240415000001 but ENABLE ROW LEVEL SECURITY was never called,
--       so the policy is silently ignored (all rows readable by anyone anyway).
--       Enabling RLS + the existing read policy makes the intent explicit and
--       prevents future accidental writes.
-- ==============================================================================

-- ── [1] audit_logs ────────────────────────────────────────────────────────────
-- The table is created at runtime via the app (no CREATE TABLE migration found),
-- so we guard with IF EXISTS throughout.

DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.tables
    WHERE table_schema = 'public' AND table_name = 'audit_logs'
  ) THEN
    -- Enable RLS
    EXECUTE 'ALTER TABLE public.audit_logs ENABLE ROW LEVEL SECURITY';

    -- Vendors can read logs for stores they own
    EXECUTE $q$
      DROP POLICY IF EXISTS "audit_logs_vendor_own" ON public.audit_logs;
      CREATE POLICY "audit_logs_vendor_own"
        ON public.audit_logs FOR SELECT TO authenticated
        USING (
          store_id IN (
            SELECT id FROM public.stores WHERE owner_id = auth.uid()
          )
        )
    $q$;

    -- Vendors can insert audit events for their own store
    EXECUTE $q$
      DROP POLICY IF EXISTS "audit_logs_vendor_insert" ON public.audit_logs;
      CREATE POLICY "audit_logs_vendor_insert"
        ON public.audit_logs FOR INSERT TO authenticated
        WITH CHECK (
          store_id IN (
            SELECT id FROM public.stores WHERE owner_id = auth.uid()
          )
          OR store_id IS NULL -- allow system-level events without a store
        )
    $q$;

    -- Admins can do everything
    EXECUTE $q$
      DROP POLICY IF EXISTS "audit_logs_admin_all" ON public.audit_logs;
      CREATE POLICY "audit_logs_admin_all"
        ON public.audit_logs FOR ALL TO authenticated
        USING (public.is_admin())
        WITH CHECK (public.is_admin())
    $q$;

    RAISE NOTICE 'audit_logs: RLS enabled and policies applied';
  ELSE
    RAISE NOTICE 'audit_logs: table does not exist yet — skipping';
  END IF;
END;
$$;

-- ── [2] store_staff ───────────────────────────────────────────────────────────
-- Protect store staff membership. Staff are referenced by useVendorData for
-- manager/staff login — they need to read their own record. Store owners need
-- to read all staff for their store. Admins need full access.

DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.tables
    WHERE table_schema = 'public' AND table_name = 'store_staff'
  ) THEN
    EXECUTE 'ALTER TABLE public.store_staff ENABLE ROW LEVEL SECURITY';

    -- Store owners can read and manage their own store's staff list
    EXECUTE $q$
      DROP POLICY IF EXISTS "store_staff_owner_all" ON public.store_staff;
      CREATE POLICY "store_staff_owner_all"
        ON public.store_staff FOR ALL TO authenticated
        USING (
          store_id IN (
            SELECT id FROM public.stores WHERE owner_id = auth.uid()
          )
        )
        WITH CHECK (
          store_id IN (
            SELECT id FROM public.stores WHERE owner_id = auth.uid()
          )
        )
    $q$;

    -- Staff members can read their own record (needed for role lookup in useVendorData)
    EXECUTE $q$
      DROP POLICY IF EXISTS "store_staff_own_select" ON public.store_staff;
      CREATE POLICY "store_staff_own_select"
        ON public.store_staff FOR SELECT TO authenticated
        USING (user_id = auth.uid())
    $q$;

    -- Admins can manage all staff
    EXECUTE $q$
      DROP POLICY IF EXISTS "store_staff_admin_all" ON public.store_staff;
      CREATE POLICY "store_staff_admin_all"
        ON public.store_staff FOR ALL TO authenticated
        USING (public.is_admin())
        WITH CHECK (public.is_admin())
    $q$;

    RAISE NOTICE 'store_staff: RLS enabled and policies applied';
  ELSE
    RAISE NOTICE 'store_staff: table does not exist yet — skipping';
  END IF;
END;
$$;

-- ── [3] product_interactions INSERT — close user_id forgery gap ───────────────
-- The previous pi_insert_any policy used WITH CHECK (true), meaning any user
-- could INSERT a row with an arbitrary user_id — spoofing views/clicks for
-- other users. Fix: allow NULL user_id (anonymous tracking) or own user_id only.

ALTER TABLE public.product_interactions ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "pi_insert_any" ON public.product_interactions;
CREATE POLICY "pi_insert_any"
  ON public.product_interactions FOR INSERT
  WITH CHECK (
    -- Anonymous tracking: user_id must be NULL
    -- Authenticated tracking: user_id must match caller
    user_id IS NULL OR user_id = auth.uid()
  );

-- ── [4] vendor_invitations — drop stale SELECT policies left by 20260829000002 ─
-- Migration 20260829000007 issued REVOKE SELECT ON vendor_invitations FROM
-- authenticated, but the old vi_select_by_token and vi_anon_select_by_token
-- policies were never explicitly dropped. Clean them up now so the only
-- valid access path is the validate_vendor_invitation_token() SECURITY DEFINER RPC.

DROP POLICY IF EXISTS "vi_select_by_token"       ON public.vendor_invitations;
DROP POLICY IF EXISTS "vi_anon_select_by_token"   ON public.vendor_invitations;
-- Also drop the original policy name from the initial migration, just in case
DROP POLICY IF EXISTS "anyone_can_read_invitation_by_token" ON public.vendor_invitations;

-- Re-assert: only admins may SELECT directly from the table
-- (validate_vendor_invitation_token uses SECURITY DEFINER so bypasses this)
DROP POLICY IF EXISTS "vi_admin_all" ON public.vendor_invitations;
CREATE POLICY "vi_admin_all"
  ON public.vendor_invitations FOR ALL TO authenticated
  USING  (public.is_admin())
  WITH CHECK (public.is_admin());

-- Ensure the REVOKE is still in effect (idempotent)
REVOKE SELECT ON public.vendor_invitations FROM authenticated;
REVOKE SELECT ON public.vendor_invitations FROM anon;
-- Service role bypasses RLS and retains full access implicitly.

-- ── [5] guinea_locations — enable RLS to activate the existing read policy ────
-- The guinea_locations_public_read policy exists since migration 20240415000001
-- but ENABLE ROW LEVEL SECURITY was never called. The policy was silently ignored.

DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.tables
    WHERE table_schema = 'public' AND table_name = 'guinea_locations'
  ) THEN
    EXECUTE 'ALTER TABLE public.guinea_locations ENABLE ROW LEVEL SECURITY';

    -- Public read (location data for address pickers — intentionally open)
    EXECUTE $q$
      DROP POLICY IF EXISTS "guinea_locations_public_read" ON public.guinea_locations;
      CREATE POLICY "guinea_locations_public_read"
        ON public.guinea_locations FOR SELECT
        USING (true)
    $q$;

    -- Only admins may write location data
    EXECUTE $q$
      DROP POLICY IF EXISTS "guinea_locations_admin_write" ON public.guinea_locations;
      CREATE POLICY "guinea_locations_admin_write"
        ON public.guinea_locations FOR ALL TO authenticated
        USING (public.is_admin())
        WITH CHECK (public.is_admin())
    $q$;

    RAISE NOTICE 'guinea_locations: RLS enabled and policies applied';
  ELSE
    RAISE NOTICE 'guinea_locations: table does not exist yet — skipping';
  END IF;
END;
$$;

-- ── Reload PostgREST schema cache ─────────────────────────────────────────────
NOTIFY pgrst, 'reload schema';
