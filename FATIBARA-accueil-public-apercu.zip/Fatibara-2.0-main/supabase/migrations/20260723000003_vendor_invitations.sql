-- Migration: vendor_invitations table
-- Allows admins to generate single-use invite links scoped to the 'vendor' role.
-- When a user registers via an invite link, their profile_type is set to 'vendor'
-- automatically and the invitation is consumed.
--
-- Created: 2026-07-23
-- Fixed:   2026-07-29 — token uses md5(uuid) instead of gen_random_bytes (no pgcrypto needed).
--                        Removed SET role = 'vendor' (column does not exist in profiles).

CREATE TABLE IF NOT EXISTS public.vendor_invitations (
  id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  -- 32-char hex token — md5(uuid||uuid), no extension required
  token        TEXT NOT NULL UNIQUE DEFAULT md5(gen_random_uuid()::text || gen_random_uuid()::text),
  created_by   UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  email_hint   TEXT,
  label        TEXT,
  used_by      UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  used_at      TIMESTAMPTZ,
  expires_at   TIMESTAMPTZ NOT NULL DEFAULT (NOW() + INTERVAL '7 days'),
  created_at   TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  is_revoked   BOOLEAN NOT NULL DEFAULT FALSE
);

-- If the table already existed with the old gen_random_bytes default, fix it
ALTER TABLE public.vendor_invitations
  ALTER COLUMN token SET DEFAULT md5(gen_random_uuid()::text || gen_random_uuid()::text);

-- Grants
GRANT SELECT, INSERT, UPDATE, DELETE ON public.vendor_invitations TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.vendor_invitations TO service_role;

-- Indexes
CREATE INDEX IF NOT EXISTS idx_vendor_invitations_token     ON public.vendor_invitations (token);
CREATE INDEX IF NOT EXISTS idx_vendor_invitations_created_by ON public.vendor_invitations (created_by);

-- RLS
ALTER TABLE public.vendor_invitations ENABLE ROW LEVEL SECURITY;

-- Admins can do everything
DROP POLICY IF EXISTS "admins_full_access_invitations" ON public.vendor_invitations;
CREATE POLICY "admins_full_access_invitations"
  ON public.vendor_invitations
  FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM public.profiles WHERE id = auth.uid() AND is_admin = true
    )
  );

-- Any authenticated user can read the token row (to validate their invite link)
DROP POLICY IF EXISTS "anyone_can_read_invitation_by_token" ON public.vendor_invitations;
CREATE POLICY "anyone_can_read_invitation_by_token"
  ON public.vendor_invitations
  FOR SELECT
  TO authenticated
  USING (true);

-- ── RPC: create_vendor_invitation ──────────────────────────────────────────────
-- Generates a new invite token. Admin-only.
CREATE OR REPLACE FUNCTION public.create_vendor_invitation(
  p_email_hint TEXT DEFAULT NULL,
  p_label      TEXT DEFAULT NULL,
  p_expires_days INT DEFAULT 7
)
RETURNS TEXT  -- returns the token
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_token TEXT;
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM public.profiles WHERE id = auth.uid() AND is_admin = true
  ) THEN
    RAISE EXCEPTION 'Unauthorized: admin role required';
  END IF;

  INSERT INTO public.vendor_invitations (created_by, email_hint, label, expires_at)
  VALUES (
    auth.uid(),
    p_email_hint,
    p_label,
    NOW() + (p_expires_days || ' days')::INTERVAL
  )
  RETURNING token INTO v_token;

  RETURN v_token;
END;
$$;

GRANT EXECUTE ON FUNCTION public.create_vendor_invitation(TEXT, TEXT, INT) TO authenticated;

-- ── RPC: consume_vendor_invitation ─────────────────────────────────────────────
-- Called at registration time. Validates the token and marks it as used.
-- Returns TRUE if the invite was valid and has been consumed.
CREATE OR REPLACE FUNCTION public.consume_vendor_invitation(p_token TEXT)
RETURNS BOOLEAN
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_invitation public.vendor_invitations%ROWTYPE;
BEGIN
  SELECT * INTO v_invitation
  FROM public.vendor_invitations
  WHERE token = p_token
  FOR UPDATE;

  IF NOT FOUND THEN
    RETURN FALSE;
  END IF;

  IF v_invitation.is_revoked THEN RETURN FALSE; END IF;
  IF v_invitation.used_at IS NOT NULL THEN RETURN FALSE; END IF;
  IF v_invitation.expires_at < NOW() THEN RETURN FALSE; END IF;

  -- Mark as consumed
  UPDATE public.vendor_invitations
  SET used_by = auth.uid(), used_at = NOW()
  WHERE id = v_invitation.id;

  -- Upgrade caller's profile_type to vendor
  UPDATE public.profiles
  SET profile_type = 'vendor'
  WHERE id = auth.uid();

  RETURN TRUE;
END;
$$;

GRANT EXECUTE ON FUNCTION public.consume_vendor_invitation(TEXT) TO authenticated;
