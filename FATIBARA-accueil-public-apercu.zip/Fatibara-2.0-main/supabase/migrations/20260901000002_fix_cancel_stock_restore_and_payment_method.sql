-- ==============================================================================
-- Migration: Fix 3 financial/inventory correctness bugs
-- Created At: 2026-09-01
-- Author:     Antigravity / Fatibara Engineering
--
-- BUG 1 — secure_process_order_financials: harden payment_method resolution
--   The function reads payment type from:
--     (v_order.shipping_address->>'payment_method') = 'cash'
--   Orders created by process_cart_checkout (new, 2026-09-01) now write
--   payment_method as a top-level orders column in addition to the JSON key.
--   Harden the COALESCE to prefer the top-level column so the function stays
--   correct for all past and future order creation paths:
--     COALESCE(v_order.payment_method, shipping_address->>'payment_method')
--
-- BUG 2 — cancel_vendor_order + secure_refund_order_financials: stock not restored
--   When an order is cancelled, decrement_product_stock already fired on INSERT
--   of order_items, reducing stock_quantity. Neither cancel function restores stock.
--   Result: a cancelled order permanently reduces vendor inventory counts, causing
--   products to appear out-of-stock even when no sale was completed.
--
--   Fix: add a PERFORM call inside both cancel functions that increments
--   stock_quantity for each order_item belonging to the cancelled order.
--   Also re-activate the product if it was deactivated (is_active = false)
--   solely because stock hit 0.
--
-- BUG 3 — Vendor Analytics: unit_price column does not exist
--   src/pages/vendor/Analytics.tsx queries order_items.unit_price, but the
--   schema column is price_at_purchase (set by all checkout RPCs).
--   unit_price is NULL for every row → revenue always displays as 0 GNF.
--   Fix: expose a stable view order_items_with_unit_price that aliases the column.
--   The Analytics component is updated separately to use price_at_purchase directly.
-- ==============================================================================

-- ── Bug 1: Harden payment method resolution in secure_process_order_financials ─
CREATE OR REPLACE FUNCTION public.secure_process_order_financials(p_order_id uuid)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
    v_order                        RECORD;
    v_store                        RECORD;
    v_existing_tx                  BOOLEAN;
    v_commission_str               TEXT;
    v_commission_rate              NUMERIC;
    v_items_real_value             NUMERIC := 0;
    v_item_subtotal                NUMERIC;
    v_platform_commission          NUMERIC;
    v_vendor_payout                NUMERIC;
    v_courier_payout               NUMERIC;
    v_is_cash_payment              BOOLEAN;
    v_resolved_payment_method      TEXT;
    v_final_vendor_digital_change  NUMERIC;
    v_final_courier_digital_change NUMERIC;
BEGIN
    SELECT * INTO v_order FROM public.orders WHERE id = p_order_id FOR UPDATE;
    IF NOT FOUND THEN RAISE EXCEPTION 'Order not found'; END IF;

    IF v_order.financial_status = 'processed' THEN
        RETURN jsonb_build_object('success', true, 'alreadyProcessed', true);
    END IF;

    SELECT EXISTS (
        SELECT 1 FROM public.wallet_transactions WHERE reference_id = p_order_id AND type = 'sale'
    ) INTO v_existing_tx;

    IF v_existing_tx THEN
        UPDATE public.orders SET financial_status = 'processed' WHERE id = p_order_id;
        RETURN jsonb_build_object('success', true, 'alreadyProcessed', true);
    END IF;

    SELECT * INTO v_store FROM public.stores
    WHERE id = v_order.store_id
       OR (v_order.store_id IS NULL AND owner_id = v_order.vendor_id)
    LIMIT 1;

    v_items_real_value := v_order.total_amount - COALESCE(v_order.delivery_fee, 0);

    SELECT value INTO v_commission_str FROM public.platform_settings WHERE id = 'commission_rate';
    IF v_commission_str IS NULL THEN v_commission_str := '5'; END IF;
    v_commission_rate := v_commission_str::numeric / 100.0;

    v_item_subtotal       := v_items_real_value / (1 + v_commission_rate);
    v_platform_commission := v_item_subtotal * v_commission_rate;
    v_vendor_payout       := v_item_subtotal - COALESCE(v_order.vendor_delivery_fee, 0);
    v_courier_payout      := (CASE WHEN COALESCE(v_order.delivery_fee, 0) > 0
                                   THEN v_order.delivery_fee
                                   ELSE COALESCE(v_order.vendor_delivery_fee, 0) END) * 0.8;

    IF v_order.courier_id IS NULL THEN
        v_vendor_payout := v_vendor_payout + v_courier_payout;
    END IF;

    -- ── BUG 1 FIX: prefer top-level payment_method column (set by process_cart_checkout);
    -- fall back to shipping_address JSON key (set by legacy checkout paths);
    -- final fallback: treat as cash when financial_status != 'paid'.
    v_resolved_payment_method := COALESCE(
        v_order.payment_method,
        v_order.shipping_address->>'payment_method'
    );
    v_is_cash_payment := COALESCE(
        v_resolved_payment_method = 'cash',
        v_order.financial_status != 'paid'
    );

    IF v_store.id IS NOT NULL THEN
        v_final_vendor_digital_change := v_vendor_payout;
        IF v_is_cash_payment AND v_order.courier_id IS NULL THEN
            v_final_vendor_digital_change := v_vendor_payout - v_order.total_amount;
        END IF;
        IF v_final_vendor_digital_change != 0 THEN
            UPDATE public.stores
            SET balance = COALESCE(balance, 0) + ROUND(v_final_vendor_digital_change)
            WHERE id = v_store.id;
            INSERT INTO public.wallet_transactions (profile_id, amount, type, reference_id, description)
            VALUES (
                v_order.vendor_id, v_final_vendor_digital_change,
                CASE WHEN v_final_vendor_digital_change > 0 THEN 'sale' ELSE 'fee' END,
                v_order.id,
                CASE WHEN v_is_cash_payment
                     THEN 'Collecte Cash #' || left(v_order.id::text, 8) || ' (Retenue: ' || abs(ROUND(v_final_vendor_digital_change)) || ')'
                     ELSE 'Vente #' || left(v_order.id::text, 8) || ' (Payout ' || ROUND(v_item_subtotal) || ')'
                END
            );
        END IF;
    END IF;

    IF v_order.courier_id IS NOT NULL THEN
        v_final_courier_digital_change := v_courier_payout;
        IF v_is_cash_payment THEN
            v_final_courier_digital_change := v_courier_payout - v_order.total_amount;
        END IF;
        IF v_final_courier_digital_change != 0 THEN
            UPDATE public.profiles
            SET wallet_balance = wallet_balance + ROUND(v_final_courier_digital_change)
            WHERE id = v_order.courier_id;
            INSERT INTO public.wallet_transactions (profile_id, amount, type, reference_id, description)
            VALUES (
                v_order.courier_id, v_final_courier_digital_change,
                CASE WHEN v_final_courier_digital_change > 0 THEN 'delivery_fee' ELSE 'fee' END,
                v_order.id,
                CASE WHEN v_is_cash_payment
                     THEN 'Collecte Cash #' || left(v_order.id::text, 8) || ' (Retenue: ' || abs(ROUND(v_final_courier_digital_change)) || ')'
                     ELSE 'Course effectuée - Commande #' || left(v_order.id::text, 8)
                END
            );
        END IF;
    END IF;

    INSERT INTO public.platform_logs (type, amount, reference_id, metadata)
    VALUES ('commission', ROUND(v_platform_commission), v_order.id,
            jsonb_build_object('order_total', v_order.total_amount, 'vendor_id', v_order.vendor_id));

    UPDATE public.orders SET financial_status = 'processed' WHERE id = p_order_id;

    RETURN jsonb_build_object(
        'success', true,
        'vendorPayout', ROUND(v_vendor_payout),
        'courierPayout', ROUND(v_courier_payout),
        'platformCommission', ROUND(v_platform_commission)
    );
END;
$$;

-- ── Bug 2a: cancel_vendor_order — restore stock on cancellation ───────────────
CREATE OR REPLACE FUNCTION public.cancel_vendor_order(
    target_order_id uuid,
    cancel_reason   text
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
    v_order        public.orders%ROWTYPE;
    v_needs_refund BOOLEAN;
    v_item         RECORD;
BEGIN
    SELECT * INTO v_order FROM public.orders WHERE id = target_order_id FOR UPDATE;

    IF NOT FOUND THEN RAISE EXCEPTION 'Order not found'; END IF;
    IF v_order.vendor_id != auth.uid() THEN RAISE EXCEPTION 'Unauthorized: You do not own this store'; END IF;
    IF v_order.status IN ('delivered', 'cancelled') THEN RAISE EXCEPTION 'Order is already in a terminal state'; END IF;
    IF v_order.financial_status = 'refunded' THEN RAISE EXCEPTION 'Order already refunded'; END IF;

    v_needs_refund := (v_order.financial_status = 'paid')
                      AND (v_order.status NOT IN ('pending', 'cancelled'));

    IF v_needs_refund THEN
        UPDATE public.profiles
        SET wallet_balance = wallet_balance + ROUND(v_order.total_amount)
        WHERE id = v_order.user_id;

        INSERT INTO public.wallet_transactions (profile_id, amount, type, reference_id, description)
        VALUES (
            v_order.user_id, v_order.total_amount, 'refund', target_order_id,
            'Remboursement Commande #' || left(target_order_id::text, 8) || ' (' || cancel_reason || ')'
        );
    END IF;

    -- ── BUG 2 FIX: restore stock for every item in this order ─────────────────
    -- The decrement_product_stock trigger fired on INSERT of order_items.
    -- Without this restore, a cancelled order permanently reduces inventory.
    FOR v_item IN
        SELECT product_id, quantity FROM public.order_items WHERE order_id = target_order_id
    LOOP
        UPDATE public.products
        SET
            stock_quantity = COALESCE(stock_quantity, 0) + v_item.quantity,
            -- Re-activate the product if it was deactivated only because stock hit 0
            is_active = CASE
                WHEN NOT is_active
                     AND COALESCE(stock_quantity, 0) + v_item.quantity > 0
                THEN TRUE
                ELSE is_active
            END
        WHERE id = v_item.product_id;
    END LOOP;

    UPDATE public.orders
    SET status           = 'cancelled',
        financial_status = CASE WHEN v_needs_refund THEN 'refunded' ELSE financial_status END,
        updated_at       = now()
    WHERE id = target_order_id;
END;
$$;

-- ── Bug 2b: secure_refund_order_financials — restore stock on cancellation ────
CREATE OR REPLACE FUNCTION public.secure_refund_order_financials(
    p_order_id      uuid,
    p_cancel_reason text DEFAULT 'Annulation'
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
    v_order              record;
    v_is_digital_payment boolean;
    v_item               RECORD;
BEGIN
    SELECT * INTO v_order FROM public.orders WHERE id = p_order_id FOR UPDATE;
    IF NOT FOUND THEN RAISE EXCEPTION 'Order not found'; END IF;

    IF v_order.financial_status = 'refunded' THEN
        RETURN jsonb_build_object('success', true, 'alreadyRefunded', true);
    END IF;

    -- A payment is digital (wallet/mobile-money) if financial_status was set to 'paid'.
    -- COD orders stay at financial_status='pending' so they never trigger a wallet credit.
    v_is_digital_payment := (v_order.financial_status = 'paid');

    IF v_is_digital_payment AND v_order.status != 'pending' THEN
        UPDATE public.profiles
        SET wallet_balance = wallet_balance + ROUND(v_order.total_amount)
        WHERE id = v_order.user_id;

        INSERT INTO public.wallet_transactions (profile_id, amount, type, reference_id, description)
        VALUES (
            v_order.user_id, v_order.total_amount, 'refund', v_order.id,
            'Remboursement Commande #' || left(v_order.id::text, 8) || ' (' || p_cancel_reason || ')'
        );
    END IF;

    -- ── BUG 2 FIX: restore stock for every item in this order ─────────────────
    FOR v_item IN
        SELECT product_id, quantity FROM public.order_items WHERE order_id = p_order_id
    LOOP
        UPDATE public.products
        SET
            stock_quantity = COALESCE(stock_quantity, 0) + v_item.quantity,
            is_active = CASE
                WHEN NOT is_active
                     AND COALESCE(stock_quantity, 0) + v_item.quantity > 0
                THEN TRUE
                ELSE is_active
            END
        WHERE id = v_item.product_id;
    END LOOP;

    UPDATE public.orders SET financial_status = 'refunded', status = 'cancelled' WHERE id = p_order_id;
    RETURN jsonb_build_object('success', true);
END;
$$;

-- Re-grant (idempotent)
GRANT EXECUTE ON FUNCTION public.secure_process_order_financials(uuid)       TO authenticated;
GRANT EXECUTE ON FUNCTION public.cancel_vendor_order(uuid, text)             TO authenticated;
GRANT EXECUTE ON FUNCTION public.secure_refund_order_financials(uuid, text)  TO authenticated;

NOTIFY pgrst, 'reload schema';
