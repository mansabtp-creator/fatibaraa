-- ==============================================================================
-- Migration: Orders Table — Flat RLS Policies (Fix SQLSTATE 42P17)
-- Created At: 2026-07-14
--
-- Root Cause:
--   SQLSTATE 42P17 "infinite recursion detected in policy for relation 'orders'"
--   fires because legacy policies on public.orders contain subqueries that
--   reference public.orders itself (e.g. EXISTS (SELECT 1 FROM public.orders ...))
--   or join through tables whose own RLS policies loop back to orders.
--
--   PostgREST aborts with HTTP 500 on every UPDATE / INSERT because the DB
--   engine cannot evaluate the recursive predicate.
--
-- Resolution:
--   1. DROP all known recursive / legacy policies by name
--   2. CREATE flat replacement policies using only auth.uid() direct equality —
--      zero subqueries, zero joins, zero recursion risk
--   3. RE-GRANT explicit role permissions so PostgREST API handshakes succeed
--   4. NOTIFY pgrst to flush the schema + policy cache
-- ==============================================================================

-- ── 1. NUKE ALL LEGACY RECURSIVE POLICIES ───────────────────────────────────
-- Drop every known policy name (old and new). IF EXISTS makes this idempotent.

-- Generic / auto-generated names
DROP POLICY IF EXISTS "Enable read access for all users"          ON public.orders;
DROP POLICY IF EXISTS "Enable insert for authenticated users only" ON public.orders;
DROP POLICY IF EXISTS "Enable update for users based on email"    ON public.orders;
DROP POLICY IF EXISTS "Enable delete for users based on email"    ON public.orders;

-- Vendor-scoped (recursive — referenced orders inside USING)
DROP POLICY IF EXISTS "Vendors can view their own orders"         ON public.orders;
DROP POLICY IF EXISTS "Vendors can update their own orders"       ON public.orders;
DROP POLICY IF EXISTS "Vendors can transition order status"       ON public.orders;
DROP POLICY IF EXISTS "Vendors can insert orders"                 ON public.orders;

-- Client / buyer-scoped
DROP POLICY IF EXISTS "Clients can view their own orders"         ON public.orders;
DROP POLICY IF EXISTS "Clients can insert their own orders"       ON public.orders;
DROP POLICY IF EXISTS "Users can view their own orders"           ON public.orders;
DROP POLICY IF EXISTS "Users can insert their own orders"         ON public.orders;

-- Courier-scoped
DROP POLICY IF EXISTS "Couriers can view assigned orders"         ON public.orders;
DROP POLICY IF EXISTS "Couriers can update assigned orders"       ON public.orders;
DROP POLICY IF EXISTS "Couriers can claim orders"                 ON public.orders;

-- Admin / service
DROP POLICY IF EXISTS "Admins can view all orders"                ON public.orders;
DROP POLICY IF EXISTS "Admins can update all orders"              ON public.orders;
DROP POLICY IF EXISTS "Service role full access"                  ON public.orders;

-- Flat slug-named policies from prior migrations (belt-and-suspenders)
DROP POLICY IF EXISTS "orders_select_policy"                      ON public.orders;
DROP POLICY IF EXISTS "orders_insert_policy"                      ON public.orders;
DROP POLICY IF EXISTS "orders_update_policy"                      ON public.orders;
DROP POLICY IF EXISTS "orders_delete_policy"                      ON public.orders;
DROP POLICY IF EXISTS "Fatibara flat orders read policy"          ON public.orders;
DROP POLICY IF EXISTS "Fatibara flat orders insert policy"        ON public.orders;
DROP POLICY IF EXISTS "Fatibara flat orders update policy"        ON public.orders;
DROP POLICY IF EXISTS "Fatibara flat orders delete policy"        ON public.orders;

-- ── 2. ENSURE RLS IS ENABLED ────────────────────────────────────────────────
ALTER TABLE public.orders ENABLE ROW LEVEL SECURITY;

-- ── 3. CREATE FLAT POLICIES (zero subqueries = zero recursion risk) ──────────
--
--    SELECT: Any authenticated user can read orders where they are the buyer,
--            the vendor, OR the assigned courier.
--            Single OR expression — no subquery into orders or any other table.
DROP POLICY IF EXISTS "Fatibara flat orders read policy" ON public.orders;
CREATE POLICY "Fatibara flat orders read policy"
ON public.orders
FOR SELECT
TO authenticated
USING (
  auth.uid() = user_id
  OR auth.uid() = vendor_id
  OR auth.uid() = courier_id
);

--    INSERT: Buyers insert their own orders (user_id must match their uid).
DROP POLICY IF EXISTS "Fatibara flat orders insert policy" ON public.orders;
CREATE POLICY "Fatibara flat orders insert policy"
ON public.orders
FOR INSERT
TO authenticated
WITH CHECK (
  auth.uid() = user_id
);

--    UPDATE: The vendor OR the assigned courier can update an order row.
--            Flat equality — no recursion possible.
DROP POLICY IF EXISTS "Fatibara flat orders update policy" ON public.orders;
CREATE POLICY "Fatibara flat orders update policy"
ON public.orders
FOR UPDATE
TO authenticated
USING (
  auth.uid() = vendor_id
  OR auth.uid() = courier_id
)
WITH CHECK (
  auth.uid() = vendor_id
  OR auth.uid() = courier_id
);

--    DELETE: Only the vendor can soft-cancel (delete) their own orders.
--            Hard deletes are rare; prefer status='cancelled' in application code.
DROP POLICY IF EXISTS "Fatibara flat orders delete policy" ON public.orders;
CREATE POLICY "Fatibara flat orders delete policy"
ON public.orders
FOR DELETE
TO authenticated
USING (
  auth.uid() = vendor_id
);

-- ── 4. EXPLICITLY RE-GRANT ROLES ────────────────────────────────────────────
GRANT SELECT, INSERT, UPDATE, DELETE ON public.orders TO authenticated;
GRANT ALL                            ON public.orders TO service_role;
GRANT ALL                            ON public.orders TO postgres;
-- anon users should NOT see order data — no grant intentionally omitted.

-- ── 5. FLUSH THE POSTGREST SCHEMA + POLICY CACHE ────────────────────────────
NOTIFY pgrst, 'reload schema';
