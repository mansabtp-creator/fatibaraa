-- ==============================================================================
-- Migration: process_cart_checkout — atomic order creation for COD & mobile money
-- Created At: 2026-09-01
-- Author:     Antigravity / Fatibara Engineering
--
-- PROBLEM:
--   CartCheckoutPage.tsx inserted orders for COD and mobile-money checkouts using
--   three separate client-side Supabase calls (orders → deliveries → order_items).
--   Because these run sequentially without a DB transaction:
--
--     1. If the `deliveries` INSERT fails after `orders` already succeeded, a ghost
--        order row exists with no delivery record and no items.
--     2. If a multi-vendor cart has 3 orders and the 3rd delivery fails, the first
--        two orders are permanently orphaned.
--     3. There is no automatic rollback — partial state silently persists in the DB.
--
-- FIX:
--   A single plpgsql function that wraps all INSERTs in one implicit transaction.
--   Any failure causes a full rollback — the DB is never left in a partial state.
--
--   The function is intentionally payment-agnostic (no balance deduction) and is
--   called for both COD and mobile-money flows.  For wallet payments, the existing
--   process_wallet_checkout RPC (which also deducts balance) is used instead.
--
-- FINANCIAL STATUS MAPPING:
--   COD    → financial_status = 'pending'  (money hasn't moved yet)
--   mobile → financial_status = 'pending'  (USSD push sent; webhook updates to 'paid')
--
-- RETURN:
--   JSONB array of { id, tracking_number } for each inserted order row.
-- ==============================================================================

CREATE OR REPLACE FUNCTION public.process_cart_checkout(
  p_user_id        UUID,
  p_payment_method TEXT,          -- 'cash' | 'orange' | 'mtn'
  p_orders         JSONB,
  p_deliveries     JSONB,
  p_order_items    JSONB
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_result           JSONB := '[]'::jsonb;
  v_order_data       JSONB;
  v_item_data        JSONB;
  v_delivery_data    JSONB;
  v_order_index      INT;
  v_new_order_id     UUID;
  v_financial_status TEXT;
  v_order_status     TEXT;
BEGIN
  -- ── 0. Auth guard ────────────────────────────────────────────────────────────
  IF auth.uid() IS NULL OR auth.uid() != p_user_id THEN
    RAISE EXCEPTION 'Unauthorized: caller must match p_user_id';
  END IF;

  -- ── 1. Determine statuses by payment method ──────────────────────────────────
  IF p_payment_method = 'cash' THEN
    -- COD: order confirmed immediately, money arrives on delivery
    v_order_status     := 'confirmed';
    v_financial_status := 'pending';   -- stays pending until delivered
  ELSE
    -- Mobile money (orange/mtn): order pending until webhook fires
    v_order_status     := 'pending';
    v_financial_status := 'pending';
  END IF;

  -- ── 2. Insert each vendor group's order atomically ───────────────────────────
  FOR v_order_index IN 0 .. jsonb_array_length(p_orders) - 1 LOOP
    v_order_data := p_orders -> v_order_index;

    INSERT INTO public.orders (
      user_id,
      store_id,
      vendor_id,
      customer_name,
      items_count,
      total_amount,
      delivery_fee,
      vendor_delivery_fee,
      status,
      financial_status,
      payment_method,
      tracking_number,
      delivery_otp,
      shipping_address
    ) VALUES (
      p_user_id,
      NULLIF((v_order_data->>'store_id'),  '')::UUID,
      NULLIF((v_order_data->>'vendor_id'), '')::UUID,
      v_order_data->>'customer_name',
      (v_order_data->>'items_count')::INT,
      (v_order_data->>'total_amount')::NUMERIC,
      COALESCE((v_order_data->>'delivery_fee')::NUMERIC, 0),
      COALESCE((v_order_data->'shipping_address'->>'vendor_delivery_fee')::NUMERIC, 0),
      v_order_status,
      v_financial_status,
      p_payment_method,                        -- top-level column, not buried in JSON
      v_order_data->>'tracking_number',
      v_order_data->>'delivery_otp',
      v_order_data->'shipping_address'
    )
    RETURNING id INTO v_new_order_id;

    -- Accumulate result
    v_result := v_result || jsonb_build_object(
      'id',              v_new_order_id,
      'tracking_number', v_order_data->>'tracking_number'
    );

    -- ── 2a. Insert delivery record ────────────────────────────────────────────
    IF p_deliveries IS NOT NULL
       AND jsonb_array_length(p_deliveries) > v_order_index
    THEN
      v_delivery_data := p_deliveries -> v_order_index;
      IF v_delivery_data IS NOT NULL
         AND jsonb_typeof(v_delivery_data) = 'object'
      THEN
        INSERT INTO public.deliveries (
          order_id, status, current_location
        ) VALUES (
          v_new_order_id,
          COALESCE(v_delivery_data->>'status', 'pending'),
          v_delivery_data->'current_location'
        );
      END IF;
    END IF;

    -- ── 2b. Insert order items ────────────────────────────────────────────────
    IF p_order_items IS NOT NULL
       AND jsonb_array_length(p_order_items) > v_order_index
    THEN
      FOR v_item_data IN
        SELECT * FROM jsonb_array_elements(p_order_items -> v_order_index)
      LOOP
        INSERT INTO public.order_items (
          order_id,
          product_id,
          quantity,
          price_at_purchase,
          selected_variations
        ) VALUES (
          v_new_order_id,
          (v_item_data->>'product_id')::UUID,
          (v_item_data->>'quantity')::INT,
          (v_item_data->>'price_at_purchase')::NUMERIC,
          COALESCE(v_item_data->'selected_variations', '{}'::jsonb)
        );
      END LOOP;
    END IF;

  END LOOP;

  RETURN v_result;

EXCEPTION
  WHEN OTHERS THEN
    -- Re-raise so the caller sees the error and Postgres rolls back the whole block
    RAISE;
END;
$$;

-- Authenticated users (buyers) can call this RPC
GRANT EXECUTE ON FUNCTION public.process_cart_checkout(UUID, TEXT, JSONB, JSONB, JSONB)
  TO authenticated;

NOTIFY pgrst, 'reload schema';
