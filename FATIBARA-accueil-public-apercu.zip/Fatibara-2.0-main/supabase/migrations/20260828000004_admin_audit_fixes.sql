-- ==============================================================================
-- MIGRATION: 20260828000004_admin_audit_fixes.sql
-- Fatibara 2.0 — Admin Portal Audit Remediation
-- Date: 2026-08-28
--
-- FIXES:
--
--   [A-3] HIGH — reject_withdrawal refunds store/profile balance but never
--         inserts a wallet_transactions row. Rejection reversals are invisible
--         in the financial ledger, making reconciliation impossible.
--         Fix: Add 'payout_refund' to wallet_transactions.type CHECK constraint
--         and insert audit rows on both vendor and courier rejections.
--         Also: sync courier_profiles.balance on courier withdrawal rejection.
--
--   [A-1-DB] HIGH — courier_profiles.status is never synced when admin changes
--         courier_status via profiles.courier_status. Add a trigger that mirrors
--         the admin toggle into courier_profiles.status using a canonical map.
-- ==============================================================================

-- ==============================================================================
-- FIX A-3: Add 'payout_refund' to wallet_transactions.type CHECK + update
--           reject_withdrawal to insert audit row and sync courier_profiles.balance
-- ==============================================================================

-- Step 1: Add payout_refund to the type CHECK constraint (idempotent)
DO $$
BEGIN
  -- Drop old constraint and recreate with new value
  ALTER TABLE public.wallet_transactions DROP CONSTRAINT IF EXISTS wallet_transactions_type_check;
  ALTER TABLE public.wallet_transactions
    ADD CONSTRAINT wallet_transactions_type_check
    CHECK (type IN (
      'topup', 'deposit', 'withdrawal', 'delivery_fee', 'sale', 'fee',
      'commission', 'refund', 'payout_refund', 'tip', 'bonus', 'adjustment'
    ));
EXCEPTION WHEN OTHERS THEN
  RAISE NOTICE 'wallet_transactions type constraint update: %', SQLERRM;
END $$;

-- Step 2: Replace reject_withdrawal with an updated version that:
--   1. Refunds store.balance (vendor) OR profiles.wallet_balance (courier/user)
--   2. ALSO syncs courier_profiles.balance for courier rejections
--   3. Inserts a wallet_transactions row for audit trail
DROP FUNCTION IF EXISTS public.reject_withdrawal(UUID, TEXT) CASCADE;

CREATE OR REPLACE FUNCTION public.reject_withdrawal(
  p_withdrawal_id UUID,
  p_reason        TEXT DEFAULT 'Demande rejetée par l''administrateur'
)
RETURNS BOOLEAN
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_w public.withdrawals%ROWTYPE;
BEGIN
  -- Admin-only guard
  IF NOT EXISTS (
    SELECT 1 FROM public.profiles WHERE id = auth.uid() AND is_admin = true
  ) THEN
    RAISE EXCEPTION 'Unauthorized: admin role required';
  END IF;

  SELECT * INTO v_w FROM public.withdrawals WHERE id = p_withdrawal_id AND status = 'pending';
  IF NOT FOUND THEN
    RETURN FALSE;
  END IF;

  -- ── Vendor refund ────────────────────────────────────────────────────────────
  IF v_w.store_id IS NOT NULL THEN
    UPDATE public.stores
    SET balance = balance + v_w.amount
    WHERE id = v_w.store_id;

    -- Audit trail: vendor payout reversal
    INSERT INTO public.wallet_transactions
        (profile_id, store_id, amount, type, reference_id, description, status)
    VALUES (
        v_w.profile_id,
        v_w.store_id,
        v_w.amount,
        'payout_refund',
        p_withdrawal_id,
        'Retrait rejeté — remboursement boutique. Raison : ' || p_reason,
        'completed'
    );
  END IF;

  -- ── Courier / user refund ────────────────────────────────────────────────────
  IF v_w.profile_id IS NOT NULL AND v_w.type IN ('courier', 'user') THEN
    -- Refund profiles.wallet_balance
    UPDATE public.profiles
    SET wallet_balance = COALESCE(wallet_balance, 0) + v_w.amount
    WHERE id = v_w.profile_id;

    -- Also sync courier_profiles.balance for couriers
    IF v_w.type = 'courier' THEN
      UPDATE public.courier_profiles
      SET balance = COALESCE(balance, 0) + v_w.amount
      WHERE user_id = v_w.profile_id;
    END IF;

    -- Audit trail: user/courier payout reversal
    INSERT INTO public.wallet_transactions
        (profile_id, amount, type, reference_id, description, status)
    VALUES (
        v_w.profile_id,
        v_w.amount,
        'payout_refund',
        p_withdrawal_id,
        'Retrait rejeté — remboursement portefeuille. Raison : ' || p_reason,
        'completed'
    );
  END IF;

  -- Mark as rejected
  UPDATE public.withdrawals
  SET status           = 'rejected',
      rejection_reason = p_reason,
      processed_at     = NOW(),
      processed_by     = auth.uid()
  WHERE id = p_withdrawal_id;

  RETURN TRUE;
END;
$$;

GRANT EXECUTE ON FUNCTION public.reject_withdrawal(UUID, TEXT) TO authenticated;

-- ==============================================================================
-- FIX A-1-DB: Trigger to sync courier_profiles.status when profiles.courier_status
--             is updated by admin (bridges the two status systems)
-- ==============================================================================
-- Canonical mapping:
--   profiles.courier_status  →  courier_profiles.status
--   'disponible' / 'active' / 'approved'  → 'active'
--   'inactive' / 'hors_ligne'             → 'inactive'
--   'suspendu' / 'suspended'              → 'suspended'
--   'en_course' / 'on_delivery'           → 'active'  (still eligible for missions)
--   NULL                                   → 'inactive'

CREATE OR REPLACE FUNCTION public.sync_courier_profile_status()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_canonical_status TEXT;
BEGIN
  -- Only fire for courier profiles
  IF NEW.profile_type != 'courier' THEN
    RETURN NEW;
  END IF;

  -- Map legacy courier_status to canonical courier_profiles.status
  v_canonical_status := CASE COALESCE(NEW.courier_status, 'hors_ligne')
    WHEN 'disponible'    THEN 'active'
    WHEN 'active'        THEN 'active'
    WHEN 'approved'      THEN 'active'
    WHEN 'en_course'     THEN 'active'
    WHEN 'on_delivery'   THEN 'active'
    WHEN 'hors_ligne'    THEN 'inactive'
    WHEN 'inactive'      THEN 'inactive'
    WHEN 'suspendu'      THEN 'suspended'
    WHEN 'suspended'     THEN 'suspended'
    ELSE 'inactive'
  END;

  -- Upsert courier_profiles row with the synced status + default capacity
  INSERT INTO public.courier_profiles (user_id, status, active_capacity, balance)
  VALUES (NEW.id, v_canonical_status, 1, 0)
  ON CONFLICT (user_id) DO UPDATE
    SET status = EXCLUDED.status;

  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_sync_courier_profile_status ON public.profiles;
CREATE TRIGGER trg_sync_courier_profile_status
  AFTER UPDATE OF courier_status, profile_type ON public.profiles
  FOR EACH ROW
  WHEN (NEW.profile_type = 'courier')
  EXECUTE FUNCTION public.sync_courier_profile_status();

-- Backfill: sync existing couriers that already have a courier_status
-- but no courier_profiles row (or a stale status)
INSERT INTO public.courier_profiles (user_id, status, active_capacity, balance)
SELECT
  p.id,
  CASE COALESCE(p.courier_status, 'hors_ligne')
    WHEN 'disponible'  THEN 'active'
    WHEN 'active'      THEN 'active'
    WHEN 'approved'    THEN 'active'
    WHEN 'en_course'   THEN 'active'
    WHEN 'on_delivery' THEN 'active'
    WHEN 'hors_ligne'  THEN 'inactive'
    WHEN 'inactive'    THEN 'inactive'
    WHEN 'suspendu'    THEN 'suspended'
    WHEN 'suspended'   THEN 'suspended'
    ELSE 'inactive'
  END,
  1,  -- default active_capacity
  0   -- default balance (will be reconciled from wallet_transactions)
FROM public.profiles p
WHERE p.profile_type = 'courier'
ON CONFLICT (user_id) DO UPDATE
  SET status = EXCLUDED.status;

-- ==============================================================================
-- VERIFY: Sanity counts
-- ==============================================================================
DO $$
DECLARE
  v_synced   INTEGER;
  v_refunds  INTEGER;
BEGIN
  SELECT COUNT(*) INTO v_synced
  FROM public.courier_profiles cp
  JOIN public.profiles p ON cp.user_id = p.id
  WHERE p.profile_type = 'courier';

  SELECT COUNT(*) INTO v_refunds
  FROM public.wallet_transactions
  WHERE type = 'payout_refund';

  RAISE NOTICE '[A-1] courier_profiles rows synced: %', v_synced;
  RAISE NOTICE '[A-3] payout_refund wallet_transactions rows: %', v_refunds;
END $$;

NOTIFY pgrst, 'reload schema';
