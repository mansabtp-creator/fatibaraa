-- =============================================================================
-- Migration: Fix table grants for tables added in Phase 2/3 migrations
-- File:      20260728000003_fix_new_table_grants.sql
-- Created:   2026-07-28
--
-- ROOT CAUSE:
--   Same as 20260721000004_fix_table_grants.sql — Supabase Local does not
--   auto-grant SELECT/INSERT/UPDATE/DELETE to anon/authenticated/service_role
--   for new tables. The following tables were added in Phase 2/3 migrations
--   and are missing their grants:
--     - content_reports       (20260723000001)
--     - push_subscriptions    (20260723000004)
--     - withdrawals           (20260728000001)
--     - announcements         (20260728000002)
--   Additionally, vendor_invitations was added in 20260723000003.
--
-- SECURITY NOTE:
--   Grants here are the MINIMUM needed to reach RLS evaluation.
--   The actual access control is enforced by each table's RLS policies.
-- =============================================================================

-- ── Content Reports ───────────────────────────────────────────────────────────
-- Authenticated users can insert their own reports (RLS enforced).
-- Only admins can read all reports (via RLS). Anon cannot write.
GRANT SELECT, INSERT           ON public.content_reports    TO authenticated;
GRANT SELECT                   ON public.content_reports    TO service_role;

-- ── Push Subscriptions ────────────────────────────────────────────────────────
-- Authenticated users manage their own device subscriptions (RLS enforced).
GRANT SELECT, INSERT, UPDATE, DELETE ON public.push_subscriptions TO authenticated;
GRANT SELECT, DELETE           ON public.push_subscriptions TO service_role;

-- ── Withdrawals ───────────────────────────────────────────────────────────────
-- Authenticated users can view their own withdrawal requests (RLS enforced).
-- Inserts only via SECURITY DEFINER RPCs (request_vendor_withdrawal / request_user_withdrawal).
-- Admin approval/rejection via approve_withdrawal / reject_withdrawal RPCs.
GRANT SELECT                   ON public.withdrawals        TO authenticated;
GRANT SELECT, INSERT, UPDATE   ON public.withdrawals        TO service_role;

-- ── Announcements ─────────────────────────────────────────────────────────────
-- Anon and authenticated can read active announcements (RLS enforced).
-- Only admins can insert/update/delete (RLS enforced).
GRANT SELECT                   ON public.announcements      TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.announcements TO authenticated;

-- ── Vendor Invitations ────────────────────────────────────────────────────────
-- Admin-only writes, authenticated reads (RLS enforced).
GRANT SELECT                   ON public.vendor_invitations TO authenticated;
GRANT SELECT, INSERT, UPDATE   ON public.vendor_invitations TO service_role;

-- ── Ensure service_role bypasses RLS as expected ─────────────────────────────
-- service_role already bypasses RLS in Supabase by default, but explicit
-- grants are needed for PostgREST to allow queries to reach the RLS engine.
GRANT SELECT, INSERT, UPDATE, DELETE ON public.content_reports    TO service_role;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.push_subscriptions TO service_role;

-- ── Sequence grants ───────────────────────────────────────────────────────────
GRANT USAGE ON ALL SEQUENCES IN SCHEMA public TO authenticated;
GRANT USAGE ON ALL SEQUENCES IN SCHEMA public TO anon;

-- ── Notify PostgREST to reload schema cache ───────────────────────────────────
NOTIFY pgrst, 'reload schema';
