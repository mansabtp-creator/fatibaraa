-- =============================================================================
-- Migration: Wallet Realtime, Topup Hardening & Withdrawal Audit Trail
-- Created At: 2026-08-13
--
-- Changes:
--   1. Enable Supabase Realtime publication on `profiles` and
--      `wallet_transactions` so the frontend can receive live balance updates
--      without polling.
--
--   2. Patch `request_user_withdrawal` RPC to INSERT a `wallet_transactions`
--      row (type='withdrawal', status='pending') so courier/user withdrawal
--      history appears in the ledger. Previously only vendor withdrawals
--      had an audit trail.
--
--   3. Add ON CONFLICT DO NOTHING guard to topup wallet_transactions INSERT
--      in case the callback fires twice (idempotency hardening).
-- =============================================================================

-- ── 1. Enable Realtime on key tables ─────────────────────────────────────────
-- Supabase's postgres_changes subscription requires the table to be present
-- in the `supabase_realtime` publication.  Adding idempotently via DO block.

DO $$
BEGIN
  -- profiles: needed for live wallet_balance updates in CourierDashboardPage
  IF NOT EXISTS (
    SELECT 1
    FROM pg_publication_tables
    WHERE pubname = 'supabase_realtime'
      AND schemaname = 'public'
      AND tablename = 'profiles'
  ) THEN
    ALTER PUBLICATION supabase_realtime ADD TABLE public.profiles;
    RAISE NOTICE 'Added public.profiles to supabase_realtime publication.';
  ELSE
    RAISE NOTICE 'public.profiles already in supabase_realtime publication — skipped.';
  END IF;
END $$;

DO $$
BEGIN
  -- wallet_transactions: needed for live ledger updates
  IF NOT EXISTS (
    SELECT 1
    FROM pg_publication_tables
    WHERE pubname = 'supabase_realtime'
      AND schemaname = 'public'
      AND tablename = 'wallet_transactions'
  ) THEN
    ALTER PUBLICATION supabase_realtime ADD TABLE public.wallet_transactions;
    RAISE NOTICE 'Added public.wallet_transactions to supabase_realtime publication.';
  ELSE
    RAISE NOTICE 'public.wallet_transactions already in supabase_realtime publication — skipped.';
  END IF;
END $$;

-- ── 2. Patch request_user_withdrawal to log withdrawal in wallet_transactions ─
-- Drop and recreate to add the missing INSERT.
DROP FUNCTION IF EXISTS public.request_user_withdrawal(NUMERIC, TEXT, TEXT) CASCADE;
CREATE OR REPLACE FUNCTION public.request_user_withdrawal(
  p_amount  NUMERIC,
  p_method  TEXT DEFAULT 'orange_money',
  p_phone   TEXT DEFAULT NULL
)
RETURNS UUID
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_profile       public.profiles%ROWTYPE;
  v_withdrawal_id UUID;
  v_min_amount    NUMERIC := 20000; -- 20 000 GNF minimum for couriers/users
BEGIN
  SELECT * INTO v_profile FROM public.profiles WHERE id = auth.uid();
  IF NOT FOUND THEN
    RAISE EXCEPTION 'Profile not found';
  END IF;

  IF p_amount < v_min_amount THEN
    RAISE EXCEPTION 'Le montant minimum de retrait est de % GNF', v_min_amount;
  END IF;

  IF COALESCE(v_profile.wallet_balance, 0) < p_amount THEN
    RAISE EXCEPTION 'Solde insuffisant. Disponible: % GNF', COALESCE(v_profile.wallet_balance, 0);
  END IF;

  -- Lock funds immediately (atomic deduction)
  UPDATE public.profiles
  SET wallet_balance = wallet_balance - p_amount
  WHERE id = auth.uid();

  -- Determine role for withdrawal type
  INSERT INTO public.withdrawals (profile_id, amount, method, phone, type)
  VALUES (
    auth.uid(),
    p_amount,
    p_method,
    p_phone,
    CASE WHEN v_profile.profile_type = 'courier' THEN 'courier' ELSE 'user' END
  )
  RETURNING id INTO v_withdrawal_id;

  -- ── AUDIT TRAIL (previously missing for courier/user withdrawals) ──────────
  -- Negative amount = money leaving the wallet. status='pending' until admin
  -- approves, at which point a 'withdrawal_approved' tx can be appended.
  INSERT INTO public.wallet_transactions (
    profile_id,
    amount,
    type,
    status,
    description,
    reference_id
  )
  VALUES (
    auth.uid(),
    -p_amount,    -- negative: funds deducted from balance
    'withdrawal',
    'pending',
    'Demande de retrait — ' || p_method || ' — ' || p_phone,
    v_withdrawal_id::TEXT
  )
  ON CONFLICT DO NOTHING;

  RETURN v_withdrawal_id;
END;
$$;

GRANT EXECUTE ON FUNCTION public.request_user_withdrawal(NUMERIC, TEXT, TEXT) TO authenticated;

-- ── 3. Refresh PostgREST schema cache ─────────────────────────────────────────
NOTIFY pgrst, 'reload schema';
