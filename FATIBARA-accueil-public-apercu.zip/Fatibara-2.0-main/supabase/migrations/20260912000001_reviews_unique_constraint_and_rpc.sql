-- Migration: enforce one review per (order, user) pair on the reviews table
-- and handle the conflict gracefully so duplicate submissions return a 
-- meaningful error code (23505) instead of silently inserting a second row.
--
-- Also awards loyalty points only on the FIRST review via a DB-level guard,
-- so the +50 pts cannot be farmed by re-submitting the same review.

-- 1. Add a unique constraint on (order_id, user_id).
--    `IF NOT EXISTS` is not supported for constraints, so we guard with a 
--    DO block that checks pg_constraint first.
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint 
    WHERE conname = 'reviews_one_per_order_user'
  ) THEN
    ALTER TABLE reviews
      ADD CONSTRAINT reviews_one_per_order_user UNIQUE (order_id, user_id);
  END IF;
END $$;

-- 2. Add an index to speed up the duplicate check query 
--    (the unique constraint already creates one, but be explicit for clarity).
CREATE INDEX IF NOT EXISTS idx_reviews_order_user ON reviews (order_id, user_id);

-- 3. Add a helper function that the ReviewModal can call instead of a raw insert.
--    Returns the review row on success, or raises a unique-violation so the
--    client can detect code 23505 and show a friendly "already reviewed" message.
CREATE OR REPLACE FUNCTION submit_review(
  p_product_id  UUID,
  p_store_id    UUID,
  p_user_id     UUID,
  p_order_id    UUID,
  p_user_name   TEXT,
  p_rating      SMALLINT,
  p_comment     TEXT,
  p_location    TEXT DEFAULT 'Guinée',
  p_avatar_url  TEXT DEFAULT NULL
)
RETURNS reviews
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_review reviews;
BEGIN
  -- Ownership check: the calling user must own the order
  IF NOT EXISTS (
    SELECT 1 FROM orders
    WHERE id = p_order_id
      AND user_id = p_user_id
      AND status = 'delivered'
  ) THEN
    RAISE EXCEPTION 'Cette commande ne peut pas encore être évaluée.' USING ERRCODE = 'P0001';
  END IF;

  -- Insert — the UNIQUE constraint on (order_id, user_id) will raise 23505 
  -- if the user already reviewed this order.
  INSERT INTO reviews (
    product_id, store_id, user_id, order_id,
    user_name, rating, comment, location, avatar_url,
    is_verified_purchase
  )
  VALUES (
    p_product_id, p_store_id, p_user_id, p_order_id,
    p_user_name, p_rating, p_comment, p_location, p_avatar_url,
    true
  )
  RETURNING * INTO v_review;

  -- Award +50 loyalty points for first review only.
  -- This is safe here because the INSERT above would have raised 23505 on a duplicate.
  PERFORM increment_loyalty_points(p_user_id, 50);

  RETURN v_review;
END;
$$;

GRANT EXECUTE ON FUNCTION submit_review(UUID, UUID, UUID, UUID, TEXT, SMALLINT, TEXT, TEXT, TEXT) TO authenticated;
