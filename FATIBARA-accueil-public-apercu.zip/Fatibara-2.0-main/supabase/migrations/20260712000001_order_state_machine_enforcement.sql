ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS vendor_id uuid;
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS courier_id uuid;
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS vendor_id uuid;
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS courier_id uuid;
-- ==============================================================================
-- Migration: Order State Machine Enforcement (RLS Policies & Trigger Guards)
-- Created At: 2026-07-12T10:35:00Z
-- ==============================================================================

-- 1. Row Level Security (RLS) Policy Adjustments for Courier Claiming & Vendor Transitions

DROP POLICY IF EXISTS "Couriers can claim orders" ON public.orders;
DROP POLICY IF EXISTS "Vendors can transition order status" ON public.orders;

-- Policy for Courier updates (Claiming ready orders)
CREATE POLICY "Couriers can claim orders" 
ON public.orders 
FOR UPDATE 
USING (
  status = 'ready_for_pickup' 
  AND courier_id IS NULL
  AND EXISTS (
    SELECT 1 FROM public.profiles 
    WHERE id = auth.uid() 
    AND courier_status IS NOT NULL
  )
)
WITH CHECK (
  courier_id = auth.uid()
);

-- Policy for Vendor updates (Transitioning statuses)
CREATE POLICY "Vendors can transition order status"
ON public.orders
FOR UPDATE
USING (
  auth.uid() = vendor_id
)
WITH CHECK (
  auth.uid() = vendor_id
);

-- 2. Database Trigger Constraints (BEFORE UPDATE)

CREATE OR REPLACE FUNCTION public.enforce_order_state_machine_constraints()
RETURNS TRIGGER AS $$
BEGIN
  -- A. Courier Order Claiming Constraint
  -- Detect when a courier is assigning themselves (courier_id transitions from NULL to a value)
  IF NEW.courier_id IS NOT NULL AND OLD.courier_id IS NULL THEN
    -- The order must be exactly 'ready_for_pickup'
    IF OLD.status != 'ready_for_pickup' THEN
      RAISE EXCEPTION 'A courier can only claim an order that is ready for pickup. Current status is %', OLD.status;
    END IF;
  END IF;

  -- B. Vendor Status Transition Constraint
  -- Enforce that only the vendor (or courier during claiming / admin) can transition statuses
  IF OLD.status IS DISTINCT FROM NEW.status THEN
    IF auth.uid() IS DISTINCT FROM OLD.vendor_id AND auth.uid() IS DISTINCT FROM NEW.courier_id THEN
      -- Allow admin override
      IF NOT EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND is_admin = true) THEN
        RAISE EXCEPTION 'Only the assigned vendor can transition the order status.';
      END IF;
    END IF;
  END IF;

  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Attach trigger to public.orders table
DROP TRIGGER IF EXISTS trg_enforce_order_state_machine_constraints ON public.orders;
CREATE TRIGGER trg_enforce_order_state_machine_constraints
  BEFORE UPDATE ON public.orders
  FOR EACH ROW
  EXECUTE FUNCTION public.enforce_order_state_machine_constraints();

-- Reload PostgREST schema cache
NOTIFY pgrst, 'reload schema';
