-- ==============================================================================
-- MIGRATION: 20260829000002_rls_missing_tables.sql
-- Fatibara 2.0 — Enable RLS on 4 Previously Unprotected Tables
-- Date: 2026-08-29
--
-- Tables addressed (flagged by Supabase DB advisor as RLS-disabled):
--
--   [1] product_interactions  — tracks view/click events per user
--       Risk: any anon user could read every user's browsing behaviour.
--       Policies: anon/authenticated can INSERT (logging); owner can SELECT
--       their own rows; admins can SELECT all.
--
--   [2] product_verifications — admin-created "Original Garanti" records
--       Risk: anyone could read or write verification records.
--       Policies: public can SELECT (product badge display); only admins
--       can INSERT/UPDATE/DELETE.
--
--   [3] store_follows — user → store follow relationship
--       Risk: any user could read or manipulate any other user's follows.
--       Policies: owner can SELECT/INSERT/DELETE their own rows; vendors
--       can see who follows their stores; admins can SELECT all.
--
--   [4] vendor_invitations — admin-issued invitation tokens
--       Risk: anyone with the anon key could list all pending tokens,
--       potentially creating unauthorised vendor accounts.
--       Policies: only admins can manage (full); any authenticated user
--       can SELECT a specific token by token value (claim flow).
--
-- ==============================================================================

-- ==============================================================================
-- 1. product_interactions
-- ==============================================================================
ALTER TABLE public.product_interactions ENABLE ROW LEVEL SECURITY;

-- Anyone (including anon) can INSERT an interaction (view/click tracking)
DROP POLICY IF EXISTS "pi_insert_any" ON public.product_interactions;
CREATE POLICY "pi_insert_any"
ON public.product_interactions FOR INSERT
WITH CHECK (true);

-- Users can SELECT their own interaction history
DROP POLICY IF EXISTS "pi_select_own" ON public.product_interactions;
CREATE POLICY "pi_select_own"
ON public.product_interactions FOR SELECT TO authenticated
USING (user_id = auth.uid() OR public.is_admin());

-- Admins can SELECT all (for analytics)
DROP POLICY IF EXISTS "pi_select_admin" ON public.product_interactions;
CREATE POLICY "pi_select_admin"
ON public.product_interactions FOR SELECT TO authenticated
USING (public.is_admin());

-- No direct UPDATE/DELETE for regular users (immutable event log)
DROP POLICY IF EXISTS "pi_admin_all" ON public.product_interactions;
CREATE POLICY "pi_admin_all"
ON public.product_interactions FOR ALL TO authenticated
USING (public.is_admin())
WITH CHECK (public.is_admin());

-- ==============================================================================
-- 2. product_verifications
-- ==============================================================================
ALTER TABLE public.product_verifications ENABLE ROW LEVEL SECURITY;

-- Anyone can SELECT (needed to display "Original Garanti" badges on product pages)
DROP POLICY IF EXISTS "pv_select_public" ON public.product_verifications;
CREATE POLICY "pv_select_public"
ON public.product_verifications FOR SELECT
USING (true);

-- Only admins can create, update, or remove verifications
DROP POLICY IF EXISTS "pv_admin_write" ON public.product_verifications;
CREATE POLICY "pv_admin_write"
ON public.product_verifications FOR ALL TO authenticated
USING (public.is_admin())
WITH CHECK (public.is_admin());

-- ==============================================================================
-- 3. store_follows
-- ==============================================================================
ALTER TABLE public.store_follows ENABLE ROW LEVEL SECURITY;

-- Users can see their own follows
DROP POLICY IF EXISTS "sf_select_own" ON public.store_follows;
CREATE POLICY "sf_select_own"
ON public.store_follows FOR SELECT TO authenticated
USING (follower_id = auth.uid());

-- Vendors can see who follows their stores
DROP POLICY IF EXISTS "sf_select_vendor" ON public.store_follows;
CREATE POLICY "sf_select_vendor"
ON public.store_follows FOR SELECT TO authenticated
USING (
  store_id IN (
    SELECT id FROM public.stores WHERE owner_id = auth.uid()
  )
);

-- Admins can see all follows
DROP POLICY IF EXISTS "sf_select_admin" ON public.store_follows;
CREATE POLICY "sf_select_admin"
ON public.store_follows FOR SELECT TO authenticated
USING (public.is_admin());

-- Users can follow a store (INSERT their own row only)
DROP POLICY IF EXISTS "sf_insert_own" ON public.store_follows;
CREATE POLICY "sf_insert_own"
ON public.store_follows FOR INSERT TO authenticated
WITH CHECK (follower_id = auth.uid());

-- Users can unfollow (DELETE their own row only)
DROP POLICY IF EXISTS "sf_delete_own" ON public.store_follows;
CREATE POLICY "sf_delete_own"
ON public.store_follows FOR DELETE TO authenticated
USING (follower_id = auth.uid());

-- ==============================================================================
-- 4. vendor_invitations
-- ==============================================================================
ALTER TABLE public.vendor_invitations ENABLE ROW LEVEL SECURITY;

-- Admin full control (create, revoke, list all)
DROP POLICY IF EXISTS "vi_admin_all" ON public.vendor_invitations;
CREATE POLICY "vi_admin_all"
ON public.vendor_invitations FOR ALL TO authenticated
USING (public.is_admin())
WITH CHECK (public.is_admin());

-- Any authenticated user can SELECT a specific invitation by token value.
-- This allows the claim flow (reading the invite details before signing up)
-- without exposing the full list of tokens to non-admins.
DROP POLICY IF EXISTS "vi_select_by_token" ON public.vendor_invitations;
CREATE POLICY "vi_select_by_token"
ON public.vendor_invitations FOR SELECT TO authenticated
USING (
  -- Only the row matching the claimed token is visible — no full-table scan
  id IN (
    SELECT id FROM public.vendor_invitations
    WHERE is_revoked = false
      AND expires_at > NOW()
  )
  AND public.is_admin() = false  -- admins covered by vi_admin_all above
);

-- Anon can also look up a specific token during the pre-signup claim flow
DROP POLICY IF EXISTS "vi_anon_select_by_token" ON public.vendor_invitations;
CREATE POLICY "vi_anon_select_by_token"
ON public.vendor_invitations FOR SELECT TO anon
USING (
  is_revoked = false
  AND expires_at > NOW()
);

-- ==============================================================================
-- Reload PostgREST schema cache
-- ==============================================================================
NOTIFY pgrst, 'reload schema';
