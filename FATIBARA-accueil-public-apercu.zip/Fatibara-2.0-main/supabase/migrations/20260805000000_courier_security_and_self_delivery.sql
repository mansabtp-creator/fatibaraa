-- =============================================================================
-- Migration: Courier Security Validation & Vendor Self-Delivery (Marchand-Livreur)
-- Created At: 2026-08-05
--
-- Changes:
--   1. Enforce security fields on courier profiles (phone_number, license_plate_number,
--      vehicle_type). These are SEPARATE from the existing `phone` and `full_name`
--      profile columns — they are courier-specific operational fields.
--
--   2. Add Vendor Self-Delivery settings to stores (allows_self_delivery toggle +
--      optional default internal rider pre-fill).
--
--   3. Add fulfillment tracking to orders (fulfillment_type, self_delivery_driver_*
--      fields). NOTE: delivery_otp already exists — NOT re-added here.
--
--   4. Refresh PostgREST schema cache.
-- =============================================================================

-- ── 1. Courier security fields on profiles ────────────────────────────────────
--    phone_number      : courier-specific contact (may differ from profile phone)
--    license_plate_number : motorcycle / vehicle plate — REQUIRED before going active
--    vehicle_type      : vehicle category for dispatch optimization

ALTER TABLE public.profiles
  ADD COLUMN IF NOT EXISTS phone_number         TEXT,
  ADD COLUMN IF NOT EXISTS license_plate_number TEXT,
  ADD COLUMN IF NOT EXISTS vehicle_type         TEXT DEFAULT 'motorcycle'
    CHECK (vehicle_type IN ('motorcycle', 'car', 'bicycle', 'foot'));

-- ── 2. Vendor Self-Delivery settings on stores ───────────────────────────────
--    allows_self_delivery   : store-level toggle (vendor delivers with own rider)
--    internal_driver_name   : pre-filled default rider name for this store
--    internal_driver_phone  : pre-filled default rider phone
--    internal_driver_plate  : pre-filled default rider plate

ALTER TABLE public.stores
  ADD COLUMN IF NOT EXISTS allows_self_delivery BOOLEAN DEFAULT TRUE,
  ADD COLUMN IF NOT EXISTS internal_driver_name  TEXT,
  ADD COLUMN IF NOT EXISTS internal_driver_phone TEXT,
  ADD COLUMN IF NOT EXISTS internal_driver_plate TEXT;

-- ── 3. Fulfillment tracking on orders ────────────────────────────────────────
--    fulfillment_type              : how this order will be delivered
--    self_delivery_driver_name     : actual rider (may differ from store default)
--    self_delivery_driver_phone    : actual rider phone
--    self_delivery_driver_plate    : actual rider plate (shown on buyer tracking)
--
--    NOTE: delivery_otp VARCHAR(4) already exists from migration
--    20260713000001_orders_logistics_columns_and_cache_bust.sql — do NOT re-add.

ALTER TABLE public.orders
  ADD COLUMN IF NOT EXISTS fulfillment_type TEXT DEFAULT 'fatibara_courier'
    CHECK (fulfillment_type IN ('fatibara_courier', 'vendor_self_delivery', 'pickup')),
  ADD COLUMN IF NOT EXISTS self_delivery_driver_name  TEXT,
  ADD COLUMN IF NOT EXISTS self_delivery_driver_phone TEXT,
  ADD COLUMN IF NOT EXISTS self_delivery_driver_plate TEXT;

-- ── 4. Ensure vendors can UPDATE the new fulfillment columns ─────────────────
--    The existing flat UPDATE policy for vendors covers `status` transitions.
--    We rebuild it here to ensure the new columns are writable by vendors.
--    (Policy already exists from 20260714000002 — we DROP + RECREATE with same
--     logic to stay idempotent and avoid silent column-level permission gaps.)

DO $$
BEGIN
  -- Only rebuild if the policy already exists (idempotency)
  IF EXISTS (
    SELECT 1 FROM pg_policies
    WHERE schemaname = 'public'
      AND tablename  = 'orders'
      AND policyname = 'Fatibara flat orders update policy'
  ) THEN
    DROP POLICY "Fatibara flat orders update policy" ON public.orders;
  END IF;
END
$$;

CREATE POLICY "Fatibara flat orders update policy"
ON public.orders
FOR UPDATE
TO authenticated
USING (
  -- Vendor owns this order directly
  auth.uid() = vendor_id
  -- Vendor owns the store that fulfills the order (store_id fallback)
  OR EXISTS (
    SELECT 1 FROM public.stores
    WHERE public.stores.id = orders.store_id
      AND public.stores.owner_id = auth.uid()
  )
  -- Assigned courier can update delivery fields
  OR auth.uid() = courier_id
)
WITH CHECK (
  -- Same conditions on the post-update row
  auth.uid() = vendor_id
  OR EXISTS (
    SELECT 1 FROM public.stores
    WHERE public.stores.id = orders.store_id
      AND public.stores.owner_id = auth.uid()
  )
  OR auth.uid() = courier_id
);

-- ── 5. Indexes for new lookup patterns ───────────────────────────────────────
CREATE INDEX IF NOT EXISTS idx_orders_fulfillment_type
  ON public.orders (fulfillment_type);

CREATE INDEX IF NOT EXISTS idx_profiles_license_plate
  ON public.profiles (license_plate_number)
  WHERE license_plate_number IS NOT NULL;

-- ── 6. Refresh PostgREST schema cache ────────────────────────────────────────
NOTIFY pgrst, 'reload schema';
