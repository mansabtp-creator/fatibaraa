-- Migration: Admin RPC to refresh trending_products_mv
-- Allows the admin dashboard to trigger a materialized view refresh
-- with a single button click, without needing direct DB access.

CREATE OR REPLACE FUNCTION public.refresh_trending_products_mv()
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  -- Admin-only guard
  IF NOT EXISTS (
    SELECT 1 FROM public.profiles
    WHERE id = auth.uid() AND is_admin = true
  ) THEN
    RAISE EXCEPTION 'Permission denied: admin only';
  END IF;

  REFRESH MATERIALIZED VIEW public.trending_products_mv;
END;
$$;

GRANT EXECUTE ON FUNCTION public.refresh_trending_products_mv() TO authenticated;
