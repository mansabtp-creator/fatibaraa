-- Migration: Clean single-signature public.request_vendor_withdrawal RPC supporting all parameter styles
-- Created: 2026-09-28

-- Drop any existing versions to avoid function signature conflicts
DROP FUNCTION IF EXISTS public.request_vendor_withdrawal CASCADE;

CREATE OR REPLACE FUNCTION public.request_vendor_withdrawal(
  store_id        UUID DEFAULT NULL,
  amount          NUMERIC DEFAULT NULL,
  method          TEXT DEFAULT 'orange_money',
  phone           TEXT DEFAULT NULL,
  phone_number    TEXT DEFAULT NULL,
  p_store_id      UUID DEFAULT NULL,
  p_amount        NUMERIC DEFAULT NULL,
  p_method        TEXT DEFAULT NULL,
  p_phone         TEXT DEFAULT NULL,
  p_phone_number  TEXT DEFAULT NULL
)
RETURNS UUID
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_effective_store_id UUID := COALESCE(store_id, p_store_id);
  v_effective_amount   NUMERIC := COALESCE(amount, p_amount);
  v_effective_method   TEXT := COALESCE(method, p_method, 'orange_money');
  v_effective_phone    TEXT := COALESCE(phone_number, phone, p_phone_number, p_phone);
  v_store              public.stores%ROWTYPE;
  v_withdrawal_id      UUID;
  v_min_amount         NUMERIC := 50000; -- 50,000 GNF minimum
BEGIN
  IF v_effective_store_id IS NULL THEN
    RAISE EXCEPTION 'store_id is required';
  END IF;

  IF v_effective_amount IS NULL THEN
    RAISE EXCEPTION 'amount is required';
  END IF;

  -- Ownership check
  SELECT * INTO v_store FROM public.stores WHERE id = v_effective_store_id AND owner_id = auth.uid();
  IF NOT FOUND THEN
    RAISE EXCEPTION 'Unauthorized: store not found or not owned by caller';
  END IF;

  IF NOT COALESCE(v_store.is_verified_store, false) THEN
    RAISE EXCEPTION 'Unverified stores cannot request withdrawals. Contact support.';
  END IF;

  IF v_effective_amount < v_min_amount THEN
    RAISE EXCEPTION 'Minimum withdrawal amount is % GNF', v_min_amount;
  END IF;

  IF (v_store.balance IS NULL OR v_store.balance < v_effective_amount) THEN
    RAISE EXCEPTION 'Solde insuffisant. Disponible: % GNF', COALESCE(v_store.balance, 0);
  END IF;

  -- Lock amount from store balance immediately
  UPDATE public.stores
  SET balance = balance - v_effective_amount
  WHERE id = v_effective_store_id;

  -- Create withdrawal record
  INSERT INTO public.withdrawals (store_id, profile_id, amount, method, phone, type)
  VALUES (v_effective_store_id, auth.uid(), v_effective_amount, v_effective_method, v_effective_phone, 'vendor')
  RETURNING id INTO v_withdrawal_id;

  -- Audit trail in wallet_transactions
  INSERT INTO public.wallet_transactions (profile_id, store_id, amount, type, description, reference_id)
  VALUES (auth.uid(), v_effective_store_id, -v_effective_amount, 'withdrawal', 'Demande de retrait en attente', v_withdrawal_id::TEXT)
  ON CONFLICT DO NOTHING;

  RETURN v_withdrawal_id;
END;
$$;

GRANT EXECUTE ON FUNCTION public.request_vendor_withdrawal TO authenticated;
GRANT EXECUTE ON FUNCTION public.request_vendor_withdrawal TO service_role;
