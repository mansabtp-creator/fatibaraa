-- Migration: content_reports table
-- Stores user-generated flags for products and stores.
-- Admin can review in AdminDashboardPage under a future "Reports" tab.
-- 
-- Created: 2026-07-23

CREATE TABLE IF NOT EXISTS public.content_reports (
  id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  reporter_id   UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  content_type  TEXT NOT NULL CHECK (content_type IN ('product', 'store')),
  content_id    UUID NOT NULL,
  reason        TEXT NOT NULL CHECK (reason IN (
    'fake_product',
    'wrong_price',
    'inappropriate_content',
    'spam',
    'counterfeit',
    'other'
  )),
  details       TEXT,
  status        TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'reviewed', 'dismissed')),
  created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  reviewed_at   TIMESTAMPTZ,
  reviewed_by   UUID REFERENCES auth.users(id) ON DELETE SET NULL
);

-- Indexes for admin query performance
CREATE INDEX IF NOT EXISTS idx_content_reports_status      ON public.content_reports (status);
CREATE INDEX IF NOT EXISTS idx_content_reports_content_type ON public.content_reports (content_type, content_id);
CREATE INDEX IF NOT EXISTS idx_content_reports_reporter     ON public.content_reports (reporter_id);

-- RLS: authenticated users can insert; admins can read/update
ALTER TABLE public.content_reports ENABLE ROW LEVEL SECURITY;

-- Any authenticated user can report content
DROP POLICY IF EXISTS "authenticated_can_insert_reports" ON public.content_reports;
CREATE POLICY "authenticated_can_insert_reports"
  ON public.content_reports
  FOR INSERT
  TO authenticated
  WITH CHECK (reporter_id = auth.uid());

-- Users can see their own reports
DROP POLICY IF EXISTS "users_can_read_own_reports" ON public.content_reports;
CREATE POLICY "users_can_read_own_reports"
  ON public.content_reports
  FOR SELECT
  TO authenticated
  USING (reporter_id = auth.uid());

-- Admins can read all reports
DROP POLICY IF EXISTS "admins_can_read_all_reports" ON public.content_reports;
CREATE POLICY "admins_can_read_all_reports"
  ON public.content_reports
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM public.profiles
      WHERE id = auth.uid() AND is_admin = true
    )
  );

-- Admins can update (mark reviewed/dismissed)
DROP POLICY IF EXISTS "admins_can_update_reports" ON public.content_reports;
CREATE POLICY "admins_can_update_reports"
  ON public.content_reports
  FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM public.profiles
      WHERE id = auth.uid() AND is_admin = true
    )
  );
