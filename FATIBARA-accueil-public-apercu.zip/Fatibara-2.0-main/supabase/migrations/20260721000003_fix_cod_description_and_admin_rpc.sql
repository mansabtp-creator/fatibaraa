-- ==============================================================================
-- Migration: Fix COD description + Admin force-settle RPC
-- File:      20260721000003_fix_cod_description_and_admin_rpc.sql
-- Created:   2026-07-21
-- Author:    Antigravity / Fatibara Engineering
--
-- CHANGES:
--   1. Update secure_process_order_financials:
--      Replace the misleading "Collecte Cash (Retenue: X)" description on
--      vendor transactions for COD orders-with-courier with the clearer:
--        "Vente Cash à la livraison (Commande #<short_id>)"
--
--   2. Expand platform_logs.type CHECK to include 'admin_cod_override'.
--
--   3. Add admin_force_settle_cod_order(p_order_id UUID):
--      SECURITY DEFINER RPC restricted to is_admin=true profiles.
--      Allows admins to manually finalize COD orders where the courier
--      had insufficient wallet balance at delivery time, leaving the
--      order in financial_status='pending'.
-- ==============================================================================

-- ── 1. Expand platform_logs.type CHECK ────────────────────────────────────────
-- Drop old constraint and re-add with 'admin_cod_override' included.
ALTER TABLE public.platform_logs
  DROP CONSTRAINT IF EXISTS platform_logs_type_check;

ALTER TABLE public.platform_logs
  ADD  CONSTRAINT platform_logs_type_check
  CHECK (type IN (
    'commission',
    'refund',
    'adjustment',
    'withdrawal',
    'system',
    'admin_cod_override'         -- ← new: manual admin COD settlements
  ));

-- ── 2. Update secure_process_order_financials ─────────────────────────────────
-- Full replacement with fixed COD-with-courier vendor description.
CREATE OR REPLACE FUNCTION public.secure_process_order_financials(p_order_id uuid)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
    v_order                        RECORD;
    v_store                        RECORD;
    v_existing_tx                  BOOLEAN;
    v_commission_str               TEXT;
    v_commission_rate              NUMERIC;
    v_items_real_value             NUMERIC;
    v_item_subtotal                NUMERIC;
    v_platform_commission          NUMERIC;
    v_vendor_payout                NUMERIC;
    v_courier_payout               NUMERIC;
    v_is_cash_payment              BOOLEAN;
    v_final_vendor_digital_change  NUMERIC;
    v_final_courier_digital_change NUMERIC;
    v_courier_balance              NUMERIC;
    v_vendor_description           TEXT;
BEGIN
    -- ── A. Lock order row ────────────────────────────────────────────────────
    SELECT * INTO v_order FROM public.orders WHERE id = p_order_id FOR UPDATE;
    IF NOT FOUND THEN RAISE EXCEPTION 'Order not found'; END IF;

    -- ── B. Idempotency guard ─────────────────────────────────────────────────
    IF v_order.financial_status = 'processed' THEN
        RETURN jsonb_build_object('success', true, 'alreadyProcessed', true);
    END IF;

    SELECT EXISTS (
        SELECT 1 FROM public.wallet_transactions
        WHERE reference_id = p_order_id AND type = 'sale'
    ) INTO v_existing_tx;

    IF v_existing_tx THEN
        UPDATE public.orders SET financial_status = 'processed' WHERE id = p_order_id;
        RETURN jsonb_build_object('success', true, 'alreadyProcessed', true);
    END IF;

    -- ── C. Resolve store ─────────────────────────────────────────────────────
    SELECT * INTO v_store FROM public.stores
    WHERE id = v_order.store_id
       OR (v_order.store_id IS NULL AND owner_id = v_order.vendor_id)
    LIMIT 1;

    -- ── D. Commission arithmetic ─────────────────────────────────────────────
    v_items_real_value := v_order.total_amount - COALESCE(v_order.delivery_fee, 0);

    SELECT value INTO v_commission_str FROM public.platform_settings WHERE id = 'commission_rate';
    IF v_commission_str IS NULL THEN v_commission_str := '5'; END IF;
    v_commission_rate := v_commission_str::numeric / 100.0;

    v_item_subtotal       := v_items_real_value / (1 + v_commission_rate);
    v_platform_commission := v_item_subtotal * v_commission_rate;
    v_vendor_payout       := v_item_subtotal - COALESCE(v_order.vendor_delivery_fee, 0);
    v_courier_payout      := (CASE WHEN COALESCE(v_order.delivery_fee, 0) > 0
                                   THEN v_order.delivery_fee
                                   ELSE COALESCE(v_order.vendor_delivery_fee, 0) END) * 0.8;

    IF v_order.courier_id IS NULL THEN
        v_vendor_payout := v_vendor_payout + v_courier_payout;
    END IF;

    v_is_cash_payment := COALESCE(
        (v_order.shipping_address->>'payment_method') = 'cash',
        v_order.financial_status != 'paid'
    );

    -- ── E. Vendor payout ─────────────────────────────────────────────────────
    IF v_store.id IS NOT NULL THEN
        v_final_vendor_digital_change := v_vendor_payout;

        -- COD with NO courier: vendor personally collected cash.
        -- Deduct total_amount from digital balance (platform withholds it).
        IF v_is_cash_payment AND v_order.courier_id IS NULL THEN
            v_final_vendor_digital_change := v_vendor_payout - v_order.total_amount;
        END IF;

        IF v_final_vendor_digital_change != 0 THEN
            UPDATE public.stores
            SET balance = COALESCE(balance, 0) + ROUND(v_final_vendor_digital_change)
            WHERE id = v_store.id;

            -- ── Build human-readable description ─────────────────────────────
            IF v_is_cash_payment AND v_order.courier_id IS NULL THEN
                -- Vendor collected cash directly — platform retains commission
                v_vendor_description :=
                    'Collecte Cash directe — Retenue commission Commande #'
                    || left(v_order.id::text, 8);
            ELSIF v_is_cash_payment AND v_order.courier_id IS NOT NULL THEN
                -- Courier collected cash on vendor's behalf; vendor gets payout digitally
                v_vendor_description :=
                    'Vente Cash à la livraison (Commande #'
                    || left(v_order.id::text, 8) || ')';
            ELSE
                -- Standard wallet / card payment
                v_vendor_description :=
                    'Vente #' || left(v_order.id::text, 8)
                    || ' (Payout ' || ROUND(v_item_subtotal) || ')';
            END IF;

            INSERT INTO public.wallet_transactions
              (profile_id, store_id, amount, type, reference_id, description)
            VALUES (
                v_order.vendor_id,
                v_store.id,
                v_final_vendor_digital_change,
                CASE WHEN v_final_vendor_digital_change > 0 THEN 'sale' ELSE 'fee' END,
                v_order.id,
                v_vendor_description
            );
        END IF;
    END IF;

    -- ── F. Courier payout — with COD negative-balance guard ──────────────────
    IF v_order.courier_id IS NOT NULL THEN
        v_final_courier_digital_change := v_courier_payout;
        IF v_is_cash_payment THEN
            -- COD: courier owes (total_amount - courier_payout) to the platform.
            v_final_courier_digital_change := v_courier_payout - v_order.total_amount;
        END IF;

        IF v_final_courier_digital_change != 0 THEN
            IF v_final_courier_digital_change < 0 THEN
                SELECT wallet_balance INTO v_courier_balance
                FROM public.profiles
                WHERE id = v_order.courier_id
                FOR UPDATE;

                IF v_courier_balance + v_final_courier_digital_change < 0 THEN
                    -- Insufficient courier balance — flag for manual admin settlement.
                    RETURN jsonb_build_object(
                        'success',        false,
                        'error',          'cod_courier_insufficient_balance',
                        'message',        format(
                            'Courier wallet too low for COD settlement. Balance: %s GNF, Required: %s GNF. Order flagged for manual collection.',
                            ROUND(v_courier_balance),
                            ROUND(abs(v_final_courier_digital_change))
                        ),
                        'courierBalance', ROUND(v_courier_balance),
                        'debtAmount',     ROUND(abs(v_final_courier_digital_change))
                    );
                END IF;
            END IF;

            UPDATE public.profiles
            SET wallet_balance = wallet_balance + ROUND(v_final_courier_digital_change)
            WHERE id = v_order.courier_id;

            INSERT INTO public.wallet_transactions
              (profile_id, amount, type, reference_id, description)
            VALUES (
                v_order.courier_id,
                v_final_courier_digital_change,
                CASE WHEN v_final_courier_digital_change > 0 THEN 'delivery_fee' ELSE 'fee' END,
                v_order.id,
                CASE WHEN v_is_cash_payment
                     THEN 'Collecte Cash — Remise Plateforme Commande #'
                          || left(v_order.id::text, 8)
                     ELSE 'Course effectuée — Commande #'
                          || left(v_order.id::text, 8)
                END
            );
        END IF;
    END IF;

    -- ── G. Platform commission log ────────────────────────────────────────────
    INSERT INTO public.platform_logs (type, amount, reference_id, metadata)
    VALUES (
        'commission',
        ROUND(v_platform_commission),
        v_order.id,
        jsonb_build_object(
            'order_total',  v_order.total_amount,
            'vendor_id',    v_order.vendor_id,
            'is_cash',      v_is_cash_payment
        )
    );

    -- ── H. Mark order as financially settled ──────────────────────────────────
    UPDATE public.orders SET financial_status = 'processed' WHERE id = p_order_id;

    RETURN jsonb_build_object(
        'success',            true,
        'vendorPayout',       ROUND(v_vendor_payout),
        'courierPayout',      ROUND(v_courier_payout),
        'platformCommission', ROUND(v_platform_commission)
    );
END;
$$;

GRANT EXECUTE ON FUNCTION public.secure_process_order_financials(uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION public.secure_process_order_financials(uuid) TO service_role;

-- ── 3. Admin force-settle RPC ─────────────────────────────────────────────────
-- Allows platform admins to manually close COD orders stuck in
-- financial_status='pending' because the courier had insufficient wallet balance.
--
-- SECURITY: Only profiles with is_admin=true may call this function.
--           SECURITY DEFINER ensures balance updates bypass RLS.
CREATE OR REPLACE FUNCTION public.admin_force_settle_cod_order(p_order_id UUID)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
    v_admin_id            UUID;
    v_order               RECORD;
    v_store               RECORD;
    v_is_admin            BOOLEAN;
    v_commission_str      TEXT;
    v_commission_rate     NUMERIC;
    v_items_real_value    NUMERIC;
    v_item_subtotal       NUMERIC;
    v_platform_commission NUMERIC;
    v_vendor_payout       NUMERIC;
    v_courier_payout      NUMERIC;
    v_vendor_already_paid BOOLEAN;
BEGIN
    -- ── 1. Authenticate and authorise admin ───────────────────────────────────
    v_admin_id := auth.uid();
    IF v_admin_id IS NULL THEN
        RAISE EXCEPTION 'Not authenticated';
    END IF;

    SELECT is_admin INTO v_is_admin
    FROM public.profiles
    WHERE id = v_admin_id;

    IF NOT COALESCE(v_is_admin, false) THEN
        RAISE EXCEPTION 'Access denied — admin privileges required';
    END IF;

    -- ── 2. Lock and validate order ────────────────────────────────────────────
    SELECT * INTO v_order FROM public.orders WHERE id = p_order_id FOR UPDATE;

    IF NOT FOUND THEN
        RAISE EXCEPTION 'Order % not found', p_order_id;
    END IF;

    IF v_order.financial_status = 'processed' THEN
        RETURN jsonb_build_object(
            'success',   false,
            'reason',    'already_processed',
            'message',   'Order is already financially settled — no action taken.'
        );
    END IF;

    IF v_order.status != 'delivered' THEN
        RAISE EXCEPTION
            'Cannot force-settle: order status is "%" — must be "delivered"',
            v_order.status;
    END IF;

    -- ── 3. Resolve store ──────────────────────────────────────────────────────
    SELECT * INTO v_store FROM public.stores
    WHERE id = v_order.store_id
       OR (v_order.store_id IS NULL AND owner_id = v_order.vendor_id)
    LIMIT 1;

    -- ── 4. Commission arithmetic (mirrors secure_process_order_financials) ────
    v_items_real_value := v_order.total_amount - COALESCE(v_order.delivery_fee, 0);

    SELECT value INTO v_commission_str
    FROM public.platform_settings WHERE id = 'commission_rate';
    IF v_commission_str IS NULL THEN v_commission_str := '5'; END IF;
    v_commission_rate := v_commission_str::numeric / 100.0;

    v_item_subtotal       := v_items_real_value / (1 + v_commission_rate);
    v_platform_commission := v_item_subtotal * v_commission_rate;
    v_vendor_payout       := v_item_subtotal - COALESCE(v_order.vendor_delivery_fee, 0);
    v_courier_payout      := (CASE WHEN COALESCE(v_order.delivery_fee, 0) > 0
                                   THEN v_order.delivery_fee
                                   ELSE COALESCE(v_order.vendor_delivery_fee, 0) END) * 0.8;

    IF v_order.courier_id IS NULL THEN
        v_vendor_payout := v_vendor_payout + v_courier_payout;
    END IF;

    -- ── 5. Check if vendor was already credited ───────────────────────────────
    SELECT EXISTS (
        SELECT 1 FROM public.wallet_transactions
        WHERE reference_id = p_order_id AND type = 'sale'
    ) INTO v_vendor_already_paid;

    -- ── 6. Credit vendor if not yet paid ─────────────────────────────────────
    IF NOT v_vendor_already_paid AND v_store.id IS NOT NULL THEN
        UPDATE public.stores
        SET balance = COALESCE(balance, 0) + ROUND(v_vendor_payout)
        WHERE id = v_store.id;

        INSERT INTO public.wallet_transactions
          (profile_id, store_id, amount, type, reference_id, description)
        VALUES (
            v_order.vendor_id,
            v_store.id,
            ROUND(v_vendor_payout),
            'sale',
            v_order.id,
            'Règlement Admin — Vente Cash à la livraison (Commande #'
            || left(v_order.id::text, 8) || ')'
        );
    END IF;

    -- ── 7. Mark order as processed ────────────────────────────────────────────
    UPDATE public.orders
    SET financial_status = 'processed'
    WHERE id = p_order_id;

    -- ── 8. Log admin intervention in platform_logs ────────────────────────────
    INSERT INTO public.platform_logs
      (type, amount, reference_id, metadata)
    VALUES (
        'admin_cod_override',
        ROUND(v_vendor_payout),
        p_order_id,
        jsonb_build_object(
            'admin_id',          v_admin_id,
            'order_id',          p_order_id,
            'order_total',       v_order.total_amount,
            'vendor_payout',     ROUND(v_vendor_payout),
            'commission',        ROUND(v_platform_commission),
            'vendor_was_paid',   v_vendor_already_paid,
            'courier_id',        v_order.courier_id,
            'forced_at',         NOW()
        )
    );

    RETURN jsonb_build_object(
        'success',            true,
        'vendorAlreadyPaid',  v_vendor_already_paid,
        'vendorPayout',       ROUND(v_vendor_payout),
        'platformCommission', ROUND(v_platform_commission),
        'message',            CASE
            WHEN v_vendor_already_paid
            THEN 'Order marked processed — vendor was already credited.'
            ELSE 'Vendor credited and order marked processed.'
        END
    );
END;
$$;

-- Restrict to authenticated users (admin check is done inside the function)
REVOKE EXECUTE ON FUNCTION public.admin_force_settle_cod_order(UUID) FROM PUBLIC;
GRANT  EXECUTE ON FUNCTION public.admin_force_settle_cod_order(UUID) TO authenticated;
GRANT  EXECUTE ON FUNCTION public.admin_force_settle_cod_order(UUID) TO service_role;

NOTIFY pgrst, 'reload schema';
