-- ==============================================================================
-- FATIBARA FOUNDATION SCHEMA
-- Migration: 20240101000000_foundation_schema.sql
--
-- PURPOSE:
--   Establishes ALL core tables with their COMPLETE column sets BEFORE any
--   feature migration runs. All statements are fully idempotent.
--   Later discovery / feature migrations use CREATE TABLE IF NOT EXISTS and
--   ADD COLUMN IF NOT EXISTS — they become safe no-ops once this runs first.
--
-- CRITICAL: This must be timestamp 20240101 to run before all other migrations.
-- ==============================================================================

-- Extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS pg_trgm;

-- ==============================================================================
-- 1. PROFILES (linked to auth.users)
-- ==============================================================================
CREATE TABLE IF NOT EXISTS public.profiles (
  id                UUID        PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  full_name         TEXT,
  avatar_url        TEXT,
  phone_number      TEXT,
  profile_type      TEXT        DEFAULT 'client'
                    CHECK (profile_type IN ('client','pro','vendor','courier','admin')),
  is_pro_member     BOOLEAN     DEFAULT false,
  is_admin          BOOLEAN     DEFAULT false,
  courier_status    TEXT,
  is_courier_online BOOLEAN     DEFAULT false,
  courier_zone      TEXT,
  wallet_balance    NUMERIC     DEFAULT 0,
  loyalty_points    INTEGER     DEFAULT 0,
  referral_code     TEXT,
  saved_address     JSONB,
  followed_vendors  TEXT[]      DEFAULT '{}',
  created_at        TIMESTAMPTZ DEFAULT NOW()
);

-- Wallet balance must never go negative
DO $$ BEGIN
  ALTER TABLE public.profiles ADD CONSTRAINT profiles_wallet_nonneg
    CHECK (wallet_balance >= 0);
EXCEPTION WHEN duplicate_object THEN NULL;
END $$;

-- Unique index on referral_code
CREATE UNIQUE INDEX IF NOT EXISTS idx_profiles_referral_code
  ON public.profiles (referral_code) WHERE referral_code IS NOT NULL;

-- Auto-create profile row on auth signup
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER LANGUAGE plpgsql SECURITY DEFINER AS $$
BEGIN
  INSERT INTO public.profiles (id, full_name)
  VALUES (NEW.id, NEW.raw_user_meta_data->>'full_name')
  ON CONFLICT (id) DO NOTHING;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "profiles_select_public" ON public.profiles;
CREATE POLICY "profiles_select_public" ON public.profiles FOR SELECT USING (true);
DROP POLICY IF EXISTS "profiles_insert_own" ON public.profiles;
CREATE POLICY "profiles_insert_own"    ON public.profiles FOR INSERT WITH CHECK (auth.uid() = id);
DROP POLICY IF EXISTS "profiles_update_own" ON public.profiles;
CREATE POLICY "profiles_update_own"    ON public.profiles FOR UPDATE USING (auth.uid() = id);

-- ==============================================================================
-- 2. STORES (vendor shops)
-- ==============================================================================
CREATE TABLE IF NOT EXISTS public.stores (
  id                UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
  owner_id          UUID        REFERENCES public.profiles(id) ON DELETE CASCADE,
  store_name        TEXT,
  description       TEXT,
  avatar_url        TEXT,
  banner_url        TEXT,
  location_commune  TEXT        DEFAULT 'Conakry',
  location_region   TEXT        DEFAULT 'Conakry',
  contact_phone     TEXT,
  whatsapp_number   TEXT,
  is_verified_store BOOLEAN     DEFAULT false,
  is_open           BOOLEAN     DEFAULT true,
  rating            NUMERIC     DEFAULT 4.5,
  response_rate     INTEGER     DEFAULT 98,
  commission_rate   NUMERIC     DEFAULT 5,
  balance           NUMERIC     DEFAULT 0,
  chat_enabled      BOOLEAN     DEFAULT true,
  created_at        TIMESTAMPTZ DEFAULT NOW()
);

-- Store balance cannot go negative
DO $$ BEGIN
  ALTER TABLE public.stores ADD CONSTRAINT stores_balance_nonneg CHECK (balance >= 0);
EXCEPTION WHEN duplicate_object THEN NULL;
END $$;

ALTER TABLE public.stores ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "stores_select_public" ON public.stores;
CREATE POLICY "stores_select_public" ON public.stores FOR SELECT USING (true);
DROP POLICY IF EXISTS "stores_insert_own"    ON public.stores;
CREATE POLICY "stores_insert_own"    ON public.stores FOR INSERT WITH CHECK (auth.uid() = owner_id);
DROP POLICY IF EXISTS "stores_update_own"    ON public.stores;
CREATE POLICY "stores_update_own"    ON public.stores FOR UPDATE USING (auth.uid() = owner_id);
DROP POLICY IF EXISTS "stores_delete_own"    ON public.stores;
CREATE POLICY "stores_delete_own"    ON public.stores FOR DELETE USING (auth.uid() = owner_id);

-- ==============================================================================
-- 3. PRODUCTS
-- ==============================================================================
CREATE TABLE IF NOT EXISTS public.products (
  id                  UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
  store_id            UUID        REFERENCES public.stores(id) ON DELETE CASCADE,
  title               TEXT,
  name                TEXT,   -- legacy alias
  description         TEXT,
  price_gnf           NUMERIC,
  price               NUMERIC,   -- legacy alias
  wholesale_price_gnf NUMERIC,
  image_urls          TEXT[]      DEFAULT '{}',
  image_url           TEXT,       -- legacy alias
  category            TEXT,
  stock_quantity      INTEGER     DEFAULT 0,
  stock               INTEGER     DEFAULT 0,   -- legacy alias
  max_stock           INTEGER     DEFAULT 100,
  is_verified         BOOLEAN     DEFAULT true,
  is_active           BOOLEAN     DEFAULT true,
  variations          JSONB       DEFAULT '[]',
  is_hero             BOOLEAN     DEFAULT false,
  is_featured         BOOLEAN     DEFAULT false,
  popularity          INTEGER     DEFAULT 0,
  relevance           INTEGER     DEFAULT 0,
  vendor_region       TEXT        DEFAULT 'Conakry',
  location            TEXT        DEFAULT 'Conakry',
  seller_name         TEXT,       -- legacy alias
  status              TEXT        DEFAULT 'published'
                      CHECK (status IN ('draft','published','scheduled')),
  created_at          TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_products_store_id  ON public.products (store_id);
CREATE INDEX IF NOT EXISTS idx_products_category  ON public.products (category);

ALTER TABLE public.products ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "products_select_public"   ON public.products;
CREATE POLICY "products_select_public" ON public.products FOR SELECT USING (true);
DROP POLICY IF EXISTS "products_insert_owner"    ON public.products;
CREATE POLICY "products_insert_owner"  ON public.products FOR INSERT WITH CHECK (
  EXISTS (SELECT 1 FROM public.stores WHERE id = products.store_id AND owner_id = auth.uid())
);
DROP POLICY IF EXISTS "products_update_owner"    ON public.products;
CREATE POLICY "products_update_owner"  ON public.products FOR UPDATE USING (
  EXISTS (SELECT 1 FROM public.stores WHERE id = products.store_id AND owner_id = auth.uid())
);
DROP POLICY IF EXISTS "products_delete_owner"    ON public.products;
CREATE POLICY "products_delete_owner"  ON public.products FOR DELETE USING (
  EXISTS (SELECT 1 FROM public.stores WHERE id = products.store_id AND owner_id = auth.uid())
);

-- ==============================================================================
-- 4. ORDERS — complete financial schema
-- ==============================================================================
CREATE TABLE IF NOT EXISTS public.orders (
  id                      UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id                 UUID        REFERENCES public.profiles(id) ON DELETE SET NULL,
  vendor_id               UUID        REFERENCES public.profiles(id) ON DELETE CASCADE,
  store_id                UUID        REFERENCES public.stores(id)   ON DELETE SET NULL,
  courier_id              UUID        REFERENCES public.profiles(id) ON DELETE SET NULL,
  -- legacy column kept for seller_stats view
  product_id              UUID        REFERENCES public.products(id) ON DELETE CASCADE,
  customer_name           TEXT,
  items_count             INTEGER     DEFAULT 1,
  total_amount            NUMERIC,
  delivery_fee            NUMERIC     DEFAULT 0,
  vendor_delivery_fee     NUMERIC     DEFAULT 0,
  shipping_address        JSONB,
  tracking_number         TEXT,
  delivery_otp            TEXT,
  cancel_reason           TEXT,
  extracted_response_time NUMERIC,
  status                  TEXT        DEFAULT 'pending',
  financial_status        TEXT        DEFAULT 'pending'
                          CHECK (financial_status IN
                            ('pending','paid','processed','failed','refunded')),
  created_at              TIMESTAMPTZ DEFAULT NOW(),
  updated_at              TIMESTAMPTZ DEFAULT NOW()
);

-- Expand status allowed values (no CHECK — too many states to enumerate safely here;
-- enforced at application layer and by the state-machine migration)
CREATE INDEX IF NOT EXISTS idx_orders_user_id       ON public.orders (user_id);
CREATE INDEX IF NOT EXISTS idx_orders_vendor_id     ON public.orders (vendor_id);
CREATE INDEX IF NOT EXISTS idx_orders_store_id      ON public.orders (store_id);
CREATE INDEX IF NOT EXISTS idx_orders_courier_id    ON public.orders (courier_id) WHERE courier_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_orders_status        ON public.orders (status);
CREATE INDEX IF NOT EXISTS idx_orders_fin_status    ON public.orders (financial_status);
CREATE INDEX IF NOT EXISTS idx_orders_tracking      ON public.orders (tracking_number) WHERE tracking_number IS NOT NULL;

-- Auto-update updated_at
CREATE OR REPLACE FUNCTION public.set_updated_at()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
BEGIN NEW.updated_at := NOW(); RETURN NEW; END;
$$;

CREATE OR REPLACE TRIGGER trg_orders_updated_at
  BEFORE UPDATE ON public.orders
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

ALTER TABLE public.orders ENABLE ROW LEVEL SECURITY;
-- Orders RLS is fully managed by later migration 20260715000001_definitive_fix_rpc_and_rls
-- Set minimal fallback policies here (overwritten later)
DROP POLICY IF EXISTS "orders_foundation_select" ON public.orders;
CREATE POLICY "orders_foundation_select" ON public.orders FOR SELECT TO authenticated
  USING (auth.uid() = user_id OR auth.uid() = vendor_id OR auth.uid() = courier_id);
DROP POLICY IF EXISTS "orders_foundation_insert" ON public.orders;
CREATE POLICY "orders_foundation_insert" ON public.orders FOR INSERT TO authenticated
  WITH CHECK (auth.uid() = user_id);

-- ==============================================================================
-- 5. ORDER ITEMS
-- ==============================================================================
CREATE TABLE IF NOT EXISTS public.order_items (
  id                  UUID    PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id            UUID    NOT NULL REFERENCES public.orders(id)   ON DELETE CASCADE,
  product_id          UUID             REFERENCES public.products(id) ON DELETE SET NULL,
  quantity            INTEGER NOT NULL DEFAULT 1,
  price_at_purchase   NUMERIC NOT NULL,
  selected_variations JSONB   DEFAULT '{}',
  created_at          TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE public.order_items ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "order_items_select" ON public.order_items;
CREATE POLICY "order_items_select" ON public.order_items FOR SELECT TO authenticated
  USING (EXISTS (SELECT 1 FROM public.orders
    WHERE id = order_items.order_id
      AND (user_id = auth.uid() OR vendor_id = auth.uid())));
DROP POLICY IF EXISTS "order_items_insert" ON public.order_items;
CREATE POLICY "order_items_insert" ON public.order_items FOR INSERT TO authenticated WITH CHECK (true);

-- ==============================================================================
-- 6. DELIVERIES
-- ==============================================================================
CREATE TABLE IF NOT EXISTS public.deliveries (
  id               UUID    PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id         UUID    NOT NULL REFERENCES public.orders(id)   ON DELETE CASCADE,
  courier_id       UUID             REFERENCES public.profiles(id) ON DELETE SET NULL,
  status           TEXT    DEFAULT 'pending'
                   CHECK (status IN ('pending','assigned','picked_up','in_transit','delivered','failed')),
  current_location JSONB,
  estimated_at     TIMESTAMPTZ,
  delivered_at     TIMESTAMPTZ,
  notes            TEXT,
  created_at       TIMESTAMPTZ DEFAULT NOW(),
  updated_at       TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE public.deliveries ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "deliveries_select" ON public.deliveries;
CREATE POLICY "deliveries_select" ON public.deliveries FOR SELECT TO authenticated
  USING (courier_id = auth.uid()
    OR EXISTS (SELECT 1 FROM public.orders WHERE id = order_id AND user_id   = auth.uid())
    OR EXISTS (SELECT 1 FROM public.orders WHERE id = order_id AND vendor_id = auth.uid()));
DROP POLICY IF EXISTS "deliveries_insert" ON public.deliveries;
CREATE POLICY "deliveries_insert" ON public.deliveries FOR INSERT TO authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "deliveries_update" ON public.deliveries;
CREATE POLICY "deliveries_update" ON public.deliveries FOR UPDATE TO authenticated
  USING (courier_id = auth.uid());

-- ==============================================================================
-- 7. WALLET TRANSACTIONS — immutable financial ledger
--    Direct INSERT/UPDATE from the 'authenticated' role is BLOCKED.
--    Only SECURITY DEFINER RPCs may write rows.
-- ==============================================================================
CREATE TABLE IF NOT EXISTS public.wallet_transactions (
  id           UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
  profile_id   UUID        REFERENCES public.profiles(id) ON DELETE SET NULL,
  store_id     UUID        REFERENCES public.stores(id)   ON DELETE SET NULL,
  amount       NUMERIC     NOT NULL,
  type         TEXT        NOT NULL
               CHECK (type IN ('purchase','sale','refund','fee','delivery_fee',
                               'withdrawal','deposit','boost','credit')),
  reference_id UUID,
  description  TEXT,
  status       TEXT        DEFAULT 'completed'
               CHECK (status IN ('pending','completed','failed','reversed')),
  created_at   TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE public.wallet_transactions ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "wt_select_own"   ON public.wallet_transactions;
CREATE POLICY "wt_select_own" ON public.wallet_transactions FOR SELECT TO authenticated
  USING (profile_id = auth.uid());

DROP POLICY IF EXISTS "wt_select_store" ON public.wallet_transactions;
CREATE POLICY "wt_select_store" ON public.wallet_transactions FOR SELECT TO authenticated
  USING (store_id IN (SELECT id FROM public.stores WHERE owner_id = auth.uid()));

-- Block direct writes from client (all writes go through SECURITY DEFINER RPCs)
REVOKE INSERT, UPDATE, DELETE ON public.wallet_transactions FROM authenticated;

CREATE INDEX IF NOT EXISTS idx_wt_profile_id   ON public.wallet_transactions (profile_id);
CREATE INDEX IF NOT EXISTS idx_wt_store_id     ON public.wallet_transactions (store_id);
CREATE INDEX IF NOT EXISTS idx_wt_reference_id ON public.wallet_transactions (reference_id);
CREATE INDEX IF NOT EXISTS idx_wt_type         ON public.wallet_transactions (type);

-- ==============================================================================
-- 8. PLATFORM LOGS — commission audit trail
-- ==============================================================================
CREATE TABLE IF NOT EXISTS public.platform_logs (
  id           UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
  type         TEXT        NOT NULL
               CHECK (type IN ('commission','refund','adjustment','withdrawal','system')),
  amount       NUMERIC     NOT NULL DEFAULT 0,
  reference_id UUID,
  metadata     JSONB       DEFAULT '{}',
  created_at   TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE public.platform_logs ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "pl_select_admin" ON public.platform_logs;
CREATE POLICY "pl_select_admin" ON public.platform_logs FOR SELECT TO authenticated
  USING (EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND is_admin = true));
REVOKE INSERT, UPDATE, DELETE ON public.platform_logs FROM authenticated;

CREATE INDEX IF NOT EXISTS idx_pl_reference_id ON public.platform_logs (reference_id);

-- ==============================================================================
-- 9. PLATFORM SETTINGS
-- ==============================================================================
CREATE TABLE IF NOT EXISTS public.platform_settings (
  id          TEXT PRIMARY KEY,
  value       TEXT NOT NULL,
  description TEXT,
  updated_at  TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE public.platform_settings ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "ps_select_all" ON public.platform_settings;
CREATE POLICY "ps_select_all" ON public.platform_settings FOR SELECT USING (true);
REVOKE INSERT, UPDATE, DELETE ON public.platform_settings FROM authenticated;

-- Default commission rate (5%) — idempotent
INSERT INTO public.platform_settings (id, value, description)
VALUES ('commission_rate', '5', 'Platform commission percentage on each sale')
ON CONFLICT (id) DO NOTHING;

-- ==============================================================================
-- 10. CART ITEMS
-- ==============================================================================
CREATE TABLE IF NOT EXISTS public.cart_items (
  id                  UUID    PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id             UUID    REFERENCES public.profiles(id) ON DELETE CASCADE,
  product_id          UUID    REFERENCES public.products(id) ON DELETE CASCADE,
  quantity            INTEGER DEFAULT 1,
  selected_variations JSONB   DEFAULT '{}',
  created_at          TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE (user_id, product_id, selected_variations)
);

ALTER TABLE public.cart_items ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "cart_manage_own" ON public.cart_items;
CREATE POLICY "cart_manage_own" ON public.cart_items FOR ALL USING (auth.uid() = user_id);

-- ==============================================================================
-- 11. HELPER FUNCTIONS (SECURITY DEFINER — not callable by authenticated role)
-- ==============================================================================
DROP FUNCTION IF EXISTS public.increment_wallet_balance(UUID, NUMERIC);

CREATE OR REPLACE FUNCTION public.increment_wallet_balance(p_user_id UUID, p_amount NUMERIC)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  UPDATE public.profiles SET wallet_balance = wallet_balance + p_amount WHERE id = p_user_id;
END;
$$;
REVOKE EXECUTE ON FUNCTION public.increment_wallet_balance(UUID, NUMERIC) FROM public, authenticated;

DROP FUNCTION IF EXISTS public.increment_store_balance(UUID, NUMERIC);

CREATE OR REPLACE FUNCTION public.increment_store_balance(p_store_id UUID, p_amount NUMERIC)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  UPDATE public.stores SET balance = balance + p_amount WHERE id = p_store_id;
END;
$$;
REVOKE EXECUTE ON FUNCTION public.increment_store_balance(UUID, NUMERIC) FROM public, authenticated;

-- ==============================================================================
-- 12. SERVICE ROLE GRANTS
-- ==============================================================================
GRANT ALL ON public.wallet_transactions TO service_role, postgres;
GRANT ALL ON public.platform_logs       TO service_role, postgres;
GRANT ALL ON public.platform_settings   TO service_role, postgres;
GRANT ALL ON public.order_items         TO service_role, postgres;
GRANT ALL ON public.deliveries          TO service_role, postgres;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.profiles TO service_role, postgres;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.stores   TO service_role, postgres;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.orders   TO service_role, postgres;

-- ==============================================================================
-- 13. REALTIME SUBSCRIPTIONS
-- ==============================================================================
DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_publication_tables
    WHERE pubname='supabase_realtime' AND tablename='orders') THEN
    ALTER PUBLICATION supabase_realtime ADD TABLE public.orders;
  END IF;
END $$;

NOTIFY pgrst, 'reload schema';
