-- Existing payment callbacks record gateway failure details in orders.notes.
-- Keep the field available for those audit messages and the unpaid-order
-- cancellation RPC.
ALTER TABLE public.orders
  ADD COLUMN IF NOT EXISTS notes TEXT;

NOTIFY pgrst, 'reload schema';
