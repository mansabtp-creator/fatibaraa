-- =============================================================================
-- Migration: Database Integrity Fixes — Audit Round 2026-08-15
-- File:      supabase/migrations/20260815000001_db_integrity_audit_fixes.sql
-- Created:   2026-08-15
--
-- ISSUES FIXED:
--
--   1. [CRITICAL] verify_delivery_otp RPC does not exist.
--      The CourierDashboardPage calls supabase.rpc('verify_delivery_otp', ...)
--      but the function was never created in any migration. This migration creates
--      it as a SECURITY DEFINER function that:
--        a) Validates the caller is the assigned courier for the order
--        b) Compares the input OTP to orders.delivery_otp
--        c) On match, calls secure_process_order_financials + sets status='delivered'
--        d) Returns structured JSONB { success, error? }
--
--   2. [HIGH] Realtime publication missing: notifications, deliveries, stores.
--      The app subscribes to these tables via supabase.channel().on('postgres_changes')
--      but they are not in the supabase_realtime publication. Changes will never
--      reach the client. Added all three.
--
--   3. [MEDIUM] Duplicate stock-decrement triggers on order_items.
--      Three triggers all fire AFTER INSERT on order_items:
--        on_order_item_created  -> handle_stock_decrement()
--        on_order_item_inserted -> handle_stock_on_order()
--        tr_reduce_stock        -> reduce_product_stock()
--      This causes triple stock deduction per order item. We drop the two
--      older duplicates and keep only the canonical tr_reduce_stock trigger.
--
--   4. [MEDIUM] Tables with RLS enabled but no policies (effectively locked):
--      admin_audit_logs, admin_impersonation_sessions, admin_registry, admins,
--      conversations, guinea_locations, messages, product_interactions,
--      product_verifications, store_follows, vendorApplications
-- =============================================================================

-- =============================================================================
-- FIX 1: Create verify_delivery_otp RPC
-- =============================================================================

CREATE OR REPLACE FUNCTION public.verify_delivery_otp(
  p_order_id UUID,
  p_otp      TEXT
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_order     RECORD;
  v_result    JSONB;
BEGIN
  -- 1. Lock and fetch the order
  SELECT id, status, courier_id, delivery_otp, financial_status
  INTO v_order
  FROM public.orders
  WHERE id = p_order_id
  FOR UPDATE;

  IF NOT FOUND THEN
    RETURN jsonb_build_object('success', false, 'error', 'order_not_found');
  END IF;

  -- 2. Caller must be the assigned courier
  IF auth.uid() IS NOT NULL AND auth.uid() != v_order.courier_id THEN
    RETURN jsonb_build_object('success', false, 'error', 'unauthorized');
  END IF;

  -- 3. Order must be in transit
  IF v_order.status NOT IN ('in_transit', 'arriving_soon') THEN
    RETURN jsonb_build_object(
      'success', false,
      'error', 'invalid_status',
      'current_status', v_order.status
    );
  END IF;

  -- 4. Already delivered guard
  IF v_order.status = 'delivered' THEN
    RETURN jsonb_build_object('success', true, 'alreadyDelivered', true);
  END IF;

  -- 5. OTP comparison
  IF TRIM(p_otp) != TRIM(v_order.delivery_otp::TEXT) THEN
    RETURN jsonb_build_object('success', false, 'error', 'invalid_otp');
  END IF;

  -- 6. Mark delivered — fires trg_auto_settle_financials_on_delivery
  UPDATE public.orders
  SET
    status     = 'delivered',
    updated_at = NOW()
  WHERE id = p_order_id;

  -- 7. Belt-and-suspenders financial settlement
  IF v_order.financial_status NOT IN ('processed', 'refunded') THEN
    BEGIN
      SELECT public.secure_process_order_financials(p_order_id) INTO v_result;
    EXCEPTION WHEN OTHERS THEN
      RAISE WARNING '[verify_delivery_otp] Financial settlement failed for order %: %',
                    p_order_id, SQLERRM;
      v_result := jsonb_build_object('success', false, 'financialError', SQLERRM);
    END;
  END IF;

  RETURN jsonb_build_object(
    'success',    true,
    'orderId',    p_order_id,
    'financials', v_result
  );

EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('success', false, 'error', SQLERRM);
END;
$$;

GRANT EXECUTE ON FUNCTION public.verify_delivery_otp(UUID, TEXT) TO authenticated;
GRANT EXECUTE ON FUNCTION public.verify_delivery_otp(UUID, TEXT) TO service_role;

COMMENT ON FUNCTION public.verify_delivery_otp(UUID, TEXT) IS
  'Validates courier OTP and atomically marks order as delivered + triggers financial settlement.
   Returns JSONB { success, error?, orderId?, financials? }.
   Caller must be the assigned courier (auth.uid() = orders.courier_id).';

-- =============================================================================
-- FIX 2: Add missing tables to Realtime publication
-- =============================================================================

ALTER PUBLICATION supabase_realtime ADD TABLE public.notifications;
ALTER PUBLICATION supabase_realtime ADD TABLE public.deliveries;
ALTER PUBLICATION supabase_realtime ADD TABLE public.stores;

-- =============================================================================
-- FIX 3: Remove duplicate stock-decrement triggers on order_items
-- =============================================================================

DROP TRIGGER IF EXISTS on_order_item_created  ON public.order_items;
DROP TRIGGER IF EXISTS on_order_item_inserted ON public.order_items;
DROP TRIGGER IF EXISTS tr_order_stock_decrement ON public.orders;

-- =============================================================================
-- FIX 4: RLS policies for zero-policy tables
-- =============================================================================

-- guinea_locations: public read (reference data)
DROP POLICY IF EXISTS "guinea_locations_public_read" ON public.guinea_locations;
CREATE POLICY "guinea_locations_public_read"
ON public.guinea_locations FOR SELECT
TO anon, authenticated
USING (true);

-- conversations: user_id (buyer) + store_id lookup
DROP POLICY IF EXISTS "conversations_own_read" ON public.conversations;
CREATE POLICY "conversations_own_read"
ON public.conversations FOR SELECT TO authenticated
USING (
  auth.uid() = user_id
  OR EXISTS (SELECT 1 FROM public.stores s WHERE s.id = store_id AND s.owner_id = auth.uid())
);

DROP POLICY IF EXISTS "conversations_own_insert" ON public.conversations;
CREATE POLICY "conversations_own_insert"
ON public.conversations FOR INSERT TO authenticated
WITH CHECK (auth.uid() = user_id);

-- messages: sender_id + conversation_id join to check membership
DROP POLICY IF EXISTS "messages_own_read" ON public.messages;
CREATE POLICY "messages_own_read"
ON public.messages FOR SELECT TO authenticated
USING (
  auth.uid() = sender_id
  OR EXISTS (
    SELECT 1 FROM public.conversations c
    WHERE c.id = conversation_id
      AND (
        c.user_id = auth.uid()
        OR EXISTS (SELECT 1 FROM public.stores s WHERE s.id = c.store_id AND s.owner_id = auth.uid())
      )
  )
);

DROP POLICY IF EXISTS "messages_own_insert" ON public.messages;
CREATE POLICY "messages_own_insert"
ON public.messages FOR INSERT TO authenticated
WITH CHECK (auth.uid() = sender_id);

-- store_follows
DROP POLICY IF EXISTS "store_follows_read" ON public.store_follows;
CREATE POLICY "store_follows_read"
ON public.store_follows FOR SELECT TO authenticated
USING (true);

DROP POLICY IF EXISTS "store_follows_own_write" ON public.store_follows;
CREATE POLICY "store_follows_own_write"
ON public.store_follows FOR INSERT TO authenticated
WITH CHECK (auth.uid() = follower_id);

DROP POLICY IF EXISTS "store_follows_own_delete" ON public.store_follows;
CREATE POLICY "store_follows_own_delete"
ON public.store_follows FOR DELETE TO authenticated
USING (auth.uid() = follower_id);

-- product_interactions
DROP POLICY IF EXISTS "product_interactions_own" ON public.product_interactions;
CREATE POLICY "product_interactions_own"
ON public.product_interactions FOR ALL TO authenticated
USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

-- product_verifications: admin only
DROP POLICY IF EXISTS "product_verifications_admin_read" ON public.product_verifications;
CREATE POLICY "product_verifications_admin_read"
ON public.product_verifications FOR SELECT TO authenticated
USING (public.is_admin());

-- admin_audit_logs
DROP POLICY IF EXISTS "admin_audit_logs_admin_read" ON public.admin_audit_logs;
CREATE POLICY "admin_audit_logs_admin_read"
ON public.admin_audit_logs FOR SELECT TO authenticated
USING (public.is_admin());

-- admin_impersonation_sessions
DROP POLICY IF EXISTS "admin_impersonation_sessions_admin" ON public.admin_impersonation_sessions;
CREATE POLICY "admin_impersonation_sessions_admin"
ON public.admin_impersonation_sessions FOR ALL TO authenticated
USING (public.is_admin()) WITH CHECK (public.is_admin());

-- admin_registry
DROP POLICY IF EXISTS "admin_registry_admin_read" ON public.admin_registry;
CREATE POLICY "admin_registry_admin_read"
ON public.admin_registry FOR SELECT TO authenticated
USING (public.is_admin());

-- admins table
DROP POLICY IF EXISTS "admins_admin_read" ON public.admins;
CREATE POLICY "admins_admin_read"
ON public.admins FOR SELECT TO authenticated
USING (public.is_admin());

-- vendorApplications (legacy camelCase table — userId column is also camelCase)
DROP POLICY IF EXISTS "vendorApplications_own_read" ON public."vendorApplications";
CREATE POLICY "vendorApplications_own_read"
ON public."vendorApplications" FOR SELECT TO authenticated
USING (auth.uid() = "userId" OR public.is_admin());

DROP POLICY IF EXISTS "vendorApplications_own_insert" ON public."vendorApplications";
CREATE POLICY "vendorApplications_own_insert"
ON public."vendorApplications" FOR INSERT TO authenticated
WITH CHECK (auth.uid() = "userId");

-- =============================================================================
-- RELOAD POSTGREST SCHEMA CACHE
-- =============================================================================
NOTIFY pgrst, 'reload schema';
