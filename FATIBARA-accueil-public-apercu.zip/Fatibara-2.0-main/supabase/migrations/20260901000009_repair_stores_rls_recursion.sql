-- =============================================================================
-- Repair the stores RLS policy set.
--
-- A production policy outside the tracked migration history is recursively
-- reading public.stores while public.stores is being evaluated. That causes
-- PostgreSQL error 42P17 ("infinite recursion detected in policy for relation
-- stores") whenever a vendor saves store settings.
--
-- Remove every policy currently attached to stores (including manually-created
-- policies with unknown names) and install the complete canonical policy set.
-- The rules deliberately use only auth.uid(), owner_id, and the SECURITY
-- DEFINER is_admin() helper; none query stores from a stores policy.
-- =============================================================================

DO $$
DECLARE
  v_policy_name TEXT;
BEGIN
  FOR v_policy_name IN
    SELECT policyname
    FROM pg_policies
    WHERE schemaname = 'public'
      AND tablename = 'stores'
  LOOP
    EXECUTE format('DROP POLICY %I ON public.stores', v_policy_name);
  END LOOP;
END;
$$;

ALTER TABLE public.stores ENABLE ROW LEVEL SECURITY;

-- Storefronts are public catalogue data. This also lets a vendor read their
-- own store before updating it.
CREATE POLICY "stores_public_read"
ON public.stores
FOR SELECT
TO anon, authenticated
USING (true);

-- A vendor may create a store for themselves; an administrator may create one
-- when processing an application.
CREATE POLICY "stores_owner_or_admin_insert"
ON public.stores
FOR INSERT
TO authenticated
WITH CHECK (auth.uid() = owner_id OR public.is_admin());

-- Owners maintain their own settings; the admin dashboard may moderate any
-- store. is_admin() is SECURITY DEFINER, so this cannot recurse through RLS.
CREATE POLICY "stores_owner_or_admin_update"
ON public.stores
FOR UPDATE
TO authenticated
USING (auth.uid() = owner_id OR public.is_admin())
WITH CHECK (auth.uid() = owner_id OR public.is_admin());

CREATE POLICY "stores_owner_or_admin_delete"
ON public.stores
FOR DELETE
TO authenticated
USING (auth.uid() = owner_id OR public.is_admin());

GRANT SELECT ON public.stores TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.stores TO authenticated;

NOTIFY pgrst, 'reload schema';
