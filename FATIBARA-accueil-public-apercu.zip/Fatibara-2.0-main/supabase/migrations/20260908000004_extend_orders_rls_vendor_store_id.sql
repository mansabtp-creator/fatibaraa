-- =============================================================================
-- Migration: 20260908000004_extend_orders_rls_vendor_store_id.sql
-- Fix V6: The orders table UPDATE policy only allowed vendors when
-- vendor_id = auth.uid(). Legacy orders (created before the vendor_id column
-- was backfilled) have vendor_id = NULL and store_id set instead.
-- Without this policy, standard status updates (accepted, preparing, in_transit)
-- silently fail with 0 rows updated — the RPC-based terminal states (delivered,
-- cancelled) are already protected by SECURITY DEFINER functions, so this only
-- covers the non-financial intermediate transitions.
-- =============================================================================

-- ── STEP 1: Drop any existing vendor update policy to avoid duplicates ────────
DROP POLICY IF EXISTS "vendors_can_update_own_orders" ON public.orders;
DROP POLICY IF EXISTS "vendor_can_update_own_orders" ON public.orders;
DROP POLICY IF EXISTS "orders_vendor_update" ON public.orders;

-- ── STEP 2: Create unified vendor UPDATE policy ───────────────────────────────
-- Allows updates when:
--   a) vendor_id = caller's UID (standard modern orders)
--   b) store_id is owned by caller via stores.owner_id (legacy orders)
-- The store ownership sub-select is NOT recursive — it queries `stores`, not `orders`.
CREATE POLICY "orders_vendor_or_store_owner_update"
  ON public.orders
  FOR UPDATE
  USING (
    vendor_id = auth.uid()
    OR
    store_id IN (
      SELECT id FROM public.stores WHERE owner_id = auth.uid()
    )
  )
  WITH CHECK (
    vendor_id = auth.uid()
    OR
    store_id IN (
      SELECT id FROM public.stores WHERE owner_id = auth.uid()
    )
  );

-- ── STEP 3: Ensure SELECT is also available for store_id arm ─────────────────
-- Some previous migrations may have left gaps in the SELECT policy too.
DROP POLICY IF EXISTS "vendors_can_view_own_orders" ON public.orders;
DROP POLICY IF EXISTS "vendor_can_view_own_orders" ON public.orders;
DROP POLICY IF EXISTS "orders_vendor_select" ON public.orders;

CREATE POLICY "orders_vendor_or_store_owner_select"
  ON public.orders
  FOR SELECT
  USING (
    -- Customer can always see their own order
    user_id = auth.uid()
    OR
    -- Vendor by vendor_id (modern)
    vendor_id = auth.uid()
    OR
    -- Vendor by store ownership (legacy)
    store_id IN (
      SELECT id FROM public.stores WHERE owner_id = auth.uid()
    )
    OR
    -- Courier assigned to this order
    courier_id = auth.uid()
    OR
    -- Admins see everything
    public.is_admin()
  );

-- ── STEP 4: Notify PostgREST to reload schema cache ──────────────────────────
NOTIFY pgrst, 'reload schema';
