-- =============================================================================
-- Fatibara Chat Enhancements Migration
-- Run this in: Supabase Dashboard → SQL Editor
-- =============================================================================

-- 1. Add last_message column (idempotent — safe to run multiple times)
ALTER TABLE chat_channels
  ADD COLUMN IF NOT EXISTS last_message TEXT;

-- 2. Create chat_reports table
CREATE TABLE IF NOT EXISTS chat_reports (
  id                UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
  channel_id        UUID        NOT NULL REFERENCES chat_channels(id) ON DELETE CASCADE,
  reporter_id       UUID        NOT NULL REFERENCES profiles(id)      ON DELETE CASCADE,
  reported_store_id UUID        NOT NULL REFERENCES stores(id)        ON DELETE CASCADE,
  reason            TEXT,
  created_at        TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

ALTER TABLE chat_reports ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Users can insert their own reports" ON chat_reports;
CREATE POLICY "Users can insert their own reports" ON chat_reports
  FOR INSERT TO authenticated
  WITH CHECK (auth.uid() = reporter_id);

DROP POLICY IF EXISTS "Users can read their own reports" ON chat_reports;
CREATE POLICY "Users can read their own reports" ON chat_reports
  FOR SELECT TO authenticated
  USING (auth.uid() = reporter_id);

-- 3. Chat-images storage bucket
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES (
  'chat-images',
  'chat-images',
  true,
  5242880,
  ARRAY['image/jpeg','image/png','image/gif','image/webp']
)
ON CONFLICT (id) DO NOTHING;

DROP POLICY IF EXISTS "Public read chat images"            ON storage.objects;
DROP POLICY IF EXISTS "Authenticated upload chat images"   ON storage.objects;
DROP POLICY IF EXISTS "Users delete own chat images"       ON storage.objects;

CREATE POLICY "Public read chat images"
  ON storage.objects FOR SELECT TO public
  USING (bucket_id = 'chat-images');

CREATE POLICY "Authenticated upload chat images"
  ON storage.objects FOR INSERT TO authenticated
  WITH CHECK (
    bucket_id = 'chat-images'
    AND (storage.foldername(name))[1] = auth.uid()::text
  );

CREATE POLICY "Users delete own chat images"
  ON storage.objects FOR DELETE TO authenticated
  USING (
    bucket_id = 'chat-images'
    AND (storage.foldername(name))[1] = auth.uid()::text
  );

-- 4. Trigger: sync last_message + server-side auto-reply
CREATE OR REPLACE FUNCTION fn_on_chat_message_insert()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_preview            TEXT;
  v_owner_id           UUID;
  v_auto_reply_enabled BOOLEAN;
  v_auto_reply_message TEXT;
BEGIN
  -- 4a. Always sync last_message preview on the channel
  v_preview := CASE
    WHEN char_length(COALESCE(NEW.message, '')) > 80
    THEN substr(NEW.message, 1, 77) || '…'
    ELSE COALESCE(NEW.message, '')
  END;

  UPDATE chat_channels
  SET last_message    = v_preview,
      last_message_at = COALESCE(NEW.created_at, NOW())
  WHERE id = NEW.channel_id;

  -- 4b. Skip auto-reply for messages that are already auto-replies
  IF (NEW.metadata->>'type') = 'auto-reply' THEN
    RETURN NEW;
  END IF;

  -- 4c. Look up store auto-reply config
  SELECT s.owner_id,
         COALESCE(s.auto_reply_enabled, false),
         s.auto_reply_message
  INTO   v_owner_id, v_auto_reply_enabled, v_auto_reply_message
  FROM   chat_channels c
  JOIN   stores s ON s.id = c.store_id
  WHERE  c.id = NEW.channel_id;

  -- 4d. Fire auto-reply only when:
  --   • store has it enabled
  --   • sender is the buyer (not the vendor)
  --   • a non-empty template exists
  IF  v_auto_reply_enabled = TRUE
  AND v_owner_id IS NOT NULL
  AND NEW.sender_id IS DISTINCT FROM v_owner_id
  AND v_auto_reply_message IS NOT NULL
  AND trim(v_auto_reply_message) != ''
  THEN
    INSERT INTO chat_messages (channel_id, sender_id, message, metadata)
    VALUES (NEW.channel_id, v_owner_id, v_auto_reply_message,
            '{"type":"auto-reply"}'::jsonb);
  END IF;

  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS tgr_chat_message_insert ON chat_messages;
CREATE TRIGGER tgr_chat_message_insert
  AFTER INSERT ON chat_messages
  FOR EACH ROW EXECUTE FUNCTION fn_on_chat_message_insert();

-- 5. Backfill last_message for channels that don't have it yet
UPDATE chat_channels c
SET    last_message = (
  SELECT CASE WHEN char_length(m.message) > 80
              THEN substr(m.message, 1, 77) || '…'
              ELSE m.message END
  FROM   chat_messages m
  WHERE  m.channel_id = c.id
  ORDER  BY m.created_at DESC
  LIMIT  1
)
WHERE  c.last_message IS NULL;
