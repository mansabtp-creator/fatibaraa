-- ==============================================================================
-- MIGRATION: 20260826000001_credit_user_wallet.sql
--
-- PURPOSE:
--   1. Patch wallet_transactions with `reference_text`, `pay_id`, `updated_at`
--      columns needed by the webhook gateway for TEXT-based TOPUP- lookups.
--   2. Ensure courier_profiles table exists so we can sync it.
--   3. Create (or replace) `credit_user_wallet` — the ATOMIC SECURITY DEFINER
--      function called by api/webhook/gateway.ts after a verified LengoPay
--      SUCCESS webhook. Atomically:
--        a) CAS on wallet_transactions (prevents double-credit on retried webhooks)
--        b) Credits profiles.wallet_balance  ← what CourierDashboardPage reads
--        c) Syncs courier_profiles.balance   ← kept in sync if row exists
-- ==============================================================================

-- ── 1. Patch wallet_transactions ──────────────────────────────────────────────
ALTER TABLE public.wallet_transactions
  ADD COLUMN IF NOT EXISTS reference_text TEXT,
  ADD COLUMN IF NOT EXISTS pay_id         TEXT,
  ADD COLUMN IF NOT EXISTS updated_at     TIMESTAMPTZ DEFAULT NOW();

CREATE INDEX IF NOT EXISTS idx_wt_reference_text
  ON public.wallet_transactions (reference_text)
  WHERE reference_text IS NOT NULL;

CREATE INDEX IF NOT EXISTS idx_wt_pay_id
  ON public.wallet_transactions (pay_id)
  WHERE pay_id IS NOT NULL;

-- ── 2. Ensure courier_profiles exists (idempotent) ───────────────────────────
CREATE TABLE IF NOT EXISTS public.courier_profiles (
  id         UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id    UUID        UNIQUE REFERENCES public.profiles(id) ON DELETE CASCADE,
  balance    NUMERIC     DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

DO $$ BEGIN
  ALTER TABLE public.courier_profiles
    ADD CONSTRAINT courier_profiles_balance_nonneg CHECK (balance >= 0);
EXCEPTION WHEN duplicate_object THEN NULL;
END $$;

ALTER TABLE public.courier_profiles ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "cp_select_own" ON public.courier_profiles;
CREATE POLICY "cp_select_own" ON public.courier_profiles
  FOR SELECT TO authenticated USING (user_id = auth.uid());

GRANT SELECT, INSERT, UPDATE ON public.courier_profiles TO service_role, postgres;

-- ── 3. credit_user_wallet ─────────────────────────────────────────────────────
--
-- Atomically:
--   a) CAS-updates wallet_transactions (pending → completed) using the UUID PK
--      so duplicate webhook replays are silently dropped.
--   b) Credits profiles.wallet_balance (read by CourierDashboardPage.tsx via
--      Realtime subscription on the `profiles` table).
--   c) Syncs courier_profiles.balance if a row exists (no-op otherwise).
--
-- Called exclusively by: api/webhook/gateway.ts (service_role key).
-- ==============================================================================
CREATE OR REPLACE FUNCTION public.credit_user_wallet(
  p_user_id UUID,
  p_amount  NUMERIC,
  p_tx_id   UUID,
  p_pay_id  TEXT DEFAULT NULL
)
RETURNS VOID
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_rows INTEGER;
BEGIN
  -- Step 1: CAS — only mark completed if the row is still pending.
  --   This is the primary double-credit guard: if LengoPay retries the webhook
  --   the row is already 'completed', GET DIAGNOSTICS returns 0, and we skip
  --   all balance updates below.
  UPDATE public.wallet_transactions
     SET status     = 'completed',
         pay_id     = COALESCE(p_pay_id, pay_id),
         updated_at = NOW()
   WHERE id     = p_tx_id
     AND status = 'pending';

  GET DIAGNOSTICS v_rows = ROW_COUNT;

  -- Step 2: Credit balances only when the CAS succeeded (1 row updated).
  IF v_rows > 0 THEN

    -- 2a. Main user balance — CourierDashboardPage reads profiles.wallet_balance
    --     and the Realtime subscription fires on this UPDATE to push live balance.
    UPDATE public.profiles
       SET wallet_balance = COALESCE(wallet_balance, 0) + p_amount,
           updated_at     = NOW()
     WHERE id = p_user_id;

    -- 2b. Courier secondary balance — kept in sync when the row exists.
    --     Silently skipped (0 rows updated) for regular client accounts.
    UPDATE public.courier_profiles
       SET balance    = COALESCE(balance, 0) + p_amount,
           updated_at = NOW()
     WHERE user_id = p_user_id;

  END IF;
END;
$$;

-- Permissions: service_role only — never callable from the browser.
REVOKE ALL    ON FUNCTION public.credit_user_wallet(UUID, NUMERIC, UUID, TEXT) FROM PUBLIC;
REVOKE ALL    ON FUNCTION public.credit_user_wallet(UUID, NUMERIC, UUID, TEXT) FROM authenticated;
GRANT EXECUTE ON FUNCTION public.credit_user_wallet(UUID, NUMERIC, UUID, TEXT) TO service_role;

-- Reload PostgREST schema cache
NOTIFY pgrst, 'reload schema';
