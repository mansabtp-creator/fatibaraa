-- Migration: auto_cancel_stale_pending_orders (H-4 audit fix)
-- Problem:  If LengoPay payment init fails AND the client-side cancel RPC also
--           fails (network drop, tab closed), orders remain stuck as 'pending'
--           forever, locking stock and preventing re-purchase.
-- Solution: A pg_cron job that runs every 10 minutes to cancel any mobile-money
--           pending orders older than 15 minutes, restoring stock atomically.

-- ── 1. Ensure pg_cron extension is available ─────────────────────────────────
CREATE EXTENSION IF NOT EXISTS pg_cron;

-- ── 2. Helper function called by the cron job ─────────────────────────────────
CREATE OR REPLACE FUNCTION public.cancel_stale_pending_orders()
RETURNS INT
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_cancelled INT := 0;
  v_order     RECORD;
BEGIN
  FOR v_order IN
    SELECT id
    FROM public.orders
    WHERE status = 'pending'
      AND payment_method IN ('orange', 'mtn')
      AND created_at < NOW() - INTERVAL '15 minutes'
    FOR UPDATE SKIP LOCKED   -- safe for concurrent invocations
  LOOP
    -- Cancel and restore stock in one atomic step
    BEGIN
      PERFORM public.cancel_unpaid_mobile_order(
        v_order.id,
        'Expiration automatique — paiement non reçu après 15 min'
      );
      v_cancelled := v_cancelled + 1;
    EXCEPTION WHEN OTHERS THEN
      -- Log but continue; don't abort the whole batch for one bad row
      RAISE WARNING 'cancel_stale_pending_orders: failed for order %, error: %', v_order.id, SQLERRM;
    END;
  END LOOP;

  RETURN v_cancelled;
END;
$$;

COMMENT ON FUNCTION public.cancel_stale_pending_orders() IS
'H-4 audit fix: called by pg_cron every 10 minutes to cancel mobile-money
orders stuck in status=pending older than 15 minutes. Returns the count of
orders cancelled. Uses SKIP LOCKED so concurrent invocations are safe.';

-- ── 3. Schedule the cron job ──────────────────────────────────────────────────
-- Runs every 10 minutes via pg_cron (requires pg_cron to be enabled in Supabase dashboard)
SELECT cron.schedule(
  'cancel-stale-pending-orders',   -- job name (idempotent)
  '*/10 * * * *',                   -- every 10 minutes
  'SELECT public.cancel_stale_pending_orders()'
);

NOTIFY pgrst, 'reload schema';
