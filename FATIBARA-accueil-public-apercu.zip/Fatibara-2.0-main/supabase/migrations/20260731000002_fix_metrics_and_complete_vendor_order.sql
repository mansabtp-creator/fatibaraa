-- =============================================================================
-- Migration: Fix get_vendor_dashboard_metrics column + add complete_vendor_order
-- Created:   2026-07-31
--
-- Fixes:
--   1. get_vendor_dashboard_metrics used `total_price` which does not exist.
--      The correct column is `total_amount`. → was returning 400 on every call.
--
--   2. complete_vendor_order was only in the project root fix_vendor_fulfillment.sql
--      and was never applied to production → 400 on every delivery confirmation.
--      This migration recreates it correctly:
--        - payment_method read from shipping_address->>'payment_method' (JSONB)
--          not from a column (the column does not exist on orders)
--        - Uses total_amount (not total_price)
--        - Handles COD vs digital payment correctly
-- =============================================================================

-- ── 1. Fix get_vendor_dashboard_metrics ──────────────────────────────────────
DROP FUNCTION IF EXISTS public.get_vendor_dashboard_metrics(UUID);

CREATE OR REPLACE FUNCTION public.get_vendor_dashboard_metrics(p_vendor_id UUID)
RETURNS JSON
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
    v_total_revenue    NUMERIC;
    v_completed_orders INT;
    v_pending_orders   INT;
    v_active_orders    INT;
BEGIN
    SELECT COALESCE(SUM(total_amount), 0)   -- ← was total_price (column does not exist)
    INTO v_total_revenue
    FROM public.orders
    WHERE vendor_id = p_vendor_id
      AND status IN ('paid', 'completed');

    SELECT COALESCE(COUNT(*), 0)
    INTO v_completed_orders
    FROM public.orders
    WHERE vendor_id = p_vendor_id
      AND status = 'completed';

    SELECT COALESCE(COUNT(*), 0)
    INTO v_pending_orders
    FROM public.orders
    WHERE vendor_id = p_vendor_id
      AND status IN ('pending', 'payment_pending');

    SELECT COALESCE(COUNT(*), 0)
    INTO v_active_orders
    FROM public.orders
    WHERE vendor_id = p_vendor_id
      AND status IN ('accepted', 'preparing', 'ready', 'shipping');

    RETURN json_build_object(
        'total_revenue',    COALESCE(v_total_revenue,    0),
        'completed_orders', COALESCE(v_completed_orders, 0),
        'pending_orders',   COALESCE(v_pending_orders,   0),
        'active_orders',    COALESCE(v_active_orders,    0)
    );
END;
$$;

GRANT EXECUTE ON FUNCTION public.get_vendor_dashboard_metrics(UUID) TO authenticated;
GRANT EXECUTE ON FUNCTION public.get_vendor_dashboard_metrics(UUID) TO service_role;

-- ── 2. complete_vendor_order ──────────────────────────────────────────────────
-- Called by VendorOrders.tsx when a vendor marks an order as delivered.
-- Parameters: target_order_id UUID, provided_otp TEXT
DROP FUNCTION IF EXISTS public.complete_vendor_order(UUID, TEXT);

CREATE OR REPLACE FUNCTION public.complete_vendor_order(
    target_order_id UUID,
    provided_otp    TEXT
)
RETURNS VOID
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
    v_order               public.orders%ROWTYPE;
    v_store_id            UUID;
    v_commission_str      TEXT;
    v_commission_rate     NUMERIC;
    v_items_real_value    NUMERIC := 0;
    v_platform_commission NUMERIC;
    v_vendor_payout       NUMERIC;
    v_courier_payout      NUMERIC;
    -- payment_method is stored in orders.shipping_address JSONB, NOT a column
    v_payment_method      TEXT;
    v_is_cash_payment     BOOLEAN;
    v_vendor_digital_delta  NUMERIC;
    v_courier_digital_delta NUMERIC;
BEGIN
    -- Lock the row to prevent race conditions
    SELECT * INTO v_order
    FROM public.orders
    WHERE id = target_order_id
    FOR UPDATE;

    IF NOT FOUND THEN
        RAISE EXCEPTION 'Order not found';
    END IF;

    IF v_order.vendor_id != auth.uid() THEN
        RAISE EXCEPTION 'Unauthorized: You do not own this order';
    END IF;

    -- Idempotency guard
    IF v_order.financial_status = 'processed' OR v_order.status = 'delivered' THEN
        RAISE EXCEPTION 'Order financials already processed';
    END IF;

    -- State machine guard
    IF v_order.status NOT IN ('ready', 'ready_for_pickup', 'in_transit', 'shipping', 'accepted', 'preparing') THEN
        RAISE EXCEPTION 'Order status "%" cannot be transitioned to delivered', v_order.status;
    END IF;

    -- OTP validation (only when an OTP was set)
    IF v_order.delivery_otp IS NOT NULL AND v_order.delivery_otp != '' THEN
        IF provided_otp IS NULL OR provided_otp != v_order.delivery_otp THEN
            RAISE EXCEPTION 'Invalid delivery OTP';
        END IF;
    END IF;

    -- Resolve store_id from order items, fallback to vendor's store
    SELECT COALESCE(
        (SELECT p.store_id
         FROM public.order_items oi
         JOIN public.products p ON oi.product_id = p.id
         WHERE oi.order_id = target_order_id
         LIMIT 1),
        (SELECT id FROM public.stores WHERE owner_id = v_order.vendor_id LIMIT 1)
    ) INTO v_store_id;

    -- Read payment method from JSONB (the column does not exist on orders)
    v_payment_method := COALESCE(
        v_order.shipping_address->>'payment_method',
        CASE WHEN v_order.financial_status = 'paid' THEN 'wallet' ELSE 'cash' END
    );
    v_is_cash_payment := (v_payment_method = 'cash');

    -- Commission rate from platform_settings (default 5%)
    SELECT value INTO v_commission_str
    FROM public.platform_settings WHERE id = 'commission_rate';
    v_commission_rate := COALESCE(NULLIF(v_commission_str, '')::NUMERIC, 5) / 100.0;

    -- Calculate item value from order_items; fallback to total_amount
    SELECT COALESCE(SUM(price_at_purchase * quantity), 0)
    INTO v_items_real_value
    FROM public.order_items
    WHERE order_id = target_order_id;

    IF v_items_real_value = 0 THEN
        v_items_real_value := COALESCE(v_order.total_amount, 0) - COALESCE(v_order.delivery_fee, 0);
    END IF;

    -- Financial math
    -- Vendor payout = item value after commission, minus vendor_delivery_fee (if they handle delivery)
    v_vendor_payout := (v_items_real_value / (1 + v_commission_rate))
                        * (1 - v_commission_rate)
                        - COALESCE(v_order.vendor_delivery_fee, 0);
    v_platform_commission := (v_items_real_value / (1 + v_commission_rate)) * v_commission_rate;

    -- Courier payout (80% of delivery fee)
    IF COALESCE(v_order.delivery_fee, 0) > 0 THEN
        v_courier_payout := v_order.delivery_fee * 0.8;
    ELSE
        v_courier_payout := COALESCE(v_order.vendor_delivery_fee, 0) * 0.8;
    END IF;

    -- If no courier, vendor absorbs courier payout
    IF v_order.courier_id IS NULL THEN
        v_vendor_payout := v_vendor_payout + v_courier_payout;
    END IF;

    -- For COD with no courier: vendor collected cash → deduct total_amount from digital balance
    v_vendor_digital_delta := v_vendor_payout;
    IF v_is_cash_payment AND v_order.courier_id IS NULL THEN
        v_vendor_digital_delta := v_vendor_payout - COALESCE(v_order.total_amount, 0);
    END IF;

    -- Credit vendor store balance
    IF v_vendor_digital_delta != 0 AND v_store_id IS NOT NULL THEN
        UPDATE public.stores
        SET balance = balance + ROUND(v_vendor_digital_delta)
        WHERE id = v_store_id;

        INSERT INTO public.wallet_transactions
            (store_id, profile_id, amount, type, reference_id, description)
        VALUES (
            v_store_id,
            v_order.vendor_id,
            ROUND(v_vendor_digital_delta),
            CASE WHEN v_vendor_digital_delta > 0 THEN 'sale' ELSE 'fee' END,
            target_order_id,
            'Vente #' || left(target_order_id::text, 8)
        );
    END IF;

    -- Credit courier balance (if assigned)
    IF v_order.courier_id IS NOT NULL THEN
        v_courier_digital_delta := v_courier_payout;
        IF v_is_cash_payment THEN
            v_courier_digital_delta := v_courier_payout - COALESCE(v_order.total_amount, 0);
        END IF;

        IF v_courier_digital_delta != 0 THEN
            -- Only update if wallet won't go negative
            IF v_courier_digital_delta > 0 OR
               (SELECT wallet_balance FROM public.profiles WHERE id = v_order.courier_id) >= ABS(v_courier_digital_delta)
            THEN
                UPDATE public.profiles
                SET wallet_balance = wallet_balance + ROUND(v_courier_digital_delta)
                WHERE id = v_order.courier_id;

                INSERT INTO public.wallet_transactions
                    (profile_id, amount, type, reference_id, description)
                VALUES (
                    v_order.courier_id,
                    ROUND(v_courier_digital_delta),
                    CASE WHEN v_courier_digital_delta > 0 THEN 'delivery_fee' ELSE 'fee' END,
                    target_order_id,
                    'Course #' || left(target_order_id::text, 8)
                );
            END IF;
        END IF;
    END IF;

    -- Log platform commission
    INSERT INTO public.platform_logs (type, amount, reference_id, metadata)
    VALUES (
        'commission',
        ROUND(v_platform_commission),
        target_order_id,
        jsonb_build_object(
            'order_total', v_order.total_amount,
            'vendor_id',   v_order.vendor_id,
            'payment',     v_payment_method
        )
    );

    -- Mark order as delivered and financially processed
    UPDATE public.orders
    SET status           = 'delivered',
        financial_status = 'processed',
        updated_at       = now()
    WHERE id = target_order_id;
END;
$$;

GRANT EXECUTE ON FUNCTION public.complete_vendor_order(UUID, TEXT) TO authenticated;
GRANT EXECUTE ON FUNCTION public.complete_vendor_order(UUID, TEXT) TO service_role;

-- Signal PostgREST to reload its schema cache
NOTIFY pgrst, 'reload schema';
