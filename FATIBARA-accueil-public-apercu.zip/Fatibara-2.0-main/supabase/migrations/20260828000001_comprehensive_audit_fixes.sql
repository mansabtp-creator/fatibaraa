-- ==============================================================================
-- MIGRATION: 20260828000001_comprehensive_audit_fixes.sql
-- Fatibara 2.0 — Comprehensive Schema, RLS & RPC Audit Fixes
-- Date: 2026-08-28
--
-- FIXES (in order of severity):
--
--   [C-1] CRITICAL — handle_new_user trigger did not copy `role` from metadata.
--         Every new signup got profile_type='client' regardless of their
--         intended role. Auth redirects and dashboard isolation depended on
--         this value being correct at registration time.
--
--   [C-2] CRITICAL — courier_profiles missing vehicle_type, status, active_capacity.
--         Dispatch logic and the courier dashboard tab read these columns.
--         Missing columns caused silent null reads and incorrect courier lists.
--
--   [H-1] HIGH — courier_profiles had only one SELECT policy (own row).
--         Admin panel could not write to courier_profiles at all.
--         Couriers could not update their own profile fields (only SELECT).
--
--   [H-2] HIGH — vendors whose orders are linked via store_id (not vendor_id
--         directly) could not SELECT those orders — empty list, 406 null.
--         Added a supplementary SELECT policy based on store ownership.
--
--   [M-1] MEDIUM — wallet_transactions.type CHECK was missing 'topup'.
--         If payin.ts inserts a pending row with type='topup', the INSERT
--         fails (CHECK violation) → webhook has no row to CAS-update →
--         silent top-up failure.
--
--   [M-2] MEDIUM — secure_process_order_financials credited profiles.wallet_balance
--         for couriers but never synced courier_profiles.balance.
--         CourierDashboardPage reads courier_profiles.balance separately →
--         drift after every delivery settlement.
--
--   [M-3] MEDIUM — profiles table had no updated_at column, but credit_user_wallet
--         and secure_process_order_financials both SET updated_at = NOW().
--         This causes a runtime error in some Postgres versions.
--
--   [L-3] LOW — approve_withdrawal used a raw EXISTS subquery into profiles
--         instead of public.is_admin() (inconsistent + slightly less efficient).
-- ==============================================================================

-- ==============================================================================
-- FIX M-3: Add updated_at to profiles (idempotent)
-- ==============================================================================
ALTER TABLE public.profiles
  ADD COLUMN IF NOT EXISTS updated_at TIMESTAMPTZ DEFAULT NOW();

-- Backfill existing rows so updated_at = created_at (not NULL)
UPDATE public.profiles
SET updated_at = COALESCE(created_at, NOW())
WHERE updated_at IS NULL;

-- ==============================================================================
-- FIX C-2: Add missing columns to courier_profiles
-- ==============================================================================

ALTER TABLE public.courier_profiles
  ADD COLUMN IF NOT EXISTS vehicle_type    TEXT DEFAULT 'motorcycle'
    CHECK (vehicle_type IS NULL OR vehicle_type IN (
      'motorcycle', 'moto',       -- both naming conventions
      'car',        'voiture',
      'bicycle',    'velo',
      'foot'
    )),
  ADD COLUMN IF NOT EXISTS status          TEXT DEFAULT 'pending'
    CHECK (status IN ('pending', 'active', 'suspended', 'inactive')),
  ADD COLUMN IF NOT EXISTS active_capacity INTEGER DEFAULT 1
    CHECK (active_capacity BETWEEN 0 AND 10);

-- Index for active courier dispatch lookups
CREATE INDEX IF NOT EXISTS idx_courier_profiles_status
  ON public.courier_profiles (status)
  WHERE status IS NOT NULL;

-- Sync vehicle_type from profiles.vehicle_type where it is already set
-- (courier_fleet_migration.sql stored vehicle_type on profiles)
UPDATE public.courier_profiles cp
SET vehicle_type = p.vehicle_type
FROM public.profiles p
WHERE cp.user_id = p.id
  AND p.vehicle_type IS NOT NULL
  AND cp.vehicle_type IS NULL;

-- Activate couriers whose profiles already show them as couriers
UPDATE public.courier_profiles cp
SET status = 'active'
FROM public.profiles p
WHERE cp.user_id = p.id
  AND p.profile_type = 'courier'
  AND p.is_courier_online = true
  AND cp.status = 'pending';

-- ==============================================================================
-- FIX H-1: Full RLS policy set for courier_profiles
-- ==============================================================================

-- Own-row SELECT (already existed — keep idempotent)
DROP POLICY IF EXISTS "cp_select_own" ON public.courier_profiles;
CREATE POLICY "cp_select_own"
ON public.courier_profiles FOR SELECT TO authenticated
USING (user_id = auth.uid() OR public.is_admin());

-- Couriers can UPDATE their own profile (toggle availability, etc.)
DROP POLICY IF EXISTS "cp_update_own" ON public.courier_profiles;
CREATE POLICY "cp_update_own"
ON public.courier_profiles FOR UPDATE TO authenticated
USING (user_id = auth.uid() OR public.is_admin())
WITH CHECK (user_id = auth.uid() OR public.is_admin());

-- Admin full access (view all couriers, suspend, approve)
DROP POLICY IF EXISTS "cp_admin_all" ON public.courier_profiles;
CREATE POLICY "cp_admin_all"
ON public.courier_profiles FOR ALL TO authenticated
USING (public.is_admin())
WITH CHECK (public.is_admin());

-- Couriers can INSERT their own profile row (first login onboarding)
DROP POLICY IF EXISTS "cp_insert_own" ON public.courier_profiles;
CREATE POLICY "cp_insert_own"
ON public.courier_profiles FOR INSERT TO authenticated
WITH CHECK (user_id = auth.uid());

-- Grants (belt-and-suspenders)
GRANT SELECT, INSERT, UPDATE ON public.courier_profiles TO authenticated;
GRANT ALL ON public.courier_profiles TO service_role, postgres;

-- ==============================================================================
-- FIX C-1: Enrich handle_new_user trigger with role metadata
-- ==============================================================================
-- Maps raw_user_meta_data->>'role' from the signup call to a valid profile_type.
-- The frontend sends { role: 'customer' | 'vendor' | 'courier' } in the options
-- object of supabase.auth.signUp().
-- The trigger also seeds the roles[] array and active_role so multi-role switching
-- works from day one.

CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_raw_role     TEXT;
  v_profile_type TEXT;
BEGIN
  -- Read the role hint from signup metadata (falls back to 'client')
  v_raw_role := LOWER(COALESCE(
    NEW.raw_user_meta_data->>'role',
    NEW.raw_user_meta_data->>'profile_type',
    'client'
  ));

  -- Normalise to a valid profile_type enum value
  v_profile_type := CASE v_raw_role
    WHEN 'customer'  THEN 'client'
    WHEN 'client'    THEN 'client'
    WHEN 'vendor'    THEN 'vendor'
    WHEN 'courier'   THEN 'courier'
    WHEN 'livreur'   THEN 'courier'   -- French alias used in legacy flows
    WHEN 'admin'     THEN 'admin'
    ELSE                  'client'    -- safe default
  END;

  INSERT INTO public.profiles (
    id,
    full_name,
    profile_type,
    roles,
    active_role,
    created_at,
    updated_at
  )
  VALUES (
    NEW.id,
    COALESCE(
      NEW.raw_user_meta_data->>'full_name',
      NEW.raw_user_meta_data->>'name',
      split_part(NEW.email, '@', 1)  -- friendly fallback
    ),
    v_profile_type,
    -- Seed the roles array (multi-role switching support)
    CASE v_profile_type
      WHEN 'vendor'  THEN ARRAY['vendor',  'customer']::TEXT[]
      WHEN 'courier' THEN ARRAY['courier', 'customer']::TEXT[]
      WHEN 'admin'   THEN ARRAY['admin',   'vendor', 'courier', 'customer']::TEXT[]
      ELSE                ARRAY['customer']::TEXT[]
    END,
    -- active_role mirrors profile_type (courier/vendor see their dashboard first)
    CASE v_profile_type
      WHEN 'client' THEN 'customer'
      ELSE v_profile_type
    END,
    NOW(),
    NOW()
  )
  ON CONFLICT (id) DO NOTHING;

  RETURN NEW;
END;
$$;

-- Re-attach the trigger (DROP + CREATE is idempotent)
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- ==============================================================================
-- FIX H-2: Vendors can SELECT orders linked to their store (not just vendor_id)
-- ==============================================================================
-- Problem: vendor_id on orders points to profiles.id, but some orders are only
-- linked via store_id. A vendor whose store_id is set but vendor_id is NULL on
-- the order row cannot SELECT those orders → empty list (406).
--
-- Solution: add a supplementary SELECT policy. We keep orders_select_v3 intact
-- and add orders_vendor_store_select alongside it. Multiple SELECT policies
-- are OR-combined by Postgres — no recursion risk (different tables in EXISTS).

DROP POLICY IF EXISTS "orders_vendor_store_select" ON public.orders;
CREATE POLICY "orders_vendor_store_select"
ON public.orders FOR SELECT TO authenticated
USING (
  -- Vendor owns the store that fulfilled this order
  store_id IN (
    SELECT id FROM public.stores WHERE owner_id = auth.uid()
  )
);

-- ==============================================================================
-- FIX M-1: Add 'topup' to wallet_transactions.type CHECK
-- ==============================================================================
-- payin.ts (and some legacy webhook paths) may insert rows with type='topup'.
-- Without this value in the CHECK, those inserts silently fail → the webhook
-- has no pending row to CAS-update → top-up balance is never credited.

ALTER TABLE public.wallet_transactions
  DROP CONSTRAINT IF EXISTS wallet_transactions_type_check;

ALTER TABLE public.wallet_transactions
  ADD CONSTRAINT wallet_transactions_type_check
  CHECK (type IN (
    'purchase',
    'sale',
    'refund',
    'fee',
    'delivery_fee',
    'withdrawal',
    'withdrawal_approved',
    'deposit',
    'topup',              -- LengoPay payin.ts pending rows
    'boost',
    'credit'
  ));

-- ==============================================================================
-- FIX M-2: Sync courier_profiles.balance inside secure_process_order_financials
-- ==============================================================================
-- The settlement function credits profiles.wallet_balance for couriers but
-- never mirrors the change to courier_profiles.balance.
-- CourierDashboardPage reads courier_profiles.balance → the two balances drift
-- after every delivery.  This replacement adds the sync step.

CREATE OR REPLACE FUNCTION public.secure_process_order_financials(p_order_id uuid)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
    v_order                        RECORD;
    v_store                        RECORD;
    v_existing_tx                  BOOLEAN;
    v_commission_str               TEXT;
    v_commission_rate              NUMERIC;
    v_items_real_value             NUMERIC;
    v_item_subtotal                NUMERIC;
    v_platform_commission          NUMERIC;
    v_vendor_payout                NUMERIC;
    v_courier_payout               NUMERIC;
    v_is_cash_payment              BOOLEAN;
    v_final_vendor_digital_change  NUMERIC;
    v_final_courier_digital_change NUMERIC;
    v_courier_balance              NUMERIC;
    v_vendor_description           TEXT;
BEGIN
    -- ── A. Lock order row ────────────────────────────────────────────────────
    SELECT * INTO v_order FROM public.orders WHERE id = p_order_id FOR UPDATE;
    IF NOT FOUND THEN RAISE EXCEPTION 'Order not found'; END IF;

    -- ── B. Idempotency guard ─────────────────────────────────────────────────
    IF v_order.financial_status = 'processed' THEN
        RETURN jsonb_build_object('success', true, 'alreadyProcessed', true);
    END IF;

    SELECT EXISTS (
        SELECT 1 FROM public.wallet_transactions
        WHERE reference_id = p_order_id::TEXT AND type = 'sale'
    ) INTO v_existing_tx;

    IF v_existing_tx THEN
        UPDATE public.orders SET financial_status = 'processed' WHERE id = p_order_id;
        RETURN jsonb_build_object('success', true, 'alreadyProcessed', true);
    END IF;

    -- ── C. Resolve store ─────────────────────────────────────────────────────
    SELECT * INTO v_store FROM public.stores
    WHERE id = v_order.store_id
       OR (v_order.store_id IS NULL AND owner_id = v_order.vendor_id)
    LIMIT 1;

    -- ── D. Commission arithmetic ─────────────────────────────────────────────
    v_items_real_value := v_order.total_amount - COALESCE(v_order.delivery_fee, 0);

    SELECT value INTO v_commission_str FROM public.platform_settings WHERE id = 'commission_rate';
    IF v_commission_str IS NULL THEN v_commission_str := '5'; END IF;
    v_commission_rate := v_commission_str::numeric / 100.0;

    v_item_subtotal       := v_items_real_value / (1 + v_commission_rate);
    v_platform_commission := v_item_subtotal * v_commission_rate;
    v_vendor_payout       := v_item_subtotal - COALESCE(v_order.vendor_delivery_fee, 0);
    v_courier_payout      := (CASE WHEN COALESCE(v_order.delivery_fee, 0) > 0
                                   THEN v_order.delivery_fee
                                   ELSE COALESCE(v_order.vendor_delivery_fee, 0) END) * 0.8;

    IF v_order.courier_id IS NULL THEN
        v_vendor_payout := v_vendor_payout + v_courier_payout;
    END IF;

    v_is_cash_payment := COALESCE(
        (v_order.shipping_address->>'payment_method') = 'cash',
        v_order.financial_status != 'paid'
    );

    -- ── E. Vendor payout ─────────────────────────────────────────────────────
    IF v_store.id IS NOT NULL THEN
        v_final_vendor_digital_change := v_vendor_payout;

        IF v_is_cash_payment AND v_order.courier_id IS NULL THEN
            v_final_vendor_digital_change := v_vendor_payout - v_order.total_amount;
        END IF;

        IF v_final_vendor_digital_change != 0 THEN
            UPDATE public.stores
            SET balance = COALESCE(balance, 0) + ROUND(v_final_vendor_digital_change)
            WHERE id = v_store.id;

            IF v_is_cash_payment AND v_order.courier_id IS NULL THEN
                v_vendor_description :=
                    'Collecte Cash directe — Retenue commission Commande #'
                    || left(v_order.id::text, 8);
            ELSIF v_is_cash_payment AND v_order.courier_id IS NOT NULL THEN
                v_vendor_description :=
                    'Vente Cash à la livraison (Commande #'
                    || left(v_order.id::text, 8) || ')';
            ELSE
                v_vendor_description :=
                    'Vente #' || left(v_order.id::text, 8)
                    || ' (Payout ' || ROUND(v_item_subtotal) || ')';
            END IF;

            INSERT INTO public.wallet_transactions
              (profile_id, store_id, amount, type, reference_id, description)
            VALUES (
                v_order.vendor_id,
                v_store.id,
                v_final_vendor_digital_change,
                CASE WHEN v_final_vendor_digital_change > 0 THEN 'sale' ELSE 'fee' END,
                v_order.id::TEXT,
                v_vendor_description
            );
        END IF;
    END IF;

    -- ── F. Courier payout — with COD negative-balance guard ──────────────────
    IF v_order.courier_id IS NOT NULL THEN
        v_final_courier_digital_change := v_courier_payout;
        IF v_is_cash_payment THEN
            v_final_courier_digital_change := v_courier_payout - v_order.total_amount;
        END IF;

        IF v_final_courier_digital_change != 0 THEN
            IF v_final_courier_digital_change < 0 THEN
                SELECT wallet_balance INTO v_courier_balance
                FROM public.profiles
                WHERE id = v_order.courier_id
                FOR UPDATE;

                IF v_courier_balance + v_final_courier_digital_change < 0 THEN
                    RETURN jsonb_build_object(
                        'success',        false,
                        'error',          'cod_courier_insufficient_balance',
                        'message',        format(
                            'Courier wallet too low for COD settlement. Balance: %s GNF, Required: %s GNF. Order flagged for manual collection.',
                            ROUND(v_courier_balance),
                            ROUND(abs(v_final_courier_digital_change))
                        ),
                        'courierBalance', ROUND(v_courier_balance),
                        'debtAmount',     ROUND(abs(v_final_courier_digital_change))
                    );
                END IF;
            END IF;

            -- Credit profiles.wallet_balance
            UPDATE public.profiles
            SET wallet_balance = wallet_balance + ROUND(v_final_courier_digital_change),
                updated_at     = NOW()
            WHERE id = v_order.courier_id;

            -- ── FIX M-2: Sync courier_profiles.balance ──────────────────────
            -- Mirror the same amount change so CourierDashboardPage stays in sync.
            UPDATE public.courier_profiles
            SET balance    = COALESCE(balance, 0) + ROUND(v_final_courier_digital_change),
                updated_at = NOW()
            WHERE user_id = v_order.courier_id;

            INSERT INTO public.wallet_transactions
              (profile_id, amount, type, reference_id, description)
            VALUES (
                v_order.courier_id,
                v_final_courier_digital_change,
                CASE WHEN v_final_courier_digital_change > 0 THEN 'delivery_fee' ELSE 'fee' END,
                v_order.id::TEXT,
                CASE WHEN v_is_cash_payment
                     THEN 'Collecte Cash — Remise Plateforme Commande #'
                          || left(v_order.id::text, 8)
                     ELSE 'Course effectuée — Commande #'
                          || left(v_order.id::text, 8)
                END
            );
        END IF;
    END IF;

    -- ── G. Platform commission log ────────────────────────────────────────────
    INSERT INTO public.platform_logs (type, amount, reference_id, metadata)
    VALUES (
        'commission',
        ROUND(v_platform_commission),
        v_order.id,
        jsonb_build_object(
            'order_total',  v_order.total_amount,
            'vendor_id',    v_order.vendor_id,
            'is_cash',      v_is_cash_payment
        )
    );

    -- ── H. Mark order as financially settled ──────────────────────────────────
    UPDATE public.orders SET financial_status = 'processed' WHERE id = p_order_id;

    RETURN jsonb_build_object(
        'success',            true,
        'vendorPayout',       ROUND(v_vendor_payout),
        'courierPayout',      ROUND(v_courier_payout),
        'platformCommission', ROUND(v_platform_commission)
    );
END;
$$;

GRANT EXECUTE ON FUNCTION public.secure_process_order_financials(uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION public.secure_process_order_financials(uuid) TO service_role;

-- ==============================================================================
-- FIX L-3: Normalize approve_withdrawal to use public.is_admin()
-- ==============================================================================
-- Replaces the raw EXISTS subquery (which re-reads profiles under RLS)
-- with the STABLE SECURITY DEFINER public.is_admin() helper for consistency
-- and to avoid any future 42P17 edge-cases.

CREATE OR REPLACE FUNCTION public.approve_withdrawal(p_withdrawal_id UUID)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
    v_withdrawal RECORD;
BEGIN
    -- Admin-only guard using the canonical helper (avoids raw profiles subquery)
    IF NOT public.is_admin() THEN
        RAISE EXCEPTION 'Unauthorized: Admin access required.';
    END IF;

    SELECT * INTO v_withdrawal
    FROM public.withdrawals
    WHERE id = p_withdrawal_id
    FOR UPDATE;

    IF NOT FOUND THEN
        RETURN jsonb_build_object(
            'success', false,
            'message', 'Withdrawal request not found.'
        );
    END IF;

    IF v_withdrawal.status != 'pending' THEN
        RETURN jsonb_build_object(
            'success',          true,
            'alreadyProcessed', true,
            'status',           v_withdrawal.status
        );
    END IF;

    UPDATE public.withdrawals
    SET
        status       = 'processed',
        processed_at = NOW(),
        processed_by = auth.uid()
    WHERE id = p_withdrawal_id;

    INSERT INTO public.wallet_transactions (
        store_id, profile_id, amount, type, reference_id, description, status
    ) VALUES (
        v_withdrawal.store_id,
        v_withdrawal.profile_id,
        0,
        'withdrawal_approved',
        v_withdrawal.id::TEXT,
        'Retrait approuvé par admin — ' || COALESCE(v_withdrawal.method, '') ||
        ' (' || COALESCE(v_withdrawal.phone, '') || ')',
        'completed'
    );

    RETURN jsonb_build_object('success', true, 'message', 'Withdrawal approved successfully.');

EXCEPTION WHEN OTHERS THEN
    RETURN jsonb_build_object('success', false, 'message', SQLERRM);
END;
$$;

GRANT EXECUTE ON FUNCTION public.approve_withdrawal(UUID) TO authenticated;

COMMENT ON FUNCTION public.approve_withdrawal(UUID) IS
  'Admin-only: marks a withdrawal as processed. Balance was already deducted at request time.
   Inserts a zero-amount audit trail row into wallet_transactions.
   Returns JSONB { success, message?, alreadyProcessed?, status? }.
   Uses public.is_admin() helper to avoid raw profiles subquery (42P17-safe).';

-- ==============================================================================
-- SECTION: Ensure Realtime covers courier_profiles (new table)
-- ==============================================================================
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_publication_tables
    WHERE pubname = 'supabase_realtime'
      AND schemaname = 'public'
      AND tablename = 'courier_profiles'
  ) THEN
    ALTER PUBLICATION supabase_realtime ADD TABLE public.courier_profiles;
    RAISE NOTICE 'Added courier_profiles to supabase_realtime publication.';
  END IF;
END $$;

-- ==============================================================================
-- SECTION: Add missing indexes for audit-required FK columns
-- ==============================================================================

-- courier_profiles → profiles
CREATE INDEX IF NOT EXISTS idx_courier_profiles_user_id
  ON public.courier_profiles (user_id);

-- wallet_transactions — ensure TEXT reference_id index still exists after type change
CREATE INDEX IF NOT EXISTS idx_wt_reference_id_text
  ON public.wallet_transactions (reference_id)
  WHERE reference_id IS NOT NULL;

-- ==============================================================================
-- FINAL: Flush PostgREST schema cache
-- ==============================================================================
NOTIFY pgrst, 'reload schema';
