-- ==============================================================================
-- BOOST CAMPAIGNS — TABLE, RLS & ATOMIC PAYMENT RPC
-- Run this migration in Supabase SQL editor
-- ==============================================================================

-- 1. BOOST CAMPAIGNS TABLE
CREATE TABLE IF NOT EXISTS public.boost_campaigns (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  store_id        UUID NOT NULL REFERENCES public.stores(id) ON DELETE CASCADE,
  campaign_type   TEXT NOT NULL CHECK (campaign_type IN ('visibility', 'conversion')),
  duration_label  TEXT NOT NULL,
  duration_days   INTEGER NOT NULL CHECK (duration_days > 0),
  budget_gnf      NUMERIC NOT NULL CHECK (budget_gnf > 0),
  status          TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'expired', 'cancelled')),
  launched_at     TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  expires_at      TIMESTAMPTZ,  -- populated by trg_set_boost_expires_at trigger
  created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Index for fast store lookups
CREATE INDEX IF NOT EXISTS idx_boost_campaigns_store_id ON public.boost_campaigns(store_id);
CREATE INDEX IF NOT EXISTS idx_boost_campaigns_status ON public.boost_campaigns(status);

-- Auto-expire campaigns past their end date
CREATE INDEX IF NOT EXISTS idx_boost_campaigns_expires_at ON public.boost_campaigns(expires_at);

-- Trigger: compute expires_at = launched_at + duration_days (avoids TIMESTAMPTZ immutability issue)
CREATE OR REPLACE FUNCTION public.set_boost_campaign_expires_at()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
BEGIN
  NEW.expires_at := NEW.launched_at + (NEW.duration_days * INTERVAL '1 day');
  RETURN NEW;
END;
$$;

CREATE OR REPLACE TRIGGER trg_set_boost_expires_at
  BEFORE INSERT OR UPDATE OF launched_at, duration_days
  ON public.boost_campaigns
  FOR EACH ROW EXECUTE FUNCTION public.set_boost_campaign_expires_at();

-- 2. ROW LEVEL SECURITY
ALTER TABLE public.boost_campaigns ENABLE ROW LEVEL SECURITY;

-- Vendors can read their own campaigns
DROP POLICY IF EXISTS "Vendors read own boost campaigns" ON public.boost_campaigns;
CREATE POLICY "Vendors read own boost campaigns"
  ON public.boost_campaigns FOR SELECT
  USING (
    store_id IN (
      SELECT id FROM public.stores WHERE owner_id = auth.uid()
    )
  );

-- Vendors can insert their own campaigns (only via RPC, so this is a safety net)
DROP POLICY IF EXISTS "Vendors insert own boost campaigns" ON public.boost_campaigns;
CREATE POLICY "Vendors insert own boost campaigns"
  ON public.boost_campaigns FOR INSERT
  WITH CHECK (
    store_id IN (
      SELECT id FROM public.stores WHERE owner_id = auth.uid()
    )
  );

-- Admins have full access
DROP POLICY IF EXISTS "Admins full access boost campaigns" ON public.boost_campaigns;
CREATE POLICY "Admins full access boost campaigns"
  ON public.boost_campaigns FOR ALL
  USING (
    EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND is_admin = true)
  );

-- 3. ATOMIC BOOST PAYMENT RPC
-- Uses SECURITY DEFINER + FOR UPDATE lock to prevent race conditions / overdrafts
CREATE OR REPLACE FUNCTION public.launch_boost_campaign(
  p_store_id      UUID,
  p_campaign_type TEXT,
  p_duration_label TEXT,
  p_duration_days INTEGER,
  p_budget_gnf    NUMERIC
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_user_id       UUID;
  v_store         RECORD;
  v_wallet        NUMERIC;
  v_campaign_id   UUID;
BEGIN
  v_user_id := auth.uid();
  IF v_user_id IS NULL THEN
    RAISE EXCEPTION 'Not authenticated';
  END IF;

  -- Validate input
  IF p_campaign_type NOT IN ('visibility', 'conversion') THEN
    RAISE EXCEPTION 'Invalid campaign type: %', p_campaign_type;
  END IF;
  IF p_budget_gnf <= 0 THEN
    RAISE EXCEPTION 'Budget must be positive';
  END IF;

  -- Verify store ownership
  SELECT * INTO v_store
  FROM public.stores
  WHERE id = p_store_id AND owner_id = v_user_id;

  IF v_store IS NULL THEN
    RAISE EXCEPTION 'Store not found or not owned by current user';
  END IF;

  -- Lock profile row and read balance
  SELECT wallet_balance INTO v_wallet
  FROM public.profiles
  WHERE id = v_user_id
  FOR UPDATE;

  IF v_wallet IS NULL THEN
    RAISE EXCEPTION 'User profile not found';
  END IF;

  IF v_wallet < p_budget_gnf THEN
    RAISE EXCEPTION 'Insufficient wallet balance — % GNF required, % GNF available',
      p_budget_gnf, v_wallet;
  END IF;

  -- 1. Deduct wallet
  UPDATE public.profiles
  SET wallet_balance = wallet_balance - p_budget_gnf
  WHERE id = v_user_id;

  -- 2. Create campaign record
  INSERT INTO public.boost_campaigns (
    store_id, campaign_type, duration_label,
    duration_days, budget_gnf, status, launched_at
  )
  VALUES (
    p_store_id, p_campaign_type, p_duration_label,
    p_duration_days, p_budget_gnf, 'active', NOW()
  )
  RETURNING id INTO v_campaign_id;

  -- 3. Log wallet transaction
  INSERT INTO public.wallet_transactions (
    profile_id, amount, type, reference_id, description, status
  )
  VALUES (
    v_user_id,
    -p_budget_gnf,
    'fee',
    v_campaign_id,
    'Boost ' || p_campaign_type || ' — ' || p_duration_label,
    'completed'
  );

  RETURN jsonb_build_object(
    'success',     true,
    'campaign_id', v_campaign_id,
    'new_balance', v_wallet - p_budget_gnf
  );
END;
$$;

-- Grant execute only to authenticated vendors
REVOKE EXECUTE ON FUNCTION public.launch_boost_campaign(UUID, TEXT, TEXT, INTEGER, NUMERIC) FROM PUBLIC;
GRANT  EXECUTE ON FUNCTION public.launch_boost_campaign(UUID, TEXT, TEXT, INTEGER, NUMERIC) TO authenticated;

-- 4. Helper function to auto-expire old campaigns (call from a cron job or trigger)
CREATE OR REPLACE FUNCTION public.expire_old_boost_campaigns()
RETURNS INTEGER
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_count INTEGER;
BEGIN
  UPDATE public.boost_campaigns
  SET status = 'expired'
  WHERE status = 'active'
    AND expires_at < NOW();

  GET DIAGNOSTICS v_count = ROW_COUNT;
  RETURN v_count;
END;
$$;
