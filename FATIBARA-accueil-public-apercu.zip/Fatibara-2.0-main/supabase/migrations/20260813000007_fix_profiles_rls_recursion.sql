-- =============================================================================
-- EMERGENCY FIX: 42P17 Infinite Recursion on `profiles` RLS
-- File:      supabase/migrations/20260813000007_fix_profiles_rls_recursion.sql
-- Created:   2026-08-13
--
-- ROOT CAUSE:
--   `20260813000004_harden_all_tables_rls.sql` introduced `profiles_admin_all`:
--
--     CREATE POLICY "profiles_admin_all" ON public.profiles FOR ALL
--     USING (EXISTS (SELECT 1 FROM public.profiles p
--                    WHERE p.id = auth.uid() AND p.is_admin = true));
--
--   This is self-referential: to evaluate whether a user can access any row
--   in `profiles`, Postgres evaluates the USING clause, which queries `profiles`
--   again, which triggers the same policy → 42P17 infinite loop.
--
--   Consequence: EVERY table that has a policy referencing
--     EXISTS (SELECT 1 FROM public.profiles WHERE ... is_admin = true)
--   is also broken because that sub-select hits the recursive `profiles` RLS.
--   This explains why products, stores, orders, notifications, announcements
--   ALL return HTTP 500 simultaneously.
--
-- SOLUTION — SECURITY DEFINER helper function (Supabase-recommended pattern):
--   1. Create `public.is_admin()` — a STABLE SECURITY DEFINER SQL function that
--      reads `profiles.is_admin` for the current user.  Because it runs as the
--      function owner (a superuser / postgres role) it bypasses RLS entirely,
--      breaking the recursion at the source.
--   2. Drop `profiles_admin_all` and replace it with a non-recursive version
--      that calls `public.is_admin()` instead of querying the table directly.
--   3. All other tables that reference `EXISTS (SELECT 1 FROM public.profiles
--      WHERE ... is_admin = true)` are fixed automatically because those
--      sub-selects no longer trigger the recursive profile SELECT policy.
--      (They only recurse because `profiles_admin_all` is FOR ALL including
--       SELECT.  Once that policy is replaced, the sub-selects are safe again.)
--
-- NOTE ON SECURITY:
--   SECURITY DEFINER functions are safe here because:
--   a) The function only exposes a single boolean (true/false) per calling user
--   b) It is scoped to `auth.uid()` — each user can only check their own flag
--   c) The function is not exposed to the `anon` role
--   d) Postgres evaluates it once per statement and caches the result (STABLE)
-- =============================================================================


-- =============================================================================
-- STEP 1 — Create the SECURITY DEFINER is_admin() helper
-- =============================================================================
-- STABLE: result is constant within a single SQL statement (Postgres caches it)
-- SECURITY DEFINER: runs as the function owner, bypasses RLS on `profiles`
-- SET search_path = public: prevents search-path injection attacks

CREATE OR REPLACE FUNCTION public.is_admin()
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT COALESCE(
    (SELECT is_admin FROM public.profiles WHERE id = auth.uid()),
    false
  );
$$;

-- Grant execute to the roles that will use it in policies
GRANT EXECUTE ON FUNCTION public.is_admin() TO authenticated;
GRANT EXECUTE ON FUNCTION public.is_admin() TO anon;

-- =============================================================================
-- STEP 2 — Drop the recursive profiles_admin_all policy and replace it
-- =============================================================================

DROP POLICY IF EXISTS "profiles_admin_all" ON public.profiles;

-- The new policy calls public.is_admin() — no sub-select into profiles,
-- no recursion.  Admin users get full write access (INSERT/UPDATE/DELETE)
-- to any profile row (needed for moderation, account suspension, etc.)
CREATE POLICY "profiles_admin_all"
ON public.profiles FOR ALL TO authenticated
USING     (public.is_admin())
WITH CHECK (public.is_admin());

-- =============================================================================
-- STEP 3 — Ensure the foundational SELECT policy still allows all reads
-- The foundation schema already creates a select_public USING(true) policy.
-- We confirm it exists; if it was dropped at some point, recreate it.
-- =============================================================================

DROP POLICY IF EXISTS "select_public" ON public.profiles;
CREATE POLICY "select_public"
ON public.profiles FOR SELECT
TO anon, authenticated
USING (true);

-- =============================================================================
-- STEP 4 — Reload PostgREST schema cache
-- =============================================================================

NOTIFY pgrst, 'reload schema';

-- =============================================================================
-- VERIFICATION QUERIES (run in Supabase SQL Editor after applying):
-- =============================================================================
-- 1. Confirm is_admin() exists:
--    SELECT proname, prosecdef FROM pg_proc WHERE proname = 'is_admin';
--    → should return 1 row with prosecdef = true
--
-- 2. Confirm profiles policies:
--    SELECT policyname, cmd, qual FROM pg_policies
--    WHERE schemaname = 'public' AND tablename = 'profiles'
--    ORDER BY cmd, policyname;
--    → profiles_admin_all USING clause should NOT contain "FROM public.profiles"
--
-- 3. Quick sanity check (run as authenticated user, not service_role):
--    SELECT id, is_admin FROM public.profiles WHERE id = auth.uid();
--    → should return 1 row without 42P17 error
-- =============================================================================
