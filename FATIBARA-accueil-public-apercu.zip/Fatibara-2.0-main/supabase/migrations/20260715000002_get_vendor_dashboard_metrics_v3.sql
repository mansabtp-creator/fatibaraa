-- ============================================================
-- Migration: get_vendor_dashboard_metrics v3
-- Created:   2026-07-15
-- Purpose:   Hard COALESCE guards on every aggregate so the JSON
--            payload NEVER contains NULL values.  Solves the
--            "TypeError: Cannot read properties of undefined
--            (reading 'toLocaleString')" crash on dashboard mount.
--
--            Fields returned (all guaranteed non-null):
--              total_revenue    NUMERIC  – sum of paid+completed orders
--              completed_orders INT      – count of completed orders
--              pending_orders   INT      – count of pending/payment_pending
--              active_orders    INT      – count of accepted/preparing/…
--
--            The frontend hook (useVendorData.ts) calls this via:
--              supabase.rpc('get_vendor_dashboard_metrics', { p_vendor_id: user.id })
-- ============================================================

-- Drop the previous version so we can cleanly redefine the function.
-- IF EXISTS makes this migration idempotent (safe on a fresh database too).
DROP FUNCTION IF EXISTS public.get_vendor_dashboard_metrics(UUID);

CREATE OR REPLACE FUNCTION public.get_vendor_dashboard_metrics(p_vendor_id UUID)
RETURNS JSON
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_total_revenue    NUMERIC;
    v_completed_orders INT;
    v_pending_orders   INT;
    v_active_orders    INT;
BEGIN
    -- 1. Total Revenue: orders that have been paid or fully completed.
    --    COALESCE(SUM(...), 0) handles the case where there are no matching
    --    rows at all (SUM returns NULL on an empty set).
    SELECT COALESCE(SUM(total_price), 0)
    INTO v_total_revenue
    FROM public.orders
    WHERE vendor_id = p_vendor_id
      AND status IN ('paid', 'completed');

    -- 2. Completed Orders
    SELECT COALESCE(COUNT(*), 0)
    INTO v_completed_orders
    FROM public.orders
    WHERE vendor_id = p_vendor_id
      AND status = 'completed';

    -- 3. Pending Orders (awaiting approval / payment confirmation)
    SELECT COALESCE(COUNT(*), 0)
    INTO v_pending_orders
    FROM public.orders
    WHERE vendor_id = p_vendor_id
      AND status IN ('pending', 'payment_pending');

    -- 4. Active Orders (payment confirmed, in-flight)
    SELECT COALESCE(COUNT(*), 0)
    INTO v_active_orders
    FROM public.orders
    WHERE vendor_id = p_vendor_id
      AND status IN ('accepted', 'preparing', 'ready', 'shipping');

    -- Build and return the JSON payload.
    -- The outer COALESCE on each variable is a belt-and-suspenders guard;
    -- the inner COALESCE on the SELECT should already prevent NULLs.
    RETURN json_build_object(
        'total_revenue',    COALESCE(v_total_revenue, 0),
        'completed_orders', COALESCE(v_completed_orders, 0),
        'pending_orders',   COALESCE(v_pending_orders, 0),
        'active_orders',    COALESCE(v_active_orders, 0)
    );
END;
$$;

-- Re-grant execute rights to the PostgREST API gateway layer.
GRANT EXECUTE ON FUNCTION public.get_vendor_dashboard_metrics(UUID) TO authenticated;

-- Signal PostgREST to reload its schema cache so the updated
-- function signature is immediately visible to the client SDK.
NOTIFY pgrst, 'reload schema';
