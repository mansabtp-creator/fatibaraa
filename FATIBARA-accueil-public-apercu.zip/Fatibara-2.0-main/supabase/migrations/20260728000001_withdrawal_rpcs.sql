-- Migration: Withdrawal RPCs for vendor and courier payout flows
-- These RPCs power the TransactionalWallet component's payout request flow.
-- They create entries in the `withdrawals` table (which is tracked by
-- the admin finance tab and approved/rejected via the withdrawalService).
--
-- Created: 2026-07-28

-- ── Withdrawals table (idempotent) ────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS public.withdrawals (
  id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  store_id      UUID REFERENCES public.stores(id) ON DELETE SET NULL,
  profile_id    UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  amount        NUMERIC(12, 2) NOT NULL CHECK (amount > 0),
  method        TEXT NOT NULL DEFAULT 'orange_money' CHECK (method IN ('orange_money', 'mtn_money', 'wave', 'bank')),
  phone         TEXT,
  status        TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'processed', 'rejected')),
  rejection_reason TEXT,
  type          TEXT NOT NULL DEFAULT 'vendor' CHECK (type IN ('vendor', 'courier', 'user')),
  requested_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  processed_at  TIMESTAMPTZ,
  processed_by  UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  notes         TEXT
);

-- If the table already existed with missing columns, add them safely
ALTER TABLE public.withdrawals ADD COLUMN IF NOT EXISTS store_id      UUID REFERENCES public.stores(id) ON DELETE SET NULL;
ALTER TABLE public.withdrawals ADD COLUMN IF NOT EXISTS profile_id    UUID REFERENCES auth.users(id) ON DELETE CASCADE;
ALTER TABLE public.withdrawals ADD COLUMN IF NOT EXISTS phone         TEXT;
ALTER TABLE public.withdrawals ADD COLUMN IF NOT EXISTS rejection_reason TEXT;
ALTER TABLE public.withdrawals ADD COLUMN IF NOT EXISTS type          TEXT NOT NULL DEFAULT 'vendor';
ALTER TABLE public.withdrawals ADD COLUMN IF NOT EXISTS requested_at  TIMESTAMPTZ NOT NULL DEFAULT NOW();
ALTER TABLE public.withdrawals ADD COLUMN IF NOT EXISTS processed_at  TIMESTAMPTZ;
ALTER TABLE public.withdrawals ADD COLUMN IF NOT EXISTS processed_by  UUID REFERENCES auth.users(id) ON DELETE SET NULL;
ALTER TABLE public.withdrawals ADD COLUMN IF NOT EXISTS notes         TEXT;

-- Ensure the type check constraint exists (idempotent via DO block)
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint
    WHERE conrelid = 'public.withdrawals'::regclass
    AND conname = 'withdrawals_type_check'
  ) THEN
    ALTER TABLE public.withdrawals ADD CONSTRAINT withdrawals_type_check
      CHECK (type IN ('vendor', 'courier', 'user'));
  END IF;
END $$;

CREATE INDEX IF NOT EXISTS idx_withdrawals_profile_id ON public.withdrawals(profile_id);
CREATE INDEX IF NOT EXISTS idx_withdrawals_store_id   ON public.withdrawals(store_id) WHERE store_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_withdrawals_status     ON public.withdrawals(status);

ALTER TABLE public.withdrawals ENABLE ROW LEVEL SECURITY;

-- Users can view their own withdrawal requests
DROP POLICY IF EXISTS "users_view_own_withdrawals" ON public.withdrawals;
CREATE POLICY "users_view_own_withdrawals"
  ON public.withdrawals FOR SELECT TO authenticated
  USING (profile_id = auth.uid() OR store_id IN (
    SELECT id FROM public.stores WHERE owner_id = auth.uid()
  ));

-- Admins can view and update all withdrawals (handled via service role key on server)

-- ── RPC: request_vendor_withdrawal ────────────────────────────────────────────
-- Called by TransactionalWallet (type='vendor'). Locks the requested amount
-- from the store's wallet and creates a pending withdrawal request.
-- Drop any prior incompatible version before replacing
DROP FUNCTION IF EXISTS public.request_vendor_withdrawal(UUID, NUMERIC, TEXT, TEXT) CASCADE;
CREATE OR REPLACE FUNCTION public.request_vendor_withdrawal(
  p_store_id  UUID,
  p_amount    NUMERIC,
  p_method    TEXT DEFAULT 'orange_money',
  p_phone     TEXT DEFAULT NULL
)
RETURNS UUID -- returns the withdrawal ID
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_store         public.stores%ROWTYPE;
  v_withdrawal_id UUID;
  v_min_amount    NUMERIC := 50000; -- 50,000 GNF minimum
BEGIN
  -- Ownership check
  SELECT * INTO v_store FROM public.stores WHERE id = p_store_id AND owner_id = auth.uid();
  IF NOT FOUND THEN
    RAISE EXCEPTION 'Unauthorized: store not found or not owned by caller';
  END IF;

  IF NOT v_store.is_verified_store THEN
    RAISE EXCEPTION 'Unverified stores cannot request withdrawals. Contact support.';
  END IF;

  IF p_amount < v_min_amount THEN
    RAISE EXCEPTION 'Minimum withdrawal amount is % GNF', v_min_amount;
  END IF;

  IF (v_store.balance IS NULL OR v_store.balance < p_amount) THEN
    RAISE EXCEPTION 'Solde insuffisant. Disponible: % GNF', COALESCE(v_store.balance, 0);
  END IF;

  -- Lock amount from store balance immediately
  UPDATE public.stores
  SET balance = balance - p_amount
  WHERE id = p_store_id;

  -- Create withdrawal record
  INSERT INTO public.withdrawals (store_id, profile_id, amount, method, phone, type)
  VALUES (p_store_id, auth.uid(), p_amount, p_method, p_phone, 'vendor')
  RETURNING id INTO v_withdrawal_id;

  -- Audit trail in wallet_transactions
  INSERT INTO public.wallet_transactions (profile_id, store_id, amount, type, description, reference_id)
  VALUES (auth.uid(), p_store_id, -p_amount, 'withdrawal', 'Demande de retrait en attente', v_withdrawal_id::TEXT)
  ON CONFLICT DO NOTHING;

  RETURN v_withdrawal_id;
END;
$$;

GRANT EXECUTE ON FUNCTION public.request_vendor_withdrawal(UUID, NUMERIC, TEXT, TEXT) TO authenticated;

-- ── RPC: request_user_withdrawal ─────────────────────────────────────────────
-- Called by TransactionalWallet (type='courier' or type='buyer').
-- Uses the profile's wallet_balance instead of a store's balance.
DROP FUNCTION IF EXISTS public.request_user_withdrawal(NUMERIC, TEXT, TEXT) CASCADE;
CREATE OR REPLACE FUNCTION public.request_user_withdrawal(
  p_amount  NUMERIC,
  p_method  TEXT DEFAULT 'orange_money',
  p_phone   TEXT DEFAULT NULL
)
RETURNS UUID -- returns the withdrawal ID
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_profile       public.profiles%ROWTYPE;
  v_withdrawal_id UUID;
  v_min_amount    NUMERIC := 20000; -- 20,000 GNF minimum for couriers
BEGIN
  SELECT * INTO v_profile FROM public.profiles WHERE id = auth.uid();
  IF NOT FOUND THEN
    RAISE EXCEPTION 'Profile not found';
  END IF;

  IF p_amount < v_min_amount THEN
    RAISE EXCEPTION 'Minimum withdrawal amount is % GNF', v_min_amount;
  END IF;

  IF COALESCE(v_profile.wallet_balance, 0) < p_amount THEN
    RAISE EXCEPTION 'Solde insuffisant. Disponible: % GNF', COALESCE(v_profile.wallet_balance, 0);
  END IF;

  -- Lock funds immediately
  UPDATE public.profiles
  SET wallet_balance = wallet_balance - p_amount
  WHERE id = auth.uid();

  -- Determine type: courier vs buyer
  INSERT INTO public.withdrawals (profile_id, amount, method, phone, type)
  VALUES (
    auth.uid(),
    p_amount,
    p_method,
    p_phone,
    CASE WHEN v_profile.profile_type = 'courier' THEN 'courier' ELSE 'user' END
  )
  RETURNING id INTO v_withdrawal_id;

  RETURN v_withdrawal_id;
END;
$$;

GRANT EXECUTE ON FUNCTION public.request_user_withdrawal(NUMERIC, TEXT, TEXT) TO authenticated;

-- ── RPC: approve_withdrawal ───────────────────────────────────────────────────
-- Admin-only: marks a withdrawal as processed (payment sent externally).
DROP FUNCTION IF EXISTS public.approve_withdrawal(UUID) CASCADE;
CREATE OR REPLACE FUNCTION public.approve_withdrawal(p_withdrawal_id UUID)
RETURNS BOOLEAN
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM public.profiles WHERE id = auth.uid() AND is_admin = true
  ) THEN
    RAISE EXCEPTION 'Unauthorized: admin role required';
  END IF;

  UPDATE public.withdrawals
  SET status = 'processed', processed_at = NOW(), processed_by = auth.uid()
  WHERE id = p_withdrawal_id AND status = 'pending';

  RETURN FOUND;
END;
$$;

GRANT EXECUTE ON FUNCTION public.approve_withdrawal(UUID) TO authenticated;

-- ── RPC: reject_withdrawal ────────────────────────────────────────────────────
-- Admin-only: rejects and REFUNDS the locked amount back to the wallet.
DROP FUNCTION IF EXISTS public.reject_withdrawal(UUID, TEXT) CASCADE;
CREATE OR REPLACE FUNCTION public.reject_withdrawal(
  p_withdrawal_id UUID,
  p_reason        TEXT DEFAULT 'Demande rejetée par l''administrateur'
)
RETURNS BOOLEAN
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_w public.withdrawals%ROWTYPE;
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM public.profiles WHERE id = auth.uid() AND is_admin = true
  ) THEN
    RAISE EXCEPTION 'Unauthorized: admin role required';
  END IF;

  SELECT * INTO v_w FROM public.withdrawals WHERE id = p_withdrawal_id AND status = 'pending';
  IF NOT FOUND THEN
    RETURN FALSE;
  END IF;

  -- Refund to vendor store balance
  IF v_w.store_id IS NOT NULL THEN
    UPDATE public.stores SET balance = balance + v_w.amount WHERE id = v_w.store_id;
  END IF;

  -- Refund to user/courier wallet
  IF v_w.profile_id IS NOT NULL AND v_w.type IN ('courier', 'user') THEN
    UPDATE public.profiles SET wallet_balance = COALESCE(wallet_balance, 0) + v_w.amount WHERE id = v_w.profile_id;
  END IF;

  -- Mark as rejected
  UPDATE public.withdrawals
  SET status = 'rejected', rejection_reason = p_reason, processed_at = NOW(), processed_by = auth.uid()
  WHERE id = p_withdrawal_id;

  RETURN TRUE;
END;
$$;

GRANT EXECUTE ON FUNCTION public.reject_withdrawal(UUID, TEXT) TO authenticated;
