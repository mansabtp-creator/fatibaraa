-- ==============================================================================
-- Migration: 20260929000003_drop_and_recreate_complete_vendor_order.sql
-- Description: Drops any prior complete_vendor_order overloads and recreates
--              public.complete_vendor_order(target_order_id UUID, status_text TEXT)
--              matching src/pages/vendor/Dashboard.tsx and src/components/VendorOrders.tsx.
-- ==============================================================================

-- 1. Drop existing function overloads to avoid parameter name conflict (Postgres 42P13)
DROP FUNCTION IF EXISTS public.complete_vendor_order(UUID, TEXT) CASCADE;
DROP FUNCTION IF EXISTS public.complete_vendor_order(UUID) CASCADE;
DROP FUNCTION IF EXISTS public.complete_vendor_order(target_order_id UUID, provided_otp TEXT) CASCADE;
DROP FUNCTION IF EXISTS public.complete_vendor_order(p_order_id UUID, p_otp TEXT) CASCADE;
DROP FUNCTION IF EXISTS public.complete_vendor_order(order_id UUID, otp TEXT) CASCADE;

-- 2. Recreate canonical complete_vendor_order function with (target_order_id UUID, status_text TEXT)
CREATE OR REPLACE FUNCTION public.complete_vendor_order(
    target_order_id UUID,
    status_text     TEXT DEFAULT NULL
)
RETURNS VOID
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
    v_order                 public.orders%ROWTYPE;
    v_store_id              UUID;
    v_vendor_user_id        UUID;
    v_commission_str        TEXT;
    v_commission_rate       NUMERIC;
    v_items_real_value      NUMERIC := 0;
    v_platform_commission   NUMERIC;
    v_vendor_payout         NUMERIC;
    v_courier_payout        NUMERIC;
    v_payment_method        TEXT;
    v_is_cash_payment       BOOLEAN;
    v_vendor_digital_delta  NUMERIC;
    v_courier_digital_delta NUMERIC;
    v_existing_sale         BOOLEAN := FALSE;
    v_is_authorized         BOOLEAN := FALSE;
BEGIN
    -- ── 1. Lock the order row to prevent race conditions ─────────────────────
    SELECT * INTO v_order
    FROM public.orders
    WHERE id = target_order_id
    FOR UPDATE;

    IF NOT FOUND THEN
        RAISE EXCEPTION 'Order not found';
    END IF;

    -- ── 2. Idempotency guard: if already delivered, do nothing ───────────────
    IF v_order.status = 'delivered' THEN
        RETURN;
    END IF;

    IF v_order.status = 'cancelled' THEN
        RAISE EXCEPTION 'Order is cancelled and cannot be delivered';
    END IF;

    -- ── 3. Resolve store_id from order items or vendor store ─────────────────
    SELECT COALESCE(
        (SELECT p.store_id
         FROM public.order_items oi
         JOIN public.products p ON oi.product_id = p.id
         WHERE oi.order_id = target_order_id
         LIMIT 1),
        (SELECT id FROM public.stores WHERE owner_id = v_order.vendor_id LIMIT 1),
        (SELECT id FROM public.stores WHERE owner_id = auth.uid() LIMIT 1)
    ) INTO v_store_id;

    -- ── 4. Authorization check ───────────────────────────────────────────────
    -- Caller is valid if:
    --   - caller is the vendor_id
    --   - OR caller owns the store
    --   - OR caller is an admin
    IF v_order.vendor_id = auth.uid() THEN
        v_is_authorized := TRUE;
    ELSIF v_store_id IS NOT NULL AND EXISTS (
        SELECT 1 FROM public.stores WHERE id = v_store_id AND owner_id = auth.uid()
    ) THEN
        v_is_authorized := TRUE;
    ELSIF public.is_admin() THEN
        v_is_authorized := TRUE;
    END IF;

    IF NOT v_is_authorized THEN
        RAISE EXCEPTION 'Unauthorized: You do not own this order or store';
    END IF;

    -- ── 5. State machine guard ───────────────────────────────────────────────
    IF v_order.status NOT IN (
        'ready', 'ready_for_pickup', 'in_transit', 'shipping', 'accepted',
        'preparing', 'processing', 'confirmed', 'paid', 'out_for_delivery'
    ) THEN
        RAISE EXCEPTION 'Order status "%" cannot be transitioned to delivered', v_order.status;
    END IF;

    -- ── 6. OTP validation (when delivery_otp is set on the order) ────────────
    IF v_order.delivery_otp IS NOT NULL AND TRIM(v_order.delivery_otp) != '' THEN
        IF status_text IS NULL OR TRIM(status_text) != TRIM(v_order.delivery_otp) THEN
            RAISE EXCEPTION 'Invalid delivery OTP';
        END IF;
    END IF;

    -- ── 7. Resolve vendor user ID (guarantee NOT NULL for profile_id) ────────
    v_vendor_user_id := COALESCE(
        v_order.vendor_id,
        (SELECT owner_id FROM public.stores WHERE id = v_store_id),
        auth.uid()
    );

    -- ── 8. Check if financial settlement has already been performed ─────────
    SELECT EXISTS (
        SELECT 1 FROM public.wallet_transactions
        WHERE reference_id = target_order_id::TEXT AND type = 'sale'
    ) INTO v_existing_sale;

    -- ── 9. Execute financial settlement only if not previously done ─────────
    IF NOT v_existing_sale THEN
        v_payment_method := COALESCE(
            v_order.shipping_address->>'payment_method',
            CASE WHEN v_order.financial_status IN ('paid', 'processed') THEN 'wallet' ELSE 'cash' END
        );
        v_is_cash_payment := (v_payment_method = 'cash');

        -- Commission rate from platform_settings (default 5%)
        SELECT value INTO v_commission_str
        FROM public.platform_settings WHERE id = 'commission_rate';
        v_commission_rate := COALESCE(NULLIF(v_commission_str, '')::NUMERIC, 5) / 100.0;

        -- Calculate item value from order_items; fallback to total_amount
        SELECT COALESCE(SUM(price_at_purchase * quantity), 0)
        INTO v_items_real_value
        FROM public.order_items
        WHERE order_id = target_order_id;

        IF v_items_real_value = 0 THEN
            v_items_real_value := COALESCE(v_order.total_amount, 0) - COALESCE(v_order.delivery_fee, 0);
        END IF;

        -- Vendor payout
        v_vendor_payout := (v_items_real_value / (1 + v_commission_rate))
                            * (1 - v_commission_rate)
                            - COALESCE(v_order.vendor_delivery_fee, 0);
        v_platform_commission := (v_items_real_value / (1 + v_commission_rate)) * v_commission_rate;

        -- Courier payout (80% of delivery fee)
        IF COALESCE(v_order.delivery_fee, 0) > 0 THEN
            v_courier_payout := v_order.delivery_fee * 0.8;
        ELSE
            v_courier_payout := COALESCE(v_order.vendor_delivery_fee, 0) * 0.8;
        END IF;

        -- If no courier, vendor absorbs courier payout
        IF v_order.courier_id IS NULL THEN
            v_vendor_payout := v_vendor_payout + v_courier_payout;
        END IF;

        -- For COD with no courier: vendor collected cash → deduct total_amount from digital credit
        v_vendor_digital_delta := v_vendor_payout;
        IF v_is_cash_payment AND v_order.courier_id IS NULL THEN
            v_vendor_digital_delta := v_vendor_payout - COALESCE(v_order.total_amount, 0);
        END IF;

        -- Credit vendor store balance
        IF v_vendor_digital_delta != 0 AND v_store_id IS NOT NULL THEN
            UPDATE public.stores
            SET balance = balance + ROUND(v_vendor_digital_delta),
                updated_at = NOW()
            WHERE id = v_store_id;

            INSERT INTO public.wallet_transactions
                (store_id, profile_id, amount, type, reference_id, description)
            VALUES (
                v_store_id,
                v_vendor_user_id,
                ROUND(v_vendor_digital_delta),
                CASE WHEN v_vendor_digital_delta > 0 THEN 'sale' ELSE 'fee' END,
                target_order_id::TEXT,
                'Vente #' || LEFT(target_order_id::TEXT, 8)
            );
        END IF;

        -- Credit courier balance (if courier assigned)
        IF v_order.courier_id IS NOT NULL THEN
            v_courier_digital_delta := v_courier_payout;
            IF v_is_cash_payment THEN
                v_courier_digital_delta := v_courier_payout - COALESCE(v_order.total_amount, 0);
            END IF;

            IF v_courier_digital_delta > 0 THEN
                UPDATE public.profiles
                SET wallet_balance = COALESCE(wallet_balance, 0) + ROUND(v_courier_digital_delta),
                    updated_at = NOW()
                WHERE id = v_order.courier_id;

                INSERT INTO public.wallet_transactions
                    (profile_id, amount, type, reference_id, description, status)
                VALUES (
                    v_order.courier_id,
                    ROUND(v_courier_digital_delta),
                    'delivery_fee',
                    target_order_id::TEXT,
                    'Course #' || LEFT(target_order_id::TEXT, 8),
                    'completed'
                );
            END IF;
        END IF;

        -- Log platform commission
        INSERT INTO public.platform_logs (type, amount, reference_id, metadata)
        VALUES (
            'commission',
            ROUND(v_platform_commission),
            target_order_id::TEXT,
            jsonb_build_object(
                'order_total', v_order.total_amount,
                'vendor_id',   v_vendor_user_id,
                'payment',     v_payment_method
            )
        );
    END IF;

    -- ── 10. Mark order as delivered and financially processed ────────────────
    UPDATE public.orders
    SET status           = 'delivered',
        financial_status = 'processed',
        completed_at     = NOW(),
        updated_at       = NOW()
    WHERE id = target_order_id;

END;
$$;

-- 3. Grants and permissions
GRANT EXECUTE ON FUNCTION public.complete_vendor_order(UUID, TEXT) TO authenticated;
GRANT EXECUTE ON FUNCTION public.complete_vendor_order(UUID, TEXT) TO service_role;
GRANT INSERT ON public.platform_logs TO authenticated;
GRANT INSERT ON public.wallet_transactions TO authenticated;
GRANT UPDATE ON public.stores TO authenticated;
GRANT SELECT ON public.order_items TO authenticated;
GRANT SELECT ON public.platform_settings TO authenticated;
GRANT UPDATE ON public.profiles TO authenticated;

-- 4. Reload PostgREST schema cache
NOTIFY pgrst, 'reload schema';
