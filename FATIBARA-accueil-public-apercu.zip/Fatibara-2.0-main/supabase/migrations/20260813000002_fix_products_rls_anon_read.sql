-- =============================================================================
-- Migration: Fix Products RLS — Restore Anonymous Read Access
-- Created At: 2026-08-13
--
-- Root Cause:
--   A previous hotfix (fix_products_rls.sql) dropped and rebuilt only the
--   vendor management policy (FOR ALL) without restoring the public SELECT
--   policy.  When RLS is enabled on a table and no policy covers a role, that
--   role gets zero rows — exactly the "Impossible de charger les produits"
--   symptom observed on unauthenticated mobile clients.
--
-- Changes:
--   1. Ensure RLS is enabled (idempotent).
--   2. Drop any stale SELECT policies (prevents duplicates).
--   3. Re-create a single, clean "Products are viewable by everyone" policy
--      covering both SELECT operations (anon + authenticated).
--   4. Grant explicit table-level SELECT to anon and authenticated roles so
--      PostgREST can access the table even before auth.uid() is resolved.
--   5. Also fix the stores table for the same reason (products query joins stores).
--   6. Reload the PostgREST schema cache.
-- =============================================================================

-- ── 1. Ensure RLS is enabled ──────────────────────────────────────────────────
ALTER TABLE public.products ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.stores   ENABLE ROW LEVEL SECURITY;

-- ── 2. Drop stale / conflicting SELECT policies ───────────────────────────────
DROP POLICY IF EXISTS "Products are viewable by everyone"            ON public.products;
DROP POLICY IF EXISTS "Allow public read access to products"         ON public.products;
DROP POLICY IF EXISTS "Public can view active products"              ON public.products;
DROP POLICY IF EXISTS "Anon users can view products"                 ON public.products;

DROP POLICY IF EXISTS "Stores are viewable by everyone"              ON public.stores;
DROP POLICY IF EXISTS "Allow public read access to stores"           ON public.stores;

-- ── 3. Re-create clean public-read policies ───────────────────────────────────
CREATE POLICY "Products are viewable by everyone"
  ON public.products
  FOR SELECT
  USING (true);

CREATE POLICY "Stores are viewable by everyone"
  ON public.stores
  FOR SELECT
  USING (true);

-- ── 4. Explicit table-level grants (belt-and-suspenders) ──────────────────────
-- PostgREST uses Postgres role grants AND RLS policies independently.
-- Without a table grant, even USING(true) won't allow anon to read.
GRANT SELECT ON public.products TO anon;
GRANT SELECT ON public.products TO authenticated;

GRANT SELECT ON public.stores TO anon;
GRANT SELECT ON public.stores TO authenticated;

-- ── 5. Verify: the vendor management policy should still be in place ──────────
-- (Reproduced from fix_products_rls.sql — idempotent DROP + CREATE)
DROP POLICY IF EXISTS "Vendors can manage their own products" ON public.products;

CREATE POLICY "Vendors can manage their own products"
  ON public.products
  FOR ALL
  USING (
    EXISTS (
      SELECT 1 FROM public.stores
      WHERE stores.id  = products.store_id
        AND stores.owner_id = auth.uid()
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM public.stores
      WHERE stores.id  = products.store_id
        AND stores.owner_id = auth.uid()
    )
    AND price_gnf >= 0  -- price-poisoning guard
  );

-- ── 6. Refresh PostgREST schema cache ─────────────────────────────────────────
NOTIFY pgrst, 'reload schema';
