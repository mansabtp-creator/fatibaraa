-- Migration: enforce product visibility at the RLS layer
-- Fixes SF-BUG-1: the public SELECT policy on products was `USING (true)`,
-- meaning rejected, hidden, and inactive products were readable by anyone.
--
-- New policy:
--   Public (anon / authenticated customers) can only see products that are:
--     1. is_active = true
--     2. is_visible = true (or is_visible IS NULL — backward compat for older rows)
--     3. moderation_status = 'approved' (or moderation_status IS NULL — for
--        products created before the moderation system was introduced)
--
--   Store owners can always see their OWN products (any status) so they can
--   see rejected listings in their vendor dashboard.
--
--   Admins bypass the filter entirely via the admin RPC paths.

-- Drop the old open-door policy
DROP POLICY IF EXISTS "products_public_select"   ON public.products;
DROP POLICY IF EXISTS "products_select_public"   ON public.products;

-- 1. Public / customer visibility policy
--    Customers (anon or authenticated non-owners) only see live, approved listings.
CREATE POLICY "products_customer_select"
ON public.products FOR SELECT
USING (
  -- Allow store owners to see their own products regardless of status
  store_id IN (
    SELECT id FROM public.stores WHERE owner_id = auth.uid()
  )
  OR
  -- Allow admins to see everything
  EXISTS (
    SELECT 1 FROM public.profiles WHERE id = auth.uid() AND is_admin = true
  )
  OR
  -- Public / customers only see active + visible + approved products
  (
    is_active    IS NOT DISTINCT FROM true
    AND (is_visible IS NULL OR is_visible = true)
    AND (moderation_status IS NULL OR moderation_status = 'approved')
  )
);

-- 2. Also enforce at the query layer as defense-in-depth:
--    Create a DB view that the ProductGrid can optionally query instead of the table.
--    This is a belt-and-suspenders approach — the RLS above is the real enforcement.
CREATE OR REPLACE VIEW public.products_public AS
  SELECT *
  FROM public.products
  WHERE
    is_active IS NOT DISTINCT FROM true
    AND (is_visible IS NULL OR is_visible = true)
    AND (moderation_status IS NULL OR moderation_status = 'approved');

-- Grant anon + authenticated read on the view
GRANT SELECT ON public.products_public TO anon, authenticated;
