-- =============================================================================
-- Migration: Fix Vendor Orders Visibility — store_id fallback SELECT policy
-- Created At: 2026-08-04
--
-- Problem:
--   Orders placed before the vendor_id column was reliably populated (or via
--   COD / wallet RPCs that may not set vendor_id) have vendor_id = NULL.
--   The flat SELECT policy `auth.uid() = vendor_id` returns no rows for those
--   orders, so the vendor dashboard shows 0 orders.
--
-- Fix:
--   Extend the SELECT policy with an OR arm that checks store_id ownership:
--     EXISTS (SELECT 1 FROM public.stores
--             WHERE stores.id = orders.store_id
--             AND   stores.owner_id = auth.uid())
--
--   This is NOT recursive (stores has its own flat RLS, but the subquery here
--   reads stores directly without going back through orders).
--
--   Also adds 'confirmed' and 'processing' to the UPDATE policy so vendors
--   can advance COD orders from those states.
-- =============================================================================

-- ── DROP + RECREATE the SELECT policy with store_id fallback arm ──────────────
DROP POLICY IF EXISTS "Fatibara flat orders read policy" ON public.orders;
CREATE POLICY "Fatibara flat orders read policy"
ON public.orders
FOR SELECT
TO authenticated
USING (
  -- Buyer sees their own order
  auth.uid() = user_id
  -- Vendor sees orders where they are the registered vendor_id ...
  OR auth.uid() = vendor_id
  -- ... OR where they own the store that fulfilled the order (store_id fallback)
  OR EXISTS (
    SELECT 1 FROM public.stores
    WHERE public.stores.id = orders.store_id
      AND public.stores.owner_id = auth.uid()
  )
  -- Assigned courier sees their delivery
  OR auth.uid() = courier_id
);

-- ── Ensure order_items SELECT also covers store owners ────────────────────────
-- The existing policy is:
--   USING (auth.uid() = user_id OR EXISTS (...orders WHERE vendor_id = auth.uid()))
-- We extend it to also cover store_id ownership, preventing 0 items on vendor detail views.
DROP POLICY IF EXISTS "order_items_select" ON public.order_items;
CREATE POLICY "order_items_select"
ON public.order_items
FOR SELECT
TO authenticated
USING (
  -- The buyer who placed the order
  EXISTS (
    SELECT 1 FROM public.orders
    WHERE public.orders.id = order_items.order_id
      AND public.orders.user_id = auth.uid()
  )
  -- The vendor (via vendor_id direct match)
  OR EXISTS (
    SELECT 1 FROM public.orders
    WHERE public.orders.id = order_items.order_id
      AND public.orders.vendor_id = auth.uid()
  )
  -- The vendor (via store ownership — handles vendor_id = NULL cases)
  -- order_items has no store_id column; we join through orders.store_id instead
  OR EXISTS (
    SELECT 1
    FROM public.orders o
    JOIN public.stores s ON s.id = o.store_id
    WHERE o.id = order_items.order_id
      AND s.owner_id = auth.uid()
  )
  -- The courier assigned to this order
  OR EXISTS (
    SELECT 1 FROM public.orders
    WHERE public.orders.id = order_items.order_id
      AND public.orders.courier_id = auth.uid()
  )
);

-- ── Notify PostgREST to reload schema cache ───────────────────────────────────
NOTIFY pgrst, 'reload schema';
