-- Sprint 1: Courier improvements
-- 1. Cancellation reason column
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS cancel_reason TEXT DEFAULT NULL;
COMMENT ON COLUMN public.orders.cancel_reason IS 'Reason provided when courier abandons or vendor cancels.';

-- 2. Courier assignment release RPC
CREATE OR REPLACE FUNCTION public.cancel_courier_assignment(
  p_order_id UUID,
  p_reason   TEXT DEFAULT 'Abandonnée par le livreur'
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE v_order orders%ROWTYPE;
BEGIN
  SELECT * INTO v_order FROM orders WHERE id = p_order_id;
  IF NOT FOUND THEN RETURN jsonb_build_object('success', false, 'error', 'Order not found'); END IF;
  IF v_order.courier_id != auth.uid() THEN RETURN jsonb_build_object('success', false, 'error', 'Not your order'); END IF;
  IF v_order.status IN ('delivered', 'cancelled') THEN RETURN jsonb_build_object('success', false, 'error', 'Cannot abandon a completed order'); END IF;
  UPDATE orders SET courier_id = NULL, status = 'ready_for_pickup', cancel_reason = p_reason, updated_at = now() WHERE id = p_order_id;
  RETURN jsonb_build_object('success', true);
END;
$$;
