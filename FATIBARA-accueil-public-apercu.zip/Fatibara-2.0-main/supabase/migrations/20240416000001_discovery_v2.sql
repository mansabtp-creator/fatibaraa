-- =================================================================================
-- FATIBARA DISCOVERY SYSTEM V2: FUZZY SEARCH & MATERIALIZED VIEWS
-- Run this script in your Supabase SQL Editor to upgrade search & trending
-- =================================================================================

-- 1. ENABLE PG_TRGM FOR FUZZY SEARCH
-- The pg_trgm extension provides trigram matching, which is excellent for fuzzy search (typos, partial matches).
CREATE EXTENSION IF NOT EXISTS pg_trgm;

-- Create GIN indexes to dramatically speed up trigram text searches on title and description
CREATE INDEX IF NOT EXISTS products_title_trgm_idx ON public.products USING GIN (title gin_trgm_ops);
CREATE INDEX IF NOT EXISTS products_desc_trgm_idx ON public.products USING GIN (description gin_trgm_ops);

-- 2. UPGRADE SECURE SEARCH RPC (Fuzzy Search)
-- This function now uses similarity() and the % operator for typo-tolerant fuzzy matching.
DROP FUNCTION IF EXISTS search_products(text);
CREATE OR REPLACE FUNCTION search_products(search_query text)
RETURNS TABLE (
  id uuid, 
  title text, 
  price_gnf numeric, 
  wholesale_price_gnf numeric, 
  image_urls text[],
  similarity_score real
) AS $$
DECLARE
  is_pro boolean := false;
BEGIN
  -- Check if the current authenticated user is a pro member
  IF auth.uid() IS NOT NULL THEN
    SELECT is_pro_member INTO is_pro FROM public.profiles WHERE profiles.id = auth.uid();
  END IF;

  RETURN QUERY
  SELECT 
    p.id, 
    p.title, 
    p.price_gnf,
    -- Security: Only return wholesale price if the user is a Pro member
    CASE WHEN is_pro THEN p.wholesale_price_gnf ELSE NULL END as wholesale_price_gnf,
    p.image_urls,
    -- Calculate the best similarity score between title and description
    GREATEST(similarity(p.title, search_query), similarity(p.description, search_query)) as similarity_score
  FROM public.products p
  WHERE 
    -- Match if similarity is above threshold OR standard ILIKE fallback for short queries
    p.title % search_query 
    OR p.description % search_query
    OR p.title ILIKE '%' || search_query || '%'
  ORDER BY similarity_score DESC, p.created_at DESC
  LIMIT 6;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;


-- 3. MATERIALIZED VIEW FOR TRENDING PRODUCTS
-- Pre-computes trending scores to avoid heavy aggregations on every page load.
ALTER TABLE public.products ADD COLUMN IF NOT EXISTS category text;
CREATE MATERIALIZED VIEW IF NOT EXISTS public.trending_products_mv AS
SELECT 
  p.id, 
  p.title, 
  p.price_gnf, 
  p.wholesale_price_gnf,
  p.image_urls, 
  p.category,
  COALESCE(SUM(CASE WHEN i.interaction_type = 'click' THEN 3 ELSE 1 END), 0) as trending_score
FROM public.products p
LEFT JOIN public.product_interactions i ON p.id = i.product_id AND i.created_at > now() - interval '24 hours'
GROUP BY p.id
ORDER BY trending_score DESC, p.created_at DESC;

-- Unique index required to refresh the materialized view concurrently (without locking reads)
CREATE UNIQUE INDEX IF NOT EXISTS idx_trending_products_mv_id ON public.trending_products_mv(id);

-- Function to refresh the materialized view
-- You can call this function periodically via pg_cron or a serverless edge function (e.g., every 5-10 mins)
CREATE OR REPLACE FUNCTION refresh_trending_products()
RETURNS void AS $$
BEGIN
  REFRESH MATERIALIZED VIEW CONCURRENTLY public.trending_products_mv;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;


-- 4. UPGRADE TRENDING RPC TO USE MATERIALIZED VIEW
-- This is now a blazing fast read from the pre-computed materialized view.
DROP FUNCTION IF EXISTS get_trending_products();
CREATE OR REPLACE FUNCTION get_trending_products()
RETURNS TABLE (
  id uuid, 
  title text, 
  price_gnf numeric, 
  wholesale_price_gnf numeric,
  image_urls text[], 
  category text,
  trending_score bigint
) AS $$
DECLARE
  is_pro boolean := false;
BEGIN
  -- Check if the current authenticated user is a pro member
  IF auth.uid() IS NOT NULL THEN
    SELECT is_pro_member INTO is_pro FROM public.profiles WHERE profiles.id = auth.uid();
  END IF;

  RETURN QUERY
  SELECT 
    mv.id, 
    mv.title, 
    mv.price_gnf,
    CASE WHEN is_pro THEN mv.wholesale_price_gnf ELSE NULL END as wholesale_price_gnf,
    mv.image_urls,
    mv.category,
    mv.trending_score
  FROM public.trending_products_mv mv
  LIMIT 10;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;
