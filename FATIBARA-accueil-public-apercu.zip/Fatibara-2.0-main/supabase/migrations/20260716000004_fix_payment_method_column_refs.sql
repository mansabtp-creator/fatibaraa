-- ==============================================================================
-- Migration: Fix payment_method column references in RPC functions
-- Created At: 2026-07-16
-- Author:     Antigravity / Fatibara Engineering
--
-- ROOT CAUSE:
--   Three RPC functions referenced v_order.payment_method which does NOT exist
--   as a column on the public.orders table. The payment_method value is stored
--   inside the JSONB column shipping_address (set by create_checkout_session).
--
--   Affected functions:
--     1. cancel_vendor_order        — used v_order.payment_method
--     2. secure_refund_order_financials — used v_order.payment_method
--     3. secure_process_order_financials — used v_order.payment_method = 'cash'
--
-- FIX:
--   1. cancel_vendor_order + secure_refund_order_financials:
--      Replace payment_method check with financial_status = 'paid'.
--      Semantically correct: digital money was collected ↔ financial_status='paid'.
--
--   2. secure_process_order_financials:
--      Read payment method from shipping_address->>'payment_method' (the JSONB
--      field where create_checkout_session stores it), with a safe fallback:
--      if the key is absent, treat as cash when financial_status != 'paid'.
-- ==============================================================================

-- ── Fix 1: cancel_vendor_order ───────────────────────────────────────────────
CREATE OR REPLACE FUNCTION public.cancel_vendor_order(
    target_order_id uuid,
    cancel_reason   text
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_order        public.orders%ROWTYPE;
    v_needs_refund BOOLEAN;
BEGIN
    SELECT * INTO v_order FROM public.orders WHERE id = target_order_id FOR UPDATE;

    IF NOT FOUND THEN RAISE EXCEPTION 'Order not found'; END IF;
    IF v_order.vendor_id != auth.uid() THEN RAISE EXCEPTION 'Unauthorized: You do not own this store'; END IF;
    IF v_order.status IN ('delivered', 'cancelled') THEN RAISE EXCEPTION 'Order is already in a terminal state'; END IF;
    IF v_order.financial_status = 'refunded' THEN RAISE EXCEPTION 'Order already refunded'; END IF;

    v_needs_refund := (v_order.financial_status = 'paid')
                      AND (v_order.status NOT IN ('pending', 'cancelled'));

    IF v_needs_refund THEN
        UPDATE public.profiles
        SET wallet_balance = wallet_balance + ROUND(v_order.total_amount)
        WHERE id = v_order.user_id;

        INSERT INTO public.wallet_transactions (profile_id, amount, type, reference_id, description)
        VALUES (
            v_order.user_id, v_order.total_amount, 'refund', target_order_id,
            'Remboursement Commande #' || left(target_order_id::text, 8) || ' (' || cancel_reason || ')'
        );
    END IF;

    UPDATE public.orders
    SET status           = 'cancelled',
        financial_status = CASE WHEN v_needs_refund THEN 'refunded' ELSE financial_status END,
        updated_at       = now()
    WHERE id = target_order_id;
END;
$$;

-- ── Fix 2: secure_refund_order_financials ────────────────────────────────────
CREATE OR REPLACE FUNCTION public.secure_refund_order_financials(
    p_order_id      uuid,
    p_cancel_reason text DEFAULT 'Annulation'
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_order              record;
    v_is_digital_payment boolean;
BEGIN
    SELECT * INTO v_order FROM public.orders WHERE id = p_order_id FOR UPDATE;
    IF NOT FOUND THEN RAISE EXCEPTION 'Order not found'; END IF;

    IF v_order.financial_status = 'refunded' THEN
        RETURN jsonb_build_object('success', true, 'alreadyRefunded', true);
    END IF;

    v_is_digital_payment := (v_order.financial_status = 'paid');

    IF v_is_digital_payment AND v_order.status != 'pending' THEN
        UPDATE public.profiles
        SET wallet_balance = wallet_balance + ROUND(v_order.total_amount)
        WHERE id = v_order.user_id;

        INSERT INTO public.wallet_transactions (profile_id, amount, type, reference_id, description)
        VALUES (
            v_order.user_id, v_order.total_amount, 'refund', v_order.id,
            'Remboursement Commande #' || left(v_order.id::text, 8) || ' (' || p_cancel_reason || ')'
        );
    END IF;

    UPDATE public.orders SET financial_status = 'refunded', status = 'cancelled' WHERE id = p_order_id;
    RETURN jsonb_build_object('success', true);
END;
$$;

-- ── Fix 3: secure_process_order_financials ───────────────────────────────────
CREATE OR REPLACE FUNCTION public.secure_process_order_financials(p_order_id uuid)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_order                        RECORD;
    v_store                        RECORD;
    v_existing_tx                  BOOLEAN;
    v_commission_str               TEXT;
    v_commission_rate              NUMERIC;
    v_items_real_value             NUMERIC := 0;
    v_item_subtotal                NUMERIC;
    v_platform_commission          NUMERIC;
    v_vendor_payout                NUMERIC;
    v_courier_payout               NUMERIC;
    v_is_cash_payment              BOOLEAN;
    v_final_vendor_digital_change  NUMERIC;
    v_final_courier_digital_change NUMERIC;
BEGIN
    SELECT * INTO v_order FROM public.orders WHERE id = p_order_id FOR UPDATE;
    IF NOT FOUND THEN RAISE EXCEPTION 'Order not found'; END IF;

    IF v_order.financial_status = 'processed' THEN
        RETURN jsonb_build_object('success', true, 'alreadyProcessed', true);
    END IF;

    SELECT EXISTS (
        SELECT 1 FROM public.wallet_transactions WHERE reference_id = p_order_id AND type = 'sale'
    ) INTO v_existing_tx;

    IF v_existing_tx THEN
        UPDATE public.orders SET financial_status = 'processed' WHERE id = p_order_id;
        RETURN jsonb_build_object('success', true, 'alreadyProcessed', true);
    END IF;

    SELECT * INTO v_store FROM public.stores
    WHERE id = v_order.store_id
       OR (v_order.store_id IS NULL AND owner_id = v_order.vendor_id)
    LIMIT 1;

    v_items_real_value := v_order.total_amount - COALESCE(v_order.delivery_fee, 0);

    SELECT value INTO v_commission_str FROM public.platform_settings WHERE id = 'commission_rate';
    IF v_commission_str IS NULL THEN v_commission_str := '5'; END IF;
    v_commission_rate := v_commission_str::numeric / 100.0;

    v_item_subtotal       := v_items_real_value / (1 + v_commission_rate);
    v_platform_commission := v_item_subtotal * v_commission_rate;
    v_vendor_payout       := v_item_subtotal - COALESCE(v_order.vendor_delivery_fee, 0);
    v_courier_payout      := (CASE WHEN COALESCE(v_order.delivery_fee, 0) > 0
                                   THEN v_order.delivery_fee
                                   ELSE COALESCE(v_order.vendor_delivery_fee, 0) END) * 0.8;

    IF v_order.courier_id IS NULL THEN
        v_vendor_payout := v_vendor_payout + v_courier_payout;
    END IF;

    -- payment_method is stored inside shipping_address JSONB by create_checkout_session.
    -- Fallback: if key absent, treat as cash when financial_status != 'paid'.
    v_is_cash_payment := COALESCE(
        (v_order.shipping_address->>'payment_method') = 'cash',
        v_order.financial_status != 'paid'
    );

    IF v_store.id IS NOT NULL THEN
        v_final_vendor_digital_change := v_vendor_payout;
        IF v_is_cash_payment AND v_order.courier_id IS NULL THEN
            v_final_vendor_digital_change := v_vendor_payout - v_order.total_amount;
        END IF;
        IF v_final_vendor_digital_change != 0 THEN
            UPDATE public.stores
            SET balance = COALESCE(balance, 0) + ROUND(v_final_vendor_digital_change)
            WHERE id = v_store.id;
            INSERT INTO public.wallet_transactions (profile_id, amount, type, reference_id, description)
            VALUES (
                v_order.vendor_id, v_final_vendor_digital_change,
                CASE WHEN v_final_vendor_digital_change > 0 THEN 'sale' ELSE 'fee' END,
                v_order.id,
                CASE WHEN v_is_cash_payment
                     THEN 'Collecte Cash #' || left(v_order.id::text, 8) || ' (Retenue: ' || abs(ROUND(v_final_vendor_digital_change)) || ')'
                     ELSE 'Vente #' || left(v_order.id::text, 8) || ' (Payout ' || ROUND(v_item_subtotal) || ')'
                END
            );
        END IF;
    END IF;

    IF v_order.courier_id IS NOT NULL THEN
        v_final_courier_digital_change := v_courier_payout;
        IF v_is_cash_payment THEN
            v_final_courier_digital_change := v_courier_payout - v_order.total_amount;
        END IF;
        IF v_final_courier_digital_change != 0 THEN
            UPDATE public.profiles
            SET wallet_balance = wallet_balance + ROUND(v_final_courier_digital_change)
            WHERE id = v_order.courier_id;
            INSERT INTO public.wallet_transactions (profile_id, amount, type, reference_id, description)
            VALUES (
                v_order.courier_id, v_final_courier_digital_change,
                CASE WHEN v_final_courier_digital_change > 0 THEN 'delivery_fee' ELSE 'fee' END,
                v_order.id,
                CASE WHEN v_is_cash_payment
                     THEN 'Collecte Cash #' || left(v_order.id::text, 8) || ' (Retenue: ' || abs(ROUND(v_final_courier_digital_change)) || ')'
                     ELSE 'Course effectuée - Commande #' || left(v_order.id::text, 8)
                END
            );
        END IF;
    END IF;

    INSERT INTO public.platform_logs (type, amount, reference_id, metadata)
    VALUES ('commission', ROUND(v_platform_commission), v_order.id,
            jsonb_build_object('order_total', v_order.total_amount, 'vendor_id', v_order.vendor_id));

    UPDATE public.orders SET financial_status = 'processed' WHERE id = p_order_id;

    RETURN jsonb_build_object(
        'success', true,
        'vendorPayout', ROUND(v_vendor_payout),
        'courierPayout', ROUND(v_courier_payout),
        'platformCommission', ROUND(v_platform_commission)
    );
END;
$$;

GRANT EXECUTE ON FUNCTION public.cancel_vendor_order(uuid, text)            TO authenticated;
GRANT EXECUTE ON FUNCTION public.secure_refund_order_financials(uuid, text) TO authenticated;
GRANT EXECUTE ON FUNCTION public.secure_process_order_financials(uuid)      TO authenticated;
NOTIFY pgrst, 'reload schema';
