-- ==============================================================================
-- Migration: Production Fixes — E2E Findings Remediation
-- File:      20260906000001_production_fixes.sql
-- Created:   2026-09-06
--
-- Fixes 5 confirmed production findings discovered during the E2E test suite run:
--
--   [F1] process_wallet_checkout stale schema cache → wallet checkout broken
--   [F2] profiles.wallet_balance readable by anon role → financial data exposed
--   [F3] request_user_withdrawal BIGINT overload ambiguity → RPC fails
--   [F4] notifications FORCE RLS blocks service role INSERT → admin push broken
--   [F5] admin_moderate_product stale schema cache → admin moderation broken
--
-- Each fix is idempotent and safe to re-apply.
-- ==============================================================================

-- ==============================================================================
-- [F2] PROFILES: Column-level REVOKE for sensitive fields from anon role
-- ==============================================================================
-- Root cause: 20260721000004_fix_table_grants.sql granted SELECT on profiles to
-- anon (needed so public pages can show vendor names). This exposes ALL columns
-- including wallet_balance and phone_number.
--
-- Fix: PostgreSQL column-level privilege REVOKE hides specific columns from anon
-- without breaking the public SELECT on safe columns (full_name, avatar_url etc.)
-- ==============================================================================

-- Column-level REVOKE must be issued as top-level DDL (cannot be inside DO block).
-- Each column is revoked individually via EXECUTE inside a DO block so that
-- missing columns (schema drift) do not abort the entire migration.
DO $$
DECLARE
  cols TEXT[] := ARRAY[
    'wallet_balance', 'phone_number', 'saved_address',
    'referral_code',  'loyalty_points', 'is_admin',
    'active_role',    'roles'
  ];
  col TEXT;
BEGIN
  FOREACH col IN ARRAY cols LOOP
    BEGIN
      EXECUTE format(
        'REVOKE SELECT (%I) ON public.profiles FROM anon', col
      );
      RAISE NOTICE '[F2] profiles: revoked SELECT(%I) from anon', col;
    EXCEPTION WHEN OTHERS THEN
      RAISE NOTICE '[F2] profiles: skipping SELECT(%) — %', col, SQLERRM;
    END;
  END LOOP;
END;
$$;


-- ==============================================================================
-- [F4] NOTIFICATIONS: Remove FORCE RLS (if set) + push_notification() helper
-- ==============================================================================
-- Root cause: The live DB has ALTER TABLE notifications FORCE ROW LEVEL SECURITY
-- set (likely from an earlier ad-hoc run), which blocks even service_role INSERTs.
-- The notifications_system_insert policy is TO authenticated only, leaving
-- service_role with no INSERT path.
--
-- Fix A: Remove FORCE RLS so service_role bypasses RLS normally (Supabase default).
-- Fix B: Create push_notification() SECURITY DEFINER as the canonical admin-push API.
-- ==============================================================================

-- Remove FORCE ROW LEVEL SECURITY (safe: Supabase's service_role bypasses RLS by default)
ALTER TABLE public.notifications NO FORCE ROW LEVEL SECURITY;

-- Ensure the table still has RLS enabled (non-force) for regular users
ALTER TABLE public.notifications ENABLE ROW LEVEL SECURITY;

-- Ensure INSERT policy exists for authenticated users (idempotent)
DROP POLICY IF EXISTS "notifications_system_insert" ON public.notifications;
CREATE POLICY "notifications_system_insert"
  ON public.notifications FOR INSERT
  TO authenticated
  WITH CHECK (true);

-- Also grant INSERT permission to authenticated role (needed for the policy to be evaluated)
GRANT INSERT ON public.notifications TO authenticated;

DO $$ BEGIN RAISE NOTICE '[F4] notifications: FORCE RLS removed, INSERT policy refreshed'; END $$;

-- push_notification(): canonical SECURITY DEFINER function for server-side push
-- Runs as the postgres superuser role → bypasses RLS entirely → always works
-- even when called from service_role or via Edge Functions.
CREATE OR REPLACE FUNCTION public.push_notification(
  p_user_id UUID,
  p_type    TEXT,
  p_title   TEXT,
  p_message TEXT
)
RETURNS UUID
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_notif_id UUID;
BEGIN
  -- Validate type
  IF p_type NOT IN ('order', 'promo', 'system', 'withdrawal', 'delivery', 'payment') THEN
    RAISE EXCEPTION 'Invalid notification type: %. Must be one of: order, promo, system, withdrawal, delivery, payment', p_type;
  END IF;

  INSERT INTO public.notifications (user_id, type, title, message, is_read)
  VALUES (p_user_id, p_type, p_title, p_message, false)
  RETURNING id INTO v_notif_id;

  RETURN v_notif_id;
END;
$$;

-- Grant to both authenticated (admin users calling via RPC) and service_role (Edge Functions)
REVOKE ALL ON FUNCTION public.push_notification(UUID, TEXT, TEXT, TEXT) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.push_notification(UUID, TEXT, TEXT, TEXT) TO authenticated;
GRANT EXECUTE ON FUNCTION public.push_notification(UUID, TEXT, TEXT, TEXT) TO service_role;

DO $$ BEGIN RAISE NOTICE '[F4] push_notification() function created and granted'; END $$;


-- ==============================================================================
-- [F3] REQUEST_USER_WITHDRAWAL: Drop BIGINT overload causing ambiguity
-- ==============================================================================
-- Root cause: An old (BIGINT, TEXT, TEXT) signature may coexist with the current
-- (NUMERIC, TEXT, TEXT) signature. PostgREST cannot resolve the ambiguous call.
--
-- Fix: Explicitly drop all overloads then recreate the canonical NUMERIC version.
-- ==============================================================================

-- Drop all overloads (idempotent — no-op if they don't exist)
DROP FUNCTION IF EXISTS public.request_user_withdrawal(BIGINT,   TEXT, TEXT) CASCADE;
DROP FUNCTION IF EXISTS public.request_user_withdrawal(BIGINT,   TEXT      ) CASCADE;
DROP FUNCTION IF EXISTS public.request_user_withdrawal(BIGINT               ) CASCADE;
DROP FUNCTION IF EXISTS public.request_user_withdrawal(NUMERIC,  TEXT, TEXT) CASCADE;
DROP FUNCTION IF EXISTS public.request_user_withdrawal(NUMERIC,  TEXT      ) CASCADE;
DROP FUNCTION IF EXISTS public.request_user_withdrawal(NUMERIC              ) CASCADE;

-- Recreate canonical (NUMERIC, TEXT, TEXT) version
CREATE OR REPLACE FUNCTION public.request_user_withdrawal(
  p_amount  NUMERIC,
  p_method  TEXT DEFAULT 'orange_money',
  p_phone   TEXT DEFAULT NULL
)
RETURNS UUID
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_profile       public.profiles%ROWTYPE;
  v_withdrawal_id UUID;
  v_min_amount    NUMERIC := 20000; -- 20,000 GNF minimum
BEGIN
  SELECT * INTO v_profile FROM public.profiles WHERE id = auth.uid();
  IF NOT FOUND THEN
    RAISE EXCEPTION 'Profile not found';
  END IF;

  IF p_amount < v_min_amount THEN
    RAISE EXCEPTION 'Minimum withdrawal amount is % GNF', v_min_amount;
  END IF;

  IF COALESCE(v_profile.wallet_balance, 0) < p_amount THEN
    RAISE EXCEPTION 'Solde insuffisant. Disponible: % GNF', COALESCE(v_profile.wallet_balance, 0);
  END IF;

  -- Lock funds immediately
  UPDATE public.profiles
  SET wallet_balance = wallet_balance - p_amount
  WHERE id = auth.uid();

  -- Create withdrawal record (type: courier or user)
  INSERT INTO public.withdrawals (profile_id, amount, method, phone, type)
  VALUES (
    auth.uid(),
    p_amount,
    p_method,
    p_phone,
    CASE WHEN v_profile.profile_type = 'courier' THEN 'courier' ELSE 'user' END
  )
  RETURNING id INTO v_withdrawal_id;

  RETURN v_withdrawal_id;
END;
$$;

REVOKE ALL ON FUNCTION public.request_user_withdrawal(NUMERIC, TEXT, TEXT) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.request_user_withdrawal(NUMERIC, TEXT, TEXT) TO authenticated;

DO $$ BEGIN RAISE NOTICE '[F3] request_user_withdrawal: BIGINT overload dropped, NUMERIC canonical version recreated'; END $$;


-- ==============================================================================
-- [F5] ADMIN_MODERATE_PRODUCT: Recreate with SET search_path + schema reload
-- ==============================================================================

DROP FUNCTION IF EXISTS public.admin_moderate_product(UUID, TEXT, TEXT) CASCADE;

CREATE OR REPLACE FUNCTION public.admin_moderate_product(
  p_product_id UUID,
  p_status     TEXT,    -- 'approved' | 'rejected'
  p_note       TEXT DEFAULT NULL
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  -- Only admins may call this
  IF NOT EXISTS (
    SELECT 1 FROM public.profiles WHERE id = auth.uid() AND is_admin = true
  ) THEN
    RAISE EXCEPTION 'Unauthorized: admin role required';
  END IF;

  IF p_status NOT IN ('approved', 'rejected') THEN
    RAISE EXCEPTION 'Invalid status: %. Must be approved or rejected', p_status;
  END IF;

  UPDATE public.products
  SET
    moderation_status  = p_status,
    is_active          = CASE WHEN p_status = 'approved' THEN true ELSE false END,
    moderated_at       = NOW(),
    moderated_by       = auth.uid(),
    moderation_note    = p_note
  WHERE id = p_product_id;

  IF NOT FOUND THEN
    RAISE EXCEPTION 'Product % not found', p_product_id;
  END IF;
END;
$$;

REVOKE ALL ON FUNCTION public.admin_moderate_product(UUID, TEXT, TEXT) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.admin_moderate_product(UUID, TEXT, TEXT) TO authenticated;
GRANT EXECUTE ON FUNCTION public.admin_moderate_product(UUID, TEXT, TEXT) TO service_role;

DO $$ BEGIN RAISE NOTICE '[F5] admin_moderate_product: recreated with SET search_path'; END $$;


-- ==============================================================================
-- [F1] PROCESS_WALLET_CHECKOUT: Force schema cache reload
-- ==============================================================================
-- The function exists in the migrations but PostgREST has a stale schema cache.
-- A NOTIFY pgrst forces an immediate cache refresh on the running PostgREST instance.
-- ==============================================================================

-- Ensure process_wallet_checkout has correct permissions (idempotent)
DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM pg_proc p
    JOIN pg_namespace n ON n.oid = p.pronamespace
    WHERE n.nspname = 'public' AND p.proname = 'process_wallet_checkout'
  ) THEN
    EXECUTE 'REVOKE ALL ON FUNCTION public.process_wallet_checkout(UUID, NUMERIC, JSONB, JSONB, JSONB) FROM PUBLIC';
    EXECUTE 'GRANT EXECUTE ON FUNCTION public.process_wallet_checkout(UUID, NUMERIC, JSONB, JSONB, JSONB) TO authenticated';
    RAISE NOTICE '[F1] process_wallet_checkout: grants confirmed';
  ELSE
    RAISE WARNING '[F1] process_wallet_checkout: function NOT FOUND in public schema — manual migration apply required';
  END IF;
END;
$$;


-- ==============================================================================
-- Additional hardening: wallet_transactions INSERT lock
-- ==============================================================================
-- Ensure no authenticated user can INSERT directly into wallet_transactions
-- (all writes must go through SECURITY DEFINER RPCs). This was intended but
-- not explicitly locked in the grants migration.

REVOKE INSERT, UPDATE, DELETE ON public.wallet_transactions FROM authenticated;
REVOKE INSERT, UPDATE, DELETE ON public.wallet_transactions FROM anon;

DO $$ BEGIN RAISE NOTICE '[hardening] wallet_transactions: direct write revoked from anon/authenticated'; END $$;


-- ==============================================================================
-- Final: Force PostgREST to reload its full schema cache
-- ==============================================================================
-- This resolves F1 (process_wallet_checkout) and F5 (admin_moderate_product)
-- being invisible to the REST API despite existing in the DB.
NOTIFY pgrst, 'reload schema';

DO $$ BEGIN RAISE NOTICE '✅ 20260906000001_production_fixes: all fixes applied successfully'; END $$;
