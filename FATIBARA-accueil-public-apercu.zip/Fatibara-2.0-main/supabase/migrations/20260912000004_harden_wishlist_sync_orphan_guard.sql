-- Migration: harden sync_wishlist_items to skip deleted products
-- Problem: If a product is deleted from the `products` table while it is still
-- in a user's local (offline) wishlist, syncWithCloud() calls
-- sync_wishlist_items with the orphaned product_id and gets a FK violation
-- (23503). This shows as a 409 error in the console and Commerce sync fails.
--
-- Fix: Filter p_product_ids through a subquery that only keeps IDs that
-- still exist in the products table. The INSERT becomes a no-op for any
-- orphaned IDs instead of throwing a constraint error.
--
-- Also fixes add_wishlist_item the same way (single-item path).

CREATE OR REPLACE FUNCTION public.add_wishlist_item(
  p_product_id uuid
)
RETURNS void
LANGUAGE sql
SECURITY DEFINER
SET search_path = public
AS $$
  -- Only insert if the product still exists; silently skip deleted products.
  INSERT INTO public.user_wishlists (user_id, product_id)
  SELECT auth.uid(), p_product_id
  WHERE EXISTS (SELECT 1 FROM public.products WHERE id = p_product_id)
  ON CONFLICT (user_id, product_id) DO NOTHING;
$$;

CREATE OR REPLACE FUNCTION public.sync_wishlist_items(
  p_product_ids uuid[]
)
RETURNS void
LANGUAGE sql
SECURITY DEFINER
SET search_path = public
AS $$
  -- Join against products so orphaned IDs (deleted products) are silently
  -- dropped instead of causing a FK constraint error (23503 / HTTP 409).
  INSERT INTO public.user_wishlists (user_id, product_id)
  SELECT auth.uid(), p.id
  FROM   unnest(p_product_ids) AS incoming(id)
  JOIN   public.products p ON p.id = incoming.id
  ON CONFLICT (user_id, product_id) DO NOTHING;
$$;

GRANT EXECUTE ON FUNCTION public.add_wishlist_item(uuid)       TO authenticated;
GRANT EXECUTE ON FUNCTION public.sync_wishlist_items(uuid[])   TO authenticated;
