-- =============================================================================
-- Migration: Multi-Role Account Context Switching
-- Created: 2026-08-13
--
-- Changes:
--   1. Add `roles TEXT[]` — the set of all roles a user is permitted to assume.
--   2. Add `active_role TEXT` — the currently active role context.
--   3. Backfill both columns from existing `profile_type` so no user loses access.
--   4. Create `switch_active_role(p_target_role TEXT)` SECURITY DEFINER RPC that
--      validates the caller owns the target role and updates `active_role`.
-- =============================================================================

-- ── 1. Add columns (idempotent) ───────────────────────────────────────────────
ALTER TABLE public.profiles
  ADD COLUMN IF NOT EXISTS roles        TEXT[]  DEFAULT ARRAY['customer']::TEXT[],
  ADD COLUMN IF NOT EXISTS active_role  TEXT    DEFAULT 'customer';

-- ── 2. Backfill from existing profile_type ────────────────────────────────────
-- courier / vendor / admin get both their role AND 'customer' so they can
-- switch to browsing the storefront.  Standard / pro users get only 'customer'.
UPDATE public.profiles
SET
  roles = CASE
    WHEN profile_type IN ('courier', 'vendor', 'admin')
      THEN ARRAY[profile_type, 'customer']::TEXT[]
    ELSE ARRAY['customer']::TEXT[]
  END,
  active_role = CASE
    WHEN profile_type IN ('courier', 'vendor', 'admin')
      THEN profile_type
    ELSE 'customer'
  END
WHERE
  -- Only update rows that still have the default placeholder value so this
  -- migration is safe to re-run (idempotent).
  roles = ARRAY['customer']::TEXT[]
  OR roles IS NULL;

-- Admins get an additional 'admin' entry if not already present (edge-case:
-- users whose is_admin=true but profile_type != 'admin').
UPDATE public.profiles
SET
  roles = ARRAY(SELECT DISTINCT unnest(roles || ARRAY['admin']::TEXT[])),
  active_role = 'admin'
WHERE
  is_admin = TRUE
  AND NOT ('admin' = ANY(roles));

-- ── 3. switch_active_role RPC ─────────────────────────────────────────────────
-- SECURITY DEFINER so it can update any row while bypassing RLS, but it
-- ALWAYS constrains writes to auth.uid() — callers can never switch another
-- user's active role.
DROP FUNCTION IF EXISTS public.switch_active_role(TEXT) CASCADE;

CREATE OR REPLACE FUNCTION public.switch_active_role(p_target_role TEXT)
RETURNS VOID
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_allowed_roles TEXT[];
BEGIN
  -- Fetch the caller's allowed roles array
  SELECT roles INTO v_allowed_roles
  FROM public.profiles
  WHERE id = auth.uid();

  IF NOT FOUND THEN
    RAISE EXCEPTION 'Profile not found for caller';
  END IF;

  IF NOT (p_target_role = ANY(v_allowed_roles)) THEN
    RAISE EXCEPTION 'Unauthorized role switch: % is not in allowed roles for this account', p_target_role;
  END IF;

  UPDATE public.profiles
  SET active_role = p_target_role
  WHERE id = auth.uid();
END;
$$;

GRANT EXECUTE ON FUNCTION public.switch_active_role(TEXT) TO authenticated;

-- ── 4. Expose new columns in the PostgREST schema cache ───────────────────────
NOTIFY pgrst, 'reload schema';
