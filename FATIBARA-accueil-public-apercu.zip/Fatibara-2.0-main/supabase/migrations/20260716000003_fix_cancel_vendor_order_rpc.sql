-- ==============================================================================
-- Migration: Fix cancel_vendor_order RPC — remove non-existent payment_method
-- Created At: 2026-07-16
-- Author:     Antigravity / Fatibara Engineering
--
-- ROOT CAUSE:
--   cancel_vendor_order() referenced v_order.payment_method which does NOT
--   exist on the orders table (confirmed via information_schema introspection).
--   The live orders schema has: id, vendor_id, user_id, total_amount,
--   delivery_fee, shipping_address, items_count, status, created_at,
--   updated_at, financial_status, vendor_delivery_fee, customer_name,
--   tracking_number, delivery_otp, courier_id, delivery_notes,
--   completed_at, store_id — no payment_method column.
--
-- FIX:
--   Replace the payment_method check with financial_status = 'paid'.
--   This is semantically correct: a refund is only needed when money was
--   actually collected (financial_status = 'paid') and the order has
--   progressed past 'pending'. The financial_status column already exists
--   and correctly tracks the payment lifecycle.
-- ==============================================================================

CREATE OR REPLACE FUNCTION public.cancel_vendor_order(
    target_order_id uuid,
    cancel_reason   text
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_order       public.orders%ROWTYPE;
    v_needs_refund BOOLEAN;
BEGIN
    SELECT * INTO v_order
    FROM public.orders
    WHERE id = target_order_id
    FOR UPDATE;

    IF NOT FOUND THEN
        RAISE EXCEPTION 'Order not found';
    END IF;

    IF v_order.vendor_id != auth.uid() THEN
        RAISE EXCEPTION 'Unauthorized: You do not own this store';
    END IF;

    IF v_order.status IN ('delivered', 'cancelled') THEN
        RAISE EXCEPTION 'Order is already in a terminal state';
    END IF;

    IF v_order.financial_status = 'refunded' THEN
        RAISE EXCEPTION 'Order already refunded';
    END IF;

    -- Refund is needed when money was collected (financial_status = 'paid')
    -- and the order progressed past the pending/unpaid stage.
    v_needs_refund := (v_order.financial_status = 'paid')
                      AND (v_order.status NOT IN ('pending', 'cancelled'));

    IF v_needs_refund THEN
        -- Credit back to user wallet
        UPDATE public.profiles
        SET wallet_balance = wallet_balance + ROUND(v_order.total_amount)
        WHERE id = v_order.user_id;

        INSERT INTO public.wallet_transactions (profile_id, amount, type, reference_id, description)
        VALUES (
            v_order.user_id,
            v_order.total_amount,
            'refund',
            target_order_id,
            'Remboursement Commande #' || left(target_order_id::text, 8) || ' (' || cancel_reason || ')'
        );
    END IF;

    UPDATE public.orders
    SET
        status           = 'cancelled',
        financial_status = CASE WHEN v_needs_refund THEN 'refunded' ELSE financial_status END,
        updated_at       = now()
    WHERE id = target_order_id;
END;
$$;

GRANT EXECUTE ON FUNCTION public.cancel_vendor_order(uuid, text) TO authenticated;
NOTIFY pgrst, 'reload schema';
