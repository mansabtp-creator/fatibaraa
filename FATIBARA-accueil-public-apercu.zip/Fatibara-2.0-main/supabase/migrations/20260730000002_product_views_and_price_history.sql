-- =============================================================================
-- Migration: product_views and price_history tables
-- Created: 2026-07-30
-- Adds:
--   1. product_views   (ProductPage analytics, AnalyticsDashboard)
--   2. price_history   (PriceHistory component on ProductPage)
-- =============================================================================

-- ── 1. product_views ──────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS public.product_views (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  product_id  UUID NOT NULL REFERENCES public.products(id) ON DELETE CASCADE,
  viewer_id   UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  session_id  TEXT,
  viewed_at   TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Add any columns that may be missing if the table pre-existed
ALTER TABLE public.product_views ADD COLUMN IF NOT EXISTS viewer_id  UUID REFERENCES auth.users(id) ON DELETE SET NULL;
ALTER TABLE public.product_views ADD COLUMN IF NOT EXISTS session_id TEXT;
ALTER TABLE public.product_views ADD COLUMN IF NOT EXISTS viewed_at  TIMESTAMPTZ NOT NULL DEFAULT NOW();

CREATE INDEX IF NOT EXISTS idx_product_views_product_id ON public.product_views(product_id);
CREATE INDEX IF NOT EXISTS idx_product_views_viewer_id  ON public.product_views(viewer_id);
CREATE INDEX IF NOT EXISTS idx_product_views_viewed_at  ON public.product_views(viewed_at);

ALTER TABLE public.product_views ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "product_views_anon_insert"  ON public.product_views;
CREATE POLICY "product_views_anon_insert"
  ON public.product_views FOR INSERT
  WITH CHECK (true);  -- Anyone can record a view (including anon)

DROP POLICY IF EXISTS "product_views_owner_select" ON public.product_views;
CREATE POLICY "product_views_owner_select"
  ON public.product_views FOR SELECT TO authenticated
  USING (
    product_id IN (
      SELECT p.id FROM public.products p
      JOIN public.stores s ON s.id = p.store_id
      WHERE s.owner_id = auth.uid()
    )
    OR EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND is_admin = true)
  );

GRANT INSERT ON public.product_views TO anon;
GRANT SELECT, INSERT ON public.product_views TO authenticated;
GRANT ALL ON public.product_views TO service_role;

-- ── 2. price_history ──────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS public.price_history (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  product_id  UUID NOT NULL REFERENCES public.products(id) ON DELETE CASCADE,
  price       NUMERIC(12, 2) NOT NULL CHECK (price >= 0),
  recorded_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_price_history_product_id   ON public.price_history(product_id);
CREATE INDEX IF NOT EXISTS idx_price_history_recorded_at  ON public.price_history(recorded_at);

ALTER TABLE public.price_history ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "price_history_public_read"   ON public.price_history;
CREATE POLICY "price_history_public_read"
  ON public.price_history FOR SELECT USING (true);

DROP POLICY IF EXISTS "price_history_service_write" ON public.price_history;
CREATE POLICY "price_history_service_write"
  ON public.price_history FOR INSERT TO authenticated
  WITH CHECK (
    product_id IN (
      SELECT p.id FROM public.products p
      JOIN public.stores s ON s.id = p.store_id
      WHERE s.owner_id = auth.uid()
    )
  );

GRANT SELECT ON public.price_history TO anon;
GRANT SELECT, INSERT ON public.price_history TO authenticated;
GRANT ALL ON public.price_history TO service_role;

-- Reload schema cache
NOTIFY pgrst, 'reload schema';
