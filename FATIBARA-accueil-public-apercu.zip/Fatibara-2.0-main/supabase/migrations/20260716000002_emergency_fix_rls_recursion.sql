-- ==============================================================================
-- EMERGENCY HOTFIX: 42P17 Infinite Recursion on orders PATCH
-- Created At: 2026-07-16
-- Author:     Antigravity / Fatibara Engineering
--
-- ROOT CAUSE:
--   The 20260712 migration created TWO recursive artifacts never fully cleaned:
--   1. "Couriers can claim orders" policy — uses EXISTS(SELECT FROM profiles)
--      inside USING → triggers orders RLS re-evaluation → infinite loop.
--   2. enforce_order_state_machine_constraints() trigger — SECURITY DEFINER
--      that calls EXISTS(SELECT FROM profiles WHERE is_admin=true) → same loop.
--   Multiple overlapping UPDATE policies compound the issue.
--
-- FIX:
--   1. Drop the recursive trigger + function
--   2. Drop ALL known policies on orders (exhaustive list)
--   3. Recreate exactly 4 clean flat policies (zero subqueries)
--   4. Flush PostgREST cache
-- ==============================================================================

-- ── STEP 1: KILL THE RECURSIVE TRIGGER ──────────────────────────────────────
DROP TRIGGER  IF EXISTS trg_enforce_order_state_machine_constraints ON public.orders;
DROP FUNCTION IF EXISTS public.enforce_order_state_machine_constraints();

-- ── STEP 2: DROP EVERY KNOWN POLICY ─────────────────────────────────────────
DROP POLICY IF EXISTS "Couriers can claim orders"                     ON public.orders;
DROP POLICY IF EXISTS "Vendors can transition order status"           ON public.orders;
DROP POLICY IF EXISTS "Enable read access for all users"              ON public.orders;
DROP POLICY IF EXISTS "Enable insert for authenticated users only"    ON public.orders;
DROP POLICY IF EXISTS "Enable update for users based on email"        ON public.orders;
DROP POLICY IF EXISTS "Enable delete for users based on email"        ON public.orders;
DROP POLICY IF EXISTS "Vendors can view their own orders"             ON public.orders;
DROP POLICY IF EXISTS "Vendors can update their own orders"           ON public.orders;
DROP POLICY IF EXISTS "Vendors can insert orders"                     ON public.orders;
DROP POLICY IF EXISTS "Clients can view their own orders"             ON public.orders;
DROP POLICY IF EXISTS "Clients can insert their own orders"           ON public.orders;
DROP POLICY IF EXISTS "Users can view their own orders"               ON public.orders;
DROP POLICY IF EXISTS "Users can insert their own orders"             ON public.orders;
DROP POLICY IF EXISTS "Couriers can view assigned orders"             ON public.orders;
DROP POLICY IF EXISTS "Couriers can update assigned orders"           ON public.orders;
DROP POLICY IF EXISTS "Admins can view all orders"                    ON public.orders;
DROP POLICY IF EXISTS "Admins can update all orders"                  ON public.orders;
DROP POLICY IF EXISTS "Service role full access"                      ON public.orders;
DROP POLICY IF EXISTS "orders_select_policy"                          ON public.orders;
DROP POLICY IF EXISTS "orders_insert_policy"                          ON public.orders;
DROP POLICY IF EXISTS "orders_update_policy"                          ON public.orders;
DROP POLICY IF EXISTS "orders_delete_policy"                          ON public.orders;
DROP POLICY IF EXISTS "Fatibara flat orders read policy"              ON public.orders;
DROP POLICY IF EXISTS "Fatibara flat orders insert policy"            ON public.orders;
DROP POLICY IF EXISTS "Fatibara flat orders update policy"            ON public.orders;
DROP POLICY IF EXISTS "Fatibara flat orders delete policy"            ON public.orders;
DROP POLICY IF EXISTS "orders_select_v2"                              ON public.orders;
DROP POLICY IF EXISTS "orders_insert_v2"                              ON public.orders;
DROP POLICY IF EXISTS "orders_update_v2"                              ON public.orders;
DROP POLICY IF EXISTS "orders_delete_v2"                              ON public.orders;

-- ── STEP 3: ENABLE RLS + RECREATE 4 FLAT POLICIES ───────────────────────────
ALTER TABLE public.orders ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "orders_select_v3" ON public.orders;
CREATE POLICY "orders_select_v3"
ON public.orders FOR SELECT TO authenticated
USING (auth.uid() = user_id OR auth.uid() = vendor_id OR auth.uid() = courier_id);

DROP POLICY IF EXISTS "orders_insert_v3" ON public.orders;
CREATE POLICY "orders_insert_v3"
ON public.orders FOR INSERT TO authenticated
WITH CHECK (auth.uid() = user_id);

-- Vendor transitions + courier claiming in ONE flat expression. No subqueries.
DROP POLICY IF EXISTS "orders_update_v3" ON public.orders;
CREATE POLICY "orders_update_v3"
ON public.orders FOR UPDATE TO authenticated
USING (auth.uid() = vendor_id OR auth.uid() = courier_id)
WITH CHECK (auth.uid() = vendor_id OR auth.uid() = courier_id);

DROP POLICY IF EXISTS "orders_delete_v3" ON public.orders;
CREATE POLICY "orders_delete_v3"
ON public.orders FOR DELETE TO authenticated
USING (auth.uid() = vendor_id);

-- ── STEP 4: GRANTS ───────────────────────────────────────────────────────────
GRANT SELECT, INSERT, UPDATE, DELETE ON public.orders TO authenticated;
GRANT ALL ON public.orders TO service_role;
GRANT ALL ON public.orders TO postgres;

-- ── STEP 5: FLUSH POSTGREST CACHE ────────────────────────────────────────────
NOTIFY pgrst, 'reload schema';

-- ── VERIFICATION (run separately after applying) ─────────────────────────────
-- SELECT policyname, cmd FROM pg_policies
-- WHERE schemaname = 'public' AND tablename = 'orders'
-- ORDER BY cmd, policyname;
-- Expected: exactly 4 rows named orders_*_v3

-- ==============================================================================
-- ADDENDUM (applied 2026-07-16): Additional stale policies found on live DB
-- These had different names not present in any migration file — they existed
-- from manual edits directly in the Supabase dashboard.
-- All dropped via CLI after discovery.
-- ==============================================================================
DROP POLICY IF EXISTS "Admins have full order access"                  ON public.orders;
DROP POLICY IF EXISTS "Allow authenticated insert"                     ON public.orders;
DROP POLICY IF EXISTS "Fatibara flat insert policy"                    ON public.orders;
DROP POLICY IF EXISTS "orders_insert_own"                              ON public.orders;
DROP POLICY IF EXISTS "Allow authenticated read"                       ON public.orders;
DROP POLICY IF EXISTS "Fatibara flat orders select policy"             ON public.orders;
DROP POLICY IF EXISTS "Fatibara flat read policy"                      ON public.orders;
DROP POLICY IF EXISTS "Vendors can view orders for their products"     ON public.orders;
DROP POLICY IF EXISTS "orders_read_authenticated"                      ON public.orders;
DROP POLICY IF EXISTS "Allow authenticated update"                     ON public.orders;
DROP POLICY IF EXISTS "Fatibara flat update policy"                    ON public.orders;
DROP POLICY IF EXISTS "Terminally locked orders cannot be modified"    ON public.orders;
DROP POLICY IF EXISTS "Vendors can update status of their orders"      ON public.orders;
DROP POLICY IF EXISTS "orders_update_parties"                          ON public.orders;
