-- =============================================================================
-- Fix: chat_channels missing FK constraints (store_id → stores, buyer_id → profiles)
-- Without these FK constraints PostgREST cannot resolve joins like
--   chat_channels(..., stores(store_name, avatar_url, owner_id))
-- which causes PGRST200 "Could not find a relationship" errors.
-- =============================================================================

-- ── 1. Add FK from chat_channels.store_id → stores(id) ───────────────────────
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.table_constraints tc
    JOIN information_schema.key_column_usage kcu
      ON tc.constraint_name = kcu.constraint_name
    WHERE tc.table_schema = 'public'
      AND tc.table_name   = 'chat_channels'
      AND tc.constraint_type = 'FOREIGN KEY'
      AND kcu.column_name = 'store_id'
  ) THEN
    ALTER TABLE public.chat_channels
      ADD CONSTRAINT chat_channels_store_id_fkey
      FOREIGN KEY (store_id) REFERENCES public.stores(id) ON DELETE CASCADE;
  END IF;
END $$;

-- ── 2. Add FK from chat_channels.buyer_id → profiles(id) ─────────────────────
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.table_constraints tc
    JOIN information_schema.key_column_usage kcu
      ON tc.constraint_name = kcu.constraint_name
    WHERE tc.table_schema = 'public'
      AND tc.table_name   = 'chat_channels'
      AND tc.constraint_type = 'FOREIGN KEY'
      AND kcu.column_name = 'buyer_id'
  ) THEN
    ALTER TABLE public.chat_channels
      ADD CONSTRAINT chat_channels_buyer_id_fkey
      FOREIGN KEY (buyer_id) REFERENCES public.profiles(id) ON DELETE CASCADE;
  END IF;
END $$;

-- ── 3. Add FK from chat_messages.channel_id → chat_channels(id) ──────────────
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.table_constraints tc
    JOIN information_schema.key_column_usage kcu
      ON tc.constraint_name = kcu.constraint_name
    WHERE tc.table_schema = 'public'
      AND tc.table_name   = 'chat_messages'
      AND tc.constraint_type = 'FOREIGN KEY'
      AND kcu.column_name = 'channel_id'
  ) THEN
    ALTER TABLE public.chat_messages
      ADD CONSTRAINT chat_messages_channel_id_fkey
      FOREIGN KEY (channel_id) REFERENCES public.chat_channels(id) ON DELETE CASCADE;
  END IF;
END $$;

-- ── 4. Add FK from chat_messages.sender_id → profiles(id) ────────────────────
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.table_constraints tc
    JOIN information_schema.key_column_usage kcu
      ON tc.constraint_name = kcu.constraint_name
    WHERE tc.table_schema = 'public'
      AND tc.table_name   = 'chat_messages'
      AND tc.constraint_type = 'FOREIGN KEY'
      AND kcu.column_name = 'sender_id'
  ) THEN
    ALTER TABLE public.chat_messages
      ADD CONSTRAINT chat_messages_sender_id_fkey
      FOREIGN KEY (sender_id) REFERENCES public.profiles(id) ON DELETE CASCADE;
  END IF;
END $$;

-- ── 5. Reload PostgREST schema cache so joins resolve immediately ─────────────
NOTIFY pgrst, 'reload schema';
