-- Migration: product moderation queue
-- Adds `moderation_status` to products so admins can approve/reject
-- new submissions before they appear on the public storefront.
--
-- States:
--   approved  → visible normally (default for existing products)
--   pending   → submitted but not yet reviewed (new products from QuickAddWizard)
--   rejected  → admin rejected; is_active set to false
--
-- Created: 2026-07-23

ALTER TABLE public.products
  ADD COLUMN IF NOT EXISTS moderation_status TEXT
    NOT NULL DEFAULT 'approved'
    CHECK (moderation_status IN ('pending', 'approved', 'rejected'));

ALTER TABLE public.products
  ADD COLUMN IF NOT EXISTS moderation_note TEXT;

ALTER TABLE public.products
  ADD COLUMN IF NOT EXISTS moderated_at TIMESTAMPTZ;

ALTER TABLE public.products
  ADD COLUMN IF NOT EXISTS moderated_by UUID REFERENCES auth.users(id) ON DELETE SET NULL;

-- Index for admin moderation queue query
CREATE INDEX IF NOT EXISTS idx_products_moderation_status
  ON public.products (moderation_status, created_at DESC);

-- RPC: admin_moderate_product
-- Approve or reject a product in one atomic operation.
-- Sets moderation_status, is_active, and records who/when.
CREATE OR REPLACE FUNCTION public.admin_moderate_product(
  p_product_id UUID,
  p_status     TEXT,   -- 'approved' | 'rejected'
  p_note       TEXT DEFAULT NULL
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  -- Only admins may call this
  IF NOT EXISTS (
    SELECT 1 FROM public.profiles WHERE id = auth.uid() AND is_admin = true
  ) THEN
    RAISE EXCEPTION 'Unauthorized: admin role required';
  END IF;

  UPDATE public.products
  SET
    moderation_status = p_status,
    is_active         = (p_status = 'approved'),
    moderation_note   = p_note,
    moderated_at      = NOW(),
    moderated_by      = auth.uid()
  WHERE id = p_product_id;
END;
$$;

-- Grant execute to authenticated (RLS inside function enforces admin-only)
GRANT EXECUTE ON FUNCTION public.admin_moderate_product(UUID, TEXT, TEXT)
  TO authenticated;
