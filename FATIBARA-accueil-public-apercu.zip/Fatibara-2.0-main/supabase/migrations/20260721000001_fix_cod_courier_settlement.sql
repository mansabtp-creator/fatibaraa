-- ==============================================================================
-- Migration: Fix COD courier payout negative wallet + vendor store_id ledger
-- Created At: 2026-07-21
-- Author:     Antigravity / Fatibara Engineering
--
-- ISSUES FIXED:
--
--   1. COD DELIVERY: constraint violation on courier wallet
--      ─────────────────────────────────────────────────────
--      When an order is paid in cash (COD), secure_process_order_financials
--      computes:
--        v_final_courier_digital_change = courier_payout - total_amount
--      which is NEGATIVE (the courier collected cash and owes it to the platform).
--      The UPDATE then tries to write wallet_balance + (-238,000) = -238,000
--      which violates CHECK (wallet_balance >= 0).
--
--      The auto_settle trigger wraps this in EXCEPTION WHEN OTHERS so the
--      order delivery UPDATE succeeds, but the financial settlement is silently
--      skipped — leaving orders with financial_status='pending' forever.
--
--      FIX: Before applying a negative digital change to the courier wallet,
--      check the current balance. If balance < |change|, set the order to
--      financial_status='pending' and return a structured error instead of
--      raising an unhandled exception. The trigger can then log this clearly.
--
--   2. VENDOR WALLET TRANSACTION: missing store_id
--      ──────────────────────────────────────────────
--      wallet_transactions for vendor sales set profile_id=vendor_id but leave
--      store_id NULL. The RLS policy "wt_select_store" filters by store_id, so
--      vendor transaction history is invisible to the store owner via that policy.
--      FIX: Populate store_id = v_store.id in the vendor wallet_transaction INSERT.
--
-- ==============================================================================

CREATE OR REPLACE FUNCTION public.secure_process_order_financials(p_order_id uuid)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
    v_order                        RECORD;
    v_store                        RECORD;
    v_existing_tx                  BOOLEAN;
    v_commission_str               TEXT;
    v_commission_rate              NUMERIC;
    v_items_real_value             NUMERIC := 0;
    v_item_subtotal                NUMERIC;
    v_platform_commission          NUMERIC;
    v_vendor_payout                NUMERIC;
    v_courier_payout               NUMERIC;
    v_is_cash_payment              BOOLEAN;
    v_final_vendor_digital_change  NUMERIC;
    v_final_courier_digital_change NUMERIC;
    v_courier_balance              NUMERIC;
BEGIN
    -- ── 1. Lock order row (prevents concurrent settlement) ────────────────────
    SELECT * INTO v_order FROM public.orders WHERE id = p_order_id FOR UPDATE;
    IF NOT FOUND THEN RAISE EXCEPTION 'Order not found'; END IF;

    -- ── 2. Idempotency: already processed ─────────────────────────────────────
    IF v_order.financial_status = 'processed' THEN
        RETURN jsonb_build_object('success', true, 'alreadyProcessed', true);
    END IF;

    SELECT EXISTS (
        SELECT 1 FROM public.wallet_transactions
        WHERE reference_id = p_order_id AND type = 'sale'
    ) INTO v_existing_tx;

    IF v_existing_tx THEN
        UPDATE public.orders SET financial_status = 'processed' WHERE id = p_order_id;
        RETURN jsonb_build_object('success', true, 'alreadyProcessed', true);
    END IF;

    -- ── 3. Resolve store ──────────────────────────────────────────────────────
    SELECT * INTO v_store FROM public.stores
    WHERE id = v_order.store_id
       OR (v_order.store_id IS NULL AND owner_id = v_order.vendor_id)
    LIMIT 1;

    -- ── 4. Commission arithmetic ──────────────────────────────────────────────
    v_items_real_value := v_order.total_amount - COALESCE(v_order.delivery_fee, 0);

    SELECT value INTO v_commission_str FROM public.platform_settings WHERE id = 'commission_rate';
    IF v_commission_str IS NULL THEN v_commission_str := '5'; END IF;
    v_commission_rate := v_commission_str::numeric / 100.0;

    v_item_subtotal       := v_items_real_value / (1 + v_commission_rate);
    v_platform_commission := v_item_subtotal * v_commission_rate;
    v_vendor_payout       := v_item_subtotal - COALESCE(v_order.vendor_delivery_fee, 0);
    v_courier_payout      := (CASE WHEN COALESCE(v_order.delivery_fee, 0) > 0
                                   THEN v_order.delivery_fee
                                   ELSE COALESCE(v_order.vendor_delivery_fee, 0) END) * 0.8;

    -- If no courier assigned, vendor absorbs the courier payout
    IF v_order.courier_id IS NULL THEN
        v_vendor_payout := v_vendor_payout + v_courier_payout;
    END IF;

    -- Determine payment method (stored in shipping_address JSONB by checkout RPCs)
    -- Fallback: treat as cash when financial_status != 'paid'
    v_is_cash_payment := COALESCE(
        (v_order.shipping_address->>'payment_method') = 'cash',
        v_order.financial_status != 'paid'
    );

    -- ── 5. Vendor payout ──────────────────────────────────────────────────────
    IF v_store.id IS NOT NULL THEN
        v_final_vendor_digital_change := v_vendor_payout;
        -- COD + no courier: vendor collected cash, platform retains commission
        IF v_is_cash_payment AND v_order.courier_id IS NULL THEN
            v_final_vendor_digital_change := v_vendor_payout - v_order.total_amount;
        END IF;

        IF v_final_vendor_digital_change != 0 THEN
            UPDATE public.stores
            SET balance = COALESCE(balance, 0) + ROUND(v_final_vendor_digital_change)
            WHERE id = v_store.id;

            INSERT INTO public.wallet_transactions
              (profile_id, store_id, amount, type, reference_id, description)
            VALUES (
                v_order.vendor_id,
                v_store.id,                  -- ← FIX: populate store_id
                v_final_vendor_digital_change,
                CASE WHEN v_final_vendor_digital_change > 0 THEN 'sale' ELSE 'fee' END,
                v_order.id,
                CASE WHEN v_is_cash_payment
                     THEN 'Collecte Cash #' || left(v_order.id::text, 8)
                          || ' (Retenue: ' || abs(ROUND(v_final_vendor_digital_change)) || ')'
                     ELSE 'Vente #' || left(v_order.id::text, 8)
                          || ' (Payout ' || ROUND(v_item_subtotal) || ')'
                END
            );
        END IF;
    END IF;

    -- ── 6. Courier payout — with COD negative-balance guard ──────────────────
    IF v_order.courier_id IS NOT NULL THEN
        v_final_courier_digital_change := v_courier_payout;
        IF v_is_cash_payment THEN
            -- COD: courier owes (total_amount - courier_payout) to the platform.
            -- We debit the courier's wallet to collect this cash obligation.
            v_final_courier_digital_change := v_courier_payout - v_order.total_amount;
        END IF;

        IF v_final_courier_digital_change != 0 THEN
            IF v_final_courier_digital_change < 0 THEN
                -- ── GUARD: check courier has enough balance before deducting ──
                SELECT wallet_balance INTO v_courier_balance
                FROM public.profiles
                WHERE id = v_order.courier_id
                FOR UPDATE;

                IF v_courier_balance + v_final_courier_digital_change < 0 THEN
                    -- Courier cannot cover COD debt digitally.
                    -- Leave order as financial_status='pending' for manual settlement.
                    -- Do NOT raise — the trigger must not be blocked.
                    RETURN jsonb_build_object(
                        'success',       false,
                        'error',         'cod_courier_insufficient_balance',
                        'message',       format(
                            'Courier wallet too low for COD settlement. Balance: %s GNF, Required: %s GNF. Order flagged for manual collection.',
                            ROUND(v_courier_balance),
                            ROUND(abs(v_final_courier_digital_change))
                        ),
                        'courierBalance', ROUND(v_courier_balance),
                        'debtAmount',    ROUND(abs(v_final_courier_digital_change))
                    );
                END IF;
            END IF;

            UPDATE public.profiles
            SET wallet_balance = wallet_balance + ROUND(v_final_courier_digital_change)
            WHERE id = v_order.courier_id;

            INSERT INTO public.wallet_transactions
              (profile_id, amount, type, reference_id, description)
            VALUES (
                v_order.courier_id,
                v_final_courier_digital_change,
                CASE WHEN v_final_courier_digital_change > 0 THEN 'delivery_fee' ELSE 'fee' END,
                v_order.id,
                CASE WHEN v_is_cash_payment
                     THEN 'Collecte Cash #' || left(v_order.id::text, 8)
                          || ' (Retenue: ' || abs(ROUND(v_final_courier_digital_change)) || ')'
                     ELSE 'Course effectuée — Commande #' || left(v_order.id::text, 8)
                END
            );
        END IF;
    END IF;

    -- ── 7. Platform commission log ────────────────────────────────────────────
    INSERT INTO public.platform_logs (type, amount, reference_id, metadata)
    VALUES (
        'commission',
        ROUND(v_platform_commission),
        v_order.id,
        jsonb_build_object(
            'order_total',  v_order.total_amount,
            'vendor_id',    v_order.vendor_id,
            'is_cash',      v_is_cash_payment,
            'test',         false
        )
    );

    -- ── 8. Mark order as financially settled ─────────────────────────────────
    UPDATE public.orders SET financial_status = 'processed' WHERE id = p_order_id;

    RETURN jsonb_build_object(
        'success',            true,
        'vendorPayout',       ROUND(v_vendor_payout),
        'courierPayout',      ROUND(v_courier_payout),
        'platformCommission', ROUND(v_platform_commission)
    );
END;
$$;

-- Re-grant execute (SECURITY DEFINER but explicit grant for auditability)
GRANT EXECUTE ON FUNCTION public.secure_process_order_financials(uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION public.secure_process_order_financials(uuid) TO service_role;

NOTIFY pgrst, 'reload schema';
