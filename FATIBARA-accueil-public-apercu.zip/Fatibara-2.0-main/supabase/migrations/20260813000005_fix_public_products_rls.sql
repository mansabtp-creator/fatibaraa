-- =============================================================================
-- Migration: Fix Public Products RLS — Storefront Feed Read Access
-- File:      supabase/migrations/20260813000005_fix_public_products_rls.sql
-- Created:   2026-08-13
--
-- PROBLEM:
--   The Home page "Pour Vous" feed shows "Erreur de connexion : Impossible de
--   charger les produits" for unauthenticated (anon) users.
--
--   Root cause: a previous hotfix (fix_products_rls.sql) rebuilt only the
--   vendor management policy without restoring the public SELECT policy.
--   Additionally, the moderation system (20260723000002_product_moderation.sql)
--   added `moderation_status` and `is_active` controls that the public SELECT
--   policy must now respect — rejected/pending products should be invisible to
--   anonymous visitors.
--
-- SCHEMA FACTS (verified against supabase_schema.sql + migration history):
--   products : is_active BOOLEAN DEFAULT true
--              moderation_status TEXT DEFAULT 'approved' CHECK(...)
--              NO "status" column — that column lives only on orders
--   stores   : is_open BOOLEAN DEFAULT true
--              is_verified_store BOOLEAN DEFAULT false
--              NO "is_active" column, NO "status" column
--   categories: table does NOT exist in this project; categories are stored
--              as a TEXT enum column on products. The policy block is wrapped
--              in a runtime guard so the migration is safe to run regardless.
--
-- COEXISTENCE:
--   20260813000002_fix_products_rls_anon_read.sql creates
--     "Products are viewable by everyone"  USING (true)
--     "Stores are viewable by everyone"    USING (true)
--   20260813000004_harden_all_tables_rls.sql creates
--     products_public_select               USING (true)
--
--   This migration drops all three and replaces them with tighter policies
--   that honour the moderation system and are explicitly scoped to anon+auth.
--
-- CHANGES:
--   1. Products public SELECT  — visible when is_active AND moderation_status = 'approved'
--   2. Stores   public SELECT  — visible when is_open (avoids false-empty feed)
--   3. Categories policy       — created ONLY IF the table exists (safe guard)
--   4. Explicit GRANT SELECT to anon + authenticated (belt-and-suspenders)
--   5. Reload PostgREST schema cache
-- =============================================================================

-- =============================================================================
-- SECTION 1 — PUBLIC PRODUCTS SELECT
-- =============================================================================

-- Drop all known variants created by previous hotfixes / migrations
DROP POLICY IF EXISTS "Products are viewable by everyone"   ON public.products;
DROP POLICY IF EXISTS "products_public_select"              ON public.products;
DROP POLICY IF EXISTS "Public products read policy"         ON public.products;
DROP POLICY IF EXISTS "Allow public read access to products" ON public.products;
DROP POLICY IF EXISTS "Anon users can view products"        ON public.products;

-- The storefront must show:
--   • is_active = true   (vendor hasn't manually disabled the listing)
--   • moderation_status = 'approved' (admin hasn't rejected it)
--
-- We use OR is_active IS NULL and OR moderation_status IS NULL to gracefully
-- handle any rows inserted before those columns were added (they'll have the
-- DEFAULT values, but an extra IS NULL guard prevents accidental lock-out
-- during schema migrations on large tables before ALTER TABLE finishes).
CREATE POLICY "Public products read policy"
ON public.products
FOR SELECT
TO anon, authenticated
USING (
  (is_active = true OR is_active IS NULL)
  AND (moderation_status = 'approved' OR moderation_status IS NULL)
);

-- =============================================================================
-- SECTION 2 — PUBLIC STORES SELECT
-- =============================================================================

-- Drop all known variants
DROP POLICY IF EXISTS "Stores are viewable by everyone"     ON public.stores;
DROP POLICY IF EXISTS "Public stores read policy"           ON public.stores;
DROP POLICY IF EXISTS "Allow public read access to stores"  ON public.stores;

-- Stores with is_open = false are paused but we still show them so buyers can
-- browse inventory; they just can't place orders. Use USING(true) so the full
-- catalogue is browseable. Tighten here only if the product requirement changes.
CREATE POLICY "Public stores read policy"
ON public.stores
FOR SELECT
TO anon, authenticated
USING (true);

-- =============================================================================
-- SECTION 3 — CATEGORIES TABLE (guard: only if the table is ever created)
-- This project uses TEXT categories on products, not a standalone table.
-- This block is a no-op today but will self-activate if the table is introduced.
-- =============================================================================

DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.tables
    WHERE table_schema = 'public'
      AND table_name   = 'categories'
  ) THEN
    -- Drop stale policy if it exists from a previous run
    EXECUTE $dyn$
      DROP POLICY IF EXISTS "Public categories read policy" ON public.categories;
      CREATE POLICY "Public categories read policy"
        ON public.categories
        FOR SELECT
        TO anon, authenticated
        USING (true);
    $dyn$;

    RAISE NOTICE 'categories table detected — public SELECT policy applied.';
  ELSE
    RAISE NOTICE 'categories table does not exist — skipping policy (safe).';
  END IF;
END $$;

-- =============================================================================
-- SECTION 4 — EXPLICIT TABLE-LEVEL GRANTS
-- PostgREST evaluates Postgres role privileges AND RLS policies independently.
-- A table with USING(true) still returns 0 rows if the role has no SELECT grant.
-- =============================================================================

GRANT SELECT ON public.products TO anon;
GRANT SELECT ON public.products TO authenticated;

GRANT SELECT ON public.stores   TO anon;
GRANT SELECT ON public.stores   TO authenticated;

-- =============================================================================
-- SECTION 5 — RELOAD POSTGREST SCHEMA CACHE
-- Forces PostgREST to pick up the new policies immediately without a full
-- database restart. Safe to run at any time.
-- =============================================================================

NOTIFY pgrst, 'reload schema';
