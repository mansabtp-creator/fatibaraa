-- =============================================================================
-- Migration: 20260908000002_fix_courier_status_rpc.sql
-- Add admin_set_courier_status SECURITY DEFINER RPC for the DISPO/COURSE/
-- HORS LGN/SUSPEND buttons in the admin courier fleet panel.
-- =============================================================================

DROP FUNCTION IF EXISTS public.admin_set_courier_status(uuid, text, text);

CREATE OR REPLACE FUNCTION public.admin_set_courier_status(
  target_user_id       uuid,
  new_courier_status   text,   -- 'disponible' | 'en_course' | 'hors_ligne' | 'suspendu'
  new_canonical_status text    -- 'active' | 'inactive' | 'suspended'
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NOT public.is_admin() THEN
    RAISE EXCEPTION 'Permission refusée : vous n''êtes pas administrateur.';
  END IF;

  IF new_courier_status NOT IN ('disponible', 'en_course', 'hors_ligne', 'suspendu') THEN
    RAISE EXCEPTION 'Statut livreur invalide : %', new_courier_status;
  END IF;

  -- Update legacy profiles.courier_status
  UPDATE public.profiles
  SET    courier_status = new_courier_status
  WHERE  id             = target_user_id;

  -- Sync canonical courier_profiles.status so accept_order_batch guard works
  INSERT INTO public.courier_profiles (user_id, status, active_capacity, balance)
  VALUES (target_user_id, new_canonical_status, 1, 0)
  ON CONFLICT (user_id) DO UPDATE
    SET status = EXCLUDED.status;
END;
$$;

GRANT EXECUTE ON FUNCTION public.admin_set_courier_status(uuid, text, text) TO authenticated;

NOTIFY pgrst, 'reload schema';
