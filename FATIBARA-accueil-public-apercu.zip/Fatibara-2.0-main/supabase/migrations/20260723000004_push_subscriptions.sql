-- Migration: push_subscriptions table
-- Stores Web Push API subscription objects per user/device.
-- One user can have multiple devices (mobile + desktop).
--
-- The endpoint + keys are provided by the browser's PushManager.subscribe()
-- and are stored as-is for server-side push via the Web Push Protocol.
--
-- Created: 2026-07-23

CREATE TABLE IF NOT EXISTS public.push_subscriptions (
  id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id      UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  endpoint     TEXT NOT NULL,
  p256dh       TEXT NOT NULL,   -- Browser encryption public key
  auth         TEXT NOT NULL,   -- Auth secret
  user_agent   TEXT,            -- For diagnostics (browser/OS)
  created_at   TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  last_used_at TIMESTAMPTZ,
  is_active    BOOLEAN NOT NULL DEFAULT TRUE,
  UNIQUE (user_id, endpoint)    -- One row per device per user
);

CREATE INDEX IF NOT EXISTS idx_push_subscriptions_user_id
  ON public.push_subscriptions (user_id) WHERE is_active = TRUE;

-- RLS
ALTER TABLE public.push_subscriptions ENABLE ROW LEVEL SECURITY;

-- Users can manage their own subscriptions
DROP POLICY IF EXISTS "users_manage_own_push_subscriptions" ON public.push_subscriptions;
CREATE POLICY "users_manage_own_push_subscriptions"
  ON public.push_subscriptions
  FOR ALL
  TO authenticated
  USING  (user_id = auth.uid())
  WITH CHECK (user_id = auth.uid());

-- Service role (used by server-side push sender) can read all
-- (handled by SUPABASE_SERVICE_ROLE_KEY bypassing RLS)
