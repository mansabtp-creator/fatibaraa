-- =============================================================================
-- Migration: Fix get_vendor_dashboard_metrics RPC — 2026-07-31
-- Reason:    Production is returning HTTP 400 on this RPC call, which means
--            either (a) the function was never applied or (b) the function
--            signature drifted.  This migration does a clean DROP + CREATE
--            to guarantee the correct named parameter (p_vendor_id UUID) is
--            active in production.
--
-- Fixes:
--   • HTTP 400 Bad Request on POST /rpc/get_vendor_dashboard_metrics
--   • TypeError: Cannot read properties of undefined (reading 'toLocaleString')
--     caused by null metrics propagating into rendering components.
--
-- Called by frontend as:
--   supabase.rpc('get_vendor_dashboard_metrics', { p_vendor_id: user.id })
-- =============================================================================

-- Drop ALL overloads of this function to avoid ambiguous-function errors.
DROP FUNCTION IF EXISTS public.get_vendor_dashboard_metrics(UUID);
DROP FUNCTION IF EXISTS public.get_vendor_dashboard_metrics(text);
DROP FUNCTION IF EXISTS public.get_vendor_dashboard_metrics();

CREATE OR REPLACE FUNCTION public.get_vendor_dashboard_metrics(p_vendor_id UUID)
RETURNS JSON
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
    v_total_revenue    NUMERIC;
    v_completed_orders INT;
    v_pending_orders   INT;
    v_active_orders    INT;
BEGIN
    -- 1. Total Revenue: paid or completed orders
    SELECT COALESCE(SUM(total_price), 0)
    INTO v_total_revenue
    FROM public.orders
    WHERE vendor_id = p_vendor_id
      AND status IN ('paid', 'completed');

    -- 2. Completed orders
    SELECT COALESCE(COUNT(*), 0)
    INTO v_completed_orders
    FROM public.orders
    WHERE vendor_id = p_vendor_id
      AND status = 'completed';

    -- 3. Pending orders (awaiting approval / payment)
    SELECT COALESCE(COUNT(*), 0)
    INTO v_pending_orders
    FROM public.orders
    WHERE vendor_id = p_vendor_id
      AND status IN ('pending', 'payment_pending');

    -- 4. Active orders (in-flight)
    SELECT COALESCE(COUNT(*), 0)
    INTO v_active_orders
    FROM public.orders
    WHERE vendor_id = p_vendor_id
      AND status IN ('accepted', 'preparing', 'ready', 'shipping');

    RETURN json_build_object(
        'total_revenue',    COALESCE(v_total_revenue,    0),
        'completed_orders', COALESCE(v_completed_orders, 0),
        'pending_orders',   COALESCE(v_pending_orders,   0),
        'active_orders',    COALESCE(v_active_orders,    0)
    );
END;
$$;

-- Grant execute to the PostgREST authenticated role
GRANT EXECUTE ON FUNCTION public.get_vendor_dashboard_metrics(UUID) TO authenticated;
GRANT EXECUTE ON FUNCTION public.get_vendor_dashboard_metrics(UUID) TO service_role;

-- Signal PostgREST to reload its schema cache immediately
NOTIFY pgrst, 'reload schema';
