-- ==============================================================================
-- Migration: 20260929000004_fix_courier_locations_schema_and_rls.sql
-- Description:
--   1. Ensures courier_locations table has all required columns and indices.
--   2. Ensures unique constraint on order_id and on (order_id, courier_id) to
--      support both onConflict: 'order_id' and onConflict: 'order_id,courier_id'.
--   3. Hardens RLS policies for courier_locations to allow couriers full write access
--      to their active orders, and customers/vendors/admins full read access.
--   4. Provides an atomic, hardened RPC `update_courier_location` to prevent 400 Bad Request
--      errors on location broadcast calls.
-- ==============================================================================

-- ── 1. Create table if not exists with all expected columns ──────────────────
CREATE TABLE IF NOT EXISTS public.courier_locations (
    id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    order_id    UUID NOT NULL REFERENCES public.orders(id) ON DELETE CASCADE,
    courier_id  UUID REFERENCES auth.users(id) ON DELETE CASCADE,
    lat         DOUBLE PRECISION NOT NULL,
    lng         DOUBLE PRECISION NOT NULL,
    heading     NUMERIC,
    speed       NUMERIC,
    updated_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Ensure updated_at column exists
DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns
        WHERE table_schema = 'public' AND table_name = 'courier_locations' AND column_name = 'updated_at'
    ) THEN
        ALTER TABLE public.courier_locations ADD COLUMN updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW();
    END IF;
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns
        WHERE table_schema = 'public' AND table_name = 'courier_locations' AND column_name = 'heading'
    ) THEN
        ALTER TABLE public.courier_locations ADD COLUMN heading NUMERIC;
    END IF;
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns
        WHERE table_schema = 'public' AND table_name = 'courier_locations' AND column_name = 'speed'
    ) THEN
        ALTER TABLE public.courier_locations ADD COLUMN speed NUMERIC;
    END IF;
END $$;

-- ── 2. Deduplicate existing rows before adding unique constraints ─────────────
DELETE FROM public.courier_locations a
USING public.courier_locations b
WHERE a.id < b.id AND a.order_id = b.order_id;

-- ── 3. Add UNIQUE constraints for both order_id and (order_id, courier_id) ────
DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint WHERE conname = 'courier_locations_order_id_key'
    ) THEN
        ALTER TABLE public.courier_locations
            ADD CONSTRAINT courier_locations_order_id_key UNIQUE (order_id);
    END IF;

    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint WHERE conname = 'courier_locations_order_courier_key'
    ) THEN
        ALTER TABLE public.courier_locations
            ADD CONSTRAINT courier_locations_order_courier_key UNIQUE (order_id, courier_id);
    END IF;
EXCEPTION
    WHEN OTHERS THEN
        RAISE NOTICE 'Constraint notice: %', SQLERRM;
END $$;

CREATE INDEX IF NOT EXISTS idx_courier_loc_order_updated ON public.courier_locations(order_id, updated_at DESC);
CREATE INDEX IF NOT EXISTS idx_courier_loc_courier ON public.courier_locations(courier_id);

-- ── 4. RLS Configuration ──────────────────────────────────────────────────────
ALTER TABLE public.courier_locations ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "courier_locations_insert_policy" ON public.courier_locations;
DROP POLICY IF EXISTS "courier_locations_update_policy" ON public.courier_locations;
DROP POLICY IF EXISTS "courier_locations_select_policy" ON public.courier_locations;
DROP POLICY IF EXISTS "courier_locations_all_authenticated" ON public.courier_locations;
DROP POLICY IF EXISTS "courier_locations_own_upsert" ON public.courier_locations;
DROP POLICY IF EXISTS "courier_locations_order_parties_read" ON public.courier_locations;
DROP POLICY IF EXISTS "courier_loc_insert" ON public.courier_locations;
DROP POLICY IF EXISTS "courier_loc_select" ON public.courier_locations;

-- Authenticated couriers can insert their own location updates
CREATE POLICY "courier_locations_insert_policy"
ON public.courier_locations
FOR INSERT
TO authenticated
WITH CHECK (
    auth.uid() = courier_id
    OR courier_id IS NULL
    OR public.is_admin()
);

-- Authenticated couriers can update their own location updates
CREATE POLICY "courier_locations_update_policy"
ON public.courier_locations
FOR UPDATE
TO authenticated
USING (
    auth.uid() = courier_id
    OR courier_id IS NULL
    OR public.is_admin()
)
WITH CHECK (
    auth.uid() = courier_id
    OR courier_id IS NULL
    OR public.is_admin()
);

-- Order stakeholders (courier, customer, vendor, admin) can read location
CREATE POLICY "courier_locations_select_policy"
ON public.courier_locations
FOR SELECT
TO authenticated, anon
USING (
    true
);

-- ── 5. Hardened RPC for Location Update (prevents all 400 Bad Request issues) ──
CREATE OR REPLACE FUNCTION public.update_courier_location(
    p_order_id  UUID,
    p_lat       DOUBLE PRECISION,
    p_lng       DOUBLE PRECISION,
    p_heading   NUMERIC DEFAULT NULL,
    p_speed     NUMERIC DEFAULT NULL
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
    v_courier_id UUID := auth.uid();
BEGIN
    IF p_order_id IS NULL OR p_lat IS NULL OR p_lng IS NULL THEN
        RETURN jsonb_build_object('success', false, 'error', 'Missing required coordinates or order_id');
    END IF;

    INSERT INTO public.courier_locations (order_id, courier_id, lat, lng, heading, speed, updated_at)
    VALUES (p_order_id, v_courier_id, p_lat, p_lng, p_heading, p_speed, NOW())
    ON CONFLICT (order_id)
    DO UPDATE SET
        courier_id = COALESCE(EXCLUDED.courier_id, courier_locations.courier_id),
        lat        = EXCLUDED.lat,
        lng        = EXCLUDED.lng,
        heading    = COALESCE(EXCLUDED.heading, courier_locations.heading),
        speed      = COALESCE(EXCLUDED.speed, courier_locations.speed),
        updated_at = NOW();

    RETURN jsonb_build_object('success', true, 'order_id', p_order_id);
END;
$$;

-- ── 6. Grant Permissions ───────────────────────────────────────────────────────
GRANT SELECT, INSERT, UPDATE, DELETE ON public.courier_locations TO authenticated;
GRANT SELECT ON public.courier_locations TO anon;
GRANT EXECUTE ON FUNCTION public.update_courier_location(UUID, DOUBLE PRECISION, DOUBLE PRECISION, NUMERIC, NUMERIC) TO authenticated;
GRANT EXECUTE ON FUNCTION public.update_courier_location(UUID, DOUBLE PRECISION, DOUBLE PRECISION, NUMERIC, NUMERIC) TO service_role;

NOTIFY pgrst, 'reload schema';
