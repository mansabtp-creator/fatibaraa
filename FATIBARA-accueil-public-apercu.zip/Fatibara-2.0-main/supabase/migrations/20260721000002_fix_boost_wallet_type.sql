-- ==============================================================================
-- Migration: Fix boost campaign wallet_transaction type label
-- Created At: 2026-07-21
--
-- The launch_boost_campaign RPC logged the vendor wallet debit with
-- type='fee' instead of type='boost', making it impossible for the
-- frontend to distinguish boost purchases from platform fees in the
-- wallet history / transaction list UI.
-- ==============================================================================

CREATE OR REPLACE FUNCTION public.launch_boost_campaign(
  p_store_id       UUID,
  p_campaign_type  TEXT,
  p_duration_label TEXT,
  p_duration_days  INTEGER,
  p_budget_gnf     NUMERIC
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_user_id     UUID;
  v_store       RECORD;
  v_wallet      NUMERIC;
  v_campaign_id UUID;
BEGIN
  v_user_id := auth.uid();
  IF v_user_id IS NULL THEN
    RAISE EXCEPTION 'Not authenticated';
  END IF;

  -- Validate input
  IF p_campaign_type NOT IN ('visibility', 'conversion') THEN
    RAISE EXCEPTION 'Invalid campaign type: %', p_campaign_type;
  END IF;
  IF p_budget_gnf <= 0 THEN
    RAISE EXCEPTION 'Budget must be positive';
  END IF;

  -- Verify store ownership
  SELECT * INTO v_store FROM public.stores
  WHERE id = p_store_id AND owner_id = v_user_id;
  IF v_store IS NULL THEN
    RAISE EXCEPTION 'Store not found or not owned by current user';
  END IF;

  -- Lock profile row and read balance (FOR UPDATE prevents race conditions)
  SELECT wallet_balance INTO v_wallet FROM public.profiles
  WHERE id = v_user_id FOR UPDATE;
  IF v_wallet IS NULL THEN
    RAISE EXCEPTION 'User profile not found';
  END IF;
  IF v_wallet < p_budget_gnf THEN
    RAISE EXCEPTION 'Insufficient wallet balance — % GNF required, % GNF available',
      p_budget_gnf, v_wallet;
  END IF;

  -- 1. Deduct wallet
  UPDATE public.profiles
  SET wallet_balance = wallet_balance - p_budget_gnf
  WHERE id = v_user_id;

  -- 2. Create campaign record
  INSERT INTO public.boost_campaigns (
    store_id, campaign_type, duration_label,
    duration_days, budget_gnf, status, launched_at
  )
  VALUES (
    p_store_id, p_campaign_type, p_duration_label,
    p_duration_days, p_budget_gnf, 'active', NOW()
  )
  RETURNING id INTO v_campaign_id;

  -- 3. Log wallet transaction with correct type='boost' (was incorrectly 'fee')
  INSERT INTO public.wallet_transactions (
    profile_id, store_id, amount, type, reference_id, description, status
  )
  VALUES (
    v_user_id,
    p_store_id,                             -- link to store for vendor RLS visibility
    -p_budget_gnf,
    'boost',                                -- ← FIX: was 'fee'
    v_campaign_id,
    'Boost ' || p_campaign_type || ' — ' || p_duration_label || ' (' || p_duration_days || 'j)',
    'completed'
  );

  RETURN jsonb_build_object(
    'success',      true,
    'campaign_id',  v_campaign_id,
    'new_balance',  v_wallet - p_budget_gnf
  );
END;
$$;

-- Grants unchanged
REVOKE EXECUTE ON FUNCTION public.launch_boost_campaign(UUID, TEXT, TEXT, INTEGER, NUMERIC) FROM PUBLIC;
GRANT  EXECUTE ON FUNCTION public.launch_boost_campaign(UUID, TEXT, TEXT, INTEGER, NUMERIC) TO authenticated;

NOTIFY pgrst, 'reload schema';
