-- =============================================================================
-- Migration: Remove Security Deposits & Guarantee Balance Holds System-Wide
-- File:      20260819000001_remove_security_deposits.sql
-- Created:   2026-08-19
--
-- CONTEXT:
--   Fatibara previously planned a security-deposit / caution system that would
--   have required couriers to maintain a minimum pre-funded wallet balance
--   before going "En Service" and accepting delivery missions.
--
--   That requirement is being removed entirely.  Couriers can now:
--     • Toggle "En Service" with no wallet balance requirement.
--     • Accept individual or batch pool orders without any balance hold.
--
-- CHANGES:
--   1. Drop `security_deposit_amount` and `deposit_verified` columns from
--      profiles (IF EXISTS — safe no-op if they were never added to this DB).
--   2. Add `is_suspended` boolean column to profiles (FALSE by default) so
--      admin suspension works cleanly and `can_accept_mission` can reference it.
--   3. Create / replace `can_accept_mission(p_courier_id UUID)` RPC.
--      The function checks only that the courier is active and not suspended —
--      it explicitly IGNORES any wallet / deposit thresholds.
--   4. Grant execute to authenticated role and refresh schema cache.
-- =============================================================================

-- ── 1. Remove deposit columns (idempotent — IF EXISTS) ───────────────────────

ALTER TABLE public.profiles DROP COLUMN IF EXISTS security_deposit_amount;
ALTER TABLE public.profiles DROP COLUMN IF EXISTS deposit_verified;

-- ── 2. Add `is_suspended` column (idempotent) ────────────────────────────────
--    Used by admin tooling to block a specific courier.  False by default so
--    all existing couriers are unaffected after this migration runs.

ALTER TABLE public.profiles
  ADD COLUMN IF NOT EXISTS is_suspended BOOLEAN DEFAULT FALSE;

-- ── 3. Create / replace `can_accept_mission` RPC ─────────────────────────────
--
--   SECURITY MODEL (post-deposit removal):
--     A courier CAN accept a mission if and only if:
--       a) Their profile exists and has a courier-flavoured role
--          (profile_type = 'courier' OR 'livreur', or 'courier' in roles[]).
--       b) They are NOT suspended (is_suspended IS NOT TRUE).
--
--   Wallet balance, minimum deposit, or guarantee hold are NOT considered.
--   These checks were intentionally removed per product decision 2026-08-19.
--
--   The function is SECURITY DEFINER so it can run the SELECT even when the
--   caller's RLS policies would otherwise be restrictive.  It only ever reads
--   the single row identified by p_courier_id — no data exposure risk.

DROP FUNCTION IF EXISTS public.can_accept_mission(UUID);

CREATE OR REPLACE FUNCTION public.can_accept_mission(p_courier_id UUID)
RETURNS BOOLEAN
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  -- Check if the courier profile is active and not suspended.
  -- Wallet deposit / minimum balance thresholds are intentionally NOT checked.
  RETURN EXISTS (
    SELECT 1
    FROM public.profiles
    WHERE id = p_courier_id
      AND (
        -- Accept both French and English role naming conventions
        profile_type IN ('courier', 'livreur')
        OR 'courier' = ANY(roles)
        OR 'livreur' = ANY(roles)
      )
      AND is_suspended IS NOT TRUE
  );
END;
$$;

-- ── 4. Grant & schema cache refresh ──────────────────────────────────────────

GRANT EXECUTE ON FUNCTION public.can_accept_mission(UUID) TO authenticated;
GRANT EXECUTE ON FUNCTION public.can_accept_mission(UUID) TO service_role;

-- Refresh PostgREST schema cache so the new RPC & column are immediately visible
NOTIFY pgrst, 'reload schema';
