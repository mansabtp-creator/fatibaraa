-- =============================================================================
-- Migration: Fix complete_vendor_order permission errors
-- Created:   2026-07-31
--
-- ROOT CAUSE:
--   complete_vendor_order is a SECURITY DEFINER function called by an
--   authenticated vendor. SECURITY DEFINER bypasses RLS but does NOT bypass
--   table-level REVOKE grants. The foundation schema does:
--
--     REVOKE INSERT, UPDATE, DELETE ON public.wallet_transactions FROM authenticated;
--     REVOKE INSERT, UPDATE, DELETE ON public.platform_logs       FROM authenticated;
--
--   So when the function body executes INSERT INTO wallet_transactions / platform_logs
--   it fails with a permission denied error, which PostgREST surfaces as a 400.
--
-- FIX:
--   Grant INSERT on both tables to authenticated (the function's effective role).
--   The SECURITY DEFINER + RLS combination still protects these tables from
--   arbitrary client writes — only the function's trusted logic can insert.
--
--   We also add a GRANT on stores (for the UPDATE balance) and order_items
--   (for the SELECT) to be safe.
-- =============================================================================

-- Allow the SECURITY DEFINER function to insert commission/audit logs
GRANT INSERT ON public.platform_logs       TO authenticated;

-- Allow the SECURITY DEFINER function to insert payout records
GRANT INSERT ON public.wallet_transactions TO authenticated;

-- Allow the function to UPDATE the store balance
GRANT UPDATE ON public.stores TO authenticated;

-- Allow the function to SELECT order items for revenue calculation
GRANT SELECT ON public.order_items TO authenticated;

-- Allow the function to SELECT platform_settings (for commission rate)
GRANT SELECT ON public.platform_settings TO authenticated;

-- Reload PostgREST schema cache
NOTIFY pgrst, 'reload schema';
