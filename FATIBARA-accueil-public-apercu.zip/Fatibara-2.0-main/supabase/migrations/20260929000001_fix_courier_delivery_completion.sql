-- ==============================================================================
-- Migration: 20260929000001_fix_courier_delivery_completion.sql
-- Fix:
--   1. Fix complete_courier_delivery state guard:
--      Only v_order.status = 'delivered' means the order has already been completed.
--      Previously checked `OR v_order.financial_status = 'processed'`, which falsely
--      blocked delivery completion for any order paid via Wallet or Mobile Money!
--   2. Ensure unique constraint/index on courier_locations(order_id) to support
--      both on_conflict=order_id and on_conflict=order_id,courier_id.
-- ==============================================================================

-- ── 1. Fix unique constraint on courier_locations ────────────────────────────
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint WHERE conname = 'courier_locations_order_id_key'
  ) THEN
    -- If there are duplicates, keep the newest one
    DELETE FROM public.courier_locations a
    USING public.courier_locations b
    WHERE a.order_id = b.order_id AND a.created_at < b.created_at;

    ALTER TABLE public.courier_locations
      ADD CONSTRAINT courier_locations_order_id_key UNIQUE (order_id);
  END IF;
EXCEPTION WHEN OTHERS THEN
  RAISE NOTICE 'Could not add unique constraint on courier_locations(order_id): %', SQLERRM;
END $$;

-- ── 2. Update complete_courier_delivery RPC ──────────────────────────────────
CREATE OR REPLACE FUNCTION public.complete_courier_delivery(
    p_order_id   UUID,
    p_otp        TEXT DEFAULT NULL
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
    v_order               public.orders%ROWTYPE;
    v_courier_profile     RECORD;
    v_commission_str      TEXT;
    v_commission_rate     NUMERIC;
    v_delivery_fee        NUMERIC;
    v_courier_payout      NUMERIC;
    v_store_id            UUID;
    v_items_real_value    NUMERIC := 0;
    v_vendor_payout       NUMERIC;
    v_platform_commission NUMERIC;
    v_payment_method      TEXT;
    v_is_cash             BOOLEAN;
    v_existing_sale       BOOLEAN;
BEGIN
    -- ── 1. Lock order row to prevent race conditions ────────────────────────
    SELECT * INTO v_order
    FROM public.orders
    WHERE id = p_order_id
    FOR UPDATE;

    IF NOT FOUND THEN
        RETURN jsonb_build_object('success', false, 'error', 'Order not found');
    END IF;

    -- ── 2. Authorization: caller must be the assigned courier (or admin) ─────
    IF v_order.courier_id IS NULL THEN
        RETURN jsonb_build_object('success', false, 'error', 'No courier assigned to this order');
    END IF;

    IF v_order.courier_id != auth.uid() AND NOT public.is_admin() THEN
        RETURN jsonb_build_object('success', false, 'error', 'Unauthorized: you are not the assigned courier');
    END IF;

    -- ── 3. State guard: only terminal delivered state blocks delivery ─────────
    -- [CRITICAL FIX]: Previously checked `OR v_order.financial_status = 'processed'`.
    -- For online/wallet paid orders, financial_status is 'processed' BEFORE the courier delivers!
    -- Checking financial_status = 'processed' falsely returned "Order already completed".
    IF v_order.status = 'delivered' THEN
        RETURN jsonb_build_object('success', false, 'error', 'Cette commande a déjà été livrée.');
    END IF;

    IF v_order.status = 'cancelled' THEN
        RETURN jsonb_build_object('success', false, 'error', 'Cette commande a été annulée.');
    END IF;

    -- ── 4. OTP verification (server-side) ───────────────────────────────────
    IF v_order.delivery_otp IS NOT NULL AND TRIM(v_order.delivery_otp) != '' THEN
        IF p_otp IS NULL OR TRIM(p_otp) != TRIM(v_order.delivery_otp) THEN
            RETURN jsonb_build_object(
                'success', false,
                'error', 'Code OTP incorrect. Veuillez réessayer.'
            );
        END IF;
    END IF;

    -- ── 5. Resolve courier profile ──────────────────────────────────────────
    SELECT * INTO v_courier_profile
    FROM public.courier_profiles
    WHERE user_id = v_order.courier_id;

    -- ── 6. Financial math ───────────────────────────────────────────────────
    v_delivery_fee   := COALESCE(v_order.delivery_fee, v_order.vendor_delivery_fee, 0);
    v_courier_payout := ROUND(v_delivery_fee * 0.8);  -- courier keeps 80%

    v_payment_method := COALESCE(
        v_order.shipping_address->>'payment_method',
        CASE WHEN v_order.financial_status IN ('paid', 'processed') THEN 'wallet' ELSE 'cash' END
    );
    v_is_cash := (v_payment_method = 'cash');

    -- For COD: courier collected cash → deduct order total from digital credit
    IF v_is_cash THEN
        v_courier_payout := v_courier_payout - COALESCE(v_order.total_amount, 0);
    END IF;

    -- ── 7. Credit courier only if payout is positive ────────────────────────
    IF v_courier_payout > 0 THEN
        UPDATE public.profiles
        SET wallet_balance = COALESCE(wallet_balance, 0) + v_courier_payout,
            updated_at     = NOW()
        WHERE id = v_order.courier_id;

        IF v_courier_profile IS NOT NULL THEN
            UPDATE public.courier_profiles
            SET balance    = COALESCE(balance, 0) + v_courier_payout,
                updated_at = NOW()
            WHERE user_id = v_order.courier_id;
        END IF;

        INSERT INTO public.wallet_transactions
            (profile_id, amount, type, reference_id, description, status)
        VALUES (
            v_order.courier_id,
            v_courier_payout,
            'delivery_fee',
            p_order_id,
            'Course livrée #' || LEFT(p_order_id::text, 8),
            'completed'
        );
    END IF;

    -- ── 8. Release courier active capacity ──────────────────────────────────
    IF v_courier_profile IS NOT NULL AND COALESCE(v_courier_profile.active_capacity, 0) > 0 THEN
        UPDATE public.courier_profiles
        SET active_capacity = GREATEST(0, active_capacity - 1),
            updated_at      = NOW()
        WHERE user_id = v_order.courier_id;
    END IF;

    -- ── 9. Mark order as delivered + financially processed ──────────────────
    UPDATE public.orders
    SET status           = 'delivered',
        financial_status = 'processed',
        completed_at     = NOW(),
        updated_at       = NOW()
    WHERE id = p_order_id;

    -- ── 10. Vendor settlement (only if not already credited) ────────────────
    SELECT EXISTS (
        SELECT 1 FROM public.wallet_transactions
        WHERE reference_id = p_order_id::TEXT AND type = 'sale'
    ) INTO v_existing_sale;

    IF NOT v_existing_sale THEN
        SELECT COALESCE(
            (SELECT p.store_id
             FROM public.order_items oi
             JOIN public.products p ON oi.product_id = p.id
             WHERE oi.order_id = p_order_id LIMIT 1),
            (SELECT id FROM public.stores WHERE owner_id = v_order.vendor_id LIMIT 1)
        ) INTO v_store_id;

        SELECT value INTO v_commission_str
        FROM public.platform_settings WHERE id = 'commission_rate';
        v_commission_rate := COALESCE(NULLIF(v_commission_str, '')::NUMERIC, 5) / 100.0;

        SELECT COALESCE(SUM(price_at_purchase * quantity), 0)
        INTO v_items_real_value
        FROM public.order_items WHERE order_id = p_order_id;

        IF v_items_real_value = 0 THEN
            v_items_real_value := COALESCE(v_order.total_amount, 0) - COALESCE(v_order.delivery_fee, 0);
        END IF;

        v_vendor_payout := ROUND(
            (v_items_real_value / (1 + v_commission_rate)) * (1 - v_commission_rate)
            - COALESCE(v_order.vendor_delivery_fee, 0)
        );

        IF v_vendor_payout > 0 AND v_store_id IS NOT NULL THEN
            UPDATE public.stores
            SET balance    = balance + v_vendor_payout,
                updated_at = NOW()
            WHERE id = v_store_id;

            INSERT INTO public.wallet_transactions
                (store_id, profile_id, amount, type, reference_id, description)
            VALUES (
                v_store_id, v_order.vendor_id, v_vendor_payout,
                'sale', p_order_id,
                'Vente livrée #' || LEFT(p_order_id::text, 8)
            );
        END IF;
    END IF;

    RETURN jsonb_build_object(
        'success',        true,
        'courier_payout', v_courier_payout
    );

EXCEPTION WHEN OTHERS THEN
    RETURN jsonb_build_object('success', false, 'error', SQLERRM);
END;
$$;

GRANT EXECUTE ON FUNCTION public.complete_courier_delivery(UUID, TEXT) TO authenticated;
GRANT EXECUTE ON FUNCTION public.complete_courier_delivery(UUID, TEXT) TO service_role;
