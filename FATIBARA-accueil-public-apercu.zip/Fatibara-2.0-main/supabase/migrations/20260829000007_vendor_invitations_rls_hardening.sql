-- Migration: vendor_invitations RLS hardening
-- Problem: the previous "anyone_can_read_invitation_by_token" policy used
-- USING(true) which allowed any authenticated user to SELECT all rows from
-- vendor_invitations — effectively making all pending invite tokens readable
-- by any logged-in user.
--
-- Fix:
--   1. Drop the overly permissive SELECT policy.
--   2. Create a SECURITY DEFINER RPC `validate_vendor_invitation_token` that
--      accepts a token string, validates it, and returns only the fields
--      needed for the registration page — without exposing other rows.
--
-- The VendorRegistrationPage invite-token check is updated to call this RPC
-- instead of querying the table directly.

-- ── 1. Drop the permissive read policy ────────────────────────────────────────
DROP POLICY IF EXISTS "anyone_can_read_invitation_by_token" ON public.vendor_invitations;

-- ── 2. Revoke direct SELECT from authenticated role ───────────────────────────
-- Admins still have full access via the existing "admins_full_access_invitations" policy.
-- Regular users should only interact with the table through the SECURITY DEFINER RPCs.
REVOKE SELECT ON public.vendor_invitations FROM authenticated;
GRANT  SELECT ON public.vendor_invitations TO service_role;

-- Re-grant to authenticated via the admin-only policy (already covers admins).
-- Non-admin authenticated users should use the RPC below.

-- ── 3. SECURITY DEFINER RPC for invite token validation ───────────────────────
-- Returns: { valid: bool, email_hint: text|null } — never exposes token, id, or other rows.
CREATE OR REPLACE FUNCTION public.validate_vendor_invitation_token(p_token TEXT)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_row public.vendor_invitations%ROWTYPE;
BEGIN
  SELECT * INTO v_row
  FROM public.vendor_invitations
  WHERE token = p_token
  LIMIT 1;

  IF NOT FOUND THEN
    RETURN jsonb_build_object('valid', false, 'email_hint', null, 'reason', 'not_found');
  END IF;

  IF v_row.is_revoked THEN
    RETURN jsonb_build_object('valid', false, 'email_hint', null, 'reason', 'revoked');
  END IF;

  IF v_row.used_at IS NOT NULL THEN
    RETURN jsonb_build_object('valid', false, 'email_hint', null, 'reason', 'already_used');
  END IF;

  IF v_row.expires_at < NOW() THEN
    RETURN jsonb_build_object('valid', false, 'email_hint', null, 'reason', 'expired');
  END IF;

  RETURN jsonb_build_object('valid', true, 'email_hint', v_row.email_hint);
END;
$$;

GRANT EXECUTE ON FUNCTION public.validate_vendor_invitation_token(TEXT) TO authenticated;
GRANT EXECUTE ON FUNCTION public.validate_vendor_invitation_token(TEXT) TO anon;

-- ── 4. Notify PostgREST of schema changes ────────────────────────────────────
NOTIFY pgrst, 'reload schema';
