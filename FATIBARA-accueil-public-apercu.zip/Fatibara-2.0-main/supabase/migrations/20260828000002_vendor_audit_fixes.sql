-- ==============================================================================
-- MIGRATION: 20260828000002_vendor_audit_fixes.sql
-- Fatibara 2.0 — Vendor Dashboard Audit Remediation
-- Date: 2026-08-28
--
-- FIXES:
--
--   [V-2] CRITICAL — withdrawals.method CHECK constraint accepts 'orange_money'
--         / 'mtn_money' but TransactionalWallet sends 'Orange Money' / 'MTN MoMo'.
--         Every vendor/courier withdrawal request fails with a CHECK violation.
--         Fix: add the display-format variants to the CHECK constraint.
--
--   [V-3] HIGH — No stock decrement trigger. stock_quantity is never reduced
--         when an order is placed, and is_active is never auto-toggled to false
--         when stock reaches 0. This means the shop can oversell any item.
--         Fix: add trigger fn + trigger on order_items INSERT.
--
--   [V-7] MEDIUM — vendor_id column not written on product INSERT from
--         Products.tsx. Orders are linked via store_id, but the VendorOrders
--         Realtime subscription also filters on vendor_id=eq.{user.id}.
--         Fix: backfill vendor_id on products from stores.owner_id, and add
--         a trigger to auto-set vendor_id on future product INSERTs.
--
--   [STORAGE] LOW — Ensure the product-images storage bucket and RLS policies
--         exist so image uploads work in production without manual dashboard
--         setup (uses Supabase storage SQL API).
-- ==============================================================================

-- ==============================================================================
-- FIX V-2: Extend withdrawals.method CHECK to accept display-format strings
-- ==============================================================================
-- Drop the old constraint and replace with one that accepts both formats.
-- The DB stores the snake_case canonical form; frontend sends Title Case.
-- We normalise on the way in via a BEFORE INSERT trigger instead of widening
-- the enum further, keeping downstream queries consistent.

ALTER TABLE public.withdrawals DROP CONSTRAINT IF EXISTS withdrawals_method_check;

-- Redefine to accept both formats
ALTER TABLE public.withdrawals
  ADD CONSTRAINT withdrawals_method_check
  CHECK (method IN (
    'orange_money', 'mtn_money', 'wave', 'bank',
    'Orange Money', 'MTN MoMo', 'Wave', 'Bank'
  ));

-- Normaliser trigger: canonicalise method to snake_case before INSERT/UPDATE
CREATE OR REPLACE FUNCTION public.normalise_withdrawal_method()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
BEGIN
  NEW.method := CASE NEW.method
    WHEN 'Orange Money' THEN 'orange_money'
    WHEN 'MTN MoMo'     THEN 'mtn_money'
    WHEN 'Wave'         THEN 'wave'
    WHEN 'Bank'         THEN 'bank'
    ELSE LOWER(REPLACE(NEW.method, ' ', '_'))
  END;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_normalise_withdrawal_method ON public.withdrawals;
CREATE TRIGGER trg_normalise_withdrawal_method
  BEFORE INSERT OR UPDATE OF method ON public.withdrawals
  FOR EACH ROW EXECUTE FUNCTION public.normalise_withdrawal_method();

-- ==============================================================================
-- FIX V-3: Stock decrement + is_active auto-toggle trigger
-- ==============================================================================
-- Fires after every row INSERT on order_items. For each item sold:
--   1. Decrements products.stock_quantity by the purchased quantity.
--   2. If stock_quantity reaches 0, sets is_active = false so the product
--      no longer appears on the buyer-facing shop.
--
-- Uses a SECURITY DEFINER function so the trigger runs with elevated
-- privileges even when the order is placed by a buyer (authenticated role).

CREATE OR REPLACE FUNCTION public.decrement_product_stock()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_new_stock INTEGER;
BEGIN
  -- Only decrement for real product rows (skip nulls from legacy data)
  IF NEW.product_id IS NULL THEN
    RETURN NEW;
  END IF;

  UPDATE public.products
  SET
    stock_quantity = GREATEST(0, COALESCE(stock_quantity, 0) - NEW.quantity),
    -- Auto-deactivate when stock hits 0
    is_active = CASE
      WHEN GREATEST(0, COALESCE(stock_quantity, 0) - NEW.quantity) = 0 THEN FALSE
      ELSE is_active
    END
  WHERE id = NEW.product_id
  RETURNING stock_quantity INTO v_new_stock;

  -- Log critical depletion to facilitate vendor alerting (optional)
  IF v_new_stock IS NOT NULL AND v_new_stock = 0 THEN
    -- Notify vendor via a lightweight pg_notify so the dashboard can surface
    -- a real-time "stock épuisé" alert without polling.
    PERFORM pg_notify(
      'stock_depleted',
      json_build_object('product_id', NEW.product_id, 'order_id', NEW.order_id)::text
    );
  END IF;

  RETURN NEW;
END;
$$;

-- Attach to order_items so it fires on every item row created
DROP TRIGGER IF EXISTS trg_decrement_product_stock ON public.order_items;
CREATE TRIGGER trg_decrement_product_stock
  AFTER INSERT ON public.order_items
  FOR EACH ROW EXECUTE FUNCTION public.decrement_product_stock();

-- Grant EXECUTE (SECURITY DEFINER so it runs as the function owner, not caller)
-- No explicit GRANT needed — triggers execute under the trigger function owner.

-- ==============================================================================
-- FIX V-7: Backfill vendor_id on products + auto-set on future INSERTs
-- ==============================================================================

-- Ensure vendor_id column exists on products
ALTER TABLE public.products
  ADD COLUMN IF NOT EXISTS vendor_id UUID REFERENCES auth.users(id) ON DELETE SET NULL;

CREATE INDEX IF NOT EXISTS idx_products_vendor_id ON public.products(vendor_id)
  WHERE vendor_id IS NOT NULL;

-- Backfill: resolve vendor_id from stores.owner_id for products with a store_id
UPDATE public.products p
SET vendor_id = s.owner_id
FROM public.stores s
WHERE p.store_id = s.id
  AND p.vendor_id IS NULL
  AND s.owner_id IS NOT NULL;

-- Trigger: auto-populate vendor_id from store on every new product INSERT
CREATE OR REPLACE FUNCTION public.set_product_vendor_id()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
BEGIN
  IF NEW.vendor_id IS NULL AND NEW.store_id IS NOT NULL THEN
    SELECT owner_id INTO NEW.vendor_id
    FROM public.stores
    WHERE id = NEW.store_id;
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_set_product_vendor_id ON public.products;
CREATE TRIGGER trg_set_product_vendor_id
  BEFORE INSERT ON public.products
  FOR EACH ROW EXECUTE FUNCTION public.set_product_vendor_id();

-- RLS: vendors must be able to SELECT their own products via vendor_id
-- (existing policies may only use store_id ownership — add vendor_id arm)
DROP POLICY IF EXISTS "vendors_select_own_products_by_vendor_id" ON public.products;
CREATE POLICY "vendors_select_own_products_by_vendor_id"
  ON public.products FOR SELECT TO authenticated
  USING (vendor_id = auth.uid());

DROP POLICY IF EXISTS "vendors_update_own_products_by_vendor_id" ON public.products;
CREATE POLICY "vendors_update_own_products_by_vendor_id"
  ON public.products FOR UPDATE TO authenticated
  USING (vendor_id = auth.uid())
  WITH CHECK (vendor_id = auth.uid());

DROP POLICY IF EXISTS "vendors_delete_own_products_by_vendor_id" ON public.products;
CREATE POLICY "vendors_delete_own_products_by_vendor_id"
  ON public.products FOR DELETE TO authenticated
  USING (vendor_id = auth.uid());

-- ==============================================================================
-- FIX STORAGE: Ensure product-images bucket exists (idempotent)
-- ==============================================================================
-- This uses the storage SQL API available in Supabase migrations.
-- Creates the bucket only if it does not already exist.

INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES (
  'product-images',
  'product-images',
  TRUE,         -- public bucket: images served without auth token
  5242880,      -- 5 MB per file
  ARRAY['image/jpeg', 'image/png', 'image/webp', 'image/gif']
)
ON CONFLICT (id) DO NOTHING;

-- Storage policies: vendors can upload to their own path prefix
-- Path convention enforced by ProductForm.tsx:
--   `stores/${storeId}/${filename}`

DROP POLICY IF EXISTS "vendor_upload_product_images" ON storage.objects;
CREATE POLICY "vendor_upload_product_images"
  ON storage.objects FOR INSERT TO authenticated
  WITH CHECK (
    bucket_id = 'product-images'
    AND (storage.foldername(name))[1] = 'stores'
  );

DROP POLICY IF EXISTS "public_read_product_images" ON storage.objects;
CREATE POLICY "public_read_product_images"
  ON storage.objects FOR SELECT TO public
  USING (bucket_id = 'product-images');

DROP POLICY IF EXISTS "vendor_update_product_images" ON storage.objects;
CREATE POLICY "vendor_update_product_images"
  ON storage.objects FOR UPDATE TO authenticated
  USING (bucket_id = 'product-images' AND auth.role() = 'authenticated');

DROP POLICY IF EXISTS "vendor_delete_product_images" ON storage.objects;
CREATE POLICY "vendor_delete_product_images"
  ON storage.objects FOR DELETE TO authenticated
  USING (bucket_id = 'product-images' AND auth.role() = 'authenticated');

-- ==============================================================================
-- VERIFY: Quick sanity counts (visible in migration logs)
-- ==============================================================================
DO $$
DECLARE
  v_products_with_vendor_id   INTEGER;
  v_products_without_vendor_id INTEGER;
BEGIN
  SELECT COUNT(*) INTO v_products_with_vendor_id    FROM public.products WHERE vendor_id IS NOT NULL;
  SELECT COUNT(*) INTO v_products_without_vendor_id  FROM public.products WHERE vendor_id IS NULL;

  RAISE NOTICE '[V-7] products with vendor_id: %, without: %',
    v_products_with_vendor_id, v_products_without_vendor_id;
END $$;
