-- ==============================================================================
-- MIGRATION: 20260829000003_fix_wallet_checkout_null_vendor.sql
-- Fix: process_wallet_checkout fails with constraint error when product has
-- no vendor_id (store not linked).  The root cause is secure_process_order_financials
-- attempting to INSERT a wallet_transactions row with profile_id = NULL when
-- v_order.vendor_id IS NULL.  PostgreSQL raises a NOT NULL / FK constraint
-- violation that bubbles up through process_wallet_checkout as the misleading
-- "orders_financial_status_check" error (it is actually the FK/NOT NULL error
-- on wallet_transactions.profile_id, but the PG error message sometimes names
-- the enclosing relation constraint instead).
--
-- Additionally, the RPC was passing the full orderEntry (including client-side
-- keys like "status", "user_id", etc.) into p_orders.  The RPC only reads the
-- keys it needs, but any extra numeric key that can't be cast will cause a
-- runtime exception.  This migration hardens the function with explicit NULL
-- guards and graceful skips for missing vendor / courier.
-- ==============================================================================

CREATE OR REPLACE FUNCTION public.secure_process_order_financials(p_order_id uuid)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
    v_order                        RECORD;
    v_store                        RECORD;
    v_existing_tx                  BOOLEAN;
    v_commission_str               TEXT;
    v_commission_rate              NUMERIC;
    v_items_real_value             NUMERIC;
    v_item_subtotal                NUMERIC;
    v_platform_commission          NUMERIC;
    v_vendor_payout                NUMERIC;
    v_courier_payout               NUMERIC;
    v_is_cash_payment              BOOLEAN;
    v_final_vendor_digital_change  NUMERIC;
    v_final_courier_digital_change NUMERIC;
    v_courier_balance              NUMERIC;
    v_vendor_description           TEXT;
BEGIN
    -- ── A. Lock order row ────────────────────────────────────────────────────
    SELECT * INTO v_order FROM public.orders WHERE id = p_order_id FOR UPDATE;
    IF NOT FOUND THEN RAISE EXCEPTION 'Order not found: %', p_order_id; END IF;

    -- ── B. Idempotency guard ─────────────────────────────────────────────────
    IF v_order.financial_status = 'processed' THEN
        RETURN jsonb_build_object('success', true, 'alreadyProcessed', true);
    END IF;

    SELECT EXISTS (
        SELECT 1 FROM public.wallet_transactions
        WHERE reference_id = p_order_id::TEXT AND type = 'sale'
    ) INTO v_existing_tx;

    IF v_existing_tx THEN
        UPDATE public.orders SET financial_status = 'processed' WHERE id = p_order_id;
        RETURN jsonb_build_object('success', true, 'alreadyProcessed', true);
    END IF;

    -- ── C. Resolve store ─────────────────────────────────────────────────────
    IF v_order.store_id IS NOT NULL THEN
        SELECT * INTO v_store FROM public.stores WHERE id = v_order.store_id;
    ELSIF v_order.vendor_id IS NOT NULL THEN
        SELECT * INTO v_store FROM public.stores WHERE owner_id = v_order.vendor_id LIMIT 1;
    END IF;
    -- v_store may be NOT FOUND — all downstream blocks guard against this with IS NOT NULL

    -- ── D. Commission arithmetic ─────────────────────────────────────────────
    v_items_real_value := COALESCE(v_order.total_amount, 0) - COALESCE(v_order.delivery_fee, 0);

    SELECT value INTO v_commission_str FROM public.platform_settings WHERE id = 'commission_rate';
    IF v_commission_str IS NULL THEN v_commission_str := '5'; END IF;
    v_commission_rate := v_commission_str::numeric / 100.0;

    v_item_subtotal       := v_items_real_value / (1 + v_commission_rate);
    v_platform_commission := v_item_subtotal * v_commission_rate;
    v_vendor_payout       := v_item_subtotal - COALESCE(v_order.vendor_delivery_fee, 0);
    v_courier_payout      := (CASE WHEN COALESCE(v_order.delivery_fee, 0) > 0
                                   THEN v_order.delivery_fee
                                   ELSE COALESCE(v_order.vendor_delivery_fee, 0) END) * 0.8;

    IF v_order.courier_id IS NULL THEN
        v_vendor_payout := v_vendor_payout + v_courier_payout;
    END IF;

    v_is_cash_payment := COALESCE(
        (v_order.shipping_address->>'payment_method') = 'cash',
        v_order.financial_status != 'paid'
    );

    -- ── E. Vendor payout ─────────────────────────────────────────────────────
    -- GUARD: only distribute if we have a resolvable store AND vendor_id
    IF v_store.id IS NOT NULL AND v_order.vendor_id IS NOT NULL THEN
        v_final_vendor_digital_change := v_vendor_payout;

        IF v_is_cash_payment AND v_order.courier_id IS NULL THEN
            v_final_vendor_digital_change := v_vendor_payout - v_order.total_amount;
        END IF;

        IF v_final_vendor_digital_change != 0 THEN
            UPDATE public.stores
            SET balance = COALESCE(balance, 0) + ROUND(v_final_vendor_digital_change)
            WHERE id = v_store.id;

            IF v_is_cash_payment AND v_order.courier_id IS NULL THEN
                v_vendor_description :=
                    'Collecte Cash directe — Retenue commission Commande #'
                    || left(v_order.id::text, 8);
            ELSIF v_is_cash_payment AND v_order.courier_id IS NOT NULL THEN
                v_vendor_description :=
                    'Vente Cash à la livraison (Commande #'
                    || left(v_order.id::text, 8) || ')';
            ELSE
                v_vendor_description :=
                    'Vente #' || left(v_order.id::text, 8)
                    || ' (Payout ' || ROUND(v_item_subtotal) || ')';
            END IF;

            -- GUARD: profile_id must not be NULL (FK constraint on wallet_transactions)
            INSERT INTO public.wallet_transactions
              (profile_id, store_id, amount, type, reference_id, description)
            VALUES (
                v_order.vendor_id,                  -- NOT NULL — guarded above
                v_store.id,
                v_final_vendor_digital_change,
                CASE WHEN v_final_vendor_digital_change > 0 THEN 'sale' ELSE 'fee' END,
                v_order.id::TEXT,
                v_vendor_description
            );
        END IF;
    END IF;
    -- If no store found: silently skip vendor payout (direct-sale / test product).
    -- The order still proceeds; admin can manually settle via admin panel.

    -- ── F. Courier payout — with COD negative-balance guard ──────────────────
    IF v_order.courier_id IS NOT NULL THEN
        v_final_courier_digital_change := v_courier_payout;
        IF v_is_cash_payment THEN
            v_final_courier_digital_change := v_courier_payout - v_order.total_amount;
        END IF;

        IF v_final_courier_digital_change != 0 THEN
            IF v_final_courier_digital_change < 0 THEN
                SELECT wallet_balance INTO v_courier_balance
                FROM public.profiles
                WHERE id = v_order.courier_id
                FOR UPDATE;

                IF v_courier_balance + v_final_courier_digital_change < 0 THEN
                    -- Return soft failure — caller (process_wallet_checkout) raises
                    RETURN jsonb_build_object(
                        'success',        false,
                        'error',          'cod_courier_insufficient_balance',
                        'message',        format(
                            'Courier wallet too low for COD settlement. Balance: %s GNF, Required: %s GNF.',
                            ROUND(v_courier_balance),
                            ROUND(abs(v_final_courier_digital_change))
                        ),
                        'courierBalance', ROUND(v_courier_balance),
                        'debtAmount',     ROUND(abs(v_final_courier_digital_change))
                    );
                END IF;
            END IF;

            -- Credit profiles.wallet_balance
            UPDATE public.profiles
            SET wallet_balance = wallet_balance + ROUND(v_final_courier_digital_change),
                updated_at     = NOW()
            WHERE id = v_order.courier_id;

            -- Mirror to courier_profiles.balance (keeps dashboard in sync)
            UPDATE public.courier_profiles
            SET balance    = COALESCE(balance, 0) + ROUND(v_final_courier_digital_change),
                updated_at = NOW()
            WHERE user_id = v_order.courier_id;

            INSERT INTO public.wallet_transactions
              (profile_id, amount, type, reference_id, description)
            VALUES (
                v_order.courier_id,
                v_final_courier_digital_change,
                CASE WHEN v_final_courier_digital_change > 0 THEN 'delivery_fee' ELSE 'fee' END,
                v_order.id::TEXT,
                CASE WHEN v_is_cash_payment
                     THEN 'Collecte Cash — Remise Plateforme Commande #'
                          || left(v_order.id::text, 8)
                     ELSE 'Course effectuée — Commande #'
                          || left(v_order.id::text, 8)
                END
            );
        END IF;
    END IF;

    -- ── G. Platform commission log ────────────────────────────────────────────
    INSERT INTO public.platform_logs (type, amount, reference_id, metadata)
    VALUES (
        'commission',
        ROUND(v_platform_commission),
        v_order.id,
        jsonb_build_object(
            'order_total',  v_order.total_amount,
            'vendor_id',    v_order.vendor_id,
            'is_cash',      v_is_cash_payment
        )
    );

    -- ── H. Mark order as financially settled ──────────────────────────────────
    UPDATE public.orders SET financial_status = 'processed' WHERE id = p_order_id;

    RETURN jsonb_build_object(
        'success',            true,
        'vendorPayout',       ROUND(v_vendor_payout),
        'courierPayout',      ROUND(v_courier_payout),
        'platformCommission', ROUND(v_platform_commission)
    );

EXCEPTION
    WHEN OTHERS THEN
        RAISE WARNING '[secure_process_order_financials] order=% error=% detail=%',
            p_order_id, SQLERRM, SQLSTATE;
        RAISE;
END;
$$;

GRANT EXECUTE ON FUNCTION public.secure_process_order_financials(uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION public.secure_process_order_financials(uuid) TO service_role;

NOTIFY pgrst, 'reload schema';
