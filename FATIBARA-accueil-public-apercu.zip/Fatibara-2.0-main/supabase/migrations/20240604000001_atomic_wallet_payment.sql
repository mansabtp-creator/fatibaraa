-- Migration: 20240604_atomic_wallet_payment.sql
-- Description: Creates an RPC function for atomic wallet payments to prevent money loss if order creation fails.

CREATE OR REPLACE FUNCTION process_wallet_checkout(
  p_user_id UUID,
  p_total_amount DECIMAL,
  p_orders JSONB,
  p_deliveries JSONB,
  p_order_items JSONB
) RETURNS JSONB AS $$
DECLARE
  v_current_balance DECIMAL;
  v_order_id UUID;
  v_result JSONB := '[]'::jsonb;
  v_order_data JSONB;
  v_item_data JSONB;
  v_delivery_data JSONB;
  v_order_index INT;
  v_new_order_id UUID;
BEGIN
  -- 1. Check Wallet Balance and lock the row
  SELECT wallet_balance INTO v_current_balance
  FROM profiles
  WHERE id = p_user_id
  FOR UPDATE;

  IF v_current_balance IS NULL THEN
    RAISE EXCEPTION 'User profile not found';
  END IF;

  IF v_current_balance < p_total_amount THEN
    RAISE EXCEPTION 'Insufficient wallet balance';
  END IF;

  -- 2. Deduct balance
  UPDATE profiles
  SET wallet_balance = wallet_balance - p_total_amount
  WHERE id = p_user_id;

  -- 3. Insert Orders
  FOR v_order_index IN 0 .. jsonb_array_length(p_orders) - 1 LOOP
    v_order_data := p_orders -> v_order_index;
    
    INSERT INTO orders (
      user_id, store_id, vendor_id, customer_name, items_count, total_amount, 
      delivery_fee, status, tracking_number, delivery_otp, shipping_address
    ) VALUES (
      p_user_id,
      NULLIF((v_order_data->>'store_id'), '')::UUID,
      NULLIF((v_order_data->>'vendor_id'), '')::UUID,
      v_order_data->>'customer_name',
      (v_order_data->>'items_count')::INT,
      (v_order_data->>'total_amount')::DECIMAL,
      COALESCE((v_order_data->>'delivery_fee')::DECIMAL, 0),
      'paid', -- Wallet orders are paid immediately
      v_order_data->>'tracking_number',
      v_order_data->>'delivery_otp',
      v_order_data->'shipping_address'
    ) RETURNING id INTO v_new_order_id;
    
    v_result := v_result || jsonb_build_object('tracking_number', v_order_data->>'tracking_number', 'id', v_new_order_id);

    -- 4. Insert Delivery if provided for this order index
    IF p_deliveries IS NOT NULL AND jsonb_array_length(p_deliveries) > v_order_index THEN
        v_delivery_data := p_deliveries -> v_order_index;
        IF v_delivery_data IS NOT NULL AND jsonb_typeof(v_delivery_data) = 'object' THEN
            INSERT INTO deliveries (
                order_id, status, current_location
            ) VALUES (
                v_new_order_id,
                v_delivery_data->>'status',
                v_delivery_data->'current_location'
            );
        END IF;
    END IF;

    -- 5. Insert Order Items for this order
    IF p_order_items IS NOT NULL AND jsonb_array_length(p_order_items) > v_order_index THEN
        FOR v_item_data IN SELECT * FROM jsonb_array_elements(p_order_items -> v_order_index) LOOP
            INSERT INTO order_items (
                order_id, product_id, quantity, price_at_purchase, selected_variations
            ) VALUES (
                v_new_order_id,
                (v_item_data->>'product_id')::UUID,
                (v_item_data->>'quantity')::INT,
                (v_item_data->>'price_at_purchase')::DECIMAL,
                v_item_data->'selected_variations'
            );
        END LOOP;
    END IF;

  END LOOP;

  RETURN v_result;

EXCEPTION
  WHEN OTHERS THEN
    RAISE;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;
