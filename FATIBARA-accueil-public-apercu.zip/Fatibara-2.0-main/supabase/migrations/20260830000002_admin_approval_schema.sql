-- Migration: Admin Approval Workflow — Schema Support
-- Adds rejection_reason to stores and profiles for vendor/courier rejection tracking.
-- Also ensures store_status has 'rejected' as a valid value and adds applied_at timestamp.

-- ── stores: add rejection_reason + ensure 'rejected' is valid ─────────────────
ALTER TABLE public.stores
  ADD COLUMN IF NOT EXISTS rejection_reason TEXT,
  ADD COLUMN IF NOT EXISTS applied_at TIMESTAMPTZ DEFAULT NOW();

-- Widen the store_status check constraint to include 'rejected' and 'archived'
ALTER TABLE public.stores
  DROP CONSTRAINT IF EXISTS stores_store_status_check;

ALTER TABLE public.stores
  ADD CONSTRAINT stores_store_status_check
  CHECK (store_status IN ('pending', 'active', 'suspended', 'rejected', 'archived'));

-- ── profiles: add courier rejection_reason ────────────────────────────────────
ALTER TABLE public.profiles
  ADD COLUMN IF NOT EXISTS courier_rejection_reason TEXT;

-- ── Ensure courier_status allows 'rejected' ───────────────────────────────────
-- The courier_status column uses a TEXT type with no check constraint by default.
-- No migration needed, but document the canonical values:
-- 'inactive'   = applied, pending admin approval
-- 'disponible' = approved, available for orders
-- 'en_course'  = on an active delivery
-- 'hors_ligne' = offline (self-set)
-- 'suspendu'   = suspended by admin
-- 'rejected'   = application rejected by admin

-- ── Notify PostgREST ──────────────────────────────────────────────────────────
NOTIFY pgrst, 'reload schema';
