-- =============================================================================
-- Resolve the remaining production schema-lint errors without deleting legacy
-- RPC compatibility paths.
-- =============================================================================

-- A legacy stock helper still records its updates in this camelCase timestamp.
-- Retaining the compatibility field is safer than dropping an already-exposed
-- RPC whose callers may exist outside this repository.
ALTER TABLE public.products
  ADD COLUMN IF NOT EXISTS "updatedAt" TIMESTAMPTZ;

-- The output column `relevance` is also a PL/pgSQL variable. Sort by its output
-- position to avoid the ambiguity while retaining the public RPC contract.
CREATE OR REPLACE FUNCTION public.search_products(search_query TEXT)
RETURNS TABLE (
  id UUID,
  title TEXT,
  price_gnf NUMERIC,
  wholesale_price_gnf NUMERIC,
  image_urls TEXT[],
  relevance REAL,
  category TEXT
)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  is_pro BOOLEAN := FALSE;
BEGIN
  IF auth.uid() IS NOT NULL THEN
    SELECT is_pro_member INTO is_pro
    FROM public.profiles
    WHERE profiles.id = auth.uid();
  END IF;

  RETURN QUERY
  SELECT
    p.id,
    p.title,
    p.price_gnf,
    CASE WHEN is_pro THEN p.wholesale_price_gnf ELSE NULL END,
    p.image_urls,
    (similarity(p.title, search_query) * 0.7
      + similarity(p.description, search_query) * 0.3)::REAL,
    p.category
  FROM public.products p
  WHERE p.title % search_query
     OR p.description % search_query
     OR p.title ILIKE '%' || search_query || '%'
     OR p.title ILIKE search_query || '%'
  ORDER BY 6 DESC, p.created_at DESC
  LIMIT 8;
END;
$$;

GRANT EXECUTE ON FUNCTION public.search_products(TEXT) TO anon, authenticated;

NOTIFY pgrst, 'reload schema';
