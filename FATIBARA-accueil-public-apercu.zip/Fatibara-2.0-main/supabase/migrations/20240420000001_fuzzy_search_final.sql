-- =================================================================================
-- FATIBARA FUZZY SEARCH SYSTEM
-- Handles typos and partial matches using pg_trgm similarity scores.
-- =================================================================================

-- 1. ENABLE PG_TRGM EXTENSION
-- Provides functions and operators for determining the similarity of text based on trigram matching.
CREATE EXTENSION IF NOT EXISTS pg_trgm;

-- 2. CREATE OPTIMIZED INDEXES
-- We use GIST with gist_trgm_ops for fast similarity searching.
-- GIST is often better for similarity searches that combine multiple conditions.
CREATE INDEX IF NOT EXISTS idx_products_title_fuzzy ON public.products USING gist (title gist_trgm_ops);
CREATE INDEX IF NOT EXISTS idx_products_description_fuzzy ON public.products USING gist (description gist_trgm_ops);

-- 3. ENHANCED SEARCH RPC WITH SIMILARITY SCORING
-- This function calculates a relevance score based on both title and description similarity.
-- It also fallback to standard ILIKE for prefix matching.
DROP FUNCTION IF EXISTS public.search_products(text);

CREATE OR REPLACE FUNCTION search_products(search_query text)
RETURNS TABLE (
  id uuid, 
  title text, 
  price_gnf numeric, 
  wholesale_price_gnf numeric, 
  image_urls text[],
  relevance real,
  category text
) AS $$
DECLARE
  is_pro boolean := false;
BEGIN
  -- Authenticated user check for Pro prices
  IF auth.uid() IS NOT NULL THEN
    SELECT is_pro_member INTO is_pro FROM public.profiles WHERE profiles.id = auth.uid();
  END IF;

  RETURN QUERY
  SELECT 
    p.id, 
    p.title, 
    p.price_gnf,
    CASE WHEN is_pro THEN p.wholesale_price_gnf ELSE NULL END as wholesale_price_gnf,
    p.image_urls,
    -- Relevance calculation: Similarity weight (Title 70%, Description 30%)
    (similarity(p.title, search_query) * 0.7 + similarity(p.description, search_query) * 0.3) as relevance,
    p.category
  FROM public.products p
  WHERE 
    -- Broad fuzzy match threshold (uses default 0.3 or custom if set)
    p.title % search_query 
    OR p.description % search_query
    -- Standard text search fallbacks for short strings
    OR p.title ILIKE '%' || search_query || '%'
    OR p.title ILIKE search_query || '%' -- Prefix match priority
  ORDER BY 
    relevance DESC,
    p.created_at DESC
  LIMIT 8;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;
