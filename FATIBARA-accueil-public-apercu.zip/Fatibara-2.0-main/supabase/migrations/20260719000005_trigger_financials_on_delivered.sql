-- ==============================================================================
-- Migration: Auto-trigger financial settlement on order delivery
-- Created At: 2026-07-19
-- Author:     Antigravity / Fatibara Engineering
--
-- PURPOSE:
--   Cash-on-delivery (COD) and any order that was not financially settled at
--   payment time (e.g., manually confirmed orders) need to have vendor balances,
--   courier ledger entries, and platform commission logs written when the courier
--   marks the order as 'delivered' — i.e., when money actually changes hands.
--
--   This trigger fires AFTER UPDATE on public.orders, detects the transition
--   to status='delivered', and calls secure_process_order_financials if the
--   order has not already been settled (financial_status NOT IN ('processed',
--   'failed', 'refunded')).
--
-- SAFETY:
--   • secure_process_order_financials has its own idempotency guard
--     (checks for existing 'sale' wallet_transactions) — duplicate calls are safe.
--   • The trigger is AFTER UPDATE so it does NOT block the status change even
--     if the financial call raises a non-fatal error; the error is logged via
--     RAISE WARNING so operations are not disrupted.
--   • The trigger uses SECURITY DEFINER so it has permission to call the
--     settlement RPC regardless of who performs the UPDATE.
-- ==============================================================================

-- ── Trigger function ───────────────────────────────────────────────────────────
CREATE OR REPLACE FUNCTION public.auto_settle_financials_on_delivery()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_result JSONB;
BEGIN
  -- Only act when status transitions TO 'delivered'
  IF NEW.status = 'delivered' AND (OLD.status IS DISTINCT FROM 'delivered') THEN

    -- Skip orders already settled or explicitly failed/refunded
    IF NEW.financial_status NOT IN ('processed', 'failed', 'refunded') THEN

      BEGIN
        SELECT public.secure_process_order_financials(NEW.id)
        INTO   v_result;

        IF NOT COALESCE((v_result->>'success')::boolean, false) THEN
          RAISE WARNING '[auto_settle] secure_process_order_financials returned failure for order %: %',
                        NEW.id, v_result;
        ELSE
          RAISE LOG '[auto_settle] Financials settled for order %: vendorPayout=%, courierPayout=%, commission=%',
                    NEW.id,
                    v_result->>'vendorPayout',
                    v_result->>'courierPayout',
                    v_result->>'platformCommission';
        END IF;

      EXCEPTION WHEN OTHERS THEN
        -- Log but do NOT re-raise — the delivery status update must succeed
        -- even if financial settlement has a transient error. Ops can re-trigger
        -- manually via secure_process_order_financials(order_id).
        RAISE WARNING '[auto_settle] Exception settling order %: %', NEW.id, SQLERRM;
      END;

    END IF;
  END IF;

  RETURN NEW;
END;
$$;

-- ── Attach trigger ─────────────────────────────────────────────────────────────
DROP TRIGGER IF EXISTS trg_auto_settle_financials_on_delivery ON public.orders;

CREATE TRIGGER trg_auto_settle_financials_on_delivery
  AFTER UPDATE OF status ON public.orders
  FOR EACH ROW
  EXECUTE FUNCTION public.auto_settle_financials_on_delivery();

-- ── Grant ──────────────────────────────────────────────────────────────────────
GRANT EXECUTE ON FUNCTION public.auto_settle_financials_on_delivery() TO service_role;

NOTIFY pgrst, 'reload schema';
