-- =============================================================================
-- Migration: Harden All Tables RLS — Full Security Audit Pass
-- File:      20260813000004_harden_all_tables_rls.sql
-- Created:   2026-08-13
--
-- CONTEXT:
--   Supabase security advisory "rls_désactivé_en_public" flagged tables that
--   either have RLS disabled entirely, or have RLS enabled but no policies
--   (effectively locking out all non-service-role access).
--
-- APPROACH:
--   1. Enable RLS on EVERY table in the public schema (idempotent loop).
--   2. Create or replace individual policies per table, using only FLAT
--      expressions (no correlated sub-selects on the same table) to avoid
--      the infinite-recursion 42P17 that plagued earlier migrations.
--   3. Admin super-access is gated on profiles.is_admin = true via a single
--      EXISTS sub-select against the profiles table (NOT orders/products itself
--      — safe, no recursion).
--   4. Grant the minimum required privileges to anon / authenticated /
--      service_role so that RLS can actually be evaluated.
--   5. All DROP POLICY statements use IF EXISTS for idempotency.
-- =============================================================================

-- =============================================================================
-- SECTION 1: Force-enable RLS on every public table (idempotent)
-- =============================================================================
DO $$
DECLARE r RECORD;
BEGIN
  FOR r IN (
    SELECT tablename FROM pg_tables WHERE schemaname = 'public'
  ) LOOP
    EXECUTE format(
      'ALTER TABLE public.%I ENABLE ROW LEVEL SECURITY;', r.tablename
    );
    -- NOTE: We intentionally do NOT use FORCE ROW LEVEL SECURITY globally
    -- because that would block table owners (postgres / service_role) from
    -- performing maintenance operations. Service_role bypasses RLS by default
    -- in Supabase — that is the intended security model.
  END LOOP;
END $$;

-- =============================================================================
-- SECTION 2: PROFILES
-- Existing policies (foundation): select_public, insert_own, update_own
-- Hardening additions:
--   • Admin full access policy (flat: checks is_admin on profiles itself is
--     safe because it's a column lookup on auth.uid() — no recursion)
--   • Delete is restricted to admin-only (users cannot delete their own profile
--     row — they must go through auth.users cascade)
-- =============================================================================

-- Admin write access
DROP POLICY IF EXISTS "profiles_admin_all" ON public.profiles;
CREATE POLICY "profiles_admin_all"
ON public.profiles FOR ALL TO authenticated
USING (
  EXISTS (SELECT 1 FROM public.profiles p WHERE p.id = auth.uid() AND p.is_admin = true)
)
WITH CHECK (
  EXISTS (SELECT 1 FROM public.profiles p WHERE p.id = auth.uid() AND p.is_admin = true)
);

-- =============================================================================
-- SECTION 3: STORES
-- Existing: select_public (true), insert_own, update_own, delete_own
-- Hardening: admin can manage any store (suspend, verify, etc.)
-- =============================================================================

DROP POLICY IF EXISTS "stores_admin_all" ON public.stores;
CREATE POLICY "stores_admin_all"
ON public.stores FOR ALL TO authenticated
USING (
  EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND is_admin = true)
)
WITH CHECK (
  EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND is_admin = true)
);

-- =============================================================================
-- SECTION 4: PRODUCTS
-- Existing: broadly open via grants. Close unauthorized writes.
-- Policy model:
--   SELECT  — public (anon + authenticated)
--   INSERT  — store owner only
--   UPDATE  — store owner only
--   DELETE  — store owner OR admin
-- =============================================================================

DROP POLICY IF EXISTS "products_public_select"   ON public.products;
CREATE POLICY "products_public_select"
ON public.products FOR SELECT USING (true);

DROP POLICY IF EXISTS "products_vendor_insert"   ON public.products;
CREATE POLICY "products_vendor_insert"
ON public.products FOR INSERT TO authenticated
WITH CHECK (
  store_id IN (
    SELECT id FROM public.stores WHERE owner_id = auth.uid()
  )
);

DROP POLICY IF EXISTS "products_vendor_update"   ON public.products;
CREATE POLICY "products_vendor_update"
ON public.products FOR UPDATE TO authenticated
USING (
  store_id IN (
    SELECT id FROM public.stores WHERE owner_id = auth.uid()
  )
  OR EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND is_admin = true)
)
WITH CHECK (
  store_id IN (
    SELECT id FROM public.stores WHERE owner_id = auth.uid()
  )
  OR EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND is_admin = true)
);

DROP POLICY IF EXISTS "products_vendor_delete"   ON public.products;
CREATE POLICY "products_vendor_delete"
ON public.products FOR DELETE TO authenticated
USING (
  store_id IN (
    SELECT id FROM public.stores WHERE owner_id = auth.uid()
  )
  OR EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND is_admin = true)
);

-- =============================================================================
-- SECTION 5: ORDERS
-- Existing policies (as of 20260807000001):
--   orders_select_v3           (buyer/vendor/courier party check)
--   orders_courier_pool_select (unclaimed pool view)
--   Fatibara flat orders update policy (vendor + courier + pool claim)
--   orders_insert_v3           (buyer only)
--   orders_delete_v3           (vendor only)
-- Hardening: add admin full-access bypass without touching existing flat policies
-- =============================================================================

DROP POLICY IF EXISTS "orders_admin_all" ON public.orders;
CREATE POLICY "orders_admin_all"
ON public.orders FOR ALL TO authenticated
USING (
  EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND is_admin = true)
)
WITH CHECK (
  EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND is_admin = true)
);

-- =============================================================================
-- SECTION 6: ORDER_ITEMS
-- SELECT  — buyer (via order user_id join) / vendor / admin
-- INSERT  — buyer creates items at order time
-- UPDATE/DELETE — admin only (corrections)
-- =============================================================================

ALTER TABLE public.order_items ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "order_items_parties_select"  ON public.order_items;
CREATE POLICY "order_items_parties_select"
ON public.order_items FOR SELECT TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM public.orders
    WHERE orders.id = order_items.order_id
      AND (
        orders.user_id    = auth.uid()
        OR orders.vendor_id  = auth.uid()
        OR orders.courier_id = auth.uid()
      )
  )
  OR EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND is_admin = true)
);

-- Anon cannot read order items
DROP POLICY IF EXISTS "order_items_anon_deny"       ON public.order_items;
-- (no anon policy = deny by default when RLS is on)

DROP POLICY IF EXISTS "order_items_buyer_insert"    ON public.order_items;
CREATE POLICY "order_items_buyer_insert"
ON public.order_items FOR INSERT TO authenticated
WITH CHECK (
  EXISTS (
    SELECT 1 FROM public.orders
    WHERE orders.id   = order_items.order_id
      AND orders.user_id = auth.uid()
  )
);

DROP POLICY IF EXISTS "order_items_admin_write"     ON public.order_items;
CREATE POLICY "order_items_admin_write"
ON public.order_items FOR ALL TO authenticated
USING (
  EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND is_admin = true)
)
WITH CHECK (
  EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND is_admin = true)
);

-- =============================================================================
-- SECTION 7: WALLET_TRANSACTIONS
-- Existing (wallet_rls_fix.sql): strict 3-way SELECT policy (profile / store / admin)
-- Hardening: ensure INSERT/UPDATE/DELETE are admin-only (all writes go via SECURITY
-- DEFINER RPCs which bypass RLS; direct writes blocked here as defense-in-depth)
-- =============================================================================

DROP POLICY IF EXISTS "wallet_transactions_admin_write" ON public.wallet_transactions;
CREATE POLICY "wallet_transactions_admin_write"
ON public.wallet_transactions FOR ALL TO authenticated
USING (
  EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND is_admin = true)
)
WITH CHECK (
  EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND is_admin = true)
);

-- =============================================================================
-- SECTION 8: WITHDRAWALS
-- SELECT  — own rows only
-- INSERT  — via RPC only (SECURITY DEFINER bypasses RLS; no direct insert allowed)
-- UPDATE  — admin only (approve/reject)
-- DELETE  — admin only
-- =============================================================================

ALTER TABLE public.withdrawals ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "withdrawals_own_select"   ON public.withdrawals;
CREATE POLICY "withdrawals_own_select"
ON public.withdrawals FOR SELECT TO authenticated
USING (
  profile_id = auth.uid()
  OR store_id IN (SELECT id FROM public.stores WHERE owner_id = auth.uid())
  OR EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND is_admin = true)
);

DROP POLICY IF EXISTS "withdrawals_admin_write"  ON public.withdrawals;
CREATE POLICY "withdrawals_admin_write"
ON public.withdrawals FOR ALL TO authenticated
USING (
  EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND is_admin = true)
)
WITH CHECK (
  EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND is_admin = true)
);

-- =============================================================================
-- SECTION 9: NOTIFICATIONS
-- =============================================================================

ALTER TABLE public.notifications ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "notifications_own_select" ON public.notifications;
CREATE POLICY "notifications_own_select"
ON public.notifications FOR SELECT TO authenticated
USING (
  user_id = auth.uid()
  OR EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND is_admin = true)
);

DROP POLICY IF EXISTS "notifications_own_update" ON public.notifications;
CREATE POLICY "notifications_own_update"
ON public.notifications FOR UPDATE TO authenticated
USING (user_id = auth.uid())
WITH CHECK (user_id = auth.uid());

DROP POLICY IF EXISTS "notifications_system_insert" ON public.notifications;
CREATE POLICY "notifications_system_insert"
ON public.notifications FOR INSERT TO authenticated
WITH CHECK (true); -- Insert restricted to SECURITY DEFINER RPCs in practice

DROP POLICY IF EXISTS "notifications_admin_all"  ON public.notifications;
CREATE POLICY "notifications_admin_all"
ON public.notifications FOR ALL TO authenticated
USING (
  EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND is_admin = true)
)
WITH CHECK (
  EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND is_admin = true)
);

-- =============================================================================
-- SECTION 10: CART_ITEMS
-- =============================================================================

ALTER TABLE public.cart_items ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "cart_items_own_all" ON public.cart_items;
CREATE POLICY "cart_items_own_all"
ON public.cart_items FOR ALL TO authenticated
USING (user_id = auth.uid())
WITH CHECK (user_id = auth.uid());

-- =============================================================================
-- SECTION 11: REVIEWS
-- Existing: reviews_public_read, reviews_authenticated_insert, reviews_vendor_respond
-- Hardening: add admin write access
-- =============================================================================

DROP POLICY IF EXISTS "reviews_admin_all" ON public.reviews;
CREATE POLICY "reviews_admin_all"
ON public.reviews FOR ALL TO authenticated
USING (
  EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND is_admin = true)
)
WITH CHECK (
  EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND is_admin = true)
);

-- =============================================================================
-- SECTION 12: DELIVERIES
-- =============================================================================

ALTER TABLE public.deliveries ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "deliveries_parties_select" ON public.deliveries;
CREATE POLICY "deliveries_parties_select"
ON public.deliveries FOR SELECT TO authenticated
USING (
  courier_id = auth.uid()
  OR EXISTS (
    SELECT 1 FROM public.orders
    WHERE orders.id = deliveries.order_id
      AND (orders.user_id = auth.uid() OR orders.vendor_id = auth.uid())
  )
  OR EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND is_admin = true)
);

DROP POLICY IF EXISTS "deliveries_courier_update" ON public.deliveries;
CREATE POLICY "deliveries_courier_update"
ON public.deliveries FOR UPDATE TO authenticated
USING (
  courier_id = auth.uid()
  OR EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND is_admin = true)
)
WITH CHECK (
  courier_id = auth.uid()
  OR EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND is_admin = true)
);

DROP POLICY IF EXISTS "deliveries_system_insert" ON public.deliveries;
CREATE POLICY "deliveries_system_insert"
ON public.deliveries FOR INSERT TO authenticated
WITH CHECK (
  EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND is_admin = true)
  OR courier_id = auth.uid()
);

-- =============================================================================
-- SECTION 13: CONTENT_REPORTS
-- =============================================================================

ALTER TABLE public.content_reports ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "content_reports_own_insert" ON public.content_reports;
CREATE POLICY "content_reports_own_insert"
ON public.content_reports FOR INSERT TO authenticated
WITH CHECK (reporter_id = auth.uid());

DROP POLICY IF EXISTS "content_reports_admin_all"  ON public.content_reports;
CREATE POLICY "content_reports_admin_all"
ON public.content_reports FOR ALL TO authenticated
USING (
  EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND is_admin = true)
)
WITH CHECK (
  EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND is_admin = true)
);

-- =============================================================================
-- SECTION 14: PUSH_SUBSCRIPTIONS
-- =============================================================================

ALTER TABLE public.push_subscriptions ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "push_own_all" ON public.push_subscriptions;
CREATE POLICY "push_own_all"
ON public.push_subscriptions FOR ALL TO authenticated
USING (user_id = auth.uid())
WITH CHECK (user_id = auth.uid());

DROP POLICY IF EXISTS "push_admin_select" ON public.push_subscriptions;
CREATE POLICY "push_admin_select"
ON public.push_subscriptions FOR SELECT TO authenticated
USING (
  EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND is_admin = true)
);

-- =============================================================================
-- SECTION 15: ANNOUNCEMENTS
-- =============================================================================

ALTER TABLE public.announcements ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "announcements_public_read"  ON public.announcements;
CREATE POLICY "announcements_public_read"
ON public.announcements FOR SELECT USING (is_active = true OR is_active IS NULL);

DROP POLICY IF EXISTS "announcements_admin_write"  ON public.announcements;
CREATE POLICY "announcements_admin_write"
ON public.announcements FOR ALL TO authenticated
USING (
  EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND is_admin = true)
)
WITH CHECK (
  EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND is_admin = true)
);

-- =============================================================================
-- SECTION 16: VENDOR_INVITATIONS
-- =============================================================================

ALTER TABLE public.vendor_invitations ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "vendor_invitations_invitee_read" ON public.vendor_invitations;
CREATE POLICY "vendor_invitations_invitee_read"
ON public.vendor_invitations FOR SELECT TO authenticated
USING (
  -- Any authenticated user can read invitations (needed for token-validation flow).
  -- The existing policy from 20260723000003 uses USING (true); we preserve that
  -- permissiveness here since the token itself is the secret.
  -- email_hint matching via auth.email() — safe, no auth.users subquery needed.
  email_hint = auth.email()
  OR email_hint IS NULL
  OR EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND is_admin = true)
);

DROP POLICY IF EXISTS "vendor_invitations_admin_write"  ON public.vendor_invitations;
CREATE POLICY "vendor_invitations_admin_write"
ON public.vendor_invitations FOR ALL TO authenticated
USING (
  EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND is_admin = true)
)
WITH CHECK (
  EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND is_admin = true)
);

-- =============================================================================
-- SECTION 17: PROMOTIONS & PROMOTION_PRODUCTS
-- Existing: public read, admin write (using profiles subquery — safe)
-- Hardening: also allow store owners to manage their own promotions
-- =============================================================================

DROP POLICY IF EXISTS "promotions_vendor_write" ON public.promotions;
CREATE POLICY "promotions_vendor_write"
ON public.promotions FOR ALL TO authenticated
USING (
  store_id IN (SELECT id FROM public.stores WHERE owner_id = auth.uid())
  OR EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND is_admin = true)
)
WITH CHECK (
  store_id IN (SELECT id FROM public.stores WHERE owner_id = auth.uid())
  OR EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND is_admin = true)
);

-- =============================================================================
-- SECTION 18: BOOST_CAMPAIGNS
-- =============================================================================

ALTER TABLE public.boost_campaigns ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "boost_campaigns_public_read"  ON public.boost_campaigns;
CREATE POLICY "boost_campaigns_public_read"
ON public.boost_campaigns FOR SELECT USING (true);

DROP POLICY IF EXISTS "boost_campaigns_vendor_write" ON public.boost_campaigns;
CREATE POLICY "boost_campaigns_vendor_write"
ON public.boost_campaigns FOR ALL TO authenticated
USING (
  store_id IN (SELECT id FROM public.stores WHERE owner_id = auth.uid())
  OR EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND is_admin = true)
)
WITH CHECK (
  store_id IN (SELECT id FROM public.stores WHERE owner_id = auth.uid())
  OR EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND is_admin = true)
);

-- =============================================================================
-- SECTION 19: COURIER_LOCATIONS
-- Couriers write their own location; admins and buyers with active orders can read
-- =============================================================================

ALTER TABLE public.courier_locations ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "courier_locations_own_upsert" ON public.courier_locations;
CREATE POLICY "courier_locations_own_upsert"
ON public.courier_locations FOR ALL TO authenticated
USING (courier_id = auth.uid())
WITH CHECK (courier_id = auth.uid());

DROP POLICY IF EXISTS "courier_locations_order_parties_read" ON public.courier_locations;
CREATE POLICY "courier_locations_order_parties_read"
ON public.courier_locations FOR SELECT TO authenticated
USING (
  -- The buyer or vendor on an active order can see the courier's location
  EXISTS (
    SELECT 1 FROM public.orders
    WHERE orders.courier_id = courier_locations.courier_id
      AND orders.status IN ('accepted', 'in_transit', 'picked_up')
      AND (orders.user_id = auth.uid() OR orders.vendor_id = auth.uid())
  )
  OR EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND is_admin = true)
);

-- =============================================================================
-- SECTION 20: PLATFORM_SETTINGS & PLATFORM_LOGS
-- =============================================================================

ALTER TABLE public.platform_settings ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "platform_settings_public_read" ON public.platform_settings;
CREATE POLICY "platform_settings_public_read"
ON public.platform_settings FOR SELECT USING (true);

DROP POLICY IF EXISTS "platform_settings_admin_write" ON public.platform_settings;
CREATE POLICY "platform_settings_admin_write"
ON public.platform_settings FOR ALL TO authenticated
USING (
  EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND is_admin = true)
)
WITH CHECK (
  EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND is_admin = true)
);

ALTER TABLE public.platform_logs ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "platform_logs_admin_all" ON public.platform_logs;
CREATE POLICY "platform_logs_admin_all"
ON public.platform_logs FOR ALL TO authenticated
USING (
  EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND is_admin = true)
)
WITH CHECK (
  EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND is_admin = true)
);

-- =============================================================================
-- SECTION 21: CHAT TABLES (chat_channels, chat_messages)
-- =============================================================================

ALTER TABLE public.chat_channels ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "chat_channels_parties_all" ON public.chat_channels;
CREATE POLICY "chat_channels_parties_all"
ON public.chat_channels FOR ALL TO authenticated
USING (
  buyer_id = auth.uid()
  OR store_id IN (SELECT id FROM public.stores WHERE owner_id = auth.uid())
  OR EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND is_admin = true)
)
WITH CHECK (
  buyer_id = auth.uid()
  OR store_id IN (SELECT id FROM public.stores WHERE owner_id = auth.uid())
);

ALTER TABLE public.chat_messages ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "chat_messages_channel_parties_select" ON public.chat_messages;
CREATE POLICY "chat_messages_channel_parties_select"
ON public.chat_messages FOR SELECT TO authenticated
USING (
  channel_id IN (
    SELECT id FROM public.chat_channels
    WHERE buyer_id = auth.uid()
      OR store_id IN (SELECT id FROM public.stores WHERE owner_id = auth.uid())
  )
  OR EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND is_admin = true)
);

DROP POLICY IF EXISTS "chat_messages_parties_insert" ON public.chat_messages;
CREATE POLICY "chat_messages_parties_insert"
ON public.chat_messages FOR INSERT TO authenticated
WITH CHECK (
  sender_id = auth.uid()
  AND channel_id IN (
    SELECT id FROM public.chat_channels
    WHERE buyer_id = auth.uid()
      OR store_id IN (SELECT id FROM public.stores WHERE owner_id = auth.uid())
  )
);

DROP POLICY IF EXISTS "chat_messages_own_update" ON public.chat_messages;
CREATE POLICY "chat_messages_own_update"
ON public.chat_messages FOR UPDATE TO authenticated
USING (
  -- Mark as read: any party in the channel can update is_read
  channel_id IN (
    SELECT id FROM public.chat_channels
    WHERE buyer_id = auth.uid()
      OR store_id IN (SELECT id FROM public.stores WHERE owner_id = auth.uid())
  )
);

-- =============================================================================
-- SECTION 22: PRODUCT AUXILIARY TABLES
-- (product_views, price_history, product_variants, product_images, categories)
-- =============================================================================

ALTER TABLE public.product_views ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "product_views_public_insert" ON public.product_views;
CREATE POLICY "product_views_public_insert"
ON public.product_views FOR INSERT WITH CHECK (true);

DROP POLICY IF EXISTS "product_views_vendor_read"   ON public.product_views;
CREATE POLICY "product_views_vendor_read"
ON public.product_views FOR SELECT TO authenticated
USING (
  product_id IN (
    SELECT id FROM public.products WHERE store_id IN (
      SELECT id FROM public.stores WHERE owner_id = auth.uid()
    )
  )
  OR EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND is_admin = true)
);

ALTER TABLE public.price_history ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "price_history_public_read"    ON public.price_history;
CREATE POLICY "price_history_public_read"
ON public.price_history FOR SELECT USING (true);

DROP POLICY IF EXISTS "price_history_vendor_write"   ON public.price_history;
CREATE POLICY "price_history_vendor_write"
ON public.price_history FOR INSERT TO authenticated
WITH CHECK (
  product_id IN (
    SELECT id FROM public.products WHERE store_id IN (
      SELECT id FROM public.stores WHERE owner_id = auth.uid()
    )
  )
);

-- categories: always public read, admin write
DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema='public' AND table_name='categories') THEN
    EXECUTE $q$
      ALTER TABLE public.categories ENABLE ROW LEVEL SECURITY;
      DROP POLICY IF EXISTS "categories_public_read" ON public.categories;
      CREATE POLICY "categories_public_read" ON public.categories FOR SELECT USING (true);
      DROP POLICY IF EXISTS "categories_admin_write" ON public.categories;
      CREATE POLICY "categories_admin_write" ON public.categories FOR ALL TO authenticated
        USING (EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND is_admin = true))
        WITH CHECK (EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND is_admin = true));
    $q$;
  END IF;
END $$;

-- =============================================================================
-- SECTION 23: COMPREHENSIVE GRANTS (catch any tables added after the last grant migration)
-- =============================================================================

-- Ensure anon can read marketplace-public tables
GRANT SELECT ON public.products             TO anon, authenticated;
GRANT SELECT ON public.stores               TO anon, authenticated;
GRANT SELECT ON public.reviews              TO anon, authenticated;
GRANT SELECT ON public.promotions           TO anon, authenticated;
GRANT SELECT ON public.promotion_products   TO anon, authenticated;
GRANT SELECT ON public.boost_campaigns      TO anon, authenticated;
GRANT SELECT ON public.announcements        TO anon, authenticated;
GRANT SELECT ON public.platform_settings    TO anon, authenticated;

-- Authenticated-only tables
GRANT SELECT, UPDATE                              ON public.profiles             TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE              ON public.cart_items           TO authenticated;
GRANT SELECT, INSERT, UPDATE                      ON public.orders               TO authenticated;
GRANT SELECT, INSERT                              ON public.order_items          TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE              ON public.products             TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE              ON public.stores               TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE              ON public.reviews              TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE              ON public.promotions           TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE              ON public.promotion_products   TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE              ON public.boost_campaigns      TO authenticated;
GRANT SELECT, UPDATE                              ON public.notifications        TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE              ON public.push_subscriptions   TO authenticated;
GRANT SELECT                                      ON public.wallet_transactions  TO authenticated;
GRANT SELECT                                      ON public.withdrawals          TO authenticated;
GRANT SELECT, INSERT                              ON public.content_reports      TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE              ON public.announcements        TO authenticated;
GRANT SELECT                                      ON public.vendor_invitations   TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE              ON public.chat_channels        TO authenticated;
GRANT SELECT, INSERT, UPDATE                      ON public.chat_messages        TO authenticated;
GRANT SELECT, INSERT, UPDATE                      ON public.deliveries           TO authenticated;
GRANT SELECT, INSERT                              ON public.product_views        TO authenticated;
GRANT SELECT, INSERT                              ON public.price_history        TO authenticated;
GRANT SELECT, INSERT, UPDATE                      ON public.courier_locations    TO authenticated;

-- Service role gets full access (bypasses RLS anyway but explicit grant needed for PostgREST)
GRANT ALL ON ALL TABLES IN SCHEMA public TO service_role;
GRANT ALL ON ALL SEQUENCES IN SCHEMA public TO service_role;

-- Sequence grants
GRANT USAGE ON ALL SEQUENCES IN SCHEMA public TO authenticated;
GRANT USAGE ON ALL SEQUENCES IN SCHEMA public TO anon;

-- =============================================================================
-- SECTION 24: WALLETS TABLE (separate from wallet_transactions if present)
-- =============================================================================
DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema='public' AND table_name='wallets') THEN
    EXECUTE $q$
      ALTER TABLE public.wallets ENABLE ROW LEVEL SECURITY;
      DROP POLICY IF EXISTS "wallets_own_read" ON public.wallets;
      CREATE POLICY "wallets_own_read" ON public.wallets FOR SELECT TO authenticated
        USING (
          profile_id = auth.uid()
          OR EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND is_admin = true)
        );
      DROP POLICY IF EXISTS "wallets_admin_write" ON public.wallets;
      CREATE POLICY "wallets_admin_write" ON public.wallets FOR ALL TO authenticated
        USING (EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND is_admin = true))
        WITH CHECK (EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND is_admin = true));
    $q$;
  END IF;
END $$;

-- =============================================================================
-- FINAL: Flush PostgREST schema cache
-- =============================================================================
NOTIFY pgrst, 'reload schema';
