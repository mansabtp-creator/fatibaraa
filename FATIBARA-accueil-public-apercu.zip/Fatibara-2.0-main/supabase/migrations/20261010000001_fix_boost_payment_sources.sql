-- ==============================================================================
-- Migration: Support both Store Balance and Profile Wallet in launch_boost_campaign
-- Created At: 2026-10-10
--
-- Vendors can pay for PROPULSE campaigns using either:
-- 1. Store Treasury Balance (stores.balance) — vendor sales revenue
-- 2. User Profile Wallet (profiles.wallet_balance) — personal wallet
-- ==============================================================================

CREATE OR REPLACE FUNCTION public.launch_boost_campaign(
  p_store_id       UUID,
  p_campaign_type  TEXT,
  p_duration_label TEXT,
  p_duration_days  INTEGER,
  p_budget_gnf     NUMERIC
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_user_id     UUID;
  v_store       RECORD;
  v_wallet      NUMERIC;
  v_campaign_id UUID;
  v_paid_from   TEXT := 'store';
  v_new_bal     NUMERIC;
BEGIN
  v_user_id := auth.uid();
  IF v_user_id IS NULL THEN
    RAISE EXCEPTION 'Not authenticated';
  END IF;

  -- Validate input
  IF p_campaign_type NOT IN ('visibility', 'conversion') THEN
    RAISE EXCEPTION 'Invalid campaign type: %', p_campaign_type;
  END IF;
  IF p_budget_gnf <= 0 THEN
    RAISE EXCEPTION 'Budget must be positive';
  END IF;

  -- Verify store ownership and lock store row
  SELECT * INTO v_store FROM public.stores
  WHERE id = p_store_id AND owner_id = v_user_id
  FOR UPDATE;

  IF v_store IS NULL THEN
    RAISE EXCEPTION 'Store not found or not owned by current user';
  END IF;

  -- Read profile balance
  SELECT wallet_balance INTO v_wallet FROM public.profiles
  WHERE id = v_user_id FOR UPDATE;

  -- Prefer store balance if sufficient, otherwise check personal profile wallet
  IF COALESCE(v_store.balance, 0) >= p_budget_gnf THEN
    -- Deduct from store balance
    UPDATE public.stores
    SET balance = balance - p_budget_gnf
    WHERE id = p_store_id;
    v_paid_from := 'store';
    v_new_bal := v_store.balance - p_budget_gnf;
  ELSIF COALESCE(v_wallet, 0) >= p_budget_gnf THEN
    -- Deduct from user profile wallet
    UPDATE public.profiles
    SET wallet_balance = wallet_balance - p_budget_gnf
    WHERE id = v_user_id;
    v_paid_from := 'profile';
    v_new_bal := v_wallet - p_budget_gnf;
  ELSE
    RAISE EXCEPTION 'Solde insuffisant — % GNF requis. Solde boutique disponible : % GNF, solde profil : % GNF',
      p_budget_gnf, COALESCE(v_store.balance, 0), COALESCE(v_wallet, 0);
  END IF;

  -- Create campaign record
  INSERT INTO public.boost_campaigns (
    store_id, campaign_type, duration_label,
    duration_days, budget_gnf, status, launched_at, expires_at
  )
  VALUES (
    p_store_id, p_campaign_type, p_duration_label,
    p_duration_days, p_budget_gnf, 'active', NOW(),
    NOW() + (p_duration_days * INTERVAL '1 day')
  )
  RETURNING id INTO v_campaign_id;

  -- Log wallet transaction
  INSERT INTO public.wallet_transactions (
    profile_id, store_id, amount, type, reference_id, description, status
  )
  VALUES (
    v_user_id,
    p_store_id,
    -p_budget_gnf,
    'boost',
    v_campaign_id,
    'Boost ' || p_campaign_type || ' — ' || p_duration_label || ' (' || p_duration_days || 'j)',
    'completed'
  );

  RETURN jsonb_build_object(
    'success',      true,
    'campaign_id',  v_campaign_id,
    'paid_from',    v_paid_from,
    'new_balance',  v_new_bal
  );
END;
$$;

REVOKE EXECUTE ON FUNCTION public.launch_boost_campaign(UUID, TEXT, TEXT, INTEGER, NUMERIC) FROM PUBLIC;
GRANT  EXECUTE ON FUNCTION public.launch_boost_campaign(UUID, TEXT, TEXT, INTEGER, NUMERIC) TO authenticated;

NOTIFY pgrst, 'reload schema';
