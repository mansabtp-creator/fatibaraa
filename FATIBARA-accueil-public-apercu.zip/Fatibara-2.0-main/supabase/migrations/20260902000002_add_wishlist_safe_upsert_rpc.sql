-- =============================================================================
-- Migration: Replace PostgREST upsert with SQL-level ON CONFLICT DO NOTHING
-- Date: 2026-09-02
--
-- Problem: supabase-js .upsert({ onConflict, ignoreDuplicates: true }) relies
-- on PostgREST honouring the `Prefer: resolution=ignore-duplicates` header.
-- Some PostgREST versions return 409 anyway, producing console noise and
-- potential silent failures once the status !== 409 guard is removed.
--
-- Fix: Two SECURITY DEFINER functions that use native PostgreSQL
-- `ON CONFLICT (user_id, product_id) DO NOTHING`. This is guaranteed by the
-- Postgres engine to be silent — it can never return a constraint error.
-- The client calls supabase.rpc() instead of .upsert(), removing the
-- dependency on PostgREST conflict resolution entirely.
-- =============================================================================

-- 1. Single-item add (used by toggleWishlist)
--    user_id is taken from auth.uid() — never trusts the client-supplied value.
CREATE OR REPLACE FUNCTION public.add_wishlist_item(
  p_product_id uuid
)
RETURNS void
LANGUAGE sql
SECURITY DEFINER
SET search_path = public
AS $$
  INSERT INTO public.user_wishlists (user_id, product_id)
  VALUES (auth.uid(), p_product_id)
  ON CONFLICT (user_id, product_id) DO NOTHING;
$$;

-- 2. Bulk sync (used by syncWithCloud to push offline-added items)
--    user_id is taken from auth.uid() — never trusts the client-supplied array.
CREATE OR REPLACE FUNCTION public.sync_wishlist_items(
  p_product_ids uuid[]
)
RETURNS void
LANGUAGE sql
SECURITY DEFINER
SET search_path = public
AS $$
  INSERT INTO public.user_wishlists (user_id, product_id)
  SELECT auth.uid(), unnest(p_product_ids)
  ON CONFLICT (user_id, product_id) DO NOTHING;
$$;

-- Grant to authenticated users only
GRANT EXECUTE ON FUNCTION public.add_wishlist_item(uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION public.sync_wishlist_items(uuid[]) TO authenticated;

-- Reload PostgREST schema cache so RPCs are immediately visible
NOTIFY pgrst, 'reload schema';
