-- ============================================================
-- Migration: get_vendor_dashboard_metrics v2
-- Created:   2026-07-14
-- Purpose:   Re-defines the vendor dashboard metrics RPC with:
--              * Canonical parameter name  p_vendor_id  (UUID)
--              * Added  completed_orders  counter
--              * COALESCE guards on every aggregate to prevent NULL
--              * SECURITY DEFINER so the function runs as the
--                owning role and bypasses per-row RLS on orders
--            The frontend hook (useVendorData.ts) calls this via
--            supabase.rpc('get_vendor_dashboard_metrics', { p_vendor_id: user.id })
-- ============================================================

-- DROP the old function first so we can freely change the return type / signature.
-- IF EXISTS makes this migration idempotent (safe on a fresh database too).
DROP FUNCTION IF EXISTS public.get_vendor_dashboard_metrics(UUID);

CREATE OR REPLACE FUNCTION public.get_vendor_dashboard_metrics(p_vendor_id UUID)
RETURNS JSON
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_total_revenue    BIGINT;
    v_pending_count    INT;
    v_accepted_count   INT;
    v_completed_count  INT;
    v_result           JSON;
BEGIN
    -- Total revenue: all committed statuses (paid through delivered)
    SELECT COALESCE(SUM(total_amount), 0)
    INTO v_total_revenue
    FROM public.orders
    WHERE vendor_id = p_vendor_id
      AND status IN ('paid', 'accepted', 'preparing',
                     'ready_for_pickup', 'in_transit',
                     'delivered', 'completed');

    -- Pending orders (awaiting payment confirmation)
    SELECT COALESCE(COUNT(*), 0)
    INTO v_pending_count
    FROM public.orders
    WHERE vendor_id = p_vendor_id
      AND status = 'pending';

    -- Active / in-flight orders (payment confirmed, not yet delivered)
    SELECT COALESCE(COUNT(*), 0)
    INTO v_accepted_count
    FROM public.orders
    WHERE vendor_id = p_vendor_id
      AND status IN ('accepted', 'preparing', 'ready_for_pickup', 'in_transit');

    -- Completed / settled orders
    SELECT COALESCE(COUNT(*), 0)
    INTO v_completed_count
    FROM public.orders
    WHERE vendor_id = p_vendor_id
      AND status IN ('delivered', 'completed');

    -- Build unified JSON payload returned to the frontend dashboard metrics hook
    v_result := json_build_object(
        'total_revenue',    v_total_revenue,
        'pending_orders',   v_pending_count,
        'accepted_orders',  v_accepted_count,
        'completed_orders', v_completed_count
    );

    RETURN v_result;
END;
$$;

-- Re-grant execute rights to the PostgREST API gateway layer
GRANT EXECUTE ON FUNCTION public.get_vendor_dashboard_metrics(UUID) TO authenticated;

-- Signal PostgREST to reload its schema cache so the updated
-- function signature is immediately visible to the client SDK.
NOTIFY pgrst, 'reload schema';
