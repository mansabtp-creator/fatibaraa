-- ==============================================================================
-- Migration: Fix process_wallet_checkout — vendor/courier/commission settlement
-- Created At: 2026-07-19
-- Author:     Antigravity / Fatibara Engineering
--
-- ROOT CAUSES FIXED:
--   1. process_wallet_checkout correctly deducted the buyer's wallet balance and
--      created orders/deliveries/order_items atomically, but it NEVER called
--      secure_process_order_financials, so vendor store balances, courier ledger
--      entries and platform commission logs were never written for wallet payments.
--
--   2. The function inserted orders with status='paid' but left financial_status
--      at its default ('pending'). This caused secure_process_order_financials
--      to misidentify wallet orders as cash payments via its fallback logic:
--        v_is_cash_payment := COALESCE(
--            (shipping_address->>'payment_method') = 'cash',
--            financial_status != 'paid'   -- ← wallet orders fell through here
--        );
--
-- FIX:
--   A. Set financial_status = 'paid' on every order row inserted by this RPC.
--   B. After inserting all orders/items/deliveries, call
--      secure_process_order_financials(order_id) for each new order.
--      Because this runs inside the same plpgsql block it is implicitly part of
--      the same transaction: if any step fails, everything rolls back.
-- ==============================================================================

CREATE OR REPLACE FUNCTION public.process_wallet_checkout(
  p_user_id       UUID,
  p_total_amount  NUMERIC,
  p_orders        JSONB,
  p_deliveries    JSONB,
  p_order_items   JSONB
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_current_balance  NUMERIC;
  v_result           JSONB  := '[]'::jsonb;
  v_order_data       JSONB;
  v_item_data        JSONB;
  v_delivery_data    JSONB;
  v_order_index      INT;
  v_new_order_id     UUID;
  v_financial_result JSONB;
BEGIN
  -- ── 1. Lock profile row and verify balance ──────────────────────────────────
  SELECT wallet_balance
  INTO   v_current_balance
  FROM   public.profiles
  WHERE  id = p_user_id
  FOR UPDATE;

  IF NOT FOUND THEN
    RAISE EXCEPTION 'User profile not found';
  END IF;

  IF v_current_balance < p_total_amount THEN
    RAISE EXCEPTION 'Insufficient wallet balance. Balance: %, Required: %',
                    v_current_balance, p_total_amount;
  END IF;

  -- ── 2. Deduct buyer wallet balance ──────────────────────────────────────────
  UPDATE public.profiles
  SET    wallet_balance = wallet_balance - p_total_amount
  WHERE  id = p_user_id;

  -- Log the debit transaction for the buyer
  INSERT INTO public.wallet_transactions (
    profile_id, amount, type, description, status
  ) VALUES (
    p_user_id,
    -p_total_amount,
    'purchase',
    'Paiement Portefeuille — ' || jsonb_array_length(p_orders) || ' commande(s)',
    'completed'
  );

  -- ── 3. Create orders, deliveries, and order items ───────────────────────────
  FOR v_order_index IN 0 .. jsonb_array_length(p_orders) - 1 LOOP
    v_order_data := p_orders -> v_order_index;

    INSERT INTO public.orders (
      user_id,
      store_id,
      vendor_id,
      customer_name,
      items_count,
      total_amount,
      delivery_fee,
      vendor_delivery_fee,
      status,
      -- FIX (Bug 4): explicitly mark financial_status = 'paid' so that
      -- secure_process_order_financials does NOT treat this as a cash order.
      financial_status,
      tracking_number,
      delivery_otp,
      shipping_address
    ) VALUES (
      p_user_id,
      NULLIF((v_order_data->>'store_id'),  '')::UUID,
      NULLIF((v_order_data->>'vendor_id'), '')::UUID,
      v_order_data->>'customer_name',
      (v_order_data->>'items_count')::INT,
      (v_order_data->>'total_amount')::NUMERIC,
      COALESCE((v_order_data->>'delivery_fee')::NUMERIC, 0),
      COALESCE((v_order_data->'shipping_address'->>'vendor_delivery_fee')::NUMERIC, 0),
      'paid',
      'paid',          -- financial_status = 'paid' (FIX for Bug 4)
      v_order_data->>'tracking_number',
      v_order_data->>'delivery_otp',
      v_order_data->'shipping_address'
    )
    RETURNING id INTO v_new_order_id;

    -- Accumulate result
    v_result := v_result || jsonb_build_object(
      'id',              v_new_order_id,
      'tracking_number', v_order_data->>'tracking_number'
    );

    -- ── 3a. Insert delivery record ───────────────────────────────────────────
    IF p_deliveries IS NOT NULL
       AND jsonb_array_length(p_deliveries) > v_order_index
    THEN
      v_delivery_data := p_deliveries -> v_order_index;
      IF v_delivery_data IS NOT NULL
         AND jsonb_typeof(v_delivery_data) = 'object'
      THEN
        INSERT INTO public.deliveries (
          order_id, status, current_location
        ) VALUES (
          v_new_order_id,
          COALESCE(v_delivery_data->>'status', 'pending'),
          v_delivery_data->'current_location'
        );
      END IF;
    END IF;

    -- ── 3b. Insert order items ───────────────────────────────────────────────
    IF p_order_items IS NOT NULL
       AND jsonb_array_length(p_order_items) > v_order_index
    THEN
      FOR v_item_data IN
        SELECT * FROM jsonb_array_elements(p_order_items -> v_order_index)
      LOOP
        INSERT INTO public.order_items (
          order_id,
          product_id,
          quantity,
          price_at_purchase,
          selected_variations
        ) VALUES (
          v_new_order_id,
          (v_item_data->>'product_id')::UUID,
          (v_item_data->>'quantity')::INT,
          (v_item_data->>'price_at_purchase')::NUMERIC,
          COALESCE(v_item_data->'selected_variations', '{}'::jsonb)
        );
      END LOOP;
    END IF;

    -- ── 4. FIX (Bug 1): Distribute vendor/courier/platform financials ─────────
    -- Call secure_process_order_financials for each order inside this same
    -- transaction. If it fails the exception propagates and the whole block
    -- rolls back (buyer balance restored, no partial credits written).
    SELECT public.secure_process_order_financials(v_new_order_id)
    INTO   v_financial_result;

    IF NOT COALESCE((v_financial_result->>'success')::boolean, false) THEN
      RAISE EXCEPTION 'Financial distribution failed for order %: %',
                      v_new_order_id,
                      v_financial_result->>'error';
    END IF;

  END LOOP;

  RETURN v_result;

EXCEPTION
  WHEN OTHERS THEN
    -- Re-raise so the calling client sees the error and the transaction rolls back
    RAISE;
END;
$$;

-- Grant execute to authenticated users (same as before)
GRANT EXECUTE ON FUNCTION public.process_wallet_checkout(UUID, NUMERIC, JSONB, JSONB, JSONB)
  TO authenticated;

NOTIFY pgrst, 'reload schema';
