-- ── Fix: admin_update_user_role must also update active_role ─────────────────
--
-- Bug: The previous version set profile_type and courier_status correctly,
-- but left active_role unchanged.  AppContext.fetchProfile reads:
--
--   const dbActiveRole = data.active_role ?? pType;
--
-- The ?? only kicks in when active_role IS NULL.  If active_role was
-- previously 'customer' (the column default), it stays 'customer' even after
-- admin promotes the user to 'courier'. Login redirect sees activeRole =
-- 'customer' and sends the livreur to '/' instead of /livreur/dashboard.
--
-- Fix: also set active_role = v_active_role in the UPDATE statement.

DROP FUNCTION IF EXISTS public.admin_update_user_role(uuid, text);

CREATE OR REPLACE FUNCTION public.admin_update_user_role(
  target_user_id  uuid,
  new_profile_type text
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_active_role text;
BEGIN
  IF NOT public.is_admin() THEN
    RAISE EXCEPTION 'Permission refusée : vous n''êtes pas administrateur.';
  END IF;

  IF new_profile_type NOT IN ('client', 'courier', 'vendor') THEN
    RAISE EXCEPTION 'Type de profil invalide : %', new_profile_type;
  END IF;

  v_active_role := CASE new_profile_type
    WHEN 'client'  THEN 'customer'
    WHEN 'courier' THEN 'courier'
    WHEN 'vendor'  THEN 'vendor'
    ELSE new_profile_type
  END;

  UPDATE public.profiles
  SET
    profile_type   = new_profile_type,
    active_role    = v_active_role,
    courier_status = CASE WHEN new_profile_type = 'courier' THEN 'active' ELSE courier_status END
  WHERE id = target_user_id;

  IF new_profile_type = 'courier' THEN
    INSERT INTO public.courier_profiles (user_id, status, active_capacity, balance)
    VALUES (target_user_id, 'active', 1, 0)
    ON CONFLICT (user_id) DO UPDATE
      SET status = 'active';
  END IF;
END;
$$;

GRANT EXECUTE ON FUNCTION public.admin_update_user_role(uuid, text) TO authenticated;

-- Backfill: fix existing courier/vendor accounts whose active_role is stale
UPDATE public.profiles
SET active_role = 'courier'
WHERE profile_type = 'courier'
  AND (active_role IS NULL OR active_role NOT IN ('courier', 'livreur'));

UPDATE public.profiles
SET active_role = 'vendor'
WHERE profile_type = 'vendor'
  AND (active_role IS NULL OR active_role = 'customer');
