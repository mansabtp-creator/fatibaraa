-- Ensure all baseline dependencies exist for seller_stats view
CREATE TABLE IF NOT EXISTS public.stores (id uuid PRIMARY KEY DEFAULT gen_random_uuid());
CREATE TABLE IF NOT EXISTS public.products (id uuid PRIMARY KEY DEFAULT gen_random_uuid());
CREATE TABLE IF NOT EXISTS public.orders (id uuid PRIMARY KEY DEFAULT gen_random_uuid());

ALTER TABLE public.products ADD COLUMN IF NOT EXISTS store_id uuid REFERENCES public.stores(id) ON DELETE CASCADE;
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS product_id uuid REFERENCES public.products(id) ON DELETE CASCADE;
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS extracted_response_time numeric;
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS status text;
CREATE TABLE IF NOT EXISTS public.profiles (id uuid PRIMARY KEY DEFAULT gen_random_uuid(), is_pro_member boolean DEFAULT false, courier_status text);
CREATE TABLE IF NOT EXISTS public.stores (id uuid PRIMARY KEY DEFAULT gen_random_uuid(), owner_id uuid);
CREATE TABLE IF NOT EXISTS public.products (id uuid PRIMARY KEY DEFAULT gen_random_uuid(), store_id uuid REFERENCES public.stores(id) ON DELETE CASCADE);
CREATE TABLE IF NOT EXISTS public.orders (id uuid PRIMARY KEY DEFAULT gen_random_uuid(), product_id uuid REFERENCES public.products(id) ON DELETE CASCADE, status text, extracted_response_time numeric, courier_id uuid, vendor_id uuid);
ALTER TABLE public.stores ADD COLUMN IF NOT EXISTS owner_id uuid;
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS vendor_id uuid;
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS courier_id uuid;
CREATE TABLE IF NOT EXISTS public.profiles (id uuid PRIMARY KEY DEFAULT gen_random_uuid(), is_pro_member boolean DEFAULT false, courier_status text);
CREATE TABLE IF NOT EXISTS public.stores (id uuid PRIMARY KEY DEFAULT gen_random_uuid());
CREATE TABLE IF NOT EXISTS public.products (id uuid PRIMARY KEY DEFAULT gen_random_uuid(), store_id uuid REFERENCES public.stores(id) ON DELETE CASCADE);
CREATE TABLE IF NOT EXISTS public.orders (id uuid PRIMARY KEY DEFAULT gen_random_uuid(), product_id uuid REFERENCES public.products(id) ON DELETE CASCADE, status text, extracted_response_time numeric, courier_id uuid);
CREATE TABLE IF NOT EXISTS public.orders (id uuid PRIMARY KEY DEFAULT gen_random_uuid());
CREATE TABLE IF NOT EXISTS public.orders (id uuid PRIMARY KEY DEFAULT gen_random_uuid());
CREATE TABLE IF NOT EXISTS public.stores (id uuid PRIMARY KEY DEFAULT gen_random_uuid());

CREATE TABLE IF NOT EXISTS public.products (id uuid PRIMARY KEY DEFAULT gen_random_uuid(), store_id uuid REFERENCES public.stores(id) ON DELETE CASCADE);
CREATE TABLE IF NOT EXISTS public.orders (id uuid PRIMARY KEY DEFAULT gen_random_uuid(), product_id uuid REFERENCES public.products(id) ON DELETE CASCADE, status text, extracted_response_time numeric);

CREATE TABLE IF NOT EXISTS public.profiles (id uuid PRIMARY KEY DEFAULT gen_random_uuid(), is_pro_member boolean DEFAULT false);
CREATE TABLE IF NOT EXISTS public.stores (id uuid PRIMARY KEY DEFAULT gen_random_uuid());

-- =================================================================================
-- FATIBARA SELLER METRICS & TRUST SYSTEM
-- =================================================================================

-- 1. STORE FOLLOWERS (For Feature #23)
-- Moves the "Follow" feature from local storage to the database for cross-device sync.
CREATE TABLE IF NOT EXISTS public.store_follows (
  id uuid primary key default gen_random_uuid(),
  follower_id uuid references public.profiles(id) on delete cascade,
  store_id uuid references public.stores(id) on delete cascade,
  created_at timestamp with time zone default now(),
  unique(follower_id, store_id)
);

-- 2. PRODUCT VERIFICATION LOG
-- Tracks who verified the "Original Garanti" status for high-ticket items.
CREATE TABLE IF NOT EXISTS public.product_verifications (
  id uuid primary key default gen_random_uuid(),
  product_id uuid references public.products(id),
  verified_by uuid references public.profiles(id),
  verification_date timestamp with time zone default now(),
  notes text
);

-- 3. SELLER PERFORMANCE METRICS
-- This view helps calculate "Répond généralement en X min" and total sales.
-- NOTE: This requires your `orders` table to exist and have `status`, `product_id`, and `extracted_response_time` columns.
CREATE OR REPLACE VIEW public.seller_stats AS
SELECT 
  p.store_id,
  count(o.id) filter (where o.status = 'completed') as total_sales,
  avg(o.extracted_response_time) as avg_response_time
FROM public.orders o
JOIN public.products p ON o.product_id = p.id
GROUP BY p.store_id;
