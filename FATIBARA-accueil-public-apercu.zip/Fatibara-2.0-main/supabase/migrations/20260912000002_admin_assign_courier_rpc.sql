-- Migration: admin_assign_courier_to_order
-- Fixes A-BUG-1: the admin dashboard's assignCourier() was doing a raw
-- orders.update() that set courier_id + status='in_transit' without ever
-- creating a deliveries row. This caused complete_courier_delivery RPC to
-- fail (it queries deliveries by order_id) and broke payout settlement.
--
-- This SECURITY DEFINER RPC atomically:
--   1. Validates admin privilege
--   2. Validates courier exists and is available
--   3. Updates orders.courier_id + status
--   4. Upserts a deliveries row (status='assigned') so the completion RPC can
--      find it later

CREATE OR REPLACE FUNCTION admin_assign_courier_to_order(
  p_order_id   UUID,
  p_courier_id UUID
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_caller_is_admin BOOLEAN;
  v_order           orders%ROWTYPE;
  v_courier         profiles%ROWTYPE;
BEGIN
  -- 1. Verify caller is admin
  SELECT is_admin INTO v_caller_is_admin
  FROM profiles
  WHERE id = auth.uid();

  IF NOT v_caller_is_admin THEN
    RETURN jsonb_build_object('success', false, 'error', 'Unauthorized: admin only');
  END IF;

  -- 2. Fetch order and validate it is in an assignable state
  SELECT * INTO v_order FROM orders WHERE id = p_order_id;

  IF NOT FOUND THEN
    RETURN jsonb_build_object('success', false, 'error', 'Order not found');
  END IF;

  IF v_order.status NOT IN ('preparing', 'ready_for_pickup', 'accepted', 'paid', 'confirmed') THEN
    RETURN jsonb_build_object(
      'success', false,
      'error', 'Order status (' || v_order.status || ') does not allow courier assignment'
    );
  END IF;

  -- 3. Validate the courier exists
  SELECT * INTO v_courier FROM profiles WHERE id = p_courier_id;

  IF NOT FOUND THEN
    RETURN jsonb_build_object('success', false, 'error', 'Courier not found');
  END IF;

  -- 4. Assign the courier and advance the order status atomically
  UPDATE orders
  SET
    courier_id = p_courier_id,
    status     = 'in_transit',
    updated_at = NOW()
  WHERE id = p_order_id;

  -- 5. Upsert a deliveries row so complete_courier_delivery can find it.
  --    ON CONFLICT handles the case where a delivery row already exists
  --    (e.g. from a previous failed assignment attempt).
  INSERT INTO deliveries (order_id, courier_id, status, created_at, updated_at)
  VALUES (p_order_id, p_courier_id, 'assigned', NOW(), NOW())
  ON CONFLICT (order_id) DO UPDATE
    SET courier_id = EXCLUDED.courier_id,
        status     = 'assigned',
        updated_at = NOW();

  RETURN jsonb_build_object('success', true);
END;
$$;

-- Add UNIQUE constraint on deliveries.order_id if not already present
-- (needed for the ON CONFLICT above to work)
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint
    WHERE conname = 'deliveries_order_id_key'
  ) THEN
    ALTER TABLE deliveries ADD CONSTRAINT deliveries_order_id_key UNIQUE (order_id);
  END IF;
END $$;

GRANT EXECUTE ON FUNCTION admin_assign_courier_to_order(UUID, UUID) TO authenticated;
