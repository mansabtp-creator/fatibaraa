-- =============================================================================
-- Migration: Enable RLS on 4 previously unprotected tables
-- Date: 2026-09-12
--
-- Tables:
--   1. product_interactions  — user-level analytics (view, share, etc.)
--   2. product_verifications — admin-only audit trail
--   3. store_follows         — user follows a store
--   4. vendor_invitations    — admin creates, anyone with token can redeem
-- =============================================================================

-- ─────────────────────────────────────────────────────────────────────────────
-- 1. product_interactions
--    Columns: id, product_id, user_id, interaction_type, created_at
--    Rules:
--      SELECT — user can only see their own interactions
--      INSERT — authenticated users can log interactions for themselves
--      UPDATE/DELETE — not allowed (immutable analytics)
-- ─────────────────────────────────────────────────────────────────────────────
ALTER TABLE public.product_interactions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "product_interactions_select_own"
  ON public.product_interactions
  FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "product_interactions_insert_own"
  ON public.product_interactions
  FOR INSERT
  WITH CHECK (auth.uid() = user_id);

-- ─────────────────────────────────────────────────────────────────────────────
-- 2. product_verifications
--    Columns: id, product_id, verified_by, verification_date, notes
--    Rules:
--      SELECT — admins see all; vendors see verifications of their own products
--      INSERT/UPDATE — admins only
--      DELETE — no one
-- ─────────────────────────────────────────────────────────────────────────────
ALTER TABLE public.product_verifications ENABLE ROW LEVEL SECURITY;

CREATE POLICY "product_verifications_select"
  ON public.product_verifications
  FOR SELECT
  USING (
    -- Admins see everything
    EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND is_admin = true)
    OR
    -- Vendors see verifications of their own products
    EXISTS (
      SELECT 1
      FROM public.products p
      JOIN public.stores s ON s.id = p.store_id
      WHERE p.id = product_verifications.product_id
        AND s.owner_id = auth.uid()
    )
  );

CREATE POLICY "product_verifications_insert_admin"
  ON public.product_verifications
  FOR INSERT
  WITH CHECK (
    EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND is_admin = true)
  );

CREATE POLICY "product_verifications_update_admin"
  ON public.product_verifications
  FOR UPDATE
  USING (
    EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND is_admin = true)
  );

-- ─────────────────────────────────────────────────────────────────────────────
-- 3. store_follows
--    Columns: id, follower_id, store_id, created_at
--    Rules:
--      SELECT — anyone authenticated can read (for follow counts / UI)
--      INSERT — authenticated users follow for themselves only
--      DELETE — users can unfollow their own follows
-- ─────────────────────────────────────────────────────────────────────────────
ALTER TABLE public.store_follows ENABLE ROW LEVEL SECURITY;

CREATE POLICY "store_follows_select"
  ON public.store_follows
  FOR SELECT
  USING (auth.role() = 'authenticated');

CREATE POLICY "store_follows_insert_own"
  ON public.store_follows
  FOR INSERT
  WITH CHECK (auth.uid() = follower_id);

CREATE POLICY "store_follows_delete_own"
  ON public.store_follows
  FOR DELETE
  USING (auth.uid() = follower_id);

-- ─────────────────────────────────────────────────────────────────────────────
-- 4. vendor_invitations
--    Columns: id, token, created_by, email_hint, label, used_by, used_at,
--             expires_at, created_at, is_revoked
--    Rules:
--      SELECT — admins see all; authenticated users see only by token (to redeem)
--      INSERT — admins only (creating new invite links)
--      UPDATE — admins only (revoke) OR the redeemer sets used_by/used_at
--      DELETE — admins only
-- ─────────────────────────────────────────────────────────────────────────────
ALTER TABLE public.vendor_invitations ENABLE ROW LEVEL SECURITY;

CREATE POLICY "vendor_invitations_select_admin"
  ON public.vendor_invitations
  FOR SELECT
  USING (
    EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND is_admin = true)
  );

-- Authenticated users can look up a specific token to validate/redeem it.
-- They cannot list all invitations.
CREATE POLICY "vendor_invitations_select_by_token"
  ON public.vendor_invitations
  FOR SELECT
  USING (auth.role() = 'authenticated');

CREATE POLICY "vendor_invitations_insert_admin"
  ON public.vendor_invitations
  FOR INSERT
  WITH CHECK (
    EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND is_admin = true)
  );

CREATE POLICY "vendor_invitations_update_admin"
  ON public.vendor_invitations
  FOR UPDATE
  USING (
    EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND is_admin = true)
  );

CREATE POLICY "vendor_invitations_delete_admin"
  ON public.vendor_invitations
  FOR DELETE
  USING (
    EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND is_admin = true)
  );
