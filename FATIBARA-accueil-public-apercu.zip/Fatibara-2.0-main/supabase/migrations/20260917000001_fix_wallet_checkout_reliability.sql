-- ==============================================================================
-- Migration: 20260917000001_fix_wallet_checkout_reliability.sql
-- Created:   2026-09-17
--
-- Fixes two remaining failure modes in the wallet checkout path:
--
--   [W1] platform_logs INSERT failure aborts the entire wallet transaction.
--        If platform_logs has schema drift (missing column, wrong type) or the
--        table simply doesn't exist, the buyer's payment rolls back silently and
--        the frontend shows a cryptic error. Commission logging must NEVER block
--        a successful payment.
--
--   [W2] cod_courier_insufficient_balance raises an EXCEPTION inside
--        process_wallet_checkout even for wallet-payment orders. The courier
--        COD balance check is only meaningful for cash-on-delivery — it should
--        never abort a buyer's digital wallet payment.
--
--   [W3] Also ensures platform_logs table exists so W1 doesn't need the guard
--        permanently (belt + suspenders approach).
-- ==============================================================================


-- ==============================================================================
-- [W3] Ensure platform_logs table exists
-- ==============================================================================
CREATE TABLE IF NOT EXISTS public.platform_logs (
    id           UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
    type         TEXT        NOT NULL,
    amount       NUMERIC     NOT NULL DEFAULT 0,
    reference_id UUID,
    metadata     JSONB       DEFAULT '{}'::jsonb,
    created_at   TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Grant read to service_role for admin reporting
GRANT SELECT, INSERT ON public.platform_logs TO service_role;
GRANT SELECT ON public.platform_logs TO authenticated;

DO $$ BEGIN RAISE NOTICE '[W3] platform_logs: table created or already exists'; END $$;


-- ==============================================================================
-- [W1 + W2] Harden secure_process_order_financials
-- ==============================================================================
CREATE OR REPLACE FUNCTION public.secure_process_order_financials(p_order_id uuid)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
    v_order                        RECORD;
    v_store                        RECORD;
    v_existing_tx                  BOOLEAN;
    v_commission_str               TEXT;
    v_commission_rate              NUMERIC;
    v_items_real_value             NUMERIC;
    v_item_subtotal                NUMERIC;
    v_platform_commission          NUMERIC;
    v_vendor_payout                NUMERIC;
    v_courier_payout               NUMERIC;
    v_is_cash_payment              BOOLEAN;
    v_final_vendor_digital_change  NUMERIC;
    v_final_courier_digital_change NUMERIC;
    v_courier_balance              NUMERIC;
    v_vendor_description           TEXT;
BEGIN
    -- ── A. Lock order row ────────────────────────────────────────────────────
    SELECT * INTO v_order FROM public.orders WHERE id = p_order_id FOR UPDATE;
    IF NOT FOUND THEN RAISE EXCEPTION 'Order not found: %', p_order_id; END IF;

    -- ── B. Idempotency guard ─────────────────────────────────────────────────
    IF v_order.financial_status = 'processed' THEN
        RETURN jsonb_build_object('success', true, 'alreadyProcessed', true);
    END IF;

    SELECT EXISTS (
        SELECT 1 FROM public.wallet_transactions
        WHERE reference_id = p_order_id::TEXT AND type = 'sale'
    ) INTO v_existing_tx;

    IF v_existing_tx THEN
        UPDATE public.orders SET financial_status = 'processed' WHERE id = p_order_id;
        RETURN jsonb_build_object('success', true, 'alreadyProcessed', true);
    END IF;

    -- ── C. Resolve store ─────────────────────────────────────────────────────
    IF v_order.store_id IS NOT NULL THEN
        SELECT * INTO v_store FROM public.stores WHERE id = v_order.store_id;
    ELSIF v_order.vendor_id IS NOT NULL THEN
        SELECT * INTO v_store FROM public.stores WHERE owner_id = v_order.vendor_id LIMIT 1;
    END IF;

    -- ── D. Commission arithmetic ─────────────────────────────────────────────
    v_items_real_value := COALESCE(v_order.total_amount, 0) - COALESCE(v_order.delivery_fee, 0);

    SELECT value INTO v_commission_str FROM public.platform_settings WHERE id = 'commission_rate';
    IF v_commission_str IS NULL THEN v_commission_str := '5'; END IF;
    v_commission_rate := v_commission_str::numeric / 100.0;

    v_item_subtotal       := v_items_real_value / (1 + v_commission_rate);
    v_platform_commission := v_item_subtotal * v_commission_rate;
    v_vendor_payout       := v_item_subtotal - COALESCE(v_order.vendor_delivery_fee, 0);
    v_courier_payout      := (CASE WHEN COALESCE(v_order.delivery_fee, 0) > 0
                                   THEN v_order.delivery_fee
                                   ELSE COALESCE(v_order.vendor_delivery_fee, 0) END) * 0.8;

    IF v_order.courier_id IS NULL THEN
        v_vendor_payout := v_vendor_payout + v_courier_payout;
    END IF;

    v_is_cash_payment := COALESCE(
        (v_order.shipping_address->>'payment_method') = 'cash',
        v_order.financial_status != 'paid'
    );

    -- ── E. Vendor payout ─────────────────────────────────────────────────────
    IF v_store.id IS NOT NULL AND v_order.vendor_id IS NOT NULL THEN
        v_final_vendor_digital_change := v_vendor_payout;

        IF v_is_cash_payment AND v_order.courier_id IS NULL THEN
            v_final_vendor_digital_change := v_vendor_payout - v_order.total_amount;
        END IF;

        IF v_final_vendor_digital_change != 0 THEN
            UPDATE public.stores
            SET balance = COALESCE(balance, 0) + ROUND(v_final_vendor_digital_change)
            WHERE id = v_store.id;

            IF v_is_cash_payment AND v_order.courier_id IS NULL THEN
                v_vendor_description :=
                    'Collecte Cash directe — Retenue commission Commande #'
                    || left(v_order.id::text, 8);
            ELSIF v_is_cash_payment AND v_order.courier_id IS NOT NULL THEN
                v_vendor_description :=
                    'Vente Cash à la livraison (Commande #'
                    || left(v_order.id::text, 8) || ')';
            ELSE
                v_vendor_description :=
                    'Vente #' || left(v_order.id::text, 8)
                    || ' (Payout ' || ROUND(v_item_subtotal) || ')';
            END IF;

            INSERT INTO public.wallet_transactions
              (profile_id, store_id, amount, type, reference_id, description)
            VALUES (
                v_order.vendor_id,
                v_store.id,
                v_final_vendor_digital_change,
                CASE WHEN v_final_vendor_digital_change > 0 THEN 'sale' ELSE 'fee' END,
                v_order.id::TEXT,
                v_vendor_description
            );
        END IF;
    END IF;

    -- ── F. Courier payout — with COD negative-balance guard ──────────────────
    -- [W2 FIX]: The COD balance guard only applies to cash-on-delivery orders.
    -- For wallet/mobile payments, couriers receive a credit (positive change) or
    -- the order has no courier yet — the balance check is irrelevant and must
    -- NOT abort the buyer's transaction.
    IF v_order.courier_id IS NOT NULL THEN
        v_final_courier_digital_change := v_courier_payout;
        IF v_is_cash_payment THEN
            v_final_courier_digital_change := v_courier_payout - v_order.total_amount;
        END IF;

        IF v_final_courier_digital_change != 0 THEN
            -- [W2 FIX]: Only block if this is a cash order AND the courier would go negative.
            -- For wallet orders: v_is_cash_payment is false → this block is skipped entirely.
            IF v_is_cash_payment AND v_final_courier_digital_change < 0 THEN
                SELECT wallet_balance INTO v_courier_balance
                FROM public.profiles
                WHERE id = v_order.courier_id
                FOR UPDATE;

                IF v_courier_balance + v_final_courier_digital_change < 0 THEN
                    -- Soft failure: return without rolling back so admin can manually settle
                    RAISE WARNING '[secure_process_order_financials] COD courier balance too low for order %. Balance=%, Required=%',
                        p_order_id, ROUND(v_courier_balance), ROUND(abs(v_final_courier_digital_change));

                    RETURN jsonb_build_object(
                        'success',        false,
                        'error',          'cod_courier_insufficient_balance',
                        'message',        format(
                            'Courier wallet too low for COD settlement. Balance: %s GNF, Required: %s GNF.',
                            ROUND(v_courier_balance),
                            ROUND(abs(v_final_courier_digital_change))
                        ),
                        'courierBalance', ROUND(v_courier_balance),
                        'debtAmount',     ROUND(abs(v_final_courier_digital_change))
                    );
                END IF;
            END IF;

            -- Credit / debit the courier
            UPDATE public.profiles
            SET wallet_balance = wallet_balance + ROUND(v_final_courier_digital_change),
                updated_at     = NOW()
            WHERE id = v_order.courier_id;

            UPDATE public.courier_profiles
            SET balance    = COALESCE(balance, 0) + ROUND(v_final_courier_digital_change),
                updated_at = NOW()
            WHERE user_id = v_order.courier_id;

            INSERT INTO public.wallet_transactions
              (profile_id, amount, type, reference_id, description)
            VALUES (
                v_order.courier_id,
                v_final_courier_digital_change,
                CASE WHEN v_final_courier_digital_change > 0 THEN 'delivery_fee' ELSE 'fee' END,
                v_order.id::TEXT,
                CASE WHEN v_is_cash_payment
                     THEN 'Collecte Cash — Remise Plateforme Commande #'
                          || left(v_order.id::text, 8)
                     ELSE 'Course effectuée — Commande #'
                          || left(v_order.id::text, 8)
                END
            );
        END IF;
    END IF;

    -- ── G. Platform commission log ────────────────────────────────────────────
    -- [W1 FIX]: Wrapped in BEGIN/EXCEPTION so a schema drift or missing table
    -- on platform_logs NEVER aborts the buyer's payment. The commission is
    -- an internal audit log — it must not block financial transactions.
    BEGIN
        INSERT INTO public.platform_logs (type, amount, reference_id, metadata)
        VALUES (
            'commission',
            ROUND(v_platform_commission),
            v_order.id,
            jsonb_build_object(
                'order_total',  v_order.total_amount,
                'vendor_id',    v_order.vendor_id,
                'is_cash',      v_is_cash_payment
            )
        );
    EXCEPTION WHEN OTHERS THEN
        -- Log a warning but do NOT re-raise — commission logging must never
        -- block a successful payment.
        RAISE WARNING '[secure_process_order_financials] platform_logs INSERT failed for order %: % (state=%)',
            p_order_id, SQLERRM, SQLSTATE;
    END;

    -- ── H. Mark order as financially settled ──────────────────────────────────
    UPDATE public.orders SET financial_status = 'processed' WHERE id = p_order_id;

    RETURN jsonb_build_object(
        'success',            true,
        'vendorPayout',       ROUND(v_vendor_payout),
        'courierPayout',      ROUND(v_courier_payout),
        'platformCommission', ROUND(v_platform_commission)
    );

EXCEPTION
    WHEN OTHERS THEN
        RAISE WARNING '[secure_process_order_financials] order=% error=% detail=%',
            p_order_id, SQLERRM, SQLSTATE;
        RAISE;
END;
$$;

GRANT EXECUTE ON FUNCTION public.secure_process_order_financials(uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION public.secure_process_order_financials(uuid) TO service_role;

DO $$ BEGIN RAISE NOTICE '[W1+W2] secure_process_order_financials: platform_logs guarded, COD courier check isolated to cash orders only'; END $$;


-- ==============================================================================
-- [W2 cont.] Update process_wallet_checkout to handle cod_courier_insufficient_balance
-- gracefully — log a warning and continue rather than raising an exception.
-- ==============================================================================
CREATE OR REPLACE FUNCTION public.process_wallet_checkout(
  p_user_id       UUID,
  p_total_amount  NUMERIC,
  p_orders        JSONB,
  p_deliveries    JSONB,
  p_order_items   JSONB
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_current_balance  NUMERIC;
  v_result           JSONB  := '[]'::jsonb;
  v_order_data       JSONB;
  v_item_data        JSONB;
  v_delivery_data    JSONB;
  v_order_index      INT;
  v_new_order_id     UUID;
  v_financial_result JSONB;
BEGIN
  -- ── 1. Lock profile row and verify balance ──────────────────────────────────
  SELECT wallet_balance
  INTO   v_current_balance
  FROM   public.profiles
  WHERE  id = p_user_id
  FOR UPDATE;

  IF NOT FOUND THEN
    RAISE EXCEPTION 'Profil introuvable. Veuillez vous reconnecter.';
  END IF;

  IF v_current_balance < p_total_amount THEN
    RAISE EXCEPTION 'Solde insuffisant. Disponible: % GNF, Requis: % GNF.',
                    ROUND(v_current_balance), ROUND(p_total_amount);
  END IF;

  -- ── 2. Deduct buyer wallet balance ──────────────────────────────────────────
  UPDATE public.profiles
  SET    wallet_balance = wallet_balance - p_total_amount
  WHERE  id = p_user_id;

  -- Log the debit transaction for the buyer
  INSERT INTO public.wallet_transactions (
    profile_id, amount, type, description, status
  ) VALUES (
    p_user_id,
    -p_total_amount,
    'purchase',
    'Paiement Portefeuille — ' || jsonb_array_length(p_orders) || ' commande(s)',
    'completed'
  );

  -- ── 3. Create orders, deliveries, and order items ───────────────────────────
  FOR v_order_index IN 0 .. jsonb_array_length(p_orders) - 1 LOOP
    v_order_data := p_orders -> v_order_index;

    INSERT INTO public.orders (
      user_id,
      store_id,
      vendor_id,
      customer_name,
      items_count,
      total_amount,
      delivery_fee,
      vendor_delivery_fee,
      status,
      financial_status,
      tracking_number,
      delivery_otp,
      shipping_address
    ) VALUES (
      p_user_id,
      NULLIF((v_order_data->>'store_id'),  '')::UUID,
      NULLIF((v_order_data->>'vendor_id'), '')::UUID,
      v_order_data->>'customer_name',
      (v_order_data->>'items_count')::INT,
      (v_order_data->>'total_amount')::NUMERIC,
      COALESCE((v_order_data->>'delivery_fee')::NUMERIC, 0),
      COALESCE((v_order_data->'shipping_address'->>'vendor_delivery_fee')::NUMERIC, 0),
      'paid',
      'paid',
      v_order_data->>'tracking_number',
      v_order_data->>'delivery_otp',
      v_order_data->'shipping_address'
    )
    RETURNING id INTO v_new_order_id;

    -- Accumulate result
    v_result := v_result || jsonb_build_object(
      'id',              v_new_order_id,
      'tracking_number', v_order_data->>'tracking_number'
    );

    -- ── 3a. Insert delivery record ───────────────────────────────────────────
    IF p_deliveries IS NOT NULL
       AND jsonb_array_length(p_deliveries) > v_order_index
    THEN
      v_delivery_data := p_deliveries -> v_order_index;
      IF v_delivery_data IS NOT NULL
         AND jsonb_typeof(v_delivery_data) = 'object'
      THEN
        INSERT INTO public.deliveries (
          order_id, status, current_location
        ) VALUES (
          v_new_order_id,
          COALESCE(v_delivery_data->>'status', 'pending'),
          v_delivery_data->'current_location'
        );
      END IF;
    END IF;

    -- ── 3b. Insert order items ───────────────────────────────────────────────
    IF p_order_items IS NOT NULL
       AND jsonb_array_length(p_order_items) > v_order_index
    THEN
      FOR v_item_data IN
        SELECT * FROM jsonb_array_elements(p_order_items -> v_order_index)
      LOOP
        INSERT INTO public.order_items (
          order_id,
          product_id,
          quantity,
          price_at_purchase,
          selected_variations
        ) VALUES (
          v_new_order_id,
          (v_item_data->>'product_id')::UUID,
          (v_item_data->>'quantity')::INT,
          (v_item_data->>'price_at_purchase')::NUMERIC,
          COALESCE(v_item_data->'selected_variations', '{}'::jsonb)
        );
      END LOOP;
    END IF;

    -- ── 4. Distribute vendor/courier/platform financials ──────────────────────
    -- [W2 FIX]: cod_courier_insufficient_balance is a warning for wallet orders,
    -- not a hard failure. The buyer has already paid — we log and continue.
    SELECT public.secure_process_order_financials(v_new_order_id)
    INTO   v_financial_result;

    IF NOT COALESCE((v_financial_result->>'success')::boolean, false) THEN
      IF v_financial_result->>'error' = 'cod_courier_insufficient_balance' THEN
        -- This is a COD courier settlement issue unrelated to the buyer's wallet payment.
        -- Log it for admin review but do NOT abort the transaction.
        RAISE WARNING '[process_wallet_checkout] COD courier balance warning on wallet order %: %',
            v_new_order_id, v_financial_result->>'message';
      ELSE
        -- All other financial errors are hard failures — rollback everything.
        RAISE EXCEPTION 'Erreur de traitement financier pour la commande %: %',
                        v_new_order_id,
                        COALESCE(v_financial_result->>'message', v_financial_result->>'error', 'Erreur inconnue');
      END IF;
    END IF;

  END LOOP;

  RETURN v_result;

EXCEPTION
  WHEN OTHERS THEN
    RAISE;
END;
$$;

GRANT EXECUTE ON FUNCTION public.process_wallet_checkout(UUID, NUMERIC, JSONB, JSONB, JSONB)
  TO authenticated;

DO $$ BEGIN RAISE NOTICE '[W2] process_wallet_checkout: cod_courier_insufficient_balance no longer aborts wallet payments'; END $$;

NOTIFY pgrst, 'reload schema';
