-- =============================================================================
-- Migration: Fix Wallet Runtime Bugs
-- File:      20260820000001_fix_wallet_bugs.sql
-- Created:   2026-08-20
--
-- ISSUES FIXED:
--
--   1. [HIGH] approve_withdrawal RPC references v_withdrawal.phone_number
--      but the withdrawals table column is named `phone`. This causes a
--      Postgres runtime error whenever an admin approves a withdrawal.
--      Fix: Drop and recreate the function using the correct column name.
--      Also adds processed_at timestamp (was missing from the wallet_ledger_fix
--      version) and uses JSONB return type consistently.
--
--   2. [MEDIUM] wallet_transactions.status CHECK constraint does not include
--      'cancelled'. The frontend Realtime listener (TransactionalWallet.tsx)
--      checks for status === 'cancelled' to close the USSD modal on failure.
--      Without this value in the enum the DB would reject any UPDATE that sets
--      status='cancelled', causing the Realtime event to never fire.
--      Fix: Drop and recreate the constraint including 'cancelled'.
-- =============================================================================

-- =============================================================================
-- FIX 1: approve_withdrawal — correct phone column reference
-- =============================================================================

DROP FUNCTION IF EXISTS public.approve_withdrawal(UUID);

CREATE OR REPLACE FUNCTION public.approve_withdrawal(p_withdrawal_id UUID)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
    v_withdrawal RECORD;
BEGIN
    -- Admin-only guard
    IF NOT EXISTS (
        SELECT 1 FROM public.profiles
        WHERE id = auth.uid() AND is_admin = true
    ) THEN
        RAISE EXCEPTION 'Unauthorized: Admin access required.';
    END IF;

    -- Lock the withdrawal row to prevent concurrent approvals
    SELECT * INTO v_withdrawal
    FROM public.withdrawals
    WHERE id = p_withdrawal_id
    FOR UPDATE;

    IF NOT FOUND THEN
        RETURN jsonb_build_object(
            'success', false,
            'message', 'Withdrawal request not found.'
        );
    END IF;

    -- Idempotency: already processed or rejected — return success silently
    IF v_withdrawal.status != 'pending' THEN
        RETURN jsonb_build_object(
            'success',          true,
            'alreadyProcessed', true,
            'status',           v_withdrawal.status
        );
    END IF;

    -- Mark as processed (balance was already deducted at request time)
    UPDATE public.withdrawals
    SET
        status       = 'processed',
        processed_at = NOW(),
        processed_by = auth.uid()
    WHERE id = p_withdrawal_id;

    -- Audit trail: zero-amount marker row (balance deduction already recorded at request time)
    INSERT INTO public.wallet_transactions (
        store_id, profile_id, amount, type, reference_id, description, status
    ) VALUES (
        v_withdrawal.store_id,
        v_withdrawal.profile_id,
        0,  -- Zero: funds already deducted when withdrawal was requested
        'withdrawal_approved',
        v_withdrawal.id,
        -- Fixed: use correct column name `phone` (not `phone_number`)
        'Retrait approuvé par admin — ' || COALESCE(v_withdrawal.method, '') ||
        ' (' || COALESCE(v_withdrawal.phone, '') || ')',
        'completed'
    );

    RETURN jsonb_build_object('success', true, 'message', 'Withdrawal approved successfully.');

EXCEPTION WHEN OTHERS THEN
    RETURN jsonb_build_object('success', false, 'message', SQLERRM);
END;
$$;

GRANT EXECUTE ON FUNCTION public.approve_withdrawal(UUID) TO authenticated;

COMMENT ON FUNCTION public.approve_withdrawal(UUID) IS
  'Admin-only: marks a withdrawal as processed. Balance was already deducted at request time.
   Inserts a zero-amount audit trail row into wallet_transactions.
   Returns JSONB { success, message?, alreadyProcessed?, status? }.';

-- =============================================================================
-- FIX 2: wallet_transactions status enum — add ''cancelled''
-- =============================================================================
-- The TransactionalWallet.tsx Realtime listener handles status === ''cancelled''
-- to close the USSD modal. Without this value in the CHECK constraint, any DB
-- UPDATE setting status=''cancelled'' would be rejected by Postgres, causing
-- the Realtime event to never fire and the modal to stall until timeout.

-- Drop the existing constraint (name may vary across migration runs)
ALTER TABLE public.wallet_transactions
  DROP CONSTRAINT IF EXISTS wallet_transactions_status_check;

-- Recreate with 'cancelled' included
ALTER TABLE public.wallet_transactions
  ADD CONSTRAINT wallet_transactions_status_check
  CHECK (status IN ('pending', 'completed', 'failed', 'cancelled', 'reversed'));

-- =============================================================================
-- RELOAD POSTGREST SCHEMA CACHE
-- =============================================================================
NOTIFY pgrst, 'reload schema';
