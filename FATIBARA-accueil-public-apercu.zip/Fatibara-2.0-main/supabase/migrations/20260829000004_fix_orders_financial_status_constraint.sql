-- ==============================================================================
-- MIGRATION: 20260829000004_fix_orders_financial_status_constraint.sql
--
-- Problem: process_wallet_checkout → 400 "orders_financial_status_check"
--
-- The live (remote) production database has a more restrictive version of the
-- orders_financial_status_check constraint that does NOT include 'paid' as a
-- valid value.  This happened because the foundation_schema migration was
-- applied BEFORE the financial_status column semantics were finalized, and a
-- later migration may have inadvertently replaced or tightened the constraint.
--
-- The npx supabase db query tool connects to the LOCAL shadow database and
-- confirmed the LOCAL version is correct.  However the REMOTE production DB
-- still has the old constraint because `supabase db push` only runs NEW
-- migrations — it does not re-run the foundation schema.
--
-- Fix: unconditionally DROP + ADD the constraint with the definitive allowed
-- value set that matches every code path in the application.
-- ==============================================================================

-- Step 1: Remove whichever version of the constraint is currently on the table
ALTER TABLE public.orders
  DROP CONSTRAINT IF EXISTS orders_financial_status_check;

-- Step 2: Re-add with the complete, authoritative value set
ALTER TABLE public.orders
  ADD CONSTRAINT orders_financial_status_check
  CHECK (financial_status IN (
    'pending',    -- Order created, awaiting payment confirmation
    'paid',       -- Payment received (wallet, mobile money)
    'processed',  -- Vendor/courier payouts distributed (settled)
    'failed',     -- Payment attempted but failed
    'refunded'    -- Buyer was refunded (cancellation / dispute)
  ));

-- Notify PostgREST to reload its schema cache
NOTIFY pgrst, 'reload schema';
