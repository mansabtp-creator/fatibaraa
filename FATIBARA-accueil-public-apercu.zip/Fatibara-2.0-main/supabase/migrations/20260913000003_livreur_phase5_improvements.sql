-- Migration: Livreur dashboard improvements Phase 5
-- Adds pickup_started_at + courier weekly stats RPC

-- ── 5.1: get_courier_weekly_stats RPC ──────────────────────────────────────
-- Replaces two separate JS queries with one server-side call.
-- Returns an array of { day text, amount numeric } for the past 7 days.
CREATE OR REPLACE FUNCTION public.get_courier_weekly_stats(p_courier_id uuid)
RETURNS TABLE(day text, amount numeric)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_start timestamptz := (now() AT TIME ZONE 'Africa/Conakry')::date - interval '6 days';
BEGIN
  RETURN QUERY
  WITH days AS (
    SELECT generate_series(0, 6) AS offset
  ),
  day_series AS (
    SELECT
      (now() AT TIME ZONE 'Africa/Conakry')::date - (6 - d.offset) AS day_date
    FROM days d
  ),
  txs AS (
    SELECT
      (created_at AT TIME ZONE 'Africa/Conakry')::date AS tx_date,
      SUM(amount) AS total
    FROM wallet_transactions
    WHERE profile_id = p_courier_id
      AND type = 'delivery_fee'
      AND created_at >= v_start
    GROUP BY tx_date
  )
  SELECT
    to_char(ds.day_date, 'Dy') AS day,
    COALESCE(t.total, 0)       AS amount
  FROM day_series ds
  LEFT JOIN txs t ON t.tx_date = ds.day_date
  ORDER BY ds.day_date;
END;
$$;

GRANT EXECUTE ON FUNCTION public.get_courier_weekly_stats(uuid) TO authenticated;

-- ── 5.2: pickup_started_at column on orders ─────────────────────────────────
-- Records the exact timestamp when the courier transitions to in_transit.
-- Used for accurate ETA countdown (instead of updated_at which changes often).
ALTER TABLE public.orders
  ADD COLUMN IF NOT EXISTS pickup_started_at timestamptz;

-- Back-fill for existing in_transit/arriving_soon orders
UPDATE public.orders
SET pickup_started_at = updated_at
WHERE pickup_started_at IS NULL
  AND status IN ('in_transit', 'arriving_soon', 'delivered');

-- Trigger: auto-set pickup_started_at when status first transitions to in_transit
CREATE OR REPLACE FUNCTION public.set_pickup_started_at()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
BEGIN
  IF NEW.status = 'in_transit' AND (OLD.status IS DISTINCT FROM 'in_transit') THEN
    NEW.pickup_started_at := now();
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_set_pickup_started_at ON public.orders;
CREATE TRIGGER trg_set_pickup_started_at
  BEFORE UPDATE ON public.orders
  FOR EACH ROW EXECUTE FUNCTION public.set_pickup_started_at();
