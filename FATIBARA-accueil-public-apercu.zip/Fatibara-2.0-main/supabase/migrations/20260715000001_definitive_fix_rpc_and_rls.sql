-- ==============================================================================
-- Migration: Definitive Fix — RPC Column Mismatch + RLS Infinite Recursion
-- Created At: 2026-07-15
-- Authors:    Antigravity / Fatibara Engineering
--
-- ROOT CAUSES ADDRESSED:
--   1. HTTP 400 on get_vendor_dashboard_metrics:
--      The function referenced column "total_price" which does NOT exist.
--      The orders table uses "total_amount". Fixed below with correct column name.
--
--   2. HTTP 500 (42P17 infinite recursion) on PATCH /orders:
--      The 20260712 state-machine migration added two UPDATE policies that were
--      NOT included in the DROP list of the 20260714 flat-RLS migration:
--        • "Couriers can claim orders"      — uses EXISTS(SELECT FROM profiles)
--        • "Vendors can transition order status" — conflicts with flat policy
--      Multiple overlapping UPDATE policies = PostgreSQL evaluates ALL of them
--      simultaneously, causing cross-table policy chain recursion.
--
--      Additionally, the trigger enforce_order_state_machine_constraints() called
--      EXISTS(SELECT FROM profiles WHERE is_admin=true) inside SECURITY DEFINER
--      context — but profiles itself had RLS policies that re-queried orders,
--      completing the recursion loop.
--
-- RESOLUTION:
--   A. Drop ALL remaining policies on orders (belt-and-suspenders exhaustive list)
--   B. Drop the recursive trigger entirely
--   C. Re-create exactly ONE flat UPDATE policy
--   D. Fix and redeploy get_vendor_dashboard_metrics with correct column name
-- ==============================================================================


-- ==============================================================================
-- PART A: OBLITERATE ALL POLICIES ON public.orders
-- (exhaustive list covering every name ever used in any migration)
-- ==============================================================================

-- Generic / auto-generated
DROP POLICY IF EXISTS "Enable read access for all users"              ON public.orders;
DROP POLICY IF EXISTS "Enable insert for authenticated users only"    ON public.orders;
DROP POLICY IF EXISTS "Enable update for users based on email"        ON public.orders;
DROP POLICY IF EXISTS "Enable delete for users based on email"        ON public.orders;

-- State-machine migration (20260712) — these were NOT dropped by 20260714
DROP POLICY IF EXISTS "Couriers can claim orders"                     ON public.orders;
DROP POLICY IF EXISTS "Vendors can transition order status"           ON public.orders;

-- Vendor-scoped
DROP POLICY IF EXISTS "Vendors can view their own orders"             ON public.orders;
DROP POLICY IF EXISTS "Vendors can update their own orders"           ON public.orders;
DROP POLICY IF EXISTS "Vendors can insert orders"                     ON public.orders;

-- Client/buyer-scoped
DROP POLICY IF EXISTS "Clients can view their own orders"             ON public.orders;
DROP POLICY IF EXISTS "Clients can insert their own orders"           ON public.orders;
DROP POLICY IF EXISTS "Users can view their own orders"               ON public.orders;
DROP POLICY IF EXISTS "Users can insert their own orders"             ON public.orders;

-- Courier-scoped
DROP POLICY IF EXISTS "Couriers can view assigned orders"             ON public.orders;
DROP POLICY IF EXISTS "Couriers can update assigned orders"           ON public.orders;

-- Admin/service
DROP POLICY IF EXISTS "Admins can view all orders"                    ON public.orders;
DROP POLICY IF EXISTS "Admins can update all orders"                  ON public.orders;
DROP POLICY IF EXISTS "Service role full access"                      ON public.orders;

-- Slug-named
DROP POLICY IF EXISTS "orders_select_policy"                          ON public.orders;
DROP POLICY IF EXISTS "orders_insert_policy"                          ON public.orders;
DROP POLICY IF EXISTS "orders_update_policy"                          ON public.orders;
DROP POLICY IF EXISTS "orders_delete_policy"                          ON public.orders;

-- Flat slug-named from 20260714
DROP POLICY IF EXISTS "Fatibara flat orders read policy"              ON public.orders;
DROP POLICY IF EXISTS "Fatibara flat orders insert policy"            ON public.orders;
DROP POLICY IF EXISTS "Fatibara flat orders update policy"            ON public.orders;
DROP POLICY IF EXISTS "Fatibara flat orders delete policy"            ON public.orders;


-- ==============================================================================
-- PART B: DROP THE RECURSIVE TRIGGER (source of 42P17 on PATCH)
-- The trigger function called EXISTS(SELECT FROM profiles) inside SECURITY
-- DEFINER context, which triggered profiles RLS → recursion back to orders.
-- ==============================================================================

DROP TRIGGER IF EXISTS trg_enforce_order_state_machine_constraints ON public.orders;
DROP FUNCTION IF EXISTS public.enforce_order_state_machine_constraints();


-- ==============================================================================
-- PART C: ENSURE RLS IS ENABLED + RECREATE FOUR CLEAN FLAT POLICIES
-- Zero subqueries. Zero joins. Zero cross-table references. Zero recursion risk.
-- ==============================================================================

ALTER TABLE public.orders ENABLE ROW LEVEL SECURITY;

-- SELECT: buyer OR vendor OR courier can read their own orders
DROP POLICY IF EXISTS "orders_select_v2" ON public.orders;
CREATE POLICY "orders_select_v2"
ON public.orders
FOR SELECT
TO authenticated
USING (
  auth.uid() = user_id
  OR auth.uid() = vendor_id
  OR auth.uid() = courier_id
);

-- INSERT: buyer inserts their own order
DROP POLICY IF EXISTS "orders_insert_v2" ON public.orders;
CREATE POLICY "orders_insert_v2"
ON public.orders
FOR INSERT
TO authenticated
WITH CHECK (
  auth.uid() = user_id
);

-- UPDATE: vendor OR assigned courier can update (single flat expression — NO subqueries)
--   Couriers who want to claim an order: the app sets courier_id = auth.uid() before
--   calling the PATCH; the RLS check (auth.uid() = vendor_id OR auth.uid() = courier_id)
--   passes because old.courier_id will be NULL and new.courier_id = auth.uid().
--   No need for a separate policy; the OR covers both actors.
DROP POLICY IF EXISTS "orders_update_v2" ON public.orders;
CREATE POLICY "orders_update_v2"
ON public.orders
FOR UPDATE
TO authenticated
USING (
  auth.uid() = vendor_id
  OR auth.uid() = courier_id
)
WITH CHECK (
  auth.uid() = vendor_id
  OR auth.uid() = courier_id
);

-- DELETE: only vendor can delete (soft-delete preferred)
DROP POLICY IF EXISTS "orders_delete_v2" ON public.orders;
CREATE POLICY "orders_delete_v2"
ON public.orders
FOR DELETE
TO authenticated
USING (
  auth.uid() = vendor_id
);

-- Explicit grants
GRANT SELECT, INSERT, UPDATE, DELETE ON public.orders TO authenticated;
GRANT ALL                            ON public.orders TO service_role;
GRANT ALL                            ON public.orders TO postgres;


-- ==============================================================================
-- PART D: FIX get_vendor_dashboard_metrics — use total_amount (not total_price)
-- Confirmed live schema: orders.total_amount is the correct column name.
-- ==============================================================================

DROP FUNCTION IF EXISTS public.get_vendor_dashboard_metrics(UUID);

CREATE OR REPLACE FUNCTION public.get_vendor_dashboard_metrics(p_vendor_id UUID)
RETURNS JSON
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_total_revenue    NUMERIC;
    v_completed_orders INT;
    v_pending_orders   INT;
    v_active_orders    INT;
BEGIN
    -- Total Revenue: orders that have been paid or fully completed.
    -- Uses total_amount (confirmed column name from live schema inspection).
    SELECT COALESCE(SUM(total_amount), 0)
    INTO v_total_revenue
    FROM public.orders
    WHERE vendor_id = p_vendor_id
      AND status IN ('paid', 'completed');

    -- Completed orders
    SELECT COALESCE(COUNT(*), 0)
    INTO v_completed_orders
    FROM public.orders
    WHERE vendor_id = p_vendor_id
      AND status = 'completed';

    -- Pending orders (awaiting payment / approval)
    SELECT COALESCE(COUNT(*), 0)
    INTO v_pending_orders
    FROM public.orders
    WHERE vendor_id = p_vendor_id
      AND status IN ('pending', 'payment_pending');

    -- Active / in-flight orders
    SELECT COALESCE(COUNT(*), 0)
    INTO v_active_orders
    FROM public.orders
    WHERE vendor_id = p_vendor_id
      AND status IN ('accepted', 'preparing', 'ready', 'ready_for_pickup', 'in_transit', 'shipping');

    RETURN json_build_object(
        'total_revenue',    COALESCE(v_total_revenue, 0),
        'completed_orders', COALESCE(v_completed_orders, 0),
        'pending_orders',   COALESCE(v_pending_orders, 0),
        'active_orders',    COALESCE(v_active_orders, 0)
    );
END;
$$;

-- Grant execute to authenticated users
GRANT EXECUTE ON FUNCTION public.get_vendor_dashboard_metrics(UUID) TO authenticated;


-- ==============================================================================
-- PART E: FLUSH POSTGREST SCHEMA + POLICY CACHE
-- Must be the very last statement so it captures all changes above.
-- ==============================================================================
NOTIFY pgrst, 'reload schema';
