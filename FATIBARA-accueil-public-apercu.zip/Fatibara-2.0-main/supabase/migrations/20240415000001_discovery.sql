-- =================================================================================
-- FATIBARA DISCOVERY SYSTEM & WHOLESALE SECURITY
-- Migration: 20240415000001_discovery.sql
-- =================================================================================

-- Guarantee that the public.products table exists before attempting to alter it
CREATE TABLE IF NOT EXISTS public.products (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Ensure required columns exist on the stub
ALTER TABLE public.products ADD COLUMN IF NOT EXISTS price_gnf numeric DEFAULT 0;
ALTER TABLE public.products ADD COLUMN IF NOT EXISTS wholesale_price_gnf numeric;
ALTER TABLE public.products ADD COLUMN IF NOT EXISTS title text;
ALTER TABLE public.products ADD COLUMN IF NOT EXISTS description text;
ALTER TABLE public.products ADD COLUMN IF NOT EXISTS image_urls text[];

-- Update existing products with a mock wholesale price (20% off) for demonstration
UPDATE public.products 
SET wholesale_price_gnf = COALESCE(price_gnf, 0) * 0.8 
WHERE wholesale_price_gnf IS NULL;


-- 2. SECURE SEARCH RPC (Remote Procedure Call)
DROP FUNCTION IF EXISTS public.search_products(text);

CREATE OR REPLACE FUNCTION search_products(search_query text)
RETURNS TABLE (
  id uuid, 
  title text, 
  price_gnf numeric, 
  wholesale_price_gnf numeric, 
  image_urls text[]
) AS $$
DECLARE
  is_pro boolean := false;
BEGIN
  IF auth.uid() IS NOT NULL THEN
    SELECT is_pro_member INTO is_pro FROM public.profiles WHERE profiles.id = auth.uid();
  END IF;

  RETURN QUERY
  SELECT 
    p.id, 
    p.title, 
    p.price_gnf,
    CASE WHEN is_pro THEN p.wholesale_price_gnf ELSE NULL END as wholesale_price_gnf,
    p.image_urls
  FROM public.products p
  WHERE 
    p.title ILIKE '%' || search_query || '%' 
    OR p.description ILIKE '%' || search_query || '%'
  LIMIT 6;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;


-- 3. TRENDING ALGORITHM (POPULAIRE)
CREATE TABLE IF NOT EXISTS public.product_interactions (
  id uuid primary key default gen_random_uuid(),
  product_id uuid references public.products(id) on delete cascade,
  user_id uuid references auth.users(id) on delete set null,
  interaction_type text check (interaction_type in ('view', 'click')),
  created_at timestamp with time zone default now()
);

CREATE INDEX IF NOT EXISTS idx_product_interactions_created_at ON public.product_interactions(created_at);
CREATE INDEX IF NOT EXISTS idx_product_interactions_product_id ON public.product_interactions(product_id);

DROP FUNCTION IF EXISTS public.get_trending_products();

CREATE OR REPLACE FUNCTION get_trending_products()
RETURNS TABLE (
  id uuid, 
  title text, 
  price_gnf numeric, 
  wholesale_price_gnf numeric,
  image_urls text[], 
  trending_score bigint
) AS $$
DECLARE
  is_pro boolean := false;
BEGIN
  IF auth.uid() IS NOT NULL THEN
    SELECT is_pro_member INTO is_pro FROM public.profiles WHERE profiles.id = auth.uid();
  END IF;

  RETURN QUERY
  SELECT 
    p.id, 
    p.title, 
    p.price_gnf,
    CASE WHEN is_pro THEN p.wholesale_price_gnf ELSE NULL END as wholesale_price_gnf,
    p.image_urls,
    COALESCE(SUM(CASE WHEN i.interaction_type = 'click' THEN 3 ELSE 1 END), 0) as trending_score
  FROM public.products p
  LEFT JOIN public.product_interactions i ON p.id = i.product_id AND i.created_at > now() - interval '24 hours'
  GROUP BY p.id
  ORDER BY trending_score DESC, p.created_at DESC
  LIMIT 10;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Insert some mock interaction data for testing the trending algorithm
INSERT INTO public.product_interactions (product_id, interaction_type, created_at)
SELECT id, 'view', now() - (random() * interval '20 hours') FROM public.products LIMIT 20;

INSERT INTO public.product_interactions (product_id, interaction_type, created_at)
SELECT id, 'click', now() - (random() * interval '20 hours') FROM public.products LIMIT 10;