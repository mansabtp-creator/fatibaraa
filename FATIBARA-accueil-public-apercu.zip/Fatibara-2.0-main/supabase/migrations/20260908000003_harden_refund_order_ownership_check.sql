-- Migration: 20260908000003_harden_refund_order_ownership_check.sql
--
-- ISSUE-19: Harden the secure_refund_order_financials RPC to enforce:
--   1. The caller owns the order (auth.uid() = orders.user_id)
--   2. The order is in a cancellable state (pending or accepted)
--   3. No double-cancellation (already cancelled orders are rejected)
--
-- This ensures that even if the client-side guard is bypassed, the database
-- function itself will reject unauthorized or invalid refund attempts.
-- The function retains SECURITY DEFINER so it can update wallet balances,
-- but now verifies caller identity before doing anything privileged.

CREATE OR REPLACE FUNCTION public.secure_refund_order_financials(
  p_order_id    UUID,
  p_cancel_reason TEXT DEFAULT 'Annulation'
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_order           RECORD;
  v_caller_id       UUID  := auth.uid();
  v_refund_amount   NUMERIC;
  v_payment_method  TEXT;
BEGIN
  -- ── 1. Auth guard ─────────────────────────────────────────────────────────
  IF v_caller_id IS NULL THEN
    RAISE EXCEPTION 'Unauthorized: caller is not authenticated';
  END IF;

  -- ── 2. Fetch and lock the order row ───────────────────────────────────────
  SELECT o.id, o.user_id, o.status, o.financial_status, o.total_amount,
         o.payment_method, o.delivery_fee
  INTO   v_order
  FROM   public.orders o
  WHERE  o.id = p_order_id
  FOR UPDATE SKIP LOCKED;           -- pessimistic lock prevents race conditions

  IF NOT FOUND THEN
    RAISE EXCEPTION 'Order not found: %', p_order_id;
  END IF;

  -- ── 3. Ownership check ────────────────────────────────────────────────────
  -- Allow admins (is_admin = true) or the order owner to cancel.
  IF v_order.user_id IS DISTINCT FROM v_caller_id THEN
    -- Check if caller is admin before rejecting
    IF NOT EXISTS (
      SELECT 1 FROM public.profiles
      WHERE id = v_caller_id AND is_admin = true
    ) THEN
      RAISE EXCEPTION 'Forbidden: caller % does not own order %', v_caller_id, p_order_id;
    END IF;
  END IF;

  -- ── 4. State check ────────────────────────────────────────────────────────
  IF v_order.status NOT IN ('pending', 'accepted') THEN
    RAISE EXCEPTION 'Cannot cancel order in status: %. Only pending or accepted orders can be cancelled.', v_order.status;
  END IF;

  IF v_order.status = 'cancelled' THEN
    RAISE EXCEPTION 'Order % is already cancelled', p_order_id;
  END IF;

  -- ── 5. Determine refund amount ────────────────────────────────────────────
  -- Refund the full total_amount for wallet/mobile payments; COD has no refund.
  v_payment_method := COALESCE(v_order.payment_method, 'cash');
  v_refund_amount  := CASE
    WHEN v_payment_method IN ('wallet', 'orange', 'mtn')
    THEN COALESCE(v_order.total_amount, 0)
    ELSE 0  -- Cash on delivery: nothing to refund
  END;

  -- ── 6. Mark order as cancelled ───────────────────────────────────────────
  UPDATE public.orders
  SET    status           = 'cancelled',
         financial_status = CASE
                              WHEN v_refund_amount > 0 THEN 'refunded'
                              ELSE financial_status
                            END,
         updated_at       = NOW()
  WHERE  id = p_order_id;

  -- ── 7. Credit wallet if applicable ───────────────────────────────────────
  IF v_refund_amount > 0 AND v_order.user_id IS NOT NULL THEN
    UPDATE public.profiles
    SET    wallet_balance = COALESCE(wallet_balance, 0) + v_refund_amount
    WHERE  id = v_order.user_id;

    -- Record the refund transaction for auditability
    INSERT INTO public.wallet_transactions (
      user_id, amount, type, description, reference_id
    ) VALUES (
      v_order.user_id,
      v_refund_amount,
      'refund',
      COALESCE(p_cancel_reason, 'Annulation') || ' — commande #' || p_order_id::text,
      p_order_id
    ) ON CONFLICT DO NOTHING;
  END IF;

  -- ── 8. Restore stock for each order item ─────────────────────────────────
  UPDATE public.products p
  SET    stock_quantity = COALESCE(p.stock_quantity, 0) + oi.quantity
  FROM   public.order_items oi
  WHERE  oi.order_id  = p_order_id
  AND    oi.product_id = p.id;

  RETURN jsonb_build_object(
    'success',        true,
    'order_id',       p_order_id,
    'refund_amount',  v_refund_amount,
    'cancel_reason',  p_cancel_reason
  );

EXCEPTION
  WHEN OTHERS THEN
    RAISE; -- re-raise so the client sees the specific error message
END;
$$;

-- Grant execute only to authenticated users
REVOKE ALL ON FUNCTION public.secure_refund_order_financials(UUID, TEXT) FROM PUBLIC;
GRANT  EXECUTE ON FUNCTION public.secure_refund_order_financials(UUID, TEXT) TO authenticated;
