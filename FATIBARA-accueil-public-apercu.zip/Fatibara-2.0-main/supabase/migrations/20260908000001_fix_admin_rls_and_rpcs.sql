-- =============================================================================
-- Migration: 20260908000001_fix_admin_rls_and_rpcs.sql
-- Fix: public.is_admin() now accepts BOTH is_admin=true AND profile_type='admin'
-- Fix: Add SECURITY DEFINER RPCs for all admin user-management mutations so
--      direct .update() calls from the frontend are no longer needed.
-- =============================================================================

-- ── STEP 1: Fix public.is_admin() ────────────────────────────────────────────
-- The previous definition only checked the boolean `is_admin` column.
-- If an admin account has profile_type='admin' but is_admin=false (or null),
-- the RLS policy evaluates to false → all admin writes silently fail (0 rows).
CREATE OR REPLACE FUNCTION public.is_admin()
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT COALESCE(
    (
      SELECT (is_admin = true OR profile_type = 'admin')
      FROM public.profiles
      WHERE id = auth.uid()
    ),
    false
  );
$$;

GRANT EXECUTE ON FUNCTION public.is_admin() TO authenticated;
GRANT EXECUTE ON FUNCTION public.is_admin() TO anon;

-- ── STEP 2: RPC — Toggle is_admin flag ───────────────────────────────────────
DROP FUNCTION IF EXISTS public.admin_toggle_is_admin(uuid, boolean);

CREATE OR REPLACE FUNCTION public.admin_toggle_is_admin(
  target_user_id uuid,
  new_value       boolean
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  -- Verify caller is admin
  IF NOT public.is_admin() THEN
    RAISE EXCEPTION 'Permission refusée : vous n''êtes pas administrateur.';
  END IF;

  -- Prevent self-demotion
  IF target_user_id = auth.uid() THEN
    RAISE EXCEPTION 'Vous ne pouvez pas modifier vos propres droits d''administrateur.';
  END IF;

  UPDATE public.profiles
  SET    is_admin = new_value
  WHERE  id       = target_user_id;
END;
$$;

GRANT EXECUTE ON FUNCTION public.admin_toggle_is_admin(uuid, boolean) TO authenticated;

-- ── STEP 3: RPC — Change profile_type / role ─────────────────────────────────
DROP FUNCTION IF EXISTS public.admin_update_user_role(uuid, text);

CREATE OR REPLACE FUNCTION public.admin_update_user_role(
  target_user_id  uuid,
  new_profile_type text          -- 'client' | 'courier' | 'vendor'
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NOT public.is_admin() THEN
    RAISE EXCEPTION 'Permission refusée : vous n''êtes pas administrateur.';
  END IF;

  IF new_profile_type NOT IN ('client', 'courier', 'vendor') THEN
    RAISE EXCEPTION 'Type de profil invalide : %', new_profile_type;
  END IF;

  UPDATE public.profiles
  SET
    profile_type   = new_profile_type,
    courier_status = CASE WHEN new_profile_type = 'courier' THEN 'active' ELSE NULL END
  WHERE id = target_user_id;

  -- When promoting to courier, ensure a courier_profiles row exists so the
  -- complete_courier_delivery RPC can always credit courier_profiles.balance.
  IF new_profile_type = 'courier' THEN
    INSERT INTO public.courier_profiles (user_id, status, active_capacity, balance)
    VALUES (target_user_id, 'active', 1, 0)
    ON CONFLICT (user_id) DO UPDATE
      SET status = 'active';
  END IF;
END;
$$;

GRANT EXECUTE ON FUNCTION public.admin_update_user_role(uuid, text) TO authenticated;

-- ── STEP 4: RPC — Suspend / reactivate account ───────────────────────────────
DROP FUNCTION IF EXISTS public.admin_update_account_status(uuid, text);

CREATE OR REPLACE FUNCTION public.admin_update_account_status(
  target_user_id uuid,
  new_status      text          -- 'active' | 'suspended'
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NOT public.is_admin() THEN
    RAISE EXCEPTION 'Permission refusée : vous n''êtes pas administrateur.';
  END IF;

  IF new_status NOT IN ('active', 'suspended') THEN
    RAISE EXCEPTION 'Statut invalide : %', new_status;
  END IF;

  IF target_user_id = auth.uid() THEN
    RAISE EXCEPTION 'Vous ne pouvez pas modifier le statut de votre propre compte.';
  END IF;

  UPDATE public.profiles
  SET    account_status = new_status
  WHERE  id             = target_user_id;
END;
$$;

GRANT EXECUTE ON FUNCTION public.admin_update_account_status(uuid, text) TO authenticated;

-- ── STEP 5: Notify PostgREST to reload schema cache ──────────────────────────
NOTIFY pgrst, 'reload schema';

-- ── STEP 6: RPC — Set courier status (DISPO / COURSE / HORS LGN / SUSPEND) ───
-- Syncs profiles.courier_status AND courier_profiles.status atomically so the
-- accept_order_batch suspension guard always sees the correct state.
DROP FUNCTION IF EXISTS public.admin_set_courier_status(uuid, text, text);

CREATE OR REPLACE FUNCTION public.admin_set_courier_status(
  target_user_id       uuid,
  new_courier_status   text,   -- 'disponible' | 'en_course' | 'hors_ligne' | 'suspendu'
  new_canonical_status text    -- 'active' | 'inactive' | 'suspended'
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NOT public.is_admin() THEN
    RAISE EXCEPTION 'Permission refusée : vous n''êtes pas administrateur.';
  END IF;

  IF new_courier_status NOT IN ('disponible', 'en_course', 'hors_ligne', 'suspendu') THEN
    RAISE EXCEPTION 'Statut livreur invalide : %', new_courier_status;
  END IF;

  -- Update legacy profiles.courier_status
  UPDATE public.profiles
  SET    courier_status = new_courier_status
  WHERE  id             = target_user_id;

  -- Sync canonical courier_profiles.status
  INSERT INTO public.courier_profiles (user_id, status, active_capacity, balance)
  VALUES (target_user_id, new_canonical_status, 1, 0)
  ON CONFLICT (user_id) DO UPDATE
    SET status = EXCLUDED.status;
END;
$$;

GRANT EXECUTE ON FUNCTION public.admin_set_courier_status(uuid, text, text) TO authenticated;

NOTIFY pgrst, 'reload schema';
