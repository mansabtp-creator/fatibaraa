-- Cancel a payment-intent order that never reached a successful gateway state.
-- The order-items INSERT trigger already reserved stock, so cancellation must
-- restore that stock exactly once.
CREATE OR REPLACE FUNCTION public.cancel_unpaid_mobile_order(
  p_order_id UUID,
  p_reason TEXT DEFAULT 'Paiement mobile non finalisé'
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_order public.orders%ROWTYPE;
  v_item RECORD;
BEGIN
  SELECT * INTO v_order
  FROM public.orders
  WHERE id = p_order_id
  FOR UPDATE;

  IF NOT FOUND THEN
    RAISE EXCEPTION 'Order not found';
  END IF;

  -- Authenticated buyers can only cancel their own pending payment intent.
  -- service_role webhook calls have no auth.uid() and are permitted.
  IF auth.uid() IS NOT NULL AND auth.uid() <> v_order.user_id THEN
    RAISE EXCEPTION 'Unauthorized';
  END IF;

  -- Idempotency: stock is restored only while the initial payment intent is
  -- still pending. Replayed gateway callbacks are harmless.
  IF v_order.status = 'cancelled' OR v_order.financial_status <> 'pending' THEN
    RETURN jsonb_build_object('success', true, 'alreadyFinalized', true);
  END IF;

  FOR v_item IN
    SELECT product_id, quantity
    FROM public.order_items
    WHERE order_id = p_order_id
      AND product_id IS NOT NULL
  LOOP
    UPDATE public.products
    SET stock_quantity = COALESCE(stock_quantity, 0) + v_item.quantity,
        is_active = CASE
          WHEN NOT is_active AND COALESCE(stock_quantity, 0) + v_item.quantity > 0 THEN TRUE
          ELSE is_active
        END
    WHERE id = v_item.product_id;
  END LOOP;

  UPDATE public.orders
  SET status = 'cancelled',
      financial_status = 'failed',
      notes = p_reason,
      updated_at = now()
  WHERE id = p_order_id;

  RETURN jsonb_build_object('success', true);
END;
$$;

GRANT EXECUTE ON FUNCTION public.cancel_unpaid_mobile_order(UUID, TEXT)
  TO authenticated, service_role;

NOTIFY pgrst, 'reload schema';
