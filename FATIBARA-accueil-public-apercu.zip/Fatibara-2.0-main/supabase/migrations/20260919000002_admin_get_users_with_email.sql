-- ==============================================================================
-- Migration: 20260919000002_admin_get_users_with_email.sql
-- Created:   2026-09-19
-- Updated:   2026-09-19 — renamed to admin_get_users_v2 to bypass PostgREST
--            stale schema cache on managed Supabase instances.
--
-- Purpose: Expose auth.users.email to the admin dashboard.
--
-- The `profiles` table does not store email — it lives in `auth.users` which
-- is only accessible via SECURITY DEFINER functions or the service-role key.
-- This function runs as the superuser (SECURITY DEFINER) and returns a merged
-- row of profile + auth email, callable by authenticated admins only.
-- ==============================================================================

-- Drop old name (may not exist on fresh installs)
DROP FUNCTION IF EXISTS public.admin_get_users_with_email();

CREATE OR REPLACE FUNCTION public.admin_get_users_v2()
RETURNS TABLE (
    id              UUID,
    full_name       TEXT,
    email           TEXT,
    phone_number    TEXT,
    profile_type    TEXT,
    is_admin        BOOLEAN,
    account_status  TEXT,
    wallet_balance  NUMERIC,
    avatar_url      TEXT,
    created_at      TIMESTAMPTZ,
    updated_at      TIMESTAMPTZ,
    last_sign_in_at TIMESTAMPTZ,
    email_confirmed BOOLEAN
)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, auth
AS $$
DECLARE
    v_caller_is_admin BOOLEAN;
BEGIN
    -- Security gate: only allow if the calling user is an admin
    SELECT p.is_admin INTO v_caller_is_admin
    FROM public.profiles p
    WHERE p.id = auth.uid();

    IF NOT COALESCE(v_caller_is_admin, false) THEN
        -- Also allow the hardcoded super-admin by user_id
        IF auth.uid()::text != 'c620a30d-5828-4066-9d59-8db34c28d20d' THEN
            RAISE EXCEPTION 'Access denied: admin only';
        END IF;
    END IF;

    RETURN QUERY
    SELECT
        p.id,
        p.full_name,
        u.email,
        p.phone_number,
        p.profile_type,
        COALESCE(p.is_admin, false)        AS is_admin,
        p.account_status,
        COALESCE(p.wallet_balance, 0)      AS wallet_balance,
        p.avatar_url,
        p.created_at,
        p.updated_at,
        u.last_sign_in_at,
        (u.email_confirmed_at IS NOT NULL) AS email_confirmed
    FROM public.profiles p
    JOIN auth.users u ON u.id = p.id
    ORDER BY p.created_at DESC;
END;
$$;

-- Only authenticated users can call it (the function itself enforces admin check)
REVOKE ALL ON FUNCTION public.admin_get_users_v2() FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.admin_get_users_v2() TO authenticated;
GRANT EXECUTE ON FUNCTION public.admin_get_users_v2() TO service_role;

DO $$ BEGIN
    RAISE NOTICE '[admin_get_users_v2] RPC created — exposes auth email + last_sign_in_at to admins';
END $$;

NOTIFY pgrst, 'reload schema';
