-- ==============================================================================
-- MIGRATION: 20260828000005_security_hardening.sql
--
-- PURPOSE:
--   Final security sweep applying fixes across three areas:
--   1. RLS Enforcement — Enable RLS on 2 tables that had policies defined but
--      RLS never switched ON (store_follows, product_interactions).
--   2. SECURITY DEFINER Hardening — Add explicit caller auth.uid() guards and
--      search_path lockdown to reject_withdrawal and related RPCs.
--   3. Defensive permissions — REVOKE PUBLIC execute from sensitive functions,
--      add courier_profiles RLS policies for INSERT/UPDATE to close write gaps.
-- ==============================================================================

-- ── 1. Enable RLS on tables that had policies but no ENABLE statement ─────────
--
-- Migration 20260815000001 created policies for these tables but never called
-- ALTER TABLE ... ENABLE ROW LEVEL SECURITY. With RLS disabled, the policies
-- are completely ignored and ALL authenticated users can read/write every row.
-- This is a critical cross-tenant data isolation gap for store_follows.
--
-- store_follows: public reads are intentional (follower counts). Only writes
--   must be locked to the follower_id owner.
-- product_interactions: fully private — users should only see their own.

ALTER TABLE public.store_follows        ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.product_interactions ENABLE ROW LEVEL SECURITY;

-- Confirm existing policies are in place (idempotent re-create for clarity)
DROP POLICY IF EXISTS "store_follows_read"       ON public.store_follows;
CREATE POLICY "store_follows_read"
  ON public.store_follows FOR SELECT
  USING (true); -- Public: follow counts are visible to all

DROP POLICY IF EXISTS "store_follows_own_write"  ON public.store_follows;
CREATE POLICY "store_follows_own_write"
  ON public.store_follows FOR INSERT TO authenticated
  WITH CHECK (auth.uid() = follower_id);

DROP POLICY IF EXISTS "store_follows_own_delete" ON public.store_follows;
CREATE POLICY "store_follows_own_delete"
  ON public.store_follows FOR DELETE TO authenticated
  USING (auth.uid() = follower_id);

DROP POLICY IF EXISTS "product_interactions_own" ON public.product_interactions;
CREATE POLICY "product_interactions_own"
  ON public.product_interactions FOR ALL TO authenticated
  USING  (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- Anonymous read on product_interactions for aggregate views (likes, views).
-- Reads are safe because the user_id column is never exposed to the client
-- in production queries (only COUNT(*) is used).
DROP POLICY IF EXISTS "product_interactions_anon_read" ON public.product_interactions;
CREATE POLICY "product_interactions_anon_read"
  ON public.product_interactions FOR SELECT
  USING (true);


-- ── 2. Harden courier_profiles RLS — close INSERT/UPDATE gap ─────────────────
--
-- The existing migration only created a SELECT policy for courier_profiles.
-- Without INSERT/UPDATE policies, an authenticated non-courier could theoretically
-- INSERT a row into courier_profiles for another user's UUID via the anon key.
-- The service_role key bypasses RLS, so webhook calls are unaffected.

DROP POLICY IF EXISTS "cp_insert_own"  ON public.courier_profiles;
CREATE POLICY "cp_insert_own"
  ON public.courier_profiles FOR INSERT TO authenticated
  WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "cp_update_own"  ON public.courier_profiles;
CREATE POLICY "cp_update_own"
  ON public.courier_profiles FOR UPDATE TO authenticated
  USING      (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- Deny direct DELETE from anon/authenticated — only service_role can delete.
-- (No DELETE policy = implicit DENY for authenticated users.)


-- ── 3. Harden reject_withdrawal: add auth.uid() guard and search_path lock ────
--
-- Migration 000004 defined reject_withdrawal with RETURNS BOOLEAN.
-- This version upgrades it to RETURNS JSONB for a richer audit response AND
-- adds a mandatory admin auth.uid() guard inside the SECURITY DEFINER body.
--
-- PostgreSQL cannot change a function's return type via CREATE OR REPLACE,
-- so we must DROP the old signature first.

DROP FUNCTION IF EXISTS public.reject_withdrawal(UUID, TEXT) CASCADE;

CREATE OR REPLACE FUNCTION public.reject_withdrawal(
  p_withdrawal_id UUID,
  p_reason        TEXT DEFAULT 'Rejeté par l''administrateur'
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public  -- lock schema to prevent search_path injection
AS $$
DECLARE
  v_withdrawal    RECORD;
  v_caller_id     UUID;
  v_caller_admin  BOOLEAN;
BEGIN
  -- ── Caller authentication guard ──────────────────────────────────────────
  -- SECURITY DEFINER bypasses RLS, so we must enforce admin-only access here.
  v_caller_id := auth.uid();

  IF v_caller_id IS NULL THEN
    RAISE EXCEPTION 'reject_withdrawal: unauthenticated caller.'
      USING ERRCODE = '42501';
  END IF;

  SELECT is_admin INTO v_caller_admin
    FROM public.profiles
   WHERE id = v_caller_id;

  IF NOT COALESCE(v_caller_admin, false) THEN
    RAISE EXCEPTION 'reject_withdrawal: caller % is not an admin.', v_caller_id
      USING ERRCODE = '42501';
  END IF;

  -- ── Fetch withdrawal record ───────────────────────────────────────────────
  SELECT * INTO v_withdrawal
    FROM public.withdrawals
   WHERE id = p_withdrawal_id;

  IF NOT FOUND THEN
    RAISE EXCEPTION 'reject_withdrawal: withdrawal % not found.', p_withdrawal_id
      USING ERRCODE = 'P0002';
  END IF;

  IF v_withdrawal.status != 'pending' THEN
    RAISE EXCEPTION 'reject_withdrawal: withdrawal % is already %, cannot reject.',
      p_withdrawal_id, v_withdrawal.status
      USING ERRCODE = '23514';
  END IF;

  -- ── Atomic rejection + refund ─────────────────────────────────────────────
  -- 1. Mark withdrawal as rejected
  UPDATE public.withdrawals
     SET status = 'rejected',
         notes  = COALESCE(notes || E'\n', '') || '[Rejeté] ' || p_reason
   WHERE id = p_withdrawal_id;

  -- 2. Refund the amount to the user's wallet balance.
  --    withdrawals.profile_id is the owner (mirrors wallet_transactions.profile_id)
  UPDATE public.profiles
     SET wallet_balance = COALESCE(wallet_balance, 0) + v_withdrawal.amount,
         updated_at     = NOW()
   WHERE id = v_withdrawal.profile_id;

  -- 3. If it was a store withdrawal, refund the store balance too
  IF v_withdrawal.store_id IS NOT NULL THEN
    UPDATE public.stores
       SET balance = COALESCE(balance, 0) + v_withdrawal.amount
     WHERE id = v_withdrawal.store_id;
  END IF;

  -- 4. Insert audit trail record into wallet_transactions
  INSERT INTO public.wallet_transactions (
    profile_id, store_id, amount, type, status, reference_id, description
  ) VALUES (
    v_withdrawal.profile_id,
    v_withdrawal.store_id,
    v_withdrawal.amount,
    'payout_refund',
    'completed',
    v_withdrawal.id::TEXT,
    'Remboursement retrait rejeté — ' || p_reason
  );

  RETURN jsonb_build_object(
    'success',       true,
    'withdrawal_id', p_withdrawal_id,
    'refunded',      v_withdrawal.amount,
    'profile_id',    v_withdrawal.profile_id,
    'rejected_by',   v_caller_id
  );

EXCEPTION
  WHEN OTHERS THEN
    RAISE;
END;
$$;

-- Permissions: only admin-authenticated callers (via PostgREST) + service_role
REVOKE ALL    ON FUNCTION public.reject_withdrawal(UUID, TEXT) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.reject_withdrawal(UUID, TEXT) TO authenticated;
GRANT EXECUTE ON FUNCTION public.reject_withdrawal(UUID, TEXT) TO service_role;


-- ── 4. Lock search_path on credit_user_wallet (belt + suspenders) ─────────────
--
-- The function already has SET search_path = public in the creation migration,
-- but re-assert here to be explicit in this audit trail migration.
ALTER FUNCTION public.credit_user_wallet(UUID, NUMERIC, UUID, TEXT)
  SET search_path = public;


-- ── 5. Verify complete_courier_delivery has auth guard (no-op if already ok) ──
--
-- complete_courier_delivery is already guarded in 20260815000001 with:
--   IF auth.uid() != v_order.courier_id THEN RAISE EXCEPTION ...
-- This GRANT/REVOKE block ensures the correct permission set is applied
-- regardless of migration order.
DO $$
BEGIN
  -- Verify the function exists before touching permissions
  IF EXISTS (
    SELECT 1 FROM pg_proc p
    JOIN pg_namespace n ON n.oid = p.pronamespace
    WHERE n.nspname = 'public' AND p.proname = 'complete_courier_delivery'
  ) THEN
    -- Only authenticated couriers should be able to call this
    EXECUTE 'REVOKE ALL    ON FUNCTION public.complete_courier_delivery(UUID, TEXT) FROM PUBLIC';
    EXECUTE 'GRANT EXECUTE ON FUNCTION public.complete_courier_delivery(UUID, TEXT) TO authenticated';
    EXECUTE 'GRANT EXECUTE ON FUNCTION public.complete_courier_delivery(UUID, TEXT) TO service_role';
  END IF;
END $$;


-- ── 6. boost_campaigns: ensure RLS policies exist for vendor isolation ─────────
--
-- boost_campaigns is in the RLS-enabled list but policy definitions were not
-- found in previous scans. Add defensive policies.

DROP POLICY IF EXISTS "boost_campaigns_vendor_own"  ON public.boost_campaigns;
CREATE POLICY "boost_campaigns_vendor_own"
  ON public.boost_campaigns FOR ALL TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM public.stores s
      WHERE s.id = store_id AND s.owner_id = auth.uid()
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM public.stores s
      WHERE s.id = store_id AND s.owner_id = auth.uid()
    )
  );

DROP POLICY IF EXISTS "boost_campaigns_admin_all"   ON public.boost_campaigns;
CREATE POLICY "boost_campaigns_admin_all"
  ON public.boost_campaigns FOR ALL TO authenticated
  USING      (public.is_admin())
  WITH CHECK (public.is_admin());


-- ── 7. Reload PostgREST schema cache ─────────────────────────────────────────
NOTIFY pgrst, 'reload schema';
