-- ==============================================================================
-- Migration: Add increment_loyalty_points RPC
-- File:      20260721000005_add_loyalty_points_rpc.sql
-- Created:   2026-07-21
--
-- PURPOSE:
--   Creates a SECURITY DEFINER RPC that safely adds (or subtracts) loyalty
--   points from a user's profile, with a floor at 0 so points can never go
--   negative (e.g. when redeeming points at checkout).
--
-- CALLERS:
--   * ReviewModal.tsx         – +points on product review submission
--   * CourierRatingModal.tsx  – +points on courier rating submission
--   * CheckoutPage.tsx        – -points when redeeming loyalty points at checkout
--
-- COLUMN NOTE:
--   loyalty_points INT DEFAULT 0 already exists on public.profiles as of
--   migration 20240101000000_foundation_schema.sql (line 34). This migration
--   adds the column idempotently in case a future reset drops/recreates the
--   table without it.
-- ==============================================================================

-- Ensure the column exists (idempotent guard)
ALTER TABLE public.profiles
  ADD COLUMN IF NOT EXISTS loyalty_points INTEGER DEFAULT 0;

-- Non-negative constraint guard (idempotent)
DO $$ BEGIN
  ALTER TABLE public.profiles
    ADD CONSTRAINT profiles_loyalty_nonneg CHECK (loyalty_points >= 0);
EXCEPTION WHEN duplicate_object THEN NULL;
END $$;

-- ==============================================================================
-- RPC: increment_loyalty_points
--
-- Parameters:
--   user_id  UUID  - the profile to update
--   points   INT   - delta (positive = earn, negative = redeem)
--
-- Behaviour:
--   Updates loyalty_points = GREATEST(0, current + points).
--   Uses SECURITY DEFINER so the authenticated role cannot bypass the floor
--   with a direct UPDATE; all point mutations go through this function.
-- ==============================================================================
CREATE OR REPLACE FUNCTION public.increment_loyalty_points(
  user_id UUID,
  points  INTEGER
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  UPDATE public.profiles
  SET    loyalty_points = GREATEST(0, COALESCE(loyalty_points, 0) + points)
  WHERE  id = user_id;
END;
$$;

-- Grant execute to authenticated users (called from client-side RPCs)
GRANT EXECUTE ON FUNCTION public.increment_loyalty_points(UUID, INTEGER) TO authenticated;

-- Notify PostgREST to reload its schema cache
NOTIFY pgrst, 'reload schema';
