-- =============================================================================
-- Migration: Fix wishlist upsert 409 conflict errors
-- Date: 2026-09-02
-- Problem: supabase-js .upsert({ onConflict: 'user_id,product_id' }) requires
--   a *named* unique constraint or unique index on exactly those columns.
--   When only an inline UNIQUE() clause exists (without a deterministic name),
--   PostgREST may not resolve the conflict target and falls back to a plain
--   INSERT, causing 409 (Conflict) on duplicates.
-- Fix: Create explicit, named unique indexes on both tables so upsert always
--   resolves correctly. IF NOT EXISTS guards make this fully idempotent.
-- =============================================================================

-- 1. user_wishlists: ensure named unique index
CREATE UNIQUE INDEX IF NOT EXISTS uq_user_wishlists_user_product
  ON public.user_wishlists (user_id, product_id);

-- 2. cart_items: ensure named unique index (used for the same upsert pattern)
CREATE UNIQUE INDEX IF NOT EXISTS uq_cart_items_user_product
  ON public.cart_items (user_id, product_id);
