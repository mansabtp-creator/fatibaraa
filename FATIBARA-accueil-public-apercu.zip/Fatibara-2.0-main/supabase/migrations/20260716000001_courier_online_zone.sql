-- Migration: Add courier online toggle and zone columns
-- Created: 2026-07-16
-- Adds:
--   profiles.is_courier_online  — courier-controlled shift toggle (default: false)
--   profiles.courier_zone       — preferred delivery zone / commune
ALTER TABLE public.profiles
  ADD COLUMN IF NOT EXISTS is_courier_online BOOLEAN DEFAULT false,
  ADD COLUMN IF NOT EXISTS courier_zone      TEXT    DEFAULT NULL;

COMMENT ON COLUMN public.profiles.is_courier_online IS 'Courier shift toggle. True = accepting orders.';
COMMENT ON COLUMN public.profiles.courier_zone      IS 'Preferred commune for deliveries (e.g. Ratoma).';
