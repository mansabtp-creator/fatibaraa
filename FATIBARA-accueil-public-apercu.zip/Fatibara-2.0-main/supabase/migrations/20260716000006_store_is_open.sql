-- Sprint 3.4: Store Open/Closed auto-pause
-- Adds is_open flag to stores table so vendors can pause order intake

ALTER TABLE stores
  ADD COLUMN IF NOT EXISTS is_open BOOLEAN NOT NULL DEFAULT true;

-- Speed up customer browse queries that filter open stores
CREATE INDEX IF NOT EXISTS idx_stores_is_open ON stores (is_open)
  WHERE is_open = true;

COMMENT ON COLUMN stores.is_open IS
  'Vendor-controlled flag. When false, the storefront is paused and customers
   cannot submit new orders for this store.';
