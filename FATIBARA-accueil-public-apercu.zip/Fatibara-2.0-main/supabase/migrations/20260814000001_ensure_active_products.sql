-- =============================================================================
-- Migration: Ensure Active Products — Data Repair
-- File:      supabase/migrations/20260814000001_ensure_active_products.sql
-- Created:   2026-08-14
--
-- PROBLEM:
--   Products inserted before the moderation columns were added
--   (20260723000002_product_moderation.sql) may have NULL values for
--   `is_active` and `moderation_status`. The public SELECT RLS policy in
--   20260813000005_fix_public_products_rls.sql accepts NULLs via
--     USING ((is_active = true OR is_active IS NULL)
--            AND (moderation_status = 'approved' OR moderation_status IS NULL))
--   but this IS NULL fallback is a temporary safety net, not a data guarantee.
--   If the policy is ever tightened those rows will silently disappear from
--   the storefront feed.
--
-- WHAT THIS MIGRATION DOES:
--   1. Sets is_active = true  on every product row where the column is NULL.
--   2. Sets moderation_status = 'approved' on every product row where it is
--      NULL OR still 'pending' (i.e. rows awaiting a moderation decision that
--      was never made — treat them as approved so they appear in the feed).
--   3. Sets is_active = true  on every store  row where the column is NULL,
--      using COALESCE so existing false values are preserved.
--   4. Reloads the PostgREST schema cache.
--
-- SAFETY:
--   • All UPDATEs use WHERE guards — only NULL / pending rows are touched.
--   • Rows explicitly set to is_active = false or moderation_status = 'rejected'
--     by an admin or vendor are NOT modified.
--   • Idempotent: running this migration twice produces the same result.
-- =============================================================================

-- ── 1. Repair products ────────────────────────────────────────────────────────

-- Set is_active = true for any product that has a NULL flag.
-- (Products explicitly set to false by the vendor are left untouched.)
UPDATE public.products
SET    is_active = true
WHERE  is_active IS NULL;

-- Set moderation_status = 'approved' for products that:
--   • Have a NULL status (inserted before the column existed), OR
--   • Are still 'pending' (admin queue was never processed — show them).
-- Explicitly 'rejected' products are NOT touched.
UPDATE public.products
SET    moderation_status = 'approved'
WHERE  moderation_status IS NULL
   OR  moderation_status = 'pending';

-- ── 2. Repair stores ──────────────────────────────────────────────────────────

-- Note: the schema comment in 20260813000005 says stores has NO is_active column.
-- This UPDATE is wrapped in a DO block so it is a no-op if the column doesn't
-- exist, keeping the migration safe regardless of schema version.
DO $$
BEGIN
  IF EXISTS (
    SELECT 1
    FROM   information_schema.columns
    WHERE  table_schema = 'public'
      AND  table_name   = 'stores'
      AND  column_name  = 'is_active'
  ) THEN
    EXECUTE $dyn$
      UPDATE public.stores
      SET    is_active = COALESCE(is_active, true)
      WHERE  is_active IS NULL;
    $dyn$;
    RAISE NOTICE 'stores.is_active column found — NULL rows set to true.';
  ELSE
    RAISE NOTICE 'stores.is_active column does not exist — skipping (safe).';
  END IF;
END $$;

-- ── 3. Reload PostgREST schema cache ──────────────────────────────────────────
-- Forces PostgREST to pick up any policy changes immediately.
NOTIFY pgrst, 'reload schema';
