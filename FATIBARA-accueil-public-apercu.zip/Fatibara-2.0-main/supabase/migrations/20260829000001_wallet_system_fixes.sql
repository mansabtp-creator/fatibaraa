-- ==============================================================================
-- MIGRATION: 20260829000001_wallet_system_fixes.sql
-- Fatibara 2.0 — Wallet System Bug Fixes
-- Date: 2026-08-29
--
-- FIXES:
--
--   [F-1] approve_withdrawal inserted amount=0 in the audit wallet_transactions
--         row, making the ledger useless for reconciliation. Fixed to insert the
--         actual withdrawal amount as a negative debit (already locked at request
--         time) so the ledger stays balanced.
--
--   [F-2] courier_profiles.balance drifts vs profiles.wallet_balance for any
--         code path that does NOT go through credit_user_wallet or
--         secure_process_order_financials (e.g. admin manual credits, refunds,
--         or future RPCs). Installing a AFTER UPDATE trigger on profiles ensures
--         courier_profiles.balance is always the single authoritative mirror.
--
--   [F-3] credit_user_wallet sync path: the RPC already syncs courier_profiles
--         but the wallet_transactions UPDATE trigger now makes it redundant.
--         Keep for belt-and-suspenders (idempotent UPDATE is cheap).
--
-- ==============================================================================

-- ==============================================================================
-- FIX F-1: approve_withdrawal — insert real amount in audit row
-- ==============================================================================
-- The previous version inserted amount=0.  A correct audit row for an approved
-- withdrawal should record -amount (the outflow already locked at request time)
-- so that a full scan of wallet_transactions produces a balanced ledger.
-- We also add reference_id so admins can join back to the withdrawals row.
-- ==============================================================================

CREATE OR REPLACE FUNCTION public.approve_withdrawal(p_withdrawal_id UUID)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
    v_withdrawal RECORD;
BEGIN
    -- Admin-only guard
    IF NOT public.is_admin() THEN
        RAISE EXCEPTION 'Unauthorized: Admin access required.';
    END IF;

    SELECT * INTO v_withdrawal
    FROM public.withdrawals
    WHERE id = p_withdrawal_id
    FOR UPDATE;

    IF NOT FOUND THEN
        RETURN jsonb_build_object(
            'success', false,
            'message', 'Withdrawal request not found.'
        );
    END IF;

    IF v_withdrawal.status != 'pending' THEN
        RETURN jsonb_build_object(
            'success',          true,
            'alreadyProcessed', true,
            'status',           v_withdrawal.status
        );
    END IF;

    -- Mark withdrawal as processed
    UPDATE public.withdrawals
    SET
        status       = 'processed',
        processed_at = NOW(),
        processed_by = auth.uid()
    WHERE id = p_withdrawal_id;

    -- ── FIX F-1: insert real amount (negative = outflow already locked) ────────
    -- Note: balance was already deducted at request time by request_vendor_withdrawal
    -- or request_user_withdrawal. This row is purely an audit trail entry.
    INSERT INTO public.wallet_transactions (
        store_id, profile_id, amount, type, reference_id, description, status
    ) VALUES (
        v_withdrawal.store_id,
        v_withdrawal.profile_id,
        -- Negative: represents the locked funds being confirmed as paid out.
        -- The deduction already happened; this closes the accounting loop.
        -ABS(v_withdrawal.amount),
        'withdrawal_approved',
        v_withdrawal.id::TEXT,
        'Retrait approuvé — ' || COALESCE(v_withdrawal.method, '') ||
        CASE WHEN v_withdrawal.phone IS NOT NULL AND v_withdrawal.phone != ''
             THEN ' (' || v_withdrawal.phone || ')'
             ELSE '' END,
        'completed'
    );

    RETURN jsonb_build_object('success', true, 'message', 'Withdrawal approved successfully.');

EXCEPTION WHEN OTHERS THEN
    RETURN jsonb_build_object('success', false, 'message', SQLERRM);
END;
$$;

GRANT EXECUTE ON FUNCTION public.approve_withdrawal(UUID) TO authenticated;

COMMENT ON FUNCTION public.approve_withdrawal(UUID) IS
'Admin-only: marks a withdrawal as processed. Balance was already deducted at
request time (request_vendor_withdrawal / request_user_withdrawal).
Inserts a -amount audit row in wallet_transactions (type=withdrawal_approved)
so the ledger is fully balanced. Returns JSONB { success, message? }.';

-- ==============================================================================
-- FIX F-2: DB trigger to keep courier_profiles.balance in sync with
--           profiles.wallet_balance for ALL update paths
-- ==============================================================================
-- Problem: secure_process_order_financials (Aug 28 patch) now syncs courier_profiles
-- but other paths (admin credits, refunds via reject_withdrawal, future RPCs) write
-- directly to profiles.wallet_balance and skip courier_profiles.
--
-- Solution: AFTER UPDATE trigger on profiles. Fires whenever wallet_balance changes,
-- silently updates courier_profiles.balance if a row exists for that user_id.
-- No-op for non-courier profiles (0 rows updated is fine).
-- ==============================================================================

CREATE OR REPLACE FUNCTION public.sync_courier_balance_from_profile()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
    -- Only act when wallet_balance actually changed value
    IF NEW.wallet_balance IS DISTINCT FROM OLD.wallet_balance THEN
        UPDATE public.courier_profiles
        SET balance    = COALESCE(NEW.wallet_balance, 0),
            updated_at = NOW()
        WHERE user_id = NEW.id;
    END IF;
    RETURN NEW;
END;
$$;

-- Attach trigger (idempotent: DROP first)
DROP TRIGGER IF EXISTS trg_sync_courier_balance ON public.profiles;

CREATE TRIGGER trg_sync_courier_balance
    AFTER UPDATE OF wallet_balance ON public.profiles
    FOR EACH ROW
    EXECUTE FUNCTION public.sync_courier_balance_from_profile();

GRANT EXECUTE ON FUNCTION public.sync_courier_balance_from_profile() TO service_role;

COMMENT ON FUNCTION public.sync_courier_balance_from_profile() IS
'AFTER UPDATE trigger on profiles.wallet_balance.
Keeps courier_profiles.balance in sync for ALL write paths (not just
credit_user_wallet / secure_process_order_financials).
No-op for non-courier users (0 rows updated silently).';

-- ==============================================================================
-- Backfill: sync courier_profiles.balance from profiles.wallet_balance NOW
-- (fixes any existing drift before the trigger takes over)
-- ==============================================================================
UPDATE public.courier_profiles cp
SET balance    = COALESCE(p.wallet_balance, 0),
    updated_at = NOW()
FROM public.profiles p
WHERE cp.user_id = p.id
  AND cp.balance IS DISTINCT FROM p.wallet_balance;

-- ==============================================================================
-- FIX F-3: Grant increment_store_balance to service_role
-- ==============================================================================
-- This function is SECURITY DEFINER (only reads/writes stores) but was revoked
-- from all roles in the foundation schema. The webhook gateway (service_role key)
-- needs to call it to credit stores.balance for vendor top-ups.
-- Authenticated users cannot call it (no GRANT to authenticated).
-- ==============================================================================
GRANT EXECUTE ON FUNCTION public.increment_store_balance(UUID, NUMERIC) TO service_role;

-- ==============================================================================
-- Reload PostgREST schema cache
-- ==============================================================================
NOTIFY pgrst, 'reload schema';
