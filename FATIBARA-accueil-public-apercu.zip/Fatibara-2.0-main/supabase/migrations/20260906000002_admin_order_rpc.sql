-- ==============================================================================
-- Migration: F7 — admin_update_order_status SECURITY DEFINER RPC
-- File:      20260906000002_admin_order_rpc.sql
-- Created:   2026-09-06
--
-- Problem: AdminDashboardPage.tsx used direct `.update()` on the `orders` table
-- from the authenticated client JWT. RLS blocks non-owner direct writes, so
-- status changes silently fail (or return 0 rows) for admin users.
--
-- Fix: Provide a SECURITY DEFINER RPC that:
--   1. Validates caller is admin (checks profiles.is_admin)
--   2. Validates status transition is legal
--   3. Runs as postgres superuser → bypasses RLS → always succeeds
-- ==============================================================================

CREATE OR REPLACE FUNCTION public.admin_update_order_status(
  p_order_id  UUID,
  p_status    TEXT
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_caller_id UUID;
  v_is_admin  BOOLEAN;
  v_allowed   TEXT[] := ARRAY[
    'pending', 'confirmed', 'preparing', 'ready_for_pickup',
    'out_for_delivery', 'delivered', 'cancelled', 'refunded'
  ];
BEGIN
  -- Identify the caller from the JWT sub claim
  v_caller_id := auth.uid();
  IF v_caller_id IS NULL THEN
    RETURN jsonb_build_object('success', false, 'error', 'Not authenticated');
  END IF;

  -- Verify admin
  SELECT is_admin INTO v_is_admin
  FROM public.profiles
  WHERE id = v_caller_id;

  IF NOT COALESCE(v_is_admin, false) THEN
    RETURN jsonb_build_object('success', false, 'error', 'Admin access required');
  END IF;

  -- Validate target status
  IF p_status <> ALL(v_allowed) THEN
    RETURN jsonb_build_object('success', false, 'error', 'Invalid order status: ' || p_status);
  END IF;

  -- Apply the update (SECURITY DEFINER bypasses RLS)
  UPDATE public.orders
  SET    status     = p_status,
         updated_at = NOW()
  WHERE  id = p_order_id;

  IF NOT FOUND THEN
    RETURN jsonb_build_object('success', false, 'error', 'Order not found');
  END IF;

  RETURN jsonb_build_object('success', true, 'order_id', p_order_id, 'status', p_status);
END;
$$;

-- Grant: any authenticated user can call it (the function itself enforces is_admin)
REVOKE ALL ON FUNCTION public.admin_update_order_status(UUID, TEXT) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.admin_update_order_status(UUID, TEXT) TO authenticated;
GRANT EXECUTE ON FUNCTION public.admin_update_order_status(UUID, TEXT) TO service_role;

DO $$ BEGIN RAISE NOTICE '[F7] admin_update_order_status() SECURITY DEFINER RPC created'; END $$;

-- Reload schema cache so PostgREST exposes the new function immediately
NOTIFY pgrst, 'reload schema';

DO $$ BEGIN RAISE NOTICE '✅ 20260906000002_admin_order_rpc: applied successfully'; END $$;
