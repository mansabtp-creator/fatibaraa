-- ==============================================================================
-- WALLET FIXES MIGRATION
-- Fatibara 2.0 — 2026-08-22
-- ==============================================================================
-- Fixes three production bugs:
--
--  1. reference_id UUID → TEXT
--     payin.ts stores "TOPUP-<userId>_<amount>_<ts>" (a string) into
--     wallet_transactions.reference_id which was typed UUID.
--     Postgres rejects the cast → DB error → HTTP 500 from the payin endpoint.
--
--  2. Add 'withdrawal_approved' to the type CHECK constraint.
--     wallet_ledger_fix.sql inserts rows with type='withdrawal_approved' for
--     admin approval audit rows, but the original CHECK didn't allow that value.
--
--  3. CREATE FUNCTION get_wallet_balance(p_id, p_type)
--     TransactionalWallet.tsx calls this RPC on the "J'ai déjà saisi mon code
--     PIN" button — but the function never existed, causing a silent failure.
-- ==============================================================================

-- ─── 1. Widen reference_id to TEXT ───────────────────────────────────────────
-- USING clause safely converts existing UUID values to their text equivalent.
-- All downstream code (payin.ts, payment/callback.ts) already treats this field
-- as a text string (TOPUP- prefix matching, pay_id assignment).
ALTER TABLE public.wallet_transactions
  ALTER COLUMN reference_id TYPE TEXT USING reference_id::TEXT;

-- ─── 2. Extend allowed transaction types ────────────────────────────────────
-- Drop the auto-named inline CHECK (Postgres names it <table>_<col>_check).
-- Use IF EXISTS inside a DO block to handle both naming conventions safely.
DO $$ BEGIN
  ALTER TABLE public.wallet_transactions
    DROP CONSTRAINT IF EXISTS wallet_transactions_type_check;
EXCEPTION WHEN undefined_object THEN NULL;
END $$;

-- Also try the alternative auto-generated name format used by older Postgres versions
DO $$ BEGIN
  ALTER TABLE public.wallet_transactions
    DROP CONSTRAINT IF EXISTS "wallet_transactions_type_check1";
EXCEPTION WHEN undefined_object THEN NULL;
END $$;

ALTER TABLE public.wallet_transactions
  ADD CONSTRAINT wallet_transactions_type_check
  CHECK (type IN (
    'purchase', 'sale', 'refund', 'fee', 'delivery_fee',
    'withdrawal', 'deposit', 'boost', 'credit',
    'withdrawal_approved'    -- added: wallet_ledger_fix.sql audit rows
  ));

-- ─── 3. get_wallet_balance RPC ────────────────────────────────────────────────
-- Called from TransactionalWallet.tsx (PIN confirm CTA) to immediately refresh
-- the displayed balance after the user confirms USSD payment.
-- Returns the numeric balance for a user profile or vendor store.
DROP FUNCTION IF EXISTS public.get_wallet_balance(UUID, TEXT);

CREATE OR REPLACE FUNCTION public.get_wallet_balance(p_id UUID, p_type TEXT)
RETURNS NUMERIC
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF p_type = 'vendor' THEN
    RETURN COALESCE(
      (SELECT balance FROM public.stores WHERE id = p_id),
      0
    );
  ELSE
    -- 'user' or 'courier' — both live on profiles.wallet_balance
    RETURN COALESCE(
      (SELECT wallet_balance FROM public.profiles WHERE id = p_id),
      0
    );
  END IF;
END;
$$;

-- Allow logged-in users and service role to call this function.
-- SECURITY DEFINER means the query runs as the function owner (postgres),
-- bypassing any RLS on profiles/stores.
GRANT EXECUTE ON FUNCTION public.get_wallet_balance(UUID, TEXT)
  TO authenticated, service_role;
