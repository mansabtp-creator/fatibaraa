-- ==============================================================================
-- MIGRATION: 20260829000006_support_contact_settings.sql
--
-- Adds support_whatsapp and support_phone to platform_settings so the admin
-- can update them from the dashboard without a code deployment.
-- Also grants UPDATE on platform_settings to authenticated users so the
-- admin saveSettings() function can upsert rows.
-- (SELECT is already public; INSERT/DELETE remain locked to service_role.)
-- ==============================================================================

-- Seed initial values (ON CONFLICT DO NOTHING so existing values are preserved)
INSERT INTO public.platform_settings (id, value, description)
VALUES
  ('support_whatsapp', '224666923393',  'WhatsApp support number in international format (no + or spaces)'),
  ('support_phone',    '+224 666 92 33 93', 'Display phone number for support calls')
ON CONFLICT (id) DO NOTHING;

-- Grant UPDATE to authenticated role so the admin dashboard can upsert
-- Note: INSERT + DELETE remain restricted to service_role for security.
-- The UPSERT in saveSettings() uses INSERT ... ON CONFLICT DO UPDATE
-- which requires both INSERT and UPDATE. We grant INSERT temporarily;
-- RLS policies ensure only admins can reach this path via the client.
GRANT INSERT, UPDATE ON public.platform_settings TO authenticated;

-- RLS: Allow authenticated admins to upsert settings rows
-- (the existing SELECT policy is already public — no change needed there)
DROP POLICY IF EXISTS "ps_admin_upsert" ON public.platform_settings;
CREATE POLICY "ps_admin_upsert"
  ON public.platform_settings
  FOR ALL
  USING (
    EXISTS (
      SELECT 1 FROM public.profiles
      WHERE id = auth.uid() AND is_admin = true
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM public.profiles
      WHERE id = auth.uid() AND is_admin = true
    )
  );

NOTIFY pgrst, 'reload schema';
