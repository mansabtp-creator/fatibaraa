-- ============================================================
-- Migration: Enable Realtime for chat tables
-- ============================================================
-- Root cause: chat_messages and chat_channels were never added
-- to the supabase_realtime publication, so postgres_changes
-- subscriptions silently received nothing.
--
-- REPLICA IDENTITY FULL is required so the old row is available
-- in UPDATE/DELETE payloads (needed for read-receipt updates).
-- ============================================================

-- 1. Set REPLICA IDENTITY FULL so all column values are
--    available in the realtime payload (UPDATE / DELETE events).
ALTER TABLE public.chat_messages REPLICA IDENTITY FULL;
ALTER TABLE public.chat_channels REPLICA IDENTITY FULL;

-- 2. Add both tables to the supabase_realtime publication
--    (idempotent: only adds if not already present).
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_publication_tables
    WHERE pubname = 'supabase_realtime'
      AND schemaname = 'public'
      AND tablename = 'chat_messages'
  ) THEN
    ALTER PUBLICATION supabase_realtime ADD TABLE public.chat_messages;
    RAISE NOTICE 'Added chat_messages to supabase_realtime publication.';
  ELSE
    RAISE NOTICE 'chat_messages already in supabase_realtime publication — skipped.';
  END IF;
END
$$;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_publication_tables
    WHERE pubname = 'supabase_realtime'
      AND schemaname = 'public'
      AND tablename = 'chat_channels'
  ) THEN
    ALTER PUBLICATION supabase_realtime ADD TABLE public.chat_channels;
    RAISE NOTICE 'Added chat_channels to supabase_realtime publication.';
  ELSE
    RAISE NOTICE 'chat_channels already in supabase_realtime publication — skipped.';
  END IF;
END
$$;

-- 3. Ensure RLS policies allow SELECT on chat_messages for
--    authenticated users who are a party to the channel.
--    (This is needed for the Realtime JWT auth check.)
--    Drop and recreate to be safe if it already exists.
DROP POLICY IF EXISTS "chat_messages_realtime_select" ON public.chat_messages;

CREATE POLICY "chat_messages_realtime_select"
  ON public.chat_messages
  FOR SELECT
  TO authenticated
  USING (
    channel_id IN (
      SELECT id FROM public.chat_channels
      WHERE buyer_id = auth.uid()
         OR store_id IN (
           SELECT id FROM public.stores WHERE owner_id = auth.uid()
         )
    )
  );

-- 4. Ensure the channel SELECT policy exists for presence / subscription auth.
DROP POLICY IF EXISTS "chat_channels_select_parties" ON public.chat_channels;

CREATE POLICY "chat_channels_select_parties"
  ON public.chat_channels
  FOR SELECT
  TO authenticated
  USING (
    buyer_id = auth.uid()
    OR store_id IN (
      SELECT id FROM public.stores WHERE owner_id = auth.uid()
    )
  );
