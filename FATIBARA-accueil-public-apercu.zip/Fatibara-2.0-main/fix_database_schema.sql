-- Fix for coupons table schema and missing indices
-- Copy and run this script in the Supabase SQL editor

-- 1. Create the coupons table if it doesn't exist
CREATE TABLE IF NOT EXISTS public.coupons (
  id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  code text UNIQUE NOT NULL,
  discount_percentage numeric,
  discount_percent numeric,
  created_at timestamp with time zone DEFAULT now()
);

-- 2. Safely add missing columns one by one
ALTER TABLE public.coupons ADD COLUMN IF NOT EXISTS store_id uuid REFERENCES public.stores(id) ON DELETE CASCADE;
ALTER TABLE public.coupons ADD COLUMN IF NOT EXISTS usage_limit integer;
ALTER TABLE public.coupons ADD COLUMN IF NOT EXISTS usage_count integer DEFAULT 0;
ALTER TABLE public.coupons ADD COLUMN IF NOT EXISTS min_order_value numeric;
ALTER TABLE public.coupons ADD COLUMN IF NOT EXISTS expires_at timestamp with time zone;
ALTER TABLE public.coupons ADD COLUMN IF NOT EXISTS is_active boolean DEFAULT true;
ALTER TABLE public.coupons ADD COLUMN IF NOT EXISTS discount_percent numeric;
ALTER TABLE public.coupons ADD COLUMN IF NOT EXISTS discount_percentage numeric;

-- 3. Create the indices
CREATE INDEX IF NOT EXISTS idx_coupons_code ON public.coupons(code);
CREATE INDEX IF NOT EXISTS idx_coupons_store ON public.coupons(store_id);

-- 4. Enable RLS and add basic policies
ALTER TABLE public.coupons ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Anyone can see active coupons" ON public.coupons;
CREATE POLICY "Anyone can see active coupons" ON public.coupons FOR SELECT USING (is_active = true);


-- 5. Build platform_logs table since and admin log system needs it
CREATE TABLE IF NOT EXISTS public.platform_logs (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES auth.users(id),
    action TEXT NOT NULL,
    entity_type TEXT NOT NULL,
    entity_id UUID,
    details JSONB,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

ALTER TABLE public.platform_logs ENABLE ROW LEVEL SECURITY;
-- Admins can do anything
CREATE POLICY "Admins can view logs" ON public.platform_logs
FOR SELECT USING (
  EXISTS (
    SELECT 1 FROM public.admins 
    WHERE user_id = auth.uid()
  )
);
CREATE POLICY "Admins can insert logs" ON public.platform_logs
FOR INSERT WITH CHECK (
  EXISTS (
    SELECT 1 FROM public.admins 
    WHERE user_id = auth.uid()
  )
);

