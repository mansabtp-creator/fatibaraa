/**
 * apply_rls_fix.ts — Applies the definitive RLS + RPC fix to Supabase
 * Uses the Supabase pg-meta /query endpoint (available on hosted projects)
 * via the service-role JWT which has SECURITY DEFINER access.
 *
 * Run: npx tsx apply_rls_fix.ts
 */
import * as fs from 'fs';
import * as path from 'path';
import * as dotenv from 'dotenv';

dotenv.config({ path: path.join(process.cwd(), '.env') });
dotenv.config({ path: path.join(process.cwd(), '.env.local'), override: true });

const SUPABASE_URL = (process.env.VITE_SUPABASE_URL ?? '').trim();
const SERVICE_KEY  = (process.env.SUPABASE_SERVICE_ROLE_KEY ?? '').trim();

if (!SUPABASE_URL || !SERVICE_KEY) {
  console.error('❌  VITE_SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY must be set in .env');
  process.exit(1);
}

// Extract project ref from URL: https://<ref>.supabase.co
const projectRef = SUPABASE_URL.match(/https:\/\/([^.]+)\.supabase\.co/)?.[1];
if (!projectRef) {
  console.error('❌  Could not parse project ref from VITE_SUPABASE_URL:', SUPABASE_URL);
  process.exit(1);
}

const MIGRATION_PATH = path.join(
  process.cwd(),
  'supabase/migrations/20260715_definitive_fix_rpc_and_rls.sql'
);
const sql = fs.readFileSync(MIGRATION_PATH, 'utf-8');

// ── Strategy: POST to Supabase pg-meta query endpoint ─────────────────────
// Available at https://<ref>.supabase.co/pg/query (requires service_role JWT)
async function runRawSQL(query: string): Promise<{ error?: string }> {
  const endpoint = `${SUPABASE_URL}/pg/query`;
  const res = await fetch(endpoint, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${SERVICE_KEY}`,
      'apikey': SERVICE_KEY,
    },
    body: JSON.stringify({ query }),
  });

  if (res.ok) return {};
  const body = await res.text();
  return { error: `HTTP ${res.status}: ${body}` };
}

(async () => {
  console.log(`\n🔧  Applying RLS fix to project: ${projectRef}\n`);

  // Run the entire migration as one atomic statement so DDL rolls back on failure
  const result = await runRawSQL(sql);

  if (result.error) {
    console.error('❌  Migration failed:', result.error);
    console.log('\n💡  The /pg/query endpoint requires a direct DB password grant.');
    console.log('    Please apply the migration manually via the Supabase SQL Editor:');
    console.log(`    https://supabase.com/dashboard/project/${projectRef}/sql/new\n`);
    console.log('    Paste the contents of:\n    supabase/migrations/20260715_definitive_fix_rpc_and_rls.sql');
    process.exit(1);
  }

  console.log('✅  Migration applied successfully!');
  console.log('    ▸ All orders RLS policies replaced with flat non-recursive versions');
  console.log('    ▸ Recursive trigger dropped');
  console.log('    ▸ get_vendor_dashboard_metrics fixed to use total_amount column');
  console.log('    ▸ PostgREST schema cache flushed via NOTIFY pgrst');
  console.log('\n🎯  The 42P17 "infinite recursion" error on PATCH /orders is now resolved.');
})();
