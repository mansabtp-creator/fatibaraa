-- FINAL POLISH: Database Triggers & Optimizations
-- Run this in your Supabase SQL Editor

-- 1. Automate stock deduction upon order creation
CREATE OR REPLACE FUNCTION reduce_product_stock()
RETURNS TRIGGER AS $$
BEGIN
    UPDATE products
    SET stock_quantity = stock_quantity - NEW.quantity
    WHERE id = NEW.product_id AND stock_quantity >= NEW.quantity;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

DROP TRIGGER IF EXISTS tr_reduce_stock ON order_items;
CREATE TRIGGER tr_reduce_stock
AFTER INSERT ON order_items
FOR EACH ROW
EXECUTE FUNCTION reduce_product_stock();

-- 2. View for Vendor Dashboard (Fast Stats)
CREATE OR REPLACE VIEW vendor_fast_stats AS
SELECT 
    s.id AS store_id,
    s.owner_id,
    s.store_name,
    COUNT(DISTINCT o.id) AS total_orders,
    SUM(o.total_amount) AS total_revenue
FROM stores s
LEFT JOIN orders o ON o.vendor_id = s.owner_id AND o.status = 'delivered'
GROUP BY s.id, s.owner_id, s.store_name;

-- 3. Enhance Courier Tracking Log (Location tracking support for future phase)
CREATE TABLE IF NOT EXISTS public.courier_locations (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    order_id UUID REFERENCES public.orders(id) ON DELETE CASCADE,
    courier_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE,
    lat DOUBLE PRECISION,
    lng DOUBLE PRECISION,
    recorded_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Enable RLS for locations
ALTER TABLE public.courier_locations ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Couriers can insert own locations" ON public.courier_locations;
CREATE POLICY "Couriers can insert own locations" 
ON public.courier_locations FOR INSERT
WITH CHECK (courier_id = auth.uid());

DROP POLICY IF EXISTS "Users can view tracking of their orders" ON public.courier_locations;
CREATE POLICY "Users can view tracking of their orders" 
ON public.courier_locations FOR SELECT
USING (order_id IN (SELECT id FROM public.orders WHERE user_id = auth.uid() OR vendor_id = auth.uid()));
