-- ==============================================================================
-- SECURE WITHDRAWAL APPROVAL RPC DEFINITION
-- ==============================================================================

CREATE OR REPLACE FUNCTION public.approve_withdrawal(
    p_withdrawal_id UUID
) RETURNS JSONB AS $$
DECLARE
    v_withdrawal RECORD;
BEGIN
    -- Check if auth user is admin
    IF NOT EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND is_admin = true) THEN
        RAISE EXCEPTION 'Unauthorized: Only administrators can approve withdrawals';
    END IF;

    -- Lock withdrawal record for update to prevent concurrent race conditions
    SELECT * INTO v_withdrawal FROM public.withdrawals WHERE id = p_withdrawal_id FOR UPDATE;
    IF v_withdrawal IS NULL THEN
        RAISE EXCEPTION 'Withdrawal not found';
    END IF;

    IF v_withdrawal.status != 'pending' THEN
        RAISE EXCEPTION 'Withdrawal is not pending';
    END IF;

    -- Update withdrawal status to processed
    UPDATE public.withdrawals
    SET status = 'processed',
        processed_at = NOW()
    WHERE id = p_withdrawal_id;

    -- Update recipient statistics
    IF v_withdrawal.store_id IS NOT NULL THEN
        UPDATE public.profiles
        SET total_withdrawn = COALESCE(total_withdrawn, 0) + ROUND(v_withdrawal.amount)
        WHERE id = (SELECT owner_id FROM public.stores WHERE id = v_withdrawal.store_id);
    ELSIF v_withdrawal.profile_id IS NOT NULL THEN
        UPDATE public.profiles
        SET total_withdrawn = COALESCE(total_withdrawn, 0) + ROUND(v_withdrawal.amount)
        WHERE id = v_withdrawal.profile_id;
    END IF;

    RETURN jsonb_build_object('success', true);
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;
