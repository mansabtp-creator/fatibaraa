/**
 * Batch reconciliation — credits ALL stuck pending wallet top-ups.
 * Run: node -r dotenv/config scripts/reconcile-all.mjs
 *
 * Reads VITE_SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY from .env
 */
import { createClient } from '@supabase/supabase-js';

const url = process.env.VITE_SUPABASE_URL ?? '';
const key = process.env.SUPABASE_SERVICE_ROLE_KEY ?? '';

if (!url || !key) {
  console.error('❌ Missing env: VITE_SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY required.');
  process.exit(1);
}

const sb = createClient(url, key, { auth: { persistSession: false, autoRefreshToken: false } });

async function main() {
  // 1. Find all pending deposit/topup transactions
  const { data: txs, error: fetchErr } = await sb
    .from('wallet_transactions')
    .select('id, profile_id, amount, status, type, created_at, reference_text')
    .eq('status', 'pending')
    .in('type', ['deposit', 'topup'])
    .order('created_at', { ascending: false });

  if (fetchErr) {
    console.error('❌ DB fetch error:', fetchErr.message);
    process.exit(1);
  }

  if (!txs || txs.length === 0) {
    console.log('✅ No stuck pending transactions found — nothing to do.');
    return;
  }

  console.log(`\nFound ${txs.length} stuck pending transaction(s):\n`);
  txs.forEach(tx => {
    console.log(`  ${tx.id}  |  ${Number(tx.amount).toLocaleString('fr-FR')} GNF  |  ${tx.type}  |  ${tx.created_at}`);
  });

  // 2. Credit each one via credit_user_wallet (idempotent CAS)
  let successCount = 0;
  let failCount    = 0;

  for (const tx of txs) {
    process.stdout.write(`\n→ Crediting tx ${tx.id} (+${Number(tx.amount).toLocaleString('fr-FR')} GNF) for user ${tx.profile_id}...`);

    const { error: rpcErr } = await sb.rpc('credit_user_wallet', {
      p_user_id: tx.profile_id,
      p_amount:  tx.amount,
      p_tx_id:   tx.id,
      p_pay_id:  null,
    });

    if (rpcErr) {
      console.log(` ❌ FAILED: ${rpcErr.message}`);
      failCount++;
    } else {
      console.log(` ✅ Done`);
      successCount++;
    }
  }

  console.log(`\n─────────────────────────────────`);
  console.log(`Reconciled:  ${successCount} ✅`);
  console.log(`Failed:      ${failCount} ❌`);
  console.log(`Total:       ${txs.length}`);
}

main().catch(err => {
  console.error('❌ Unexpected error:', err);
  process.exit(1);
});
