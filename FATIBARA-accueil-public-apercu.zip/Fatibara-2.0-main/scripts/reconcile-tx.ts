/**
 * Manual Wallet Reconciliation CLI
 * ──────────────────────────────────────────────────────────────────────────────
 * Run via:
 *   npx ts-node scripts/reconcile-tx.ts <TRANSACTION_ID_OR_REFERENCE>
 *
 * Use this when a LengoPay webhook was missed or a top-up is stuck in 'pending'
 * and you need to credit the user's wallet immediately without waiting for a
 * webhook replay.
 *
 * It accepts:
 *   - A wallet_transactions UUID (looks up by primary key `id`)
 *   - A TOPUP- reference string (looks up by `reference_text` column)
 *
 * The script calls `credit_user_wallet` which atomically:
 *   1. Marks the transaction 'completed' (CAS — skips if already done)
 *   2. Credits profiles.wallet_balance
 *   3. Syncs courier_profiles.balance if the courier row exists
 *
 * Requires env vars:
 *   NEXT_PUBLIC_SUPABASE_URL  (or VITE_SUPABASE_URL)
 *   SUPABASE_SERVICE_ROLE_KEY
 *
 * Load them via dotenv: npx ts-node -r dotenv/config scripts/reconcile-tx.ts <REF>
 * ──────────────────────────────────────────────────────────────────────────────
 */

import { createClient } from '@supabase/supabase-js';

const supabaseUrl =
  process.env.NEXT_PUBLIC_SUPABASE_URL ??
  process.env.VITE_SUPABASE_URL ??
  '';

const serviceRoleKey = process.env.SUPABASE_SERVICE_ROLE_KEY ?? '';

if (!supabaseUrl || !serviceRoleKey) {
  console.error(
    '[reconcile] ❌ Missing env vars. Set NEXT_PUBLIC_SUPABASE_URL (or VITE_SUPABASE_URL) and SUPABASE_SERVICE_ROLE_KEY.'
  );
  process.exit(1);
}

const supabase = createClient(supabaseUrl, serviceRoleKey, {
  auth: { persistSession: false, autoRefreshToken: false },
});

const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

async function reconcile(refArg: string): Promise<void> {
  const ref = refArg.trim();

  if (!ref) {
    console.error('[reconcile] ❌ Usage: npx ts-node scripts/reconcile-tx.ts <TX_ID_OR_REF>');
    process.exit(1);
  }

  console.log(`\n[reconcile] Looking up transaction for ref: ${ref}`);

  // ── Step 1: Fetch the transaction ──────────────────────────────────────────
  type TxRow = {
    id: string;
    profile_id: string;
    amount: number;
    status: string;
    description: string | null;
    reference_text: string | null;
  };

  let tx: TxRow | null = null;

  if (UUID_RE.test(ref)) {
    // Exact UUID — look up by primary key
    const { data, error } = await supabase
      .from('wallet_transactions')
      .select('id, profile_id, amount, status, description, reference_text')
      .eq('id', ref)
      .maybeSingle();

    if (error) {
      console.error('[reconcile] ❌ DB error (id lookup):', error.message);
      process.exit(1);
    }
    tx = data as TxRow | null;
  } else {
    // Non-UUID (e.g. TOPUP- reference) — look up by reference_text
    const { data, error } = await supabase
      .from('wallet_transactions')
      .select('id, profile_id, amount, status, description, reference_text')
      .eq('reference_text', ref)
      .maybeSingle();

    if (error) {
      console.error('[reconcile] ❌ DB error (reference_text lookup):', error.message);
      process.exit(1);
    }
    tx = data as TxRow | null;
  }

  if (!tx) {
    console.error(`[reconcile] ❌ No transaction found for ref: ${ref}`);
    process.exit(1);
  }

  console.log(`[reconcile] Found transaction:`);
  console.log(`  id          : ${tx.id}`);
  console.log(`  profile_id  : ${tx.profile_id}`);
  console.log(`  amount      : ${Number(tx.amount).toLocaleString('fr-GN')} GNF`);
  console.log(`  status      : ${tx.status}`);
  console.log(`  description : ${tx.description ?? '—'}`);

  // ── Step 2: Guard against re-processing ───────────────────────────────────
  if (tx.status === 'completed') {
    console.warn('\n[reconcile] ⚠️  Transaction already completed — no action taken.');
    return;
  }

  if (tx.status === 'failed') {
    console.warn('\n[reconcile] ⚠️  Transaction is marked failed. Proceeding with forced credit...');
    // Force: manually set status back to pending so the CAS in credit_user_wallet
    // can match and complete it. This handles the edge case where a webhook first
    // fired a failure and then LengoPay confirmed success out-of-order.
    const { error: resetErr } = await supabase
      .from('wallet_transactions')
      .update({ status: 'pending', updated_at: new Date().toISOString() })
      .eq('id', tx.id);

    if (resetErr) {
      console.error('[reconcile] ❌ Could not reset status to pending:', resetErr.message);
      process.exit(1);
    }
    console.log('[reconcile] Status reset to pending — continuing credit...');
  }

  // ── Step 3: Call credit_user_wallet RPC ───────────────────────────────────
  const { error: rpcErr } = await supabase.rpc('credit_user_wallet', {
    p_user_id: tx.profile_id,
    p_amount:  tx.amount,
    p_tx_id:   tx.id,
    p_pay_id:  null,   // manual reconciliation — no LengoPay pay_id available
  });

  if (rpcErr) {
    console.error('\n[reconcile] ❌ credit_user_wallet RPC failed:', rpcErr.message);
    process.exit(1);
  }

  console.log(`\n[reconcile] ✅ Successfully reconciled:`);
  console.log(`  Transaction : ${tx.id}`);
  console.log(`  User        : ${tx.profile_id}`);
  console.log(`  Amount      : +${Number(tx.amount).toLocaleString('fr-GN')} GNF`);
}

const arg = process.argv[2] ?? '';
reconcile(arg).catch((err) => {
  console.error('[reconcile] ❌ Unexpected error:', err);
  process.exit(1);
});
