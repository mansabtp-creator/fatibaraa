/**
 * execute-seed-prod.mjs
 * Executes seed_beta.sql against linked production DB by splitting into
 * individual statements, bypassing the prepared-statement single-command limit.
 * Usage: node scripts/execute-seed-prod.mjs
 */
import { readFileSync, writeFileSync, unlinkSync } from 'fs';
import { execSync } from 'child_process';
import { fileURLToPath } from 'url';
import path from 'path';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const SEED_FILE = path.join(__dirname, '..', 'supabase', 'seed_beta.sql');
const sql = readFileSync(SEED_FILE, 'utf8');

function splitStatements(sql) {
  const statements = [];
  let current = '';
  let i = 0;
  let inDollarQuote = false;
  let dollarTag = '';
  let inSingleQuote = false;

  while (i < sql.length) {
    if (!inSingleQuote && sql[i] === '$') {
      const rest = sql.slice(i);
      const match = rest.match(/^\$([A-Za-z_]*)\$/);
      if (match) {
        const tag = match[0];
        if (!inDollarQuote) { inDollarQuote = true; dollarTag = tag; current += tag; i += tag.length; continue; }
        else if (tag === dollarTag) { inDollarQuote = false; dollarTag = ''; current += tag; i += tag.length; continue; }
      }
    }
    if (!inDollarQuote && sql[i] === "'") { inSingleQuote = !inSingleQuote; current += sql[i++]; continue; }
    if (!inDollarQuote && !inSingleQuote && sql[i] === '-' && sql[i+1] === '-') {
      const end = sql.indexOf('\n', i);
      current += end === -1 ? sql.slice(i) : sql.slice(i, end + 1);
      i = end === -1 ? sql.length : end + 1;
      continue;
    }
    if (!inDollarQuote && !inSingleQuote && sql[i] === ';') {
      current += ';';
      const trimmed = current.trim();
      if (trimmed && trimmed !== ';') statements.push(trimmed);
      current = ''; i++; continue;
    }
    current += sql[i++];
  }
  const trimmed = current.trim();
  if (trimmed) statements.push(trimmed);
  return statements;
}

const statements = splitStatements(sql);
console.log(`\n══════════════════════════════════`);
console.log(`  Beta Seed → Production`);
console.log(`  ${statements.length} statements`);
console.log(`══════════════════════════════════\n`);

let passed = 0, failed = 0;
const errors = [];

for (let idx = 0; idx < statements.length; idx++) {
  const stmt = statements[idx];
  const stripped = stmt.replace(/--[^\n]*/g, '').trim();
  if (!stripped || stripped === ';') { passed++; continue; }
  const preview = stmt.slice(0, 70).replace(/\n/g, ' ');
  process.stdout.write(`  [${idx+1}/${statements.length}] ${preview}... `);
  const tmpFile = `/tmp/fseed_${idx}.sql`;
  try {
    writeFileSync(tmpFile, stmt);
    execSync(`npx supabase db query --linked -f "${tmpFile}"`, { cwd: path.join(__dirname, '..'), stdio: 'pipe' });
    unlinkSync(tmpFile);
    console.log('✅'); passed++;
  } catch(err) {
    try { unlinkSync(tmpFile); } catch {}
    const msg = (err.stderr?.toString() || err.message || '').slice(0, 400);
    if (msg.includes('already exists') || msg.includes('duplicate key') || msg.includes('skipping')) {
      console.log('⚠️  (skip)'); passed++;
    } else {
      console.log('❌'); errors.push({ idx: idx+1, preview, error: msg }); failed++;
    }
  }
}

console.log(`\n══════════════════════════════════`);
console.log(`  ${passed} passed · ${failed} failed`);
console.log(`══════════════════════════════════`);
if (errors.length) { errors.forEach(e => console.log(`\n• [${e.idx}] ${e.preview}\n  ${e.error}`)); process.exit(1); }
else console.log('\n  🎉 Beta seed applied to production!\n');
