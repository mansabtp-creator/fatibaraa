-- Phase 5: Advanced Analytics & Merchant Stock Alerts

-- 1. Product Views Tracking
CREATE TABLE IF NOT EXISTS public.product_views (
    id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
    product_id uuid REFERENCES public.products(id) ON DELETE CASCADE NOT NULL,
    user_id uuid REFERENCES auth.users(id) ON DELETE SET NULL,
    viewer_session_id text, -- For anonymous tracking
    viewed_at timestamp with time zone DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- Index for analytics performance
CREATE INDEX IF NOT EXISTS idx_product_views_product_id ON public.product_views(product_id);
CREATE INDEX IF NOT EXISTS idx_product_views_viewed_at ON public.product_views(viewed_at);

-- 2. Store Analytics Table (Aggregated for performance)
-- Instead of a view, a table helped by triggers for fast dashboard loads
CREATE TABLE IF NOT EXISTS public.vendor_analytics (
    vendor_id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
    total_views bigint DEFAULT 0,
    total_sales bigint DEFAULT 0,
    total_revenue numeric DEFAULT 0,
    last_updated timestamp with time zone DEFAULT timezone('utc'::text, now())
);

-- 3. Stock Level Triggers
-- Automatically subtract stock on order_items insertion and check for alerts
CREATE OR REPLACE FUNCTION handle_stock_on_order()
RETURNS TRIGGER AS $$
DECLARE
    current_stock INTEGER;
    v_id UUID;
    p_title TEXT;
BEGIN
    -- 1. Decrement stock
    UPDATE public.products 
    SET stock_quantity = stock_quantity - NEW.quantity
    WHERE id = NEW.product_id
    RETURNING stock_quantity, title, (SELECT owner_id FROM public.stores WHERE id = products.store_id) INTO current_stock, p_title, v_id;

    -- 2. Check for low stock alert (Threshold: 5)
    IF current_stock <= 5 AND current_stock >= 0 THEN
        INSERT INTO public.notifications (user_id, type, title, message)
        VALUES (
            v_id, 
            'stock_alert', 
            'Alerte de Stock Bas !', 
            'Le produit "' || p_title || '" n''a plus que ' || current_stock || ' exemplaires en stock. Pensez à réapprovisionner.'
        );
    END IF;

    -- 3. Mark if out of stock
    IF current_stock <= 0 THEN
        UPDATE public.products SET is_active = false WHERE id = NEW.product_id;
    END IF;

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS on_order_item_inserted ON public.order_items;
CREATE TRIGGER on_order_item_inserted
    AFTER INSERT ON public.order_items
    FOR EACH ROW
    EXECUTE FUNCTION handle_stock_on_order();

-- 4. RLS for Analytics
ALTER TABLE public.product_views ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.vendor_analytics ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Anyone can record a view" ON public.product_views;
CREATE POLICY "Anyone can record a view" ON public.product_views FOR INSERT WITH CHECK (true);

DROP POLICY IF EXISTS "Vendors can view their own product analytics" ON public.product_views;
CREATE POLICY "Vendors can view their own product analytics" ON public.product_views FOR SELECT 
USING (EXISTS (
    SELECT 1 FROM public.products p
    JOIN public.stores s ON p.store_id = s.id
    WHERE p.id = product_views.product_id AND s.owner_id = auth.uid()
));

DROP POLICY IF EXISTS "Vendors can view their own summary analytics" ON public.vendor_analytics;
CREATE POLICY "Vendors can view their own summary analytics" ON public.vendor_analytics FOR SELECT 
USING (vendor_id = auth.uid());

-- 5. Realtime for notifications is already enabled in standard setup
