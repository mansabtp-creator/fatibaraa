-- ==============================================================================
-- FATIBARA MASTER SCHEMA FIX (V3)
-- Run this in your Supabase SQL Editor to resolve all product upload errors
-- and ensure the database handles branding correctly.
-- ==============================================================================

-- 1. FIX PRODUCTS TABLE
ALTER TABLE public.products ADD COLUMN IF NOT EXISTS scheduled_at timestamp with time zone;
ALTER TABLE public.products ADD COLUMN IF NOT EXISTS status text NOT NULL DEFAULT 'published';
ALTER TABLE public.products ADD COLUMN IF NOT EXISTS low_stock_threshold integer DEFAULT 5;
ALTER TABLE public.products ADD COLUMN IF NOT EXISTS is_digital boolean DEFAULT false;
ALTER TABLE public.products ADD COLUMN IF NOT EXISTS download_url text;
ALTER TABLE public.products ADD COLUMN IF NOT EXISTS variations jsonb DEFAULT '[]'::jsonb;
ALTER TABLE public.products ADD COLUMN IF NOT EXISTS volume_discount_qty integer;
ALTER TABLE public.products ADD COLUMN IF NOT EXISTS volume_discount_percent numeric;
ALTER TABLE public.products ADD COLUMN IF NOT EXISTS buying_price_gnf numeric;
ALTER TABLE public.products ADD COLUMN IF NOT EXISTS seo_description text;
ALTER TABLE public.products ADD COLUMN IF NOT EXISTS updated_at timestamp with time zone DEFAULT now();

-- FIX ORDERS TABLE (Missing Columns)
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS customer_name text;
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS items_count integer;
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS financial_status text DEFAULT 'pending';
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS tracking_number text;
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS delivery_otp text;
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS vendor_id uuid REFERENCES auth.users(id);

-- 2. FIX STORES TABLE
ALTER TABLE public.stores ADD COLUMN IF NOT EXISTS payout_orange_money text;
ALTER TABLE public.stores ADD COLUMN IF NOT EXISTS payout_mtn_money text;
ALTER TABLE public.stores ADD COLUMN IF NOT EXISTS store_status text DEFAULT 'active';
ALTER TABLE public.stores ADD COLUMN IF NOT EXISTS global_sale_active boolean DEFAULT false;
ALTER TABLE public.stores ADD COLUMN IF NOT EXISTS global_sale_percent numeric;
ALTER TABLE public.stores ADD COLUMN IF NOT EXISTS updated_at timestamp with time zone DEFAULT now();

-- 3. ENSURE METRICS & TRIGGERS EXIST
CREATE OR REPLACE FUNCTION public.handle_updated_at()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Products Trigger
DROP TRIGGER IF EXISTS set_products_updated_at ON public.products;
CREATE TRIGGER set_products_updated_at
    BEFORE UPDATE ON public.products
    FOR EACH ROW
    EXECUTE FUNCTION public.handle_updated_at();

-- Stores Trigger
DROP TRIGGER IF EXISTS set_stores_updated_at ON public.stores;
CREATE TRIGGER set_stores_updated_at
    BEFORE UPDATE ON public.stores
    FOR EACH ROW
    EXECUTE FUNCTION public.handle_updated_at();

-- 4. FIX PROFILES TABLE (If needed for admin/user roles)
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS is_admin boolean DEFAULT false;
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS full_name text;

-- 5. RELOAD SCHEMA CACHE (IMPORTANT)
-- This tells PostgREST that the columns have been added
NOTIFY pgrst, 'reload schema';

-- 6. GRANT PERMISSIONS (Just in case RLS is blocking but returning vague errors)
GRANT ALL ON public.products TO authenticated;
GRANT ALL ON public.stores TO authenticated;
GRANT ALL ON public.profiles TO authenticated;

-- 7. CLEANUP CACHE HINT
COMMENT ON TABLE public.products IS 'FATIBARA Products Table';
