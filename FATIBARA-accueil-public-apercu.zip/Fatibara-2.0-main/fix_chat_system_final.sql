-- ==============================================================================
-- FATIBARA CHAT SYSTEM & SCHEMA RECONCILIATION FIX
-- Run this in your Supabase SQL Editor to resolve all chat errors,
-- create missing store_staff schema components, and align database columns.
-- ==============================================================================

-- 1. CREATE STORE STAFF TABLE (IF MISSING)
CREATE TABLE IF NOT EXISTS public.store_staff (
  id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  store_id uuid REFERENCES public.stores(id) ON DELETE CASCADE,
  user_id uuid REFERENCES public.profiles(id) ON DELETE CASCADE,
  role text NOT NULL CHECK (role IN ('owner', 'manager', 'staff')),
  created_at timestamp with time zone DEFAULT now(),
  UNIQUE(store_id, user_id)
);

-- ENABLE RLS ON STORE STAFF
ALTER TABLE public.store_staff ENABLE ROW LEVEL SECURITY;

-- POLICIES FOR STORE STAFF
DROP POLICY IF EXISTS "Store staff are viewable by themselves or owners" ON public.store_staff;
CREATE POLICY "Store staff are viewable by themselves or owners" ON public.store_staff
  FOR SELECT USING (
    user_id = auth.uid() OR
    EXISTS (
      SELECT 1 FROM public.stores
      WHERE stores.id = store_staff.store_id
      AND stores.owner_id = auth.uid()
    )
  );

DROP POLICY IF EXISTS "Store owners can manage staff" ON public.store_staff;
CREATE POLICY "Store owners can manage staff" ON public.store_staff
  FOR ALL USING (
    EXISTS (
      SELECT 1 FROM public.stores
      WHERE stores.id = store_staff.store_id
      AND stores.owner_id = auth.uid()
    )
  );

-- 2. CREATE check_store_role FUNCTION (IF MISSING OR BROKEN)
CREATE OR REPLACE FUNCTION public.check_store_role(store_id_param uuid, role_param text) 
RETURNS boolean AS $$
BEGIN
  -- Check if user is owner of the store
  IF EXISTS (
    SELECT 1 FROM public.stores 
    WHERE id = store_id_param 
    AND owner_id = auth.uid()
  ) THEN
    RETURN TRUE;
  END IF;

  -- Check if user is staff of the store with the role or higher
  RETURN EXISTS (
    SELECT 1 FROM public.store_staff 
    WHERE store_id = store_id_param 
    AND user_id = auth.uid() 
    AND (role = role_param OR role = 'owner')
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- 3. ALIGN chat_channels TABLE SCHEMA
-- Add missing last_message and last_message_at columns
ALTER TABLE public.chat_channels ADD COLUMN IF NOT EXISTS last_message text;
ALTER TABLE public.chat_channels ADD COLUMN IF NOT EXISTS last_message_at timestamp with time zone DEFAULT now();
ALTER TABLE public.chat_channels ADD COLUMN IF NOT EXISTS product_id uuid;

-- Add or repair the foreign key constraint to products table
ALTER TABLE public.chat_channels DROP CONSTRAINT IF EXISTS chat_channels_product_id_fkey;
ALTER TABLE public.chat_channels 
  ADD CONSTRAINT chat_channels_product_id_fkey 
  FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE SET NULL;

-- ENABLE RLS ON CHAT CHANNELS
ALTER TABLE public.chat_channels ENABLE ROW LEVEL SECURITY;

-- POLICIES FOR CHAT CHANNELS
DROP POLICY IF EXISTS "Users can view their own chat channels" ON public.chat_channels;
CREATE POLICY "Users can view their own chat channels" ON public.chat_channels
  FOR SELECT USING (
    buyer_id = auth.uid() OR 
    public.check_store_role(store_id, 'staff')
  );

DROP POLICY IF EXISTS "Users can create their own chat channels" ON public.chat_channels;
CREATE POLICY "Users can create their own chat channels" ON public.chat_channels
  FOR INSERT WITH CHECK (
    buyer_id = auth.uid() OR
    public.check_store_role(store_id, 'staff')
  );

DROP POLICY IF EXISTS "Users can update their own chat channels" ON public.chat_channels;
CREATE POLICY "Users can update their own chat channels" ON public.chat_channels
  FOR UPDATE USING (
    buyer_id = auth.uid() OR
    public.check_store_role(store_id, 'staff')
  ) WITH CHECK (
    buyer_id = auth.uid() OR
    public.check_store_role(store_id, 'staff')
  );

-- 4. RESOLVE CONFLICTING chat_messages SCHEMA
-- If the existing chat_messages table contains old columns (like chat_id and text instead of channel_id and message),
-- rename the conflicting table to legacy_chat_messages to preserve data safety and create the correct table structure.
DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'chat_messages' AND column_name = 'chat_id'
  ) THEN
    ALTER TABLE IF EXISTS public.chat_messages RENAME TO legacy_chat_messages;
  END IF;
END $$;

-- CREATE CORRECT chat_messages TABLE
CREATE TABLE IF NOT EXISTS public.chat_messages (
  id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  channel_id uuid REFERENCES public.chat_channels(id) ON DELETE CASCADE,
  sender_id uuid REFERENCES auth.users(id) ON DELETE CASCADE,
  message text NOT NULL,
  is_read boolean DEFAULT false,
  created_at timestamp with time zone DEFAULT now(),
  image_url text,
  metadata jsonb DEFAULT '{}'::jsonb
);

-- ENABLE RLS ON CHAT MESSAGES
ALTER TABLE public.chat_messages ENABLE ROW LEVEL SECURITY;

-- POLICIES FOR CHAT MESSAGES
DROP POLICY IF EXISTS "Users can view messages in their channels" ON public.chat_messages;
CREATE POLICY "Users can view messages in their channels" ON public.chat_messages
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM public.chat_channels
      WHERE chat_channels.id = chat_messages.channel_id
      AND (chat_channels.buyer_id = auth.uid() OR public.check_store_role(chat_channels.store_id, 'staff'))
    )
  );

DROP POLICY IF EXISTS "Users can send messages to their channels" ON public.chat_messages;
CREATE POLICY "Users can send messages to their channels" ON public.chat_messages
  FOR INSERT WITH CHECK (
    sender_id = auth.uid() AND
    EXISTS (
      SELECT 1 FROM public.chat_channels
      WHERE chat_channels.id = chat_messages.channel_id
      AND (chat_channels.buyer_id = auth.uid() OR public.check_store_role(chat_channels.store_id, 'staff'))
    )
  );

DROP POLICY IF EXISTS "Users can update messages in their channels" ON public.chat_messages;
CREATE POLICY "Users can update messages in their channels" ON public.chat_messages
  FOR UPDATE USING (
    EXISTS (
      SELECT 1 FROM public.chat_channels
      WHERE chat_channels.id = chat_messages.channel_id
      AND (chat_channels.buyer_id = auth.uid() OR public.check_store_role(chat_channels.store_id, 'staff'))
    )
  ) WITH CHECK (
    EXISTS (
      SELECT 1 FROM public.chat_channels
      WHERE chat_channels.id = chat_messages.channel_id
      AND (chat_channels.buyer_id = auth.uid() OR public.check_store_role(chat_channels.store_id, 'staff'))
    )
  );

-- 5. NOTIFY POSTGREST SCHEMA CACHE (RELOAD)
NOTIFY pgrst, 'reload schema';

-- 6. GRANT EXPLICIT ACCESS TO ALL RELEVANT TABLES
GRANT ALL ON public.store_staff TO authenticated;
GRANT ALL ON public.chat_channels TO authenticated;
GRANT ALL ON public.chat_messages TO authenticated;
