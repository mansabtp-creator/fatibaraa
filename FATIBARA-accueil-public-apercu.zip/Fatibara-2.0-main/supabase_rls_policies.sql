-- FATIBARA ELITE: PHASE 4 - FORTRESS RLS POLICIES
-- This script hardens the database against unauthorized access and ensures data integrity.

-- 1. ENABLE RLS ON ALL TABLES
ALTER TABLE public.products ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.stores ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.order_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.cart_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_wishlists ENABLE ROW LEVEL SECURITY;
-- ALTER TABLE public.payout_settings ENABLE ROW LEVEL SECURITY;

-- 2. PRODUCTS: READ FOR ALL, WRITE FOR STORE OWNERS ONLY
DROP POLICY IF EXISTS "Products are viewable by everyone" ON public.products;
CREATE POLICY "Products are viewable by everyone" 
ON public.products FOR SELECT 
USING (true);

DROP POLICY IF EXISTS "Vendors can manage their own products" ON public.products;
CREATE POLICY "Vendors can manage their own products" 
ON public.products FOR ALL 
USING (
  EXISTS (
    SELECT 1 FROM public.stores 
    WHERE stores.id = products.store_id 
    AND stores.owner_id = auth.uid()
  )
)
WITH CHECK (
  EXISTS (
    SELECT 1 FROM public.stores 
    WHERE stores.id = products.store_id 
    AND stores.owner_id = auth.uid()
  )
  AND (price_gnf >= 0) -- PRICE POISONING GUARD
);

-- 2.1 STORES: READ ALL, UPDATE OWNER ONLY
DROP POLICY IF EXISTS "Stores are viewable by everyone" ON public.stores;
CREATE POLICY "Stores are viewable by everyone" ON public.stores FOR SELECT USING (true);

DROP POLICY IF EXISTS "Owners can update their stores" ON public.stores;
CREATE POLICY "Owners can update their stores" ON public.stores FOR UPDATE 
USING (owner_id = auth.uid())
WITH CHECK (
  owner_id = auth.uid() AND
  owner_id = (SELECT s.owner_id FROM public.stores s WHERE s.id = stores.id) -- PREVENT OWNER HIJACKING
);

-- 3. ORDERS: CUSTOMERS, VENDORS, AND COURIERS
DROP POLICY IF EXISTS "Users can view their own orders" ON public.orders;
CREATE POLICY "Users can view their own orders" 
ON public.orders FOR SELECT 
USING (
  auth.uid() = user_id 
  OR auth.uid() = vendor_id 
  OR auth.uid() = courier_id 
  OR (status = 'ready_for_pickup' AND EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND courier_status IS NOT NULL))
);

DROP POLICY IF EXISTS "Terminally locked orders cannot be modified" ON public.orders;
CREATE POLICY "Terminally locked orders cannot be modified"
ON public.orders FOR UPDATE
USING (
  (
    auth.uid() = user_id 
    OR auth.uid() = vendor_id 
    OR auth.uid() = courier_id
    OR (
      status = 'ready_for_pickup' 
      AND courier_id IS NULL 
      AND EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND courier_status IS NOT NULL)
    )
  )
  AND status NOT IN ('delivered', 'cancelled')
)
WITH CHECK (
  -- Ensure user_id and vendor_id are never changed after creation
  user_id = (SELECT o.user_id FROM public.orders o WHERE o.id = orders.id) AND
  vendor_id = (SELECT o.vendor_id FROM public.orders o WHERE o.id = orders.id) AND
  -- Ensure courier_id can only be set to the authenticated user's ID (or not changed/cleared by admin)
  (courier_id IS NULL OR courier_id = (SELECT o.courier_id FROM public.orders o WHERE o.id = orders.id) OR courier_id = auth.uid()) AND
  -- Enforce transition rules if status is changing
  (
    CASE (SELECT o.status FROM public.orders o WHERE o.id = orders.id)
      WHEN 'pending' THEN status IN ('accepted', 'confirmed', 'cancelled', 'pending')
      WHEN 'accepted' THEN status IN ('preparing', 'cancelled', 'accepted')
      WHEN 'confirmed' THEN status IN ('preparing', 'cancelled', 'confirmed')
      WHEN 'preparing' THEN status IN ('ready_for_pickup', 'preparing')
      WHEN 'ready_for_pickup' THEN status IN ('picked_up', 'in_transit', 'ready_for_pickup')
      WHEN 'picked_up' THEN status IN ('in_transit', 'picked_up')
      WHEN 'in_transit' THEN status IN ('arriving_soon', 'delivered', 'cancelled', 'in_transit')
      WHEN 'arriving_soon' THEN status IN ('delivered', 'cancelled', 'arriving_soon')
      ELSE true 
    END
  )
);

-- 3.1 ORDER ITEMS: READ PERMISSION DERIVED FROM ORDERS
DROP POLICY IF EXISTS "Users can view their own order items" ON public.order_items;
CREATE POLICY "Users can view their own order items" 
ON public.order_items FOR SELECT 
USING (
  EXISTS (
    SELECT 1 FROM public.orders 
    WHERE orders.id = order_items.order_id 
    AND (
      orders.user_id = auth.uid() 
      OR orders.vendor_id = auth.uid() 
      OR orders.courier_id = auth.uid()
      OR (orders.status = 'ready_for_pickup' AND EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND courier_status IS NOT NULL))
    )
  )
);

DROP POLICY IF EXISTS "Users can create order items for their orders" ON public.order_items;
CREATE POLICY "Users can create order items for their orders" 
ON public.order_items FOR INSERT 
WITH CHECK (
  EXISTS (
    SELECT 1 FROM public.orders 
    WHERE orders.id = order_items.order_id 
    AND orders.user_id = auth.uid()
  )
);

-- 4. CART & WISHLIST: STRICT OWNERSHIP
DROP POLICY IF EXISTS "Users can manage their own cart" ON public.cart_items;
CREATE POLICY "Users can manage their own cart" 
ON public.cart_items FOR ALL 
USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "Users can manage their own wishlist" ON public.user_wishlists;
CREATE POLICY "Users can manage their own wishlist" 
ON public.user_wishlists FOR ALL 
USING (auth.uid() = user_id);

-- 5. PAYOUT SETTINGS: PRIVATE TO OWNER (Commented out because table does not exist)
-- DROP POLICY IF EXISTS "Payout settings are private" ON public.payout_settings;
-- CREATE POLICY "Payout settings are private" 
-- ON public.payout_settings FOR ALL 
-- USING (auth.uid() = user_id);

-- 6. ANALYTICS: ANONYMIZED & SECURE
ALTER TABLE public.product_views ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Anyone can record a view" ON public.product_views;
CREATE POLICY "Anyone can record a view" ON public.product_views FOR INSERT WITH CHECK (true);

DROP POLICY IF EXISTS "Only store owners can see their views" ON public.product_views;
CREATE POLICY "Only store owners can see their views" ON public.product_views FOR SELECT USING (
  EXISTS (
    SELECT 1 FROM public.products p 
    JOIN public.stores s ON p.store_id = s.id 
    WHERE p.id = product_views.product_id AND s.owner_id = auth.uid()
  )
);

ALTER TABLE public.cart_events ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Users can insert their own cart events" ON public.cart_events;
CREATE POLICY "Users can insert their own cart events" ON public.cart_events FOR INSERT WITH CHECK (auth.uid() = user_id OR user_id IS NULL);

DROP POLICY IF EXISTS "Users and vendors can view relevant cart events" ON public.cart_events;
CREATE POLICY "Users and vendors can view relevant cart events" ON public.cart_events FOR SELECT USING (
  auth.uid() = user_id OR 
  EXISTS (SELECT 1 FROM public.stores WHERE stores.id = cart_events.store_id AND stores.owner_id = auth.uid())
);

-- 7. ANONYMIZED GLOBAL PULSE (for Social Proof)
CREATE TABLE IF NOT EXISTS public.public_pulse_events (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_name TEXT NOT NULL,
  item_name TEXT NOT NULL,
  location TEXT NOT NULL,
  created_at TIMESTAMPTZ DEFAULT now()
);

-- Pulse events are viewable by everyone
ALTER TABLE public.public_pulse_events ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Pulse is public" ON public.public_pulse_events;
CREATE POLICY "Pulse is public" ON public.public_pulse_events FOR SELECT USING (true);

-- Trigger to populate pulse from new orders
CREATE OR REPLACE FUNCTION public.handle_new_order_pulse()
RETURNS TRIGGER AS $$
DECLARE
  first_item_name TEXT;
BEGIN
  -- Get the first item name for the pulse
  SELECT products.title INTO first_item_name 
  FROM public.order_items 
  JOIN public.products ON order_items.product_id = products.id
  WHERE order_items.order_id = NEW.id
  LIMIT 1;

  INSERT INTO public.public_pulse_events (user_name, item_name, location)
  VALUES (
    split_part(NEW.customer_name, ' ', 1), 
    COALESCE(first_item_name, 'un article Elite'),
    COALESCE((NEW.shipping_address->>'commune'), 'Conakry')
  );
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE TRIGGER on_order_created_pulse
  AFTER INSERT ON public.orders
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_order_pulse();

-- 9. AUTO-TIMESTAMPS FOR INTEGRITY
CREATE OR REPLACE FUNCTION public.update_timestamp()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER update_order_timestamp
  BEFORE UPDATE ON public.orders
  FOR EACH ROW EXECUTE FUNCTION public.update_timestamp();

CREATE TRIGGER update_product_timestamp
  BEFORE UPDATE ON public.products
  FOR EACH ROW EXECUTE FUNCTION public.update_timestamp();
