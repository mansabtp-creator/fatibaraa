-- ==============================================================================
-- COURIER BATCH ACCEPTANCE MIGRATION
-- Fatibara 2.0 — Courier Job Board: 2026-08
-- ==============================================================================
-- Defines accept_order_batch(p_order_ids, p_courier_id):
--   • Atomically assigns a list of pool orders to a courier
--   • Guards against concurrent double-assignment via FOR UPDATE SKIP LOCKED
--   • Enforces a maximum of 5 concurrent in_transit orders per courier
--   • Returns JSONB: { accepted: uuid[], skipped: uuid[], error?: text }
--
-- Also adds shipping_address.commune index to support Job Board area filtering.
-- ==============================================================================

-- ─── 1. ENSURE shipping_address COLUMN EXISTS ─────────────────────────────────
-- shipping_address is JSONB in the live DB. Add it idempotently for safety.
ALTER TABLE public.orders
ADD COLUMN IF NOT EXISTS shipping_address JSONB DEFAULT NULL;

-- ─── 2. GIN INDEX FOR COMMUNE-BASED FILTERING ─────────────────────────────────
-- Allows fast JSONB path queries like: shipping_address->>'commune' = 'Kaloum'
CREATE INDEX IF NOT EXISTS idx_orders_shipping_commune
ON public.orders USING GIN (shipping_address jsonb_path_ops);

-- ─── 3. accept_order_batch RPC ────────────────────────────────────────────────
DROP FUNCTION IF EXISTS public.accept_order_batch(UUID[], UUID);

CREATE OR REPLACE FUNCTION public.accept_order_batch(
    p_order_ids  UUID[],
    p_courier_id UUID
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_courier         RECORD;
    v_active_count    INT;
    v_max_concurrent  CONSTANT INT := 5;
    v_accepted        UUID[] := '{}';
    v_skipped         UUID[]  := '{}';
    v_order           RECORD;
    v_order_id        UUID;
BEGIN
    -- ── Guard 1: Caller must be the courier (or service-role bypasses via DEFINER) ──
    IF auth.uid() IS NOT NULL AND auth.uid() != p_courier_id THEN
        RAISE EXCEPTION 'Unauthorized: courier_id must match authenticated user';
    END IF;

    -- ── Guard 2: Courier must exist and be eligible ───────────────────────────
    SELECT id, profile_type, courier_status, is_courier_online, license_plate_number
    INTO v_courier
    FROM public.profiles
    WHERE id = p_courier_id;

    IF v_courier IS NULL THEN
        RAISE EXCEPTION 'Courier profile not found';
    END IF;

    IF v_courier.profile_type != 'courier' THEN
        RAISE EXCEPTION 'Profile is not a courier';
    END IF;

    -- ── Guard 3: Capacity check ───────────────────────────────────────────────
    -- Count how many orders this courier currently has in_transit
    SELECT COUNT(*) INTO v_active_count
    FROM public.orders
    WHERE courier_id   = p_courier_id
      AND status       = 'in_transit';

    IF v_active_count + array_length(p_order_ids, 1) > v_max_concurrent THEN
        RETURN jsonb_build_object(
            'success',  false,
            'accepted', '[]'::jsonb,
            'skipped',  '[]'::jsonb,
            'error',    format(
                'Capacity exceeded: courier has %s active orders. Max concurrent = %s. ' ||
                'Cannot accept %s more.',
                v_active_count,
                v_max_concurrent,
                array_length(p_order_ids, 1)
            )
        );
    END IF;

    -- ── Per-order atomic assignment ───────────────────────────────────────────
    FOREACH v_order_id IN ARRAY p_order_ids
    LOOP
        -- Lock the row; SKIP LOCKED means a concurrent courier racing for the same
        -- order will simply find zero rows here and skip rather than deadlock.
        SELECT id, status, courier_id
        INTO v_order
        FROM public.orders
        WHERE id         = v_order_id
          AND status     = 'ready_for_pickup'
          AND courier_id IS NULL
        FOR UPDATE SKIP LOCKED;

        IF v_order IS NULL THEN
            -- Order was already taken or is not in the right state
            v_skipped := array_append(v_skipped, v_order_id);
            CONTINUE;
        END IF;

        -- Assign the order
        UPDATE public.orders
        SET courier_id = p_courier_id,
            status     = 'in_transit',
            updated_at = NOW()
        WHERE id = v_order_id;

        v_accepted := array_append(v_accepted, v_order_id);
    END LOOP;

    -- ── Return result ─────────────────────────────────────────────────────────
    RETURN jsonb_build_object(
        'success',  array_length(v_accepted, 1) > 0,
        'accepted', to_jsonb(v_accepted),
        'skipped',  to_jsonb(v_skipped),
        'error',    NULL
    );

EXCEPTION WHEN OTHERS THEN
    RETURN jsonb_build_object(
        'success', false,
        'accepted', '[]'::jsonb,
        'skipped',  '[]'::jsonb,
        'error',    SQLERRM
    );
END;
$$;

-- Grant execution rights to authenticated users
GRANT EXECUTE ON FUNCTION public.accept_order_batch(UUID[], UUID) TO authenticated;

-- ─── 4. COMMENTS ─────────────────────────────────────────────────────────────
COMMENT ON FUNCTION public.accept_order_batch(UUID[], UUID) IS
  'Atomically accepts a list of pool orders for a courier.
   Guards: caller auth match, max 5 concurrent in_transit orders.
   Uses FOR UPDATE SKIP LOCKED to prevent double-assignment race conditions.
   Returns JSONB { success, accepted: uuid[], skipped: uuid[], error?: text }.';
