-- Adding product context to chat channels
ALTER TABLE public.chat_channels ADD COLUMN IF NOT EXISTS product_id uuid REFERENCES public.products(id) ON DELETE SET NULL;
