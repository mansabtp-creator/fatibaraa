-- 1. FIX USER VISIBILITY (RLS)
-- This allows users with is_admin = true to see all other profiles
DROP POLICY IF EXISTS "Admins can view all profiles" ON public.profiles;
CREATE POLICY "Admins can view all profiles" 
ON public.profiles 
FOR SELECT 
USING (
  (SELECT is_admin FROM public.profiles WHERE id = auth.uid()) = true
);

-- 2. CREATE PLATFORM SETTINGS TABLE (Force Clean State)
DROP TABLE IF EXISTS public.platform_settings;
CREATE TABLE public.platform_settings (
    id TEXT PRIMARY KEY,
    value TEXT NOT NULL,
    description TEXT,
    updated_at TIMESTAMPTZ DEFAULT now()
);

-- 3. SEED INITIAL SETTINGS
INSERT INTO public.platform_settings (id, value, description) VALUES 
('commission_rate', '5', 'Percentage taken from each sale'),
('withdrawal_delay', '3', 'Days before a vendor can withdraw funds'),
('referral_bonus', '10000', 'GNF given to new users via referral');

-- 4. SETTINGS SECURITY
ALTER TABLE public.platform_settings ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Public read for settings" 
ON public.platform_settings FOR SELECT USING (true);

CREATE POLICY "Admin only write for settings" 
ON public.platform_settings FOR ALL 
USING ((SELECT is_admin FROM public.profiles WHERE id = auth.uid()) = true);

-- 5. AUDIT LOGS TABLE
CREATE TABLE IF NOT EXISTS public.audit_logs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    admin_id UUID REFERENCES public.profiles(id),
    action TEXT NOT NULL,
    target_type TEXT NOT NULL, -- 'user', 'product', 'store', 'setting'
    target_id TEXT,
    details JSONB,
    created_at TIMESTAMPTZ DEFAULT now()
);

ALTER TABLE public.audit_logs ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Admins can view audit logs" ON public.audit_logs;
CREATE POLICY "Admins can view audit logs" ON public.audit_logs FOR SELECT USING ((SELECT is_admin FROM public.profiles WHERE id = auth.uid()) = true);
DROP POLICY IF EXISTS "System can insert audit logs" ON public.audit_logs;
CREATE POLICY "System can insert audit logs" ON public.audit_logs FOR INSERT WITH CHECK (true);

-- 6. ANNOUNCEMENTS TABLE
CREATE TABLE IF NOT EXISTS public.announcements (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    title TEXT NOT NULL,
    content TEXT NOT NULL,
    target_role TEXT DEFAULT 'all', -- 'all', 'vendor', 'user'
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMPTZ DEFAULT now()
);

ALTER TABLE public.announcements ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Public read for active announcements" ON public.announcements;
CREATE POLICY "Public read for active announcements" ON public.announcements FOR SELECT USING (is_active = true);
DROP POLICY IF EXISTS "Admin full access to announcements" ON public.announcements;
CREATE POLICY "Admin full access to announcements" ON public.announcements FOR ALL USING ((SELECT is_admin FROM public.profiles WHERE id = auth.uid()) = true);
