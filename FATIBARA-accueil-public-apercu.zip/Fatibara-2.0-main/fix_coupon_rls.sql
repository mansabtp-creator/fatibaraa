-- FIX COUPONS ROW LEVEL SECURITY & SCHEMA
-- This script adds the missing columns and INSERT, UPDATE, and DELETE policies for store owners.

-- 1. Ensure table and columns exist
CREATE TABLE IF NOT EXISTS public.coupons (
  id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  created_at timestamp with time zone DEFAULT timezone('utc'::text, now()) NOT NULL
);

DO $$
BEGIN
  -- Add columns if they don't exist
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'coupons' AND column_name = 'store_id') THEN
    ALTER TABLE public.coupons ADD COLUMN store_id uuid REFERENCES public.stores(id) ON DELETE CASCADE;
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'coupons' AND column_name = 'code') THEN
    ALTER TABLE public.coupons ADD COLUMN code text;
  END IF;

  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'coupons' AND column_name = 'discount_percent') THEN
    ALTER TABLE public.coupons ADD COLUMN discount_percent numeric;
  END IF;

  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'coupons' AND column_name = 'usage_limit') THEN
    ALTER TABLE public.coupons ADD COLUMN usage_limit integer;
  END IF;

  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'coupons' AND column_name = 'usage_count') THEN
    ALTER TABLE public.coupons ADD COLUMN usage_count integer DEFAULT 0;
  END IF;

  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'coupons' AND column_name = 'min_order_value') THEN
    ALTER TABLE public.coupons ADD COLUMN min_order_value numeric;
  END IF;

  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'coupons' AND column_name = 'expires_at') THEN
    ALTER TABLE public.coupons ADD COLUMN expires_at timestamp with time zone;
  END IF;

  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'coupons' AND column_name = 'is_active') THEN
    ALTER TABLE public.coupons ADD COLUMN is_active boolean DEFAULT true;
  END IF;
END $$;

-- Enable RLS just in case it's not enabled
ALTER TABLE public.coupons ENABLE ROW LEVEL SECURITY;

-- Drop existing policies if they conflict
DROP POLICY IF EXISTS "Vendors can insert coupons for their stores" ON public.coupons;
DROP POLICY IF EXISTS "Vendors can update coupons for their stores" ON public.coupons;
DROP POLICY IF EXISTS "Vendors can delete coupons for their stores" ON public.coupons;
DROP POLICY IF EXISTS "Vendors can view their own coupons" ON public.coupons;

-- 1. Vendors can view all coupons that belong to their store
CREATE POLICY "Vendors can view their own coupons" ON public.coupons 
FOR SELECT 
USING (
  EXISTS (
    SELECT 1 FROM public.stores 
    WHERE stores.id = coupons.store_id 
    AND stores.owner_id = auth.uid()
  )
);

-- 2. Vendors can insert coupons only for their own store
CREATE POLICY "Vendors can insert coupons for their stores" ON public.coupons 
FOR INSERT 
WITH CHECK (
  EXISTS (
    SELECT 1 FROM public.stores 
    WHERE stores.id = coupons.store_id 
    AND stores.owner_id = auth.uid()
  )
);

-- 3. Vendors can update coupons only for their own store
CREATE POLICY "Vendors can update coupons for their stores" ON public.coupons 
FOR UPDATE 
USING (
  EXISTS (
    SELECT 1 FROM public.stores 
    WHERE stores.id = coupons.store_id 
    AND stores.owner_id = auth.uid()
  )
);

-- 4. Vendors can delete coupons only for their own store
CREATE POLICY "Vendors can delete coupons for their stores" ON public.coupons 
FOR DELETE 
USING (
  EXISTS (
    SELECT 1 FROM public.stores 
    WHERE stores.id = coupons.store_id 
    AND stores.owner_id = auth.uid()
  )
);
