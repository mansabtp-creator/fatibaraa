-- RUN THIS IN SUPABASE SQL EDITOR TO FIX ADMIN ACCESS
-- This ensures your user ID is explicitly marked as admin in the database

UPDATE public.profiles 
SET is_admin = true 
WHERE id = 'c620a30d-5828-4066-9d59-8db34c28d20d' 
   OR id = (SELECT id FROM auth.users WHERE email = 'fatibara.gn@gmail.com' LIMIT 1);

-- Ensure the update policy allows admins to manage and sync their own status
DROP POLICY IF EXISTS "Users can update own profile" ON public.profiles;
CREATE POLICY "Users can update own profile" 
ON public.profiles 
FOR UPDATE 
USING (auth.uid() = id)
WITH CHECK (auth.uid() = id);

-- Verify
SELECT id, email, is_admin FROM public.profiles WHERE is_admin = true;
