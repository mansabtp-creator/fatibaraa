-- Comprehensive Fix for Supabase Schema
-- Run this in your Supabase SQL Editor

-- 1. Fix Profiles Table
ALTER TABLE public.profiles 
  ADD COLUMN IF NOT EXISTS profile_type TEXT DEFAULT 'client' CHECK (profile_type IN ('client', 'pro', 'vendor', 'admin')),
  ADD COLUMN IF NOT EXISTS full_name TEXT,
  ADD COLUMN IF NOT EXISTS phone_number TEXT,
  ADD COLUMN IF NOT EXISTS wallet_balance NUMERIC DEFAULT 0;

-- Ensure handle_new_user trigger is robust
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO public.profiles (id, full_name, profile_type)
  VALUES (new.id, new.raw_user_meta_data->>'full_name', 'client')
  ON CONFLICT (id) DO NOTHING;
  RETURN new;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- 2. Fix Orders Table
DO $$ 
BEGIN 
    -- Add amount if missing
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='orders' AND column_name='amount') THEN
        ALTER TABLE public.orders ADD COLUMN amount NUMERIC;
    END IF;
    
    -- Add total_amount if missing
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='orders' AND column_name='total_amount') THEN
        ALTER TABLE public.orders ADD COLUMN total_amount NUMERIC;
    END IF;
    
    -- Add tracking_number if missing
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='orders' AND column_name='tracking_number') THEN
        ALTER TABLE public.orders ADD COLUMN tracking_number TEXT;
    END IF;

    -- Add customer_name if missing
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='orders' AND column_name='customer_name') THEN
        ALTER TABLE public.orders ADD COLUMN customer_name TEXT;
    END IF;

    -- Add items_count if missing
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='orders' AND column_name='items_count') THEN
        ALTER TABLE public.orders ADD COLUMN items_count INTEGER DEFAULT 1;
    END IF;
END $$;

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

