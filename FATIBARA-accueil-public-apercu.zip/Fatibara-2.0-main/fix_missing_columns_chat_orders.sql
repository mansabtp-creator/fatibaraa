-- Add missing columns for chat_channels and orders if they do not exist
DO $$
BEGIN

  -- Add last_message to chat_channels
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'chat_channels' AND column_name = 'last_message'
  ) THEN
    ALTER TABLE chat_channels ADD COLUMN last_message text;
  END IF;

  -- Add amount to orders if it doesn't exist
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'orders' AND column_name = 'amount'
  ) THEN
    ALTER TABLE orders ADD COLUMN amount integer;
  END IF;

END $$;
