-- WALLET & WITHDRAWALS SYSTEM
CREATE TABLE IF NOT EXISTS public.wallet_transactions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    store_id UUID REFERENCES public.stores(id) ON DELETE CASCADE,
    amount BIGINT NOT NULL,
    type TEXT NOT NULL, -- 'sale', 'withdrawal', 'refund', 'adjustment'
    reference_id UUID,
    description TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS public.withdrawals (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    store_id UUID REFERENCES public.stores(id) ON DELETE CASCADE,
    amount BIGINT NOT NULL,
    method TEXT NOT NULL, -- 'Orange Money', 'MTN MoMo'
    phone_number TEXT NOT NULL,
    status TEXT DEFAULT 'pending', -- 'pending', 'processed', 'rejected'
    processed_at TIMESTAMP WITH TIME ZONE,
    admin_notes TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Trigger to log sales as transactions automatically
CREATE OR REPLACE FUNCTION log_sale_transaction()
RETURNS TRIGGER AS $$
BEGIN
    IF (TG_OP = 'UPDATE' AND OLD.status != 'delivered' AND NEW.status = 'delivered') THEN
        INSERT INTO wallet_transactions (store_id, amount, type, reference_id, description)
        VALUES (NEW.store_id, NEW.total_amount, 'sale', NEW.id, 'Vente finalisée: Commande ' || NEW.id);
        
        UPDATE stores
        SET balance = COALESCE(balance, 0) + NEW.total_amount
        WHERE id = NEW.store_id;
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS tr_log_sale_transaction ON orders;
CREATE TRIGGER tr_log_sale_transaction
AFTER UPDATE ON orders
FOR EACH ROW
EXECUTE FUNCTION log_sale_transaction();
