-- Run this script in your Supabase SQL Editor to update the cart_items table unique constraints.
-- This will resolve the 409 (Conflict) errors when adding products with variations to the cart.

-- 1. Drop the legacy unique constraint if it exists (This is blocking multiple variations of the same product!)
ALTER TABLE public.cart_items DROP CONSTRAINT IF EXISTS cart_items_user_id_product_id_key;

-- 2. Drop the updated constraint if it exists (to prevent duplicate key errors during recreation)
ALTER TABLE public.cart_items DROP CONSTRAINT IF EXISTS cart_items_user_id_product_id_variations_key;
DROP INDEX IF EXISTS cart_items_user_product_variations_idx;

-- 3. Add the proper composite unique INDEX (Postgres cannot put UNIQUE constraints directly on JSONB)
CREATE UNIQUE INDEX cart_items_user_product_variations_idx 
ON public.cart_items (user_id, product_id, (selected_variations::text));

-- 4. Reload PostgREST schema cache
NOTIFY pgrst, 'reload schema';
