-- Supabase Migration types/logic
-- Run this in your Supabase SQL Editor

-- 1. Patch existing products table
-- 1. Patch existing products table
ALTER TABLE public.products ADD COLUMN IF NOT EXISTS store_id uuid REFERENCES public.stores(id) ON DELETE CASCADE;
ALTER TABLE public.products ADD COLUMN IF NOT EXISTS status text NOT NULL DEFAULT 'published';
ALTER TABLE public.products ADD COLUMN IF NOT EXISTS scheduled_at timestamp with time zone;
ALTER TABLE public.products ADD COLUMN IF NOT EXISTS low_stock_threshold integer DEFAULT 5;
ALTER TABLE public.products ADD COLUMN IF NOT EXISTS is_digital boolean DEFAULT false;
ALTER TABLE public.products ADD COLUMN IF NOT EXISTS download_url text;
ALTER TABLE public.products ADD COLUMN IF NOT EXISTS variants jsonb DEFAULT '[]'::jsonb;
ALTER TABLE public.products ADD COLUMN IF NOT EXISTS volume_discount_qty integer;
ALTER TABLE public.products ADD COLUMN IF NOT EXISTS volume_discount_percent numeric;


-- Optional index for products
CREATE INDEX IF NOT EXISTS idx_products_status ON public.products(status);
CREATE INDEX IF NOT EXISTS idx_products_scheduled_at ON public.products(scheduled_at);

-- 2. Patch existing stores table
DO $$
BEGIN
  ALTER TABLE public.stores ADD COLUMN IF NOT EXISTS payout_orange_money text;
  ALTER TABLE public.stores ADD COLUMN IF NOT EXISTS payout_mtn_money text;
  ALTER TABLE public.stores ADD COLUMN IF NOT EXISTS store_status text DEFAULT 'active';
  ALTER TABLE public.stores ADD COLUMN IF NOT EXISTS global_sale_active boolean DEFAULT false;
  ALTER TABLE public.stores ADD COLUMN IF NOT EXISTS global_sale_percent numeric;
END $$;

-- 3. Create or Patch coupons table
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_tables WHERE schemaname = 'public' AND tablename = 'coupons') THEN
    CREATE TABLE public.coupons (
      id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
      code text NOT NULL,
      discount_percent numeric NOT NULL,
      created_at timestamp with time zone DEFAULT now()
    );
  END IF;

  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema='public' AND table_name='coupons' AND column_name='store_id') THEN
    ALTER TABLE public.coupons ADD COLUMN store_id uuid REFERENCES public.stores(id) ON DELETE CASCADE;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema='public' AND table_name='coupons' AND column_name='usage_limit') THEN
    ALTER TABLE public.coupons ADD COLUMN usage_limit integer;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema='public' AND table_name='coupons' AND column_name='usage_count') THEN
    ALTER TABLE public.coupons ADD COLUMN usage_count integer DEFAULT 0;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema='public' AND table_name='coupons' AND column_name='min_order_value') THEN
    ALTER TABLE public.coupons ADD COLUMN min_order_value numeric;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema='public' AND table_name='coupons' AND column_name='expires_at') THEN
    ALTER TABLE public.coupons ADD COLUMN expires_at timestamp with time zone;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema='public' AND table_name='coupons' AND column_name='is_active') THEN
    ALTER TABLE public.coupons ADD COLUMN is_active boolean DEFAULT true;
  END IF;

  -- Create indexes for coupons
  IF NOT EXISTS (SELECT 1 FROM pg_indexes WHERE indexname = 'idx_coupons_code') THEN
    CREATE INDEX idx_coupons_code ON public.coupons(code);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_indexes WHERE indexname = 'idx_coupons_store') THEN
    CREATE INDEX idx_coupons_store ON public.coupons(store_id);
  END IF;
END $$;

-- 4. Create or Patch cart_events table
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_tables WHERE schemaname = 'public' AND tablename = 'cart_events') THEN
    CREATE TABLE public.cart_events (
      id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
      total_value numeric NOT NULL,
      items jsonb NOT NULL,
      created_at timestamp with time zone DEFAULT now()
    );
  END IF;

  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema='public' AND table_name='cart_events' AND column_name='store_id') THEN
    ALTER TABLE public.cart_events ADD COLUMN store_id uuid REFERENCES public.stores(id) ON DELETE CASCADE;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema='public' AND table_name='cart_events' AND column_name='user_id') THEN
    ALTER TABLE public.cart_events ADD COLUMN user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema='public' AND table_name='cart_events' AND column_name='status') THEN
    ALTER TABLE public.cart_events ADD COLUMN status text DEFAULT 'abandoned';
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema='public' AND table_name='cart_events' AND column_name='updated_at') THEN
    ALTER TABLE public.cart_events ADD COLUMN updated_at timestamp with time zone DEFAULT now();
  END IF;

  -- Create indexes for cart_events
  IF NOT EXISTS (SELECT 1 FROM pg_indexes WHERE indexname = 'idx_cart_events_store') THEN
    CREATE INDEX idx_cart_events_store ON public.cart_events(store_id);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_indexes WHERE indexname = 'idx_cart_events_user') THEN
    CREATE INDEX idx_cart_events_user ON public.cart_events(user_id);
  END IF;
END $$;

-- 5. Staff Accounts & Permissions
CREATE TABLE IF NOT EXISTS public.store_staff (
  id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  store_id uuid REFERENCES public.stores(id) ON DELETE CASCADE,
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE,
  role text NOT NULL DEFAULT 'staff',
  created_at timestamp with time zone DEFAULT now(),
  UNIQUE(store_id, user_id)
);

CREATE INDEX IF NOT EXISTS idx_store_staff_store ON public.store_staff(store_id);
CREATE INDEX IF NOT EXISTS idx_store_staff_user ON public.store_staff(user_id);

-- 6. Audit Logs
CREATE TABLE IF NOT EXISTS public.audit_logs (
  id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  store_id uuid REFERENCES public.stores(id) ON DELETE CASCADE,
  user_id uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  action text NOT NULL,
  entity_type text NOT NULL,
  entity_id uuid NOT NULL,
  old_data jsonb,
  new_data jsonb,
  created_at timestamp with time zone DEFAULT now()
);

-- 7. Integrated Chat
CREATE TABLE IF NOT EXISTS public.chat_channels (
  id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  store_id uuid REFERENCES public.stores(id) ON DELETE CASCADE,
  buyer_id uuid REFERENCES auth.users(id) ON DELETE CASCADE,
  last_message text,
  last_message_at timestamp with time zone DEFAULT now(),
  created_at timestamp with time zone DEFAULT now(),
  UNIQUE(store_id, buyer_id)
);

CREATE TABLE IF NOT EXISTS public.chat_messages (
  id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  channel_id uuid REFERENCES public.chat_channels(id) ON DELETE CASCADE,
  sender_id uuid REFERENCES auth.users(id) ON DELETE CASCADE,
  message text NOT NULL,
  is_read boolean DEFAULT false,
  created_at timestamp with time zone DEFAULT now()
);

-- 8. Analytics
CREATE TABLE IF NOT EXISTS public.product_views (
  id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  product_id uuid REFERENCES public.products(id) ON DELETE CASCADE,
  store_id uuid REFERENCES public.stores(id) ON DELETE CASCADE,
  user_id uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at timestamp with time zone DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_product_views_store ON public.product_views(store_id);

-- 9. Add RLS Policies for Staff Permissions

-- Helper to check if user is store owner or staff with specific role
CREATE OR REPLACE FUNCTION public.check_store_role(store_id_param uuid, role_param text) 
RETURNS boolean AS $$
BEGIN
  RETURN EXISTS (
    SELECT 1 FROM public.store_staff 
    WHERE store_id = store_id_param 
    AND user_id = auth.uid() 
    AND (role = role_param OR role = 'owner')
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Audit Logs
ALTER TABLE public.audit_logs ENABLE ROW LEVEL SECURITY;
CREATE POLICY "View own store logs" ON public.audit_logs
  FOR SELECT USING (public.check_store_role(store_id, 'manager'));

-- Chat Channels
ALTER TABLE public.chat_channels ENABLE ROW LEVEL SECURITY;
CREATE POLICY "View own store chats" ON public.chat_channels
  FOR SELECT USING (public.check_store_role(store_id, 'staff'));

-- Only owners can view payouts
ALTER TABLE public.stores ENABLE ROW LEVEL SECURITY;
CREATE POLICY "View own store details" ON public.stores
  FOR SELECT USING (public.check_store_role(id, 'staff'));
CREATE POLICY "Owner can view store payouts" ON public.stores
  FOR SELECT USING (EXISTS (
    SELECT 1 FROM public.store_staff WHERE store_id = id AND user_id = auth.uid() AND role = 'owner'
  ));


