-- ATOMIC FINANCIAL OPERATIONS
-- Prevents race conditions during wallet updates

CREATE OR REPLACE FUNCTION public.increment_wallet_balance(user_id UUID, amount NUMERIC)
RETURNS VOID AS $$
BEGIN
    UPDATE public.profiles 
    SET wallet_balance = wallet_balance + amount
    WHERE id = user_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE OR REPLACE FUNCTION public.increment_store_balance(target_store_id UUID, amount NUMERIC)
RETURNS VOID AS $$
BEGIN
    UPDATE public.stores 
    SET balance = balance + amount
    WHERE id = target_store_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Index for performance
CREATE INDEX IF NOT EXISTS idx_wallet_transactions_profile_id ON public.wallet_transactions(profile_id);
CREATE INDEX IF NOT EXISTS idx_withdrawals_status ON public.withdrawals(status);
