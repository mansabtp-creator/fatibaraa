-- ==============================================================================
-- WALLET LEDGER FIX MIGRATION
-- Fatibara 2.0 — Audit & Fix: 2026-08
-- ==============================================================================
-- This migration fixes:
--   1. Drops the legacy `tr_log_sale_transaction` trigger that caused double-credits
--      alongside `secure_process_order_financials` (no commission split, no idempotency).
--   2. Adds the missing `approve_withdrawal` RPC (referenced in withdrawalService.ts).
--   3. Adds `recalculate_store_balance` & `recalculate_profile_balance` utility functions
--      for on-demand ledger reconciliation (admin-only).
-- ==============================================================================

-- ─── 1. DROP LEGACY DOUBLE-CREDIT TRIGGER ─────────────────────────────────────
-- The trigger `tr_log_sale_transaction` (created by wallet_setup_v2.sql) fires on
-- EVERY order status update to 'delivered'. It:
--   a) Credits vendor the FULL total_amount (no commission deduction) — incorrect.
--   b) Has NO idempotency guard (no financial_status check) — causes double-credit.
-- The correct path is `secure_process_order_financials` RPC which:
--   a) Applies proper commission split, courier share, and cash-payment deductions.
--   b) Is guarded by `financial_status = 'processed'` + a `wallet_transactions` check.
DROP TRIGGER IF EXISTS tr_log_sale_transaction ON public.orders;
DROP FUNCTION IF EXISTS public.log_sale_transaction();

-- ─── 2. MISSING `approve_withdrawal` RPC ──────────────────────────────────────
-- withdrawalService.ts calls supabase.rpc('approve_withdrawal', { p_withdrawal_id })
-- but this function was never defined in any migration. When admin approves a
-- withdrawal, the balance was already deducted at withdrawal request time, so this
-- RPC only needs to mark the withdrawal as 'processed'.
-- Drop any prior version first to allow changing the return type signature.
DROP FUNCTION IF EXISTS public.approve_withdrawal(UUID);

CREATE OR REPLACE FUNCTION public.approve_withdrawal(p_withdrawal_id UUID)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_withdrawal RECORD;
BEGIN
    -- Admin-only guard
    IF NOT EXISTS (
        SELECT 1 FROM public.profiles
        WHERE id = auth.uid() AND is_admin = true
    ) THEN
        RAISE EXCEPTION 'Unauthorized: Only administrators can approve withdrawals';
    END IF;

    -- Lock the withdrawal row
    SELECT * INTO v_withdrawal
    FROM public.withdrawals
    WHERE id = p_withdrawal_id
    FOR UPDATE;

    IF v_withdrawal IS NULL THEN
        RAISE EXCEPTION 'Withdrawal not found';
    END IF;

    IF v_withdrawal.status != 'pending' THEN
        -- Idempotency: already processed or rejected — return success silently
        RETURN jsonb_build_object(
            'success', true,
            'alreadyProcessed', true,
            'status', v_withdrawal.status
        );
    END IF;

    -- Mark as processed (balance was deducted at request time)
    UPDATE public.withdrawals
    SET status       = 'processed',
        processed_at = NOW()
    WHERE id = p_withdrawal_id;

    -- Log the approval for audit trail
    INSERT INTO public.wallet_transactions (
        store_id, profile_id, amount, type, reference_id, description, status
    ) VALUES (
        v_withdrawal.store_id,
        v_withdrawal.profile_id,
        0,  -- Zero amount: balance already deducted; this row is an audit marker
        'withdrawal_approved',
        v_withdrawal.id,
        'Retrait approuvé par admin — ' || COALESCE(v_withdrawal.method, '') ||
        ' (' || v_withdrawal.phone_number || ')',
        'completed'
    );

    RETURN jsonb_build_object('success', true);
END;
$$;

GRANT EXECUTE ON FUNCTION public.approve_withdrawal(UUID) TO authenticated;

-- ─── 3. BALANCE RECONCILIATION UTILITIES (Admin-only) ─────────────────────────
-- These functions recompute cached balances from the wallet_transactions ledger.
-- Use for manual reconciliation or post-migration verification.

DROP FUNCTION IF EXISTS public.recalculate_store_balance(UUID);

CREATE OR REPLACE FUNCTION public.recalculate_store_balance(p_store_id UUID)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_ledger_sum BIGINT;
    v_current_balance BIGINT;
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM public.profiles
        WHERE id = auth.uid() AND is_admin = true
    ) THEN
        RAISE EXCEPTION 'Unauthorized';
    END IF;

    -- Sum all completed transactions for this store
    SELECT COALESCE(SUM(amount), 0)
    INTO v_ledger_sum
    FROM public.wallet_transactions
    WHERE store_id = p_store_id
      AND status = 'completed';

    -- Read current cached balance
    SELECT balance INTO v_current_balance
    FROM public.stores
    WHERE id = p_store_id;

    -- Update the cached balance to match the ledger
    UPDATE public.stores
    SET balance = v_ledger_sum
    WHERE id = p_store_id;

    RETURN jsonb_build_object(
        'store_id',       p_store_id,
        'old_balance',    v_current_balance,
        'new_balance',    v_ledger_sum,
        'drift',          v_ledger_sum - COALESCE(v_current_balance, 0)
    );
END;
$$;

GRANT EXECUTE ON FUNCTION public.recalculate_store_balance(UUID) TO authenticated;


DROP FUNCTION IF EXISTS public.recalculate_profile_balance(UUID);

CREATE OR REPLACE FUNCTION public.recalculate_profile_balance(p_profile_id UUID)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_ledger_sum BIGINT;
    v_current_balance BIGINT;
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM public.profiles
        WHERE id = auth.uid() AND is_admin = true
    ) THEN
        RAISE EXCEPTION 'Unauthorized';
    END IF;

    SELECT COALESCE(SUM(amount), 0)
    INTO v_ledger_sum
    FROM public.wallet_transactions
    WHERE profile_id = p_profile_id
      AND status = 'completed';

    SELECT wallet_balance INTO v_current_balance
    FROM public.profiles
    WHERE id = p_profile_id;

    UPDATE public.profiles
    SET wallet_balance = v_ledger_sum
    WHERE id = p_profile_id;

    RETURN jsonb_build_object(
        'profile_id',   p_profile_id,
        'old_balance',  v_current_balance,
        'new_balance',  v_ledger_sum,
        'drift',        v_ledger_sum - COALESCE(v_current_balance, 0)
    );
END;
$$;

GRANT EXECUTE ON FUNCTION public.recalculate_profile_balance(UUID) TO authenticated;

-- ─── 4. ENSURE wallet_transactions.status HAS DEFAULT 'completed' ────────────
-- Older inserts might lack a status column value. Normalize nulls → 'completed'.
UPDATE public.wallet_transactions
SET status = 'completed'
WHERE status IS NULL;

-- ─── 5. ENSURE financial_status column exists on orders ──────────────────────
-- This was created by transaction_system_v3.sql but run idempotently for safety.
ALTER TABLE public.orders
ADD COLUMN IF NOT EXISTS financial_status TEXT DEFAULT 'pending'
CHECK (financial_status IN ('pending', 'processing', 'processed', 'failed', 'refunded'));

-- ─── 6. BACKFILL financial_status FOR DELIVERED ORDERS ───────────────────────
-- Any delivered order that has a wallet_transactions entry should be marked
-- 'processed' to prevent future RPC re-runs on historical data.
UPDATE public.orders o
SET financial_status = 'processed'
WHERE o.status = 'delivered'
  AND o.financial_status = 'pending'
  AND EXISTS (
      SELECT 1 FROM public.wallet_transactions wt
      WHERE wt.reference_id = o.id
        AND wt.type = 'sale'
  );

-- ─── 7. BACKFILL financial_status FOR CANCELLED/REFUNDED ORDERS ──────────────
UPDATE public.orders o
SET financial_status = 'refunded'
WHERE o.status = 'cancelled'
  AND o.financial_status = 'pending'
  AND EXISTS (
      SELECT 1 FROM public.wallet_transactions wt
      WHERE wt.reference_id = o.id
        AND wt.type = 'refund'
  );
