import os
import glob
import subprocess

def inspect_and_fix():
    migrations = sorted(glob.glob("supabase/migrations/*.sql"))
    if not migrations:
        print("❌ No migration files found in supabase/migrations/")
        return

    all_sql = ""
    for filepath in migrations:
        all_sql += f"\n--- FILE: {os.path.basename(filepath)} ---\n"
        with open(filepath, "r", encoding="utf-8", errors="ignore") as f:
            all_sql += f.read()

    # System instruction ensuring clean SQL output
    prompt = f"""
    You are a Postgres DB Architect. Analyze these Supabase migration files.
    Identify all referenced tables and columns (e.g., profiles, stores, products, orders, cart_items, vendor_id, courier_id, courier_status, owner_id) 
    that appear in CREATE VIEW, ALTER TABLE, or CREATE POLICY queries before being defined.

    OUTPUT INSTRUCTIONS:
    - Return ONLY valid SQL code.
    - Do NOT wrap in markdown code blocks like ```sql ... ```.
    - Output ONLY CREATE TABLE IF NOT EXISTS and ALTER TABLE ... ADD COLUMN IF NOT EXISTS statements.
    - Use UUID primary keys and DEFAULT gen_random_uuid() where appropriate.

    MIGRATIONS TO ANALYZE:
    {all_sql[:16000]}
    """

    print("🧠 Qwen2.5 is analyzing migration dependencies...")
    
    res = subprocess.run(
        ["ollama", "run", "qwen2.5-coder", prompt], 
        capture_output=True, 
        text=True
    )

    # Sanitize output (remove markdown fences if Qwen still outputs them)
    clean_sql = res.stdout.strip()
    if clean_sql.startswith("```sql"):
        clean_sql = clean_sql[6:]
    if clean_sql.startswith("```"):
        clean_sql = clean_sql[3:]
    if clean_sql.endswith("```"):
        clean_sql = clean_sql[:-3]

    output_filename = "supabase/migrations/20240101000000_00_auto_stubs.sql"
    with open(output_filename, "w", encoding="utf-8") as f:
        f.write("-- AUTO-GENERATED BASELINE STUBS BY QWEN2.5-CODER\n")
        f.write(clean_sql.strip())
        
    print(f"✨ Successfully generated baseline stubs in {output_filename}!")

if __name__ == "__main__":
    inspect_and_fix()