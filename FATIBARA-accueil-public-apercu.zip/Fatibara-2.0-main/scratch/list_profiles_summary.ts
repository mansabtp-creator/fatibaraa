import { createClient } from '@supabase/supabase-js';
import dotenv from 'dotenv';

dotenv.config();

const supabase = createClient(process.env.VITE_SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!);

async function run() {
  const { data: profiles, error } = await supabase
    .from('profiles')
    .select('id, full_name, profile_type, is_admin, role');
    
  if (error) {
    console.error(error);
    return;
  }
  
  console.log("Summary of profiles:");
  profiles.forEach(p => {
    console.log(`ID: ${p.id} | Name: ${p.full_name} | Type: ${p.profile_type} | Admin: ${p.is_admin} | Role: ${p.role}`);
  });
}

run();
