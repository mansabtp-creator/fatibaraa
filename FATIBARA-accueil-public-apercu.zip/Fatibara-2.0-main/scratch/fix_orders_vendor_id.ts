import { createClient } from '@supabase/supabase-js';
import dotenv from 'dotenv';

dotenv.config();

const supabase = createClient(process.env.VITE_SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!);

async function run() {
  console.log("Starting consistency audit and fix for orders vendor_ids...");
  
  // 1. Fetch all orders
  const { data: orders, error: ordersErr } = await supabase
    .from('orders')
    .select('id, tracking_number, vendor_id, customer_name, created_at');
    
  if (ordersErr) {
    console.error("Error fetching orders:", ordersErr);
    return;
  }
  
  console.log(`Checking ${orders.length} orders...`);
  
  let fixedCount = 0;
  
  for (const order of orders) {
    // 2. Fetch order items for this order
    const { data: items, error: itemsErr } = await supabase
      .from('order_items')
      .select('id, product_id')
      .eq('order_id', order.id);
      
    if (itemsErr) {
      console.error(`Error fetching items for order ${order.id}:`, itemsErr);
      continue;
    }
    
    if (!items || items.length === 0) {
      console.log(`Warning: Order ${order.id} (${order.tracking_number}) has no items. Skipping.`);
      continue;
    }
    
    // Filter out null product IDs (e.g. from deleted products)
    const validProductIds = items.map(i => i.product_id).filter(Boolean);
    
    if (validProductIds.length === 0) {
      console.log(`Warning: Order ${order.id} (${order.tracking_number}) has only null product_ids (deleted products). Keeping current vendor_id: ${order.vendor_id}`);
      continue;
    }
    
    // 3. Get products for these items
    const { data: products, error: productsErr } = await supabase
      .from('products')
      .select('id, title, store_id, stores(owner_id)')
      .in('id', validProductIds);
      
    if (productsErr) {
      console.error(`Error fetching products for order ${order.id}:`, productsErr);
      continue;
    }
    
    // Determine the true vendor(s) from products
    const storeOwners = new Set(products.map(p => (p.stores as any)?.owner_id).filter(Boolean));
    
    if (storeOwners.size === 0) {
      console.log(`Warning: Order ${order.id} (${order.tracking_number}) products have no associated store owners. Skipping.`);
      continue;
    }
    
    const correctVendorId = Array.from(storeOwners)[0];
    
    if (!order.vendor_id || order.vendor_id !== correctVendorId) {
      console.log(`Mismatch/Missing vendor_id found in Order ${order.id} (${order.tracking_number}):`);
      console.log(`  Current vendor_id: ${order.vendor_id}`);
      console.log(`  Correct vendor_id: ${correctVendorId}`);
      
      // Update order in database
      const { error: updateErr } = await supabase
        .from('orders')
        .update({ vendor_id: correctVendorId })
        .eq('id', order.id);
        
      if (updateErr) {
        console.error(`  Failed to update Order ${order.id}:`, updateErr);
      } else {
        console.log(`  Successfully updated Order ${order.id} with correct vendor_id.`);
        fixedCount++;
      }
    }
  }
  
  console.log(`\nConsistency audit and fix finished. Fixed ${fixedCount} orders.`);
}

run();
