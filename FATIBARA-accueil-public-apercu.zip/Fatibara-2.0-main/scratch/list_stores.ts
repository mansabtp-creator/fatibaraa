import { createClient } from '@supabase/supabase-js';
import dotenv from 'dotenv';

dotenv.config();

const supabase = createClient(process.env.VITE_SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!);

async function run() {
  const { data: stores, error } = await supabase
    .from('stores')
    .select('*');
    
  console.log("Stores list:", stores, error);
}

run();
