import { createClient } from '@supabase/supabase-js';
import dotenv from 'dotenv';

dotenv.config();

const supabase = createClient(process.env.VITE_SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!);

async function run() {
  const { data: items, error } = await supabase
    .from('order_items')
    .select('*')
    .eq('order_id', 'af774542-fddb-4bab-852d-d7ecadf05896');
    
  console.log("Items for af774542-fddb-4bab-852d-d7ecadf05896:", items, error);
}

run();
