import { createClient } from '@supabase/supabase-js';
import dotenv from 'dotenv';

dotenv.config();

const supabase = createClient(process.env.VITE_SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!);

async function run() {
  console.log("Auditing orders vendor profiles...");
  
  // 1. Fetch all orders
  const { data: orders, error: ordersErr } = await supabase
    .from('orders')
    .select('id, tracking_number, vendor_id, user_id, customer_name, created_at');
    
  if (ordersErr) {
    console.error("Error fetching orders:", ordersErr);
    return;
  }
  
  // 2. Fetch all profiles
  const { data: profiles, error: profilesErr } = await supabase
    .from('profiles')
    .select('*');
    
  if (profilesErr) {
    console.error("Error fetching profiles:", profilesErr);
    return;
  }
  
  const profileMap = new Map(profiles.map(p => [p.id, p]));
  
  console.log(`Auditing ${orders.length} orders against ${profiles.length} profiles...`);
  
  let issueCount = 0;
  for (const order of orders) {
    const vendorProfile = profileMap.get(order.vendor_id);
    const userProfile = profileMap.get(order.user_id);
    
    // Check if vendor profile exists
    if (!vendorProfile) {
      console.log(`Issue: Order ${order.id} (${order.tracking_number}) has vendor_id ${order.vendor_id} which does not exist in profiles.`);
      issueCount++;
      continue;
    }
    
    // Check if vendor_id equals user_id
    if (order.vendor_id === order.user_id) {
      console.log(`Issue: Order ${order.id} (${order.tracking_number}) has vendor_id equal to user_id (${order.vendor_id}).`);
      issueCount++;
    }
    
    // Check if vendor profile has profile_type !== 'vendor'
    if (vendorProfile.profile_type !== 'vendor' && vendorProfile.profile_type !== 'admin') {
      console.log(`Issue: Order ${order.id} (${order.tracking_number}) has vendor_id profile type '${vendorProfile.profile_type}' (Name: ${vendorProfile.full_name}), expected 'vendor'.`);
      issueCount++;
    }
  }
  
  console.log(`\nAudit completed. Found ${issueCount} issues.`);
}

run();
