import { createClient } from '@supabase/supabase-js';
import dotenv from 'dotenv';
import path from 'path';

dotenv.config();

const supabaseUrl = process.env.VITE_SUPABASE_URL;
const supabaseKey = process.env.SUPABASE_SERVICE_ROLE_KEY;

if (!supabaseUrl || !supabaseKey) {
  console.error("Missing environment variables VITE_SUPABASE_URL or SUPABASE_SERVICE_ROLE_KEY");
  process.exit(1);
}

const supabase = createClient(supabaseUrl, supabaseKey, {
  auth: {
    persistSession: false
  }
});

async function run() {
  console.log("Checking orders table...");
  const { data: orders, error } = await supabase
    .from('orders')
    .select('id, tracking_number, vendor_id, created_at');

  if (error) {
    console.error("Error fetching orders:", error);
    return;
  }

  console.log(`Total orders found: ${orders.length}`);
  const missingVendor = orders.filter(o => !o.vendor_id);

  console.log(`Orders missing vendor_id: ${missingVendor.length}`);

  if (missingVendor.length > 0) {
    console.log("\nSample orders missing vendor_id:");
    console.log(missingVendor.slice(0, 5));
  }
}

run();
