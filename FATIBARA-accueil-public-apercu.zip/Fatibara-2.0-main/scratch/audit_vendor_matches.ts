import { createClient } from '@supabase/supabase-js';
import dotenv from 'dotenv';

dotenv.config();

const supabaseUrl = process.env.VITE_SUPABASE_URL;
const supabaseKey = process.env.SUPABASE_SERVICE_ROLE_KEY;

if (!supabaseUrl || !supabaseKey) {
  console.error("Missing environment variables");
  process.exit(1);
}

const supabase = createClient(supabaseUrl, supabaseKey, {
  auth: { persistSession: false }
});

async function run() {
  console.log("Auditing orders vendor matching...");
  
  // 1. Fetch all orders
  const { data: orders, error: ordersErr } = await supabase
    .from('orders')
    .select('id, tracking_number, vendor_id, customer_name, created_at');
  
  if (ordersErr) {
    console.error("Error fetching orders:", ordersErr);
    return;
  }
  
  console.log(`Checking ${orders.length} orders...`);
  
  let mismatches = 0;
  
  for (const order of orders) {
    // 2. Fetch order items for this order
    const { data: items, error: itemsErr } = await supabase
      .from('order_items')
      .select('id, product_id')
      .eq('order_id', order.id);
      
    if (itemsErr) {
      console.error(`Error fetching items for order ${order.id}:`, itemsErr);
      continue;
    }
    
    if (!items || items.length === 0) {
      console.log(`Warning: Order ${order.id} (${order.tracking_number}) has no items.`);
      continue;
    }
    
    // 3. Get products for these items
    const productIds = items.map(i => i.product_id);
    const { data: products, error: productsErr } = await supabase
      .from('products')
      .select('id, title, store_id, stores(owner_id)')
      .in('id', productIds);
      
    if (productsErr) {
      console.error(`Error fetching products for order ${order.id}:`, productsErr);
      continue;
    }
    
    // Determine the true vendor(s) from products
    const storeOwners = new Set(products.map(p => (p.stores as any)?.owner_id).filter(Boolean));
    
    if (storeOwners.size === 0) {
      console.log(`Warning: Order ${order.id} (${order.tracking_number}) products have no store/owner.`);
      continue;
    }
    
    // If multiple store owners (multi-vendor cart checkout) - each sub-order should have its specific vendor_id.
    // Let's check if the current vendor_id is in the set of owners.
    if (!storeOwners.has(order.vendor_id)) {
      console.log(`Mismatch found! Order ${order.id} (${order.tracking_number}):`);
      console.log(`  Current vendor_id on order: ${order.vendor_id}`);
      console.log(`  True store owner(s) from products:`, Array.from(storeOwners));
      mismatches++;
      
      // Let's find a valid owner to correct it
      const correctVendorId = Array.from(storeOwners)[0];
      if (correctVendorId) {
        console.log(`  Suggested correction: set vendor_id to ${correctVendorId}`);
      }
    }
  }
  
  console.log(`\nAudit finished. Found ${mismatches} mismatching orders.`);
}

run();
