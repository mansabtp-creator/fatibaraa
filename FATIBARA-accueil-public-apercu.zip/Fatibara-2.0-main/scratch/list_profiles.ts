import { createClient } from '@supabase/supabase-js';
import dotenv from 'dotenv';

dotenv.config();

const supabase = createClient(process.env.VITE_SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!);

async function run() {
  const { data: profiles, error } = await supabase
    .from('profiles')
    .select('*');
    
  console.log("Profiles list:", profiles, error);
}

run();
