import { createClient } from '@supabase/supabase-js';
import dotenv from 'dotenv';

dotenv.config();

const supabase = createClient(process.env.VITE_SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!);

async function run() {
  const { data: stores, error } = await supabase
    .from('stores')
    .select('id, store_name, owner_id');
    
  if (error) {
    console.error(error);
    return;
  }
  
  console.log("All stores:");
  stores.forEach(s => {
    console.log(`Store ID: ${s.id} | Name: ${s.store_name} | Owner ID: ${s.owner_id}`);
  });
}

run();
