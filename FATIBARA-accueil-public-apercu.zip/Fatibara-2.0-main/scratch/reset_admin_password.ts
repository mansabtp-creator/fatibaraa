import { createClient } from '@supabase/supabase-js';
import dotenv from 'dotenv';

dotenv.config();

const supabase = createClient(process.env.VITE_SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!);

async function run() {
  const userId = '89263195-e7f0-4fd2-925a-c7e9e7d263f7';
  const { data, error } = await supabase.auth.admin.updateUserById(
    userId,
    { password: 'Password123!', email_confirm: true }
  );
  if (error) {
    console.error("Error updating user password:", error);
    return;
  }
  console.log("Successfully updated password for fatibara.gn@gmail.com");
}

run();
