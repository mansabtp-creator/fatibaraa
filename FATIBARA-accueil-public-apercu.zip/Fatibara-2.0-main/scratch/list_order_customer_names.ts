import { createClient } from '@supabase/supabase-js';
import dotenv from 'dotenv';

dotenv.config();

const supabase = createClient(process.env.VITE_SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!);

async function run() {
  const { data: orders, error } = await supabase
    .from('orders')
    .select('id, tracking_number, customer_name, vendor_id');
    
  if (error) {
    console.error(error);
    return;
  }
  
  console.log("Orders customer_name values:");
  orders.forEach(o => {
    console.log(`Order: ${o.tracking_number} | Customer: ${o.customer_name} | Vendor ID: ${o.vendor_id}`);
  });
}

run();
