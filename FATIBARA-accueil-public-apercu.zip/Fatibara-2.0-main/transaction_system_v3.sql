-- UNIFIED TRANSACTION SYSTEM & FINANCIAL FIXES
-- Fixes the 'profile_id' missing error and ensures couriers/users/vendors all use the same wallet core.

-- 1. Ensure Profiles has wallet_balance
ALTER TABLE public.profiles 
ADD COLUMN IF NOT EXISTS wallet_balance BIGINT DEFAULT 0,
ADD COLUMN IF NOT EXISTS total_withdrawn BIGINT DEFAULT 0;

-- 2. Upgrade wallet_transactions for profile support
ALTER TABLE public.wallet_transactions 
ADD COLUMN IF NOT EXISTS profile_id UUID REFERENCES public.profiles(id),
ADD COLUMN IF NOT EXISTS platform_fee BIGINT DEFAULT 0,
ADD COLUMN IF NOT EXISTS status TEXT DEFAULT 'completed';

-- 3. Update RLS for broader profile access
DROP POLICY IF EXISTS "Users can view own transactions" ON public.wallet_transactions;
CREATE POLICY "Users can view own transactions" 
ON public.wallet_transactions FOR SELECT 
USING (auth.uid() = profile_id OR profile_id IS NULL); -- Null check for legacy or platform-only logs

-- 4. Unified Withdrawal Table (handling both Vendor Stores and direct Profiles like couriers)
ALTER TABLE public.withdrawals
ADD COLUMN IF NOT EXISTS profile_id UUID REFERENCES public.profiles(id),
ADD COLUMN IF NOT EXISTS fee_deducted BIGINT DEFAULT 0;

-- Update Withdrawal Policies
DROP POLICY IF EXISTS "Users can view own withdrawals v2" ON public.withdrawals;
CREATE POLICY "Users can view own withdrawals v2" 
ON public.withdrawals FOR SELECT 
USING (profile_id = auth.uid() OR store_id IN (SELECT id FROM public.stores WHERE owner_id = auth.uid()));

DROP POLICY IF EXISTS "Users can create withdrawals v2" ON public.withdrawals;
CREATE POLICY "Users can create withdrawals v2" 
ON public.withdrawals FOR INSERT 
WITH CHECK (profile_id = auth.uid() OR store_id IN (SELECT id FROM public.stores WHERE owner_id = auth.uid()));

-- 5. Helper Function for Real-time Balance
-- This ensures that updating a transaction also updates the balance if we use triggers later
-- For now, we rely on service-side atomic updates, but let the DB have the structure.

-- 6. Add financial_status to orders to prevent double-payouts
ALTER TABLE public.orders
ADD COLUMN IF NOT EXISTS financial_status TEXT DEFAULT 'pending' CHECK (financial_status IN ('pending', 'processing', 'processed', 'failed'));

-- 7. Add platform_earnings tracking
CREATE TABLE IF NOT EXISTS public.platform_logs (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    type TEXT NOT NULL, -- 'commission', 'subscription', 'refund'
    amount BIGINT NOT NULL,
    reference_id UUID,
    metadata JSONB,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 8. Platform Governance Settings
CREATE TABLE IF NOT EXISTS public.platform_settings (
    id TEXT PRIMARY KEY,
    value TEXT NOT NULL,
    description TEXT,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

INSERT INTO public.platform_settings (id, value, description)
VALUES 
('commission_rate', '5', 'Platform Flat Commission %'),
('withdrawal_delay', '3', 'Days to hold funds before withdrawal'),
('referral_bonus', '10000', 'Amount in GNF for successful referral')
ON CONFLICT (id) DO NOTHING;

-- 9. Audit Logging System
CREATE TABLE IF NOT EXISTS public.audit_logs (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES auth.users(id),
    action TEXT NOT NULL,
    entity_type TEXT,
    entity_id TEXT,
    new_data JSONB,
    old_data JSONB,
    store_id UUID REFERENCES public.stores(id),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Admin only access for logs
ALTER TABLE public.audit_logs ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Admins only view all logs" ON public.audit_logs
FOR SELECT USING (EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND is_admin = true));
CREATE POLICY "Admins can insert logs" ON public.audit_logs
FOR INSERT WITH CHECK (true); -- Allow system to log
