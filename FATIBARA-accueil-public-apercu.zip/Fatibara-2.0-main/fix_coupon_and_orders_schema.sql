-- ==========================================
-- MIGRATION: Harmonize Coupons and Orders Schema
-- Description: 
-- 1. Adds the missing `store_id` column to the `orders` table.
-- 2. Consolidates coupon naming to `discount_percentage` and removes redundant `discount_percent`.
-- 3. Updates `secure_process_order_financials` RPC to safely query the store.
-- ==========================================

-- 1. FIX ORDERS TABLE SCHEMA
-- Add the missing store_id column referencing public.stores(id)
ALTER TABLE public.orders 
ADD COLUMN IF NOT EXISTS store_id UUID REFERENCES public.stores(id) ON DELETE SET NULL;

-- 2. UNIFY COUPONS TABLE SCHEMA
-- Ensure discount_percentage exists
ALTER TABLE public.coupons 
ADD COLUMN IF NOT EXISTS discount_percentage NUMERIC;

-- If discount_percentage is NULL but discount_percent has a value, copy it over
UPDATE public.coupons 
SET discount_percentage = discount_percent 
WHERE discount_percentage IS NULL AND discount_percent IS NOT NULL;

-- Drop the redundant discount_percent column to avoid future mismatches
ALTER TABLE public.coupons 
DROP COLUMN IF EXISTS discount_percent;

-- 3. UPDATE SECURE PROCESS ORDER FINANCIALS RPC
CREATE OR REPLACE FUNCTION public.secure_process_order_financials(p_order_id UUID)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER -- Runs as DB admin to bypass RLS for financial updates
AS $$
DECLARE
    v_order RECORD;
    v_store RECORD;
    v_existing_tx BOOLEAN;
    v_commission_str TEXT;
    v_commission_rate NUMERIC;
    v_items_real_value NUMERIC := 0;
    v_item_subtotal NUMERIC;
    v_platform_commission NUMERIC;
    v_vendor_payout NUMERIC;
    v_courier_payout NUMERIC;
    v_is_cash_payment BOOLEAN;
    v_final_vendor_digital_change NUMERIC;
    v_final_courier_digital_change NUMERIC;
BEGIN
    -- 1. Get Order Details (Locked with FOR UPDATE to prevent race conditions)
    SELECT * INTO v_order FROM public.orders WHERE id = p_order_id FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'Order not found';
    END IF;

    -- 1.5. Idempotency Check
    IF v_order.financial_status = 'processed' THEN
        RETURN jsonb_build_object('success', true, 'alreadyProcessed', true);
    END IF;

    SELECT EXISTS (
        SELECT 1 FROM public.wallet_transactions 
        WHERE reference_id = p_order_id AND type = 'sale'
    ) INTO v_existing_tx;

    IF v_existing_tx THEN
        UPDATE public.orders SET financial_status = 'processed' WHERE id = p_order_id;
        RETURN jsonb_build_object('success', true, 'alreadyProcessed', true);
    END IF;

    -- Get Store (using store_id with fallback to owner_id matching vendor_id)
    SELECT * INTO v_store FROM public.stores 
    WHERE id = v_order.store_id 
       OR (v_order.store_id IS NULL AND owner_id = v_order.vendor_id)
    LIMIT 1;

    -- Calculate real value of goods based on actual paid amount (accounting for discounts/coupons)
    v_items_real_value := v_order.total_amount - COALESCE(v_order.delivery_fee, 0);

    -- Fetch dynamic commission rate
    SELECT value INTO v_commission_str FROM public.platform_settings WHERE id = 'commission_rate';
    IF v_commission_str IS NULL THEN
        v_commission_str := '5';
    END IF;
    v_commission_rate := v_commission_str::numeric / 100.0;

    v_item_subtotal := v_items_real_value / (1 + v_commission_rate);
    v_platform_commission := v_item_subtotal * v_commission_rate;
    v_vendor_payout := v_item_subtotal - COALESCE(v_order.vendor_delivery_fee, 0);
    
    v_courier_payout := (CASE WHEN COALESCE(v_order.delivery_fee, 0) > 0 THEN v_order.delivery_fee ELSE COALESCE(v_order.vendor_delivery_fee, 0) END) * 0.8;

    IF v_order.courier_id IS NULL THEN
        v_vendor_payout := v_vendor_payout + v_courier_payout;
    END IF;

    v_is_cash_payment := v_order.payment_method = 'cash';

    -- 2. Update Vendor Balance
    IF v_store.id IS NOT NULL THEN
        v_final_vendor_digital_change := v_vendor_payout;

        IF v_is_cash_payment AND v_order.courier_id IS NULL THEN
            v_final_vendor_digital_change := v_vendor_payout - v_order.total_amount;
        END IF;

        IF v_final_vendor_digital_change != 0 THEN
            UPDATE public.stores 
            SET balance = balance + ROUND(v_final_vendor_digital_change)
            WHERE id = v_store.id;

            INSERT INTO public.wallet_transactions (store_id, profile_id, amount, type, reference_id, description)
            VALUES (
                v_store.id, 
                v_store.owner_id, 
                v_final_vendor_digital_change, 
                CASE WHEN v_final_vendor_digital_change > 0 THEN 'sale' ELSE 'fee' END, 
                v_order.id, 
                CASE WHEN v_is_cash_payment AND v_order.courier_id IS NULL 
                     THEN 'Collecte Cash #' || left(v_order.id::text, 8) || ' (Retenue: ' || abs(ROUND(v_final_vendor_digital_change)) || ')'
                     ELSE 'Vente #' || left(v_order.id::text, 8) || ' (Payout ' || ROUND(v_item_subtotal) || ')'
                END
            );
        END IF;
    END IF;

    -- 3. Update Courier Balance
    IF v_order.courier_id IS NOT NULL THEN
        v_final_courier_digital_change := v_courier_payout;

        IF v_is_cash_payment THEN
            v_final_courier_digital_change := v_courier_payout - v_order.total_amount;
        END IF;

        IF v_final_courier_digital_change != 0 THEN
            UPDATE public.profiles 
            SET wallet_balance = wallet_balance + ROUND(v_final_courier_digital_change)
            WHERE id = v_order.courier_id;

            INSERT INTO public.wallet_transactions (profile_id, amount, type, reference_id, description)
            VALUES (
                v_order.courier_id, 
                v_final_courier_digital_change, 
                CASE WHEN v_final_courier_digital_change > 0 THEN 'delivery_fee' ELSE 'fee' END, 
                v_order.id, 
                CASE WHEN v_is_cash_payment 
                     THEN 'Collecte Cash #' || left(v_order.id::text, 8) || ' (Retenue: ' || abs(ROUND(v_final_courier_digital_change)) || ')'
                     ELSE 'Course effectuée - Commande #' || left(v_order.id::text, 8)
                END
            );
        END IF;
    END IF;

    -- 4. Log Platform Commission
    INSERT INTO public.platform_logs (type, amount, reference_id, metadata)
    VALUES (
        'commission', 
        ROUND(v_platform_commission), 
        v_order.id, 
        jsonb_build_object('order_total', v_order.total_amount, 'vendor_id', v_order.vendor_id)
    );

    -- 5. Mark Processed
    UPDATE public.orders SET financial_status = 'processed' WHERE id = p_order_id;

    RETURN jsonb_build_object(
        'success', true, 
        'vendorPayout', ROUND(v_vendor_payout), 
        'courierPayout', ROUND(v_courier_payout), 
        'platformCommission', ROUND(v_platform_commission)
    );
END;
$$;

-- 4. RELOAD SCHEMA CACHE
NOTIFY pgrst, 'reload schema';
