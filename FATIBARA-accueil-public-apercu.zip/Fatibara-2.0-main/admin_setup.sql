-- Admin Setup & RLS Polishing
-- Run this in your Supabase SQL Editor

-- 1. Ensure is_admin column exists (it should, but just in case)
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS is_admin BOOLEAN DEFAULT false;

-- 2. Promote the main admin (Replace with your actual UUID if needed)
-- Based on your request, using UID: c620a30d-5828-4066-9d59-8db34c28d20d
UPDATE public.profiles 
SET is_admin = true 
WHERE id = 'c620a30d-5828-4066-9d59-8db34c28d20d';

-- 3. Create admins table to avoid RLS recursion
CREATE TABLE IF NOT EXISTS public.admins (                
  user_id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE
);
ALTER TABLE public.admins DISABLE ROW LEVEL SECURITY;

-- Migrate existing admins to the new table
INSERT INTO public.admins (user_id)                
SELECT id FROM public.profiles WHERE is_admin = true
ON CONFLICT (user_id) DO NOTHING;

-- Create helper function to check admin status
CREATE OR REPLACE FUNCTION public.is_admin() 
RETURNS boolean AS $$
BEGIN
  RETURN EXISTS (
    SELECT 1 FROM public.admins 
    WHERE user_id = auth.uid()
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- 4. Enhance RLS Policies for Admin Global Access
-- Normally, RLS restricts users to their own data. Admins need to see EVERYTHING.

-- Profile Access
DROP POLICY IF EXISTS "Admins can see all profiles" ON public.profiles;
CREATE POLICY "Admins can see all profiles" ON public.profiles 
FOR ALL USING (
  public.is_admin()
  OR auth.uid() = id
);

-- Store Access
DROP POLICY IF EXISTS "Admins can manage all stores" ON public.stores;
CREATE POLICY "Admins can manage all stores" ON public.stores 
FOR ALL USING (
  public.is_admin()
  OR auth.uid() = owner_id
);

-- Product Access
DROP POLICY IF EXISTS "Admins can manage all products" ON public.products;
CREATE POLICY "Admins can manage all products" ON public.products 
FOR ALL USING (
  public.is_admin()
  OR EXISTS (SELECT 1 FROM public.stores s WHERE s.id = products.store_id AND s.owner_id = auth.uid())
);

-- Order Access
DROP POLICY IF EXISTS "Admins can see all orders" ON public.orders;
CREATE POLICY "Admins can see all orders" ON public.orders 
FOR ALL USING (
  public.is_admin()
  OR auth.uid() = vendor_id 
  OR auth.uid() = user_id
);

-- Order Items Access
DROP POLICY IF EXISTS "Admins can see all order items" ON public.order_items;
CREATE POLICY "Admins can see all order items" ON public.order_items 
FOR ALL USING (
  public.is_admin()
  OR EXISTS (SELECT 1 FROM public.orders o WHERE o.id = order_items.order_id AND (o.user_id = auth.uid() OR o.vendor_id = auth.uid()))
);

-- Review Moderation
DROP POLICY IF EXISTS "Admins can moderate reviews" ON public.reviews;
CREATE POLICY "Admins can moderate reviews" ON public.reviews 
FOR ALL USING (
  public.is_admin()
  OR auth.uid() = user_id
);

-- Notification System
DROP POLICY IF EXISTS "Admins can send global notifications" ON public.notifications;
CREATE POLICY "Admins can send global notifications" ON public.notifications 
FOR INSERT WITH CHECK (
  public.is_admin()
  OR auth.uid() = user_id
);

