-- Add admin privileges to stores
CREATE POLICY "Admins can update any store" ON public.stores
FOR UPDATE USING (public.is_admin());

CREATE POLICY "Admins can delete any store" ON public.stores
FOR DELETE USING (public.is_admin());

-- Also perhaps for products?
CREATE POLICY "Admins can delete any product" ON public.products
FOR DELETE USING (public.is_admin());
