-- FIX ORDERS TABLE (Missing Columns & RLS Hardening)
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS customer_name text;
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS items_count integer;
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS financial_status text DEFAULT 'pending';
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS tracking_number text;
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS delivery_otp text;
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS vendor_id uuid REFERENCES auth.users(id);

-- 2. FIX STORES TABLE
ALTER TABLE public.stores ADD COLUMN IF NOT EXISTS payout_orange_money text;
ALTER TABLE public.stores ADD COLUMN IF NOT EXISTS payout_mtn_money text;

-- 3. RESET & HARDEN ORDERS RLS
-- First, drop the existing restrictive/broken policy
DROP POLICY IF EXISTS "Users can insert their own orders" ON public.orders;

-- Enable RLS
ALTER TABLE public.orders ENABLE ROW LEVEL SECURITY;

-- Create broad but secure policies
CREATE POLICY "Allow authenticated insert" ON public.orders
    FOR INSERT
    TO authenticated
    WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Allow authenticated read" ON public.orders
    FOR SELECT
    TO authenticated
    USING (auth.uid() = user_id OR auth.uid() = vendor_id);

CREATE POLICY "Allow authenticated update" ON public.orders
    FOR UPDATE
    TO authenticated
    USING (auth.uid() = user_id OR auth.uid() = vendor_id)
    WITH CHECK (auth.uid() = user_id OR auth.uid() = vendor_id);
