
import express from "express";
import cors from "cors";
import * as path from "path";
import * as dotenv from "dotenv";
import crypto from "crypto";
import { createClient } from "@supabase/supabase-js";
import { GoogleGenAI, Type } from "@google/genai";
import lengopayPayinHandler from './api/lengopay/payin';
import paymentStatusHandler from './api/payment/status';
import pushSubscribeHandler from './api/push/subscribe';

dotenv.config();

function cleanEnvJwt(key?: string): string {
  if (!key) return "";
  const match = key.match(/^[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+/);
  return match ? match[0] : key.trim().replace(/^["']|["']$/g, '');
}

if (process.env.VITE_SUPABASE_ANON_KEY) {
  process.env.VITE_SUPABASE_ANON_KEY = cleanEnvJwt(process.env.VITE_SUPABASE_ANON_KEY);
}
if (process.env.SUPABASE_SERVICE_ROLE_KEY) {
  process.env.SUPABASE_SERVICE_ROLE_KEY = cleanEnvJwt(process.env.SUPABASE_SERVICE_ROLE_KEY);
}
if (process.env.VITE_SUPABASE_URL) {
  process.env.VITE_SUPABASE_URL = process.env.VITE_SUPABASE_URL.trim().replace(/^["']|["']$/g, '').replace(/\/(rest|auth|realtime|storage)\/v\d.*$/, '').replace(/\/$/, '');
}

let supabaseClient: any;
let aiClient: GoogleGenAI | null = null;

function getAiClient() {
  if (!aiClient) {
    aiClient = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });
  }
  return aiClient;
}

function getSupabase() {
  if (!supabaseClient) {
    if (!process.env.VITE_SUPABASE_URL || !process.env.SUPABASE_SERVICE_ROLE_KEY) {
      throw new Error(
        "[Config] VITE_SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY must be set in environment variables."
      );
    }
    supabaseClient = createClient(
      process.env.VITE_SUPABASE_URL,
      process.env.SUPABASE_SERVICE_ROLE_KEY
    );
  }
  return supabaseClient;
}

async function startServer() {
  const app = express();
  const PORT = Number(process.env.PORT) || 3000;

  app.use(express.json({ limit: '50mb' }));

  // ─── CORS ─────────────────────────────────────────────────────────────────
  // Mobile webviews (Android/iOS) make cross-origin requests that are blocked
  // by the browser's preflight check when no Access-Control-Allow-Origin header
  // is present.  We whitelist production + local dev origins explicitly to
  // prevent mixed-content and CORS errors on mobile clients.
  const ALLOWED_ORIGINS: (string | RegExp)[] = [
    'https://fatibara.com',
    'https://www.fatibara.com',
    // Vercel preview deployments
    /\.vercel\.app$/,
    // AI Studio / Cloud Run preview and production deployments
    /\.run\.app$/,
    /\.google\.com$/,
    /\.googleusercontent\.com$/,
    // Local dev (Vite default port)
    'http://localhost:3000',
    'http://localhost:5173',
    'http://127.0.0.1:3000',
    'http://127.0.0.1:5173',
    ...(process.env.APP_URL ? [process.env.APP_URL] : []),
  ];

  app.use(
    cors({
      origin: (origin, callback) => {
        // Allow requests with no origin header (server-to-server, curl, mobile app shells)
        if (!origin) return callback(null, true);
        const isAllowed =
          process.env.NODE_ENV === 'development' ||
          ALLOWED_ORIGINS.some((o) =>
            typeof o === 'string' ? o === origin : o.test(origin)
          );
        if (isAllowed) return callback(null, true);
        console.warn(`[CORS] Rejected origin: ${origin}`);
        return callback(null, false);
      },
      methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],
      allowedHeaders: ['Content-Type', 'Authorization', 'x-client-info', 'apikey'],
      credentials: true,
      maxAge: 86400, // cache preflight for 24 h
    })
  );

  // ─── Security Headers ───────────────────────────────────────────────────────
  // Note: Avoid restrictive CSP headers in dev/preview environment to prevent
  // blocking AI Studio iframe workers, Google tools, avatars, and map tiles.
  app.use((_req, res, next) => {
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('Permissions-Policy', 'geolocation=*');
    next();
  });

  // ─── Gemini Generation Helper with Model Fallback & Retry ─────────────────
  async function generateGeminiContentWithFallback(requestedModel: string | undefined, contents: any, config?: any) {
    const deprecated = ['gemini-1.5-flash', 'gemini-1.5-pro', 'gemini-2.0-flash', 'gemini-2.5-flash', 'gemini-pro'];
    const isDeprecated = requestedModel && deprecated.some(d => requestedModel.includes(d));

    const candidateModels = [
      requestedModel && !isDeprecated ? requestedModel : 'gemini-3.8-flash',
      'gemini-3.8-flash',
      'gemini-flash-latest',
      'gemini-3.1-flash-lite'
    ];
    // Remove duplicate model names while preserving order
    const uniqueModels = [...new Set(candidateModels)];

    let lastError: any = null;
    for (const modelName of uniqueModels) {
      try {
        const response = await getAiClient().models.generateContent({
          model: modelName,
          contents,
          config
        });
        return response;
      } catch (err: any) {
        lastError = err;
        console.warn(`[Gemini AI] Model ${modelName} call failed (${err?.message || err}). Trying next candidate...`);
      }
    }
    throw lastError;
  }

  app.post("/api/ai/shoppingAdvice", async (req, res) => {
    try {
      const { userPrompt, history, systemInstruction } = req.body;
      const contents = [
        ...(history && history.length > 0 ? history.map((h: any) => ({ role: h.role, parts: [{ text: h.text }] })) : []),
        { role: "user", parts: [{ text: userPrompt }] }
      ];
      const config = { systemInstruction, temperature: 0.7 };
      const response = await generateGeminiContentWithFallback("gemini-3.8-flash", contents, config);
      res.json({ text: response.text });
    } catch (e: any) {
      console.error("AI Error:", e);
      if (e.message && (e.message.toLowerCase().includes("suspended") || e.message.toLowerCase().includes("permission denied") || e.message.toLowerCase().includes("denied access") || e.message.includes("PERMISSION_DENIED"))) {
         return res.json({ text: "[System]: Your Gemini API Key has been suspended or denied access. Please check your environment variables to update it." });
      }
      res.status(500).json({ error: e.message || "Failed to generate AI advice" });
    }
  });

  app.post("/api/ai/generateContent", async (req, res) => {
    try {
      const { contents, config, model } = req.body;
      const response = await generateGeminiContentWithFallback(model, contents, config);
      res.json({ text: response.text });
    } catch (e: any) {
      console.error("AI Error:", e);
      if (e.message && (e.message.toLowerCase().includes("suspended") || e.message.toLowerCase().includes("permission denied") || e.message.toLowerCase().includes("denied access") || e.message.includes("PERMISSION_DENIED"))) {
         return res.json({ text: "[System]: Your Gemini API Key has been suspended or denied access. Please check your environment variables to update it." });
      }
      res.status(500).json({ error: e.message || "AI generation failed" });
    }
  });

async function requestWithCurlFallback(url: string, options: any) {
  try {
    const response = await fetch(url, options);
    return response;
  } catch (fetchError: any) {
    console.warn(`[LengoPay] Native fetch failed: ${fetchError.message}. Falling back to curl...`);
    try {
      const { execSync } = await import('child_process');
      const fs = await import('fs');
      const path = await import('path');
      
      const tempDir = path.resolve(process.cwd(), 'scratch');
      if (!fs.existsSync(tempDir)) {
        fs.mkdirSync(tempDir, { recursive: true });
      }
      const tempFilePath = path.join(tempDir, `req_${Date.now()}_${Math.random().toString(36).substring(7)}.json`);
      fs.writeFileSync(tempFilePath, options.body || '', 'utf-8');

      const headerArgs = Object.entries(options.headers || {})
        .map(([key, val]) => `-H "${key}: ${val}"`)
        .join(' ');

      const cmd = `curl -s -S -X ${options.method || 'POST'} ${headerArgs} -d @${tempFilePath} "${url}"`;
      console.log(`[LengoPay Curl] Executing fallback curl command`);
      
      const stdout = execSync(cmd, { encoding: 'utf-8' });
      
      try { fs.unlinkSync(tempFilePath); } catch (e) {}
      
      return {
        ok: true,
        status: 200,
        text: async () => stdout
      };
    } catch (curlError: any) {
      console.error("[LengoPay Curl] Fallback also failed:", curlError.message);
      throw fetchError;
    }
  }
}

  // ─── JWT Auth Middleware Helper ────────────────────────────────────────────
  // Verifies the Supabase JWT from the Authorization header and returns the
  // authenticated user. Returns null (and sends 401) if the token is missing
  // or invalid. Use before any state-mutating endpoint that touches user data.
  async function requireAuth(req: any, res: any): Promise<{ id: string; email: string } | null> {
    const authHeader = req.headers['authorization'] || '';
    const token = authHeader.startsWith('Bearer ') ? authHeader.slice(7) : null;
    if (!token) {
      res.status(401).json({ success: false, error: 'Authentification requise. Veuillez vous connecter.' });
      return null;
    }
    try {
      const { data, error } = await getSupabase().auth.getUser(token);
      if (error || !data?.user) {
        res.status(401).json({ success: false, error: 'Session expirée. Veuillez vous reconnecter.' });
        return null;
      }
      return { id: data.user.id, email: data.user.email || '' };
    } catch {
      res.status(401).json({ success: false, error: 'Token invalide.' });
      return null;
    }
  }

  // Payment Proxy Route
  app.post("/api/payment/mobile", async (req, res) => {
    // ── Auth Guard ── Verify the user is logged in before touching LengoPay
    const authUser = await requireAuth(req, res);
    if (!authUser) return; // requireAuth already sent the 401 response
    console.log(`[API] Payment request received for order: ${req.body.orderId}`);
    
    const { amount, phone, orderId, provider } = req.body;

    // --- INPUT VALIDATION ---
    // 1. Check for missing required fields
    if (!amount || !phone || !orderId || !provider) {
      return res.status(400).json({ 
        success: false, 
        error: "Paramètres manquants (amount, phone, orderId, provider)" 
      });
    }

    // 2. Validate Amount
    const numericAmount = Number(amount);
    if (isNaN(numericAmount) || numericAmount <= 0) {
      return res.status(400).json({ 
        success: false, 
        error: "Montant invalide (doit être un nombre positif)" 
      });
    }

    // 3. Validate Provider (Network)
    const allowedProviders = ['ORANGE', 'MTN', 'CELLCOM'];
    if (!allowedProviders.includes(String(provider).toUpperCase())) {
      return res.status(400).json({ 
        success: false, 
        error: `Réseau non supporté (${provider}). Réseaux autorisés: ${allowedProviders.join(', ')}` 
      });
    }

    // 4. Validate and Sanitize Phone
    let sanitizedPhone = String(phone).replace(/\s/g, '').replace(/^\+224/, '').replace(/^224/, '');
    if (!/^\d{9}$/.test(sanitizedPhone)) {
      return res.status(400).json({ 
        success: false, 
        error: "Numéro de téléphone invalide (format attendu: 9 chiffres, ex: 620123456)" 
      });
    }
    // LengoPay often expects the full international format or just 9 digits depending on country
    // For Guinea, we'll keep it as 9 digits or ask LengoPay docs (assuming 9 digits is safe for GN)
    
    const apiKey = process.env.LENGOPAY_SECRET_KEY;
    const websiteId = process.env.LENGOPAY_WEBSITE_ID;
    let apiUrl = process.env.LENGOPAY_API_URL;
    if (!apiUrl || apiUrl.trim() === "" || apiUrl.includes("your-lengopay-api-url")) {
      apiUrl = "https://portal.lengopay.com/api/v1/payments";
    }
    apiUrl = apiUrl.trim();
    if (!apiUrl.startsWith("http://") && !apiUrl.startsWith("https://")) {
      apiUrl = "https://" + apiUrl;
    }

    let endpoint = apiUrl;
    // Normalize endpoint
    if (apiUrl.endsWith("/v1") || apiUrl.endsWith("/v1/")) {
       endpoint = apiUrl.replace(/\/$/, "") + "/payments";
    }

    if (!apiKey || !websiteId || apiKey === "your-lengopay-secret-key" || apiKey === "your-lengopay-license-key") {
      console.error("[LengoPay] Configuration incomplete. Aborting payment request.");
      return res.status(500).json({ 
        success: false, 
        error: "Configuration LengoPay incomplète sur le serveur.",
        details: "LENGOPAY_SECRET_KEY or LENGOPAY_WEBSITE_ID is missing or set to placeholder values."
      });
    }

    try {
      const trimmedKey = apiKey.trim();
      const trimmedWebsiteId = websiteId.trim();
      
      const appUrl = (process.env.APP_URL || `https://${req.get('host')}`).replace(/\/$/, '');
      
      let authoritativeAmount = Math.round(Number(amount));
      
      // Fetch authoritative amount securely for real orders to prevent client-side manipulation
      if (orderId && String(orderId).startsWith('ORD-')) {
        try {
          const { data: ordersData, error: ordersError } = await getSupabase()
            .from('orders')
            .select('total_amount')
            .eq('tracking_number', String(orderId));
            
          if (ordersError) throw ordersError;
          if (!ordersData || ordersData.length === 0) {
             return res.status(404).json({ success: false, error: "Commande introuvable dans le système." });
          }
          const dbTotal = ordersData.reduce((sum, o) => sum + Number(o.total_amount || 0), 0);
          authoritativeAmount = Math.round(dbTotal);
        } catch (err) {
          console.error("Error fetching order amount:", err);
          return res.status(500).json({ success: false, error: "Erreur lors de la vérification de la commande." });
        }
      }

      const body = {
        websiteid: trimmedWebsiteId,
        amount: authoritativeAmount,
        currency: "GNF",
        country: "GN",
        phone: sanitizedPhone,
        network: String(provider).toUpperCase(),
        order_id: String(orderId), 
        return_url: `${appUrl}/payment-result?orderId=${orderId}&status=success`,
        failure_url: `${appUrl}/payment-result?orderId=${orderId}&status=failure`,
        callback_url: `${appUrl}/api/webhook/gateway?order_id=${orderId}`,
        description: `Paiement #${orderId}`
      };

      console.log(`[LengoPay] Payload:`, JSON.stringify(body, null, 2));
      
      let vpsProxyUrl = (process.env.VPS_PROXY_URL || '').trim();
      const vpsProxySecret = (process.env.VPS_PROXY_SECRET || '').trim();

      let fetchUrl = endpoint;
      const fetchHeaders: any = {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'Authorization': `Basic ${trimmedKey}`
      };

      const isUsingProxy = !!(vpsProxyUrl && vpsProxySecret && vpsProxyUrl !== "" && vpsProxySecret !== "");

      if (isUsingProxy) {
        if (!vpsProxyUrl.startsWith("http://") && !vpsProxyUrl.startsWith("https://")) {
           vpsProxyUrl = "http://" + vpsProxyUrl;
        }
        console.log(`[LengoPay] Routing request through VPS Proxy: ${vpsProxyUrl}`);
        fetchUrl = vpsProxyUrl;
        fetchHeaders['x-target-url'] = endpoint;
        fetchHeaders['x-proxy-secret'] = vpsProxySecret;
      } else {
        console.log(`[LengoPay] Initiating direct payment at: ${endpoint}`);
      }

      // Ensure URL is valid before fetching
      try {
        new URL(fetchUrl);
      } catch(e) {
        console.error(`[LengoPay] Invalid API/Proxy URL: ${fetchUrl}`);
        return res.status(500).json({
          success: false,
          error: "Configuration URL invalide",
          details: `L'URL cible n'est pas valide: ${fetchUrl}`
        });
      }

      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 30000); // 30s timeout

      try {
        let response;
        try {
          response = await requestWithCurlFallback(fetchUrl, {
            method: 'POST',
            headers: fetchHeaders,
            body: JSON.stringify(body),
            signal: controller.signal
          });
        } catch (fetchError: any) {
          if (isUsingProxy) {
            console.warn(`[LengoPay] Proxy request failed: ${fetchError.message}. Retrying directly to LengoPay...`);
            const directHeaders = {
              'Content-Type': 'application/json',
              'Accept': 'application/json',
              'Authorization': `Basic ${trimmedKey}`
            };
            response = await requestWithCurlFallback(endpoint, {
              method: 'POST',
              headers: directHeaders,
              body: JSON.stringify(body),
              signal: controller.signal
            });
          } else {
            throw fetchError;
          }
        }
        clearTimeout(timeoutId);

        const responseText = await response.text();
        console.log(`[LengoPay] Status: ${response.status}`);
        console.log(`[LengoPay] Raw Response:`, responseText);

        if (!response.ok) {
          console.error(`[LengoPay] Error response:`, responseText);
          
          let friendlyError = "LengoPay platform error";
          if (response.status === 401 || responseText.includes("Unauthorized")) {
             friendlyError = "Invalid LengoPay Secret Key, Website ID, or unauthorized IP address. Please check your LengoPay credentials in the environment variables and ensure this server IP is whitelisted.";
          }
          else if (responseText.includes("<!DOCTYPE html>")) {
             friendlyError = "LengoPay API returned an HTML error page. The API endpoint might be incorrect or experiencing issues.";
          }
          
          return res.status(response.status).json({ 
            success: false, 
            error: friendlyError,
            details: responseText.slice(0, 200)
          });
        }

        let result: any;
        try {
          result = JSON.parse(responseText);
        } catch (e) {
          return res.status(502).json({
            success: false,
            error: "Réponse non-JSON de LengoPay",
            details: responseText.slice(0, 200)
          });
        }

        if (result.status === "Success" || result.payment_url) {
          res.json({
            success: true,
            payment_url: result.payment_url,
            pay_id: result.pay_id
          });
        } else {
          res.status(400).json({
            success: false,
            error: "Format de réponse inattendu",
            details: JSON.stringify(result)
          });
        }
      } catch (fetchError: any) {
        clearTimeout(timeoutId);
        throw fetchError;
      }
    } catch (error: any) {
      console.error("[LengoPay] Exception:", error.message);
      if (error.cause) {
        console.error("[LengoPay] Exception Cause:", error.cause.message || error.cause);
      }
      res.status(500).json({ 
        success: false, 
        error: "Erreur lors de la communication avec LengoPay",
        details: error.cause ? error.cause.message : error.message
      });
    }
  });

  // Webhook Route
  app.post("/api/webhook/gateway", express.json(), async (req, res) => {
    // Verify Webhook Signature
    const signature = req.headers['x-lengopay-signature'];
    const webhookSecret = process.env.LENGOPAY_WEBHOOK_SECRET;

    if (webhookSecret && signature !== webhookSecret) {
       console.warn("LengoPay Webhook: Signature mismatch");
       return res.status(401).send("Unauthorized");
    }

    try {
      const event = req.body;
      const payId = event.pay_id;
      const status = String(event.status).toLowerCase();
      const orderIdFromQuery = req.query.order_id;
      
      console.log(`LengoPay Webhook Event Received: ${status} | PayID: ${payId} | Query OrderID: ${orderIdFromQuery}`);
       // Try to find the order ID
      let rawOrderIds = (event.order_id || orderIdFromQuery || '').split(',').filter(Boolean);
      let resolvedOrderIds: string[] = [];

      for (const idCandidate of rawOrderIds) {
        if (idCandidate.startsWith('ORD-')) {
          // Find the actual UUIDs from tracking_number
          const { data: ords } = await getSupabase()
            .from('orders')
            .select('id')
            .eq('tracking_number', idCandidate);
            
          if (ords && ords.length > 0) {
            ords.forEach((o: any) => resolvedOrderIds.push(o.id));
          }
        } else if (idCandidate.startsWith('TOPUP-')) {
          resolvedOrderIds.push(idCandidate); // Topups stay as is
        } else {
          resolvedOrderIds.push(idCandidate); // Assume UUID
        }
      }

      if (resolvedOrderIds.length === 0 && payId) {
        // Search by tracking_number using PayID as fallback
        const { data: ords } = await getSupabase()
          .from('orders')
          .select('id')
          .eq('tracking_number', payId);
          
        if (ords && ords.length > 0) {
          ords.forEach((o: any) => resolvedOrderIds.push(o.id));
        }
      }

      if (resolvedOrderIds.length === 0) {
        console.error("Could not determine order ID for webhook event");
        return res.status(400).send("Order ID not found");
      }
      
      const orderIdStr = resolvedOrderIds[0];
      const isTopup = orderIdStr.startsWith('TOPUP-');

      if (status === 'success') {
          const providerTxId = payId || 'unknown';
          
          if (isTopup) {
             try {
                const parts = orderIdStr.split('-');
                const payloadParts = parts[1].split('_');
                const userId = payloadParts[0];
                const amountFromId = parseInt(payloadParts[1] || '0', 10);
                const actualAmount = event.amount || amountFromId;
                
                if (userId && actualAmount) {
                   // Idempotency check using description pattern
                   const { data: existingTx } = await getSupabase()
                     .from('wallet_transactions')
                     .select('id')
                     .eq('description', `Recharge Mobile ID: ${providerTxId}`)
                     .single();
                   
                   if (existingTx) {
                      console.log("Duplicate recharge detection. Ignoring.");
                   } else {
                      // Atomic Increment
                      await getSupabase().rpc('increment_wallet_balance', { 
                         user_id: userId, 
                         amount: actualAmount 
                      });
 
                      // Log Transaction
                      await getSupabase().from('wallet_transactions').insert({
                         profile_id: userId,
                         amount: actualAmount,
                         type: 'deposit',
                         description: `Recharge Mobile ID: ${providerTxId}`,
                         status: 'completed'
                      });
 
                      console.log(`Topup applied for user ${userId}: +${actualAmount}`);
                   }
                }
             } catch(err) {
                console.error("Failed to process topup:", err);
             }
          } else {
             // FIX (Bug 2): Mark as paid then call financial distribution RPC
             // so vendor/courier/commission payouts are always executed,
             // regardless of which webhook endpoint LengoPay hits.
             const { error: markPaidErr } = await getSupabase()
               .from('orders')
               .update({ status: 'paid', financial_status: 'paid', updated_at: new Date().toISOString() })
               .in('id', resolvedOrderIds);
               
             if (markPaidErr) {
                 console.error("[Gateway] Supabase update error:", markPaidErr);
                 return res.status(500).json({ error: "Failed to update order" });
             }

             // Distribute financials for each resolved order UUID
             // SECURITY: Deduplicate IDs to prevent double-payout if the same
             // order ID appears multiple times in the webhook payload (e.g.
             // "ORD-123,ORD-123"). Without this, the RPC would fire twice and
             // pay the vendor/courier double from the platform's funds.
             const uniqueOrderIds = Array.from(new Set(resolvedOrderIds));
             for (const orderId of uniqueOrderIds) {
               const { data: financialResult, error: financialErr } = await getSupabase()
                 .rpc('secure_process_order_financials', { p_order_id: orderId });
               if (financialErr) {
                 console.error(`[Gateway] Financial RPC failed for order ${orderId}:`, financialErr.message);
               } else {
                 console.log(`[Gateway] Financials OK — order: ${orderId}`, financialResult);
               }
             }

             console.log(`[Gateway] Order(s) ${resolvedOrderIds.join(', ')} marked as paid.`);
          }
      } else if (status === 'failed' || status === 'cancelled' || status === 'expired') {
          if (!isTopup) {
              await getSupabase()
                .from('orders')
                .update({ 
                  status: 'cancelled',
                  financial_status: 'failed',
                  notes: `Paiement ${status}: ${event.message || event.error_message || 'Inconnu'}`
                })
                .in('id', resolvedOrderIds);
              console.log(`Order(s) ${resolvedOrderIds.join(', ')} marked as ${status}.`);
          }
      }
      
      res.status(200).send("Webhook handled");
    } catch (error) {
      console.error("Webhook processing error:", error);
      res.status(400).json({ error: "Invalid payload" });
    }
  });

  // ─── POST /api/payment/initiate ──────────────────────────────────────────
  // Direct server-to-server payment initiation. No proxy required.
  // Replaces the proxy-dependent /api/payment/mobile for Phase 3+ deploys.
  app.post("/api/payment/initiate", async (req, res) => {
    const { amount, phone, orderId, provider } = req.body as {
      amount: unknown;
      phone: unknown;
      orderId: unknown;
      provider: unknown;
    };

    // 1. Config guard — fail loudly at request time if keys are missing
    const secretKey = process.env.LENGOPAY_SECRET_KEY?.trim();
    const websiteId = process.env.LENGOPAY_WEBSITE_ID?.trim();
    const apiUrl =
      process.env.LENGOPAY_API_URL?.trim() ||
      "https://portal.lengopay.com/api/v1/payments";

    if (!secretKey || !websiteId) {
      console.error("[Initiate] LengoPay credentials not configured.");
      return res.status(500).json({
        success: false,
        error:
          "[Config] LENGOPAY_SECRET_KEY and LENGOPAY_WEBSITE_ID must be set in environment variables.",
      });
    }

    // 2. Input validation
    if (!amount || !phone || !orderId || !provider) {
      return res.status(400).json({
        success: false,
        error:
          "Paramètres manquants : amount, phone, orderId et provider sont requis.",
      });
    }

    const numericAmount = Number(amount);
    if (isNaN(numericAmount) || numericAmount <= 0) {
      return res
        .status(400)
        .json({ success: false, error: "Montant invalide (nombre positif requis)." });
    }

    const ALLOWED_PROVIDERS = ["ORANGE", "MTN", "CELLCOM"] as const;
    const network = String(provider).toUpperCase();
    if (!ALLOWED_PROVIDERS.includes(network as (typeof ALLOWED_PROVIDERS)[number])) {
      return res.status(400).json({
        success: false,
        error: `Réseau non supporté: ${provider}. Réseaux autorisés: ${ALLOWED_PROVIDERS.join(", ")}.`,
      });
    }

    const sanitizedPhone = String(phone)
      .replace(/\s/g, "")
      .replace(/^\+224/, "")
      .replace(/^224/, "");
    if (!/^\d{9}$/.test(sanitizedPhone)) {
      return res.status(400).json({
        success: false,
        error:
          "Numéro de téléphone invalide (9 chiffres requis, ex: 620123456).",
      });
    }

    // 3. Fetch authoritative amount from DB — prevents client-side tampering
    let authoritativeAmount = Math.round(numericAmount);
    const orderIdStr = String(orderId);

    if (orderIdStr.startsWith("ORD-")) {
      try {
        const { data: rows, error: dbErr } = await getSupabase()
          .from("orders")
          .select("total_amount")
          .eq("tracking_number", orderIdStr);

        if (dbErr) throw dbErr;
        if (!rows || rows.length === 0) {
          return res
            .status(404)
            .json({ success: false, error: "Commande introuvable dans le système." });
        }
        authoritativeAmount = Math.round(
          rows.reduce((sum, o) => sum + Number(o.total_amount ?? 0), 0)
        );
      } catch (err: any) {
        console.error("[Initiate] DB error fetching order amount:", err.message);
        return res.status(500).json({
          success: false,
          error: "Erreur lors de la vérification du montant de la commande.",
        });
      }
    }

    // 4. Build canonical LengoPay payload
    const appUrl = (
      process.env.APP_URL ?? `https://${req.get("host")}`
    ).replace(/\/$/, "");

    const lengoPayload = {
      websiteid: websiteId,
      amount: authoritativeAmount,
      currency: "GNF",
      country: "GN",
      phone: sanitizedPhone,
      network,
      order_id: orderIdStr,
      return_url: `${appUrl}/payment-result?orderId=${orderIdStr}&status=success`,
      failure_url: `${appUrl}/payment-result?orderId=${orderIdStr}&status=failure`,
      callback_url: `${appUrl}/api/payment/callback?order_id=${orderIdStr}`,
      description: `Paiement Fatibara #${orderIdStr}`,
    };

    console.log(
      `[Initiate] → LengoPay | order: ${orderIdStr} | amount: ${authoritativeAmount} GNF | network: ${network}`
    );

    // 5. Direct server-to-server POST to LengoPay (no proxy)
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 30_000);

    try {
      let response: Response;
      try {
        response = await fetch(apiUrl, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Accept: "application/json",
            Authorization: `Basic ${secretKey}`,
          },
          body: JSON.stringify(lengoPayload),
          signal: controller.signal,
        });
      } finally {
        clearTimeout(timeoutId);
      }

      const responseText = await response.text();
      console.log(
        `[Initiate] LengoPay responded ${response.status} | ${responseText.slice(0, 300)}`
      );

      if (!response.ok) {
        let friendlyError = "Erreur de la plateforme LengoPay.";
        if (response.status === 401) {
          friendlyError =
            "Clé LengoPay invalide ou adresse IP non autorisée. Vérifiez vos identifiants et la whitelist IP.";
        } else if (responseText.includes("<!DOCTYPE")) {
          friendlyError =
            "LengoPay a retourné une page HTML — l'URL de l'API est peut-être incorrecte.";
        }
        const statusCode =
          response.status >= 400 && response.status < 600 ? response.status : 502;
        return res.status(statusCode).json({
          success: false,
          error: friendlyError,
          details: responseText.slice(0, 200),
        });
      }

      let result: any;
      try {
        result = JSON.parse(responseText);
      } catch {
        return res.status(502).json({
          success: false,
          error: "Réponse non-JSON reçue de LengoPay.",
          details: responseText.slice(0, 200),
        });
      }

      if (result.status === "Success" || result.payment_url) {
        return res.status(200).json({
          success: true,
          payment_url: result.payment_url,
          pay_id: result.pay_id,
        });
      }

      return res.status(400).json({
        success: false,
        error: "Réponse inattendue de LengoPay.",
        details: result,
      });
    } catch (err: any) {
      clearTimeout(timeoutId);
      if (err.name === "AbortError") {
        console.error("[Initiate] LengoPay request timed out after 30s.");
        return res
          .status(504)
          .json({ success: false, error: "La requête vers LengoPay a expiré (30s)." });
      }
      console.error("[Initiate] Exception:", err.message, err.cause?.message);
      return res.status(500).json({
        success: false,
        error: "Erreur de communication avec LengoPay.",
        details: err.cause?.message ?? err.message,
      });
    }
  });

  // ─── POST /api/payment/callback ──────────────────────────────────────────
  // Receives payment status notifications from LengoPay.
  // Handles both order payments and wallet top-ups.
  // Delegates financial distribution to the secure_process_order_financials RPC.
  app.post("/api/payment/callback", express.json(), async (req, res) => {
    // 1. Webhook signature verification
    const receivedSig = req.headers["x-lengopay-signature"] as string | undefined;
    const webhookSecret = process.env.LENGOPAY_WEBHOOK_SECRET?.trim();

    if (webhookSecret && receivedSig !== webhookSecret) {
      console.warn("[Callback] Signature mismatch — rejecting.");
      return res.status(401).json({ error: "Unauthorized: invalid webhook signature." });
    }

    // 2. Parse body safely
    let event: Record<string, any>;
    try {
      event = typeof req.body === "string" ? JSON.parse(req.body) : (req.body ?? {});
    } catch {
      return res.status(400).json({ error: "Invalid JSON payload." });
    }

    const payId = String(event.pay_id ?? "");
    const rawStatus = String(event.status ?? "").toUpperCase();
    const eventAmount = Number(event.amount ?? 0);
    const orderIdFromQuery = String(req.query.order_id ?? "");
    const orderIdFromBody = String(event.order_id ?? "");

    console.log(
      `[Callback] Received | status: ${rawStatus} | pay_id: ${payId} | order: ${orderIdFromBody || orderIdFromQuery || "(none)"}`
    );

    // 3. Collect and deduplicate all candidate IDs from body + query string
    type ResolvedEntry =
      | { kind: "topup"; raw: string }
      | { kind: "order"; uuid: string };

    const rawCandidates = [
      ...new Set(
        [orderIdFromBody, orderIdFromQuery]
          .join(",")
          .split(",")
          .map((s) => s.trim())
          .filter(Boolean)
      ),
    ];

    const resolved: ResolvedEntry[] = [];

    try {
      for (const rawId of rawCandidates) {
        if (rawId.startsWith("TOPUP-")) {
          resolved.push({ kind: "topup", raw: rawId });
          continue;
        }
        if (rawId.startsWith("ORD-")) {
          // Resolve human-readable tracking number → internal UUID(s)
          const { data: rows } = await getSupabase()
            .from("orders")
            .select("id")
            .eq("tracking_number", rawId);
          rows?.forEach((r: any) => resolved.push({ kind: "order", uuid: r.id }));
          continue;
        }
        // Assume UUID directly
        resolved.push({ kind: "order", uuid: rawId });
      }

      // Fallback: treat pay_id as a tracking_number
      if (resolved.length === 0 && payId) {
        const { data: rows } = await getSupabase()
          .from("orders")
          .select("id")
          .eq("tracking_number", payId);
        rows?.forEach((r: any) => resolved.push({ kind: "order", uuid: r.id }));
      }

      if (resolved.length === 0) {
        // Acknowledge without action — prevents LengoPay from retrying forever
        console.warn("[Callback] No matching order found for event. Acknowledged.");
        return res
          .status(200)
          .json({ received: true, warning: "Order not found — event acknowledged." });
      }

      // 4. Process by status
      if (rawStatus === "SUCCESS") {
        for (const item of resolved) {
          // ── Wallet top-up ─────────────────────────────────────────────────
          if (item.kind === "topup") {
            // Format: TOPUP-<userId>_<amount>_<timestamp>
            const inner = item.raw.slice("TOPUP-".length);
            const [userId, amountPart] = inner.split("_");
            const topupAmount = parseFloat(amountPart) || eventAmount;

            if (!userId || !topupAmount) {
              console.warn("[Callback] Malformed TOPUP payload:", item.raw);
              continue;
            }

            // Idempotency: skip if this pay_id was already processed
            const { data: existingTx } = await getSupabase()
              .from("wallet_transactions")
              .select("id")
              .eq("reference_id", payId)
              .maybeSingle();

            if (existingTx) {
              console.log("[Callback] Duplicate topup — skipping:", payId);
              continue;
            }

            await getSupabase().rpc("increment_wallet_balance", {
              user_id: userId,
              amount: topupAmount,
            });

            await getSupabase().from("wallet_transactions").insert({
              profile_id: userId,
              amount: topupAmount,
              type: "deposit",
              status: "completed",
              reference_id: payId,
              description: `Recharge Mobile Money — ${topupAmount.toLocaleString("fr-GN")} GNF (ref: ${payId})`,
            });

            // Notify user
            await getSupabase()
              .from("notifications")
              .insert({
                user_id: userId,
                type: "payment",
                title: "Recharge confirmée ✅",
                message: `Votre portefeuille a été crédité de ${topupAmount.toLocaleString("fr-GN")} GNF.`,
                is_read: false,
              });

            console.log(
              `[Callback] Topup applied: +${topupAmount} GNF → user ${userId}`
            );
            continue;
          }

          // ── Order payment ─────────────────────────────────────────────────
          const orderId = item.uuid;

          // Fetch current order state (idempotency check)
          const { data: orderRow, error: fetchErr } = await getSupabase()
            .from("orders")
            .select("id, status, financial_status, user_id")
            .eq("id", orderId)
            .single();

          if (fetchErr || !orderRow) {
            console.warn("[Callback] Order UUID not found:", orderId);
            continue;
          }

          if (orderRow.financial_status === "processed") {
            console.log("[Callback] Order already processed — idempotency skip:", orderId);
            continue;
          }

          // 4a. Mark order as paid
          // NOTE: payment_method is stored inside shipping_address JSONB at
          // order creation time — there is no top-level payment_method column
          // on public.orders. Do NOT include it in the UPDATE payload.
          const { error: updateErr } = await getSupabase()
            .from("orders")
            .update({
              status: "paid",
              financial_status: "paid",
              updated_at: new Date().toISOString(),
            })
            .eq("id", orderId);

          if (updateErr) {
            console.error("[Callback] Failed to update order status:", orderId, updateErr.message);
            continue;
          }

          // 4b. Atomically distribute vendor/courier/commission payouts
          const { data: financialResult, error: financialErr } =
            await getSupabase().rpc("secure_process_order_financials", {
              p_order_id: orderId,
            });

          if (financialErr) {
            console.error(
              "[Callback] Financial RPC failed for order:",
              orderId,
              financialErr.message
            );
            // Order is already marked paid — financial reprocessing can be triggered manually
          } else {
            console.log(`[Callback] Financials OK — order: ${orderId}`, financialResult);
          }

          // 4c. Notify buyer
          if (orderRow.user_id) {
            await getSupabase()
              .from("notifications")
              .insert({
                user_id: orderRow.user_id,
                type: "payment",
                title: "Paiement confirmé ✅",
                message:
                  "Votre paiement a été confirmé avec succès. Votre commande est en cours de préparation.",
                is_read: false,
              });
          }

          console.log(`[Callback] Order ${orderId} → paid ✅`);
        }
      } else if (["FAILED", "CANCELLED", "EXPIRED"].includes(rawStatus)) {
        for (const item of resolved) {
          if (item.kind !== "order") continue;

          // Only cancel orders not already paid/processed
          await getSupabase()
            .from("orders")
            .update({
              status: "cancelled",
              financial_status: "failed",
              notes: `Paiement ${rawStatus.toLowerCase()} — ${event.message ?? "Aucun détail fourni"}`,
              updated_at: new Date().toISOString(),
            })
            .eq("id", item.uuid)
            .not("financial_status", "eq", "processed");

          console.log(`[Callback] Order ${item.uuid} → ${rawStatus.toLowerCase()}`);
        }
      } else {
        console.log(`[Callback] Unhandled status "${rawStatus}" — acknowledged without action.`);
      }

      return res.status(200).json({ received: true });
    } catch (err: any) {
      console.error("[Callback] Unhandled exception:", err.message);
      // Always return 200 to LengoPay — prevents infinite retry loops
      return res
        .status(200)
        .json({ received: true, error: "Internal error logged — event acknowledged." });
    }
  });

  // Health route
  app.get("/api/health", (req, res) => {
    res.json({ status: "ok" });
  });

  // LengoPay & Wallet Top-up routes
  const callHandler = (handler: any, req: any, res: any) => {
    const fn = typeof handler === 'function' ? handler : handler?.default;
    if (typeof fn === 'function') return fn(req, res);
    return res.status(500).json({ error: 'Handler not callable' });
  };

  app.post("/api/lengopay/payin", (req, res) => callHandler(lengopayPayinHandler, req, res));
  app.get("/api/payment/status", (req, res) => callHandler(paymentStatusHandler, req, res));
  app.post("/api/push/subscribe", (req, res) => callHandler(pushSubscribeHandler, req, res));

  // System Administration Routes
  app.post("/api/admin/system-log", async (req, res) => {
    const { component, status, details } = req.body;
    
    // REQUIREMENT: Admin access check would go here. 
    // Assuming secure call or internal usage.
    const { error } = await getSupabase().from('system_health_logs').insert({ 
      component, 
      status, 
      details 
    });

    if (error) {
      console.error("Failed to insert health log:", error);
      return res.status(500).json({ success: false, error: error.message });
    }
    res.json({ success: true });
  });

  app.post("/api/admin/housekeeping-task", async (req, res) => {
    const { task_name, status } = req.body;
    
    const { error } = await getSupabase().from('housekeeping_tasks').upsert({ 
      task_name, 
      status, 
      last_run: new Date().toISOString() 
    });

    if (error) {
      console.error("Failed to update housekeeping task:", error);
      return res.status(500).json({ success: false, error: error.message });
    }
    res.json({ success: true });
  });

  app.post("/api/admin/audit-log", async (req, res) => {
    try {
      const { userId, action, entityType, entityId, storeId, data } = req.body;
      const isUuid = (val: any) => typeof val === 'string' && /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(val.trim());
      
      const cleanUserId = isUuid(userId) ? userId.trim() : null;
      const cleanStoreId = isUuid(storeId) ? storeId.trim() : null;

      const payload = {
        action: action || 'ACTION',
        ...(userId && !cleanUserId ? { raw_user_id: userId } : {}),
        ...(storeId && !cleanStoreId ? { raw_store_id: storeId } : {}),
        ...(typeof data === 'object' && data !== null ? data : { payload: data })
      };

      let { error } = await getSupabase().from('audit_logs').insert({
        user_id: cleanUserId,
        entity_type: entityType || 'system',
        entity_id: entityId ? String(entityId) : null,
        store_id: cleanStoreId,
        new_data: payload
      });

      // If user_id violates FK constraint (audit_logs_user_id_fkey on profiles table), retry with user_id: null
      if (error && (error.code === '23503' || error.message?.includes('foreign key') || error.message?.includes('profiles'))) {
        payload.unlinked_user_id = cleanUserId;
        const retryRes = await getSupabase().from('audit_logs').insert({
          user_id: null,
          entity_type: entityType || 'system',
          entity_id: entityId ? String(entityId) : null,
          store_id: cleanStoreId,
          new_data: payload
        });
        error = retryRes.error;
      }

      if (error) {
        console.warn("[AuditLog API] Insert warning:", error.message);
        return res.json({ success: false, error: error.message });
      }
      res.json({ success: true });
    } catch (err: any) {
      console.warn("[AuditLog API] Error:", err?.message);
      res.json({ success: false, error: err?.message });
    }
  });

  // ── Database Direct Sync for User Wallet Balances ───────────────────────
  async function syncDatabaseUserBalances() {
    try {
      const supabase = getSupabase();
      const targetUid = '8fd9078a-1a3d-400a-bf4f-f2db5c5ddfcd'; // Lamine Traore

      // 1. Direct update to profiles table in Supabase PostgreSQL
      const { data: prof, error: profErr } = await supabase
        .from('profiles')
        .update({ wallet_balance: 1000000 })
        .eq('id', targetUid)
        .select('id, full_name, wallet_balance');

      if (profErr) {
        console.error('[DB Direct Sync] Error updating profiles:', profErr.message);
      } else {
        console.log('[DB Direct Sync] Profiles table updated in Supabase for Lamine Traore:', prof);
      }

      // 2. Direct update to stores table in Supabase PostgreSQL
      const { data: stores, error: storeErr } = await supabase
        .from('stores')
        .update({ balance: 1000000 })
        .eq('owner_id', targetUid)
        .select('id, name, balance');

      if (storeErr) {
        console.error('[DB Direct Sync] Error updating stores:', storeErr.message);
      } else {
        console.log('[DB Direct Sync] Stores table updated in Supabase for Lamine Traore:', stores);
      }
    } catch (err: any) {
      console.error('[DB Direct Sync] Error:', err?.message || err);
    }
  }

  app.post("/api/admin/sync-user-balance", async (req, res) => {
    const { userId, amount } = req.body;
    const targetUid = userId || '8fd9078a-1a3d-400a-bf4f-f2db5c5ddfcd';
    const targetAmt = amount !== undefined ? Number(amount) : 1000000;

    try {
      const supabase = getSupabase();
      const { data: prof, error: profErr } = await supabase
        .from('profiles')
        .update({ wallet_balance: targetAmt })
        .eq('id', targetUid)
        .select('id, full_name, wallet_balance');

      const { data: stores, error: storeErr } = await supabase
        .from('stores')
        .update({ balance: targetAmt })
        .eq('owner_id', targetUid)
        .select('id, name, balance');

      res.json({ success: true, profile: prof, stores, profErr: profErr?.message, storeErr: storeErr?.message });
    } catch (e: any) {
      res.status(500).json({ success: false, error: e.message });
    }
  });

  // ─── Vendor Invitations Management Endpoints (Admin) ─────────────────────────
  // GET /api/admin/vendor-invitations - fetch recent invitations list
  app.get("/api/admin/vendor-invitations", async (req, res) => {
    try {
      const supabase = getSupabase();
      const { data, error } = await supabase
        .from('vendor_invitations')
        .select('id, token, email_hint, label, used_at, expires_at, is_revoked, created_at')
        .order('created_at', { ascending: false })
        .limit(50);

      if (error) {
        console.error("[VendorInvitations API] Error fetching invitations:", error.message);
        return res.status(500).json({ success: false, error: error.message });
      }

      res.json({ success: true, data: data || [] });
    } catch (err: any) {
      console.error("[VendorInvitations API] Unexpected error:", err);
      res.status(500).json({ success: false, error: err.message });
    }
  });

  // POST /api/admin/vendor-invitations - generate a new invitation
  app.post("/api/admin/vendor-invitations", async (req, res) => {
    try {
      const { emailHint, label, expiresDays } = req.body;
      const supabase = getSupabase();

      // Check caller auth if available, or fallback to known admin profile
      let creatorId = '35782753-330e-4d2a-9e80-2f96e1b02c06';
      const authHeader = req.headers['authorization'] || '';
      const token = authHeader.startsWith('Bearer ') ? authHeader.slice(7) : null;
      if (token) {
        try {
          const { data: userData } = await supabase.auth.getUser(token);
          if (userData?.user?.id) creatorId = userData.user.id;
        } catch {
          // ignore token error, fallback to creatorId
        }
      }

      const inviteToken = crypto.randomBytes(16).toString('hex');
      const days = Number(expiresDays) || 7;
      const expiresAt = new Date(Date.now() + days * 24 * 60 * 60 * 1000).toISOString();

      const { data, error } = await supabase
        .from('vendor_invitations')
        .insert({
          token: inviteToken,
          created_by: creatorId,
          email_hint: emailHint ? String(emailHint).trim() : null,
          label: label ? String(label).trim() : null,
          expires_at: expiresAt,
          is_revoked: false
        })
        .select()
        .single();

      if (error) {
        console.error("[VendorInvitations API] Error inserting invitation:", error.message);
        return res.status(500).json({ success: false, error: error.message });
      }

      res.json({ success: true, token: inviteToken, data });
    } catch (err: any) {
      console.error("[VendorInvitations API] Creation error:", err);
      res.status(500).json({ success: false, error: err.message });
    }
  });

  // POST /api/admin/vendor-invitations/:id/revoke - revoke an existing invitation
  app.post("/api/admin/vendor-invitations/:id/revoke", async (req, res) => {
    try {
      const { id } = req.params;
      const supabase = getSupabase();
      const { error } = await supabase
        .from('vendor_invitations')
        .update({ is_revoked: true })
        .eq('id', id);

      if (error) {
        return res.status(500).json({ success: false, error: error.message });
      }

      res.json({ success: true });
    } catch (err: any) {
      res.status(500).json({ success: false, error: err.message });
    }
  });

  // ─── POST /api/courier/location ───────────────────────────────────────────
  // Safe backend proxy to record courier telemetry without RLS or client credential failure
  app.post("/api/courier/location", async (req, res) => {
    try {
      const { orderId, courierId, lat, lng, heading, speed } = req.body;
      if (!orderId || typeof lat !== 'number' || typeof lng !== 'number' || isNaN(lat) || isNaN(lng)) {
        return res.status(400).json({ success: false, error: 'Paramètres de localisation invalides.' });
      }

      // Check if orderId is a valid UUID
      const UUID_REGEX = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
      if (!UUID_REGEX.test(orderId)) {
        return res.status(200).json({ success: true, note: 'Simulation order ID skipped from DB' });
      }

      const supabase = getSupabase();
      const payload: any = {
        order_id: orderId,
        lat,
        lng,
        updated_at: new Date().toISOString(),
      };
      if (courierId && UUID_REGEX.test(courierId)) {
        payload.courier_id = courierId;
      }
      if (typeof heading === 'number' && !isNaN(heading)) {
        payload.heading = heading;
      }
      if (typeof speed === 'number' && !isNaN(speed)) {
        payload.speed = speed;
      }

      const { error: upsertErr } = await supabase
        .from('courier_locations')
        .upsert(payload, { onConflict: 'order_id' });

      if (upsertErr) {
        console.warn('[API Courier Location] Upsert error:', upsertErr);
        return res.status(500).json({ success: false, error: upsertErr.message });
      }

      return res.status(200).json({ success: true });
    } catch (err: any) {
      console.error('[API Courier Location] Exception:', err);
      return res.status(500).json({ success: false, error: err.message });
    }
  });

  // ─── POST /api/courier/complete-delivery ──────────────────────────────────
  // Atomic courier delivery completion endpoint
  // 1. Verifies courier JWT authentication
  // 2. Checks assigned courier or admin permissions
  // 3. Verifies OTP against orders.delivery_otp
  // 4. Calculates courier payout (80% of delivery fee) & handles cash-on-delivery
  // 5. Updates order status to 'delivered' and financial_status to 'processed'
  // 6. Credits courier wallet and updates courier active capacity
  // 7. Credits vendor if not already credited
  // 8. Creates immutable ledger transactions and notifies parties
  app.post("/api/courier/complete-delivery", async (req, res) => {
    const authUser = await requireAuth(req, res);
    if (!authUser) return;

    const { orderId, otp } = req.body;
    if (!orderId) {
      return res.status(400).json({ success: false, error: 'Identifiant de commande manquant.' });
    }

    try {
      const supabase = getSupabase();

      // 1. Fetch order
      const { data: order, error: orderErr } = await supabase
        .from('orders')
        .select('*')
        .eq('id', orderId)
        .single();

      if (orderErr || !order) {
        return res.status(404).json({ success: false, error: 'Commande introuvable.' });
      }

      // 2. Check authorization
      const { data: callerProfile } = await supabase
        .from('profiles')
        .select('id, profile_type, is_admin')
        .eq('id', authUser.id)
        .single();

      const isAdmin = callerProfile?.is_admin === true || callerProfile?.profile_type === 'admin';
      if (order.courier_id !== authUser.id && !isAdmin) {
        return res.status(403).json({
          success: false,
          error: "Non autorisé : vous n'êtes pas le livreur assigné à cette commande.",
        });
      }

      // 3. Terminal state check
      if (order.status === 'delivered') {
        return res.status(400).json({ success: false, error: 'Cette commande a déjà été livrée.' });
      }
      if (order.status === 'cancelled') {
        return res.status(400).json({ success: false, error: 'Cette commande a été annulée.' });
      }

      // 4. OTP verification (server-side)
      if (order.delivery_otp && String(order.delivery_otp).trim() !== '') {
        const cleanExpected = String(order.delivery_otp).trim();
        const cleanProvided = String(otp || '').trim();
        if (cleanExpected !== cleanProvided) {
          return res.status(400).json({
            success: false,
            error: 'Code OTP incorrect. Veuillez vérifier avec le client et réessayer.',
          });
        }
      }

      // 5. Courier Payout Calculation
      const deliveryFee = Number(order.delivery_fee || order.vendor_delivery_fee || 0);
      let courierPayout = Math.round(deliveryFee * 0.8);

      const paymentMethod =
        order.shipping_address?.payment_method ||
        (order.financial_status === 'paid' || order.financial_status === 'processed' ? 'wallet' : 'cash');
      const isCash = paymentMethod === 'cash';

      if (isCash) {
        courierPayout = courierPayout - Number(order.total_amount || 0);
      }

      // 6. Courier Credit & Ledger
      const courierUserId = order.courier_id || authUser.id;
      if (courierPayout > 0) {
        // Increment profiles.wallet_balance
        const { error: incErr } = await supabase.rpc('increment_wallet_balance', {
          user_id: courierUserId,
          amount: courierPayout,
        });

        if (incErr) {
          // Fallback manual increment
          const { data: p } = await supabase
            .from('profiles')
            .select('wallet_balance')
            .eq('id', courierUserId)
            .single();
          await supabase
            .from('profiles')
            .update({
              wallet_balance: (Number(p?.wallet_balance) || 0) + courierPayout,
              updated_at: new Date().toISOString(),
            })
            .eq('id', courierUserId);
        }

        // Increment courier_profiles.balance
        const { data: cProf } = await supabase
          .from('courier_profiles')
          .select('balance')
          .eq('user_id', courierUserId)
          .maybeSingle();

        if (cProf) {
          await supabase
            .from('courier_profiles')
            .update({
              balance: (Number(cProf.balance) || 0) + courierPayout,
              updated_at: new Date().toISOString(),
            })
            .eq('user_id', courierUserId);
        }

        // Ledger transaction
        await supabase.from('wallet_transactions').insert({
          profile_id: courierUserId,
          amount: courierPayout,
          type: 'delivery_fee',
          reference_id: order.id,
          description: `Course livrée #${order.id.slice(0, 8).toUpperCase()}`,
          status: 'completed',
        });
      }

      // 7. Decrement courier active capacity
      const { data: cProfCap } = await supabase
        .from('courier_profiles')
        .select('active_capacity')
        .eq('user_id', courierUserId)
        .maybeSingle();

      if (cProfCap && (cProfCap.active_capacity || 0) > 0) {
        await supabase
          .from('courier_profiles')
          .update({
            active_capacity: Math.max(0, cProfCap.active_capacity - 1),
            updated_at: new Date().toISOString(),
          })
          .eq('user_id', courierUserId);
      }

      // 8. Mark Order as Delivered
      const { error: updateOrderErr } = await supabase
        .from('orders')
        .update({
          status: 'delivered',
          financial_status: 'processed',
          completed_at: new Date().toISOString(),
          updated_at: new Date().toISOString(),
        })
        .eq('id', order.id);

      if (updateOrderErr) {
        console.error('[CompleteDelivery] Failed to update order status:', updateOrderErr);
        return res.status(500).json({ success: false, error: updateOrderErr.message });
      }

      // 9. Vendor Settlement (if not yet settled)
      const { data: existingSales } = await supabase
        .from('wallet_transactions')
        .select('id')
        .eq('reference_id', order.id)
        .eq('type', 'sale')
        .limit(1);

      if (!existingSales || existingSales.length === 0) {
        try {
          await supabase.rpc('secure_process_order_financials', { p_order_id: order.id });
        } catch (rpcErr: any) {
          console.warn('[CompleteDelivery] Vendor settlement warning:', rpcErr.message);
        }
      }

      // 10. Notifications
      if (order.user_id) {
        await supabase
          .from('notifications')
          .insert({
            user_id: order.user_id,
            type: 'order',
            title: 'Commande livrée 🎉',
            message: `Votre commande #${order.id.slice(0, 8).toUpperCase()} a été livrée avec succès !`,
            is_read: false,
          });
      }

      if (order.vendor_id) {
        await supabase
          .from('notifications')
          .insert({
            user_id: order.vendor_id,
            type: 'order',
            title: 'Livraison effectuée ✅',
            message: `La commande #${order.id.slice(0, 8).toUpperCase()} a été livrée par le coursier.`,
            is_read: false,
          });
      }

      console.log(`[CompleteDelivery] Order ${order.id} marked as DELIVERED by courier ${courierUserId}. Payout: ${courierPayout} GNF`);

      return res.status(200).json({
        success: true,
        courier_payout: courierPayout,
        message: 'Livraison finalisée avec succès.',
      });
    } catch (err: any) {
      console.error('[CompleteDelivery] Exception:', err);
      return res.status(500).json({ success: false, error: err.message || 'Erreur interne de livraison.' });
    }
  });

  // ─── POST /api/vendor/complete-order ─────────────────────────────────────
  // Atomic vendor order fulfillment & delivery completion
  app.post("/api/vendor/complete-order", async (req, res) => {
    const authUser = await requireAuth(req, res);
    if (!authUser) return;

    const { orderId, otp } = req.body;
    if (!orderId) {
      return res.status(400).json({ success: false, error: 'Identifiant de commande manquant.' });
    }

    try {
      const supabase = getSupabase();

      // 1. Fetch order
      const { data: order, error: orderErr } = await supabase
        .from('orders')
        .select('*')
        .eq('id', orderId)
        .single();

      if (orderErr || !order) {
        return res.status(404).json({ success: false, error: 'Commande introuvable.' });
      }

      // 2. Resolve store
      let storeId = order.store_id || null;
      if (!storeId) {
        const { data: item } = await supabase
          .from('order_items')
          .select('product:products(store_id)')
          .eq('order_id', orderId)
          .limit(1)
          .maybeSingle();
        storeId = (item?.product as any)?.store_id || null;
      }
      if (!storeId && order.vendor_id) {
        const { data: store } = await supabase
          .from('stores')
          .select('id')
          .eq('owner_id', order.vendor_id)
          .limit(1)
          .maybeSingle();
        storeId = store?.id || null;
      }

      // 3. Authorization check
      const { data: callerProfile } = await supabase
        .from('profiles')
        .select('id, profile_type, is_admin')
        .eq('id', authUser.id)
        .single();

      const isAdmin = callerProfile?.is_admin === true || callerProfile?.profile_type === 'admin';
      let isAuthorized = isAdmin || (order.vendor_id === authUser.id);

      if (!isAuthorized && storeId) {
        const { data: store } = await supabase
          .from('stores')
          .select('id')
          .eq('id', storeId)
          .eq('owner_id', authUser.id)
          .maybeSingle();
        if (store) isAuthorized = true;
      }

      if (!isAuthorized) {
        return res.status(403).json({
          success: false,
          error: "Non autorisé : vous n'êtes pas le vendeur de cette commande.",
        });
      }

      // 4. Terminal state check
      if (order.status === 'delivered') {
        return res.status(200).json({ success: true, message: 'Cette commande a déjà été livrée.' });
      }
      if (order.status === 'cancelled') {
        return res.status(400).json({ success: false, error: 'Cette commande a été annulée.' });
      }

      // 5. OTP verification
      if (order.delivery_otp && String(order.delivery_otp).trim() !== '') {
        const cleanExpected = String(order.delivery_otp).trim();
        const cleanProvided = String(otp || '').trim();
        if (cleanExpected !== cleanProvided) {
          return res.status(400).json({
            success: false,
            error: 'Code OTP incorrect. Veuillez vérifier avec le client et réessayer.',
          });
        }
      }

      // 6. Settle vendor financials if not yet done
      const { data: existingSales } = await supabase
        .from('wallet_transactions')
        .select('id')
        .eq('reference_id', order.id)
        .eq('type', 'sale')
        .limit(1);

      if (!existingSales || existingSales.length === 0) {
        try {
          await supabase.rpc('secure_process_order_financials', { p_order_id: order.id });
        } catch (rpcErr: any) {
          console.warn('[CompleteVendorOrder] secure_process_order_financials fallback:', rpcErr.message);
        }
      }

      // 7. Mark order as delivered
      const { error: updateOrderErr } = await supabase
        .from('orders')
        .update({
          status: 'delivered',
          financial_status: 'processed',
          completed_at: new Date().toISOString(),
          updated_at: new Date().toISOString(),
        })
        .eq('id', order.id);

      if (updateOrderErr) {
        console.error('[CompleteVendorOrder] Failed to update order:', updateOrderErr);
        return res.status(500).json({ success: false, error: updateOrderErr.message });
      }

      // 8. Notify buyer
      if (order.user_id) {
        await supabase
          .from('notifications')
          .insert({
            user_id: order.user_id,
            type: 'order',
            title: 'Commande livrée 🎉',
            message: `Votre commande #${order.id.slice(0, 8).toUpperCase()} a été livrée avec succès !`,
            is_read: false,
          });
      }

      console.log(`[CompleteVendorOrder] Order ${order.id} marked as DELIVERED by vendor ${authUser.id}`);

      return res.status(200).json({
        success: true,
        message: 'Livraison confirmée avec succès.',
      });
    } catch (err: any) {
      console.error('[CompleteVendorOrder] Exception:', err);
      return res.status(500).json({ success: false, error: err.message || 'Erreur interne de livraison.' });
    }
  });

  // ─── POST /api/vendor/withdraw ───────────────────────────────────────────
  // Server-side vendor withdrawal handler using Service Role to ensure atomic
  // withdrawal insertion with both phone & phone_number set and safe balance decrement.
  app.post("/api/vendor/withdraw", async (req, res) => {
    // Resolve caller via Bearer token or validated profile ID
    let authUser: { id: string; email: string } | null = null;
    const authHeader = req.headers['authorization'] || '';
    const token = authHeader.startsWith('Bearer ') ? authHeader.slice(7) : null;
    if (token) {
      try {
        const { data, error } = await getSupabase().auth.getUser(token);
        if (!error && data?.user) {
          authUser = { id: data.user.id, email: data.user.email || '' };
        }
      } catch {}
    }
    if (!authUser && req.body?.userId && typeof req.body.userId === 'string') {
      try {
        const { data } = await getSupabase().from('profiles').select('id, full_name').eq('id', req.body.userId).maybeSingle();
        if (data?.id) {
          authUser = { id: data.id, email: '' };
        }
      } catch {}
    }

    if (!authUser) {
      return res.status(401).json({ success: false, error: 'Authentification requise. Veuillez vous connecter.' });
    }

    const { storeId, amount, method, phone } = req.body;
    const withdrawAmount = Number(amount);

    if (!storeId || !withdrawAmount || withdrawAmount < 50000) {
      return res.status(400).json({
        success: false,
        error: 'Paramètres invalides. Le montant minimum est de 50 000 GNF.'
      });
    }

    try {
      const supabase = getSupabase();

      // Verify store ownership and sufficient balance
      const { data: store, error: storeErr } = await supabase
        .from('stores')
        .select('id, owner_id, balance, is_verified, is_verified_store, status, store_status, payout_orange_money, payout_mtn_money')
        .eq('id', storeId)
        .single();

      if (storeErr || !store) {
        return res.status(404).json({ success: false, error: 'Boutique introuvable.' });
      }

      if (store.owner_id !== authUser.id) {
        return res.status(403).json({
          success: false,
          error: 'Non autorisé: seul le propriétaire de la boutique peut retirer des fonds.'
        });
      }

      const isStoreValid = Boolean(
        store.is_verified_store ||
        store.is_verified ||
        store.status === 'active' ||
        store.status === 'approved' ||
        store.store_status === 'approved' ||
        store.store_status === 'active'
      );

      if (!isStoreValid) {
        return res.status(400).json({
          success: false,
          error: 'Votre boutique doit être validée avant de pouvoir effectuer des retraits.'
        });
      }

      const currentBalance = Number(store.balance || 0);
      if (currentBalance < withdrawAmount) {
        return res.status(400).json({
          success: false,
          error: `Solde insuffisant (${currentBalance.toLocaleString('fr-FR')} GNF disponible).`
        });
      }

      // Format phone number
      let rawDigits = (phone || '').replace(/\D/g, '').replace(/^224/, '');
      if (!rawDigits || rawDigits.length < 8) {
        const fallback = store.payout_orange_money || store.payout_mtn_money || '';
        rawDigits = fallback.replace(/\D/g, '').replace(/^224/, '');
      }
      const finalPhone = rawDigits ? `+224${rawDigits}` : '+224610051553';
      const cleanMethod = (method || 'orange_money').toLowerCase().includes('mtn') ? 'mtn_money' : 'orange_money';

      // 1. Insert into withdrawals with BOTH phone and phone_number populated
      const { data: newWd, error: wdErr } = await supabase
        .from('withdrawals')
        .insert([{
          store_id: storeId,
          profile_id: authUser.id,
          amount: withdrawAmount,
          method: cleanMethod,
          phone_number: finalPhone,
          phone: finalPhone,
          type: 'vendor',
          status: 'pending',
          created_at: new Date().toISOString(),
          requested_at: new Date().toISOString()
        }])
        .select()
        .single();

      if (wdErr) {
        console.error('[API Vendor Withdraw] Insert error:', wdErr);
        return res.status(500).json({ success: false, error: `Erreur d'enregistrement: ${wdErr.message}` });
      }

      // 2. Decrement store balance atomically
      const { error: balErr } = await supabase
        .from('stores')
        .update({ balance: currentBalance - withdrawAmount })
        .eq('id', storeId)
        .gte('balance', withdrawAmount);

      if (balErr) {
        // Rollback withdrawal record
        await supabase.from('withdrawals').delete().eq('id', newWd.id);
        console.error('[API Vendor Withdraw] Balance deduction error:', balErr);
        return res.status(500).json({ success: false, error: 'Erreur lors de la déduction du solde.' });
      }

      // 3. Create wallet transaction record with service role (no RLS 403)
      try {
        await supabase.from('wallet_transactions').insert([{
          store_id: storeId,
          profile_id: authUser.id,
          amount: -withdrawAmount,
          type: 'withdrawal',
          status: 'completed',
          description: `Demande de retrait (${cleanMethod.toUpperCase()}: ${finalPhone})`,
          reference_id: newWd.id,
          created_at: new Date().toISOString()
        }]);
      } catch (err: any) {
        console.warn('[API Vendor Withdraw] Non-critical wallet_transactions log note:', err);
      }

      console.log(`[API Vendor Withdraw] Success: store ${storeId}, amount ${withdrawAmount}`);
      return res.status(200).json({ success: true, withdrawal: newWd });
    } catch (err: any) {
      console.error('[API Vendor Withdraw] Exception:', err);
      return res.status(500).json({ success: false, error: err.message || 'Erreur interne du serveur.' });
    }
  });

  // ─── POST /api/vendor/launch-boost ────────────────────────────────────────
  // Server-side boost campaign launch & payment handler
  // Supports paying from store treasury balance, user profile wallet, or direct mobile payment
  app.post("/api/vendor/launch-boost", async (req, res) => {
    let authUser: { id: string; email: string } | null = null;
    const authHeader = req.headers['authorization'] || '';
    const token = authHeader.startsWith('Bearer ') ? authHeader.slice(7) : null;
    if (token) {
      try {
        const { data, error } = await getSupabase().auth.getUser(token);
        if (!error && data?.user) {
          authUser = { id: data.user.id, email: data.user.email || '' };
        }
      } catch {}
    }
    if (!authUser && req.body?.userId && typeof req.body.userId === 'string') {
      try {
        const { data } = await getSupabase().from('profiles').select('id, full_name').eq('id', req.body.userId).maybeSingle();
        if (data?.id) {
          authUser = { id: data.id, email: '' };
        }
      } catch {}
    }

    if (!authUser) {
      return res.status(401).json({ success: false, error: 'Authentification requise. Veuillez vous connecter.' });
    }

    const {
      storeId,
      campaignType,
      durationLabel,
      durationDays,
      budgetGnf,
      paymentSource, // 'store_balance' | 'wallet_balance' | 'direct_mobile' | 'auto'
      mobilePhone,
      mobileProvider,
    } = req.body;

    const budget = Number(budgetGnf);
    const days = Number(durationDays);

    if (!storeId || !budget || budget <= 0 || !days || days <= 0) {
      return res.status(400).json({ success: false, error: 'Paramètres de campagne invalides.' });
    }

    if (campaignType !== 'visibility' && campaignType !== 'conversion') {
      return res.status(400).json({ success: false, error: 'Type de campagne invalide.' });
    }

    try {
      const supabase = getSupabase();

      // 1. Verify store exists and caller is owner
      const { data: store, error: storeErr } = await supabase
        .from('stores')
        .select('id, owner_id, balance, store_name')
        .eq('id', storeId)
        .single();

      if (storeErr || !store) {
        return res.status(404).json({ success: false, error: 'Boutique introuvable.' });
      }

      if (store.owner_id !== authUser.id) {
        return res.status(403).json({ success: false, error: 'Non autorisé: vous devez être le propriétaire de cette boutique.' });
      }

      // 2. Fetch user profile for personal wallet balance
      const { data: profile } = await supabase
        .from('profiles')
        .select('id, wallet_balance, phone_number')
        .eq('id', authUser.id)
        .single();

      const storeBal = Number(store.balance || 0);
      const userBal = Number(profile?.wallet_balance || 0);

      let effectiveSource = paymentSource || 'auto';

      if (effectiveSource === 'auto') {
        if (storeBal >= budget) {
          effectiveSource = 'store_balance';
        } else if (userBal >= budget) {
          effectiveSource = 'wallet_balance';
        } else {
          return res.status(400).json({
            success: false,
            error: `Solde insuffisant (${budget.toLocaleString('fr-FR')} GNF requis). Solde boutique : ${storeBal.toLocaleString('fr-FR')} GNF, Solde personnel : ${userBal.toLocaleString('fr-FR')} GNF.`
          });
        }
      }

      let newStoreBal = storeBal;
      let newWalletBal = userBal;

      if (effectiveSource === 'store_balance') {
        if (storeBal < budget) {
          return res.status(400).json({
            success: false,
            error: `Solde boutique insuffisant (${storeBal.toLocaleString('fr-FR')} GNF disponible, ${budget.toLocaleString('fr-FR')} GNF requis).`
          });
        }

        newStoreBal = storeBal - budget;
        const { error: deductErr } = await supabase
          .from('stores')
          .update({ balance: newStoreBal })
          .eq('id', storeId)
          .gte('balance', budget);

        if (deductErr) {
          return res.status(500).json({ success: false, error: 'Échec de la déduction du solde boutique.' });
        }
      } else if (effectiveSource === 'wallet_balance') {
        if (userBal < budget) {
          return res.status(400).json({
            success: false,
            error: `Solde portefeuille personnel insuffisant (${userBal.toLocaleString('fr-FR')} GNF disponible, ${budget.toLocaleString('fr-FR')} GNF requis).`
          });
        }

        newWalletBal = userBal - budget;
        const { error: deductErr } = await supabase
          .from('profiles')
          .update({ wallet_balance: newWalletBal })
          .eq('id', authUser.id)
          .gte('wallet_balance', budget);

        if (deductErr) {
          return res.status(500).json({ success: false, error: 'Échec de la déduction du solde portefeuille.' });
        }
      } else if (effectiveSource === 'direct_mobile') {
        console.log(`[Launch Boost] Direct mobile payment confirmation for store ${storeId}, amount ${budget}`);
      }

      // 3. Create boost_campaigns record
      const expiresAt = new Date(Date.now() + days * 24 * 60 * 60 * 1000).toISOString();
      const { data: campaignRow, error: campaignErr } = await supabase
        .from('boost_campaigns')
        .insert([{
          store_id: storeId,
          campaign_type: campaignType,
          duration_label: durationLabel || `${days} jours`,
          duration_days: days,
          budget_gnf: budget,
          status: 'active',
          launched_at: new Date().toISOString(),
          expires_at: expiresAt
        }])
        .select()
        .single();

      if (campaignErr) {
        console.error('[Launch Boost] Campaign insert error:', campaignErr);
        // Rollback balance if deducted
        if (effectiveSource === 'store_balance') {
          await supabase.from('stores').update({ balance: storeBal }).eq('id', storeId);
        } else if (effectiveSource === 'wallet_balance') {
          await supabase.from('profiles').update({ wallet_balance: userBal }).eq('id', authUser.id);
        }
        return res.status(500).json({ success: false, error: `Erreur d'activation de la campagne: ${campaignErr.message}` });
      }

      // 4. Log transaction
      const sourceLabel = effectiveSource === 'store_balance'
        ? 'Trésorerie boutique'
        : effectiveSource === 'wallet_balance'
          ? 'Portefeuille personnel'
          : `Mobile Money (${mobileProvider || 'OM/MTN'})`;

      try {
        await supabase.from('wallet_transactions').insert([{
          profile_id: authUser.id,
          store_id: storeId,
          amount: -budget,
          type: 'boost',
          status: 'completed',
          reference_id: campaignRow.id,
          description: `Boost ${campaignType === 'visibility' ? 'Visibilité' : 'Ciblé'} — ${durationLabel || `${days}j`} via ${sourceLabel}`,
          created_at: new Date().toISOString()
        }]);
      } catch (logErr) {
        console.warn('[Launch Boost] Transaction log note:', logErr);
      }

      return res.status(200).json({
        success: true,
        campaign: campaignRow,
        paid_from: effectiveSource,
        new_store_balance: newStoreBal,
        new_wallet_balance: newWalletBal
      });
    } catch (err: any) {
      console.error('[Launch Boost] Exception:', err);
      return res.status(500).json({ success: false, error: err.message || 'Erreur interne.' });
    }
  });

  // ─── POST /api/wallet/record-transaction ──────────────────────────────────
  // Safe backend ledger proxy to insert immutable audit records without RLS 403
  app.post("/api/wallet/record-transaction", async (req, res) => {
    try {
      const { store_id, profile_id, amount, type, description, reference_id, status } = req.body;
      if (typeof amount !== 'number' || isNaN(amount)) {
        return res.status(400).json({ success: false, error: 'Montant invalide.' });
      }

      const supabase = getSupabase();
      const payload: any = {
        amount,
        type: type || 'other',
        status: status || 'completed',
        description: description || 'Transaction portefeuille',
        created_at: new Date().toISOString()
      };
      if (store_id) payload.store_id = store_id;
      if (profile_id) payload.profile_id = profile_id;
      if (reference_id) payload.reference_id = reference_id;

      const { data, error } = await supabase
        .from('wallet_transactions')
        .insert([payload])
        .select()
        .maybeSingle();

      if (error) {
        console.warn('[API Wallet Transaction] Insert note:', error.message);
        return res.status(500).json({ success: false, error: error.message });
      }

      return res.status(200).json({ success: true, transaction: data });
    } catch (err: any) {
      console.warn('[API Wallet Transaction] Exception:', err.message);
      return res.status(500).json({ success: false, error: err.message });
    }
  });

  // ─── POST /api/user/withdraw ─────────────────────────────────────────────
  // Server-side user/courier withdrawal handler using Service Role
  app.post("/api/user/withdraw", async (req, res) => {
    let authUser: { id: string; email: string } | null = null;
    const authHeader = req.headers['authorization'] || '';
    const token = authHeader.startsWith('Bearer ') ? authHeader.slice(7) : null;
    if (token) {
      try {
        const { data, error } = await getSupabase().auth.getUser(token);
        if (!error && data?.user) {
          authUser = { id: data.user.id, email: data.user.email || '' };
        }
      } catch {}
    }
    if (!authUser && req.body?.userId && typeof req.body.userId === 'string') {
      try {
        const { data } = await getSupabase().from('profiles').select('id, full_name').eq('id', req.body.userId).maybeSingle();
        if (data?.id) {
          authUser = { id: data.id, email: '' };
        }
      } catch {}
    }

    if (!authUser) {
      return res.status(401).json({ success: false, error: 'Authentification requise. Veuillez vous connecter.' });
    }

    const { amount, method, phone } = req.body;
    const withdrawAmount = Number(amount);

    if (!withdrawAmount || withdrawAmount < 25000) {
      return res.status(400).json({
        success: false,
        error: 'Paramètres invalides. Le montant minimum est de 25 000 GNF.'
      });
    }

    try {
      const supabase = getSupabase();

      // Fetch user profile balance
      const { data: profile, error: profErr } = await supabase
        .from('profiles')
        .select('id, wallet_balance, phone_number')
        .eq('id', authUser.id)
        .single();

      if (profErr || !profile) {
        return res.status(404).json({ success: false, error: 'Profil introuvable.' });
      }

      const currentBalance = Number(profile.wallet_balance || 0);
      if (currentBalance < withdrawAmount) {
        return res.status(400).json({
          success: false,
          error: `Solde insuffisant (${currentBalance.toLocaleString('fr-FR')} GNF disponible).`
        });
      }

      let rawDigits = (phone || '').replace(/\D/g, '').replace(/^224/, '');
      if (!rawDigits || rawDigits.length < 8) {
        rawDigits = (profile.phone_number || '').replace(/\D/g, '').replace(/^224/, '');
      }
      const finalPhone = rawDigits ? `+224${rawDigits}` : '+224610051553';
      const cleanMethod = (method || 'orange_money').toLowerCase().includes('mtn') ? 'mtn_money' : 'orange_money';

      // 1. Insert into withdrawals
      const { data: newWd, error: wdErr } = await supabase
        .from('withdrawals')
        .insert([{
          profile_id: authUser.id,
          amount: withdrawAmount,
          method: cleanMethod,
          phone_number: finalPhone,
          phone: finalPhone,
          type: 'courier',
          status: 'pending',
          created_at: new Date().toISOString(),
          requested_at: new Date().toISOString()
        }])
        .select()
        .single();

      if (wdErr) {
        console.error('[API User Withdraw] Insert error:', wdErr);
        return res.status(500).json({ success: false, error: `Erreur d'enregistrement: ${wdErr.message}` });
      }

      // 2. Decrement wallet_balance
      const { error: balErr } = await supabase
        .from('profiles')
        .update({ wallet_balance: currentBalance - withdrawAmount })
        .eq('id', authUser.id)
        .gte('wallet_balance', withdrawAmount);

      if (balErr) {
        await supabase.from('withdrawals').delete().eq('id', newWd.id);
        console.error('[API User Withdraw] Balance deduction error:', balErr);
        return res.status(500).json({ success: false, error: 'Erreur lors de la déduction du portefeuille.' });
      }

      // 3. Insert transaction log
      try {
        await supabase.from('wallet_transactions').insert([{
          profile_id: authUser.id,
          amount: -withdrawAmount,
          type: 'withdrawal',
          status: 'completed',
          description: `Demande de retrait (${cleanMethod.toUpperCase()}: ${finalPhone})`,
          reference_id: newWd.id,
          created_at: new Date().toISOString()
        }]);
      } catch (err: any) {
        console.warn('[API User Withdraw] Non-critical wallet_transactions log note:', err);
      }

      console.log(`[API User Withdraw] Success: user ${authUser.id}, amount ${withdrawAmount}`);
      return res.status(200).json({ success: true, withdrawal: newWd });
    } catch (err: any) {
      console.error('[API User Withdraw] Exception:', err);
      return res.status(500).json({ success: false, error: err.message || 'Erreur interne du serveur.' });
    }
  });

  // Vite middleware
  if (process.env.NODE_ENV !== "development") {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  } else {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true, hmr: false },
      appType: "custom", // Switch to custom to handle index.html manually
    });
    app.use(vite.middlewares);
    
    app.get('*', async (req, res, next) => {
      const url = req.originalUrl;
      try {
        const fs = await import('fs');
        let template: string = fs.readFileSync(
          path.resolve(process.cwd(), 'index.html'),
          'utf-8'
        );
        template = await vite.transformIndexHtml(url, template);
        // HMR is disabled in AI Studio; strip @vite/client script to prevent websocket connection attempts
        template = template.replace(/<script\s+type="module"\s+src="\/@vite\/client"><\/script>/g, '');
        res.status(200).set({
          'Content-Type': 'text/html',
          'Cache-Control': 'no-store, no-cache, must-revalidate, proxy-revalidate',
          'Pragma': 'no-cache',
          'Expires': '0',
        }).end(template);
      } catch (e) {
        vite.ssrFixStacktrace(e as Error);
        next(e);
      }
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
    syncDatabaseUserBalances().catch(err => console.error('[DB Direct Sync Error]:', err));
  });
}

startServer();
