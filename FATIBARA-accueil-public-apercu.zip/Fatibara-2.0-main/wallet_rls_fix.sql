-- ==============================================================================
-- WALLET TRANSACTIONS RLS FIX
-- Fatibara 2.0 — Security Audit: 2026-08
-- ==============================================================================
-- Fixes: Suite 5 RLS failures — anonymous and cross-user reads of wallet_transactions
--
-- Root cause: transaction_system_v3.sql defines:
--   USING (auth.uid() = profile_id OR profile_id IS NULL)
--
-- The `OR profile_id IS NULL` clause exposes ALL legacy rows (inserted before
-- the profile_id column was added) to EVERY user including anonymous.
-- The test suite inserts a row with profile_id set but 2 pre-existing seed rows
-- with profile_id = NULL leak through and cause expect(rowCount).toBe(0) to fail.
--
-- Fix: Replace with a strict 3-way policy:
--   1. User owns the profile_id   → direct profile transactions (courier, buyer topups)
--   2. User owns the store         → vendor store ledger entries
--   3. User is admin               → full visibility for reconciliation
-- ==============================================================================

-- ─── Drop all existing SELECT policies on wallet_transactions ─────────────────
-- Multiple migrations have created overlapping policies; drop them all.
DROP POLICY IF EXISTS "Users can view own transactions"      ON public.wallet_transactions;
DROP POLICY IF EXISTS "Vendors can view own transactions"    ON public.wallet_transactions;
DROP POLICY IF EXISTS "Admins full access to transactions"   ON public.wallet_transactions;
DROP POLICY IF EXISTS "Users can read own wallet transactions" ON public.wallet_transactions;

-- ─── Strict scoped SELECT policy (authenticated only) ────────────────────────
-- Anonymous users: no rows (no matching USING clause since TO authenticated)
-- Authenticated buyer/courier: sees only rows where profile_id = their uid
-- Authenticated vendor: sees rows for their stores (store_id matches a store they own)
-- Admin: sees everything
CREATE POLICY "Users can read own wallet transactions"
ON public.wallet_transactions
FOR SELECT
TO authenticated
USING (
  auth.uid() = profile_id
  OR
  auth.uid() IN (
    SELECT owner_id FROM public.stores
    WHERE id = wallet_transactions.store_id
  )
  OR
  EXISTS (
    SELECT 1 FROM public.profiles
    WHERE id = auth.uid() AND is_admin = true
  )
);

-- ─── Ensure RLS is enabled ────────────────────────────────────────────────────
ALTER TABLE public.wallet_transactions ENABLE ROW LEVEL SECURITY;

-- ─── Preserve admin INSERT/UPDATE/DELETE (service-role bypasses RLS) ─────────
-- The existing "Admins full access" ALL policy for non-SELECT is intentionally
-- NOT recreated: INSERT/UPDATE/DELETE on wallet_transactions should go through
-- SECURITY DEFINER RPCs only (service-role or RPC). No direct write policies needed.

COMMENT ON TABLE public.wallet_transactions IS
  'Ledger of all wallet credits/debits. RLS: authenticated users see own rows only. '
  'NULL profile_id rows (legacy) are admin-visible only. '
  'Writes go exclusively through SECURITY DEFINER RPCs.';
