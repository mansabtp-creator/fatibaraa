-- RUN THIS SCRIPT IN SUPABASE SQL EDITOR TO GRANT ADMIN TO YOUR EMAIL DIRECTLY
-- This completely bypasses the profiles table and uses the authenticated user's email

CREATE OR REPLACE FUNCTION public.is_admin()
RETURNS BOOLEAN AS $$
DECLARE
  user_email TEXT;
BEGIN
  -- Extract email from the JWT token
  user_email := auth.jwt() ->> 'email';
  
  -- Grant admin to these hardcoded emails:
  IF user_email IN ('fatibara.gn@gmail.com', 'admin@fatibara.com') THEN
    RETURN TRUE;
  END IF;

  -- Fallback to checking the profiles table for other admins
  RETURN EXISTS (
    SELECT 1 FROM public.profiles 
    WHERE id = auth.uid() 
    AND is_admin = true
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Let's also forcefully insert/update your profile to ensure it exists
INSERT INTO public.profiles (id, full_name, is_admin, is_pro_member)
SELECT id, 'FatiBara Admin', true, true
FROM auth.users 
WHERE email IN ('fatibara.gn@gmail.com', 'admin@fatibara.com')
ON CONFLICT (id) DO UPDATE SET is_admin = true, is_pro_member = true;
