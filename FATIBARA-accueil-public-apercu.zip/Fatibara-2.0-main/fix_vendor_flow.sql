-- FATIBARA 2.0 VENDOR FLOW SECURITY FIXES

-- 1. STORES: PREVENT BALANCE AND VERIFICATION SPOOFING
DROP POLICY IF EXISTS "Owners can update their stores" ON public.stores;
CREATE POLICY "Owners can update their stores" ON public.stores FOR UPDATE 
USING (owner_id = auth.uid())
WITH CHECK (
  owner_id = auth.uid() AND
  NEW.owner_id = OLD.owner_id AND
  NEW.balance = OLD.balance AND
  NEW.is_verified_store = OLD.is_verified_store AND
  NEW.status = OLD.status
);

-- 2. PRODUCTS: ONLY SHOW PRODUCTS FROM VERIFIED STORES TO PUBLIC
DROP POLICY IF EXISTS "Products are viewable by everyone" ON public.products;
CREATE POLICY "Products are viewable by everyone" 
ON public.products FOR SELECT 
USING (
  EXISTS (
    SELECT 1 FROM public.stores 
    WHERE stores.id = products.store_id 
    AND (stores.is_verified_store = true OR stores.owner_id = auth.uid())
  )
);

-- 3. ATOMIC VENDOR WITHDRAWAL RPC
CREATE OR REPLACE FUNCTION request_vendor_withdrawal(
    p_store_id UUID,
    p_amount BIGINT,
    p_method TEXT,
    p_phone TEXT
) RETURNS JSONB AS $$
DECLARE
    v_store RECORD;
    v_withdrawal_id UUID;
BEGIN
    -- Validate store and lock for update to prevent concurrent race conditions
    SELECT * INTO v_store FROM public.stores WHERE id = p_store_id FOR UPDATE;
    
    IF v_store IS NULL THEN
        RAISE EXCEPTION 'Store not found';
    END IF;
    
    IF v_store.owner_id != auth.uid() THEN
        RAISE EXCEPTION 'Unauthorized: You do not own this store';
    END IF;
    
    IF NOT v_store.is_verified_store THEN
        RAISE EXCEPTION 'Unverified stores cannot withdraw funds';
    END IF;
    
    IF v_store.balance < p_amount THEN
        RAISE EXCEPTION 'Insufficient balance';
    END IF;
    
    IF p_amount < 2000 THEN
        RAISE EXCEPTION 'Minimum withdrawal amount is 2000 GNF';
    END IF;
    
    -- 1. Create withdrawal record
    INSERT INTO public.withdrawals (store_id, amount, method, phone_number, status)
    VALUES (p_store_id, p_amount, p_method, p_phone, 'pending')
    RETURNING id INTO v_withdrawal_id;
    
    -- 2. Deduct balance atomically
    UPDATE public.stores
    SET balance = balance - p_amount
    WHERE id = p_store_id;
    
    -- 3. Log transaction
    INSERT INTO public.wallet_transactions (store_id, amount, type, reference_id, description, status)
    VALUES (
        p_store_id, 
        -p_amount, 
        'withdrawal', 
        v_withdrawal_id, 
        'Retrait vers ' || p_method || ' (' || p_phone || ')', 
        'completed'
    );
    
    RETURN jsonb_build_object('success', true, 'withdrawal_id', v_withdrawal_id);
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;
