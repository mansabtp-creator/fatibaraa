-- Patch to resolve RLS recursion issues
-- 1. Create a SECURITY DEFINER helper to check store ownership
CREATE OR REPLACE FUNCTION public.is_store_owner(s_id uuid)
RETURNS BOOLEAN AS $$
BEGIN
    RETURN EXISTS (SELECT 1 FROM public.stores WHERE id = s_id AND owner_id = auth.uid());
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- 2. Update Conversations Policy
DROP POLICY IF EXISTS "Users can see their own conversations." ON public.conversations;
CREATE POLICY "Users can see their own conversations." ON public.conversations FOR SELECT 
USING (auth.uid() = user_id OR public.is_store_owner(store_id));

-- 3. Update Messages Policy
DROP POLICY IF EXISTS "Users can see messages in their conversations." ON public.messages;
CREATE POLICY "Users can see messages in their conversations." ON public.messages FOR SELECT 
USING (EXISTS (
    SELECT 1 FROM public.conversations 
    WHERE conversations.id = messages.conversation_id 
    AND (conversations.user_id = auth.uid() OR public.is_store_owner(conversations.store_id))
));
