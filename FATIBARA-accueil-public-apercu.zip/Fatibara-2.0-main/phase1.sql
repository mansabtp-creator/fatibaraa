-- 1. Fix infinite recursion in profiles by dropping and recreating the admin policies on profiles
DROP POLICY IF EXISTS "Admins can update all profiles" ON public.profiles;
DROP POLICY IF EXISTS "Admins can delete profiles" ON public.profiles;
DROP POLICY IF EXISTS "Admins can see all profiles" ON public.profiles;

CREATE POLICY "Admins can update all profiles"
ON public.profiles FOR UPDATE
USING (
  public.is_admin()
);

CREATE POLICY "Admins can delete profiles"
ON public.profiles FOR DELETE
USING (
  public.is_admin()
);

CREATE POLICY "Admins can see all profiles"
ON public.profiles FOR SELECT
USING (
  public.is_admin() OR true
);

-- 2. Add phone column to stores
ALTER TABLE public.stores ADD COLUMN IF NOT EXISTS phone TEXT;
-- Migrate existing contact_phone data just in case
UPDATE public.stores SET phone = contact_phone WHERE phone IS NULL;

-- 3. Create missing tables if they don't exist
CREATE TABLE IF NOT EXISTS public.chat_channels (
  id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  store_id uuid REFERENCES public.stores(id) ON DELETE CASCADE,
  buyer_id uuid REFERENCES public.profiles(id) ON DELETE CASCADE,
  last_message text,
  last_message_at timestamp with time zone DEFAULT now(),
  created_at timestamp with time zone DEFAULT now(),
  product_id uuid REFERENCES public.products(id) ON DELETE SET NULL,
  UNIQUE(store_id, buyer_id)
);

-- Try to update relationships if the table already existed
ALTER TABLE public.chat_channels DROP CONSTRAINT IF EXISTS chat_channels_buyer_id_fkey;

DO $$ 
BEGIN
  ALTER TABLE public.chat_channels ADD COLUMN IF NOT EXISTS buyer_id uuid;
  ALTER TABLE public.chat_channels ADD COLUMN IF NOT EXISTS product_id uuid;
EXCEPTION 
  WHEN duplicate_column THEN NULL;
END $$;

DO $$ 
BEGIN
  ALTER TABLE public.chat_channels 
  ADD CONSTRAINT chat_channels_buyer_id_fkey_profiles 
  FOREIGN KEY (buyer_id) REFERENCES public.profiles(id) ON DELETE CASCADE;
EXCEPTION 
  WHEN duplicate_object THEN NULL;
END $$;

CREATE TABLE IF NOT EXISTS public.flash_deals (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    product_id UUID REFERENCES public.products(id) ON DELETE CASCADE NOT NULL,
    store_id UUID REFERENCES public.stores(id) ON DELETE CASCADE NOT NULL,
    discount_price DECIMAL(12,2) NOT NULL,
    start_time TIMESTAMPTZ NOT NULL,
    end_time TIMESTAMPTZ NOT NULL,
    created_at TIMESTAMPTZ DEFAULT now()
);

-- Ensure flash_deals product_id has foreign key if table already existed
ALTER TABLE public.flash_deals DROP CONSTRAINT IF EXISTS flash_deals_product_id_fkey;

DO $$ 
BEGIN
  ALTER TABLE public.flash_deals 
  ADD CONSTRAINT flash_deals_product_id_fkey 
  FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;
EXCEPTION 
  WHEN duplicate_object THEN NULL;
END $$;

-- Also let's ensure the DB schema cache is notified of the changes
NOTIFY pgrst, 'reload schema';
