/**
 * setup-sweep.ts
 * ─────────────────────────────────────────────────────────────────────────────
 * One-time setup script for the End-to-End Integration Sweep.
 * Creates persistent test accounts that BYPASS Playwright's globalTeardown
 * (because they are NOT created via createTestAccount, so they aren't in
 * the _createdAccountIds tracking list).
 *
 * Creates:
 *   • sweep_buyer   — funded buyer (wallet: 200,000 GNF)
 *   • sweep_vendor  — vendor with store + test product
 *   • sweep_courier — courier with plate / phone / vehicle_type
 *   • sweep_admin   — admin-role user (re-uses existing prod admin or creates one)
 *
 * Writes: sweep-state.json at project root
 *
 * Usage:
 *   npx tsx setup-sweep.ts
 *   npx tsx setup-sweep.ts --cleanup   ← removes sweep accounts when done
 */

import { createClient } from '@supabase/supabase-js';
import * as fs from 'fs';
import * as dotenv from 'dotenv';
import * as path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
dotenv.config({ path: path.join(__dirname, '.env') });
// NOTE: do NOT load .env.local — it contains a local dev Supabase URL
// that overrides the production URL and breaks the service role JWT.

const SUPABASE_URL     = process.env.VITE_SUPABASE_URL!;
const SERVICE_ROLE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY!;
const STATE_FILE       = path.join(__dirname, 'sweep-state.json');

const svc = createClient(SUPABASE_URL, SERVICE_ROLE_KEY, {
  auth: { persistSession: false, autoRefreshToken: false },
});

// ── Config ─────────────────────────────────────────────────────────────────────
const TS           = Date.now();
const SWEEP_TAG    = `sweep_${TS}`;
const TEST_DOMAIN  = 'e2e.fatibara-test.internal';
const TEST_PASS    = 'E2eTest!2026$Fatibara';

const PRODUCT_PRICE = 5_000;    // GNF — cheapest so wallet requirements are low
const DELIVERY_FEE  = 10_000;   // GNF
const ORDER_TOTAL   = PRODUCT_PRICE + DELIVERY_FEE;
const BUYER_WALLET  = 200_000;  // GNF — generous buffer for all phases

// ── Helper: create user ────────────────────────────────────────────────────────
async function createUser(role: string, extraProfile: Record<string, unknown> = {}): Promise<{
  id: string; email: string; password: string;
}> {
  const email = `${SWEEP_TAG}_${role}@${TEST_DOMAIN}`;
  const { data, error } = await svc.auth.admin.createUser({
    email,
    password: TEST_PASS,
    email_confirm: true,
    user_metadata: { full_name: `Sweep ${role} ${TS}` },
  });
  if (error || !data?.user) throw new Error(`createUser(${role}) failed: ${error?.message}`);
  const id = data.user.id;

  // Upsert profile
  await svc.from('profiles').upsert({
    id,
    full_name: `Sweep ${role} ${TS}`,
    wallet_balance: role === 'buyer' ? BUYER_WALLET : 0,
    ...extraProfile,
  }, { onConflict: 'id', ignoreDuplicates: false });

  console.log(`  ✅ ${role.padEnd(8)} | ${id.slice(0, 8)} | ${email}`);
  return { id, email, password: TEST_PASS };
}

// ── Main setup ─────────────────────────────────────────────────────────────────
async function main() {
  const isCleanup = process.argv.includes('--cleanup');

  if (isCleanup) {
    await cleanup();
    return;
  }

  console.log(`\n🚀 Fatibara E2E Integration Sweep — Account Setup`);
  console.log(`   Tag: ${SWEEP_TAG}\n`);

  // ── 1. Buyer ────────────────────────────────────────────────────────────────
  const buyer = await createUser('buyer', {
    profile_type: 'client',
    wallet_balance: BUYER_WALLET,
  });

  // ── 2. Vendor ───────────────────────────────────────────────────────────────
  const vendor = await createUser('vendor', { profile_type: 'vendor' });

  // Create vendor store
  const { data: storeData, error: storeErr } = await svc.from('stores').insert({
    owner_id:         vendor.id,
    store_name:       `Sweep Store ${TS}`,
    balance:          100_000, // pre-fund to avoid constraint violations
    is_verified_store: false,
    store_status:     'active',
  }).select('id').single();
  if (storeErr) throw new Error(`Store creation failed: ${storeErr.message}`);
  const storeId = storeData.id;
  console.log(`  ✅ store    | ${storeId.slice(0, 8)} | Sweep Store ${TS}`);

  // Create product in that store
  const { data: productData, error: prodErr } = await svc.from('products').insert({
    store_id:          storeId,
    title:             `Sweep Test Product ${TS}`,
    price_gnf:         PRODUCT_PRICE,
    stock_quantity:    100,
    is_active:         true,
    moderation_status: 'approved',
  }).select('id').single();
  if (prodErr) throw new Error(`Product creation failed: ${prodErr.message}`);
  const productId = productData.id;
  console.log(`  ✅ product  | ${productId.slice(0, 8)} | price=${PRODUCT_PRICE} GNF`);

  // ── 3. Courier ──────────────────────────────────────────────────────────────
  const plate = `SWP-${TS.toString().slice(-5)}-MC`;
  const phone = `62${Math.floor(Math.random() * 9_000_000 + 1_000_000)}`;

  const courier = await createUser('courier', {
    profile_type:         'courier',
    phone_number:         phone,
    license_plate_number: plate,
    vehicle_type:         'moto',
    is_courier_online:    false,
    wallet_balance:       0,
  });

  // ── 4. Write state file ─────────────────────────────────────────────────────
  const state = {
    tag:       SWEEP_TAG,
    createdAt: new Date().toISOString(),
    ids: {
      buyerId:   buyer.id,
      vendorId:  vendor.id,
      courierId: courier.id,
      storeId,
      productId,
    },
    credentials: {
      buyer:   { email: buyer.email,   password: TEST_PASS },
      vendor:  { email: vendor.email,  password: TEST_PASS },
      courier: { email: courier.email, password: TEST_PASS },
    },
    order: {
      // Populated during Phase 1
      id:          null as string | null,
      status:      null as string | null,
      deliveryOtp: null as string | null,
      total:       ORDER_TOTAL,
      deliveryFee: DELIVERY_FEE,
      productPrice: PRODUCT_PRICE,
    },
    phases: {
      phase1: { complete: false, timestamp: null as string | null },
      phase2: { complete: false, timestamp: null as string | null },
      phase3: { complete: false, timestamp: null as string | null },
      phase4: { complete: false, timestamp: null as string | null },
    },
  };

  fs.writeFileSync(STATE_FILE, JSON.stringify(state, null, 2));
  console.log(`\n  📄 State written to: sweep-state.json`);
  console.log(`\n  🔑 Credentials:`);
  console.log(`     buyer   : ${buyer.email}`);
  console.log(`     vendor  : ${vendor.email}`);
  console.log(`     courier : ${courier.email}`);
  console.log(`     password: ${TEST_PASS} (all roles)`);
  console.log(`\n  ✅ Setup complete — run Phase 1 spec next.\n`);
}

// ── Cleanup ────────────────────────────────────────────────────────────────────
async function cleanup() {
  if (!fs.existsSync(STATE_FILE)) {
    console.log('No sweep-state.json found — nothing to clean up.');
    return;
  }
  const state = JSON.parse(fs.readFileSync(STATE_FILE, 'utf-8'));
  const { buyerId, vendorId, courierId } = state.ids;

  console.log(`\n🗑️  Cleaning up sweep accounts (tag: ${state.tag})...`);
  for (const id of [buyerId, vendorId, courierId]) {
    const { error } = await svc.auth.admin.deleteUser(id);
    if (error) console.warn(`  ⚠️  Failed to delete ${id.slice(0, 8)}: ${error.message}`);
    else console.log(`  ✅ Deleted ${id.slice(0, 8)}`);
  }

  fs.unlinkSync(STATE_FILE);
  console.log(`  📄 sweep-state.json removed\n`);
}

main().catch(err => { console.error('❌', err); process.exit(1); });
