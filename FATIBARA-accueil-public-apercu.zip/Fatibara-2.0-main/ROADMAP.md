# Fatibara 2.0 — Project Roadmap

> **Last updated:** 2026-09-12  
> **Build status:** `tsc --noEmit` → ✅ Exit 0  
> **DB migrations:** 91 applied  
> **Tech stack:** React + Vite + Supabase + TailwindCSS + PWA

---

## Legend

| Symbol | Meaning |
|--------|---------|
| ✅ | Done and verified |
| 🔄 | In progress |
| ⬜ | Not started |
| 🔴 | Blocker — must be done before production |
| 🟡 | Important — should be done before public launch |
| 🟢 | Nice-to-have — can ship without it |

---

## Phase 0 — Vendor Flow (COMPLETE) ✅

The entire vendor dashboard has been deep-audited across 2 full cycles. All critical bugs are fixed.

### Completed Fixes
- ✅ V1 — Double toast in `VendorOrders.tsx`
- ✅ V2 — GNF buying price `parseFloat` locale bug in `Products.tsx`
- ✅ V3 — Silent `is_open` toggle failure in `Dashboard.tsx`
- ✅ V4 — Realtime Channel B (legacy `store_id` orders) never subscribed → hoisted `fetchOrders` to `useCallback` + split into dedicated `useEffect([vendorStoreId])`
- ✅ V5 — `location_region` not saved in `Settings.tsx`
- ✅ V6 — RLS migration `extend_orders_rls_vendor_store_id.sql` deployed
- ✅ V7 — Raw Supabase error exposed in `Settings.tsx`
- ✅ V8 — Buying price unformatted on edit-open in `Products.tsx`
- ✅ V9 — `useVendorData` metrics excluded legacy store_id orders
- ✅ V10 — Dead withdrawal button link (`/vendor/wallet?tab=withdraw` → `/vendor/wallet`)
- ✅ V11 — Boost modal queried `profiles.wallet_balance` instead of `stores.balance`
- ✅ V12 — Bulk status update bypassed terminal-state guard
- ✅ V13 — `processing` + `out_for_delivery` missing from `ALLOWED_TRANSITIONS`
- ✅ V14 — CSV export used `o.items_count` (undefined) instead of `o.order_items?.length`

---

## Phase 1 — Courier Flow Audit 🔴

**Priority: BLOCKER.** The courier dashboard touches the same order state machine and financial RPCs as the vendor flow. Any bug here directly impacts delivery settlement and vendor payouts.

**File:** `src/pages/CourierDashboardPage.tsx` (1,889 lines)

### Checklist
- ⬜ **C1** — Audit realtime subscription strategy: does the courier subscribe to orders by `courier_id` AND by `store_id`? Are both channels cleaned up on unmount?
- ⬜ **C2** — Audit `complete_vendor_order` / `complete_courier_order` RPC calls: are they called on `delivered` status, or does the courier set status directly via `.update()`?
- ⬜ **C3** — Audit `cancel_vendor_order` RPC delegation: is the courier able to cancel orders, and if so, does it go through the atomic RPC (not a raw `.update()`)?
- ⬜ **C4** — Verify status machine guard: does the courier have an `ALLOWED_TRANSITIONS` equivalent, or can it jump states arbitrarily?
- ⬜ **C5** — Audit multi-order batch pickup: does `20260813000001_multi_order_courier_batch.sql` migration align with the UI batch workflow?
- ⬜ **C6** — Check OTP delivery verification: is OTP validated server-side via RPC or client-side only?
- ⬜ **C7** — Audit `is_courier_online` toggle: does it persist correctly to `profiles` table? Is there a realtime listener for new order assignments?
- ⬜ **C8** — Check COD cash collection flow: when the courier marks COD order as delivered, does the financial trigger fire correctly?
- ⬜ **C9** — Audit courier earnings ledger: does the courier's wallet update reflect correctly after delivery settlement?
- ⬜ **C10** — Check self-delivery exclusion: when vendor uses `vendor_self_delivery`, does the courier dashboard correctly hide that order?
- ⬜ **C11** — Verify all RPC errors are surfaced to the user with toasts, not swallowed silently
- ⬜ **C12** — Run `tsc --noEmit` clean after all fixes

---

## Phase 2 — Customer Flow Re-Audit 🔴

**Priority: BLOCKER.** The customer flow was audited in a prior session but has not been re-verified against the recent DB migrations (91 total, many touching checkout financials).

### Files to audit
- `src/pages/CheckoutPage.tsx` (1,332 lines)
- `src/pages/CartCheckoutPage.tsx` (970 lines)
- `src/pages/PaymentResultPage.tsx`
- `src/pages/DashboardPage.tsx` (794 lines)
- `src/components/TransactionalWallet.tsx` (884 lines)
- `src/components/LiveOrderTracking.tsx` (595 lines)

### Checklist
- ⬜ **K1** — Audit `process_cart_checkout` RPC call: does it handle stock deduction, wallet debit, and order creation atomically?
- ⬜ **K2** — Verify payment success/failure routing: does `PaymentResultPage` correctly distinguish Elite Pay vs. COD vs. wallet payment outcomes?
- ⬜ **K3** — Audit `TransactionalWallet`: does it reflect the correct balance from `profiles.wallet_balance` (not `stores.balance`)?
- ⬜ **K4** — Check abandoned cart handling: does `AbandonedCarts.tsx` correctly re-hydrate cart state on session resume?
- ⬜ **K5** — Verify `LiveOrderTracking.tsx` realtime subscription: does it track `in_transit` → `out_for_delivery` → `delivered` changes?
- ⬜ **K6** — Audit OTP display: is the delivery OTP shown to the customer at the right time (only when `in_transit`)?
- ⬜ **K7** — Check `cancel_unpaid_mobile_orders` RPC effect: are timed-out orders correctly removed from the customer order list?
- ⬜ **K8** — Verify loyalty points: does `add_loyalty_points_rpc` fire after `delivered`? Is the customer's balance shown in `DashboardPage`?
- ⬜ **K9** — Audit product review gating: can a customer only review after a confirmed `delivered` order containing that product?
- ⬜ **K10** — Check coupon/promo application: are discount amounts correctly deducted before the financial RPC is called?
- ⬜ **K11** — Verify cart merge on login: if a guest adds items then logs in, are the carts merged?
- ⬜ **K12** — Run `tsc --noEmit` clean after all fixes

---

## Phase 3 — Admin Dashboard Audit 🟡

**Priority: HIGH.** The admin dashboard is the operational control plane. Bugs here risk data corruption.

**File:** `src/pages/AdminDashboardPage.tsx` (4,351 lines, 37+ DB calls)

### Checklist
- ⬜ **A1** — Audit vendor approval flow: does approving a vendor correctly set `profile_type = 'vendor'` AND create a `stores` row atomically?
- ⬜ **A2** — Audit manual refund RPC: is the admin's refund action atomic (wallet credit + order status update)?
- ⬜ **A3** — Audit order override: can admin force-transition any order status? Is there a guard?
- ⬜ **A4** — Audit `credit_user_wallet_rpc`: is the admin credit logged in `wallet_transactions`? Are amounts validated server-side?
- ⬜ **A5** — Verify `AuditLogView`: does every financial admin action create an audit log entry?
- ⬜ **A6** — Check announcement creation: does `AnnouncementBanner` read from `announcements` table? Can the admin set expiry?
- ⬜ **A7** — Audit product moderation: can admin deactivate a product? Does it immediately hide from the storefront via RLS?
- ⬜ **A8** — Audit content reports queue: are reported products/stores correctly surfaced and resolved?
- ⬜ **A9** — Verify withdrawal approval: when admin approves a withdrawal, does `stores.balance` decrement atomically?
- ⬜ **A10** — Check analytics data freshness: are KPIs computed via DB view or RPC? Can data be stale?
- ⬜ **A11** — Run `tsc --noEmit` clean after all fixes

---

## Phase 4 — Storefront & Discovery Audit 🟡

**Priority: HIGH.** The storefront is the top of the acquisition funnel.

### Files to audit
- `src/app/page.tsx` (home page)
- `src/pages/ProductPage.tsx` (36KB)
- `src/pages/SearchPage.tsx` (16KB)
- `src/pages/ShopPage.tsx` (25KB)
- `src/pages/StoreProfilePage.tsx` (21KB)
- `src/components/ProductGrid.tsx` (27KB)
- `src/components/Header.tsx` (50KB)

### Checklist
- ⬜ **S1** — Audit `ProductPage` stock display: is `stock_quantity` real-time? Does checkout block when stock = 0?
- ⬜ **S2** — Check `SearchPage` fuzzy search: is the `fuzzy_search_final` RPC being called? Verify with `EXPLAIN ANALYZE`.
- ⬜ **S3** — Audit product view tracking: does `ProductPage` call the view-increment RPC? Is it debounced?
- ⬜ **S4** — Verify `PriceHistory.tsx`: does it read from `product_price_history` table correctly?
- ⬜ **S5** — Audit `StoreProfilePage`: does it show `is_open` status? Does the Message button work for guests?
- ⬜ **S6** — Check `QuickViewModal` add-to-cart: does it handle product variants and quantity limits?
- ⬜ **S7** — Audit `FlashDeals`: are flash deal time windows enforced server-side or client-side only?
- ⬜ **S8** — Verify `Header.tsx` cart badge updates in real-time across tabs
- ⬜ **S9** — Check `RecentlyViewedBar`: is it persisted to localStorage or DB? What is the max item count?
- ⬜ **S10** — Audit `ProductCard` wishlist toggle: does `wishlist_safe_upsert_rpc` handle race conditions?

---

## Phase 5 — Performance & PWA 🟡

### Checklist
- ⬜ **P1** — Re-enable `PwaReloadPrompt` in `App.tsx` (currently commented out): test update flow and offline fallback
- ⬜ **P2** — Audit Workbox runtime caching config in `vite.config.ts`: confirm API routes are excluded and image CDN responses are cached
- ⬜ **P3** — Measure and optimize LCP on home page: identify heaviest render-blocking assets
- ⬜ **P4** — Split `AdminDashboardPage.tsx` (4,351 lines) into lazy code-split sub-routes
- ⬜ **P5** — Memoize `VendorOrders.tsx` list items with `React.memo` to reduce re-renders
- ⬜ **P6** — Audit `Header.tsx` (50KB): ensure all sub-components are lazy-loaded
- ⬜ **P7** — Wire up `@sentry/react` (already in `package.json`) to `ErrorBoundary` for production error tracking
- ⬜ **P8** — Bundle PWA icons locally instead of pointing to remote Supabase URLs (breaks offline install)

---

## Phase 6 — Testing & Quality Gates 🟢

### Checklist
- ⬜ **T1** — Write Playwright E2E test: full customer purchase flow (browse → cart → checkout → order tracking)
- ⬜ **T2** — Write Playwright E2E test: vendor order fulfillment (new order → accept → prepare → dispatch → deliver)
- ⬜ **T3** — Write Playwright E2E test: courier delivery flow (assign → pickup → OTP verify → deliver)
- ⬜ **T4** — Write Playwright E2E test: admin refund and vendor approval flows
- ⬜ **T5** — Add `tsc --noEmit` + `eslint` to CI pipeline (GitHub Actions or Vercel build hook)
- ⬜ **T6** — Add `supabase db lint` to CI pipeline

---

## Phase 7 — Pre-Launch Hardening 🟢

### Checklist
- ⬜ **L1** — Audit all `console.log` statements and gate behind `import.meta.env.DEV`
- ⬜ **L2** — Verify all Supabase environment variables are set in Vercel production config
- ⬜ **L3** — Check rate-limiting on sensitive RPCs (wallet transfers, withdrawals, OTP verification)
- ⬜ **L4** — Run `supabase db lint` and address all warnings
- ⬜ **L5** — Review all Supabase storage bucket policies: confirm vendor/admin-only buckets are not publicly writable
- ⬜ **L6** — Confirm `factory_reset_preserve_admin` migration is excluded from the production migration set
- ⬜ **L7** — Set up a production database backup schedule in Supabase
- ⬜ **L8** — Verify CORS + CSP headers are correctly configured for the production domain
- ⬜ **L9** — Add `robots.txt` and `sitemap.xml` for SEO
- ⬜ **L10** — Test PWA install flow on Android Chrome and iOS Safari with the production domain

---

## Execution Order

```
Phase 0  ✅ DONE
   ↓
Phase 1  🔴 Courier Audit        ← START HERE
   ↓
Phase 2  🔴 Customer Flow
   ↓
Phase 3  🟡 Admin Dashboard
   ↓
Phase 4  🟡 Storefront
   ↓
Phase 5  🟡 Performance + PWA
   ↓
Phase 6  🟢 Testing
   ↓
Phase 7  🟢 Pre-Launch Hardening
   ↓
🚀 PRODUCTION LAUNCH
```

---

## Definition of Done (Per Phase)

A phase is **complete** when:
1. All checklist items are marked ✅
2. `npx tsc --noEmit` returns exit code 0
3. Any new DB migration has been pushed via `npx supabase db push`
4. The walkthrough artifact is updated with a summary of changes

---

*This roadmap is a living document. Update checklist items as work is completed.*
