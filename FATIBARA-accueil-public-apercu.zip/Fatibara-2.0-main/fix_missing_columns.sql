-- Fix missing columns in products table
-- Run this in your Supabase SQL Editor to resolve upload errors

-- 1. Ensure products table has all required columns
ALTER TABLE public.products ADD COLUMN IF NOT EXISTS scheduled_at timestamp with time zone;
ALTER TABLE public.products ADD COLUMN IF NOT EXISTS status text NOT NULL DEFAULT 'published';
ALTER TABLE public.products ADD COLUMN IF NOT EXISTS low_stock_threshold integer DEFAULT 5;
ALTER TABLE public.products ADD COLUMN IF NOT EXISTS is_digital boolean DEFAULT false;
ALTER TABLE public.products ADD COLUMN IF NOT EXISTS download_url text;
ALTER TABLE public.products ADD COLUMN IF NOT EXISTS variations jsonb DEFAULT '[]'::jsonb;
ALTER TABLE public.products ADD COLUMN IF NOT EXISTS volume_discount_qty integer;
ALTER TABLE public.products ADD COLUMN IF NOT EXISTS volume_discount_percent numeric;
ALTER TABLE public.products ADD COLUMN IF NOT EXISTS buying_price_gnf numeric;
ALTER TABLE public.products ADD COLUMN IF NOT EXISTS seo_description text;
ALTER TABLE public.products ADD COLUMN IF NOT EXISTS updated_at timestamp with time zone DEFAULT now();

-- 2. Add performance indices
CREATE INDEX IF NOT EXISTS idx_products_scheduled_at ON public.products(scheduled_at);
CREATE INDEX IF NOT EXISTS idx_products_status ON public.products(status);

-- 3. Automatic updated_at trigger (Best Practice)
CREATE OR REPLACE FUNCTION public.handle_updated_at()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS set_products_updated_at ON public.products;
CREATE TRIGGER set_products_updated_at
    BEFORE UPDATE ON public.products
    FOR EACH ROW
    EXECUTE FUNCTION public.handle_updated_at();

-- 4. Ensure stores table has required columns too
ALTER TABLE public.stores ADD COLUMN IF NOT EXISTS payout_orange_money text;
ALTER TABLE public.stores ADD COLUMN IF NOT EXISTS payout_mtn_money text;
ALTER TABLE public.stores ADD COLUMN IF NOT EXISTS store_status text DEFAULT 'active';
ALTER TABLE public.stores ADD COLUMN IF NOT EXISTS global_sale_active boolean DEFAULT false;
ALTER TABLE public.stores ADD COLUMN IF NOT EXISTS global_sale_percent numeric;
ALTER TABLE public.stores ADD COLUMN IF NOT EXISTS updated_at timestamp with time zone DEFAULT now();

DROP TRIGGER IF EXISTS set_stores_updated_at ON public.stores;
CREATE TRIGGER set_stores_updated_at
    BEFORE UPDATE ON public.stores
    FOR EACH ROW
    EXECUTE FUNCTION public.handle_updated_at();

-- Reload schema cache
NOTIFY pgrst, 'reload schema';
