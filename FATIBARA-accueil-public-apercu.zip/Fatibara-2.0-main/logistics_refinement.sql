
-- LOGISTICS & DELIVERY REFINEMENT
-- 1. Add advanced tracking fields
ALTER TABLE public.orders
ADD COLUMN IF NOT EXISTS tracking_number TEXT,
ADD COLUMN IF NOT EXISTS courier_id UUID REFERENCES auth.users(id),
ADD COLUMN IF NOT EXISTS delivery_otp TEXT,
ADD COLUMN IF NOT EXISTS delivery_attempts INTEGER DEFAULT 0,
ADD COLUMN IF NOT EXISTS last_location_lat DOUBLE PRECISION,
ADD COLUMN IF NOT EXISTS last_location_lng DOUBLE PRECISION,
ADD COLUMN IF NOT EXISTS estimated_arrival TIMESTAMP WITH TIME ZONE,
ADD COLUMN IF NOT EXISTS delivery_proof_url TEXT;

-- 2. Add courier status to profiles (if they are a courier)
ALTER TABLE public.profiles
ADD COLUMN IF NOT EXISTS courier_status TEXT DEFAULT 'inactive' CHECK (courier_status IN ('active', 'inactive', 'on_delivery'));
