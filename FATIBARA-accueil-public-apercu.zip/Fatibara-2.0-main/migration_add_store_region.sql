ALTER TABLE public.stores ADD COLUMN IF NOT EXISTS location_region TEXT DEFAULT 'Conakry';
UPDATE public.stores SET location_region = 'Conakry' WHERE location_region IS NULL;
