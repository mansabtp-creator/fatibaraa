-- Add buying_price_gnf to products
ALTER TABLE public.products ADD COLUMN IF NOT EXISTS buying_price_gnf NUMERIC;

-- Add main_image to products, though it's better to just use image_urls. But since some code might expect it, wait, we can just edit the code!
-- The frontend is querying it. Better to fix the frontend logic.

-- Let's check relation between chat_channels and product_id
ALTER TABLE public.chat_channels ADD COLUMN IF NOT EXISTS product_id UUID REFERENCES public.products(id) ON DELETE SET NULL;

NOTIFY pgrst, 'reload schema';
