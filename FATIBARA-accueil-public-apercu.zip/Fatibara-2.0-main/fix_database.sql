-- FIX ORDERS TABLE (Missing Columns)
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS customer_name text;
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS items_count integer;
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS financial_status text DEFAULT 'pending';
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS tracking_number text;
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS delivery_otp text;
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS vendor_id uuid REFERENCES auth.users(id);

-- 2. FIX STORES TABLE
ALTER TABLE public.stores ADD COLUMN IF NOT EXISTS payout_orange_money text;
ALTER TABLE public.stores ADD COLUMN IF NOT EXISTS payout_mtn_money text;

-- 3. ENSURE ORDERS RLS ALLOWS INSERT (Consult Supabase Dashboard to confirm)
-- This policy allows authenticated users to insert their own orders.
-- YOU SHOULD VERIFY THIS POLICY IN YOUR SUPABASE DASHBOARD -> Authentication -> Policies -> orders
DROP POLICY IF EXISTS "Users can insert their own orders" ON public.orders;
CREATE POLICY "Users can insert their own orders" ON public.orders
    FOR INSERT
    TO authenticated
    WITH CHECK (auth.uid() = user_id);
