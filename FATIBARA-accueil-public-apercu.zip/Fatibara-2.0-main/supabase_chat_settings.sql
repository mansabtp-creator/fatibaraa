-- Adding chat settings to stores
ALTER TABLE public.stores ADD COLUMN IF NOT EXISTS auto_reply_enabled BOOLEAN DEFAULT false;
ALTER TABLE public.stores ADD COLUMN IF NOT EXISTS auto_reply_message TEXT DEFAULT 'Bonjour ! Merci de nous avoir contactés. Nous reviendrons vers vous dès que possible.';
ALTER TABLE public.stores ADD COLUMN IF NOT EXISTS whatsapp_sync_enabled BOOLEAN DEFAULT false;
