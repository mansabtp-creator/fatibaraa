SELECT
    policyname,
    relname,
    permissive,
    roles,
    cmd,
    qual,
    with_check
FROM
    pg_policies
JOIN
    pg_class ON pg_policies.tablename = pg_class.relname
WHERE
    pg_class.relname = 'order_items';
