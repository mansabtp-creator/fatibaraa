-- FIX RLS POLICIES FOR DELIVERIES TABLE
ALTER TABLE public.deliveries ENABLE ROW LEVEL SECURITY;

-- Allow authenticated users to insert deliveries only for orders they own
-- This prevents users from inserting a delivery for someone else's order
DROP POLICY IF EXISTS "Authenticated users can insert deliveries for their orders" ON public.deliveries;
CREATE POLICY "Authenticated users can insert deliveries for their orders" 
ON public.deliveries FOR INSERT 
TO authenticated
WITH CHECK (
  EXISTS (
    SELECT 1 FROM public.orders 
    WHERE id = order_id AND user_id = auth.uid()
  )
);

-- Ensure users can view their own deliveries
DROP POLICY IF EXISTS "Users can view their order deliveries." ON public.deliveries;
CREATE POLICY "Users can view their order deliveries." 
ON public.deliveries FOR SELECT 
TO authenticated 
USING (
  EXISTS (
    SELECT 1 FROM public.orders 
    WHERE id = order_id AND (user_id = auth.uid() OR vendor_id = auth.uid())
  )
);
