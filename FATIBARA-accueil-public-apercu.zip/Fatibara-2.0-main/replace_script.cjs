const fs = require('fs');
const path = require('path');

function getFiles(dir, files = []) {
  const fileList = fs.readdirSync(dir);
  for (const file of fileList) {
    const name = `${dir}/${file}`;
    if (fs.statSync(name).isDirectory()) {
      getFiles(name, files);
    } else if (name.endsWith('.tsx') || name.endsWith('.ts')) {
      files.push(name);
    }
  }
  return files;
}

const allFiles = [...getFiles('./src/pages'), ...getFiles('./src/components')];

allFiles.forEach(filepath => {
  let content = fs.readFileSync(filepath, 'utf8');

  let oldContent = content;
  content = content.replace(/text-indigo-600/g, 'text-[#ff6600]')
    .replace(/text-indigo-700/g, 'text-[#e62e00]')
    .replace(/text-indigo-500/g, 'text-[#ff6600]')
    .replace(/hover:text-indigo-700/g, 'hover:text-[#e62e00]')
    .replace(/hover:text-indigo-600/g, 'hover:text-[#ff6600]')
    .replace(/bg-indigo-600/g, 'bg-[#ff6600]')
    .replace(/bg-indigo-500/g, 'bg-[#ff6600]')
    .replace(/hover:bg-indigo-600/g, 'hover:bg-[#ff6600]')
    .replace(/hover:bg-indigo-700/g, 'hover:bg-[#e62e00]')
    .replace(/bg-indigo-500\/50/g, 'bg-[#ff6600]/50')
    .replace(/group-hover:bg-indigo-400\/50/g, 'group-hover:bg-[#ff6600]/50')
    .replace(/text-indigo-100/g, 'text-orange-100')
    .replace(/text-indigo-200/g, 'text-orange-200')
    .replace(/text-indigo-300/g, 'text-orange-300')
    .replace(/text-indigo-400/g, 'text-orange-400')
    .replace(/text-indigo-800/g, 'text-orange-800')
    .replace(/text-indigo-900/g, 'text-orange-900')
    .replace(/text-indigo-50/g, 'text-orange-50')
    .replace(/bg-indigo-50/g, 'bg-orange-50')
    .replace(/bg-indigo-100/g, 'bg-orange-100')
    .replace(/bg-indigo-200/g, 'bg-orange-200')
    .replace(/bg-indigo-900/g, 'bg-orange-900')
    .replace(/bg-indigo-800/g, 'bg-orange-800')
    .replace(/bg-indigo-50\/50/g, 'bg-orange-50/50')
    .replace(/group-hover:bg-indigo-50/g, 'group-hover:bg-orange-50')
    .replace(/border-indigo-50/g, 'border-orange-50')
    .replace(/border-indigo-100/g, 'border-orange-100')
    .replace(/border-indigo-200/g, 'border-orange-200')
    .replace(/border-indigo-500/g, 'border-[#ff6600]')
    .replace(/border-indigo-600/g, 'border-[#ff6600]')
    .replace(/hover:border-indigo-500/g, 'hover:border-[#ff6600]')
    .replace(/hover:border-indigo-600/g, 'hover:border-[#ff6600]')
    .replace(/hover:border-indigo-100/g, 'hover:border-orange-100')
    .replace(/focus:ring-indigo-500/g, 'focus:ring-[#ff6600]')
    .replace(/focus:border-indigo-500/g, 'focus:border-[#ff6600]')
    .replace(/focus:ring-indigo-600/g, 'focus:ring-[#ff6600]')
    .replace(/focus:border-indigo-600/g, 'focus:border-[#ff6600]')
    .replace(/bg-indigo-600\/10/g, 'bg-[#ff6600]/10')
    .replace(/bg-indigo-600\/20/g, 'bg-[#ff6600]/20')
    .replace(/bg-indigo-500\/10/g, 'bg-[#ff6600]/10')
    .replace(/bg-indigo-500\/20/g, 'bg-[#ff6600]/20')
    .replace(/border-indigo-600\/10/g, 'border-[#ff6600]/10')
    .replace(/border-indigo-600\/30/g, 'border-[#ff6600]/30')
    .replace(/shadow-indigo-500\/20/g, 'shadow-[#ff6600]/20')
    .replace(/shadow-indigo-600\/20/g, 'shadow-[#ff6600]/20')
    .replace(/fill-indigo-600/g, 'fill-[#ff6600]')
    .replace(/fill-indigo-500/g, 'fill-[#ff6600]');

  if (content !== oldContent) {
    fs.writeFileSync(filepath, content, 'utf8');
    console.log(`done replacing in ${filepath}`);
  }
});
