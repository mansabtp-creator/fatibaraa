-- FLASH DEALS ENGINE INFRASTRUCTURE

CREATE TABLE IF NOT EXISTS public.flash_deals (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    product_id UUID REFERENCES public.products(id) ON DELETE CASCADE NOT NULL,
    store_id UUID REFERENCES public.stores(id) ON DELETE CASCADE NOT NULL,
    discount_price DECIMAL(12,2) NOT NULL,
    start_time TIMESTAMPTZ NOT NULL,
    end_time TIMESTAMPTZ NOT NULL,
    stock_limit INTEGER DEFAULT 10,
    sold_count INTEGER DEFAULT 0,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMPTZ DEFAULT now()
);

ALTER TABLE public.flash_deals ENABLE ROW LEVEL SECURITY;

-- POLICIES
CREATE POLICY "Flash deals are publicly viewable" ON public.flash_deals FOR SELECT USING (is_active = true AND end_time > now());
CREATE POLICY "Vendors can manage own flash deals" ON public.flash_deals FOR ALL USING (store_id IN (SELECT id FROM public.stores WHERE owner_id = auth.uid()));
CREATE POLICY "Admins full access to flash deals" ON public.flash_deals FOR ALL USING ((SELECT is_admin FROM public.profiles WHERE id = auth.uid()) = true);
