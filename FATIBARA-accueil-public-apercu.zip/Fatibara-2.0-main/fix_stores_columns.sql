
-- FIX: Missing columns in stores table
-- Run this in your Supabase SQL Editor

ALTER TABLE public.stores ADD COLUMN IF NOT EXISTS store_status TEXT DEFAULT 'active';
ALTER TABLE public.stores ADD COLUMN IF NOT EXISTS status TEXT DEFAULT 'pending';
ALTER TABLE public.stores ADD COLUMN IF NOT EXISTS logo_dark_url TEXT;
ALTER TABLE public.stores ADD COLUMN IF NOT EXISTS global_sale_active BOOLEAN DEFAULT false;
ALTER TABLE public.stores ADD COLUMN IF NOT EXISTS global_sale_percent INTEGER DEFAULT 0;
ALTER TABLE public.stores ADD COLUMN IF NOT EXISTS payout_orange_money TEXT;
ALTER TABLE public.stores ADD COLUMN IF NOT EXISTS payout_mtn_money TEXT;

-- Update search path
GRANT ALL ON TABLE public.stores TO postgres;
GRANT ALL ON TABLE public.stores TO anon;
GRANT ALL ON TABLE public.stores TO authenticated;
GRANT ALL ON TABLE public.stores TO service_role;
