-- Run this in your Supabase SQL Editor to create the Commerce tables for Phase 2

-- 1. Wishlists Table
CREATE TABLE IF NOT EXISTS public.user_wishlists (
    id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
    user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
    product_id uuid NOT NULL, -- references your products table
    created_at timestamp with time zone DEFAULT timezone('utc'::text, now()) NOT NULL,
    UNIQUE(user_id, product_id) -- Prevents duplicate wishlist items
);

ALTER TABLE public.user_wishlists ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Users can manage their own wishlists" ON public.user_wishlists;
CREATE POLICY "Users can manage their own wishlists"
    ON public.user_wishlists FOR ALL
    USING (auth.uid() = user_id);

-- 2. Shopping Cart Table
CREATE TABLE IF NOT EXISTS public.cart_items (
    id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
    user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
    product_id uuid NOT NULL,
    quantity integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT timezone('utc'::text, now()) NOT NULL,
    UNIQUE(user_id, product_id)
);

ALTER TABLE public.cart_items ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Users can manage their own cart" ON public.cart_items;
CREATE POLICY "Users can manage their own cart"
    ON public.cart_items FOR ALL
    USING (auth.uid() = user_id);

-- Note: No realtime publication needed here unless you expect users 
-- to checkout from extreme multi-tab scenarios, but standard fetches suffice.
