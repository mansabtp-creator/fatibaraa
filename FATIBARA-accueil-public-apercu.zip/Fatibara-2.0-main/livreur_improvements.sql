-- ============================================================================
-- Livreur System Improvements Migration
-- Generated from analysis of the Fatibara Livreur (courier) system
-- Run in Supabase SQL Editor
-- ============================================================================

-- ----------------------------------------------------------------------------
-- 2.1 Add new courier columns to profiles
-- ----------------------------------------------------------------------------

ALTER TABLE profiles
  ADD COLUMN IF NOT EXISTS courier_rejection_reason TEXT,
  ADD COLUMN IF NOT EXISTS courier_approved_at       TIMESTAMPTZ,
  ADD COLUMN IF NOT EXISTS courier_terms_accepted_at TIMESTAMPTZ,
  ADD COLUMN IF NOT EXISTS courier_rating            NUMERIC(3,2) DEFAULT 0;

-- ----------------------------------------------------------------------------
-- 2.2 Create courier_reports table (for "Signaler un problème")
-- ----------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS courier_reports (
  id          UUID         PRIMARY KEY DEFAULT gen_random_uuid(),
  courier_id  UUID         NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  order_id    UUID         REFERENCES orders(id) ON DELETE SET NULL,
  description TEXT         NOT NULL,
  status      TEXT         NOT NULL DEFAULT 'open', -- open | resolved
  created_at  TIMESTAMPTZ  NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS courier_reports_courier_id_idx ON courier_reports(courier_id);
CREATE INDEX IF NOT EXISTS courier_reports_order_id_idx  ON courier_reports(order_id);

ALTER TABLE courier_reports ENABLE ROW LEVEL SECURITY;

-- Couriers can insert their own reports
DROP POLICY IF EXISTS "Couriers can insert own reports" ON courier_reports;
CREATE POLICY "Couriers can insert own reports" ON courier_reports
  FOR INSERT WITH CHECK (courier_id = auth.uid());

-- Couriers can read their own reports
DROP POLICY IF EXISTS "Couriers can read own reports" ON courier_reports;
CREATE POLICY "Couriers can read own reports" ON courier_reports
  FOR SELECT USING (courier_id = auth.uid());

-- Admins can read all reports
DROP POLICY IF EXISTS "Admins can read all reports" ON courier_reports;
CREATE POLICY "Admins can read all reports" ON courier_reports
  FOR ALL USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE id = auth.uid()
        AND active_role IN ('admin', 'super_admin')
    )
  );

-- ----------------------------------------------------------------------------
-- 2.3 Trigger: auto-update courier_rating on new rating insert/update
-- ----------------------------------------------------------------------------

CREATE OR REPLACE FUNCTION update_courier_rating()
RETURNS TRIGGER LANGUAGE plpgsql SECURITY DEFINER AS $$
BEGIN
  UPDATE profiles
  SET courier_rating = (
    SELECT COALESCE(ROUND(AVG(rating)::NUMERIC, 2), 0)
    FROM courier_ratings
    WHERE courier_id = NEW.courier_id
  )
  WHERE id = NEW.courier_id;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_update_courier_rating ON courier_ratings;
CREATE TRIGGER trg_update_courier_rating
  AFTER INSERT OR UPDATE ON courier_ratings
  FOR EACH ROW EXECUTE FUNCTION update_courier_rating();

-- Back-fill courier_rating for all existing couriers
UPDATE profiles p
SET courier_rating = (
  SELECT COALESCE(ROUND(AVG(r.rating)::NUMERIC, 2), 0)
  FROM courier_ratings r
  WHERE r.courier_id = p.id
)
WHERE p.courier_status IS NOT NULL;

-- ----------------------------------------------------------------------------
-- 2.4 Fix courier_locations: add unique index for UPSERT support
-- ----------------------------------------------------------------------------

ALTER TABLE courier_locations
  ADD COLUMN IF NOT EXISTS updated_at TIMESTAMPTZ DEFAULT now();

-- Allow UPSERT on (order_id, courier_id) — keep only latest GPS per order
CREATE UNIQUE INDEX IF NOT EXISTS courier_locations_order_courier_uniq
  ON courier_locations(order_id, courier_id);

-- ----------------------------------------------------------------------------
-- 2.5 Add courier_commission_rate to platform_settings
-- ----------------------------------------------------------------------------

INSERT INTO platform_settings (id, value)
VALUES ('courier_commission_rate', '0.80')
ON CONFLICT (id) DO NOTHING;

-- ----------------------------------------------------------------------------
-- 2.6 Fix accept_order_batch — capacity now counts ALL non-terminal orders
--     (previously only counted 'in_transit', missing 'preparing', etc.)
-- ----------------------------------------------------------------------------

CREATE OR REPLACE FUNCTION accept_order_batch(
  p_order_ids  UUID[],
  p_courier_id UUID
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_active_count INT;
  v_max_capacity INT := 5;
  v_accepted     UUID[] := '{}';
  v_skipped      UUID[] := '{}';
  v_order_id     UUID;
BEGIN
  -- Guard: count ALL active (non-terminal) assignments for this courier
  SELECT COUNT(*) INTO v_active_count
  FROM orders
  WHERE courier_id = p_courier_id
    AND status NOT IN ('delivered', 'cancelled');

  IF v_active_count >= v_max_capacity THEN
    RETURN jsonb_build_object(
      'error',    'Capacité maximale atteinte',
      'accepted', to_jsonb(v_accepted),
      'skipped',  to_jsonb(v_skipped)
    );
  END IF;

  FOREACH v_order_id IN ARRAY p_order_ids LOOP
    EXIT WHEN v_active_count >= v_max_capacity;

    -- Atomic acquire with FOR UPDATE SKIP LOCKED (prevents race conditions)
    UPDATE orders
    SET
      courier_id = p_courier_id,
      updated_at = now()
    WHERE id = v_order_id
      AND status = 'ready_for_pickup'
      AND courier_id IS NULL
      AND fulfillment_type IS DISTINCT FROM 'vendor_self_delivery';

    IF FOUND THEN
      v_accepted     := v_accepted || v_order_id;
      v_active_count := v_active_count + 1;
    ELSE
      v_skipped := v_skipped || v_order_id;
    END IF;
  END LOOP;

  -- Any remaining unprocessed IDs are skipped (capacity hit mid-loop)
  FOREACH v_order_id IN ARRAY p_order_ids LOOP
    IF NOT (v_order_id = ANY(v_accepted)) AND NOT (v_order_id = ANY(v_skipped)) THEN
      v_skipped := v_skipped || v_order_id;
    END IF;
  END LOOP;

  RETURN jsonb_build_object(
    'accepted', to_jsonb(v_accepted),
    'skipped',  to_jsonb(v_skipped)
  );
END;
$$;

-- ----------------------------------------------------------------------------
-- 2.7 Add RLS to courier_locations
-- ----------------------------------------------------------------------------

ALTER TABLE courier_locations ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Courier can manage own locations" ON courier_locations;
CREATE POLICY "Courier can manage own locations" ON courier_locations
  FOR ALL USING (courier_id = auth.uid());

-- Customers can read courier location for their own orders
DROP POLICY IF EXISTS "Customers can read location for own orders" ON courier_locations;
CREATE POLICY "Customers can read location for own orders" ON courier_locations
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM orders o
      WHERE o.id = courier_locations.order_id
        AND o.user_id = auth.uid()
    )
  );

-- ----------------------------------------------------------------------------
-- 2.8 TTL cleanup for courier_locations via pg_cron
--     (uncomment if pg_cron is enabled on your Supabase plan)
-- ----------------------------------------------------------------------------

-- SELECT cron.schedule(
--   'cleanup-courier-locations',
--   '0 3 * * *',
--   $$DELETE FROM courier_locations WHERE created_at < NOW() - INTERVAL '7 days'$$
-- );

-- Manual alternative — run this query periodically:
-- DELETE FROM courier_locations WHERE created_at < NOW() - INTERVAL '7 days';
