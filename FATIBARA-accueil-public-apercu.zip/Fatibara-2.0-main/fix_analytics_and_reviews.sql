ALTER TABLE public.product_views ADD COLUMN IF NOT EXISTS store_id UUID REFERENCES public.stores(id) ON DELETE CASCADE;

CREATE TABLE IF NOT EXISTS public.review_photos (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  review_id UUID REFERENCES public.reviews(id) ON DELETE CASCADE,
  photo_url TEXT NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Ensure policies for review_photos
ALTER TABLE public.review_photos ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Public can view review photos" ON public.review_photos;
CREATE POLICY "Public can view review photos" ON public.review_photos FOR SELECT USING (true);
DROP POLICY IF EXISTS "Users can upload their own review photos" ON public.review_photos;
CREATE POLICY "Users can upload their own review photos" ON public.review_photos FOR INSERT WITH CHECK (
  EXISTS (
    SELECT 1 FROM public.reviews r
    WHERE r.id = review_photos.review_id
    AND r.user_id = auth.uid()
  )
);
