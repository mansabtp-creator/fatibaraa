/**
 * apply_migration.ts
 * ─────────────────────────────────────────────────────────────────────────────
 * Applies the definitive RLS + RPC fix migration to the live Supabase project
 * via the Management API (requires SUPABASE_ACCESS_TOKEN in env), or falls back
 * to executing the SQL via the service-role REST API using pg_dump workaround.
 *
 * Usage:
 *   npx tsx apply_migration.ts
 */

import * as fs from 'fs';
import * as path from 'path';
import * as dotenv from 'dotenv';

dotenv.config({ path: '.env' });
dotenv.config({ path: '.env.local', override: true });

const SUPABASE_URL = process.env.VITE_SUPABASE_URL;
const SERVICE_ROLE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY;

if (!SUPABASE_URL || !SERVICE_ROLE_KEY) {
  console.error('❌ VITE_SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY must be set');
  process.exit(1);
}

const MIGRATION_FILE = path.join(
  process.cwd(),
  'supabase/migrations/20260715_definitive_fix_rpc_and_rls.sql'
);

const sql = fs.readFileSync(MIGRATION_FILE, 'utf-8');

async function runSQL(statement: string): Promise<void> {
  // Supabase exposes a /rest/v1/rpc/exec_sql endpoint only via pg_meta or
  // direct psql. We use the PostgREST rpc route with a SECURITY DEFINER wrapper.
  // The cleanest approach without psql access: use the Supabase REST query endpoint.
  const url = `${SUPABASE_URL}/rest/v1/rpc/exec_sql`;
  const res = await fetch(url, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${SERVICE_ROLE_KEY}`,
      'apikey': SERVICE_ROLE_KEY,
    },
    body: JSON.stringify({ sql_query: statement }),
  });

  if (!res.ok) {
    const text = await res.text();
    throw new Error(`HTTP ${res.status}: ${text}`);
  }
}

// Split the migration into individual statements (by semicolon + newline)
// and apply each one that has actual content.
const statements = sql
  .split(/;\s*\n/)
  .map(s => s.trim())
  .filter(s => s.length > 0 && !s.startsWith('--'));

console.log(`📦 Applying ${statements.length} SQL statements from ${path.basename(MIGRATION_FILE)}…\n`);

(async () => {
  let applied = 0;
  for (const stmt of statements) {
    process.stdout.write(`  ▸ ${stmt.slice(0, 60).replace(/\n/g, ' ')}… `);
    try {
      await runSQL(stmt + ';');
      console.log('✅');
      applied++;
    } catch (err: any) {
      // Many DROP IF EXISTS statements return "no rows" which is fine.
      if (err.message?.includes('does not exist') || err.message?.includes('404')) {
        console.log('⏭  (skipped — object not found, DROP IF EXISTS is safe)');
      } else {
        console.log(`❌\n    Error: ${err.message}`);
      }
    }
  }
  console.log(`\n✅ Migration complete — ${applied} statements applied.`);
})();
